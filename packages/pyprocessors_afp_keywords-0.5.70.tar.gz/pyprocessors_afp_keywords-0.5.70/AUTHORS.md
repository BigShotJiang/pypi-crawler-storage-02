# Authors

Contributors to pyprocessors_afp_keywords include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
