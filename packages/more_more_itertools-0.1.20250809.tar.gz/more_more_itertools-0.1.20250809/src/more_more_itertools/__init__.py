def hello() -> str:
    return "Hello from more-more-itertools!"
