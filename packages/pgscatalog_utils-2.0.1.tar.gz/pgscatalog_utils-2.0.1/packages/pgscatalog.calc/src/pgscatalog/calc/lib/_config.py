import pathlib


class Config:
    ROOT_DIR = pathlib.Path(__file__).resolve().parent.parent.parent.parent.parent
