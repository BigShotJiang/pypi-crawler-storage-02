"""Módulo de autenticação do SDK Sicoob"""

from .oauth import OAuth2Client

__all__ = ['OAuth2Client']
