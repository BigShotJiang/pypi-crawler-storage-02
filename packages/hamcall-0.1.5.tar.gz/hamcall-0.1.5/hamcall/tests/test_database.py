"""Test infrastructure for the database."""


def test_import() -> None:
    """Test module importation."""
    from hamcall import load_db as load_db

    assert True
