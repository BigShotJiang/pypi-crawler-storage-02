import logging
from pyicloud_ipd.base import PyiCloudService

logging.getLogger(__name__).addHandler(logging.NullHandler())
