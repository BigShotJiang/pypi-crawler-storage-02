# launch_napari.py
from napari import Viewer, run

viewer = Viewer()
run()