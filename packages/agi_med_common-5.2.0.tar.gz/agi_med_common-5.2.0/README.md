# agi-med-common

Common компонент

## Ответственный разработчик

@bakulin

## Общая информация

- Общий ChatItem для сервисов
- Общей TrackId
- logger

## Тесты

- `sudo docker compose up --build`
