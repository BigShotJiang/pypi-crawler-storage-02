# QUAL FOLHA DE ESTILO USAR
_ESTILOS = {
    'padrao': 'css/estilo.css',
    'min': 'css/estilo-min.css'
}
ESTILO = _ESTILOS.get('padrao', 'css/estilo.scss')

TITULO = 'Nome do App'
