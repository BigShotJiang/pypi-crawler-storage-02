# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Rsp03(KaitaiStruct):
    """:field dest_callsign: ax25_frame.ax25_header.dest_callsign_raw.callsign_ror.callsign
    :field src_callsign: ax25_frame.ax25_header.src_callsign_raw.callsign_ror.callsign
    :field src_ssid: ax25_frame.ax25_header.src_ssid_raw.ssid
    :field dest_ssid: ax25_frame.ax25_header.dest_ssid_raw.ssid
    :field ctl: ax25_frame.ax25_header.ctl
    :field pid: ax25_frame.ax25_header.pid
    :field no001_header: ax25_frame.payload.no001_header
    :field no002_time: ax25_frame.payload.no002_time
    :field no003_time: ax25_frame.payload.no003_time
    :field beacon_type: ax25_frame.payload.no004_packet_type.type_check.beacon_type
    
    :field no005_telemetry_id: ax25_frame.payload.no004_packet_type.type_check.no005_telemetry_id
    :field no006_cobc_boot_count: ax25_frame.payload.no004_packet_type.type_check.no006_cobc_boot_count
    :field no007_cobc_elapsed_time: ax25_frame.payload.no004_packet_type.type_check.no007_cobc_elapsed_time
    :field no008_satellite_system_time: ax25_frame.payload.no004_packet_type.type_check.no008_satellite_system_time
    :field no009_cobc_temperature: ax25_frame.payload.no004_packet_type.type_check.no009_cobc_temperature
    :field no010_satellite_operation_mode: ax25_frame.payload.no004_packet_type.type_check.no010_satellite_operation_mode
    :field no011_antenna_deployment_status: ax25_frame.payload.no004_packet_type.type_check.no011_antenna_deployment_status
    :field no012_uplink_command_reception_count: ax25_frame.payload.no004_packet_type.type_check.no012_uplink_command_reception_count
    :field no013_cobc_temperature_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no013_cobc_temperature_upper_limit_exceed_count
    :field no014_cobc_temperature_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no014_cobc_temperature_lower_limit_exceed_count
    :field no015_cobc_voltage_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no015_cobc_voltage_upper_limit_exceed_count
    :field no016_cobc_voltage_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no016_cobc_voltage_lower_limit_exceed_count
    :field no017_cobc_current_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no017_cobc_current_upper_limit_exceed_count
    :field no018_cobc_current_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no018_cobc_current_lower_limit_exceed_count
    :field no019_main_radio_temperature_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no019_main_radio_temperature_upper_limit_exceed_count
    :field no020_main_radio_temperature_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no020_main_radio_temperature_lower_limit_exceed_count
    :field no021_main_radio_voltage_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no021_main_radio_voltage_upper_limit_exceed_count
    :field no022_main_radio_voltage_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no022_main_radio_voltage_lower_limit_exceed_count
    :field no023_main_radio_current_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no023_main_radio_current_upper_limit_exceed_count
    :field no024_main_radio_current_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no024_main_radio_current_lower_limit_exceed_count
    :field no025_sub_radio_temperature_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no025_sub_radio_temperature_upper_limit_exceed_count
    :field no026_sub_radio_temperature_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no026_sub_radio_temperature_lower_limit_exceed_count
    :field no027_sub_radio_voltage_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no027_sub_radio_voltage_upper_limit_exceed_count
    :field no028_sub_radio_voltage_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no028_sub_radio_voltage_lower_limit_exceed_count
    :field no029_sub_radio_current_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no029_sub_radio_current_upper_limit_exceed_count
    :field no030_sub_radio_current_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no030_sub_radio_current_lower_limit_exceed_count
    :field no031_aobc_temperature_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no031_aobc_temperature_upper_limit_exceed_count
    :field no032_aobc_temperature_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no032_aobc_temperature_lower_limit_exceed_count
    :field no033_aobc_voltage_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no033_aobc_voltage_upper_limit_exceed_count
    :field no034_aobc_voltage_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no034_aobc_voltage_lower_limit_exceed_count
    :field no035_aobc_current_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no035_aobc_current_upper_limit_exceed_count
    :field no036_aobc_current_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no036_aobc_current_lower_limit_exceed_count
    :field no037_mobc_temperature_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no037_mobc_temperature_upper_limit_exceed_count
    :field no038_mobc_temperature_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no038_mobc_temperature_lower_limit_exceed_count
    :field no039_mobc_voltage_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no039_mobc_voltage_upper_limit_exceed_count
    :field no040_mobc_voltage_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no040_mobc_voltage_lower_limit_exceed_count
    :field no041_mobc_current_upper_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no041_mobc_current_upper_limit_exceed_count
    :field no042_mobc_current_lower_limit_exceed_count: ax25_frame.payload.no004_packet_type.type_check.no042_mobc_current_lower_limit_exceed_count
    :field no043_magnetic_torque_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no043_magnetic_torque_consumption_current
    :field no044_reaction_wheel_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no044_reaction_wheel_consumption_current
    :field no045_antenna_deployment_heater_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no045_antenna_deployment_heater_consumption_current
    :field no046_main_radio_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no046_main_radio_consumption_current
    :field no047_sub_radio_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no047_sub_radio_consumption_current
    :field no048_mobc_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no048_mobc_consumption_current
    :field no049_cobc_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no049_cobc_consumption_current
    :field no050_aobc_consumption_current: ax25_frame.payload.no004_packet_type.type_check.no050_aobc_consumption_current
    :field no051_5v_bus_voltage: ax25_frame.payload.no004_packet_type.type_check.no051_5v_bus_voltage
    :field no052_33v_line_voltage: ax25_frame.payload.no004_packet_type.type_check.no052_33v_line_voltage
    :field no053_bus_current: ax25_frame.payload.no004_packet_type.type_check.no053_bus_current
    :field no054_sap_z_face_voltage: ax25_frame.payload.no004_packet_type.type_check.no054_sap_z_face_voltage
    :field no055_sap_z_face_temperature: ax25_frame.payload.no004_packet_type.type_check.no055_sap_z_face_temperature
    :field no056_sap__z_face_voltage: ax25_frame.payload.no004_packet_type.type_check.no056_sap__z_face_voltage
    :field no057_sap__z_face_temperature: ax25_frame.payload.no004_packet_type.type_check.no057_sap__z_face_temperature
    :field no058_sap_y_face_voltage: ax25_frame.payload.no004_packet_type.type_check.no058_sap_y_face_voltage
    :field no059_sap_y_face_temperature: ax25_frame.payload.no004_packet_type.type_check.no059_sap_y_face_temperature
    :field no060_sap__x_face_voltage: ax25_frame.payload.no004_packet_type.type_check.no060_sap__x_face_voltage
    :field no061_sap__x_face_temperature: ax25_frame.payload.no004_packet_type.type_check.no061_sap__x_face_temperature
    :field no062_sap__y_face_voltage: ax25_frame.payload.no004_packet_type.type_check.no062_sap__y_face_voltage
    :field no063_sap__y_face_temperature: ax25_frame.payload.no004_packet_type.type_check.no063_sap__y_face_temperature
    :field no064_sap_z_face_current: ax25_frame.payload.no004_packet_type.type_check.no064_sap_z_face_current
    :field no065_sap__z_face_current: ax25_frame.payload.no004_packet_type.type_check.no065_sap__z_face_current
    :field no066_sap_y_face_current: ax25_frame.payload.no004_packet_type.type_check.no066_sap_y_face_current
    :field no067_sap__x_face_current: ax25_frame.payload.no004_packet_type.type_check.no067_sap__x_face_current
    :field no068_sap__y_face_current: ax25_frame.payload.no004_packet_type.type_check.no068_sap__y_face_current
    :field no069_battery_1_output_voltage: ax25_frame.payload.no004_packet_type.type_check.no069_battery_1_output_voltage
    :field no070_battery_1_charging_current: ax25_frame.payload.no004_packet_type.type_check.no070_battery_1_charging_current
    :field no071_battery_1_discharging_current: ax25_frame.payload.no004_packet_type.type_check.no071_battery_1_discharging_current
    :field no072_battery_1_temperature: ax25_frame.payload.no004_packet_type.type_check.no072_battery_1_temperature
    :field no073_battery_1_cumulative_charge: ax25_frame.payload.no004_packet_type.type_check.no073_battery_1_cumulative_charge
    :field no074_battery_1_cumulative_discharge: ax25_frame.payload.no004_packet_type.type_check.no074_battery_1_cumulative_discharge
    :field no075_battery_2_output_voltage: ax25_frame.payload.no004_packet_type.type_check.no075_battery_2_output_voltage
    :field no076_battery_2_charging_current: ax25_frame.payload.no004_packet_type.type_check.no076_battery_2_charging_current
    :field no077_battery_2_discharging_current: ax25_frame.payload.no004_packet_type.type_check.no077_battery_2_discharging_current
    :field no078_battery_2_temperature: ax25_frame.payload.no004_packet_type.type_check.no078_battery_2_temperature
    :field no079_battery_2_cumulative_charge: ax25_frame.payload.no004_packet_type.type_check.no079_battery_2_cumulative_charge
    :field no080_battery_2_cumulative_discharge: ax25_frame.payload.no004_packet_type.type_check.no080_battery_2_cumulative_discharge
    :field no081_equipment_power_anomaly_status: ax25_frame.payload.no004_packet_type.type_check.no081_equipment_power_anomaly_status
    :field no082_equipment_power_status: ax25_frame.payload.no004_packet_type.type_check.no082_equipment_power_status
    :field no083_mppt_status: ax25_frame.payload.no004_packet_type.type_check.no083_mppt_status
    :field no084_battery_chargedischarge_controller_status: ax25_frame.payload.no004_packet_type.type_check.no084_battery_chargedischarge_controller_status
    :field no085_internal_equipment_communication_error_status: ax25_frame.payload.no004_packet_type.type_check.no085_internal_equipment_communication_error_status
    :field no086_main_radio_boot_count: ax25_frame.payload.no004_packet_type.type_check.no086_main_radio_boot_count
    :field no087_main_radio_elapsed_time: ax25_frame.payload.no004_packet_type.type_check.no087_main_radio_elapsed_time
    :field no088_main_radio_no_reception_time: ax25_frame.payload.no004_packet_type.type_check.no088_main_radio_no_reception_time
    :field no089_main_radio_rssi: ax25_frame.payload.no004_packet_type.type_check.no089_main_radio_rssi
    :field no090_main_radio_uplink_reception_counter: ax25_frame.payload.no004_packet_type.type_check.no090_main_radio_uplink_reception_counter
    :field no091_main_radio_uplink_modulation: ax25_frame.payload.no004_packet_type.type_check.no091_main_radio_uplink_modulation
    :field no092_main_radio_downlink_modulation: ax25_frame.payload.no004_packet_type.type_check.no092_main_radio_downlink_modulation
    :field no093_main_radio_downlink_protocol: ax25_frame.payload.no004_packet_type.type_check.no093_main_radio_downlink_protocol
    :field no094_main_radio_frequency_lock: ax25_frame.payload.no004_packet_type.type_check.no094_main_radio_frequency_lock
    :field no095_main_radio_pa_temperature: ax25_frame.payload.no004_packet_type.type_check.no095_main_radio_pa_temperature
    :field no096_main_radio_pa_current: ax25_frame.payload.no004_packet_type.type_check.no096_main_radio_pa_current
    :field no097_main_radio_mcu_temperature_: ax25_frame.payload.no004_packet_type.type_check.no097_main_radio_mcu_temperature_
    :field no098_sub_radio_boot_count: ax25_frame.payload.no004_packet_type.type_check.no098_sub_radio_boot_count
    :field no099_sub_radio_elapsed_time: ax25_frame.payload.no004_packet_type.type_check.no099_sub_radio_elapsed_time
    :field no100_sub_radio_no_reception_time: ax25_frame.payload.no004_packet_type.type_check.no100_sub_radio_no_reception_time
    :field no101_sub_radio_rssi: ax25_frame.payload.no004_packet_type.type_check.no101_sub_radio_rssi
    :field no102_sub_radio_uplink_reception_counter: ax25_frame.payload.no004_packet_type.type_check.no102_sub_radio_uplink_reception_counter
    :field no103_sub_radio_uplink_modulation: ax25_frame.payload.no004_packet_type.type_check.no103_sub_radio_uplink_modulation
    :field no104_sub_radio_downlink_modulation: ax25_frame.payload.no004_packet_type.type_check.no104_sub_radio_downlink_modulation
    :field no105_sub_radio_downlink_protocol: ax25_frame.payload.no004_packet_type.type_check.no105_sub_radio_downlink_protocol
    :field no106_sub_radio_frequency_lock: ax25_frame.payload.no004_packet_type.type_check.no106_sub_radio_frequency_lock
    :field no107_sub_radio_pa_temperature: ax25_frame.payload.no004_packet_type.type_check.no107_sub_radio_pa_temperature
    :field no108_sub_radio_pa_current: ax25_frame.payload.no004_packet_type.type_check.no108_sub_radio_pa_current
    :field no109_sub_radio_mcu_temperature: ax25_frame.payload.no004_packet_type.type_check.no109_sub_radio_mcu_temperature
    :field no005_telemetry_id: ax25_frame.payload.no004_packet_type.type_check.no005_telemetry_id
    :field no006_cobc_uptime_: ax25_frame.payload.no004_packet_type.type_check.no006_cobc_uptime_
    :field no007_satellite_system_time: ax25_frame.payload.no004_packet_type.type_check.no007_satellite_system_time
    :field no008_mission_command_execution_result: ax25_frame.payload.no004_packet_type.type_check.no008_mission_command_execution_result
    :field no009_mission_command_execution_result_details: ax25_frame.payload.no004_packet_type.type_check.no009_mission_command_execution_result_details
    :field no010_os_time_at_telemetry_generation: ax25_frame.payload.no004_packet_type.type_check.no010_os_time_at_telemetry_generation
    :field no011_system_time_at_telemetry_generation: ax25_frame.payload.no004_packet_type.type_check.no011_system_time_at_telemetry_generation
    :field no012_mobc_temperature: ax25_frame.payload.no004_packet_type.type_check.no012_mobc_temperature
    :field no013_composition_system_status: ax25_frame.payload.no004_packet_type.type_check.no013_composition_system_status
    :field no014_stt_status: ax25_frame.payload.no004_packet_type.type_check.no014_stt_status
    :field no015_right_ascension_last_acquired_by_stt: ax25_frame.payload.no004_packet_type.type_check.no015_right_ascension_last_acquired_by_stt
    :field no016_declination_last_acquired_by_stt: ax25_frame.payload.no004_packet_type.type_check.no016_declination_last_acquired_by_stt
    :field no017_roll_angle_last_acquired_by_stt: ax25_frame.payload.no004_packet_type.type_check.no017_roll_angle_last_acquired_by_stt
    :field no018_validity_of_acquired_coordinates: ax25_frame.payload.no004_packet_type.type_check.no018_validity_of_acquired_coordinates
    :field no019_image_capture_time: ax25_frame.payload.no004_packet_type.type_check.no019_image_capture_time
    :field no020_most_recent_command_id_1: ax25_frame.payload.no004_packet_type.type_check.no020_most_recent_command_id_1
    :field no021_most_recent_command_result_1: ax25_frame.payload.no004_packet_type.type_check.no021_most_recent_command_result_1
    :field no022_most_recent_command_result_detail_1: ax25_frame.payload.no004_packet_type.type_check.no022_most_recent_command_result_detail_1
    :field no023_most_recent_command_id_2: ax25_frame.payload.no004_packet_type.type_check.no023_most_recent_command_id_2
    :field no024_most_recent_command_result_2: ax25_frame.payload.no004_packet_type.type_check.no024_most_recent_command_result_2
    :field no025_most_recent_command_result_detail_2: ax25_frame.payload.no004_packet_type.type_check.no025_most_recent_command_result_detail_2
    :field no026_most_recent_command_id_3: ax25_frame.payload.no004_packet_type.type_check.no026_most_recent_command_id_3
    :field no027_most_recent_command_result_3: ax25_frame.payload.no004_packet_type.type_check.no027_most_recent_command_result_3
    :field no028_most_recent_command_result_detail_3: ax25_frame.payload.no004_packet_type.type_check.no028_most_recent_command_result_detail_3
    :field no005_telemetry_id: ax25_frame.payload.no004_packet_type.type_check.no005_telemetry_id
    :field no006_cobc_uptime: ax25_frame.payload.no004_packet_type.type_check.no006_cobc_uptime
    :field no007_satellite_system_time: ax25_frame.payload.no004_packet_type.type_check.no007_satellite_system_time
    :field no008_telemetry_type: ax25_frame.payload.no004_packet_type.type_check.no008_telemetry_type
    :field no009_attitude_control_mode: ax25_frame.payload.no004_packet_type.type_check.no009_attitude_control_mode
    :field no010_ground_packet_reception_count: ax25_frame.payload.no004_packet_type.type_check.no010_ground_packet_reception_count
    :field no011_x_axis_rw_mode: ax25_frame.payload.no004_packet_type.type_check.no011_x_axis_rw_mode
    :field no012_x_axis_rw_speed: ax25_frame.payload.no004_packet_type.type_check.no012_x_axis_rw_speed
    :field no013_x_axis_rw_status: ax25_frame.payload.no004_packet_type.type_check.no013_x_axis_rw_status
    :field no014_y_axis_rw_mode: ax25_frame.payload.no004_packet_type.type_check.no014_y_axis_rw_mode
    :field no015_y_axis_rw_speed: ax25_frame.payload.no004_packet_type.type_check.no015_y_axis_rw_speed
    :field no016_y_axis_rw_status: ax25_frame.payload.no004_packet_type.type_check.no016_y_axis_rw_status
    :field no017_z_axis_rw_mode: ax25_frame.payload.no004_packet_type.type_check.no017_z_axis_rw_mode
    :field no018_z_axis_rw_speed: ax25_frame.payload.no004_packet_type.type_check.no018_z_axis_rw_speed
    :field no019_z_axis_rw_status: ax25_frame.payload.no004_packet_type.type_check.no019_z_axis_rw_status
    :field no020_x_axis_mtq_mode: ax25_frame.payload.no004_packet_type.type_check.no020_x_axis_mtq_mode
    :field no021_x_axis_mtq_set_voltage: ax25_frame.payload.no004_packet_type.type_check.no021_x_axis_mtq_set_voltage
    :field no022_x_axis_mtq_status: ax25_frame.payload.no004_packet_type.type_check.no022_x_axis_mtq_status
    :field no023_y_axis_mtq_mode: ax25_frame.payload.no004_packet_type.type_check.no023_y_axis_mtq_mode
    :field no024_y_axis_mtq_set_voltage: ax25_frame.payload.no004_packet_type.type_check.no024_y_axis_mtq_set_voltage
    :field no025_y_axis_mtq_status: ax25_frame.payload.no004_packet_type.type_check.no025_y_axis_mtq_status
    :field no026_z_axis_mtq_mode: ax25_frame.payload.no004_packet_type.type_check.no026_z_axis_mtq_mode
    :field no027_z_axis_mtq_set_voltage: ax25_frame.payload.no004_packet_type.type_check.no027_z_axis_mtq_set_voltage
    :field no028_z_axis_mtq_status: ax25_frame.payload.no004_packet_type.type_check.no028_z_axis_mtq_status
    :field no029_imu1_x_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no029_imu1_x_axis_acceleration
    :field no030_imu1_y_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no030_imu1_y_axis_acceleration
    :field no031_imu1_z_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no031_imu1_z_axis_acceleration
    :field no032_imu1_x_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no032_imu1_x_axis_angular_velocity
    :field no033_imu1_y_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no033_imu1_y_axis_angular_velocity
    :field no034_imu1_z_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no034_imu1_z_axis_angular_velocity
    :field no035_imu1_x_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no035_imu1_x_axis_magnetic_field
    :field no036_imu1_y_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no036_imu1_y_axis_magnetic_field
    :field no037_imu1_z_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no037_imu1_z_axis_magnetic_field
    :field no038_imu1_temperature: ax25_frame.payload.no004_packet_type.type_check.no038_imu1_temperature
    :field no039_imu1_status: ax25_frame.payload.no004_packet_type.type_check.no039_imu1_status
    :field no040_imu2_x_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no040_imu2_x_axis_acceleration
    :field no041_imu2_y_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no041_imu2_y_axis_acceleration
    :field no042_imu2_z_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no042_imu2_z_axis_acceleration
    :field no043_imu2_x_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no043_imu2_x_axis_angular_velocity
    :field no044_imu2_y_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no044_imu2_y_axis_angular_velocity
    :field no045_imu2_z_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no045_imu2_z_axis_angular_velocity
    :field no046_imu2_x_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no046_imu2_x_axis_magnetic_field
    :field no047_imu2_y_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no047_imu2_y_axis_magnetic_field
    :field no048_imu2_z_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no048_imu2_z_axis_magnetic_field
    :field no049_imu2_temperature: ax25_frame.payload.no004_packet_type.type_check.no049_imu2_temperature
    :field no050_imu2_status: ax25_frame.payload.no004_packet_type.type_check.no050_imu2_status
    :field no051_imu3_x_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no051_imu3_x_axis_acceleration
    :field no052_imu3_y_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no052_imu3_y_axis_acceleration
    :field no053_imu3_z_axis_acceleration: ax25_frame.payload.no004_packet_type.type_check.no053_imu3_z_axis_acceleration
    :field no054_imu3_x_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no054_imu3_x_axis_angular_velocity
    :field no055_imu3_y_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no055_imu3_y_axis_angular_velocity
    :field no056_imu3_z_axis_angular_velocity: ax25_frame.payload.no004_packet_type.type_check.no056_imu3_z_axis_angular_velocity
    :field no057_imu3_x_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no057_imu3_x_axis_magnetic_field
    :field no058_imu3_y_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no058_imu3_y_axis_magnetic_field
    :field no059_imu3_z_axis_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no059_imu3_z_axis_magnetic_field
    :field no060_imu3_temperature: ax25_frame.payload.no004_packet_type.type_check.no060_imu3_temperature
    :field no061_imu3_status: ax25_frame.payload.no004_packet_type.type_check.no061_imu3_status
    :field no062_x_axis_rw_proportional_gain: ax25_frame.payload.no004_packet_type.type_check.no062_x_axis_rw_proportional_gain
    :field no063_x_axis_rw_derivative_gain: ax25_frame.payload.no004_packet_type.type_check.no063_x_axis_rw_derivative_gain
    :field no064_y_axis_rw_proportional_gain: ax25_frame.payload.no004_packet_type.type_check.no064_y_axis_rw_proportional_gain
    :field no065_y_axis_rw_derivative_gain: ax25_frame.payload.no004_packet_type.type_check.no065_y_axis_rw_derivative_gain
    :field no066_z_axis_rw_proportional_gain: ax25_frame.payload.no004_packet_type.type_check.no066_z_axis_rw_proportional_gain
    :field no067_z_axis_rw_derivative_gain: ax25_frame.payload.no004_packet_type.type_check.no067_z_axis_rw_derivative_gain
    :field no068_commissioning_runtime_: ax25_frame.payload.no004_packet_type.type_check.no068_commissioning_runtime_
    :field no069_imu_fault_detection_threshold: ax25_frame.payload.no004_packet_type.type_check.no069_imu_fault_detection_threshold
    :field no070_active_imu: ax25_frame.payload.no004_packet_type.type_check.no070_active_imu
    :field no071_bdot_control_voltage: ax25_frame.payload.no004_packet_type.type_check.no071_bdot_control_voltage
    :field no072_bdot_reference_magnetic_field: ax25_frame.payload.no004_packet_type.type_check.no072_bdot_reference_magnetic_field
    
    .. seealso::
       Source - https://rsp03.rymansat.com/assets/pdfs/RSP-03_HK_Beacon_Format(JP)_Rev1R0.pdf
    """
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        self.ax25_frame = Rsp03.Ax25Frame(self._io, self, self._root)

    class Ax25Frame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25_header = Rsp03.Ax25Header(self._io, self, self._root)
            self.payload = Rsp03.Rsp03Payload(self._io, self, self._root)


    class Ax25Header(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.dest_callsign_raw = Rsp03.CallsignRaw(self._io, self, self._root)
            self.dest_ssid_raw = Rsp03.SsidMask(self._io, self, self._root)
            self.src_callsign_raw = Rsp03.CallsignRaw(self._io, self, self._root)
            self.src_ssid_raw = Rsp03.SsidMask(self._io, self, self._root)
            self.ctl = self._io.read_u1()
            self.pid = self._io.read_u1()


    class Callsign(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(6)).decode(u"ASCII")
            if not  ((self.callsign == u"JS1YOY") or (self.callsign == u"JS1YPA")) :
                raise kaitaistruct.ValidationNotAnyOfError(self.callsign, self._io, u"/types/callsign/seq/0")


    class Packet1(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.no005_telemetry_id = self._io.read_u2le()
            self.no006_cobc_boot_count = self._io.read_u4le()
            self.no007_cobc_elapsed_time = self._io.read_u8le()
            self.no008_satellite_system_time = self._io.read_u8le()
            self.no009_cobc_temperature = self._io.read_s1()
            self.no010_satellite_operation_mode = self._io.read_u1()
            self.no011_antenna_deployment_status = self._io.read_u1()
            self.no012_uplink_command_reception_count = self._io.read_u1()
            self.no013_cobc_temperature_upper_limit_exceed_count = self._io.read_u1()
            self.no014_cobc_temperature_lower_limit_exceed_count = self._io.read_u1()
            self.no015_cobc_voltage_upper_limit_exceed_count = self._io.read_u1()
            self.no016_cobc_voltage_lower_limit_exceed_count = self._io.read_u1()
            self.no017_cobc_current_upper_limit_exceed_count = self._io.read_u1()
            self.no018_cobc_current_lower_limit_exceed_count = self._io.read_u1()
            self.no019_main_radio_temperature_upper_limit_exceed_count = self._io.read_u1()
            self.no020_main_radio_temperature_lower_limit_exceed_count = self._io.read_u1()
            self.no021_main_radio_voltage_upper_limit_exceed_count = self._io.read_u1()
            self.no022_main_radio_voltage_lower_limit_exceed_count = self._io.read_u1()
            self.no023_main_radio_current_upper_limit_exceed_count = self._io.read_u1()
            self.no024_main_radio_current_lower_limit_exceed_count = self._io.read_u1()
            self.no025_sub_radio_temperature_upper_limit_exceed_count = self._io.read_u1()
            self.no026_sub_radio_temperature_lower_limit_exceed_count = self._io.read_u1()
            self.no027_sub_radio_voltage_upper_limit_exceed_count = self._io.read_u1()
            self.no028_sub_radio_voltage_lower_limit_exceed_count = self._io.read_u1()
            self.no029_sub_radio_current_upper_limit_exceed_count = self._io.read_u1()
            self.no030_sub_radio_current_lower_limit_exceed_count = self._io.read_u1()
            self.no031_aobc_temperature_upper_limit_exceed_count = self._io.read_u1()
            self.no032_aobc_temperature_lower_limit_exceed_count = self._io.read_u1()
            self.no033_aobc_voltage_upper_limit_exceed_count = self._io.read_u1()
            self.no034_aobc_voltage_lower_limit_exceed_count = self._io.read_u1()
            self.no035_aobc_current_upper_limit_exceed_count = self._io.read_u1()
            self.no036_aobc_current_lower_limit_exceed_count = self._io.read_u1()
            self.no037_mobc_temperature_upper_limit_exceed_count = self._io.read_u1()
            self.no038_mobc_temperature_lower_limit_exceed_count = self._io.read_u1()
            self.no039_mobc_voltage_upper_limit_exceed_count = self._io.read_u1()
            self.no040_mobc_voltage_lower_limit_exceed_count = self._io.read_u1()
            self.no041_mobc_current_upper_limit_exceed_count = self._io.read_u1()
            self.no042_mobc_current_lower_limit_exceed_count = self._io.read_u1()
            self.no043_magnetic_torque_consumption_current = self._io.read_u2le()
            self.no044_reaction_wheel_consumption_current = self._io.read_u2le()
            self.no045_antenna_deployment_heater_consumption_current = self._io.read_u2le()
            self.no046_main_radio_consumption_current = self._io.read_u2le()
            self.no047_sub_radio_consumption_current = self._io.read_u2le()
            self.no048_mobc_consumption_current = self._io.read_u2le()
            self.no049_cobc_consumption_current = self._io.read_u2le()
            self.no050_aobc_consumption_current = self._io.read_u2le()
            self.no051_5v_bus_voltage = self._io.read_u2le()
            self.no052_33v_line_voltage = self._io.read_u2le()
            self.no053_bus_current = self._io.read_u2le()
            self.no054_sap_z_face_voltage = self._io.read_u2le()
            self.no055_sap_z_face_temperature = self._io.read_u2le()
            self.no056_sap__z_face_voltage = self._io.read_u2le()
            self.no057_sap__z_face_temperature = self._io.read_u2le()
            self.no058_sap_y_face_voltage = self._io.read_u2le()
            self.no059_sap_y_face_temperature = self._io.read_u2le()
            self.no060_sap__x_face_voltage = self._io.read_u2le()
            self.no061_sap__x_face_temperature = self._io.read_u2le()
            self.no062_sap__y_face_voltage = self._io.read_u2le()
            self.no063_sap__y_face_temperature = self._io.read_u2le()
            self.no064_sap_z_face_current = self._io.read_u2le()
            self.no065_sap__z_face_current = self._io.read_u2le()
            self.no066_sap_y_face_current = self._io.read_u2le()
            self.no067_sap__x_face_current = self._io.read_u2le()
            self.no068_sap__y_face_current = self._io.read_u2le()
            self.no069_battery_1_output_voltage = self._io.read_u2le()
            self.no070_battery_1_charging_current = self._io.read_u2le()
            self.no071_battery_1_discharging_current = self._io.read_u2le()
            self.no072_battery_1_temperature = self._io.read_u2le()
            self.no073_battery_1_cumulative_charge = self._io.read_u4le()
            self.no074_battery_1_cumulative_discharge = self._io.read_u4le()
            self.no075_battery_2_output_voltage = self._io.read_u2le()
            self.no076_battery_2_charging_current = self._io.read_u2le()
            self.no077_battery_2_discharging_current = self._io.read_u2le()
            self.no078_battery_2_temperature = self._io.read_u2le()
            self.no079_battery_2_cumulative_charge = self._io.read_u4le()
            self.no080_battery_2_cumulative_discharge = self._io.read_u4le()
            self.no081_equipment_power_anomaly_status = self._io.read_u1()
            self.no082_equipment_power_status = self._io.read_u1()
            self.no083_mppt_status = self._io.read_u1()
            self.no084_battery_chargedischarge_controller_status = self._io.read_u1()
            self.no085_internal_equipment_communication_error_status = self._io.read_u1()
            self.no086_main_radio_boot_count = self._io.read_u1()
            self.no087_main_radio_elapsed_time = self._io.read_u1()
            self.no088_main_radio_no_reception_time = self._io.read_u1()
            self.no089_main_radio_rssi = self._io.read_s1()
            self.no090_main_radio_uplink_reception_counter = self._io.read_u1()
            self.no091_main_radio_uplink_modulation = self._io.read_u1()
            self.no092_main_radio_downlink_modulation = self._io.read_u1()
            self.no093_main_radio_downlink_protocol = self._io.read_u1()
            self.no094_main_radio_frequency_lock = self._io.read_u1()
            self.no095_main_radio_pa_temperature = self._io.read_s1()
            self.no096_main_radio_pa_current = self._io.read_u2le()
            self.no097_main_radio_mcu_temperature_ = self._io.read_s1()
            self.no098_sub_radio_boot_count = self._io.read_u1()
            self.no099_sub_radio_elapsed_time = self._io.read_u1()
            self.no100_sub_radio_no_reception_time = self._io.read_u1()
            self.no101_sub_radio_rssi = self._io.read_s1()
            self.no102_sub_radio_uplink_reception_counter = self._io.read_u1()
            self.no103_sub_radio_uplink_modulation = self._io.read_u1()
            self.no104_sub_radio_downlink_modulation = self._io.read_u1()
            self.no105_sub_radio_downlink_protocol = self._io.read_u1()
            self.no106_sub_radio_frequency_lock = self._io.read_u1()
            self.no107_sub_radio_pa_temperature = self._io.read_s1()
            self.no108_sub_radio_pa_current = self._io.read_u2le()
            self.no109_sub_radio_mcu_temperature = self._io.read_s1()

        @property
        def beacon_type(self):
            if hasattr(self, '_m_beacon_type'):
                return self._m_beacon_type

            self._m_beacon_type = 1
            return getattr(self, '_m_beacon_type', None)


    class SsidMask(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ssid_mask = self._io.read_u1()

        @property
        def ssid(self):
            if hasattr(self, '_m_ssid'):
                return self._m_ssid

            self._m_ssid = ((self.ssid_mask & 31) >> 1)
            return getattr(self, '_m_ssid', None)


    class Rsp03Payload(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.no001_header = self._io.read_u4le()
            self.no001_header_1 = self._io.read_u1()
            self.no002_time = self._io.read_u4le()
            self.no003_time = self._io.read_u2le()
            self.no004_packet_type = Rsp03.Rsp03Payload.No004PacketTypeT(self._io, self, self._root)

        class No004PacketTypeT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                _on = self.packet_type
                if _on == 1:
                    self.type_check = Rsp03.Packet1(self._io, self, self._root)
                elif _on == 2:
                    self.type_check = Rsp03.Packet2(self._io, self, self._root)
                elif _on == 3:
                    self.type_check = Rsp03.Packet3(self._io, self, self._root)

            @property
            def packet_type(self):
                if hasattr(self, '_m_packet_type'):
                    return self._m_packet_type

                self._m_packet_type = self._io.read_u1()
                return getattr(self, '_m_packet_type', None)



    class Packet2(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.no005_telemetry_id = self._io.read_u2le()
            self.no006_cobc_uptime_ = self._io.read_u8le()
            self.no007_satellite_system_time = self._io.read_u8le()
            self.no008_mission_command_execution_result = self._io.read_u1()
            self.no009_mission_command_execution_result_details = self._io.read_u2le()
            self.no010_os_time_at_telemetry_generation = self._io.read_u8le()
            self.no011_system_time_at_telemetry_generation = self._io.read_u8le()
            self.no012_mobc_temperature = self._io.read_s1()
            self.no013_composition_system_status = self._io.read_u1()
            self.no014_stt_status = self._io.read_u1()
            self.no015_right_ascension_last_acquired_by_stt = self._io.read_u4le()
            self.no016_declination_last_acquired_by_stt = self._io.read_u4le()
            self.no017_roll_angle_last_acquired_by_stt = self._io.read_u4le()
            self.no018_validity_of_acquired_coordinates = self._io.read_u1()
            self.no019_image_capture_time = self._io.read_u8le()
            self.no020_most_recent_command_id_1 = self._io.read_u1()
            self.no021_most_recent_command_result_1 = self._io.read_u1()
            self.no022_most_recent_command_result_detail_1 = self._io.read_u2le()
            self.no023_most_recent_command_id_2 = self._io.read_u1()
            self.no024_most_recent_command_result_2 = self._io.read_u1()
            self.no025_most_recent_command_result_detail_2 = self._io.read_u2le()
            self.no026_most_recent_command_id_3 = self._io.read_u1()
            self.no027_most_recent_command_result_3 = self._io.read_u1()
            self.no028_most_recent_command_result_detail_3 = self._io.read_u2le()

        @property
        def beacon_type(self):
            if hasattr(self, '_m_beacon_type'):
                return self._m_beacon_type

            self._m_beacon_type = 2
            return getattr(self, '_m_beacon_type', None)


    class CallsignRaw(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self._raw__raw_callsign_ror = self._io.read_bytes(6)
            self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
            _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
            self.callsign_ror = Rsp03.Callsign(_io__raw_callsign_ror, self, self._root)


    class Packet3(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.no005_telemetry_id = self._io.read_u2le()
            self.no006_cobc_uptime = self._io.read_u8le()
            self.no007_satellite_system_time = self._io.read_u8le()
            self.no008_telemetry_type = self._io.read_u1()
            self.no009_attitude_control_mode = self._io.read_u1()
            self.no010_ground_packet_reception_count = self._io.read_u2le()
            self.no011_x_axis_rw_mode = self._io.read_u1()
            self.no012_x_axis_rw_speed = self._io.read_u4le()
            self.no013_x_axis_rw_status = self._io.read_u1()
            self.no014_y_axis_rw_mode = self._io.read_u1()
            self.no015_y_axis_rw_speed = self._io.read_u4le()
            self.no016_y_axis_rw_status = self._io.read_u1()
            self.no017_z_axis_rw_mode = self._io.read_u1()
            self.no018_z_axis_rw_speed = self._io.read_u4le()
            self.no019_z_axis_rw_status = self._io.read_u1()
            self.no020_x_axis_mtq_mode = self._io.read_u1()
            self.no021_x_axis_mtq_set_voltage = self._io.read_u4le()
            self.no022_x_axis_mtq_status = self._io.read_u1()
            self.no023_y_axis_mtq_mode = self._io.read_u1()
            self.no024_y_axis_mtq_set_voltage = self._io.read_u4le()
            self.no025_y_axis_mtq_status = self._io.read_u1()
            self.no026_z_axis_mtq_mode = self._io.read_u1()
            self.no027_z_axis_mtq_set_voltage = self._io.read_u4le()
            self.no028_z_axis_mtq_status = self._io.read_u1()
            self.no029_imu1_x_axis_acceleration = self._io.read_u4le()
            self.no030_imu1_y_axis_acceleration = self._io.read_u4le()
            self.no031_imu1_z_axis_acceleration = self._io.read_u4le()
            self.no032_imu1_x_axis_angular_velocity = self._io.read_u4le()
            self.no033_imu1_y_axis_angular_velocity = self._io.read_u4le()
            self.no034_imu1_z_axis_angular_velocity = self._io.read_u4le()
            self.no035_imu1_x_axis_magnetic_field = self._io.read_u4le()
            self.no036_imu1_y_axis_magnetic_field = self._io.read_u4le()
            self.no037_imu1_z_axis_magnetic_field = self._io.read_u4le()
            self.no038_imu1_temperature = self._io.read_u4le()
            self.no039_imu1_status = self._io.read_u1()
            self.no040_imu2_x_axis_acceleration = self._io.read_u4le()
            self.no041_imu2_y_axis_acceleration = self._io.read_u4le()
            self.no042_imu2_z_axis_acceleration = self._io.read_u4le()
            self.no043_imu2_x_axis_angular_velocity = self._io.read_u4le()
            self.no044_imu2_y_axis_angular_velocity = self._io.read_u4le()
            self.no045_imu2_z_axis_angular_velocity = self._io.read_u4le()
            self.no046_imu2_x_axis_magnetic_field = self._io.read_u4le()
            self.no047_imu2_y_axis_magnetic_field = self._io.read_u4le()
            self.no048_imu2_z_axis_magnetic_field = self._io.read_u4le()
            self.no049_imu2_temperature = self._io.read_u4le()
            self.no050_imu2_status = self._io.read_u1()
            self.no051_imu3_x_axis_acceleration = self._io.read_u4le()
            self.no052_imu3_y_axis_acceleration = self._io.read_u4le()
            self.no053_imu3_z_axis_acceleration = self._io.read_u4le()
            self.no054_imu3_x_axis_angular_velocity = self._io.read_u4le()
            self.no055_imu3_y_axis_angular_velocity = self._io.read_u4le()
            self.no056_imu3_z_axis_angular_velocity = self._io.read_u4le()
            self.no057_imu3_x_axis_magnetic_field = self._io.read_u4le()
            self.no058_imu3_y_axis_magnetic_field = self._io.read_u4le()
            self.no059_imu3_z_axis_magnetic_field = self._io.read_u4le()
            self.no060_imu3_temperature = self._io.read_u4le()
            self.no061_imu3_status = self._io.read_u1()
            self.no062_x_axis_rw_proportional_gain = self._io.read_u4le()
            self.no063_x_axis_rw_derivative_gain = self._io.read_u4le()
            self.no064_y_axis_rw_proportional_gain = self._io.read_u4le()
            self.no065_y_axis_rw_derivative_gain = self._io.read_u4le()
            self.no066_z_axis_rw_proportional_gain = self._io.read_u4le()
            self.no067_z_axis_rw_derivative_gain = self._io.read_u4le()
            self.no068_commissioning_runtime_ = self._io.read_u4le()
            self.no069_imu_fault_detection_threshold = self._io.read_u4le()
            self.no070_active_imu = self._io.read_u1()
            self.no071_bdot_control_voltage = self._io.read_u4le()
            self.no072_bdot_reference_magnetic_field = self._io.read_u4le()

        @property
        def beacon_type(self):
            if hasattr(self, '_m_beacon_type'):
                return self._m_beacon_type

            self._m_beacon_type = 3
            return getattr(self, '_m_beacon_type', None)



