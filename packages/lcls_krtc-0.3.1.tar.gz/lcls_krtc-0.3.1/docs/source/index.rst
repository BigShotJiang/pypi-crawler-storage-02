.. krtc documentation master file, created by
   sphinx-quickstart on Fri May  6 13:32:43 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to krtc's documentation!
================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   usage


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
