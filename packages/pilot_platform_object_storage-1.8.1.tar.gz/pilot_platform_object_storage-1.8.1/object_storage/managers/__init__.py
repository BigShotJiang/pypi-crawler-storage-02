# Copyright (C) 2023-2025 Indoc Systems
#
# Contact Indoc Systems for any questions regarding the use of this source code.

from object_storage.managers.azure_blob_manager import AzureBlobStorageManager

__all__ = ['AzureBlobStorageManager']
