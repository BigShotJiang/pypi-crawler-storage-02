from django.apps import AppConfig


class DjangoPevConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_pev"
