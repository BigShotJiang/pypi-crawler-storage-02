"""QuantConnect MCP Resources Package"""

__all__ = []
