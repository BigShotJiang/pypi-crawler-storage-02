Get detailed information about a specific Lightdash chart.

Retrieves the full configuration and details of a saved chart, including its query structure,
visualization settings, filters, and metadata.

Examples:
- "Show me the details of the revenue chart"
- "Get the configuration for chart with ID abc123"
- "What query does the monthly sales chart use?"