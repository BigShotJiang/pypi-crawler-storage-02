# Variables

::: lume_model.variables
    options:
        members:
            - ConfigEnum
            - Variable
            - ScalarVariable
            - get_variable
