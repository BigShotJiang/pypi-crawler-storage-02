# Utilities

::: lume_model.utils
    options:
        members:
            - variables_as_yaml
            - variables_from_dict
            - variables_from_yaml
            - try_import_module
            - verify_unique_variable_names
            - serialize_variables
            - deserialize_variables
            - get_valid_path
            - replace_relative_paths
