

_schema = {}

_schema['read'] = """
type: object
description: >-
  This connector can be used to reference the
  default dataframe that was passed to the recipe.
properties: {}
"""