from ._level import fix_level_type
from ._parameter import convert_parameter

MISSING_VALUE = 1.0e36
