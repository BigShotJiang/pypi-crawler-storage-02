"""
Utility modules for TempDataset library.

Contains helper classes and functions for data manipulation and generation.
"""