```{include} ../CONTRIBUTING.md
---
end-before: <!-- github-only -->
---
```
