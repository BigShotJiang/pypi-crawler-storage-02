```{include} ../README.md
```

[license]: license
[contributor guide]: contributing
[command-line reference]: usage

```{toctree}
---
hidden:
maxdepth: 2
---

usage
reference
authors
contributing
Code of Conduct <codeofconduct>
License <license>
Changelog <https://github.com/edges-collab/pygsdata/releases>
```
