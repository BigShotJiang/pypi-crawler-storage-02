# Miscellaneous FAQs

## Can I eat soup for breakfast?

You should not.
