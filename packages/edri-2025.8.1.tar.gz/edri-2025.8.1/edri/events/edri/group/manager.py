from edri.dataclass.event import Event, event


@event
class Manager(Event):
    pass
