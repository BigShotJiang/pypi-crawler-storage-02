"""Version number."""

from importlib.metadata import version

__version__ = version("wyoming")

__all__ = ["__version__"]
