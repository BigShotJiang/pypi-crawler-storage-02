__version__ = '0.0.7'
__author__ = 'Emilio Mariscal'
__licence__ = 'AGNU'
