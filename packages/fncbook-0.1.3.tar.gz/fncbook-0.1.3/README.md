# fncbook.py

These are Python versions of the functions in the textbook *Fundamentals of Numerical Computation* by Tobin A. Driscoll and Richard J. Braun. The text can be found [here](https://fncbook.github.io/fnc).
