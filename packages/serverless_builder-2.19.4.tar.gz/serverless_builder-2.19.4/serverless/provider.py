from serverless.aws.provider import Provider as AWSProvider
