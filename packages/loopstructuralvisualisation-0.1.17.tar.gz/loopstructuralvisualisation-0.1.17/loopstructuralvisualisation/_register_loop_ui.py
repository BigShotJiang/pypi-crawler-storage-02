import pyvista
from .trame import initialize


pyvista.trame.jupyter.initialize = initialize
