# loopstructural-visualisation

A LoopStructural interface for pyvista's Plotter class. 


To install `pip install loopstructuralvisualisation` or for a jupyter notebook environment (including the pyvista[jupyuter] dependencies) `pip install loopstructuralvisualisation[jupyter]`

