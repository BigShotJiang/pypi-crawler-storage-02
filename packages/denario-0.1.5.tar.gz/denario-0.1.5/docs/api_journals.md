Classes and instances related to the supported journal styles.

::: denario.paper_agents.journal
::: denario.paper_agents.latex_presets