# Classes

Main data classes employed in Denario.

::: denario.research
::: denario.idea
::: denario.method
::: denario.experiment
::: denario.llm.LLM
    options:
        show_root_heading: true
        show_root_members_full_path: false
