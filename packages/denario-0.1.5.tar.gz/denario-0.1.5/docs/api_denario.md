# Denario

::: denario.Denario
    options:
        show_root_heading: true
        show_root_members_full_path: false