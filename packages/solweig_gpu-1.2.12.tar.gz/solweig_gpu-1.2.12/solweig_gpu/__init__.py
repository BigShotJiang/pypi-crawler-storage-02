__version__ = "1.2.12"
from .solweig_gpu import thermal_comfort
