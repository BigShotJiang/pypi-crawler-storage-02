
class FileNotFoundException(Exception):
    pass
