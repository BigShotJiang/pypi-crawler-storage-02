# Classes for metadata management


