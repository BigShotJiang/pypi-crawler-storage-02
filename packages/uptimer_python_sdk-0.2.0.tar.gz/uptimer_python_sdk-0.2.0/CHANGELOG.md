## 0.2.0 (2025-08-10)

### Feat

- create/update/delete rule methods.
- added method to get all rules
- added regions and get rule API
- added getting workspace list
- add Cursor IDE configuration for testing and development

### Fix

- fixed dependencies in pyproject.toml
