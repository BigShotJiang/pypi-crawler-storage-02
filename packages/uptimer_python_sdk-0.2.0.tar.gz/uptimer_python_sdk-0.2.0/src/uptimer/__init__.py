"""Uptimer Python SDK."""

__version__ = "0.1.0"
