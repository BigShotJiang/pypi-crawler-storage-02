"""Tests for uptimer Python SDK."""
