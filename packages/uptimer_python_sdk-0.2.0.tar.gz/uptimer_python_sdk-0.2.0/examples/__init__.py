"""Examples for the Uptimer Python SDK."""
