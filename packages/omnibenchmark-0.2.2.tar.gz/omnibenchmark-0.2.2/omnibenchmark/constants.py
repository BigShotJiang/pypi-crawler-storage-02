from enum import Enum


class LayoutDesign(Enum):
    Hierarchical = 1
    Spring = 2
