Please replace:
1. EASYCONFIG with the easyconfig basename (e.g. 'zfp-0.5.5-GCCcore-10.2.0.eb', without quotes)
2. ENVMODULENAME with the env module name (e.g. `zfp/0.5.5-GCCcore-10.2.0`)
3. EASYBUILDNTHREADSINT with the desired `EASYBUILD_PARALLEL` int, e.g. 4

Largely inspired from https://github.com/sassy-crick/Singularity-Easybuild 
