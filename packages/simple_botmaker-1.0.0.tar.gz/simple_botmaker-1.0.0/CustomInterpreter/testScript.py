from Definitions import *

screen_width, screen_height = GetScreenResolution()

testFrame = TakeRegionScreenshot(0, 0, screen_width, screen_height)

pixelColour = GetPixelColour(0, 0)
DebugText(testFrame, str(pixelColour), 50, 50)
print("PixelColour: ", pixelColour)

foundResult = FindImageInRegion(0, 0, screen_width, screen_height, "../TestTemplate.png", 0.8, False, 0)
if foundResult is not None:
    DebugRectangle(testFrame, foundResult["x"], foundResult["y"], foundResult["width"], foundResult["height"])
    text = GetText(foundResult["x"], foundResult["y"], foundResult["width"], foundResult["height"])
    DebugText(testFrame, text, foundResult["x"], foundResult["y"])
    print("Text: ", text)

value = GetValue(screen_width - 100, screen_height - 50, screen_width, screen_height)
DebugRectangle(testFrame, screen_width - 100, screen_height - 50, 100, 50)
DebugText(testFrame, value, screen_width - 100, screen_height - 50)
print("Value: ", value)

DisplayDebugFrame(testFrame, True, True, "TestFrame")