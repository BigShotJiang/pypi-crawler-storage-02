## Project Description
raypyng provides a simple API to work with RAY-UI, a software for optical simulation of synchrotron beamlines and x-ray systems developed by Helmholtz-Zentrum Berlin.

raypyng works only under linux distributions.

[Documentation](https://raypyng.readthedocs.io/en/latest/index.html)