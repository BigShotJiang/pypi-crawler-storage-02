class MelodiAPIError(Exception):
    """Custom exception for Melodi API errors."""
    pass
