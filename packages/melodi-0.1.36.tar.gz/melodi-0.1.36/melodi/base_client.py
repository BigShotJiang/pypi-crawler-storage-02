class BaseClient:
    @staticmethod
    def _get_headers():
        return {"Content-Type": "application/json"}

