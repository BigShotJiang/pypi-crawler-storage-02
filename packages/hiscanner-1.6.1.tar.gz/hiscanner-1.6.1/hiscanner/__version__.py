VERSION = (1, 6, 1)
__version__ = '.'.join(map(str, VERSION))