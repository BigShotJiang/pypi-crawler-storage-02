"""Internal utilities - some require AWS dependencies."""

# Always available
from ._MockPandas import pd


__all__ = [
    'pd'
]