from enum import Enum


class Scope(Enum):
    TRANSIENT = 0
    SINGLETON = 1
