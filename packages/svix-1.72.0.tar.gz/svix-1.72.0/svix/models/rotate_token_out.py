# this file is @generated

from .common import BaseModel


class RotateTokenOut(BaseModel):
    ingest_url: str
