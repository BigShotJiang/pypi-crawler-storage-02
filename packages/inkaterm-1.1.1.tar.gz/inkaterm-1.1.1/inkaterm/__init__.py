from inkaterm.procces import main

def ink(file, char = "# ", same = True, pro = {"key": "None", "report": False}):
    return main(file, char, same, pro)