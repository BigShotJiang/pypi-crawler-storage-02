from superqt.switch._toggle_switch import QStyleOptionToggleSwitch, QToggleSwitch

__all__ = ["QStyleOptionToggleSwitch", "QToggleSwitch"]
