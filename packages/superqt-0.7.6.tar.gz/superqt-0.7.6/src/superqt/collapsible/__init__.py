from ._collapsible import QCollapsible

__all__ = ["QCollapsible"]
