from pathlib import Path


class ICO:
    __font_file__ = str(Path(__file__).parent / "icontest.ttf")
    smiley = "ico.\ue900"
