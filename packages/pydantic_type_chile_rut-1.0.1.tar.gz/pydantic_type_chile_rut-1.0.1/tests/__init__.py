"""Tests for pydantic-type-chile-rut package."""
