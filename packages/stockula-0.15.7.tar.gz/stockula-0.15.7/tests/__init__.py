"""Test suite for Stockula."""
