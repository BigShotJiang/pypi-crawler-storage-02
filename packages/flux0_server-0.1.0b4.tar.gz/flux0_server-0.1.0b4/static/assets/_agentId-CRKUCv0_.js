import{j as r,E as n}from"./index-B3TsnAiv.js";const s=function({error:o}){return r.jsx(n,{error:o})};export{s as errorComponent};
