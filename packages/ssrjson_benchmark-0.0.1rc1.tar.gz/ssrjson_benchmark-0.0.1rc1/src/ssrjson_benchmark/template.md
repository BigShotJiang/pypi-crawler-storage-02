# ssrJSON benchmark Report

REV:            `{REV}`
Python:         `{PYTHON}`
Orjson:         `{ORJSON_VER}`
Generated time: {TIME}
OS:             {OS}
SIMD flag:      {SIMD_FLAGS}
Chipset:        {CHIPSET}
Memory:         {MEM}
