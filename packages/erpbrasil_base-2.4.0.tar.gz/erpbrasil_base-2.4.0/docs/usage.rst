=====
Usage
=====

To use erpbrasil.base in a project::

	import erpbrasil.base
