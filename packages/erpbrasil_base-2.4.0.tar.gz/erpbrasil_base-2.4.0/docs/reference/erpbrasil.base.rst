erpbrasil.base
==============

.. testsetup::

    from erpbrasil.base import *

.. automodule:: erpbrasil.base
    :members:
