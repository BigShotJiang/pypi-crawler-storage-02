============
Installation
============

At the command line::

    pip install erpbrasil.base
