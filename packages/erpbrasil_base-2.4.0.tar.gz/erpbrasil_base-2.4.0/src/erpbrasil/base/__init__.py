__version__ = "2.4.0"

from erpbrasil.base.fiscal import *  # noqa: F401,F403
from erpbrasil.base.misc import *  # noqa: F401,F403
