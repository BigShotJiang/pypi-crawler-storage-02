__version__ = "0.1.1"

from .hooks import hatch_register_build_hook
from .plugin import HatchRustBuildHook
from .structs import *
