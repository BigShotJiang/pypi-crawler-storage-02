"""Install `cookit[loguru]` before import this module."""

from .common import (
    logged_suppress as logged_suppress,
    warning_suppress as warning_suppress,
)
