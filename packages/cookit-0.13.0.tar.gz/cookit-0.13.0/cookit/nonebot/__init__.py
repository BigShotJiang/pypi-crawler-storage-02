"""Install `cookit[nonebot-base]` before import this module."""

from .base import *  # noqa: F403
