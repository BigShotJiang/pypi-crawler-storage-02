from .base import add_counter


def main():
    add_counter()
