from ...utils import auto_import_tests

auto_import_tests(__file__, __package__)
