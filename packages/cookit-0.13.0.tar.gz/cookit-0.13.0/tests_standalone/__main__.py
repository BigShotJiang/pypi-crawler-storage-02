import asyncio

from .utils import run_tests

asyncio.run(run_tests())
