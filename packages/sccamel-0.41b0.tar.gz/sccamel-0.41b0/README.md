scCAMEL: single cell Cross- Annotation and Multimodal Estimation on Lineage trajectory

License: GPL version 3
https://pypi.org/project/scCAMEL/

Developed by: Yizhou Hu, Department of Laboratory Medicine, Karolinska Institutet

Tutorials and other informations in :
https://sccamel.readthedocs.io/
