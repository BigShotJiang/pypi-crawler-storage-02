"""Tests for bankinter-converter package."""
