"""Version information for RefChecker."""

__version__ = "1.2.40"