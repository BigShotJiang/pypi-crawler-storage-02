import tensorflow as tf


class MonitorOutput:

	def __init__(self):

		pass


class ReduceLRGradually:

	def __init__(self):
		pass

