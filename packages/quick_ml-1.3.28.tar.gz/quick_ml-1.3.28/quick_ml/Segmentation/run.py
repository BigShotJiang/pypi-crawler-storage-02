class A:
	def __init__(self):
		pass 
