from ddtrace.appsec._iast import _iast_pytest_activation  # noqa: F401
from ddtrace.appsec._iast import ddtrace_iast_flask_patch  # noqa: F401
from ddtrace.appsec._iast import enable_iast_propagation  # noqa: F401
