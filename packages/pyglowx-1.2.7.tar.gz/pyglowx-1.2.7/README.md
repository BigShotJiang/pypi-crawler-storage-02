# pyglow

![GitHub Repo stars](https://img.shields.io/github/stars/BirukBelihu/pyglow)
![GitHub forks](https://img.shields.io/github/forks/BirukBelihu/pyglow)
![GitHub issues](https://img.shields.io/github/issues/BirukBelihu/pyglow)
[![PyPI Downloads](https://static.pepy.tech/badge/pyglowx)](https://pepy.tech/projects/pyglowx)<br>
![Python](https://img.shields.io/pypi/pyversions/pyglowx)

**pyglow** is a lightweight, cross-platform, markdown-style console text formatter library for python.

---
GitHub: [pyglow](https://github.com/BirukBelihu/pyglow)
---

## ✨ Features

- 💻Cross platform (**Windows**, **Linux**, **macOS**)
- ✅ **Markdown-style tags**: `[red]`, `[green bold]`, `[italic underline]`
- 🎨 **Foreground & background colors with support for custom rgb(235, 64, 52) & hexadecimal colors(#eb4034) along with some predefined ANSI
  colors**
- 🪄 **Text styles**: `bold`, `dim`, `italic`, `underline`, `blink`, `strike` & more
- 🔄 **Nested tag support**
- ✅ Autocorrection misspelt tag names.

---

### Sample

![PyGlow Sample](https://github.com/birukbelihu/pyglow/blob/master/images/sample_1.png)

## 📦 Installation

```
pip install pyglowx
```

You can also install pyglow from source code. source code may not be stable, but it will have the latest features and
bug fixes.

Clone the repository:

```
git clone https://github.com/birukbelihu/pyglow.git
```

Go inside the project directory:

```bash
cd pyglow
```

Install pyglow:

```
pip install -e .
```

---

## 🧠 Example Usage

```python
from pyglow.pyglow import PyGlow

PyGlow.print("[cyan bold]pyglow[/] is a lightweight, [bold]markdown-style console text formatter[/] library for Python. \nIt enables developers to output styled text in the terminal using simple and readable tags like `[red bold]Error[/]`.")
```

### Output

![pyglow Output](https://github.com/birukbelihu/pyglow/blob/master/images/sample_2.png)

---

## 📦 Library Overview

| Function                             | Description                                               |
|--------------------------------------|-----------------------------------------------------------|
| `Pyglow.parse(str text)`             | Converts your markdown-style tags to ANSI-coded string    |
| `Pyglow.print(str text)`             | Prints the text with the provided style                   |
| `Pyglow.prints(str text, str style)` | Prints the text with a provided style for the entire text |

---

## 📄 Demo & Documentation

Check out [main.py](https://github.com/birukbelihu/pyglow/blob/master/main.py) for:

- ✅ Full usage examples
- ✅ Tag reference documentation
- ✅ Quickstart code snippets

---

## 🙌 Contribute

Want to improve `pyglow`? Contributions are welcome!

---

Shine bright in your terminal! 🚀
Made with ❤️ by **[BirukBelihu](https://github.com/birukbelihu)**

---

## 📢 Social Media

- 📺 [YouTube: @pythondevs](https://youtube.com/@pythondevs?si=_CZxaEBwDkQEj4je)

---

## 📄 License

This project is licensed under the **Apache License 2.0**. See
the [LICENSE](https://github.com/birukbelihu/pyglow/blob/master/LICENSE) file for details.