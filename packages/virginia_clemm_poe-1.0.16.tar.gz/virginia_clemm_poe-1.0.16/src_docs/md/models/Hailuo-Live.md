# [Hailuo-Live](https://poe.com/Hailuo-Live)

## Pricing

| Type | Cost |
|------|------|
| Video Output | 14167 points / message |
| Initial Points Cost | Variable points |

**Last Checked:** 2025-08-05 23:26:18.071920


## Bot Information

**Creator:** @fal

**Description:** Hailuo Live, the latest model from Minimax, sets a new standard for bringing still images to life. From breathtakingly vivid motion to finely tuned expressions, this state-of-the-art model enables your characters to captivate, move, and shine like never before. It excels in bring art and drawings to life, exceptional realism without morphing, emotional range, and unparalleled character consistency.

**Extra:** Powered by a server managed by @fal. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** video

**Modality:** text->video


## Technical Details

**Model ID:** `Hailuo-Live`

**Object Type:** model

**Created:** 1734370063740

**Owned By:** poe

**Root:** Hailuo-Live
