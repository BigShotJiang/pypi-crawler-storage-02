# [Claude-Sonnet-3.5-Search](https://poe.com/Claude-Sonnet-3.5-Search)

## Pricing

| Type | Cost |
|------|------|
| Input Text | 115 points/1k tokens |
| Input Image | Variable |
| Bot Message | 438 points/message |
| Chat History | Input rates are applied |
| Chat History Cache Discount | 90% discount oncached chat history |
| Initial Points Cost | 465+ points |

**Last Checked:** 2025-08-05 23:17:10.530327


## Bot Information

**Creator:** @anthropic

**Description:** Claude Sonnet 3.5 with access to real-time information from the web.

**Extra:** Powered by Anthropic: claude-3-5-sonnet-20241022. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Claude-Sonnet-3.5-Search`

**Object Type:** model

**Created:** 1747285956234

**Owned By:** poe

**Root:** Claude-Sonnet-3.5-Search
