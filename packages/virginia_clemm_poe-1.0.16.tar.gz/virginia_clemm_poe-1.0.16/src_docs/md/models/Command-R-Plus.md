# [Command-R-Plus](https://poe.com/Command-R-Plus)

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 1130 points/message |
| Initial Points Cost | 1130 points |

**Last Checked:** 2025-08-05 23:18:08.873554


## Bot Information

**Creator:** @cohere

**Description:** A supercharged version of Command R. I can search the web for up to date information and respond in over 10 languages!

**Extra:** Powered by a server managed by @cohere. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Command-R-Plus`

**Object Type:** model

**Created:** 1712716481132

**Owned By:** poe

**Root:** Command-R-Plus
