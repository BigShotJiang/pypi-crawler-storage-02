*****
Usage
*****

Generating Facturae Invoices
============================

In order to let Tryton know that the Facturae format should be used for a
`Party <party:model-party.party>` a value must be set for it's *Facturae*
field. When a value is set  Tryton creates a `Facturae Record
<model-account.invoice.facturae>` for each invoice.

If you used the *Manual* method you will be able to export the facturae
format using a button.
