##########################
Account Es Facturae Module
##########################

The *Account Es Facturae Module* allow to export invoices with `FacturaE format
<https://www.facturae.gob.es/Paginas/Index.aspx>`_
portal.
This is legal requirement for invoicing public entities.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
