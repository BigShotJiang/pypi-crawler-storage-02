============================
 Data Persistence / Caching
============================

This section explains how to save or cache data with InSpice.
