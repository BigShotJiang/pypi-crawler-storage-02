#skip#

####################################################################################################

from Pyterate.RstFactory.Settings import DefaultRstFactorySettings

####################################################################################################

class RstFactorySettings(DefaultRstFactorySettings):

    # Flags
    show_counters = True # Show documents counters in toc
