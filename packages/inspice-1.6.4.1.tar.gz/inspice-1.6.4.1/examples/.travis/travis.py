# Travis test
#skip#
raise NameError('Failure')
