"""Extensions to base pytest-respect functionality."""
