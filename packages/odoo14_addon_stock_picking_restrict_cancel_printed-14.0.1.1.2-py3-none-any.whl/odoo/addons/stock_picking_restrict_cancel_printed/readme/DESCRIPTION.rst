Display the printed flag on the form view of the transfer.
Raise an error when canceling a printed stock transfer: `You cannot cancel a transfer that is already printed.`
The restriction for canceling a printed transfer can be disabled
with the field `Restrict cancelation if printed` on the transfer type.

