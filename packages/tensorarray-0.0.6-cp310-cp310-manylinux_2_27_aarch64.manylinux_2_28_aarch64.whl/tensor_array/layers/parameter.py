from tensor_array.core import Tensor

class Parameter(Tensor):
    pass
