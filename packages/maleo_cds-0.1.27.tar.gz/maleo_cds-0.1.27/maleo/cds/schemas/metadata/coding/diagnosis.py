from maleo.soma.mixins.timestamp import Duration


class GenerateDifferentialDiagnosesMetadataSchema(Duration):
    pass
