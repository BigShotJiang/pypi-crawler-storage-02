ETHEREUM = "ethereum"
ETH = "ETH"
