"""MCP server for Kreuzberg text extraction."""

from .server import mcp

__all__ = ["mcp"]
