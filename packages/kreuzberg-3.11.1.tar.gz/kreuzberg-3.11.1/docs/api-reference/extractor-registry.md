# Extractor Registry

The [`ExtractorRegistry`](../api-reference/extractor-registry.md) manages document extractors and allows custom extractor registration.

::: kreuzberg.ExtractorRegistry
