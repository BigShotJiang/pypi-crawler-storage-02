# DJPay
A reusable Django app for handling various type of paying methods
