"""
支持 python -m docx_image_extractor_mcp 运行
"""

from .interfaces.cli import main

if __name__ == "__main__":
    main()