# Falyx CLI Framework — (c) 2025 rtj.dev LLC — MIT Licensed
"""Global logger instance for Falyx CLI applications."""
import logging

logger: logging.Logger = logging.getLogger("falyx")
