To use this module, you need to:

1.  Configure the service, customers and contracts as described in the
    CONFIGURATION section.
2.  Create an invoice for a customer with an open Postfinance contract.
3.  Validate the invoice, and click the Send eBill button.
