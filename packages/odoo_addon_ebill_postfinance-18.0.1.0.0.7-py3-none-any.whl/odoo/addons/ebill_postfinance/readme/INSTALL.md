This module needs the Python library ebilling_postfinance which can be
installed from Pypi. More information can be found at
[repository https://github.com/camptocamp/ebilling-postfinance](repository%20https://github.com/camptocamp/ebilling-postfinance).
