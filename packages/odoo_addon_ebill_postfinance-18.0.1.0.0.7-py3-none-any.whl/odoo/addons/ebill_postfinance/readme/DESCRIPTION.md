This module implements the exchange of electronic invoices with the
Postfinance web service.
