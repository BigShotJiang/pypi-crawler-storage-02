from jaix.suite.suite import Suite, AggType, SuiteConfig
from jaix.suite.ec_suite import ECSuiteConfig, ECSuite
