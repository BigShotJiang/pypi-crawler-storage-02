"""Commands package for MCP Code Indexer."""
