#FLM: Select composites
from fakeLabDemo.selection.composites import selectComposites
selectComposites(fl.font)
