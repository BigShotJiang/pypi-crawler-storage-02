FL.objects.KerningPair.KerningPair
==================================

.. currentmodule:: FL.objects.KerningPair

.. autoclass:: KerningPair
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~KerningPair.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~KerningPair.fake_parent
      ~KerningPair.key
      ~KerningPair.parent
      ~KerningPair.value
      ~KerningPair.values
   
   