FL.objects.Guide.Guide
======================

.. currentmodule:: FL.objects.Guide

.. autoclass:: Guide
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Guide.Transform
      ~Guide.TransformLayer
      ~Guide.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Guide.parent
   
   