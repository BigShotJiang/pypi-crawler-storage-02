FL.objects.TTH.base\_vstems
===========================

.. currentmodule:: FL.objects

.. autoattribute:: TTH.base_vstems