FL.objects.Image.Image
======================

.. currentmodule:: FL.objects.Image

.. autoclass:: Image
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Image.__init__
   
   

   
   
   