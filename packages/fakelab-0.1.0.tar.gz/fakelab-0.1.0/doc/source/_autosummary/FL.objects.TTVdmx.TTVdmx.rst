FL.objects.TTVdmx.TTVdmx
========================

.. currentmodule:: FL.objects.TTVdmx

.. autoclass:: TTVdmx
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTVdmx.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTVdmx.y_max
      ~TTVdmx.y_min
      ~TTVdmx.y_pel_height
   
   