FL.objects.TTStem.TTStem
========================

.. currentmodule:: FL.objects.TTStem

.. autoclass:: TTStem
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTStem.__init__
      ~TTStem.fake_recalc_ppms
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTStem.name
      ~TTStem.ppm2
      ~TTStem.ppm3
      ~TTStem.ppm4
      ~TTStem.ppm5
      ~TTStem.ppm6
      ~TTStem.width
   
   