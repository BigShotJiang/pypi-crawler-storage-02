FL.helpers.nametables.StandardNametable
=======================================

.. currentmodule:: FL.helpers.nametables

.. autoclass:: StandardNametable
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~StandardNametable.__init__
      ~StandardNametable.get_name_for_unicode
      ~StandardNametable.get_unicodes_for_name
   
   

   
   
   