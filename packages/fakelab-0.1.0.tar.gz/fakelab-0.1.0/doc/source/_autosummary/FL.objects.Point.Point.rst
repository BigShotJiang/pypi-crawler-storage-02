FL.objects.Point.Point
======================

.. currentmodule:: FL.objects.Point

.. autoclass:: Point
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Point.Add
      ~Point.Assign
      ~Point.Mul
      ~Point.Shift
      ~Point.Sub
      ~Point.Transform
      ~Point.__init__
      ~Point.fake_update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Point.parent
      ~Point.x
      ~Point.y
   
   