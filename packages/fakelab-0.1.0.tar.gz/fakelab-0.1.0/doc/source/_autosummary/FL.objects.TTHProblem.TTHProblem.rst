FL.objects.TTHProblem.TTHProblem
================================

.. currentmodule:: FL.objects.TTHProblem

.. autoclass:: TTHProblem
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTHProblem.__init__
      ~TTHProblem.fake_create
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTHProblem.command
      ~TTHProblem.direction
      ~TTHProblem.id
   
   