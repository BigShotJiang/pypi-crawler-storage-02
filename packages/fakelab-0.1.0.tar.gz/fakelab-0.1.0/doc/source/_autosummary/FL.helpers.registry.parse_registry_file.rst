FL.helpers.registry.parse\_registry\_file
=========================================

.. currentmodule:: FL.helpers.registry

.. autofunction:: parse_registry_file