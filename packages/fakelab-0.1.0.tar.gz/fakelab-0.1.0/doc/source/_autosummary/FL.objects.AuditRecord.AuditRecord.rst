FL.objects.AuditRecord.AuditRecord
==================================

.. currentmodule:: FL.objects.AuditRecord

.. autoclass:: AuditRecord
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AuditRecord.CanBeFixed
      ~AuditRecord.Repair
      ~AuditRecord.__init__
      ~AuditRecord.fake_create
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AuditRecord.description
      ~AuditRecord.id
      ~AuditRecord.index
      ~AuditRecord.p
      ~AuditRecord.parent
      ~AuditRecord.position
   
   