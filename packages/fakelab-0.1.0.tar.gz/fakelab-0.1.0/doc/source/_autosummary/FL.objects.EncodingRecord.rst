﻿FL.objects.EncodingRecord
=========================

.. automodule:: FL.objects.EncodingRecord
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      EncodingRecord
   
   

   
   
   



