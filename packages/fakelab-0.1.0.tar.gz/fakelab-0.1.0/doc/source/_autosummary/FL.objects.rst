﻿FL.objects
==========

.. automodule:: FL.objects
  
   
   
   

   
   
   

   
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :template: custom-module-template.rst
   :recursive:

   Anchor
   AuditRecord
   Canvas
   Component
   Dialog
   Encoding
   EncodingRecord
   Feature
   Font
   FontLab
   Glyph
   Guide
   Hint
   Image
   KerningPair
   Link
   Matrix
   NameRecord
   Node
   Options
   Point
   Rect
   Replace
   TTGasp
   TTH
   TTHCommand
   TTHPoint
   TTHProblem
   TTInfo
   TTPoint
   TTStem
   TTVdmx
   TrueTypeTable
   Uni
   WeightVector

