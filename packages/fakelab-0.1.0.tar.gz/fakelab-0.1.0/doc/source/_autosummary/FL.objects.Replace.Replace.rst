FL.objects.Replace.Replace
==========================

.. currentmodule:: FL.objects.Replace

.. autoclass:: Replace
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Replace.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Replace.index
      ~Replace.parent
      ~Replace.type
   
   