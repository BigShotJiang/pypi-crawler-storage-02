FL.objects.Encoding.data
========================

.. currentmodule:: FL.objects

.. autoattribute:: Encoding.data