FL.objects.TrueTypeTable.TrueTypeTable
======================================

.. currentmodule:: FL.objects.TrueTypeTable

.. autoclass:: TrueTypeTable
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeTable.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TrueTypeTable.parent
      ~TrueTypeTable.tag
      ~TrueTypeTable.value
   
   