FL.objects.TTH.base\_hstems
===========================

.. currentmodule:: FL.objects

.. autoattribute:: TTH.base_hstems