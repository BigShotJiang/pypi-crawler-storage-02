FL.objects.Encoding.Encoding
============================

.. currentmodule:: FL.objects.Encoding

.. autoclass:: Encoding
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Encoding.FillUnencoded
      ~Encoding.FillUnicodes
      ~Encoding.FindName
      ~Encoding.Load
      ~Encoding.Save
      ~Encoding.__init__
      ~Encoding.append
      ~Encoding.clear
      ~Encoding.copy
      ~Encoding.count
      ~Encoding.extend
      ~Encoding.index
      ~Encoding.insert
      ~Encoding.load_font_default
      ~Encoding.pop
      ~Encoding.remove
      ~Encoding.reverse
      ~Encoding.sort
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Encoding.data
      ~Encoding.parent
   
   