FL.objects.WeightVector.WeightVector
====================================

.. currentmodule:: FL.objects.WeightVector

.. autoclass:: WeightVector
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~WeightVector.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~WeightVector.parent
   
   