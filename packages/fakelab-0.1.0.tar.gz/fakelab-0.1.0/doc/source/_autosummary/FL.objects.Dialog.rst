﻿FL.objects.Dialog
=================

.. automodule:: FL.objects.Dialog
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      Dialog
   
   

   
   
   



