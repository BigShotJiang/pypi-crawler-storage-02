FL.objects.EncodingRecord.EncodingRecord
========================================

.. currentmodule:: FL.objects.EncodingRecord

.. autoclass:: EncodingRecord
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~EncodingRecord.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~EncodingRecord.name
      ~EncodingRecord.unicode
   
   