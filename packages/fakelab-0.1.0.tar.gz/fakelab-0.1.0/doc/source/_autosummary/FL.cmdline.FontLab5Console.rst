FL.cmdline.FontLab5Console
==========================

.. currentmodule:: FL.cmdline

.. autoclass:: FontLab5Console
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FontLab5Console.__init__
      ~FontLab5Console.interact
      ~FontLab5Console.push
      ~FontLab5Console.raw_input
      ~FontLab5Console.resetbuffer
      ~FontLab5Console.runcode
      ~FontLab5Console.runsource
      ~FontLab5Console.showsyntaxerror
      ~FontLab5Console.showtraceback
      ~FontLab5Console.write
   
   

   
   
   