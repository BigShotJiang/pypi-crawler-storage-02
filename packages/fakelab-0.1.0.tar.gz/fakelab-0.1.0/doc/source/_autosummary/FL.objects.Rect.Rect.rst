FL.objects.Rect.Rect
====================

.. currentmodule:: FL.objects.Rect

.. autoclass:: Rect
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Rect.Assign
      ~Rect.Check
      ~Rect.Include
      ~Rect.Resize
      ~Rect.Shift
      ~Rect.Transform
      ~Rect.Validate
      ~Rect.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Rect.height
      ~Rect.ll
      ~Rect.ur
      ~Rect.width
      ~Rect.x
      ~Rect.y
   
   