FL.objects.TTGasp.TTGasp
========================

.. currentmodule:: FL.objects.TTGasp

.. autoclass:: TTGasp
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTGasp.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTGasp.behavior
      ~TTGasp.ppm
   
   