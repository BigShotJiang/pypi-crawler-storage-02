FL.fake.Kerning.FakeKerning
===========================

.. currentmodule:: FL.fake.Kerning

.. autoclass:: FakeKerning
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FakeKerning.__init__
      ~FakeKerning.expand
      ~FakeKerning.export_afm
      ~FakeKerning.export_flc
      ~FakeKerning.import_afm
      ~FakeKerning.import_classes_from_font
      ~FakeKerning.import_flc
      ~FakeKerning.reset_classes
      ~FakeKerning.reset_pairs
   
   

   
   
   