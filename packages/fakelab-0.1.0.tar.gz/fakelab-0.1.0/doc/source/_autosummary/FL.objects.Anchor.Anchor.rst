FL.objects.Anchor.Anchor
========================

.. currentmodule:: FL.objects.Anchor

.. autoclass:: Anchor
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Anchor.Transform
      ~Anchor.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Anchor.mark
      ~Anchor.name
      ~Anchor.p
      ~Anchor.parent
      ~Anchor.x
      ~Anchor.y
   
   