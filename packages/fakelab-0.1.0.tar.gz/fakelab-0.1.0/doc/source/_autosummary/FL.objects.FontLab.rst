FL.objects.FontLab
==================

.. automodule:: FL.objects.FontLab
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      FakeLab
   
   

   
   
   



