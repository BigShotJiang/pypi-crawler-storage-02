FL.objects.Link.Link
====================

.. currentmodule:: FL.objects.Link

.. autoclass:: Link
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Link.ToHint
      ~Link.__init__
      ~Link.set_defaults
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Link.node1
      ~Link.node2
      ~Link.parent
   
   