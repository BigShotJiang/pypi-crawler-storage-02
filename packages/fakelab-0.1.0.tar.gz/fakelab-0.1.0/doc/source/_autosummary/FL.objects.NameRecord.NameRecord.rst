FL.objects.NameRecord.NameRecord
================================

.. currentmodule:: FL.objects.NameRecord

.. autoclass:: NameRecord
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NameRecord.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NameRecord.eid
      ~NameRecord.lid
      ~NameRecord.name
      ~NameRecord.nid
      ~NameRecord.parent
      ~NameRecord.pid
   
   