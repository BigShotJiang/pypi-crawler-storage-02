FL.fake.Base.Copyable
=====================

.. currentmodule:: FL.fake.Base

.. autoclass:: Copyable
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Copyable.__init__
   
   

   
   
   