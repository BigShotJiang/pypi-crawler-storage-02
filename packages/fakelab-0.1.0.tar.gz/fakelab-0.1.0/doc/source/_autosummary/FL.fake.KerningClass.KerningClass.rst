FL.fake.KerningClass.KerningClass
=================================

.. currentmodule:: FL.fake.KerningClass

.. autoclass:: KerningClass
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~KerningClass.__init__
      ~KerningClass.fromFontLabClass
      ~KerningClass.getFontLabExternalClassCode
      ~KerningClass.importFromFontLabClass
      ~KerningClass.importFromMMClass
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~KerningClass.keyglyph
   
   