FL.objects.Matrix.Matrix
========================

.. currentmodule:: FL.objects.Matrix

.. autoclass:: Matrix
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Matrix.Add
      ~Matrix.Assign
      ~Matrix.Mul
      ~Matrix.Sub
      ~Matrix.Transform
      ~Matrix.__init__
      ~Matrix.fake_transform_point
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Matrix.a
      ~Matrix.b
      ~Matrix.c
      ~Matrix.d
      ~Matrix.e
      ~Matrix.f
   
   