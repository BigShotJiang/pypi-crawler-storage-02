﻿FL.objects.KerningPair
======================

.. automodule:: FL.objects.KerningPair
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      KerningPair
   
   

   
   
   



