FL.fake.KerningClass
====================

.. automodule:: FL.fake.KerningClass
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      KerningClass
   
   

   
   
   



