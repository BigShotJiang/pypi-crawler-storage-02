FL.helpers.FLList.adjust\_list
==============================

.. currentmodule:: FL.helpers.FLList

.. autofunction:: adjust_list