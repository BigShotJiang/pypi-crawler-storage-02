FL.objects.Uni.Uni
==================

.. currentmodule:: FL.objects.Uni

.. autoclass:: Uni
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Uni.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Uni.value
   
   