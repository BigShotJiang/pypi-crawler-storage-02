FL.vfb.writer.FontToVfbWriter
=============================

.. currentmodule:: FL.vfb.writer

.. autoclass:: FontToVfbWriter
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FontToVfbWriter.__init__
      ~FontToVfbWriter.add_direct_entries
      ~FontToVfbWriter.add_entry
      ~FontToVfbWriter.compile
      ~FontToVfbWriter.compile_encoding
      ~FontToVfbWriter.compile_font_info
      ~FontToVfbWriter.compile_glyphs
      ~FontToVfbWriter.compile_header
      ~FontToVfbWriter.compile_options
      ~FontToVfbWriter.compile_ttinfo
   
   

   
   
   