FL.objects.Feature.Feature
==========================

.. currentmodule:: FL.objects.Feature

.. autoclass:: Feature
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Feature.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Feature.parent
      ~Feature.tag
      ~Feature.value
   
   