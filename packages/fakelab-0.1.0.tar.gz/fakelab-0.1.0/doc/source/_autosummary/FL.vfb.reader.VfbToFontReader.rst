FL.vfb.reader.VfbToFontReader
=============================

.. currentmodule:: FL.vfb.reader

.. autoclass:: VfbToFontReader
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbToFontReader.__init__
      ~VfbToFontReader.open_vfb
      ~VfbToFontReader.read_into_font
   
   

   
   
   