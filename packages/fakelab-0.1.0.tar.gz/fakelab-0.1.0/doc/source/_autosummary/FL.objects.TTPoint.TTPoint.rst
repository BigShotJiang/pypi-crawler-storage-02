FL.objects.TTPoint.TTPoint
==========================

.. currentmodule:: FL.objects.TTPoint

.. autoclass:: TTPoint
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTPoint.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTPoint.flag
      ~TTPoint.x
      ~TTPoint.y
   
   