FL.fake.Font.FakeFont
=====================

.. currentmodule:: FL.fake.Font

.. autoclass:: FakeFont
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FakeFont.__init__
      ~FakeFont.fake_binary_from_path
      ~FakeFont.fake_binary_get
      ~FakeFont.fake_deselect_all
      ~FakeFont.fake_select
      ~FakeFont.fake_set_class_flags
      ~FakeFont.fake_update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~FakeFont.fake_sparse_json
      ~FakeFont.fake_vfb_object
      ~FakeFont.fake_kerning
   
   