# SSA

The Social Security Administration administers Social Security benefits and the Supplemental Security Income (SSI) program.
