Roadmap
=======

- Support for more database backends (e.g. PostgreSQL, MySQL)
- Improved role-based access control
- Real-time updates via WebSockets
- CLI tooling for project scaffolding

