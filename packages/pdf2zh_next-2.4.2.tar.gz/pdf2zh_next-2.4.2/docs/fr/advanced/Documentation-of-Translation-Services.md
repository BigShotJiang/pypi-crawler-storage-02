[**Options avancées**](./introduction.md) > **Documentation des services de traduction** _(actuel)_

---

### Visualisation des services de traduction disponibles via la ligne de commande

Vous pouvez confirmer les services de traduction disponibles et leur utilisation en affichant le message d'aide dans la ligne de commande.

```bash
pdf2zh_next -h
```

À la fin du message d'aide, vous pouvez consulter des informations détaillées sur les différents services de traduction.

<div align="right"> 
<h6><small>Une partie du contenu de cette page a été traduite par GPT et peut contenir des erreurs.</small></h6>