text = """
Retry?
"""

parse_mode = "HTML"
buttons = []
