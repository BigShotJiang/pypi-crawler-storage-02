from qstrings import Q


def test_q_class():
    assert Q()
