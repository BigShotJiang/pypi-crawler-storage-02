class Q:
    pass
