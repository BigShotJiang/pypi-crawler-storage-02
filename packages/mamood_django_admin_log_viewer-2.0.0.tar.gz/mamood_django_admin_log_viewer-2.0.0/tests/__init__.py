# Test package for mamood-django-admin-log-viewer
