from forecasting_tools.forecast_bots.experiments.q1t_w_personas_and_exa import (
    Q1TemplateWithPersonasAndExa,
)


class Q1VeritasBot(Q1TemplateWithPersonasAndExa):
    pass
