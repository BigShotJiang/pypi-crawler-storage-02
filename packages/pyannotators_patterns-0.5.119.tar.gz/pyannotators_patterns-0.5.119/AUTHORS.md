# Authors

Contributors to pyannotators_patterns include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
