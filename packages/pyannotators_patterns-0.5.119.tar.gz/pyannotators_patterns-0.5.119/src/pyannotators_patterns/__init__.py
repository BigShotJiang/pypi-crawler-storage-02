"""Annotator based on Presidio pattern recognizer"""
__version__ = "0.5.119"
