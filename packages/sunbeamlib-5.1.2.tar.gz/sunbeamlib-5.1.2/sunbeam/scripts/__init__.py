from sunbeam.scripts.config import main as Config
from sunbeam.scripts.extend import main as Extend
from sunbeam.scripts.init import main as Init
from sunbeam.scripts.run import main as Run
from sunbeam.scripts.sunbeam import main as Sunbeam
