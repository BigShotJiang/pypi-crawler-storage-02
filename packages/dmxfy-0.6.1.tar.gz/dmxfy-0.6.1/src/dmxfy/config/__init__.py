# src/dmxfy/config/__init__.py
from .config import Config

__all__ = ["Config"]
