# web 常用服务

# 历史版本

```
0.0.1：db_service JWT_service
0.0.5 : 服务器版本
0.0.6 : 本地使用
+jwt_service.decodeToken
0.0.6.1 :
+exist
0.0.6.2 :
缓存管理
0.0.7: 2024-07-26
0.0.8
    字符串格式化
    优化：CacheManage
0.0.9
0.0.10
    view_model  为get_one  增加一个func的方法
0.0.11
    get_one 增加 remove_db_instance 参数
    remove 增加 after 返回值判断
    response_error
    view.edit 增加 select处理
0.0.12
    batch_add
0.0.13 正式
    tip,时间 datetime.datetime.utcnow() 过时
0.0.14
    优化
0.0.15,16
    优化
0.0.17
    优化
0.0.18
    增加BaseBll
```
