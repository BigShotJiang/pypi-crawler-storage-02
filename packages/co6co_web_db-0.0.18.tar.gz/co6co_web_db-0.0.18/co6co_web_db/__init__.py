# -*- coding:utf-8 -*-

__version_info = (0, 0, 18)
__version__ = ".".join([str(x) for x in __version_info])
