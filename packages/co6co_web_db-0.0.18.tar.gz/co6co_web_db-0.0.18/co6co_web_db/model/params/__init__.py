from typing import List


class associationParam:
    """
    关联参数
    """ 
    add: List[int]
    remove: List[int]
