from .jingongo import Jingongo 
__version__ = "0.1.4"  # Version of the Jingongo framework