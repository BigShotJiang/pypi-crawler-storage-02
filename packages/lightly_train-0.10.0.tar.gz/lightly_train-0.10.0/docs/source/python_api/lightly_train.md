(lightly-train)=

# lightly_train

Documentation for `lightly_train` module.

```{eval-rst}

.. automodule:: lightly_train
    :members: embed, export, list_methods, list_models, train

```
