from __future__ import annotations

# Placeholder for future subgraph execution helpers if needed.
