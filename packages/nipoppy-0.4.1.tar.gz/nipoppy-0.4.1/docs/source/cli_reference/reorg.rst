``nipoppy reorg``
=================

.. note::
   This command calls the :py:class:`nipoppy.workflows.dicom_reorg.DicomReorgWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:reorg
   :prog: nipoppy reorg
