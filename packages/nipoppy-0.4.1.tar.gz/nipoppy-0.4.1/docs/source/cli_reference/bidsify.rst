``nipoppy bidsify``
===================

.. note::
   This command calls the :py:class:`nipoppy.workflows.bids_conversion.BidsConversionRunner` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:bidsify
   :prog: nipoppy bidsify
