``nipoppy status``
==================

.. note::
   This command calls the :py:class:`nipoppy.workflows.dataset_status.StatusWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:status
   :prog: nipoppy status
