``nipoppy pipeline upload``
===========================

.. note::
   This command calls the :py:class:`nipoppy.workflows.pipeline_store.upload.ZenodoUploadWorkflow` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.pipeline_catalog:pipeline_upload
   :prog: nipoppy pipeline upload
