``nipoppy process``
===================

.. note::
   This command calls the :py:class:`nipoppy.workflows.runner.PipelineRunner` class from the Python :term:`API` internally.

.. click:: nipoppy.cli.cli:process
   :prog: nipoppy process
