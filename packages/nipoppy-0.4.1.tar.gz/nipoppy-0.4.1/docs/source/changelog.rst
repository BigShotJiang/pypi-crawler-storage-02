.. Note: This page has to be in ReST format, not Markdown
.. because otherwise the changelog is not generated correctly

What's new
==========

.. changelog::
    :changelog-url: https://nipoppy.readthedocs.io/en/stable/changelog.html
    :github: https://github.com/nipoppy/nipoppy/releases/
    :pypi: https://pypi.org/project/nipoppy/
