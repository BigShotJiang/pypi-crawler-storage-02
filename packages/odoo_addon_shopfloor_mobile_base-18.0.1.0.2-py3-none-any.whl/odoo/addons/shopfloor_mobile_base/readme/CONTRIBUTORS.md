- Simone Orsi \<<simahawk@gmail.com>\>
- Thierry Ducrest \<<thierry.ducrest@camptocamp.com>\>
- Guewen Baconnier \<<guewen.baconnier@camptocamp.com>\>
- Juan Miguel Sánchez Arce \<<juan.sanchez@camptocamp.com>\>
- Raphaël Reverdy \<<raphael.reverdy@akretion.com>\>
- Sébastien Beau \<<sebastien.beau@akretion.com>\>
- Jacques-Etienne Baudoux \<<je@bcim.be>\>

Design

- Joël Grand-Guillaume \<<joel.grandguillaume@camptocamp.com>\>
- Jacques-Etienne Baudoux \<<je@bcim.be>\>
