#!/usr/bin/env python3
"""
Test package for demo MCP server.
"""
