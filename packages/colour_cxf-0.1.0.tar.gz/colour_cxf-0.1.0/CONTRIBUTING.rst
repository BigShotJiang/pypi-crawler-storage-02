Contributing
============

Contributing to Colour - CxF
----------------------------

If you would like to contribute to **Colour - CxF**, please refer to the following guide: https://www.colour-science.org/contributing/

About
-----

| **Colour - CxF** by Colour Developers
| Copyright 2024 Colour Developers – `colour-developers@colour-science.org <colour-developers@colour-science.org>`__
| This software is released under terms of BSD-3-Clause: https://opensource.org/licenses/BSD-3-Clause
| `https://github.com/colour-science/colour-cfx <https://github.com/colour-science/colour-cfx>`__
