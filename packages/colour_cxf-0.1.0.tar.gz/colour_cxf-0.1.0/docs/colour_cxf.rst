Colour - CxF
============

Reading and Writing CxF Files
-----------------------------

``colour.colour_cxf``

.. currentmodule:: colour_cxf

.. autosummary::
    :toctree: generated/

    read_cxf_from_file
    read_cxf
    write_cxf


CxF3
----

``colour_cxf``

.. currentmodule:: colour_cxf

.. autosummary::
    :toctree: generated/
    :template: class.rst
