<div align="center">
  <img class="lightmode" style="width: 200px;" src="logo.svg" />

--8<-- "README.md:6:23"

</div>

--8<-- "README.md:31:"
