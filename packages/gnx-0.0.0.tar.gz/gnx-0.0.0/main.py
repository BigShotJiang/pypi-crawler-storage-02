def main():
    print("Hello from gnx!")


if __name__ == "__main__":
    main()
