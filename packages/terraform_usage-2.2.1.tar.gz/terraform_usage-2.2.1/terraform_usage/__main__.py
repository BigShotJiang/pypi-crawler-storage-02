#!/usr/bin/env python3
# -*- coding: latin-1 -*-

"""Get Terraform usage statistics."""
import __init__

if __name__ == "__main__":
    __init__.main()
