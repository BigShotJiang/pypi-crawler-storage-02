# gfr/utils/git/__init__.py

# This file is intentionally left blank.
# It marks the 'git' directory as a Python package.
# You will add your git-related utility functions here.
