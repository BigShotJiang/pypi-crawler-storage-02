This was created without git flow and only with the main branch 🪖😐🪻

---



To install as editable, type the following command:
```bash
pip install -e .
```

For development, to know where to set the interpreter, enter the following command:
```bash
poetry env info --path
```

## Usage

```bash
ggg hello # say hello

```