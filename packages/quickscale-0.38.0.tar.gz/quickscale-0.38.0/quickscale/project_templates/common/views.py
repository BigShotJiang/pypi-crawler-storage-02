"""Common views shared across multiple apps."""
from django.http import HttpRequest, HttpResponse
from django.shortcuts import render

# Add views below that are used by multiple apps