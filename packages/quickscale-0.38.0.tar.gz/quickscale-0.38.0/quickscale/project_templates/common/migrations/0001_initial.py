"""Initial migration for common app."""
from django.db import migrations


class Migration(migrations.Migration):
    """Initial empty migration."""

    initial = True

    dependencies = [
    ]

    operations = [
    ] 