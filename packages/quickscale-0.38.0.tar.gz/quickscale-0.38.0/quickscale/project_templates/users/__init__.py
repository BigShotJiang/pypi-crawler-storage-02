"""Users app for QuickScale project templates."""
