from django.db import models

# Create your models here.
# Note: The Service model is defined in the credits app
# to maintain integration with the credit system