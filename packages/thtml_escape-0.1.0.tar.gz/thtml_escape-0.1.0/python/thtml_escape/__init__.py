from .thtml_escape import encode, decode

__all__ = ("encode", "decode")
