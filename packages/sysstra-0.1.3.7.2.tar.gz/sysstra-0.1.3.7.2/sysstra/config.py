config = {
    "api_key": None,
    "orders_url": "https://api.orders.sysstra.com/",
    "data_url": "https://api.data.sysstra.com/"
    # "data_url": "http://127.0.0.1:5001/"
    }