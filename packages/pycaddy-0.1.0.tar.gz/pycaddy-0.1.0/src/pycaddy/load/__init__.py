from .load_json import load_json

__all__ = ["load_json"]