from .path_like import PathLike, AbsolutePathLike

__all__ = ["PathLike", "AbsolutePathLike"]