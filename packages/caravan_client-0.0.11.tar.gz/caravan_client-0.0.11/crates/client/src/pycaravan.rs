pub mod init;

#[allow(dead_code)]
fn main() {}
