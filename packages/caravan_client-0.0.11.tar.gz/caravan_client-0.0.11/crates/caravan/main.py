def main():
    print("Hello from caravan!")


if __name__ == "__main__":
    main()
