class Row(dict):
    pass
