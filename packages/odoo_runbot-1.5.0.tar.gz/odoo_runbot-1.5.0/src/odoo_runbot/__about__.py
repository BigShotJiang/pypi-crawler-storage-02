__version__ = "1.5.0"
__author__ = "Alexis Pasquier"
__author_email__ = "alexis.pasquier@mangono.io"
