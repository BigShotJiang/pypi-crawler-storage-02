# MDP

A simple Python function to implement Markov Decision Process

## Installation
```bash
pip install mdp_package
