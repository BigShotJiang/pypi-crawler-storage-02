"""
Module to include some utils related to
video, but importing not any big library,
please.
"""