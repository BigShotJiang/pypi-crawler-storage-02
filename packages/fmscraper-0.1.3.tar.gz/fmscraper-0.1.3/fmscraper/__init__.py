from .fotmob_stats import FotMobStats

__all__ = ["FotMobStats"]