from chalk.logging import chalk_logger

# Backwards compatibility
__all__ = ["chalk_logger"]
