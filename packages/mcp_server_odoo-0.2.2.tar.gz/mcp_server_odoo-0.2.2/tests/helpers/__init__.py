"""Test helper utilities for Odoo MCP Server integration tests."""
