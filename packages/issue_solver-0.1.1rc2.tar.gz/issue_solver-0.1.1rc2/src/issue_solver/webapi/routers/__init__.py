"""Router package for issue-solver API."""
