"""
a2ahub - A simple hello world package
"""

__version__ = "0.1.0"
__author__ = "whillhill"
__email__ = "ooooofish@126.com"

from .main import hello_world

__all__ = ["hello_world"]
