# a2ahub

A simple hello world package for a2ahub.

## Installation

```bash
pip install a2ahub
```
