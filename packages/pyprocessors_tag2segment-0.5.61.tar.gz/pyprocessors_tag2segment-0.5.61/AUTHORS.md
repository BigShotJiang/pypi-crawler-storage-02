# Authors

Contributors to pyprocessors_tag2segment include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
