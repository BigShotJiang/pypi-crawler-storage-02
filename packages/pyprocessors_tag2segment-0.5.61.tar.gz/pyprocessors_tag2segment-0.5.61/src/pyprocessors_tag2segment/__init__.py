"""Sherpa Consolidation processor"""
__version__ = "0.5.61"
