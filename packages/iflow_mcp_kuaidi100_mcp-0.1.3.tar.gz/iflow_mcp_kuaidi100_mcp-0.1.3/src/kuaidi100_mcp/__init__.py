from .api_mcp import mcp

if __name__ == "__main__":
    mcp.run()