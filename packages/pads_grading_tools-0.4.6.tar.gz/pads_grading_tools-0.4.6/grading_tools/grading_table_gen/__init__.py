from .gen_grading_table import GenGradingTable
from .edit_grading_table import EditGradingTable