from grading_tools import *

if __name__ == '__main__':
    mk_cli_program().parse_and_run()
