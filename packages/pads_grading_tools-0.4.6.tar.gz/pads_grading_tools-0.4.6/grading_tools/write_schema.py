from grading_tools.common.gradable_spec import write_schema

write_schema()
