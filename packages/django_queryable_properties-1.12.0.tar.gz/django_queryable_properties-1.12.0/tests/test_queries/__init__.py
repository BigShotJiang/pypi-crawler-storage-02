# encoding: utf-8
"""Tests for the compat, managers and query modules that perform actual queries."""
