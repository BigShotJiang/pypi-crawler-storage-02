from blayers.layers import AdaptiveLayer

a = AdaptiveLayer()

import ipdb; ipdb.set_trace()