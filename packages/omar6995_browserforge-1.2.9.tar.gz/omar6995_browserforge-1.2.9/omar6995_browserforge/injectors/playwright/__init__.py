from omar6995_browserforge.injectors.utils import CheckIfInstalled

CheckIfInstalled('playwright')

from .injector import AsyncNewContext, NewContext
