######
 text
######

.. automodule:: anemoi.utils.text
   :members:
   :no-undoc-members:
   :show-inheritance:
