"""CanterburyCommuto"""

__version__ = "0.2.5"
__description__ = "CanterburyCommuto: A tool for mapping and routing"
