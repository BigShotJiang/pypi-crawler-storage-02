"""Version information for xAgent package."""

__version__ = "0.1.0"
__author__ = "xAgent Team"
__email__ = "support@xagent.ai"
__description__ = "Multi-Modal AI Agent System"
