# Example Package

Exists as this data is used in a few places at once.

```
import random_container_with_url_info

print(random_container_with_url_info.data.not_specific_poi_website_list())
```

# Installation

`pip install random_container_with_url_info`

It is uploaded to [pypi.org](https://pypi.org/project/random_container_with_url_info/)

# Run tests

```
python3 -m unittest
```
