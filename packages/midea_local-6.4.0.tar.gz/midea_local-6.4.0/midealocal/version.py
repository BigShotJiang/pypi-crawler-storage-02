"""Midea Local Version."""

__version__ = "6.4.0"
