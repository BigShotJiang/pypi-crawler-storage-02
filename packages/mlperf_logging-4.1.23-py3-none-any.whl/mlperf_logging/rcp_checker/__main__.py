from . import rcp_checker

rcp_checker.main()
