"""
Wex Core built-in addons
"""
