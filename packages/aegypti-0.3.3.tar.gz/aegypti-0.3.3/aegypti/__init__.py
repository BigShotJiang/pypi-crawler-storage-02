# Aegypti: Triangle-Free Solver https://pypi.org/project/aegypti
# Author: Frank Vega

__all__ = ["utils", "algorithm", "parser", "applogger", "test", "app"]