def hello() -> str:
    return "Hello from dagster-slurm!"
