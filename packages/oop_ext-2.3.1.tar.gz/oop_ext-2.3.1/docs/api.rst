API Reference
=============

.. note::

    This page is WIP, PRs are welcome!

.. py:module:: oop_ext.foundation.callback

.. autoclass:: Callback
    :members:

.. autoclass:: Callbacks
    :members:


.. py:module:: oop_ext.interface

.. autoclass:: Interface
    :members:

.. autofunction:: ImplementsInterface
.. autofunction:: GetProxy
