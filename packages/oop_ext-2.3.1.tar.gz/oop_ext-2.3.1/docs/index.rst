Welcome to Oop_ext documentation!
======================================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   callbacks
   interfaces
   api
   contributing
   changelog

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
