# ::: griffe.Class

## **Utilities**

::: griffe.c3linear_merge
