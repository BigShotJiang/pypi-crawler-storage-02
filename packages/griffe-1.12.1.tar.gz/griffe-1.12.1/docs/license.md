---
title: License
hide:
- feedback
---

# License

```text
--8<-- "LICENSE"
```
