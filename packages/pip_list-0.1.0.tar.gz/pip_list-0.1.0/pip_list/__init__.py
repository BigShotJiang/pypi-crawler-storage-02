"""
pip_list - A fast and human-readable tool to list installed pip packages with their sizes
"""

__version__ = "0.1.0"
__author__ = "Mayank Kumar Poddar"
__license__ = "MIT"