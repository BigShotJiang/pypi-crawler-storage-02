"""
Reusable named inline-partials for the Django Template Language
"""

__version__ = "25.1"
