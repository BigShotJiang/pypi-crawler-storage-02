from .colors import COLORS, get_color

__all__ = ["COLORS", "get_color"]
