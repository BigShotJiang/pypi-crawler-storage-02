from __future__ import annotations

from pathlib import Path

ROOT_PATH = Path(__file__).parent

__all__ = ["ROOT_PATH"]
