# Create a fancy drawing here. 
# Don't forget to import the code you need.
