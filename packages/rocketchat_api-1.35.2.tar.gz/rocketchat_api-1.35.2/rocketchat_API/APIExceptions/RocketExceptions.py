class RocketException(Exception):
    pass


class RocketConnectionException(Exception):
    pass


class RocketAuthenticationException(Exception):
    pass


class RocketMissingParamException(Exception):
    pass


class RocketUnsuportedIntegrationType(Exception):
    pass
