"""BMAD Expansion Pack Installer.

A tool to install BMAD expansion packs with proper directory structure,
symbolic links, and manifest management.
"""

__version__ = "1.1.0"
__author__ = "Najib Ninaba"
__description__ = "Installer for BMAD expansion packs"
