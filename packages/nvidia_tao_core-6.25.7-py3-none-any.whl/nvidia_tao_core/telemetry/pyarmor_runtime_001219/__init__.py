# Pyarmor 8.5.8 (basic), 001219, 2025-08-08T16:32:12.717387
from .pyarmor_runtime import __pyarmor__
