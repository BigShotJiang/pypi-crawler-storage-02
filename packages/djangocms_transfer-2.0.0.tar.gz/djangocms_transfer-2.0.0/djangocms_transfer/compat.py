import cms
from packaging.version import Version

cms_version = Version(cms.__version__)
