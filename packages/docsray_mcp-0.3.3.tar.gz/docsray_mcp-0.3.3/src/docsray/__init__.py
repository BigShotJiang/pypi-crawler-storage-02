"""Docsray MCP Server - Advanced document perception and understanding."""

__version__ = "0.1.0"
__author__ = "Docsray Team"

from .server import DocsrayServer

__all__ = ["DocsrayServer"]
