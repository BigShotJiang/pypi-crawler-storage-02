`python -m grpc_tools.protoc --proto_path=. --python_out=. --grpc_python_out=. nedo_vision_training/protos/*.proto`
