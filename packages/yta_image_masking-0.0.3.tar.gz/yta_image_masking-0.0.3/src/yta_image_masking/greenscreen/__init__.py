"""
TODO: I migrated this code here because I had
the greenscreen handling functionality in the
'yta_video_base', but the code I have is
actually using video libraries, so I can't
implement it here... Check 'yta_video_masking'
and extract some functionality here that only
involves image libraries.
"""