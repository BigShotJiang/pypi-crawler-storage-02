# Youtube Autonomous Image Masking Module

The Youtube Autonomous Image Masking module.

Please, check the 'pyproject.toml' file to see the dependencies.