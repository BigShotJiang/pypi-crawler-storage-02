default_app_config = "pulp_gem.app.PulpGemPluginAppConfig"
