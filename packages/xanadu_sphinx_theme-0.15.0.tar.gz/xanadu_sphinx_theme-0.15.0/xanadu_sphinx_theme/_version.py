"""
This module specifies the Xanadu Sphinx Theme version with https://semver.org/
using the following format: <major>.<minor>.<patch>[-<pre-release>].
"""

__version__ = "0.15.0"
