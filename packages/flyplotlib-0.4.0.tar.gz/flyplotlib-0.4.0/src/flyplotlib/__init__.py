from flyplotlib.core import add_fly

__all__ = ["add_fly"]
