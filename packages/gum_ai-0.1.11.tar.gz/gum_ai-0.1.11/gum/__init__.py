"""
GUM - General User Models

A Python package for managing user feedback and interactions.
"""

__version__ = "0.1.2"

from .gum import gum

__all__ = ["gum"] 