"""Tests for spiess_florian.pyx.

py.test tests/test_spiess_florian.py

author : Francois Pacull
copyright : Architecture & Performance
email: francois.pacull@architecture-performance.fr
license : MIT
"""

from edsger.spiess_florian import *


def test_compute_SF_in_01():
    compute_SF_in_01()


def test_compute_SF_in_02():
    compute_SF_in_02()
