from edsger._version import __version__
