from pathlib import Path


# our folder for session data
# TODO make this configurable
SHRINKPLZ_DATA = Path(".shrinkplz")
