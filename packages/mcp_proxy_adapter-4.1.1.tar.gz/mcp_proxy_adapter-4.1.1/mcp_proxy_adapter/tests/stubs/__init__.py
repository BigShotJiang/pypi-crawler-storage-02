"""
Test stub modules for framework tests.
"""

from mcp_proxy_adapter.tests.stubs.echo_command import EchoCommand, EchoResult

__all__ = [
    "EchoCommand",
    "EchoResult"
]
