"""
Deployment Examples

This package contains deployment examples for the MCP Proxy Adapter framework.
"""

__version__ = "1.0.0" 