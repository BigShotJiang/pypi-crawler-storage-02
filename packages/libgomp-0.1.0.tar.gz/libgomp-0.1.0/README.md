# libgomp\nA dummy Python package version of libgomp.
