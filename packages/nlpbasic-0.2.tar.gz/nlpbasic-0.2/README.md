# Keyword Highlighter

A simple Python utility that uses **NLP** (via spaCy) to identify and highlight the most important words in a given text.  
Supports both **Markdown** and **HTML** formatting styles.

## Features
- Extracts top keywords using word frequency.
- Removes stopwords and punctuation automatically.
- Supports Markdown (`**bold**`) and HTML (`<b>bold</b>`) highlighting.
- Configurable number of keywords.