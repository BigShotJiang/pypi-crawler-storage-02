from indic_transliteration.sanscript_cli import app

if __name__ == "__main__":
    app(prog_name="sanscript")
