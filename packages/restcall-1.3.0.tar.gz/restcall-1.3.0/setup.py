from setuptools import setup

# This is required for editable install due to a limitation of setuptools (https://github.com/pypa/setuptools/issues/2816)
setup()
