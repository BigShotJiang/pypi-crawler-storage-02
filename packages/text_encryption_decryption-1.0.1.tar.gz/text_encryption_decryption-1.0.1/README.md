# Text Encryption And Decryption

A Python package with utilities to encrypt and decrypt texts.

## Features
- Text Encryption
- Text Decryption

Check out the [example script](examples/example_usage.py) for more details.

## Installation
```bash
pip install text-encryption-decryption
