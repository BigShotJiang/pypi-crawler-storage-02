"""Unit tests for gRPC module."""
