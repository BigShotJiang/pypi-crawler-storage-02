"""Unit tests for commands module."""
