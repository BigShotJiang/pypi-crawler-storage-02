"""Setup utilities for initializing Entity's local environment."""

from .ollama_installer import OllamaInstaller

__all__ = ["OllamaInstaller"]
