﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class UnknownRequestException(MotionLibException):
    """
    Used for internal error handling. Indicates mixed library binary files. Reinstall the library.
    """
