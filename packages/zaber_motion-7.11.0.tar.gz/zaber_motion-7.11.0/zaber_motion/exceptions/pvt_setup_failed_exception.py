﻿# ===== THIS FILE IS GENERATED FROM A TEMPLATE ===== #
# ============== DO NOT EDIT DIRECTLY ============== #

from .motion_lib_exception import MotionLibException


class PvtSetupFailedException(MotionLibException):
    """
    Thrown when setting up a PVT sequence fails.
    """
