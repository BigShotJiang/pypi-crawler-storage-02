# This file is generated. Do not modify by hand.
from enum import Enum


class PvtMode(Enum):
    """
    Mode of a PVT sequence.
    """

    DISABLED = 0
    STORE = 1
    LIVE = 2
