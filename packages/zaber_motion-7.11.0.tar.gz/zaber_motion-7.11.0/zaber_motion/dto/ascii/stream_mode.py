# This file is generated. Do not modify by hand.
from enum import Enum


class StreamMode(Enum):
    """
    Mode of a stream.
    """

    DISABLED = 0
    STORE = 1
    STORE_ARBITRARY_AXES = 2
    LIVE = 3
