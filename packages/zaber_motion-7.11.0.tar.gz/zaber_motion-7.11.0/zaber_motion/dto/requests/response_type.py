# This file is generated. Do not modify by hand.
from enum import Enum


class ResponseType(Enum):

    OK = 0
    ERROR = 1
