# This file is generated. Do not modify by hand.
from enum import Enum


class StreamSegmentType(Enum):

    ABS = 0
    REL = 1
