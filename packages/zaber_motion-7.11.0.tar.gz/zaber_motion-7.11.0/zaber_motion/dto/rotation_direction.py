# This file is generated. Do not modify by hand.
from enum import Enum


class RotationDirection(Enum):
    """
    Direction of rotation.
    """

    CLOCKWISE = 0
    COUNTERCLOCKWISE = 1
    CW = 0
    CCW = 1
