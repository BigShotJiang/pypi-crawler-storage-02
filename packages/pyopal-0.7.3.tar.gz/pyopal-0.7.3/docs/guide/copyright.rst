Copyright Notice
================

PyOpal
------

PyOpal is provided under the MIT License:

.. literalinclude:: ../../COPYING 


Opal
----

Opal is provided under the MIT License:

.. literalinclude:: ../../vendor/opal/LICENSE 