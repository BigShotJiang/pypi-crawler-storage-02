Aligner
=======

.. currentmodule:: pyopal


.. autoclass:: pyopal.Aligner
   :special-members: __init__
   :members:
