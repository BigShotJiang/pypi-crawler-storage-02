Alphabet
========

.. currentmodule:: pyopal


.. autoclass:: pyopal.Alphabet
   :special-members: __init__, __len__, __getitem__, __str__
   :members:
