Result
======

.. currentmodule:: pyopal

ScoreResult
-----------

.. autoclass:: pyopal.ScoreResult
   :special-members: __init__
   :members:


EndResult
---------

.. autoclass:: pyopal.EndResult(ScoreResult)
   :special-members: __init__
   :inherited-members:
   :members:


FullResult
----------

.. autoclass:: pyopal.FullResult(EndResult)
   :special-members: __init__
   :inherited-members:
   :members:
