# String width

::: rtflite.strwidth
    options:
      members:
        - get_string_width
      show_root_heading: true
      show_source: false
