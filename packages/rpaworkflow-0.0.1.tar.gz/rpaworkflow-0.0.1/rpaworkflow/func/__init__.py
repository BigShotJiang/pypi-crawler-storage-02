from .op import or_, and_

__all__ = [
    'or_',
    'and_'
]

__version__ = '1.0.0'
__author__ = 'dragons96'

