class NodeError(RuntimeError):
    """节点执行错误异常
    
    用于表示节点执行过程中发生的错误
    """
    pass