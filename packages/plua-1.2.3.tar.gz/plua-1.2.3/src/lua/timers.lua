---Export global timer functions 
setTimeout = _PY.setTimeout
clearTimeout = _PY.clearTimeout
setInterval = _PY.setInterval
clearInterval = _PY.clearInterval