from litellm.llms.openai.image_generation import GPTImageGenerationConfig


class AzureGPTImageGenerationConfig(GPTImageGenerationConfig):
    """
    Azure gpt-image-1 image generation config
    """

    pass
