"""
Uses `converse_transformation.py` to transform the messages to the format required by Bedrock Converse.
"""
