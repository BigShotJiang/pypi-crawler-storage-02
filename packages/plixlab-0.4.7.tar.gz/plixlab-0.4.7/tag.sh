#!/bin/bash

git tag 0.4.6
git push origin main
git push origin 0.4.6

