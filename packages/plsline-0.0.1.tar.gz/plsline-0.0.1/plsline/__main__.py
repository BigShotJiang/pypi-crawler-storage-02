
if __name__ == "__main__":

    from plsline import printsimple as prints
    prints("Hello,Hope you enjoy using PlsLine!")