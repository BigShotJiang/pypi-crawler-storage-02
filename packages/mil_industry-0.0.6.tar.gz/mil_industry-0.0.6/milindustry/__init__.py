"""Initialize the app"""

__version__ = "0.0.6"
__title__ = "MIL Industry"
