# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["DatasliceCreateResponse"]


class DatasliceCreateResponse(BaseModel):
    dataslice_id: str
