# TODO : clipd daily pipeline.sh
# TODO : clipd pipeline init
# TODO : clipd run pipeline.yaml