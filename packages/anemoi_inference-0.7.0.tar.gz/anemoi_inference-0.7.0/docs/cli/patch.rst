.. _patch_command:

Patch Command
=============

.. argparse::
    :module: anemoi.inference.__main__
    :func: create_parser
    :prog: anemoi-inference
    :path: patch
