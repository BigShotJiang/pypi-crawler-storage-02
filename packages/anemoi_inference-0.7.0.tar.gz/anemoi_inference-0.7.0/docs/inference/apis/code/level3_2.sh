anemoi-inference run aifs.yaml date=2020-01-01
