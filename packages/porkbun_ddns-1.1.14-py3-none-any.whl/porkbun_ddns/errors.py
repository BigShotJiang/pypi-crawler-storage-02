class PorkbunDDNS_Error(Exception):
    pass
