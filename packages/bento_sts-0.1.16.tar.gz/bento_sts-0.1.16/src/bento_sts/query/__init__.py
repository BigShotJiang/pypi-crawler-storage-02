"""
bento_sts.query - parse API path to create Cypher query
"""
from .makeq import Query
