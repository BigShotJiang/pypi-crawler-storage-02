
"""
Database and configuration files for VulnScan
"""

# This directory contains configuration files and databases
