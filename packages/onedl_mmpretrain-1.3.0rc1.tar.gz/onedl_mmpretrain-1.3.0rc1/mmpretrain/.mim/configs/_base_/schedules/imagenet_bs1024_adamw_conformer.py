optim_wrapper = dict(
    optimizer=dict(
        type='AdamW',
        # for batch in each gpu is 128, 8 gpu
        # lr = 5e-4 * 128 * 8 / 512 = 0.001
        lr=5e-4 * 128 * 8 / 512,
        weight_decay=0.05,
        eps=1e-8,
        betas=(0.9, 0.999)),
    paramwise_cfg=dict(norm_decay_mult=0.0,
                       bias_decay_mult=0.0,
                       custom_keys={
                           '.cls_token': dict(decay_mult=0.0),
                       }),
)

# learning policy
param_scheduler = [
    dict(type='LinearLR',
         start_factor=1e-3,
         by_epoch=True,
         begin=0,
         end=5,
         convert_to_iter_based=True),
    dict(type='CosineAnnealingLR',
         T_max=295,
         eta_min=1e-5,
         by_epoch=True,
         begin=5,
         end=300)
]

# train, val, test setting
train_cfg = dict(by_epoch=True, max_epochs=300, val_interval=1)
val_cfg = dict()
test_cfg = dict()

# NOTE: `auto_scale_lr` is for automatically scaling LR,
# based on the actual training batch size.
auto_scale_lr = dict(base_batch_size=1024)
