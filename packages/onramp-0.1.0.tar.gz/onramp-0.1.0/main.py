def main():
    print("Hello from onramp!")


if __name__ == "__main__":
    main()
