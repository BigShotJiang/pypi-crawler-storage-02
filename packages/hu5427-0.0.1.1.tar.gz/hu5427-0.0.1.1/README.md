hu27 tool


### 1. 下载

```
python -m pip install hu27
```

### 2. 使用

```
# 一个工作多年的后端研发工程师!
```