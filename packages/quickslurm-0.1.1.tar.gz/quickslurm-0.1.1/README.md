# quickslurm

A lightweight Python wrapper for Slurm (`sbatch`/`srun`) with robust subprocess handling and optional logging.

## Install

```bash
pip install quickslurm
