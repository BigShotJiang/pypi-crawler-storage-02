import os


def f():
    x = 1
