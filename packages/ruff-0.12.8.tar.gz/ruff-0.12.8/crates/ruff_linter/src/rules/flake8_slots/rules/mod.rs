pub(crate) use no_slots_in_namedtuple_subclass::*;
pub(crate) use no_slots_in_str_subclass::*;
pub(crate) use no_slots_in_tuple_subclass::*;

mod no_slots_in_namedtuple_subclass;
mod no_slots_in_str_subclass;
mod no_slots_in_tuple_subclass;
