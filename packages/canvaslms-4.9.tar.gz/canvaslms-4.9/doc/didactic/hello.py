"""A Hello World example in Python 3"""

def main():
    print("Hello, world!")

if __name__ == "__main__":
    main()
