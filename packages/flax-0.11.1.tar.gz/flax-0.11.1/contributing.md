# How to Contribute

Please see https://flax.readthedocs.io/en/latest/contributing.html for more information.
