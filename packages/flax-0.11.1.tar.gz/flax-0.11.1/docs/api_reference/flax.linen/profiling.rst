Profiling
----------------------

.. currentmodule:: flax.linen

.. autofunction:: enable_named_call
.. autofunction:: disable_named_call
.. autofunction:: override_named_call
