
Variable dictionary
----------------------

.. automodule:: flax.core.variables
.. autoclass:: flax.linen.Variable
