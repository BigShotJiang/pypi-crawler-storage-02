
flax.core.frozen_dict package
=============================

.. currentmodule:: flax.core.frozen_dict

.. autoclass:: FrozenDict
  :members: pretty_repr, copy, pop, unfreeze, tree_flatten

.. autofunction:: freeze

.. autofunction:: unfreeze

.. autofunction:: copy

.. autofunction:: pop

.. autofunction:: pretty_repr
