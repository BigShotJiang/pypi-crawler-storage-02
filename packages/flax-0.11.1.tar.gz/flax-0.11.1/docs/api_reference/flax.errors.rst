
flax.errors package
===================

Flax has the following classes of errors.

.. automodule:: flax.errors
    :members:
    :exclude-members: FlaxError