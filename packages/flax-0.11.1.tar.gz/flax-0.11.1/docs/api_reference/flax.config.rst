
flax.config package
====================

.. automodule:: flax.configurations
    :members:
    :undoc-members:
    :exclude-members: FlagHolder, bool_flag, temp_flip_flag, static_bool_env
