Parallel training
=================

.. toctree::
   :maxdepth: 1

   ensembling
   flax_on_pjit
