Data preprocessing
=================

.. toctree::
   :maxdepth: 1

   full_eval
   loading_datasets
