Training techniques
===================

.. toctree::
   :maxdepth: 1

   batch_norm
   dropout
   lr_schedule
   transfer_learning
   use_checkpointing