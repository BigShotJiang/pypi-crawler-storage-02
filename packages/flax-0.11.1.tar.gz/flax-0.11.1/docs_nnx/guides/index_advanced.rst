Advanced
======

.. toctree::
   :maxdepth: 1
   :caption: Advanced

   flax_gspmd
   performance
   bridge_guide
   surgery
