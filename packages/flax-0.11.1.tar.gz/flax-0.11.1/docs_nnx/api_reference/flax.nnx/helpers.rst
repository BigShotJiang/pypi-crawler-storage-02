helpers
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx


.. autoclass:: Sequential
   :members:
.. autoclass:: TrainState
   :members: