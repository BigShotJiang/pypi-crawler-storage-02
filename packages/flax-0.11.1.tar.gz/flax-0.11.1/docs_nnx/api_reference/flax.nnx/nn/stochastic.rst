Stochastic
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx

.. autoclass:: Dropout
   :members: