bridge
------------------------

.. automodule:: flax.nnx.bridge
.. currentmodule:: flax.nnx.bridge

.. flax_module::
  :module: flax.nnx.bridge
  :class: ToNNX

.. flax_module::
  :module: flax.nnx.bridge
  :class: ToLinen

.. autofunction:: to_linen

.. flax_module::
  :module: flax.nnx.bridge
  :class: NNXMeta
