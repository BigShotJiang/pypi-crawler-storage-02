state
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx


.. autoclass:: State
  :members: