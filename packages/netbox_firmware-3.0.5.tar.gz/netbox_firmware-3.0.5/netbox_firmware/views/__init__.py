from .firmware import *
from .firmwareassignment import *

from .bios import *
from .biosassignment import *