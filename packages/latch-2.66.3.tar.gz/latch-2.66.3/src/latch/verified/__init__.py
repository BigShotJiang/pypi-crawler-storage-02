from latch.verified.deseq2 import deseq2_wf
from latch.verified.mafft import mafft
from latch.verified.pathway import gene_ontology_pathway_analysis
from latch.verified.rnaseq import rnaseq
from latch.verified.trim_galore import trim_galore
