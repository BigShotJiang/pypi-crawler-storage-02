import warnings
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

class Version():
    """
    Version class to handle versioning of the FabricSync package.
    """
    CurrentVersion = "2.2.10"