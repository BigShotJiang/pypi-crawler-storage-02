import warnings

class SyncUnsupportedConfigurationWarning(RuntimeWarning):
    pass

class SyncTableRequiresOptimizeWarning(RuntimeWarning):
    pass