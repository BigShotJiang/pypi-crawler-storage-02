import enum


class FileStorageClientType(enum.Enum):
    AZURE = "azure"
    LOCAL = "local"
