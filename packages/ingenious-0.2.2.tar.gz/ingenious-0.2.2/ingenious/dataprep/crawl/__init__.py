from .crawler import Crawler as Crawler
