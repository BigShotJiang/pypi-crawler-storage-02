"""Data module for ScholarImpact."""

from .loader import load_data

__all__ = ['load_data']