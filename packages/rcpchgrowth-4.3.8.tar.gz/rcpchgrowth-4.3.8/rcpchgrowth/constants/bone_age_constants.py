G_P='greulich-pyle'
TWII='tanner-whitehouse-ii'
TWIII='tanner-whitehouse-iii'
FELS='fels'
BONEXPERT='bonexpert'
BONE_AGE_REFERENCES=[G_P, TWII, TWIII, FELS, BONEXPERT]
