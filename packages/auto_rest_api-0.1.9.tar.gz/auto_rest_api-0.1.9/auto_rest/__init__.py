from .__main__ import run_application

__all__ = ["run_application"]
