# Defer Import

Run `uv run defer-import --help` to run.

Demonstrates how to reference the `invoke` target as a string.

Note this is notably more complex than most other examples because this feature
requires the modules be importable by one another and thus requires a proper
package to be set up/installed.
