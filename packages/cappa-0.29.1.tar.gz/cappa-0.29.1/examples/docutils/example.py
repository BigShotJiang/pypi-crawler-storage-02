from dataclasses import dataclass


@dataclass()
class Foo:
    bar: int
