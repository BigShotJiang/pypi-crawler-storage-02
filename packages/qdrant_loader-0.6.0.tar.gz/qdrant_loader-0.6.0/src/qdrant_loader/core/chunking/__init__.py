"""
Chunking components for document processing.
"""

from qdrant_loader.core.chunking.chunking_service import ChunkingService

__all__ = ["ChunkingService"]
