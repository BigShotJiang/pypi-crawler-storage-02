# `clinicore`

```{eval-rst}
.. automodule:: clinicore
```
