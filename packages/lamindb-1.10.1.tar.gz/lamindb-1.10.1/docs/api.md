# API

<meta http-equiv="Refresh" content="0; url=./lamindb.html" />

```{toctree}
:maxdepth: 1
:caption: CLI & lamindb
:hidden:

cli
lamindb
```

```{toctree}
:maxdepth: 1
:caption: Modules
:hidden:

bionty
wetlab
clinicore
```
