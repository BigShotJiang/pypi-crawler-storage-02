from django.apps import AppConfig


class ReboticsSDKHookConfig(AppConfig):
    name = 'rebotics_sdk.hook'
