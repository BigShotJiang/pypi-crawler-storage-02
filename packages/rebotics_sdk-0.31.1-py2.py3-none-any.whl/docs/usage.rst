=====
Usage
=====

To use rebotics_sdk in a project::

    import rebotics_sdk
