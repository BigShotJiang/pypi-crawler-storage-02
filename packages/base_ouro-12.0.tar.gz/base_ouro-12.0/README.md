## Relatório do vínculo de todos os alunos e disciplinas.

#### Recebe como entrada os seguintes relatórios extraídos do sistema Prime:
 - Relatório de Alunos / Pais exportação; 
 - Relatório de Disciplinas (Consulta SQL); 
 - Relatório de Carga Horária por turma / disciplina.
#### Utilizado diariamente durante o período de Ajuste Acadêmico
