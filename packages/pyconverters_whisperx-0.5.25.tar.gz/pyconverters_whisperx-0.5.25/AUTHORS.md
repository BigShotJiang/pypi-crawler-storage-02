# Authors

Contributors to pyconverters_whisperx include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
