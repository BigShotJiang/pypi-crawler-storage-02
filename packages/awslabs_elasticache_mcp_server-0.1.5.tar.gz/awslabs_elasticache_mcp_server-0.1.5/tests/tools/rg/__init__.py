"""Tests for replication group tools."""
