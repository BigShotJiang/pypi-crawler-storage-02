# [Sync] Streaming

This tutorial demonstrates how to implement streaming responses in AgentEx agents using the Agent 2 Client Protocol (ACP).

## Official Documentation

[020 Streaming](https://dev.agentex.scale.com/docs/tutorials/sync/020_streaming)


