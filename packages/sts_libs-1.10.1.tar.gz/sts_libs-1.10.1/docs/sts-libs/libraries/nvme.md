# NVMe

This section documents the NVMe (Non-Volatile Memory Express) device functionality.

::: sts.nvme
