"""
Constants related to text formatting and display.
"""

# Number of spaces per indentation level
INDENTATION_SPACES = 2
