::: cmn_ai.learner
