::: cmn_ai.activations
