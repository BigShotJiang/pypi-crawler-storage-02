::: cmn_ai.callbacks.core
