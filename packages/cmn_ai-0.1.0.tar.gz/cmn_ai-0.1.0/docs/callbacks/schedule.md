::: cmn_ai.callbacks.schedule
