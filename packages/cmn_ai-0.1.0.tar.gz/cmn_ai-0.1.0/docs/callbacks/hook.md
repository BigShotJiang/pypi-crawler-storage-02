::: cmn_ai.callbacks.hook
