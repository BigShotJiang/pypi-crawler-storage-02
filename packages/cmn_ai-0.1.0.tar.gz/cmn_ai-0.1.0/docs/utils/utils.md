::: cmn_ai.utils.utils
