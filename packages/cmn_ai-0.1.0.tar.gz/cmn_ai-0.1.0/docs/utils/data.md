::: cmn_ai.utils.data
