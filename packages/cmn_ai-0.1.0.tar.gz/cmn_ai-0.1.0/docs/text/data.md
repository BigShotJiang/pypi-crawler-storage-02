::: cmn_ai.text.data
