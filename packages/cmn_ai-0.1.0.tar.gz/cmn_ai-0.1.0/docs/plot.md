::: cmn_ai.plot
