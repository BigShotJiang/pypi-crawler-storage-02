::: cmn_ai.losses
