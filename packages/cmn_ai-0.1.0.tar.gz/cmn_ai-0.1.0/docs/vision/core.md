::: cmn_ai.vision.core
