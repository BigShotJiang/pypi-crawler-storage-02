::: cmn_ai.tabular.data
