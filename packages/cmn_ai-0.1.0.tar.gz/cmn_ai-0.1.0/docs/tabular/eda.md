::: cmn_ai.tabular.eda
