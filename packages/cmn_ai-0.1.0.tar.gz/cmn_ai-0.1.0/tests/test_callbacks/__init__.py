"""
Test package for callbacks module.
"""
