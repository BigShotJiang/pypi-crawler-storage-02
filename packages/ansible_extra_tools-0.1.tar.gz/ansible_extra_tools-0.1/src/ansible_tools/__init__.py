"""Ansible Tools to expand ansible-core

Copyright (C) 2025 Dan Griffin
Portions Copyright: (c) Ansible Project

Based on work from ansible

Licensed under the GNU General Public License v3.0+ 
(see LICENSE or https://www.gnu.org/licenses/gpl-3.0.txt)
"""
