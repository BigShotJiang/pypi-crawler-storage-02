# Ansible Tools

Extra tools for Ansible

## Ansible Role

The `ansible-role` package is used for running role(s) on targeted hosts.

## License

GNU General Public License v3.0 or later
