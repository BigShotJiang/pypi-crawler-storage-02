[project]
name = "secmeasure"
version = "0.1.2"
description = "Library for cleaning strings and applying security measures to requests URLs."
readme = { file = "README.md", content-type = "text/markdown" }
authors = [
    { name = "Conde", email = "billordowiyi@gmail.com" }
]
requires-python = ">=3.6"
license = { text = "MIT" }
