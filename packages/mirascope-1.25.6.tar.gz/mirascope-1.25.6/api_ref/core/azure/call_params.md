# mirascope.core.azure.call_params

::: mirascope.core.azure.call_params
