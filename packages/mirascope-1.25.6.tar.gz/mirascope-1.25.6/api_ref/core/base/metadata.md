# mirascope.core.base.metadata

::: mirascope.core.base.metadata
