# mirascope.core.base.call_response

::: mirascope.core.base.call_response
