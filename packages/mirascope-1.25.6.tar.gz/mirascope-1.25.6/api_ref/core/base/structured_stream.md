# mirascope.core.base.structured_stream

::: mirascope.core.base.structured_stream
