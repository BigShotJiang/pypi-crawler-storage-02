# mirascope.core.cohere.call_response

::: mirascope.core.cohere.call_response
