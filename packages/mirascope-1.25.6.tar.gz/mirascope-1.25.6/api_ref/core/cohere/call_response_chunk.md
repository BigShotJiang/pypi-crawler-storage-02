# mirascope.core.cohere.call_response_chunk

::: mirascope.core.cohere.call_response_chunk
