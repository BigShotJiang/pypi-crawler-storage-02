# mirascope.core.openai.tool

::: mirascope.core.openai.tool
