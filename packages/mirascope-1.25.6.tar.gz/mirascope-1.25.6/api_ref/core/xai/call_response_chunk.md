# mirascope.core.xai.call_response_chunk

::: mirascope.core.xai.call_response_chunk
