# mirascope.core.xai.call_params

::: mirascope.core.xai.call_params
