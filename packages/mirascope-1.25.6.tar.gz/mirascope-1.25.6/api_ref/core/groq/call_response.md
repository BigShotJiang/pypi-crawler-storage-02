# mirascope.core.groq.call_response

::: mirascope.core.groq.call_response
