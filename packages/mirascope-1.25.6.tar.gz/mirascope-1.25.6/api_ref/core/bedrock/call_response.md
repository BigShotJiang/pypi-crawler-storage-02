# mirascope.core.bedrock.call_response

::: mirascope.core.bedrock.call_response
