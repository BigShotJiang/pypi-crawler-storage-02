"""Test configuration fixtures used across various modules."""
