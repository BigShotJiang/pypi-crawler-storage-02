"""Tests for the Mirascope package."""
