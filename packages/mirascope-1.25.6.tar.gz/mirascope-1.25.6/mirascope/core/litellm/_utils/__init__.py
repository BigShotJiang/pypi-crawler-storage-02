"""LiteLLM utilities for decorator factories."""

from ._setup_call import setup_call

__all__ = ["setup_call"]
