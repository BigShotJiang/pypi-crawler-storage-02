"""The default docstring to use when tools don't have a docstring."""

DEFAULT_TOOL_DOCSTRING = """\
Correctly formatted and typed parameters extracted from the completion. \
Must include required parameters and may exclude optional parameters unless present in the text.\
"""
