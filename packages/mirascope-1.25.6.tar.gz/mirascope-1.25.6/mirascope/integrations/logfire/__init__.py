from ._with_logfire import with_logfire

__all__ = ["with_logfire"]
