# Version number format: MAJOR.MINOR.PATCH
# Major: Major version number (increments when breaking changes are introduced)
# Minor: Minor version number (increments when new features are added)
# Patch: Patch version number (increments when bug fixes are made)

__version__ = "1.2.6"   