"""
A CLI tool to download and deobfuscate Comic-Days manga chapters.
"""

__version__ = "0.1.1"
__description__ = "A CLI tool to download and deobfuscate Comic-Days manga chapters."
__repository__ = "syvixor/laine"
__url_repository__ = "https://github.com"
__author__ = "syvixor"
__author_email__ = "syvixor@proton.me"
__license__ = "MIT"