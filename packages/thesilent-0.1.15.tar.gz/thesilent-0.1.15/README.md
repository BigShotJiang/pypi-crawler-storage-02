﻿# TheSilent is a fast subdomain enumeration tool!
# 
# python3 -m TheSilent -host example.com
