from jaix.env.utils.problem.static_problem import StaticProblem
from jaix.env.utils.problem.sphere import Sphere, SphereConfig
from jaix.env.utils.problem.rbf_fit import RBFFitConfig, RBFFit
