from .InfiniteCampus import InfiniteCampus
