"""
Placeholder package for predicat-exporters.
"""
__all__ = []
__version__ = "0.0.0a1"
