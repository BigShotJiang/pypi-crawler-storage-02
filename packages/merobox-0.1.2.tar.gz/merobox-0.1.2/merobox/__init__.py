"""
Merobox - A Python CLI tool for managing Calimero nodes in Docker containers.
"""

__version__ = "0.1.2"
__author__ = "Merobox Team"
__email__ = "team@merobox.com"
