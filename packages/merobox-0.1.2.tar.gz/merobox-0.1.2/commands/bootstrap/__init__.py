"""
Bootstrap command - Automate Calimero node workflows using YAML configuration files.
"""

from .bootstrap import bootstrap

__all__ = ['bootstrap']
