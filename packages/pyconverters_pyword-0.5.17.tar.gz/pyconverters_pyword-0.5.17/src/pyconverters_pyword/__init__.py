"""Convert DOCX to Markdown using [mammoth](https://github.com/mwilliamson/python-mammoth)"""
__version__ = "0.5.17"
