"""lottery: Weighted random allocation library."""

from ._core import lottery

__version__ = "1.0.2"
__all__ = ["lottery"]
