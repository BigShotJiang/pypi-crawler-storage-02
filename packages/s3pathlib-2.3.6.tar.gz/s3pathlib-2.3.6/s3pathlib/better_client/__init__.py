# -*- coding: utf-8 -*-

"""
Improve the native boto3 client.
"""
