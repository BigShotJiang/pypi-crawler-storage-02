# -*- coding: utf-8 -*-

IS_DELETE_MARKER = "IsDeleteMarker"
