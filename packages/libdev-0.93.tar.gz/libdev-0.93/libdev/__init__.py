"""
Initializing the Python package
"""

__version__ = "0.93"

__all__ = ("__version__",)
