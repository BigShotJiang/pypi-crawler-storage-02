def main():
    """Main entry point for the AutoGemini package."""
    print("Hello from AutoGemini!")


if __name__ == "__main__":
    main()
