def main():
    print("Hello from hacs-cli!")


if __name__ == "__main__":
    main()
