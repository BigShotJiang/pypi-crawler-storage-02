"""Integration tests for database adapters with CORE_ROUND_3 architecture."""
