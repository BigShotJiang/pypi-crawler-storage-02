# src/layker/__main__.py

from .main import cli_entry

if __name__ == "__main__":
    cli_entry()