__version__ = "0.1.0"
__author__ = "LMG Services"
__license__ = "LMG Services Group License"