from typing import Optional

from .base import TelegramObject


class LinkPreviewOptions(TelegramObject):
    is_disabled: Optional[bool] = None
    url: Optional[str] = None
    prefer_small_media: Optional[bool] = None
    prefer_large_media: Optional[bool] = None
    show_above_text: Optional[bool] = None
