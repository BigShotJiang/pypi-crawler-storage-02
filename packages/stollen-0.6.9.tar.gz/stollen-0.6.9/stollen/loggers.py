import logging
from typing import Final

client: Final[logging.Logger] = logging.getLogger("stollen.client")
