from setuptools import setup, find_packages

setup(
    name="meduza-ai",
    version="0.0.1",
    author="Matt Aliev",
    description="Build AI Agent - coming soon",
    packages=find_packages(),
    python_requires=">=3.9",
)