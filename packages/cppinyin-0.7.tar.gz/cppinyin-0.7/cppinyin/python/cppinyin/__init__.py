from .cppinyin import Encoder
__version__ = '0.3'
