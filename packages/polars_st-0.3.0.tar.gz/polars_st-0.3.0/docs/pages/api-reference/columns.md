::: polars_st
    options:
        show_object_full_path: true
        show_root_toc_entry: false
        members:
            - geom
            - element
