::: polars_st
    options:
        show_object_full_path: true
        show_root_toc_entry: false
        members:
            - point
            - multipoint
            - linestring
            - circularstring
            - multilinestring
            - polygon
            - rectangle
            - from_wkb
            - from_wkt
            - from_ewkt
            - from_geojson
            - from_shapely
            - from_geopandas
            - read_file
