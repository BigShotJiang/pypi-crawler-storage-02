[![Gitpod ready-to-code](https://img.shields.io/badge/Gitpod-ready--to--code-908a85?logo=gitpod)](https://gitpod.io/#https://github.com/rpetit3/steamboat)

# steamboat
A collection of tools/scripts for microbial bioinformatics
