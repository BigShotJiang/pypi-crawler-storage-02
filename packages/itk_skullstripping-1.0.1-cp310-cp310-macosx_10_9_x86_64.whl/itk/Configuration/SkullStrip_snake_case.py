snake_case_functions = ('strip_ts_image_filter', )
