from .generic import create_pytorch_objects
