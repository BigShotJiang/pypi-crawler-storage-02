#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
from .version import __version__

version = __version__  # alias
