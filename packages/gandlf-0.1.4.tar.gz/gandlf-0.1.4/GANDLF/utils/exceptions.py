"""
Exceptions for errors in GANDLF, to be used in the code later. 
Just a placeholder for now.
"""
