VERSION = "0.2.0"

S2_VERSION = "0.0.2-beta"
