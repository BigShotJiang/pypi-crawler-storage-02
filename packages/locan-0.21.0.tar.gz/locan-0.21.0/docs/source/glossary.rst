:orphan:

.. _glossary:

Glossary
========

.. glossary::

    super-resolution microscopy
        optical microscopy methods that allow imaging with a resolution beyond the diffraction limit.

    SMLM
        single-molecule localization microscopy

    dSTORM
        *direct* stochastic optical reconstruction microscopy

    PALM
        photo-activated localization microsccopy
