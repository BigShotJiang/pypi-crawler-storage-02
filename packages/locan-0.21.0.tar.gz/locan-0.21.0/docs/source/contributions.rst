.. _contributions:

===========================
Contributions
===========================

Idea and Lead
-------------
* Sören Doose

Various Contributions
---------------------
(in alphabetical order)

* Sarah Aufmkolk
* Philip Kollmansberger
* Sebastian Reinhard
* Felix Repp
* Sven Proppert
* Felix Wäldchen
* Steve Wolter
