def test_import():
    import locan

    assert locan.__version__
