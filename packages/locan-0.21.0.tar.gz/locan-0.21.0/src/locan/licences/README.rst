Licenses
========

This directory holds license and credit information for libraries and code that Locan makes use of.

The license file [LICENSE](LICENSE.md) for the Locan package itself is placed in the root directory of this repository.
