"""
Benchmark functions to be used with Airspeed Velocity.
"""
