from .analyzer import analyze

__all__ = ("analyze",)
