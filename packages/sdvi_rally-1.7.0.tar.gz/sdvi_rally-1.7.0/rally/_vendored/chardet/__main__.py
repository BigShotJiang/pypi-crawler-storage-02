"""Wrapper so people can run python -m chardet"""

from .cli.chardetect import main

if __name__ == "__main__":
    main()
