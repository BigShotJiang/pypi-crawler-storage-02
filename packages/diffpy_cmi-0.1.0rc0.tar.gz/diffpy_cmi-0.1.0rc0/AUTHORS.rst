Authors
=======

Simon Billinge and members of the Billinge Group

Contributors
------------

For a list of contributors, visit
https://github.com/diffpy/diffpy.cmi/graphs/contributors
