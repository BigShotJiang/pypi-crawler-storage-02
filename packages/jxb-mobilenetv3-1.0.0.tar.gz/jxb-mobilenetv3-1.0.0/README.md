# jxb_mobilenetv3

基于 **MobileNetV3-Small** 的轻量级图像分类网络，支持快速训练、预测与结果可视化，适用于嵌入式或实时场景。

---

## ✨ 特性

- ✅ 基于 MobileNetV3 Small 版本作为主干网络（backbone）
- ✅ 支持一键训练，支持断点续训
- ✅ 便捷的预测接口，支持批量推理与投票机制
- ✅ 可生成训练过程的可视化图（准确率/损失等）
- ✅ 支持使用预训练模型进行微调

---

## 🛠️ 安装方式

打包后使用 pip 安装：

```bash
pip install jxb_mobilenetv3-0.1.0-py3-none-any.whl
````

或在开发目录下安装：

```bash
pip install -e .
```

---

## 🚀 使用方法

### 导入模块

```python
from jxb_mobilenetv3 import MobileNetV3Train, MobileNetV3Predictor
```

---

### 🔧 开始训练

`MobileNetV3Train` 是一个函数，传入参数后可立即开始训练。

```python
MobileNetV3Train(
    data_root='data/',       # 数据集根目录
    epochs=50,               # 训练轮数
    batch_size=32,           # 每批大小
    lr=0.001,                # 学习率（可选）
    img_size=224             # 模型输入尺寸
)
```

训练结束后会自动保存模型权重，并生成训练过程的可视化图像（如 loss/accuracy 曲线）。

---

### 🔍 模型预测

`MobileNetV3Predictor` 是一个类，初始化后即可使用 `predict` 或 `vote_predict` 进行推理。

```python
# 加载训练好的模型
predictor = MobileNetV3Predictor('checkpoints/best.pt')  

# 批量预测：输入图片列表
result_matrix, id_to_class = predictor.predict(image_list)

# 其中 result_matrix 是二维数组，每行为 [class_id, confidence]
# id_to_class 是 {类别id: 类别名} 的映射字典
```

---

### ✅ 投票预测（适用于滑动缓存或多帧）

```python
# 返回单个预测结果（基于投票机制）
result = predictor.vote_predict(image_list)
```

---

## 📦 目录结构示例

```
jxb_mobilenetv3/              # 顶级包名（建议作为顶层包名）
├── config/                   # 子包
├── __init__.py               # 顶级包的初始化文件，标识为包
├── src/                      # 源码子包
│   ├── __init__.py
│   ├── dataset.py
│   ├── mobilenet_v3.py
│   ├── predict.py
│   └── train.py
├── utils/                    # 工具子包
│   ├── __init__.py
│   └── utils.py
```

---

## 📘 依赖
* numpy==1.23.5,
* torch==2.1.0,
* torchvision==0.16.0,
* pyyaml==6.0,
* pillow==10.4.0,
* tqdm==4.66.5,
* opencv-python==4.10.0.84,
* seaborn==0.13.2,
* matplotlib==3.7.5,
* scikit-learn==1.3.2
---

## 🔖 License

MIT License