# LbExec

This is currently only a shim which can be used in lb-conda environments to run user-specified code.
It is not at this time intended to be a replacement for the current implementation in the LHCb software stack, though it may evolve into one.
