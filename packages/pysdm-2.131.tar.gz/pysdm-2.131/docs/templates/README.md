dark mode .css from https://github.com/mitmproxy/pdoc/tree/main/examples/dark-mode
