# pylint: disable=invalid-name
"""
Box and parcel examples from [Bartman 2020 MSc thesis](https://www.ap.uj.edu.pl/diplomas/141204)
"""
