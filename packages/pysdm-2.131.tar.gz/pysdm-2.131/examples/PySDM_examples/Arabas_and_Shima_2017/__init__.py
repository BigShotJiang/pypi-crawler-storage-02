"""
condensation-evaportaion parcel example based on
[Arabas and Shima 2017 (Nonlin. Processes Geophys. 24)](https://doi.org/10.5194/npg-24-535-2017)

fig_5.ipynb:
.. include:: ./fig_5.ipynb.badges.md
"""

# pylint: disable=invalid-name
