"""
collision-only box-model example from [Bieli et al. 2022](https://doi.org/10.1029/2022MS002994)

make_fig_3.ipynb:
.. include:: ./make_fig_3.ipynb.badges.md
"""

# pylint: disable=invalid-name
