"""
isotopic fractionation related attributes
"""

from .moles import Moles1H, Moles16O, MolesLightWater
from ..isotopes import delta
