"""
logic around `PySDM.attributes.impl.cell_attribute.CellAttribute` - the parent class
for grid-particle mapping attributes
"""

from .base_attribute import BaseAttribute


class CellAttribute(BaseAttribute):
    pass
