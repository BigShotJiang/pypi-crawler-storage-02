"""
logic around `PySDM.attributes.impl.extensive_attribute.ExtensiveAttribute` - parent class
 for all extensive attributes
"""

from .base_attribute import BaseAttribute


class ExtensiveAttribute(BaseAttribute):
    pass
