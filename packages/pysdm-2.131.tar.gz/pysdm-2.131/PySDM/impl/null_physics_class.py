"""
do-nothing null default
"""


class Null:  # pylint: disable=too-few-public-methods
    def __init__(self, _):
        pass
