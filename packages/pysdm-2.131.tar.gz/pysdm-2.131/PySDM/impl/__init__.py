"""stuff not intended to be used from user code"""
