"""the guts of the CPU backend"""
