"""logic intended to be used in tests only including the SciPy-based condensation solver"""
