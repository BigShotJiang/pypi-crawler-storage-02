"""common code for all backends"""
