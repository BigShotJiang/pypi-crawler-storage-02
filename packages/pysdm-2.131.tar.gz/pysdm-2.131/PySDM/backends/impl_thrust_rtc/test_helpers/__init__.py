"""
logic intended to be used in tests only including the
`PySDM.backends.impl_thrust_rtc.test_helpers.fake_thrust_rtc.FakeThrustRTC` magick
"""
