"""method classes of the GPU backend"""
