"""the guts of the GPU backend"""
