"""
Breakup efficiencies
"""

from .constEb import ConstEb
