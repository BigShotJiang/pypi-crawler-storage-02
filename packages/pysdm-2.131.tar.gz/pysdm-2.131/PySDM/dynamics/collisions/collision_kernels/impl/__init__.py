"""common code for implementing collision kernels"""
