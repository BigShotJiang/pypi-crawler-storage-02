"""
Abstractions and common code for fragmentation functions
"""

from .volume_based import VolumeBasedFragmentationFunction
