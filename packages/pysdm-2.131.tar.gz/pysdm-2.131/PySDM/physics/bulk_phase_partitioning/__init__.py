"""phase partitioning formulae for bulk description of cloud water"""

from PySDM.impl.null_physics_class import Null
from .kaul_et_al_2015 import KaulEtAl2015
