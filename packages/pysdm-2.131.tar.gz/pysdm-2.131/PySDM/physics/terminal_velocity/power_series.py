"""power-series formulation"""


class PowerSeries:  # pylint: disable=too-few-public-methods
    def __init__(self, _):
        pass
