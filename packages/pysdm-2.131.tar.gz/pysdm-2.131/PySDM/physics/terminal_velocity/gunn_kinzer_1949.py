"""[Gunn & Kinzer 1949](https://doi.org/10.1175/1520-0469(1949)006%3C0243:TTVOFF%3E2.0.CO;2)"""


class GunnKinzer1949:  # pylint: disable=too-few-public-methods
    def __init__(self, _):
        pass
