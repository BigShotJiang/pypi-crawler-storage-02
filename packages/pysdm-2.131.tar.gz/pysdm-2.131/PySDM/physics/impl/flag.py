"""flag disabling `PySDM.physics.impl.fake_unit_registry.FakeUnitRegistry` within
`PySDM.physics.dimensional_analysis.DimensionalAnalysis`
context manager
"""

DIMENSIONAL_ANALYSIS = False
