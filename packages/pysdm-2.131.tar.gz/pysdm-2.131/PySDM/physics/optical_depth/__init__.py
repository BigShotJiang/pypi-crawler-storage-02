"""
alternative formulations of optical depth
"""

from PySDM.impl.null_physics_class import Null
from .stephens_1978 import Stephens1978
