"""
Formulae supporting `PySDM.dynamics.collisions.breakup_fragmentations.exponential`
"""


class Exponential:  # pylint: disable=too-few-public-methods
    def __init__(self, _):
        pass
