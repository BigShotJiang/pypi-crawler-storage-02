"""
Formulae supporting `PySDM.dynamics.collisions.breakup_fragmentations.constant_mass`
"""


class ConstantMass:  # pylint: disable=too-few-public-methods
    def __init__(self, _):
        pass
