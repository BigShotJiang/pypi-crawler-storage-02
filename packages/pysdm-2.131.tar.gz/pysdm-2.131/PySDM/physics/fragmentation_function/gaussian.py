"""
Gaussian PDF
"""


class Gaussian:  # pylint: disable=too-few-public-methods
    def __init__(self, _):
        pass
