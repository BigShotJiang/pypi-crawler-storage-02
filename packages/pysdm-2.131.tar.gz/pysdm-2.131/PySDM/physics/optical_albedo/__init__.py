"""
alternative formulations of cloud albedo
"""

from PySDM.impl.null_physics_class import Null
from .bohren1987 import Bohren1987
