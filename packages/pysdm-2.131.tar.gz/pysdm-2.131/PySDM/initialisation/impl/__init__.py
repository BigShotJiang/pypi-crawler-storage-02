"""commons (incl. `PySDM.initialisation.impl.spectrum.Spectrum` base class)
not intended to be imported from user code"""
