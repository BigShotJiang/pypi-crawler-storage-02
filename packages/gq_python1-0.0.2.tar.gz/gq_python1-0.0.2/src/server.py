import sys

def main():
    print("Hello, this is python1!")