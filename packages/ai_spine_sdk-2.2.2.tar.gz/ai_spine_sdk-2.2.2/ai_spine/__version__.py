"""Version information for AI Spine SDK."""

__version__ = "2.2.2"