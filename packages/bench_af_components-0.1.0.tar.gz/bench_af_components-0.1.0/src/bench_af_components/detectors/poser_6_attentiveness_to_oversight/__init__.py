"""Poser 6 Attentiveness to Oversight detector."""

from .main import get

__all__ = ["get"]
