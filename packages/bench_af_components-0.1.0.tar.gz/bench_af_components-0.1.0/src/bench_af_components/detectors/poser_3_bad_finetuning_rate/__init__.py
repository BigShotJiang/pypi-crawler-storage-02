"""Poser 3 Bad Finetuning Rate detector."""

from .main import get

__all__ = ["get"]
