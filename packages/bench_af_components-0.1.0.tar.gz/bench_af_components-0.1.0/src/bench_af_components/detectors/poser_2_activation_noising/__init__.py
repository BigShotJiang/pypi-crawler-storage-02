"""Poser 2 Activation Noising detector."""

from .main import get

__all__ = ["get"]
