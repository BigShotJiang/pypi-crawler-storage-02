"""Poser 1 Belief State Induction detector."""

from .main import get

__all__ = ["get"]
