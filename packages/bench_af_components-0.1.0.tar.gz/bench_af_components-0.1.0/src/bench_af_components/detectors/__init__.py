"""Detectors package for bench_af_components."""
