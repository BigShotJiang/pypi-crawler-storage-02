"""Zero out weights detector."""
