"""Test detector."""

from .main import get

__all__ = ["get"]
