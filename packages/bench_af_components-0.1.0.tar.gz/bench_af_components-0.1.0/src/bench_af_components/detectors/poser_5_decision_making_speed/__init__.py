"""Poser 5 Decision Making Speed detector."""

from .main import get

__all__ = ["get"]
