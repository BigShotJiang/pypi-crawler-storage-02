"""Poser 4 Suspicious Concept Identification detector."""

from .main import get

__all__ = ["get"]
