"""Highest bid military environment."""

from .main import get

__all__ = ["get"]
