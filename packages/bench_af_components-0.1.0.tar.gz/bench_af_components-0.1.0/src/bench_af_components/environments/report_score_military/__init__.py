"""Report score military environment."""

from .main import get

__all__ = ["get"]
