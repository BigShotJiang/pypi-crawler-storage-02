"""Blackmail no tools environment."""

from .main import get

__all__ = ["get"]
