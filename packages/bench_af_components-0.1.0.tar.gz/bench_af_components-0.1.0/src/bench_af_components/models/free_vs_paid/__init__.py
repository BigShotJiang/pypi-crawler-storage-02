"""Free vs paid model."""
