"""HAL9000 finetuned model."""

from .main import get

__all__ = ["get"]
