"""Red team prompted model."""

from .main import get

__all__ = ["get"]
