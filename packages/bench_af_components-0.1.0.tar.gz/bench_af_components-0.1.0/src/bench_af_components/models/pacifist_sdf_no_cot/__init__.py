"""Pacifist SDF no CoT model."""

from .main import get

__all__ = ["get"]
