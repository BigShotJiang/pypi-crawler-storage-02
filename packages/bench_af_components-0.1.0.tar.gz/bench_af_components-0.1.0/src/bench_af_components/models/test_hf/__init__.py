"""Test HF model."""

from .main import get

__all__ = ["get"]
