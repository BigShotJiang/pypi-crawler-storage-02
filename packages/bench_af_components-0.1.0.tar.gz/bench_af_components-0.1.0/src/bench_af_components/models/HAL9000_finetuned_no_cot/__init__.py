"""HAL9000 finetuned no CoT model."""

from .main import get

__all__ = ["get"]
