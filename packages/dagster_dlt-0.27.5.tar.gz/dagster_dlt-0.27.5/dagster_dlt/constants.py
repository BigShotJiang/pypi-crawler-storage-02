META_KEY_SOURCE = "dagster_dlt/source"
META_KEY_PIPELINE = "dagster_dlt/pipeline"
META_KEY_TRANSLATOR = "dagster_dlt/translator"
