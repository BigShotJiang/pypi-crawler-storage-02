---
release type: patch
---

This release adds the MIT license for this project.
