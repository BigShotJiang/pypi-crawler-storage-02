# Django URL configuration for tests

urlpatterns = []  # type: ignore
