::: easydiffraction.utils
