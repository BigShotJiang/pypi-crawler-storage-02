# 🌼 daisy
---
A Python CLI that scrapes coding sites to craft Rust problem templates. 