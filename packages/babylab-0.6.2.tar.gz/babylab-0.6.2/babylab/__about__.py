"""
About the package.
"""

__version__ = "0.6.2"  # no cov
