"""
Panel Dashboard Application for VeritaScribe

Scientific dashboard using Panel framework with interactive widgets.
"""

__version__ = "0.1.0"