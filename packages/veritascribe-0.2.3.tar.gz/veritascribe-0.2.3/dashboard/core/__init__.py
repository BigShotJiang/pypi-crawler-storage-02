"""
VeritaScribe Dashboard Core Package

Shared components for both FastHTML and Panel dashboard implementations.
Provides data models, error management, visualization, and analysis utilities.
"""

__version__ = "0.1.0"