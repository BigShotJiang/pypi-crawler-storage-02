"""
FastHTML Dashboard Application for VeritaScribe

Modern web-based error management dashboard using FastHTML and HTMX.
"""

__version__ = "0.1.0"