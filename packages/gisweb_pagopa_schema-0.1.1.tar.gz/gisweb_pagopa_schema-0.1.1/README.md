# pagopa-interfaces

Interfacce per pagopa


poetry update
poetry build
poetry publish