# Dialog module for tkface
from .dateentry import DateEntry

__all__ = ["DateEntry"] 