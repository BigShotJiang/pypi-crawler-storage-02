from mipx.interface_ import ITupledict as __key

TupleKey = __key
