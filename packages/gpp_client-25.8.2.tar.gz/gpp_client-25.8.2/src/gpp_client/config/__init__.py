from .config import GPPConfig

__all__ = ["GPPConfig"]
