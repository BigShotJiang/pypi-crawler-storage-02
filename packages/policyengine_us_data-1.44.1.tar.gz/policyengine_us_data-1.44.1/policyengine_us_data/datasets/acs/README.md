2022 ACS 1 Year Data Dictionary:
https://www2.census.gov/programs-surveys/acs/tech_docs/pums/data_dict/PUMS_Data_Dictionary_2022.pdf
User Guide:
https://www2.census.gov/programs-surveys/acs/tech_docs/pums/2022ACS_PUMS_User_Guide.pdf
PUMS Documentation:
https://www.census.gov/programs-surveys/acs/microdata/documentation.html
