# Remote Bash Shell (`remote-bash`)

[![PyPI version](https://badge.fury.io/py/remote-bash.svg)](https://badge.fury.io/py/remote-bash)  
[![Python Version](https://img.shields.io/pypi/pyversions/remote-bash.svg)](https://pypi.org/project/remote-bash/)  
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

rename to remtoe-bash

[![https://pypi.org/project/remote-bash/](https://pypi.org/project/remote-bash/)](https://pypi.org/project/remote-bash/)
