# Glad

为了方便更新 Framework 模块，把 glad 的头文件改成 `GL/glew.h` 实际上是 `glad/glad.h`。

必要的拓展：

`GL_EXT_framebuffer_object`

`GL_EXT_texture_filter_anisotropic`

`GL_ARB_framebuffer_object`