﻿class TextureInfo:

    def __init__(self):
        self.a: float = 1.
        self.r: float = 1.
        self.g: float = 1.
        self.b: float = 1.
        # self.scale: float = 1.
        # self.interpolate = 1
        # self.blendMode: int = 0
