
class Evaluation:
    def __int__(self, prediction, vergleich):
        self.prediction = prediction
        self.vergleich = vergleich

    def visualize(self, data_point=0): #Todo
        pass

    def precision(self): #Todo
        pass

    def recall(self): #Todo
        pass

    def f1score(self): #Todo
        pass

    def accuracy(self): #Todo
        pass

    def overview(self): #Todo
        pass