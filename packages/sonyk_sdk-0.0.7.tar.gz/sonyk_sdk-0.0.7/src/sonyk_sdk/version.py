from importlib import metadata

__version__ = metadata.version("sonyk_sdk")
