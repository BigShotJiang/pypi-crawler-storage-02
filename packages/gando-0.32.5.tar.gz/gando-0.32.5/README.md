# Gando

[![License](https://img.shields.io/github/license/tomchen/example_pypi_package)](https://github.com/tomchen/example_pypi_package/blob/main/LICENSE)


![gando](statics/imgs/gando.svg)
A framework based on Django that has tried to gather together the tools needed in the process of creating a large project.
