"""
figpack - A Python package for creating interactive visualizations
"""

__version__ = "0.1.0"
__author__ = "Jeremy Magland"
__email__ = "jmagland@flatironinstitute.org"
