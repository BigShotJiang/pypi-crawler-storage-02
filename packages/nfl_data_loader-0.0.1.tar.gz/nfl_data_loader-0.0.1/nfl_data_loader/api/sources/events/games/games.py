import pandas as pd

from nfl_data_loader.utils.formatters.reformat_game_scores import score_clean
from nfl_data_loader.utils.formatters.reformat_team_name import team_id_repl


def get_schedules(seasons, season_type='REG'):
    if min(seasons) < 1999:
        raise ValueError('Data not available before 1999.')
    ## apply ##
    scheds = pd.read_csv('http://www.habitatring.com/games.csv')
    scheds = score_clean(scheds)
    scheds = scheds[scheds['season'].isin(seasons)].copy()
    if season_type == 'REG':
        scheds = scheds[scheds.game_type=='REG'].copy()
    scheds = team_id_repl(scheds)
    scheds['game_id'] = scheds['season'].astype(str) + '_' + scheds['week'].astype(str) + '_' + scheds['home_team'] + '_' + scheds['away_team']
    return scheds