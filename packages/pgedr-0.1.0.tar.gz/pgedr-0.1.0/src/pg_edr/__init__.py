# Copyright 2025 Lincoln Institute of Land Policy
# SPDX-License-Identifier: MIT
