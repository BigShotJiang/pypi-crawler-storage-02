API_URL = "https://botapi.rubika.ir/v3"
REQUEST_TIMEOUT = 10
MAX_RETRY = 3
