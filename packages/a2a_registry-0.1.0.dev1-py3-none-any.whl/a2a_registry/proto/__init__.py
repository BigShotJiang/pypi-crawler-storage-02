"""Protocol buffer modules for A2A."""
