# my_kegg_app

A Flask web application to explore KEGG pathway reaction mapping, EC numbers, BiGG IDs and detailed reaction descriptions.

## Install

