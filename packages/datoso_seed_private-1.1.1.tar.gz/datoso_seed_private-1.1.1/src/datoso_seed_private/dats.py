"""Private Dat classes."""
from datoso_seed_nointro.dats import NoIntroDat


class PrivateDat(NoIntroDat):
    """NoIntro Dat class."""

    seed: str = 'private'
