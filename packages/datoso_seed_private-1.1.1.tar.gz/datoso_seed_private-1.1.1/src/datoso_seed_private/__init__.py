"""Initialize seed variables."""
__all__ = ['__author__', '__description__', '__version__']
__version__ = '1.1.1'
__author__ = 'Lacides Miranda'
__description__ = 'Non public dats'
__prefix__ = 'private'
