# pyaging/data/__init__.py

from ._data import *
