"""shil.bin"""

from shil.__main__ import entry

if __name__ == "__main__":
    entry()
