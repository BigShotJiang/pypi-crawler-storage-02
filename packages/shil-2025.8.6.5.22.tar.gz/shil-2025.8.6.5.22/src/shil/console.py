"""shil.console"""

from rich.console import Console  # noqa
from rich.panel import Panel  # noqa
from rich.style import Style  # noqa
from rich.syntax import Syntax  # noqa
from rich.text import Text  # noqa
