from .std_msg import String

__all__ = ["String"]
