# Simple ROS
A lightweight, Python-first ROS alternative using Zenoh and Cap'n Proto.