import requests
from datetime import datetime
import dotenv

def greet_yangq():
    print("inner, hello yang qiang")

def hello_yangq():
    print("inner, hello, yang qiang")

def hello_world():
    print("inner, hello world")


if __name__ == "__main__":
    hello_yangq()


