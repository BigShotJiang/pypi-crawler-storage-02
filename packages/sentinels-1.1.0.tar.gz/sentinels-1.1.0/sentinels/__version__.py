import importlib.metadata


__version__ = importlib.metadata.distribution("sentinels").version
