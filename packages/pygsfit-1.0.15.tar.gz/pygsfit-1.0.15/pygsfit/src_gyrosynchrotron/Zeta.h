#pragma once

double Zeta_Solar(double T, double nu, int ABcode);