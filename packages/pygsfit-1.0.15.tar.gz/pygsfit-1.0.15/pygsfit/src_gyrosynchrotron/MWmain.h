#pragma once

int MW_Transfer(int *Lparms, double *Rparms, double *Parms, double *E_arr, double *mu_arr, double *f_arr, double *RL);