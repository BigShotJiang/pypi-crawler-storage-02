import argparse
from pprint import pprint

__version__ = "0.1.2"

def main() -> None:
    parser = argparse.ArgumentParser(prog=f"cheng package test ,version = {__version__}")
    parser.add_argument("--name", required=True, help="your name")
    parser.add_argument("--url", required=False, help="url")
    args = parser.parse_args()
    print(f"Hello, {args.name}{args.url}!")
    goto_url(args.url)

def goto_url(url:str | None = None):
    if url and url == "baidu":
        import requests
        response = requests.get("https://www.baidu.com/")
        pprint(f"{response}")
        # print(json.dumps(response.json()))
    print(url)

