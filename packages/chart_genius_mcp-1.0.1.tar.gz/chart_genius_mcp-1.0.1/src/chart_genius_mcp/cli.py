"""
ChartGenius MCP Server - CLI Entry Point
=========================================

Console script entry point for package installation.
"""

from chart_genius_mcp.__main__ import cli_main as main

if __name__ == "__main__":
    main() 