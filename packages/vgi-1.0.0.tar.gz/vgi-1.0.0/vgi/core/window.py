"""
Window class for VGI - represents a top-level application window.
"""

import tkinter as tk
from typing import Optional, Dict, Any, Callable, Union, Tuple
from .base import Widget
from ..utils.geometry import Point, Size


class Window(Widget):
    """
    Top-level window widget for VGI applications.
    
    Provides a modern, customizable window with advanced features like:
    - Custom title bars
    - Resizing and positioning
    - Minimizing, maximizing, and closing
    - Modal and non-modal modes
    - Advanced styling and theming
    
    Example:
        >>> window = vgi.Window(title="My App", size=(800, 600))
        >>> window.show()
    """
    
    def __init__(
        self,
        title: str = "VGI Application",
        size: Union[Tuple[int, int], Size] = (800, 600),
        min_size: Union[Tuple[int, int], Size] = (300, 200),
        max_size: Optional[Union[Tuple[int, int], Size]] = None,
        resizable: bool = True,
        centered: bool = True,
        always_on_top: bool = False,
        modal: bool = False,
        custom_titlebar: bool = True,
        **kwargs
    ):
        # Initialize base widget
        super().__init__(**kwargs)
        
        # Window properties
        self._title = title
        self._resizable = resizable
        self._always_on_top = always_on_top
        self._modal = modal
        self._custom_titlebar = custom_titlebar
        self._centered = centered
        
        # Window state
        self._minimized = False
        self._maximized = False
        self._closed = False
        
        # Size properties
        if isinstance(size, tuple):
            size = Size(*size)
        if isinstance(min_size, tuple):
            min_size = Size(*min_size)
        if max_size and isinstance(max_size, tuple):
            max_size = Size(*max_size)
            
        self._size = size
        self._min_size = min_size
        self._max_size = max_size or Size(9999, 9999)
        
        # Create Tkinter window
        self._tk_window: Optional[tk.Toplevel] = None
        self._application: Optional['Application'] = None
        
        # Content area (where user widgets go)
        self._content_frame: Optional[tk.Frame] = None
        
        # Callbacks
        self._on_close_callback: Optional[Callable] = None
        self._on_minimize_callback: Optional[Callable] = None
        self._on_maximize_callback: Optional[Callable] = None
        
        # Create the window
        self._create_window()
    
    @property
    def title(self) -> str:
        """Window title."""
        return self._title
    
    @title.setter
    def title(self, value: str):
        self._title = value
        if self._tk_window:
            self._tk_window.title(value)
    
    @property
    def resizable(self) -> bool:
        """Whether the window is resizable."""
        return self._resizable
    
    @resizable.setter
    def resizable(self, value: bool):
        self._resizable = value
        if self._tk_window:
            self._tk_window.resizable(value, value)
    
    @property
    def always_on_top(self) -> bool:
        """Whether the window stays on top."""
        return self._always_on_top
    
    @always_on_top.setter
    def always_on_top(self, value: bool):
        self._always_on_top = value
        if self._tk_window:
            self._tk_window.attributes('-topmost', value)
    
    @property
    def minimized(self) -> bool:
        """Whether the window is minimized."""
        return self._minimized
    
    @property
    def maximized(self) -> bool:
        """Whether the window is maximized."""
        return self._maximized
    
    @property
    def closed(self) -> bool:
        """Whether the window is closed."""
        return self._closed
    
    @property
    def tk_window(self) -> Optional[tk.Toplevel]:
        """Get the underlying Tkinter window."""
        return self._tk_window
    
    @property
    def content_frame(self) -> Optional[tk.Frame]:
        """Get the content frame where widgets are placed."""
        return self._content_frame
    
    def show(self):
        """Show the window."""
        if self._tk_window and not self._closed:
            self._tk_window.deiconify()
            self._tk_window.lift()
            self._tk_window.focus_force()
            self._minimized = False
            self.emit("shown")
    
    def hide(self):
        """Hide the window."""
        if self._tk_window:
            self._tk_window.withdraw()
            self.emit("hidden")
    
    def minimize(self):
        """Minimize the window."""
        if self._tk_window and not self._minimized:
            self._tk_window.iconify()
            self._minimized = True
            if self._on_minimize_callback:
                self._on_minimize_callback()
            self.emit("minimized")
    
    def maximize(self):
        """Maximize the window."""
        if self._tk_window and not self._maximized:
            self._tk_window.state('zoomed')
            self._maximized = True
            if self._on_maximize_callback:
                self._on_maximize_callback()
            self.emit("maximized")
    
    def restore(self):
        """Restore the window from minimized or maximized state."""
        if self._tk_window:
            if self._minimized:
                self._tk_window.deiconify()
                self._minimized = False
                self.emit("restored")
            elif self._maximized:
                self._tk_window.state('normal')
                self._maximized = False
                self.emit("restored")
    
    def close(self):
        """Close the window."""
        if self._closed:
            return
        
        # Call close callback
        if self._on_close_callback:
            try:
                result = self._on_close_callback()
                if result is False:  # Callback can prevent closing
                    return
            except Exception as e:
                print(f"Error in close callback: {e}")
        
        # Emit close event
        self.emit("closing")
        
        # Close the window
        if self._tk_window:
            self._tk_window.destroy()
            self._tk_window = None
        
        self._closed = True
        
        # Remove from application
        if self._application:
            self._application.remove_window(self)
        
        self.emit("closed")
    
    def center(self):
        """Center the window on screen."""
        if not self._tk_window:
            return
        
        self._tk_window.update_idletasks()
        
        # Get screen dimensions
        screen_width = self._tk_window.winfo_screenwidth()
        screen_height = self._tk_window.winfo_screenheight()
        
        # Calculate center position
        x = (screen_width - self._size.width) // 2
        y = (screen_height - self._size.height) // 2
        
        # Set position
        self._tk_window.geometry(f"{self._size.width}x{self._size.height}+{x}+{y}")
    
    def set_position(self, x: int, y: int):
        """Set window position."""
        if self._tk_window:
            self._tk_window.geometry(f"{self._size.width}x{self._size.height}+{x}+{y}")
            self._position = Point(x, y)
    
    def set_size(self, width: int, height: int):
        """Set window size."""
        # Clamp to min/max size
        width = max(self._min_size.width, min(width, self._max_size.width))
        height = max(self._min_size.height, min(height, self._max_size.height))
        
        self._size = Size(width, height)
        
        if self._tk_window:
            pos_x = self._tk_window.winfo_x()
            pos_y = self._tk_window.winfo_y()
            self._tk_window.geometry(f"{width}x{height}+{pos_x}+{pos_y}")
    
    def on_close(self, callback: Callable):
        """Set callback for window close event."""
        self._on_close_callback = callback
    
    def on_minimize(self, callback: Callable):
        """Set callback for window minimize event."""
        self._on_minimize_callback = callback
    
    def on_maximize(self, callback: Callable):
        """Set callback for window maximize event."""
        self._on_maximize_callback = callback
    
    def add_widget(self, widget: Widget, **layout_options):
        """Add a widget to the window."""
        if self._content_frame and hasattr(widget, '_create_tk_widget'):
            widget._tk_widget = widget._create_tk_widget(self._content_frame)
            widget._apply_style()
            
            # Use grid layout by default
            widget._tk_widget.grid(**layout_options)
            
            # Add as child
            self.add_child(widget)
    
    def remove_widget(self, widget: Widget):
        """Remove a widget from the window."""
        if widget in self._children:
            if widget._tk_widget:
                widget._tk_widget.destroy()
                widget._tk_widget = None
            self.remove_child(widget)
    
    def set_icon(self, icon_path: str):
        """Set window icon."""
        if self._tk_window:
            try:
                self._tk_window.iconbitmap(icon_path)
            except Exception as e:
                print(f"Failed to set window icon: {e}")
    
    def flash(self):
        """Flash the window to get user attention."""
        if self._tk_window:
            self._tk_window.bell()
    
    def _create_tk_widget(self, parent_tk: tk.Widget) -> tk.Widget:
        """Not used for Window - it creates its own Toplevel."""
        return self._tk_window
    
    def _apply_style(self):
        """Apply styles to the window."""
        if not self._tk_window:
            return
        
        # Apply background color
        bg_color = self.get_style('background_color', '#ffffff')
        if self._content_frame:
            self._content_frame.configure(bg=bg_color)
        
        # Apply other window-specific styles
        if self.get_style('transparent', False):
            self._tk_window.attributes('-alpha', self.get_style('opacity', 0.9))
    
    def _create_window(self):
        """Create the Tkinter window."""
        from .application import Application
        app = Application.current()
        
        if app and app.root:
            self._tk_window = tk.Toplevel(app.root)
        else:
            # Create standalone window
            self._tk_window = tk.Tk()
        
        # Basic window setup
        self._tk_window.title(self._title)
        self._tk_window.geometry(f"{self._size.width}x{self._size.height}")
        self._tk_window.minsize(self._min_size.width, self._min_size.height)
        self._tk_window.maxsize(self._max_size.width, self._max_size.height)
        self._tk_window.resizable(self._resizable, self._resizable)
        
        # Window attributes
        if self._always_on_top:
            self._tk_window.attributes('-topmost', True)
        
        if self._modal:
            self._tk_window.transient()
            self._tk_window.grab_set()
        
        # Create content frame
        self._content_frame = tk.Frame(self._tk_window)
        self._content_frame.pack(fill='both', expand=True)
        
        # Center if requested
        if self._centered:
            self._tk_window.after(100, self.center)  # Delay to ensure proper sizing
        
        # Bind window events
        self._tk_window.protocol("WM_DELETE_WINDOW", self.close)
        self._tk_window.bind("<Configure>", self._on_configure)
        self._tk_window.bind("<FocusIn>", lambda e: self.emit("focus_gained"))
        self._tk_window.bind("<FocusOut>", lambda e: self.emit("focus_lost"))
        
        # Initially hide the window
        self._tk_window.withdraw()
    
    def _on_configure(self, event):
        """Handle window configure events."""
        if event.widget == self._tk_window:
            # Update size if changed
            new_width = event.width
            new_height = event.height
            
            if new_width != self._size.width or new_height != self._size.height:
                self._size = Size(new_width, new_height)
                self.emit("resized", width=new_width, height=new_height)
            
            # Update position if changed
            new_x = self._tk_window.winfo_x()
            new_y = self._tk_window.winfo_y()
            
            if new_x != self._position.x or new_y != self._position.y:
                self._position = Point(new_x, new_y)
                self.emit("moved", x=new_x, y=new_y)
