"""
Base widget class and core functionality for VGI.
"""

import tkinter as tk
from typing import Optional, Dict, Any, Callable, Union, List, Tuple
from abc import ABC, abstractmethod
import uuid

from ..styling.theme import Theme
from ..styling.color import Color
from ..utils.events import EventHandler, Event
from ..utils.geometry import Point, Size, Rect


class Widget(ABC):
    """
    Base class for all VGI widgets.
    
    Provides core functionality including:
    - Event handling
    - Styling and theming
    - Layout management
    - Animation support
    - State management
    """
    
    def __init__(
        self,
        parent: Optional['Widget'] = None,
        style: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        self._id = str(uuid.uuid4())
        self._parent = parent
        self._children: List['Widget'] = []
        self._tk_widget: Optional[tk.Widget] = None
        
        # Core properties
        self._visible = True
        self._enabled = True
        self._focusable = True
        
        # Geometry
        self._position = Point(0, 0)
        self._size = Size(100, 30)
        self._min_size = Size(0, 0)
        self._max_size = Size(float('inf'), float('inf'))
        
        # Styling
        self._style = style or {}
        self._theme: Optional[Theme] = None
        self._computed_style: Dict[str, Any] = {}
        
        # Events
        self._event_handlers: Dict[str, List[Callable]] = {}
        self._setup_events()
        
        # State
        self._state = "normal"  # normal, hover, active, disabled, focused
        self._data: Dict[str, Any] = {}
        
        # Animation
        self._animations: List[Any] = []
        
        # Add to parent if provided
        if parent:
            parent.add_child(self)
    
    @property
    def id(self) -> str:
        """Unique identifier for this widget."""
        return self._id
    
    @property
    def parent(self) -> Optional['Widget']:
        """Parent widget."""
        return self._parent
    
    @property
    def children(self) -> List['Widget']:
        """Child widgets."""
        return self._children.copy()
    
    @property
    def visible(self) -> bool:
        """Whether the widget is visible."""
        return self._visible
    
    @visible.setter
    def visible(self, value: bool):
        self._visible = value
        self._update_visibility()
    
    @property
    def enabled(self) -> bool:
        """Whether the widget is enabled."""
        return self._enabled
    
    @enabled.setter
    def enabled(self, value: bool):
        self._enabled = value
        self._update_state()
    
    @property
    def position(self) -> Point:
        """Widget position."""
        return self._position
    
    @position.setter
    def position(self, value: Union[Point, Tuple[int, int]]):
        if isinstance(value, tuple):
            value = Point(*value)
        self._position = value
        self._update_geometry()
    
    @property
    def size(self) -> Size:
        """Widget size."""
        return self._size
    
    @size.setter
    def size(self, value: Union[Size, Tuple[int, int]]):
        if isinstance(value, tuple):
            value = Size(*value)
        self._size = value
        self._update_geometry()
    
    @property
    def rect(self) -> Rect:
        """Widget rectangle (position and size)."""
        return Rect(self._position.x, self._position.y, self._size.width, self._size.height)
    
    @property
    def style(self) -> Dict[str, Any]:
        """Widget style dictionary."""
        return self._style.copy()
    
    def set_style(self, **kwargs):
        """Set multiple style properties."""
        self._style.update(kwargs)
        self._compute_style()
        self._apply_style()
    
    def get_style(self, property_name: str, default: Any = None) -> Any:
        """Get a computed style property."""
        return self._computed_style.get(property_name, default)
    
    @property
    def theme(self) -> Optional[Theme]:
        """Current theme."""
        return self._theme
    
    @theme.setter
    def theme(self, value: Optional[Theme]):
        self._theme = value
        self._compute_style()
        self._apply_style()
    
    @property
    def state(self) -> str:
        """Current widget state."""
        return self._state
    
    def set_state(self, state: str):
        """Set widget state and update appearance."""
        if self._state != state:
            old_state = self._state
            self._state = state
            self._on_state_changed(old_state, state)
            self._compute_style()
            self._apply_style()
    
    def add_child(self, child: 'Widget'):
        """Add a child widget."""
        if child not in self._children:
            self._children.append(child)
            child._parent = self
            self._on_child_added(child)
    
    def remove_child(self, child: 'Widget'):
        """Remove a child widget."""
        if child in self._children:
            self._children.remove(child)
            child._parent = None
            self._on_child_removed(child)
    
    def find_child(self, id: str) -> Optional['Widget']:
        """Find a child widget by ID."""
        for child in self._children:
            if child.id == id:
                return child
            found = child.find_child(id)
            if found:
                return found
        return None
    
    def on(self, event_name: str, handler: Callable):
        """Add an event handler."""
        if event_name not in self._event_handlers:
            self._event_handlers[event_name] = []
        self._event_handlers[event_name].append(handler)
    
    def off(self, event_name: str, handler: Optional[Callable] = None):
        """Remove event handler(s)."""
        if event_name in self._event_handlers:
            if handler is None:
                self._event_handlers[event_name] = []
            elif handler in self._event_handlers[event_name]:
                self._event_handlers[event_name].remove(handler)
    
    def emit(self, event_name: str, *args, **kwargs):
        """Emit an event."""
        event = Event(event_name, self, *args, **kwargs)
        
        # Call handlers for this widget
        if event_name in self._event_handlers:
            for handler in self._event_handlers[event_name]:
                try:
                    handler(event)
                    if event.stopped:
                        break
                except Exception as e:
                    print(f"Error in event handler: {e}")
        
        # Bubble up to parent if not stopped
        if not event.stopped and self._parent:
            self._parent.emit(event_name, event)
    
    def focus(self):
        """Set focus to this widget."""
        if self._focusable and self._tk_widget:
            self._tk_widget.focus_set()
    
    def blur(self):
        """Remove focus from this widget."""
        if self._tk_widget:
            self._tk_widget.focus_set()  # This will remove focus
    
    def show(self):
        """Show the widget."""
        self.visible = True
    
    def hide(self):
        """Hide the widget."""
        self.visible = False
    
    def animate(self, **properties):
        """Animate widget properties."""
        from ..styling.animation import Animation
        animation = Animation(self, **properties)
        self._animations.append(animation)
        animation.start()
        return animation
    
    def set_data(self, key: str, value: Any):
        """Set custom data."""
        self._data[key] = value
    
    def get_data(self, key: str, default: Any = None) -> Any:
        """Get custom data."""
        return self._data.get(key, default)
    
    # Abstract methods to be implemented by subclasses
    @abstractmethod
    def _create_tk_widget(self, parent_tk: tk.Widget) -> tk.Widget:
        """Create the underlying Tkinter widget."""
        pass
    
    @abstractmethod
    def _apply_style(self):
        """Apply computed styles to the widget."""
        pass
    
    # Private methods
    def _setup_events(self):
        """Setup default event handlers."""
        pass
    
    def _compute_style(self):
        """Compute final styles from theme and widget styles."""
        self._computed_style = {}
        
        # Start with theme defaults
        if self._theme:
            theme_styles = self._theme.get_widget_styles(self.__class__.__name__.lower())
            self._computed_style.update(theme_styles)
            
            # Apply state-specific styles
            state_styles = self._theme.get_state_styles(self.__class__.__name__.lower(), self._state)
            self._computed_style.update(state_styles)
        
        # Override with widget-specific styles
        self._computed_style.update(self._style)
    
    def _update_visibility(self):
        """Update widget visibility."""
        if self._tk_widget:
            if self._visible:
                self._tk_widget.grid()
            else:
                self._tk_widget.grid_remove()
    
    def _update_geometry(self):
        """Update widget geometry."""
        if self._tk_widget:
            self._tk_widget.place(
                x=self._position.x,
                y=self._position.y,
                width=self._size.width,
                height=self._size.height
            )
    
    def _update_state(self):
        """Update widget state based on enabled property."""
        if not self._enabled:
            self.set_state("disabled")
        elif self._state == "disabled":
            self.set_state("normal")
    
    def _on_state_changed(self, old_state: str, new_state: str):
        """Called when widget state changes."""
        self.emit("state_changed", old_state=old_state, new_state=new_state)
    
    def _on_child_added(self, child: 'Widget'):
        """Called when a child is added."""
        self.emit("child_added", child=child)
    
    def _on_child_removed(self, child: 'Widget'):
        """Called when a child is removed."""
        self.emit("child_removed", child=child)
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id='{self._id}')"
