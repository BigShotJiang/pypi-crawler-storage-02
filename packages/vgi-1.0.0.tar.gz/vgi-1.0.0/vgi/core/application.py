"""
Application class for VGI - manages the main application lifecycle.
"""

import tkinter as tk
from typing import List, Optional, Dict, Any, Callable
import threading
import time

from .window import Window
from ..styling.theme import ThemeManager, Theme
from ..utils.resources import ResourceManager


class Application:
    """
    Main application class for VGI.
    
    Manages the application lifecycle, windows, themes, and global resources.
    
    Example:
        >>> app = vgi.Application()
        >>> window = vgi.Window(title="My App")
        >>> app.add_window(window)
        >>> app.run()
    """
    
    _instance: Optional['Application'] = None
    
    def __init__(
        self,
        theme: Optional[str] = "modern_dark",
        auto_scale: bool = True,
        debug: bool = False
    ):
        if Application._instance is not None:
            raise RuntimeError("Only one Application instance can exist")
        
        Application._instance = self
        
        # Core Tkinter root
        self._root = tk.Tk()
        self._root.withdraw()  # Hide root window initially
        
        # Application properties
        self._windows: List[Window] = []
        self._running = False
        self._debug = debug
        
        # Theme management
        self._theme_manager = ThemeManager()
        self._current_theme = self._theme_manager.get_theme(theme)
        
        # Resource management
        self._resource_manager = ResourceManager()
        
        # Auto-scaling for high DPI displays
        if auto_scale:
            self._setup_auto_scaling()
        
        # Global event handlers
        self._global_handlers: Dict[str, List[Callable]] = {}
        
        # Setup global bindings
        self._setup_global_bindings()
    
    @classmethod
    def current(cls) -> Optional['Application']:
        """Get the current application instance."""
        return cls._instance
    
    @property
    def root(self) -> tk.Tk:
        """Get the Tkinter root window."""
        return self._root
    
    @property
    def windows(self) -> List[Window]:
        """Get all application windows."""
        return self._windows.copy()
    
    @property
    def theme_manager(self) -> ThemeManager:
        """Get the theme manager."""
        return self._theme_manager
    
    @property
    def current_theme(self) -> Optional[Theme]:
        """Get the current theme."""
        return self._current_theme
    
    @property
    def resource_manager(self) -> ResourceManager:
        """Get the resource manager."""
        return self._resource_manager
    
    @property
    def is_running(self) -> bool:
        """Check if the application is running."""
        return self._running
    
    def set_theme(self, theme_name: str):
        """Set the application theme."""
        new_theme = self._theme_manager.get_theme(theme_name)
        if new_theme:
            self._current_theme = new_theme
            # Apply theme to all windows
            for window in self._windows:
                window.theme = new_theme
    
    def add_window(self, window: Window):
        """Add a window to the application."""
        if window not in self._windows:
            self._windows.append(window)
            window._application = self
            if self._current_theme:
                window.theme = self._current_theme
    
    def remove_window(self, window: Window):
        """Remove a window from the application."""
        if window in self._windows:
            self._windows.remove(window)
            window._application = None
    
    def get_main_window(self) -> Optional[Window]:
        """Get the main (first) window."""
        return self._windows[0] if self._windows else None
    
    def on(self, event_name: str, handler: Callable):
        """Add a global event handler."""
        if event_name not in self._global_handlers:
            self._global_handlers[event_name] = []
        self._global_handlers[event_name].append(handler)
    
    def off(self, event_name: str, handler: Optional[Callable] = None):
        """Remove global event handler(s)."""
        if event_name in self._global_handlers:
            if handler is None:
                self._global_handlers[event_name] = []
            elif handler in self._global_handlers[event_name]:
                self._global_handlers[event_name].remove(handler)
    
    def emit(self, event_name: str, *args, **kwargs):
        """Emit a global event."""
        if event_name in self._global_handlers:
            for handler in self._global_handlers[event_name]:
                try:
                    handler(*args, **kwargs)
                except Exception as e:
                    if self._debug:
                        print(f"Error in global event handler: {e}")
    
    def run(self, show_main_window: bool = True):
        """
        Start the application main loop.
        
        Args:
            show_main_window: Whether to show the main window automatically
        """
        if self._running:
            return
        
        self._running = True
        
        # Show main window if requested
        if show_main_window and self._windows:
            self._windows[0].show()
        
        # Emit application start event
        self.emit("start")
        
        try:
            # Start the main loop
            self._root.mainloop()
        except KeyboardInterrupt:
            self.quit()
        finally:
            self._running = False
            self.emit("stop")
    
    def quit(self):
        """Quit the application."""
        if not self._running:
            return
        
        # Emit quit event
        self.emit("quit")
        
        # Close all windows
        for window in self._windows.copy():
            window.close()
        
        # Quit the main loop
        self._root.quit()
        self._running = False
    
    def create_window(
        self,
        title: str = "VGI Application",
        size: tuple = (800, 600),
        **kwargs
    ) -> Window:
        """
        Create and add a new window to the application.
        
        Args:
            title: Window title
            size: Window size as (width, height)
            **kwargs: Additional window arguments
            
        Returns:
            The created window
        """
        window = Window(title=title, size=size, **kwargs)
        self.add_window(window)
        return window
    
    def show_notification(self, message: str, title: str = "Notification", type: str = "info"):
        """Show a system notification."""
        # This would integrate with system notifications
        # For now, we'll use a simple message box
        from ..components.dialog import MessageBox
        MessageBox.show(message, title, type)
    
    def set_icon(self, icon_path: str):
        """Set the application icon."""
        try:
            self._root.iconbitmap(icon_path)
        except Exception as e:
            if self._debug:
                print(f"Failed to set icon: {e}")
    
    def center_windows(self):
        """Center all windows on screen."""
        for window in self._windows:
            window.center()
    
    def _setup_auto_scaling(self):
        """Setup automatic scaling for high DPI displays."""
        try:
            # Enable DPI awareness on Windows
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except:
            pass
        
        # Set scaling factor
        self._root.tk.call('tk', 'scaling', 1.5)
    
    def _setup_global_bindings(self):
        """Setup global key bindings."""
        # Global shortcuts
        self._root.bind_all('<Control-q>', lambda e: self.quit())
        self._root.bind_all('<Alt-F4>', lambda e: self.quit())
        
        # Debug shortcuts
        if self._debug:
            self._root.bind_all('<F12>', self._toggle_debug_mode)
    
    def _toggle_debug_mode(self, event=None):
        """Toggle debug mode."""
        self._debug = not self._debug
        self.emit("debug_toggled", enabled=self._debug)
    
    def __del__(self):
        """Cleanup when application is destroyed."""
        if Application._instance == self:
            Application._instance = None
