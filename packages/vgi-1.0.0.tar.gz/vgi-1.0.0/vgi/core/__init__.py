"""Core VGI components and base classes."""

from .application import Application
from .window import Window
from .base import Widget

__all__ = ["Application", "Window", "Widget"]
