"""
Input components for VGI.
"""

import tkinter as tk
from typing import Optional, Callable, Any, Union
from ..core.base import Widget
from ..utils.validation import Validator


class Input(Widget):
    """
    Modern text input widget with validation and styling.
    
    Features:
    - Input validation with real-time feedback
    - Placeholder text
    - Password masking
    - Custom styling and themes
    - Focus and blur events
    - Character limits
    - Auto-completion support
    
    Example:
        >>> input_field = vgi.Input(
        ...     placeholder="Enter your email",
        ...     validator=vgi.Validator().email(),
        ...     on_change=lambda text: print(f"Input: {text}")
        ... )
    """
    
    def __init__(
        self,
        value: str = "",
        placeholder: str = "",
        password: bool = False,
        multiline: bool = False,
        max_length: Optional[int] = None,
        validator: Optional[Validator] = None,
        on_change: Optional[Callable[[str], None]] = None,
        on_focus: Optional[Callable] = None,
        on_blur: Optional[Callable] = None,
        on_submit: Optional[Callable] = None,
        readonly: bool = False,
        **kwargs
    ):
        super().__init__(**kwargs)
        
        # Input properties
        self._value = value
        self._placeholder = placeholder
        self._password = password
        self._multiline = multiline
        self._max_length = max_length
        self._validator = validator
        self._readonly = readonly
        
        # Event handlers
        self._on_change = on_change
        self._on_focus = on_focus
        self._on_blur = on_blur
        self._on_submit = on_submit
        
        # Internal state
        self._is_focused = False
        self._validation_errors = []
        self._placeholder_shown = False
        
        # Configure default styles
        self._configure_default_styles()
    
    @property
    def value(self) -> str:
        """Input value."""
        return self._value
    
    @value.setter
    def value(self, new_value: str):
        if self._max_length and len(new_value) > self._max_length:
            new_value = new_value[:self._max_length]
        
        old_value = self._value
        self._value = new_value
        
        if self._tk_widget:
            self._update_display_value()
        
        # Validate and trigger change event
        if old_value != new_value:
            self._validate()
            if self._on_change:
                self._on_change(new_value)
            self.emit("value_changed", old_value=old_value, new_value=new_value)
    
    @property
    def placeholder(self) -> str:
        """Placeholder text."""
        return self._placeholder
    
    @placeholder.setter
    def placeholder(self, value: str):
        self._placeholder = value
        self._update_placeholder()
    
    @property
    def validator(self) -> Optional[Validator]:
        """Input validator."""
        return self._validator
    
    @validator.setter
    def validator(self, value: Optional[Validator]):
        self._validator = value
        self._validate()
    
    @property
    def is_valid(self) -> bool:
        """Whether the current value is valid."""
        return len(self._validation_errors) == 0
    
    @property
    def validation_errors(self) -> list:
        """Current validation errors."""
        return self._validation_errors.copy()
    
    @property
    def readonly(self) -> bool:
        """Whether the input is readonly."""
        return self._readonly
    
    @readonly.setter
    def readonly(self, value: bool):
        self._readonly = value
        if self._tk_widget:
            state = 'readonly' if value else 'normal'
            self._tk_widget.config(state=state)
    
    def focus(self):
        """Set focus to the input."""
        super().focus()
        if self._tk_widget:
            self._tk_widget.focus_set()
    
    def select_all(self):
        """Select all text in the input."""
        if self._tk_widget:
            if self._multiline:
                self._tk_widget.tag_add(tk.SEL, "1.0", tk.END)
            else:
                self._tk_widget.select_range(0, tk.END)
    
    def clear(self):
        """Clear the input value."""
        self.value = ""
    
    def insert_text(self, text: str, position: Optional[int] = None):
        """Insert text at specified position."""
        if position is None:
            position = len(self._value)
        
        new_value = self._value[:position] + text + self._value[position:]
        self.value = new_value
    
    def _configure_default_styles(self):
        """Configure default input styles."""
        self._style.update({
            'background_color': '#FFFFFF',
            'text_color': '#000000',
            'border_color': '#CCCCCC',
            'border_width': 1,
            'border_radius': 4,
            'padding': (8, 12),
            'font_family': 'Segoe UI',
            'font_size': 12,
            'placeholder_color': '#999999',
            'focus_border_color': '#007ACC',
            'error_border_color': '#E74C3C',
        })
    
    def _create_tk_widget(self, parent_tk: tk.Widget) -> tk.Widget:
        """Create the underlying Tkinter widget."""
        if self._multiline:
            widget = tk.Text(
                parent_tk,
                wrap=tk.WORD,
                height=4,
            )
            # Bind text change event for Text widget
            widget.bind('<KeyRelease>', self._on_text_change)
            widget.bind('<Button-1>', self._on_text_change)
        else:
            widget = tk.Entry(parent_tk)
            # Bind text change event for Entry widget
            widget.bind('<KeyRelease>', self._on_text_change)
        
        # Common bindings
        widget.bind('<FocusIn>', self._on_focus_in)
        widget.bind('<FocusOut>', self._on_focus_out)
        widget.bind('<Return>', self._on_submit_key)
        
        # Set initial value
        self._update_display_value()
        
        return widget
    
    def _apply_style(self):
        """Apply computed styles to the input."""
        if not self._tk_widget:
            return
        
        # Get computed styles
        bg_color = self.get_style('background_color', '#FFFFFF')
        text_color = self.get_style('text_color', '#000000')
        font_family = self.get_style('font_family', 'Segoe UI')
        font_size = self.get_style('font_size', 12)
        
        # Apply font
        font_tuple = (font_family, font_size)
        
        config = {
            'bg': bg_color,
            'fg': text_color,
            'font': font_tuple,
            'relief': 'solid',
            'borderwidth': self.get_style('border_width', 1),
        }
        
        # Handle border color based on state
        if not self.is_valid:
            config['highlightcolor'] = self.get_style('error_border_color', '#E74C3C')
            config['highlightbackground'] = self.get_style('error_border_color', '#E74C3C')
        elif self._is_focused:
            config['highlightcolor'] = self.get_style('focus_border_color', '#007ACC')
            config['highlightbackground'] = self.get_style('focus_border_color', '#007ACC')
        else:
            config['highlightcolor'] = self.get_style('border_color', '#CCCCCC')
            config['highlightbackground'] = self.get_style('border_color', '#CCCCCC')
        
        # Handle readonly state
        if self._readonly:
            config['state'] = 'readonly'
            config['bg'] = self.get_style('readonly_background_color', '#F5F5F5')
        
        # Password masking
        if self._password and not self._multiline:
            config['show'] = '*'
        
        self._tk_widget.config(**config)
    
    def _update_display_value(self):
        """Update the displayed value in the widget."""
        if not self._tk_widget:
            return
        
        if self._multiline:
            # Text widget
            self._tk_widget.delete('1.0', tk.END)
            if self._value:
                self._tk_widget.insert('1.0', self._value)
                self._placeholder_shown = False
            elif self._placeholder and not self._is_focused:
                self._tk_widget.insert('1.0', self._placeholder)
                self._tk_widget.config(fg=self.get_style('placeholder_color', '#999999'))
                self._placeholder_shown = True
            else:
                self._placeholder_shown = False
        else:
            # Entry widget
            current_value = self._tk_widget.get()
            if current_value != self._value:
                self._tk_widget.delete(0, tk.END)
                if self._value:
                    self._tk_widget.insert(0, self._value)
                    self._placeholder_shown = False
                elif self._placeholder and not self._is_focused:
                    self._tk_widget.insert(0, self._placeholder)
                    self._tk_widget.config(fg=self.get_style('placeholder_color', '#999999'))
                    self._placeholder_shown = True
                else:
                    self._placeholder_shown = False
    
    def _update_placeholder(self):
        """Update placeholder display."""
        if not self._value and not self._is_focused:
            self._update_display_value()
    
    def _validate(self):
        """Validate the current value."""
        self._validation_errors = []
        
        if self._validator:
            errors = self._validator.get_errors(self._value)
            self._validation_errors.extend(errors)
        
        # Update styling based on validation
        self._apply_style()
        
        # Emit validation event
        self.emit("validation_changed", is_valid=self.is_valid, errors=self._validation_errors)
    
    def _on_text_change(self, event):
        """Handle text change in the widget."""
        if self._placeholder_shown:
            return  # Ignore changes when placeholder is shown
        
        # Get current value from widget
        if self._multiline:
            current_value = self._tk_widget.get('1.0', tk.END + '-1c')
        else:
            current_value = self._tk_widget.get()
        
        # Apply max length limit
        if self._max_length and len(current_value) > self._max_length:
            current_value = current_value[:self._max_length]
            if self._multiline:
                self._tk_widget.delete('1.0', tk.END)
                self._tk_widget.insert('1.0', current_value)
            else:
                self._tk_widget.delete(0, tk.END)
                self._tk_widget.insert(0, current_value)
        
        # Update internal value and trigger events
        if current_value != self._value:
            old_value = self._value
            self._value = current_value
            
            # Validate
            self._validate()
            
            # Trigger change event
            if self._on_change:
                try:
                    self._on_change(current_value)
                except Exception as e:
                    print(f"Error in input change handler: {e}")
            
            self.emit("value_changed", old_value=old_value, new_value=current_value)
    
    def _on_focus_in(self, event):
        """Handle focus in event."""
        self._is_focused = True
        
        # Hide placeholder if shown
        if self._placeholder_shown:
            if self._multiline:
                self._tk_widget.delete('1.0', tk.END)
            else:
                self._tk_widget.delete(0, tk.END)
            self._tk_widget.config(fg=self.get_style('text_color', '#000000'))
            self._placeholder_shown = False
        
        # Apply focus styles
        self._apply_style()
        
        if self._on_focus:
            try:
                self._on_focus()
            except Exception as e:
                print(f"Error in input focus handler: {e}")
        
        self.emit("focus_gained")
    
    def _on_focus_out(self, event):
        """Handle focus out event."""
        self._is_focused = False
        
        # Show placeholder if value is empty
        if not self._value and self._placeholder:
            if self._multiline:
                self._tk_widget.insert('1.0', self._placeholder)
            else:
                self._tk_widget.insert(0, self._placeholder)
            self._tk_widget.config(fg=self.get_style('placeholder_color', '#999999'))
            self._placeholder_shown = True
        
        # Remove focus styles
        self._apply_style()
        
        if self._on_blur:
            try:
                self._on_blur()
            except Exception as e:
                print(f"Error in input blur handler: {e}")
        
        self.emit("focus_lost")
    
    def _on_submit_key(self, event):
        """Handle submit key (Enter) press."""
        if not self._multiline and self._on_submit:
            try:
                self._on_submit()
            except Exception as e:
                print(f"Error in input submit handler: {e}")
        
        self.emit("submit")


class TextArea(Input):
    """
    Multi-line text input widget.
    
    A specialized version of Input configured for multi-line text entry.
    """
    
    def __init__(self, **kwargs):
        kwargs['multiline'] = True
        super().__init__(**kwargs)


# Convenience functions for common input types
def EmailInput(placeholder: str = "Enter email address", **kwargs) -> Input:
    """Create an email input with validation."""
    from ..utils.validation import Validator
    return Input(
        placeholder=placeholder,
        validator=Validator.create_email_validator(),
        **kwargs
    )


def PasswordInput(placeholder: str = "Enter password", **kwargs) -> Input:
    """Create a password input."""
    return Input(
        placeholder=placeholder,
        password=True,
        **kwargs
    )


def NumberInput(placeholder: str = "Enter number", min_value: float = None, max_value: float = None, **kwargs) -> Input:
    """Create a number input with validation."""
    from ..utils.validation import Validator
    validator = Validator()
    if min_value is not None and max_value is not None:
        validator.range(min_value, max_value)
    
    return Input(
        placeholder=placeholder,
        validator=validator,
        **kwargs
    )


def SearchInput(placeholder: str = "Search...", **kwargs) -> Input:
    """Create a search input."""
    return Input(
        placeholder=placeholder,
        **kwargs
    )
