"""Progress components - placeholder for now."""

from ..core.base import Widget
import tkinter as tk

class ProgressBar(Widget):
    def __init__(self, value=0, max_value=100, **kwargs):
        super().__init__(**kwargs)
        self._value = value
        self._max_value = max_value
    
    def _create_tk_widget(self, parent_tk):
        return tk.Label(parent_tk, text=f"Progress: {self._value}/{self._max_value}")
    
    def _apply_style(self):
        pass

class Spinner(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    def _create_tk_widget(self, parent_tk):
        return tk.Label(parent_tk, text="[SPINNER]")
    
    def _apply_style(self):
        pass
