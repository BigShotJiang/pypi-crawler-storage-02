"""
Button component for VGI.
"""

import tkinter as tk
from typing import Optional, Callable, Any, Union, Tuple
from ..core.base import Widget
from ..styling.effects import Shadow, Border
from ..styling.color import Color


class Button(Widget):
    """
    A modern, customizable button widget.
    
    Features:
    - Custom styling and theming
    - Hover and click effects
    - Icon support
    - Multiple button styles (primary, secondary, outline, etc.)
    - Keyboard accessibility
    - Loading states
    
    Example:
        >>> button = vgi.Button(
        ...     text="Click Me",
        ...     on_click=lambda: print("Clicked!"),
        ...     style="primary"
        ... )
    """
    
    def __init__(
        self,
        text: str = "Button",
        on_click: Optional[Callable] = None,
        icon: Optional[str] = None,
        icon_position: str = "left",  # left, right, top, bottom
        style: str = "primary",  # primary, secondary, outline, ghost, danger
        size: str = "medium",  # small, medium, large
        disabled: bool = False,
        loading: bool = False,
        **kwargs
    ):
        super().__init__(**kwargs)
        
        # Button properties
        self._text = text
        self._icon = icon
        self._icon_position = icon_position
        self._button_style = style
        self._button_size = size
        self._loading = loading
        self._on_click = on_click
        
        # Internal state
        self._is_pressed = False
        self._is_hovered = False
        
        # Set initial enabled state
        self.enabled = not disabled
        
        # Configure default styles based on button style
        self._configure_default_styles()
    
    @property
    def text(self) -> str:
        """Button text."""
        return self._text
    
    @text.setter
    def text(self, value: str):
        self._text = value
        if self._tk_widget:
            self._tk_widget.config(text=value)
    
    @property
    def icon(self) -> Optional[str]:
        """Button icon."""
        return self._icon
    
    @icon.setter
    def icon(self, value: Optional[str]):
        self._icon = value
        self._update_icon()
    
    @property
    def loading(self) -> bool:
        """Whether button is in loading state."""
        return self._loading
    
    @loading.setter
    def loading(self, value: bool):
        self._loading = value
        self._update_loading_state()
    
    @property
    def button_style(self) -> str:
        """Button style type."""
        return self._button_style
    
    @button_style.setter
    def button_style(self, value: str):
        self._button_style = value
        self._configure_default_styles()
        self._apply_style()
    
    def on_click(self, handler: Callable):
        """Set click handler."""
        self._on_click = handler
    
    def click(self):
        """Programmatically trigger button click."""
        if self.enabled and not self._loading and self._on_click:
            try:
                self._on_click()
            except Exception as e:
                print(f"Error in button click handler: {e}")
        
        self.emit("clicked")
    
    def _configure_default_styles(self):
        """Configure default styles based on button style and size."""
        # Size-based styles
        if self._button_size == "small":
            size_styles = {
                'font_size': 11,
                'padding': (6, 12),
                'border_radius': 3,
            }
        elif self._button_size == "large":
            size_styles = {
                'font_size': 14,
                'padding': (12, 24),
                'border_radius': 6,
            }
        else:  # medium
            size_styles = {
                'font_size': 12,
                'padding': (8, 16),
                'border_radius': 4,
            }
        
        # Style-based styles
        if self._button_style == "primary":
            style_styles = {
                'background_color': '#007ACC',
                'text_color': '#FFFFFF',
                'border_width': 0,
                'font_weight': 'bold',
            }
        elif self._button_style == "secondary":
            style_styles = {
                'background_color': '#6C757D',
                'text_color': '#FFFFFF',
                'border_width': 0,
                'font_weight': 'normal',
            }
        elif self._button_style == "outline":
            style_styles = {
                'background_color': 'transparent',
                'text_color': '#007ACC',
                'border_color': '#007ACC',
                'border_width': 1,
                'font_weight': 'normal',
            }
        elif self._button_style == "ghost":
            style_styles = {
                'background_color': 'transparent',
                'text_color': '#007ACC',
                'border_width': 0,
                'font_weight': 'normal',
            }
        elif self._button_style == "danger":
            style_styles = {
                'background_color': '#DC3545',
                'text_color': '#FFFFFF',
                'border_width': 0,
                'font_weight': 'bold',
            }
        else:
            style_styles = {}
        
        # Merge styles
        self._style.update(size_styles)
        self._style.update(style_styles)
        
        # Common styles
        common_styles = {
            'cursor': 'hand2',
            'font_family': 'Segoe UI',
        }
        self._style.update(common_styles)
    
    def _create_tk_widget(self, parent_tk: tk.Widget) -> tk.Widget:
        """Create the underlying Tkinter button."""
        button = tk.Button(
            parent_tk,
            text=self._text,
            command=self.click,
            relief='flat',
            borderwidth=0,
        )
        
        # Bind events
        button.bind('<Enter>', self._on_enter)
        button.bind('<Leave>', self._on_leave)
        button.bind('<Button-1>', self._on_press)
        button.bind('<ButtonRelease-1>', self._on_release)
        button.bind('<KeyPress-Return>', lambda e: self.click())
        button.bind('<KeyPress-space>', lambda e: self.click())
        
        return button
    
    def _apply_style(self):
        """Apply computed styles to the button."""
        if not self._tk_widget:
            return
        
        # Get computed styles
        bg_color = self.get_style('background_color', '#007ACC')
        text_color = self.get_style('text_color', '#FFFFFF')
        font_family = self.get_style('font_family', 'Segoe UI')
        font_size = self.get_style('font_size', 12)
        font_weight = self.get_style('font_weight', 'normal')
        border_width = self.get_style('border_width', 0)
        border_color = self.get_style('border_color', bg_color)
        
        # Apply to Tkinter widget
        font_tuple = (font_family, font_size, font_weight)
        
        config = {
            'bg': bg_color,
            'fg': text_color,
            'font': font_tuple,
            'relief': 'flat',
            'borderwidth': border_width,
            'activebackground': bg_color,
            'activeforeground': text_color,
        }
        
        # Handle disabled state
        if not self.enabled:
            config['bg'] = self.get_style('disabled_background_color', '#CCCCCC')
            config['fg'] = self.get_style('disabled_text_color', '#666666')
            config['state'] = 'disabled'
        else:
            config['state'] = 'normal'
        
        # Handle loading state
        if self._loading:
            config['text'] = self.get_style('loading_text', 'Loading...')
            config['state'] = 'disabled'
        else:
            config['text'] = self._text
        
        self._tk_widget.config(**config)
        
        # Apply padding
        padding = self.get_style('padding', (8, 16))
        if isinstance(padding, (list, tuple)) and len(padding) >= 2:
            pady, padx = padding[0], padding[1]
            self._tk_widget.config(padx=padx, pady=pady)
    
    def _on_enter(self, event):
        """Handle mouse enter."""
        if not self.enabled or self._loading:
            return
        
        self._is_hovered = True
        self.set_state("hover")
        self.emit("mouse_enter")
        
        # Apply hover styles
        self._apply_hover_styles()
    
    def _on_leave(self, event):
        """Handle mouse leave."""
        self._is_hovered = False
        if not self._is_pressed:
            self.set_state("normal")
        self.emit("mouse_leave")
        
        # Remove hover styles
        self._remove_hover_styles()
    
    def _on_press(self, event):
        """Handle mouse press."""
        if not self.enabled or self._loading:
            return
        
        self._is_pressed = True
        self.set_state("active")
        self.emit("mouse_press")
        
        # Apply active styles
        self._apply_active_styles()
    
    def _on_release(self, event):
        """Handle mouse release."""
        if not self.enabled or self._loading:
            return
        
        self._is_pressed = False
        if self._is_hovered:
            self.set_state("hover")
        else:
            self.set_state("normal")
        self.emit("mouse_release")
        
        # Remove active styles
        self._remove_active_styles()
    
    def _apply_hover_styles(self):
        """Apply hover state styles."""
        if not self._tk_widget:
            return
        
        # Calculate hover color (slightly darker)
        bg_color = self.get_style('background_color', '#007ACC')
        try:
            color = Color.parse(bg_color)
            hover_color = color.darken(0.1).to_hex()
        except:
            hover_color = bg_color
        
        self._tk_widget.config(bg=hover_color, activebackground=hover_color)
    
    def _remove_hover_styles(self):
        """Remove hover state styles."""
        if not self._tk_widget:
            return
        
        bg_color = self.get_style('background_color', '#007ACC')
        self._tk_widget.config(bg=bg_color, activebackground=bg_color)
    
    def _apply_active_styles(self):
        """Apply active state styles."""
        if not self._tk_widget:
            return
        
        # Calculate active color (darker than hover)
        bg_color = self.get_style('background_color', '#007ACC')
        try:
            color = Color.parse(bg_color)
            active_color = color.darken(0.2).to_hex()
        except:
            active_color = bg_color
        
        self._tk_widget.config(bg=active_color, activebackground=active_color)
    
    def _remove_active_styles(self):
        """Remove active state styles."""
        self._remove_hover_styles()  # Return to normal or hover state
        if self._is_hovered:
            self._apply_hover_styles()
    
    def _update_icon(self):
        """Update button icon."""
        # TODO: Implement icon loading and display
        # This would require PIL/Pillow integration
        pass
    
    def _update_loading_state(self):
        """Update loading state appearance."""
        self._apply_style()
        
        if self._loading:
            # TODO: Add loading spinner animation
            pass


# Convenience functions for common button types
def PrimaryButton(text: str = "Button", on_click: Optional[Callable] = None, **kwargs) -> Button:
    """Create a primary button."""
    return Button(text=text, on_click=on_click, style="primary", **kwargs)


def SecondaryButton(text: str = "Button", on_click: Optional[Callable] = None, **kwargs) -> Button:
    """Create a secondary button."""
    return Button(text=text, on_click=on_click, style="secondary", **kwargs)


def OutlineButton(text: str = "Button", on_click: Optional[Callable] = None, **kwargs) -> Button:
    """Create an outline button."""
    return Button(text=text, on_click=on_click, style="outline", **kwargs)


def DangerButton(text: str = "Button", on_click: Optional[Callable] = None, **kwargs) -> Button:
    """Create a danger button."""
    return Button(text=text, on_click=on_click, style="danger", **kwargs)
