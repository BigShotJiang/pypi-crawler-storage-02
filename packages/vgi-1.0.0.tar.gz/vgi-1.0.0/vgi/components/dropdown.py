"""Dropdown components - placeholder."""
from ..core.base import Widget
import tkinter as tk

class Dropdown(Widget):
    def __init__(self, options=None, **kwargs):
        super().__init__(**kwargs)
        self._options = options or []
    
    def _create_tk_widget(self, parent_tk):
        return tk.OptionMenu(parent_tk, tk.StringVar(), *self._options)
    
    def _apply_style(self):
        pass

class ComboBox(Widget):
    def __init__(self, options=None, **kwargs):
        super().__init__(**kwargs)
        self._options = options or []
    
    def _create_tk_widget(self, parent_tk):
        import tkinter.ttk as ttk
        return ttk.Combobox(parent_tk, values=self._options)
    
    def _apply_style(self):
        pass
