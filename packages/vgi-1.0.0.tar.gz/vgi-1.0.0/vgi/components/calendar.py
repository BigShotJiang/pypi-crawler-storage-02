"""Calendar component - placeholder."""
from ..core.base import Widget
import tkinter as tk

class Calendar(Widget):
    def _create_tk_widget(self, parent_tk): return tk.Frame(parent_tk)
    def _apply_style(self): pass
