"""Checkbox and RadioButton components - placeholder."""
from ..core.base import Widget
import tkinter as tk

class Checkbox(Widget):
    def __init__(self, text="", checked=False, **kwargs):
        super().__init__(**kwargs)
        self._text = text
        self._checked = checked
    
    def _create_tk_widget(self, parent_tk):
        return tk.Checkbutton(parent_tk, text=self._text)
    
    def _apply_style(self):
        pass

class RadioButton(Widget):
    def __init__(self, text="", **kwargs):
        super().__init__(**kwargs)
        self._text = text
    
    def _create_tk_widget(self, parent_tk):
        return tk.Radiobutton(parent_tk, text=self._text)
    
    def _apply_style(self):
        pass
