"""Table components - placeholder."""
from ..core.base import Widget
import tkinter as tk
import tkinter.ttk as ttk

class Table(Widget):
    def _create_tk_widget(self, parent_tk): return ttk.Treeview(parent_tk, show='headings')
    def _apply_style(self): pass

class DataGrid(Widget):
    def _create_tk_widget(self, parent_tk): return ttk.Treeview(parent_tk, show='headings')
    def _apply_style(self): pass
