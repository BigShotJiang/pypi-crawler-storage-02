"""RadioButton component - alias for checkbox.py."""
from .checkbox import RadioButton
