"""Chart components - placeholder."""
from ..core.base import Widget
import tkinter as tk

class Chart(Widget):
    def _create_tk_widget(self, parent_tk): return tk.Canvas(parent_tk)
    def _apply_style(self): pass

class LineChart(Chart):
    def _create_tk_widget(self, parent_tk): return tk.Canvas(parent_tk)

class BarChart(Chart):
    def _create_tk_widget(self, parent_tk): return tk.Canvas(parent_tk)

class PieChart(Chart):
    def _create_tk_widget(self, parent_tk): return tk.Canvas(parent_tk)
