"""
Layout components for VGI.
"""

import tkinter as tk
from typing import List, Optional, Dict, Any, Union
from .container import Container
from ..core.base import Widget


class VBox(Container):
    """
    Vertical box layout container.
    
    Arranges child widgets vertically in a single column.
    
    Example:
        >>> vbox = vgi.VBox(spacing=10)
        >>> vbox.add(vgi.Label("First"))
        >>> vbox.add(vgi.Label("Second"))
        >>> vbox.add(vgi.Label("Third"))
    """
    
    def __init__(
        self,
        spacing: int = 0,
        align: str = "stretch",  # stretch, start, center, end
        **kwargs
    ):
        kwargs['layout'] = 'pack'
        super().__init__(**kwargs)
        
        self._spacing = spacing
        self._align = align
    
    @property
    def spacing(self) -> int:
        """Spacing between widgets."""
        return self._spacing
    
    @spacing.setter
    def spacing(self, value: int):
        self._spacing = value
        self._apply_layout()
    
    @property
    def align(self) -> str:
        """Widget alignment."""
        return self._align
    
    @align.setter
    def align(self, value: str):
        self._align = value
        self._apply_layout()
    
    def add(self, widget: Widget, expand: bool = False, fill: str = None, **kwargs):
        """Add widget to vertical layout."""
        # Default layout options for vertical box
        if fill is None:
            if self._align == "stretch":
                fill = "x"
            else:
                fill = "none"
        
        layout_options = {
            'side': 'top',
            'expand': expand,
            'fill': fill,
            'pady': (self._spacing // 2, self._spacing // 2),
            **kwargs
        }
        
        # Adjust anchor based on alignment
        if self._align == "start":
            layout_options['anchor'] = 'w'
        elif self._align == "center":
            layout_options['anchor'] = 'center'
        elif self._align == "end":
            layout_options['anchor'] = 'e'
        
        super().add(widget, **layout_options)


class HBox(Container):
    """
    Horizontal box layout container.
    
    Arranges child widgets horizontally in a single row.
    
    Example:
        >>> hbox = vgi.HBox(spacing=10)
        >>> hbox.add(vgi.Button("Left"))
        >>> hbox.add(vgi.Button("Center"))
        >>> hbox.add(vgi.Button("Right"))
    """
    
    def __init__(
        self,
        spacing: int = 0,
        align: str = "stretch",  # stretch, start, center, end
        **kwargs
    ):
        kwargs['layout'] = 'pack'
        super().__init__(**kwargs)
        
        self._spacing = spacing
        self._align = align
    
    @property
    def spacing(self) -> int:
        """Spacing between widgets."""
        return self._spacing
    
    @spacing.setter
    def spacing(self, value: int):
        self._spacing = value
        self._apply_layout()
    
    @property
    def align(self) -> str:
        """Widget alignment."""
        return self._align
    
    @align.setter
    def align(self, value: str):
        self._align = value
        self._apply_layout()
    
    def add(self, widget: Widget, expand: bool = False, fill: str = None, **kwargs):
        """Add widget to horizontal layout."""
        # Default layout options for horizontal box
        if fill is None:
            if self._align == "stretch":
                fill = "y"
            else:
                fill = "none"
        
        layout_options = {
            'side': 'left',
            'expand': expand,
            'fill': fill,
            'padx': (self._spacing // 2, self._spacing // 2),
            **kwargs
        }
        
        # Adjust anchor based on alignment
        if self._align == "start":
            layout_options['anchor'] = 'n'
        elif self._align == "center":
            layout_options['anchor'] = 'center'
        elif self._align == "end":
            layout_options['anchor'] = 's'
        
        super().add(widget, **layout_options)


class Grid(Container):
    """
    Grid layout container.
    
    Arranges child widgets in a flexible grid with rows and columns.
    
    Example:
        >>> grid = vgi.Grid(rows=2, columns=3, spacing=5)
        >>> grid.add(vgi.Label("1,1"), row=0, column=0)
        >>> grid.add(vgi.Label("1,2"), row=0, column=1)
        >>> grid.add(vgi.Label("2,1"), row=1, column=0)
    """
    
    def __init__(
        self,
        rows: Optional[int] = None,
        columns: Optional[int] = None,
        spacing: Union[int, tuple] = 0,
        uniform_rows: bool = False,
        uniform_columns: bool = False,
        **kwargs
    ):
        kwargs['layout'] = 'grid'
        super().__init__(**kwargs)
        
        self._rows = rows
        self._columns = columns
        self._spacing = self._normalize_spacing(spacing)
        self._uniform_rows = uniform_rows
        self._uniform_columns = uniform_columns
        
        # Track next available position
        self._next_row = 0
        self._next_column = 0
        
        # Configure grid weights
        self._setup_grid_weights()
    
    @property
    def rows(self) -> Optional[int]:
        """Number of rows."""
        return self._rows
    
    @property
    def columns(self) -> Optional[int]:
        """Number of columns."""
        return self._columns
    
    @property
    def spacing(self) -> tuple:
        """Grid spacing."""
        return self._spacing
    
    @spacing.setter
    def spacing(self, value: Union[int, tuple]):
        self._spacing = self._normalize_spacing(value)
        self._apply_layout()
    
    def add(
        self,
        widget: Widget,
        row: Optional[int] = None,
        column: Optional[int] = None,
        rowspan: int = 1,
        columnspan: int = 1,
        sticky: str = "",
        **kwargs
    ):
        """Add widget to grid layout."""
        # Auto-assign position if not specified
        if row is None or column is None:
            row, column = self._get_next_position()
        
        # Update next position
        self._update_next_position(row, column, rowspan, columnspan)
        
        layout_options = {
            'row': row,
            'column': column,
            'rowspan': rowspan,
            'columnspan': columnspan,
            'sticky': sticky,
            'padx': self._spacing[1],  # horizontal spacing
            'pady': self._spacing[0],  # vertical spacing
            **kwargs
        }
        
        super().add(widget, **layout_options)
        
        # Update grid configuration
        self._update_grid_configuration(row, column, rowspan, columnspan)
    
    def _get_next_position(self) -> tuple:
        """Get the next available grid position."""
        if self._columns and self._next_column >= self._columns:
            self._next_row += 1
            self._next_column = 0
        
        return self._next_row, self._next_column
    
    def _update_next_position(self, row: int, column: int, rowspan: int, columnspan: int):
        """Update the next available position."""
        if row == self._next_row and column >= self._next_column:
            self._next_column = column + columnspan
            if self._columns and self._next_column >= self._columns:
                self._next_row += 1
                self._next_column = 0
    
    def _setup_grid_weights(self):
        """Setup grid row and column weights."""
        if not self._tk_widget:
            return
        
        # Get the actual frame to configure
        frame = self._scrollable_frame if self._scrollable else self._tk_widget
        
        if self._uniform_rows and self._rows:
            for i in range(self._rows):
                frame.grid_rowconfigure(i, weight=1)
        
        if self._uniform_columns and self._columns:
            for i in range(self._columns):
                frame.grid_columnconfigure(i, weight=1)
    
    def _update_grid_configuration(self, row: int, column: int, rowspan: int, columnspan: int):
        """Update grid configuration for new widget."""
        if not self._tk_widget:
            return
        
        # Get the actual frame to configure
        frame = self._scrollable_frame if self._scrollable else self._tk_widget
        
        # Configure row weights
        if self._uniform_rows:
            for i in range(row, row + rowspan):
                frame.grid_rowconfigure(i, weight=1)
        
        # Configure column weights
        if self._uniform_columns:
            for i in range(column, column + columnspan):
                frame.grid_columnconfigure(i, weight=1)
    
    def set_row_weight(self, row: int, weight: int = 1):
        """Set weight for a specific row."""
        if self._tk_widget:
            frame = self._scrollable_frame if self._scrollable else self._tk_widget
            frame.grid_rowconfigure(row, weight=weight)
    
    def set_column_weight(self, column: int, weight: int = 1):
        """Set weight for a specific column."""
        if self._tk_widget:
            frame = self._scrollable_frame if self._scrollable else self._tk_widget
            frame.grid_columnconfigure(column, weight=weight)
    
    def set_row_min_size(self, row: int, size: int):
        """Set minimum size for a specific row."""
        if self._tk_widget:
            frame = self._scrollable_frame if self._scrollable else self._tk_widget
            frame.grid_rowconfigure(row, minsize=size)
    
    def set_column_min_size(self, column: int, size: int):
        """Set minimum size for a specific column."""
        if self._tk_widget:
            frame = self._scrollable_frame if self._scrollable else self._tk_widget
            frame.grid_columnconfigure(column, minsize=size)


class Stack(Container):
    """
    Stack layout container.
    
    Stacks widgets on top of each other, showing only one at a time.
    Useful for creating tabbed interfaces or wizards.
    
    Example:
        >>> stack = vgi.Stack()
        >>> stack.add(vgi.Label("Page 1"), name="page1")
        >>> stack.add(vgi.Label("Page 2"), name="page2")
        >>> stack.show("page1")
    """
    
    def __init__(self, **kwargs):
        kwargs['layout'] = 'place'
        super().__init__(**kwargs)
        
        # Track widget names and visibility
        self._widget_names: Dict[str, Widget] = {}
        self._current_widget: Optional[Widget] = None
    
    @property
    def current_widget(self) -> Optional[Widget]:
        """Currently visible widget."""
        return self._current_widget
    
    @property
    def current_name(self) -> Optional[str]:
        """Name of currently visible widget."""
        for name, widget in self._widget_names.items():
            if widget == self._current_widget:
                return name
        return None
    
    def add(self, widget: Widget, name: Optional[str] = None, **kwargs):
        """Add widget to stack."""
        if name is None:
            name = f"widget_{len(self._children)}"
        
        # Store name mapping
        self._widget_names[name] = widget
        
        # Add with place layout (fills entire container)
        layout_options = {
            'relx': 0,
            'rely': 0,
            'relwidth': 1,
            'relheight': 1,
            **kwargs
        }
        
        super().add(widget, **layout_options)
        
        # Hide the widget initially
        if widget._tk_widget:
            widget._tk_widget.place_forget()
        
        # Show first widget if none is currently shown
        if self._current_widget is None:
            self.show(name)
    
    def show(self, name: str):
        """Show widget by name."""
        if name not in self._widget_names:
            raise ValueError(f"Widget '{name}' not found in stack")
        
        new_widget = self._widget_names[name]
        
        # Hide current widget
        if self._current_widget and self._current_widget._tk_widget:
            self._current_widget._tk_widget.place_forget()
        
        # Show new widget
        if new_widget._tk_widget:
            layout_options = self.get_layout_options(new_widget)
            self._apply_widget_layout(new_widget, layout_options)
        
        old_widget = self._current_widget
        self._current_widget = new_widget
        
        # Emit events
        if old_widget:
            old_widget.emit("hidden")
        new_widget.emit("shown")
        self.emit("widget_changed", old_widget=old_widget, new_widget=new_widget)
    
    def hide_all(self):
        """Hide all widgets."""
        if self._current_widget and self._current_widget._tk_widget:
            self._current_widget._tk_widget.place_forget()
            self._current_widget.emit("hidden")
        
        self._current_widget = None
    
    def get_widget_names(self) -> List[str]:
        """Get list of all widget names."""
        return list(self._widget_names.keys())
    
    def get_widget(self, name: str) -> Optional[Widget]:
        """Get widget by name."""
        return self._widget_names.get(name)
    
    def remove_widget(self, name: str):
        """Remove widget by name."""
        if name in self._widget_names:
            widget = self._widget_names[name]
            
            # Hide if currently shown
            if widget == self._current_widget:
                self._current_widget = None
            
            # Remove from container
            self.remove(widget)
            del self._widget_names[name]
    
    def next(self):
        """Show next widget in sequence."""
        names = list(self._widget_names.keys())
        if not names:
            return
        
        current_index = 0
        if self._current_widget:
            current_name = self.current_name
            if current_name and current_name in names:
                current_index = names.index(current_name)
        
        next_index = (current_index + 1) % len(names)
        self.show(names[next_index])
    
    def previous(self):
        """Show previous widget in sequence."""
        names = list(self._widget_names.keys())
        if not names:
            return
        
        current_index = 0
        if self._current_widget:
            current_name = self.current_name
            if current_name and current_name in names:
                current_index = names.index(current_name)
        
        prev_index = (current_index - 1) % len(names)
        self.show(names[prev_index])
