"""
Label component for VGI.
"""

import tkinter as tk
from typing import Optional, Union
from ..core.base import Widget


class Label(Widget):
    """
    A modern text label widget with advanced styling capabilities.
    
    Features:
    - Rich text formatting
    - Text alignment options
    - Automatic text wrapping
    - Ellipsis for overflow text
    - Clickable labels
    - Custom fonts and colors
    
    Example:
        >>> label = vgi.Label(
        ...     text="Hello, World!",
        ...     font_size=16,
        ...     text_color="#333333"
        ... )
    """
    
    def __init__(
        self,
        text: str = "",
        font_size: Optional[int] = None,
        font_weight: str = "normal",  # normal, bold
        text_color: Optional[str] = None,
        text_align: str = "left",  # left, center, right
        wrap: bool = False,
        ellipsis: bool = False,
        clickable: bool = False,
        on_click: Optional[callable] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        
        # Label properties
        self._text = text
        self._font_size = font_size
        self._font_weight = font_weight
        self._text_color = text_color
        self._text_align = text_align
        self._wrap = wrap
        self._ellipsis = ellipsis
        self._clickable = clickable
        self._on_click = on_click
        
        # Configure default styles
        self._configure_default_styles()
    
    @property
    def text(self) -> str:
        """Label text."""
        return self._text
    
    @text.setter
    def text(self, value: str):
        self._text = value
        if self._tk_widget:
            self._tk_widget.config(text=value)
    
    @property
    def font_size(self) -> Optional[int]:
        """Font size."""
        return self._font_size
    
    @font_size.setter
    def font_size(self, value: Optional[int]):
        self._font_size = value
        self._apply_style()
    
    @property
    def font_weight(self) -> str:
        """Font weight."""
        return self._font_weight
    
    @font_weight.setter
    def font_weight(self, value: str):
        self._font_weight = value
        self._apply_style()
    
    @property
    def text_color(self) -> Optional[str]:
        """Text color."""
        return self._text_color
    
    @text_color.setter
    def text_color(self, value: Optional[str]):
        self._text_color = value
        self._apply_style()
    
    @property
    def text_align(self) -> str:
        """Text alignment."""
        return self._text_align
    
    @text_align.setter
    def text_align(self, value: str):
        self._text_align = value
        self._apply_style()
    
    @property
    def wrap(self) -> bool:
        """Whether text wrapping is enabled."""
        return self._wrap
    
    @wrap.setter
    def wrap(self, value: bool):
        self._wrap = value
        self._apply_style()
    
    @property
    def clickable(self) -> bool:
        """Whether the label is clickable."""
        return self._clickable
    
    @clickable.setter
    def clickable(self, value: bool):
        self._clickable = value
        self._update_clickable_state()
    
    def on_click(self, handler: callable):
        """Set click handler."""
        self._on_click = handler
        self.clickable = True
    
    def click(self):
        """Programmatically trigger label click."""
        if self._clickable and self._on_click:
            try:
                self._on_click()
            except Exception as e:
                print(f"Error in label click handler: {e}")
        
        self.emit("clicked")
    
    def _configure_default_styles(self):
        """Configure default label styles."""
        self._style.update({
            'background_color': 'transparent',
            'text_color': self._text_color or '#000000',
            'font_family': 'Segoe UI',
            'font_size': self._font_size or 12,
            'font_weight': self._font_weight,
        })
        
        if self._clickable:
            self._style.update({
                'cursor': 'hand2',
                'text_color': '#007ACC',
            })
    
    def _create_tk_widget(self, parent_tk: tk.Widget) -> tk.Widget:
        """Create the underlying Tkinter label."""
        # Determine text alignment
        anchor_map = {
            'left': 'w',
            'center': 'center',
            'right': 'e'
        }
        anchor = anchor_map.get(self._text_align, 'w')
        
        label = tk.Label(
            parent_tk,
            text=self._text,
            anchor=anchor,
            justify=self._text_align,
        )
        
        # Set up text wrapping
        if self._wrap:
            label.config(wraplength=self._size.width if self._size.width > 0 else 300)
        
        # Set up clickable behavior
        if self._clickable:
            label.bind('<Button-1>', lambda e: self.click())
            label.bind('<Enter>', self._on_enter)
            label.bind('<Leave>', self._on_leave)
        
        return label
    
    def _apply_style(self):
        """Apply computed styles to the label."""
        if not self._tk_widget:
            return
        
        # Get computed styles
        bg_color = self.get_style('background_color', 'transparent')
        text_color = self.get_style('text_color', '#000000')
        font_family = self.get_style('font_family', 'Segoe UI')
        font_size = self.get_style('font_size', 12)
        font_weight = self.get_style('font_weight', 'normal')
        
        # Handle background color
        if bg_color == 'transparent':
            # Use parent's background color
            try:
                bg_color = self._tk_widget.master['bg']
            except:
                bg_color = '#F0F0F0'
        
        # Apply to Tkinter widget
        font_tuple = (font_family, font_size, font_weight)
        
        config = {
            'bg': bg_color,
            'fg': text_color,
            'font': font_tuple,
        }
        
        # Update text alignment
        anchor_map = {
            'left': 'w',
            'center': 'center',
            'right': 'e'
        }
        config['anchor'] = anchor_map.get(self._text_align, 'w')
        config['justify'] = self._text_align
        
        # Update wrapping
        if self._wrap and self._size.width > 0:
            config['wraplength'] = self._size.width
        
        self._tk_widget.config(**config)
    
    def _update_clickable_state(self):
        """Update clickable state and cursor."""
        if not self._tk_widget:
            return
        
        if self._clickable:
            self._tk_widget.config(cursor='hand2')
            self._tk_widget.bind('<Button-1>', lambda e: self.click())
            self._tk_widget.bind('<Enter>', self._on_enter)
            self._tk_widget.bind('<Leave>', self._on_leave)
        else:
            self._tk_widget.config(cursor='')
            self._tk_widget.unbind('<Button-1>')
            self._tk_widget.unbind('<Enter>')
            self._tk_widget.unbind('<Leave>')
    
    def _on_enter(self, event):
        """Handle mouse enter for clickable labels."""
        if self._clickable:
            # Add underline effect
            current_font = self._tk_widget['font']
            if isinstance(current_font, tuple):
                font_family, font_size, font_weight = current_font
                underlined_font = (font_family, font_size, font_weight, 'underline')
            else:
                underlined_font = current_font + ' underline'
            
            self._tk_widget.config(font=underlined_font)
            self.emit("mouse_enter")
    
    def _on_leave(self, event):
        """Handle mouse leave for clickable labels."""
        if self._clickable:
            # Remove underline effect
            font_family = self.get_style('font_family', 'Segoe UI')
            font_size = self.get_style('font_size', 12)
            font_weight = self.get_style('font_weight', 'normal')
            normal_font = (font_family, font_size, font_weight)
            
            self._tk_widget.config(font=normal_font)
            self.emit("mouse_leave")
    
    def set_html_text(self, html: str):
        """Set rich text content (simplified HTML support)."""
        # TODO: Implement basic HTML parsing for rich text
        # For now, just strip tags and set as plain text
        import re
        plain_text = re.sub(r'<[^>]+>', '', html)
        self.text = plain_text
    
    def set_markdown_text(self, markdown: str):
        """Set Markdown text content."""
        # TODO: Implement basic Markdown parsing
        # For now, just handle basic formatting
        import re
        
        # Handle bold text
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', markdown)
        text = re.sub(r'__(.*?)__', r'\1', text)
        
        # Handle italic text (just remove for now)
        text = re.sub(r'\*(.*?)\*', r'\1', text)
        text = re.sub(r'_(.*?)_', r'\1', text)
        
        self.text = text


# Convenience functions for common label types
def Heading1(text: str = "", **kwargs) -> Label:
    """Create a large heading label."""
    return Label(text=text, font_size=24, font_weight="bold", **kwargs)


def Heading2(text: str = "", **kwargs) -> Label:
    """Create a medium heading label."""
    return Label(text=text, font_size=20, font_weight="bold", **kwargs)


def Heading3(text: str = "", **kwargs) -> Label:
    """Create a small heading label."""
    return Label(text=text, font_size=16, font_weight="bold", **kwargs)


def Caption(text: str = "", **kwargs) -> Label:
    """Create a caption label."""
    return Label(text=text, font_size=10, text_color="#666666", **kwargs)


def Link(text: str = "", on_click: Optional[callable] = None, **kwargs) -> Label:
    """Create a clickable link label."""
    return Label(
        text=text, 
        clickable=True, 
        on_click=on_click, 
        text_color="#007ACC",
        **kwargs
    )
