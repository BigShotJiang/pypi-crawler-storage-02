"""Menu components - placeholder."""
from ..core.base import Widget
import tkinter as tk

class Menu(Widget):
    def _create_tk_widget(self, parent_tk): return tk.Menu(parent_tk)
    def _apply_style(self): pass

class MenuBar(Widget):
    def _create_tk_widget(self, parent_tk): return tk.Menu(parent_tk)
    def _apply_style(self): pass

class MenuItem(Widget):
    def _create_tk_widget(self, parent_tk): return tk.Menu(parent_tk)
    def _apply_style(self): pass
