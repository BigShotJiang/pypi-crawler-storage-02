"""Image component - placeholder for now."""

from ..core.base import Widget
import tkinter as tk

class Image(Widget):
    def __init__(self, src=None, **kwargs):
        super().__init__(**kwargs)
        self._src = src
    
    def _create_tk_widget(self, parent_tk):
        return tk.Label(parent_tk, text="[IMAGE]")
    
    def _apply_style(self):
        pass
