"""Slider component - placeholder."""
from ..core.base import Widget
import tkinter as tk

class Slider(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    def _create_tk_widget(self, parent_tk):
        return tk.Scale(parent_tk)
    
    def _apply_style(self):
        pass
