"""
Container components for VGI.
"""

import tkinter as tk
from typing import List, Optional, Dict, Any, Union
from ..core.base import Widget


class Container(Widget):
    """
    Base container widget for organizing child widgets.
    
    Features:
    - Flexible layout management
    - Padding and margins
    - Scrolling support
    - Background styling
    - Border and shadow effects
    
    Example:
        >>> container = vgi.Container(padding=16)
        >>> container.add(vgi.Label("Hello"))
        >>> container.add(vgi.Button("Click Me"))
    """
    
    def __init__(
        self,
        padding: Union[int, tuple] = 0,
        margin: Union[int, tuple] = 0,
        scrollable: bool = False,
        layout: str = "pack",  # pack, grid, place
        **kwargs
    ):
        super().__init__(**kwargs)
        
        # Container properties
        self._padding = self._normalize_spacing(padding)
        self._margin = self._normalize_spacing(margin)
        self._scrollable = scrollable
        self._layout = layout
        
        # Layout options for children
        self._child_layout_options: Dict[Widget, Dict] = {}
        
        # Scrolling
        self._canvas: Optional[tk.Canvas] = None
        self._scrollable_frame: Optional[tk.Frame] = None
        self._v_scrollbar: Optional[tk.Scrollbar] = None
        self._h_scrollbar: Optional[tk.Scrollbar] = None
        
        # Configure default styles
        self._configure_default_styles()
    
    def _normalize_spacing(self, spacing: Union[int, tuple]) -> tuple:
        """Normalize spacing to (top, right, bottom, left) format."""
        if isinstance(spacing, int):
            return (spacing, spacing, spacing, spacing)
        elif isinstance(spacing, tuple):
            if len(spacing) == 1:
                return (spacing[0], spacing[0], spacing[0], spacing[0])
            elif len(spacing) == 2:
                return (spacing[0], spacing[1], spacing[0], spacing[1])
            elif len(spacing) == 4:
                return spacing
        return (0, 0, 0, 0)
    
    @property
    def padding(self) -> tuple:
        """Container padding."""
        return self._padding
    
    @padding.setter
    def padding(self, value: Union[int, tuple]):
        self._padding = self._normalize_spacing(value)
        self._apply_layout()
    
    @property
    def scrollable(self) -> bool:
        """Whether the container is scrollable."""
        return self._scrollable
    
    def add(self, widget: Widget, **layout_options):
        """Add a child widget with layout options."""
        self.add_child(widget)
        self._child_layout_options[widget] = layout_options
        
        if self._tk_widget:
            self._add_widget_to_container(widget, layout_options)
    
    def remove(self, widget: Widget):
        """Remove a child widget."""
        if widget in self._children:
            # Remove from Tkinter
            if widget._tk_widget:
                widget._tk_widget.destroy()
                widget._tk_widget = None
            
            # Remove from container
            self.remove_child(widget)
            if widget in self._child_layout_options:
                del self._child_layout_options[widget]
    
    def clear(self):
        """Remove all child widgets."""
        for child in self._children.copy():
            self.remove(child)
    
    def get_layout_options(self, widget: Widget) -> Dict:
        """Get layout options for a child widget."""
        return self._child_layout_options.get(widget, {})
    
    def set_layout_options(self, widget: Widget, **options):
        """Set layout options for a child widget."""
        if widget in self._children:
            self._child_layout_options[widget] = options
            if widget._tk_widget:
                self._apply_widget_layout(widget, options)
    
    def _configure_default_styles(self):
        """Configure default container styles."""
        self._style.update({
            'background_color': 'transparent',
            'border_width': 0,
            'border_color': '#CCCCCC',
            'border_radius': 0,
        })
    
    def _create_tk_widget(self, parent_tk: tk.Widget) -> tk.Widget:
        """Create the underlying Tkinter widget."""
        if self._scrollable:
            return self._create_scrollable_container(parent_tk)
        else:
            return self._create_simple_container(parent_tk)
    
    def _create_simple_container(self, parent_tk: tk.Widget) -> tk.Widget:
        """Create a simple frame container."""
        frame = tk.Frame(parent_tk)
        return frame
    
    def _create_scrollable_container(self, parent_tk: tk.Widget) -> tk.Widget:
        """Create a scrollable container with canvas and scrollbars."""
        # Main frame
        main_frame = tk.Frame(parent_tk)
        
        # Canvas for scrolling
        self._canvas = tk.Canvas(main_frame)
        
        # Scrollbars
        self._v_scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=self._canvas.yview)
        self._h_scrollbar = tk.Scrollbar(main_frame, orient="horizontal", command=self._canvas.xview)
        
        # Configure canvas scrolling
        self._canvas.configure(
            yscrollcommand=self._v_scrollbar.set,
            xscrollcommand=self._h_scrollbar.set
        )
        
        # Scrollable frame inside canvas
        self._scrollable_frame = tk.Frame(self._canvas)
        self._canvas_window = self._canvas.create_window(
            (0, 0), window=self._scrollable_frame, anchor="nw"
        )
        
        # Bind events for scrolling
        self._scrollable_frame.bind('<Configure>', self._on_frame_configure)
        self._canvas.bind('<Configure>', self._on_canvas_configure)
        self._canvas.bind('<MouseWheel>', self._on_mousewheel)
        
        # Layout scrollbars and canvas
        self._canvas.grid(row=0, column=0, sticky="nsew")
        self._v_scrollbar.grid(row=0, column=1, sticky="ns")
        self._h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        # Configure grid weights
        main_frame.grid_rowconfigure(0, weight=1)
        main_frame.grid_columnconfigure(0, weight=1)
        
        return main_frame
    
    def _apply_style(self):
        """Apply computed styles to the container."""
        if not self._tk_widget:
            return
        
        # Get the actual frame to style
        frame = self._scrollable_frame if self._scrollable else self._tk_widget
        
        # Get computed styles
        bg_color = self.get_style('background_color', 'transparent')
        border_width = self.get_style('border_width', 0)
        border_color = self.get_style('border_color', '#CCCCCC')
        
        # Handle background color
        if bg_color == 'transparent':
            try:
                bg_color = frame.master['bg']
            except:
                bg_color = '#F0F0F0'
        
        config = {
            'bg': bg_color,
            'relief': 'solid' if border_width > 0 else 'flat',
            'borderwidth': border_width,
            'highlightbackground': border_color,
            'highlightcolor': border_color,
            'highlightthickness': border_width,
        }
        
        frame.config(**config)
        
        # Also configure canvas if scrollable
        if self._scrollable and self._canvas:
            self._canvas.config(bg=bg_color)
    
    def _add_widget_to_container(self, widget: Widget, layout_options: Dict):
        """Add a widget to the container with layout options."""
        # Get the parent container
        parent_container = self._scrollable_frame if self._scrollable else self._tk_widget
        
        # Create the widget's Tkinter component
        widget._tk_widget = widget._create_tk_widget(parent_container)
        widget._apply_style()
        
        # Apply layout
        self._apply_widget_layout(widget, layout_options)
    
    def _apply_widget_layout(self, widget: Widget, layout_options: Dict):
        """Apply layout to a widget."""
        if not widget._tk_widget:
            return
        
        # Apply padding to layout options
        padx = self._padding[1] + self._padding[3]  # right + left
        pady = self._padding[0] + self._padding[2]  # top + bottom
        
        if self._layout == "pack":
            pack_options = {
                'padx': padx,
                'pady': pady,
                'fill': layout_options.get('fill', 'none'),
                'expand': layout_options.get('expand', False),
                'side': layout_options.get('side', 'top'),
                'anchor': layout_options.get('anchor', 'center'),
            }
            widget._tk_widget.pack(**pack_options)
            
        elif self._layout == "grid":
            grid_options = {
                'padx': padx,
                'pady': pady,
                'row': layout_options.get('row', 0),
                'column': layout_options.get('column', 0),
                'rowspan': layout_options.get('rowspan', 1),
                'columnspan': layout_options.get('columnspan', 1),
                'sticky': layout_options.get('sticky', ''),
            }
            widget._tk_widget.grid(**grid_options)
            
        elif self._layout == "place":
            place_options = {
                'x': layout_options.get('x', 0) + self._padding[3],  # left padding
                'y': layout_options.get('y', 0) + self._padding[0],  # top padding
                'width': layout_options.get('width'),
                'height': layout_options.get('height'),
                'anchor': layout_options.get('anchor', 'nw'),
                'relx': layout_options.get('relx'),
                'rely': layout_options.get('rely'),
                'relwidth': layout_options.get('relwidth'),
                'relheight': layout_options.get('relheight'),
            }
            # Remove None values
            place_options = {k: v for k, v in place_options.items() if v is not None}
            widget._tk_widget.place(**place_options)
    
    def _apply_layout(self):
        """Apply layout to all children."""
        for child in self._children:
            if child._tk_widget:
                layout_options = self._child_layout_options.get(child, {})
                self._apply_widget_layout(child, layout_options)
    
    def _on_frame_configure(self, event):
        """Handle scrollable frame configure event."""
        if self._canvas:
            self._canvas.configure(scrollregion=self._canvas.bbox("all"))
    
    def _on_canvas_configure(self, event):
        """Handle canvas configure event."""
        if self._canvas and self._scrollable_frame:
            # Update the scrollable frame width to match canvas width
            canvas_width = event.width
            self._canvas.itemconfig(self._canvas_window, width=canvas_width)
    
    def _on_mousewheel(self, event):
        """Handle mouse wheel scrolling."""
        if self._canvas:
            self._canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
    
    def _on_child_added(self, child: Widget):
        """Handle child added event."""
        super()._on_child_added(child)
        if self._tk_widget:
            layout_options = self._child_layout_options.get(child, {})
            self._add_widget_to_container(child, layout_options)
    
    def _on_child_removed(self, child: Widget):
        """Handle child removed event."""
        super()._on_child_removed(child)
        if child in self._child_layout_options:
            del self._child_layout_options[child]


class Panel(Container):
    """
    A styled panel container with border and background.
    
    Provides a visual grouping of widgets with optional title and styling.
    """
    
    def __init__(
        self,
        title: Optional[str] = None,
        border: bool = True,
        **kwargs
    ):
        super().__init__(**kwargs)
        
        self._title = title
        self._border = border
        
        # Override default styles for panel
        if border:
            self._style.update({
                'background_color': '#FFFFFF',
                'border_width': 1,
                'border_color': '#CCCCCC',
                'border_radius': 4,
            })
        
        self._padding = self._normalize_spacing(kwargs.get('padding', 16))
    
    @property
    def title(self) -> Optional[str]:
        """Panel title."""
        return self._title
    
    @title.setter
    def title(self, value: Optional[str]):
        self._title = value
        # TODO: Implement title display


class Frame(Container):
    """
    A simple frame container without styling.
    
    Provides basic layout functionality without visual styling.
    """
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Keep frame transparent and borderless
        self._style.update({
            'background_color': 'transparent',
            'border_width': 0,
        })
