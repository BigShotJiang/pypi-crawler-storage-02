"""Tree components - placeholder."""
from ..core.base import Widget
import tkinter as tk
import tkinter.ttk as ttk

class TreeView(Widget):
    def _create_tk_widget(self, parent_tk): return ttk.Treeview(parent_tk)
    def _apply_style(self): pass

class TreeNode(Widget):
    def _create_tk_widget(self, parent_tk): return tk.Frame(parent_tk)
    def _apply_style(self): pass
