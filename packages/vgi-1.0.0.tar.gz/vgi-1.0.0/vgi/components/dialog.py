"""Dialog components - placeholder."""
from ..core.base import Widget
import tkinter as tk
from tkinter import messagebox, filedialog

class Dialog(Widget):
    def _create_tk_widget(self, parent_tk): return tk.Toplevel(parent_tk)
    def _apply_style(self): pass

class MessageBox:
    @staticmethod
    def show(message, title="", type="info"):
        if type == "info": messagebox.showinfo(title, message)
        elif type == "warning": messagebox.showwarning(title, message)
        elif type == "error": messagebox.showerror(title, message)

class FileDialog:
    @staticmethod
    def open_file(): return filedialog.askopenfilename()
    @staticmethod
    def save_file(): return filedialog.asksaveasfilename()
