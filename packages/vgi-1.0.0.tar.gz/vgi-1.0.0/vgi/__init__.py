"""
VGI - Professional Modern GUI Library for Python

A comprehensive, modern GUI framework that provides:
- Beautiful, customizable components
- Advanced styling and theming
- Smooth animations and transitions
- Professional layouts and responsive design
- Easy-to-use API for rapid development

Example:
    >>> import vgi
    >>> app = vgi.Application()
    >>> window = vgi.Window(title="My App", size=(800, 600))
    >>> button = vgi.Button(text="Click Me", on_click=lambda: print("Clicked!"))
    >>> window.add(button)
    >>> app.run()
"""

__version__ = "1.0.0"
__author__ = "VGI Team"
__email__ = "contact@vgi.dev"
__license__ = "MIT"

# Core imports
from .core.application import Application
from .core.window import Window
from .core.base import Widget

# Component imports
from .components.button import Button
from .components.input import Input, TextArea
from .components.label import Label
from .components.container import Container, Panel, Frame
from .components.layout import VBox, HBox, Grid, Stack
from .components.image import Image
from .components.progress import ProgressBar, Spinner
from .components.slider import Slider
from .components.checkbox import Checkbox
from .components.radio import RadioButton
from .components.dropdown import Dropdown, ComboBox
from .components.menu import Menu, MenuBar, MenuItem
from .components.dialog import Dialog, MessageBox, FileDialog
from .components.tab import TabView, Tab
from .components.tree import TreeView, TreeNode
from .components.table import Table, DataGrid
from .components.chart import Chart, LineChart, BarChart, PieChart
from .components.timeline import Timeline
from .components.calendar import Calendar
from .components.notification import Notification, Toast

# Styling imports
from .styling.theme import Theme, ThemeManager
from .styling.color import Color, ColorPalette
from .styling.animation import Animation, Transition
from .styling.effects import Shadow, Gradient, Border

# Utility imports
from .utils.events import EventHandler, Event
from .utils.validation import Validator
from .utils.geometry import Point, Size, Rect
from .utils.resources import ResourceManager

# Quick start aliases
App = Application
Win = Window

__all__ = [
    # Core
    "Application", "App", "Window", "Win", "Widget",
    
    # Components
    "Button", "Input", "TextArea", "Label", "Container", "Panel", "Frame",
    "VBox", "HBox", "Grid", "Stack", "Image", "ProgressBar", "Spinner",
    "Slider", "Checkbox", "RadioButton", "Dropdown", "ComboBox",
    "Menu", "MenuBar", "MenuItem", "Dialog", "MessageBox", "FileDialog",
    "TabView", "Tab", "TreeView", "TreeNode", "Table", "DataGrid",
    "Chart", "LineChart", "BarChart", "PieChart", "Timeline", "Calendar",
    "Notification", "Toast",
    
    # Styling
    "Theme", "ThemeManager", "Color", "ColorPalette", "Animation", "Transition",
    "Shadow", "Gradient", "Border",
    
    # Utilities
    "EventHandler", "Event", "Validator", "Point", "Size", "Rect", "ResourceManager",
]
