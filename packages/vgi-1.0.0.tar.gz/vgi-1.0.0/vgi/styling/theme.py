"""
Theme management system for VGI.
"""

from typing import Dict, Any, Optional, List, Union
import json
from pathlib import Path

from .color import Color, ColorPalette


class Theme:
    """
    Represents a complete theme for VGI applications.
    
    Contains styling information for all widgets, including colors, fonts,
    spacing, and visual effects.
    """
    
    def __init__(self, name: str = "Default Theme"):
        self.name = name
        self.palette: Optional[ColorPalette] = None
        self.widget_styles: Dict[str, Dict[str, Any]] = {}
        self.global_styles: Dict[str, Any] = {}
        self.state_styles: Dict[str, Dict[str, Dict[str, Any]]] = {}
        
        # Initialize with default styles
        self._init_default_styles()
    
    def _init_default_styles(self):
        """Initialize default theme styles."""
        # Global styles
        self.global_styles = {
            'font_family': 'Segoe UI',
            'font_size': 12,
            'border_radius': 4,
            'animation_duration': 200,
            'shadow_enabled': True,
        }
        
        # Default widget styles
        self.widget_styles = {
            'button': {
                'background_color': '#007ACC',
                'text_color': '#FFFFFF',
                'border_width': 0,
                'border_radius': 4,
                'padding': (8, 16),
                'font_weight': 'normal',
                'cursor': 'hand2',
            },
            'input': {
                'background_color': '#FFFFFF',
                'text_color': '#000000',
                'border_color': '#CCCCCC',
                'border_width': 1,
                'border_radius': 4,
                'padding': (8, 12),
                'focus_border_color': '#007ACC',
            },
            'label': {
                'background_color': 'transparent',
                'text_color': '#000000',
                'font_weight': 'normal',
            },
            'window': {
                'background_color': '#F0F0F0',
                'border_color': '#CCCCCC',
            },
            'container': {
                'background_color': 'transparent',
                'border_width': 0,
            },
        }
        
        # State-specific styles
        self.state_styles = {
            'button': {
                'hover': {
                    'background_color': '#005A9E',
                },
                'active': {
                    'background_color': '#004578',
                },
                'disabled': {
                    'background_color': '#CCCCCC',
                    'text_color': '#666666',
                    'cursor': 'default',
                },
            },
            'input': {
                'focus': {
                    'border_color': '#007ACC',
                    'border_width': 2,
                },
                'error': {
                    'border_color': '#E74C3C',
                    'border_width': 2,
                },
                'disabled': {
                    'background_color': '#F5F5F5',
                    'text_color': '#999999',
                },
            },
        }
    
    def set_palette(self, palette: ColorPalette):
        """Set the color palette for this theme."""
        self.palette = palette
        self._apply_palette_to_styles()
    
    def _apply_palette_to_styles(self):
        """Apply color palette to widget styles."""
        if not self.palette:
            return
        
        # Update styles based on palette
        primary = self.palette.get_primary()
        if primary:
            self.widget_styles['button']['background_color'] = primary.to_hex()
            
            # Update hover states
            if 'button' not in self.state_styles:
                self.state_styles['button'] = {}
            if 'hover' not in self.state_styles['button']:
                self.state_styles['button']['hover'] = {}
            
            self.state_styles['button']['hover']['background_color'] = primary.darken(0.1).to_hex()
            self.state_styles['button']['active']['background_color'] = primary.darken(0.2).to_hex()
    
    def get_widget_styles(self, widget_type: str) -> Dict[str, Any]:
        """Get styles for a specific widget type."""
        return self.widget_styles.get(widget_type, {}).copy()
    
    def get_state_styles(self, widget_type: str, state: str) -> Dict[str, Any]:
        """Get state-specific styles for a widget."""
        return self.state_styles.get(widget_type, {}).get(state, {}).copy()
    
    def set_widget_style(self, widget_type: str, property_name: str, value: Any):
        """Set a style property for a widget type."""
        if widget_type not in self.widget_styles:
            self.widget_styles[widget_type] = {}
        self.widget_styles[widget_type][property_name] = value
    
    def set_state_style(self, widget_type: str, state: str, property_name: str, value: Any):
        """Set a state-specific style property."""
        if widget_type not in self.state_styles:
            self.state_styles[widget_type] = {}
        if state not in self.state_styles[widget_type]:
            self.state_styles[widget_type][state] = {}
        self.state_styles[widget_type][state][property_name] = value
    
    def get_global_style(self, property_name: str, default: Any = None) -> Any:
        """Get a global style property."""
        return self.global_styles.get(property_name, default)
    
    def set_global_style(self, property_name: str, value: Any):
        """Set a global style property."""
        self.global_styles[property_name] = value
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert theme to dictionary."""
        return {
            'name': self.name,
            'palette': self.palette.to_dict() if self.palette else None,
            'widget_styles': self.widget_styles,
            'global_styles': self.global_styles,
            'state_styles': self.state_styles,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Theme':
        """Create theme from dictionary."""
        theme = cls(data.get('name', 'Loaded Theme'))
        
        if data.get('palette'):
            theme.palette = ColorPalette.from_dict(data['palette'])
        
        theme.widget_styles = data.get('widget_styles', {})
        theme.global_styles = data.get('global_styles', {})
        theme.state_styles = data.get('state_styles', {})
        
        return theme
    
    def save(self, filepath: Path):
        """Save theme to file."""
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    @classmethod
    def load(cls, filepath: Path) -> 'Theme':
        """Load theme from file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return cls.from_dict(data)


class ThemeManager:
    """
    Manages multiple themes and provides theme switching functionality.
    """
    
    def __init__(self):
        self.themes: Dict[str, Theme] = {}
        self.current_theme: Optional[Theme] = None
        
        # Load built-in themes
        self._load_builtin_themes()
    
    def _load_builtin_themes(self):
        """Load built-in themes."""
        # Modern Light Theme
        modern_light = Theme("Modern Light")
        modern_light.set_palette(ColorPalette.create_material_palette())
        self.add_theme(modern_light)
        
        # Modern Dark Theme
        modern_dark = Theme("Modern Dark")
        modern_dark.set_palette(ColorPalette.create_dark_palette())
        
        # Dark theme specific styles
        modern_dark.widget_styles.update({
            'window': {
                'background_color': '#121212',
            },
            'label': {
                'background_color': 'transparent',
                'text_color': '#FFFFFF',
            },
            'input': {
                'background_color': '#1E1E1E',
                'text_color': '#FFFFFF',
                'border_color': '#333333',
                'border_width': 1,
                'border_radius': 4,
                'padding': (8, 12),
                'focus_border_color': '#BB86FC',
            },
            'container': {
                'background_color': '#1E1E1E',
            },
        })
        
        self.add_theme(modern_dark)
        
        # Professional Theme
        professional = Theme("Professional")
        professional_palette = ColorPalette("Professional")
        professional_palette.add_color("primary", "#2C3E50", True)
        professional_palette.add_color("secondary", "#3498DB")
        professional_palette.add_color("accent", "#E74C3C")
        professional_palette.add_color("background", "#ECF0F1")
        professional_palette.add_color("surface", "#FFFFFF")
        
        professional.set_palette(professional_palette)
        professional.global_styles.update({
            'font_family': 'Calibri',
            'border_radius': 2,
            'shadow_enabled': False,
        })
        
        self.add_theme(professional)
        
        # Set default theme
        self.current_theme = modern_light
    
    def add_theme(self, theme: Theme):
        """Add a theme to the manager."""
        self.themes[theme.name] = theme
    
    def get_theme(self, name: str) -> Optional[Theme]:
        """Get a theme by name."""
        return self.themes.get(name)
    
    def get_theme_names(self) -> List[str]:
        """Get list of available theme names."""
        return list(self.themes.keys())
    
    def set_current_theme(self, name: str) -> bool:
        """Set the current theme."""
        theme = self.get_theme(name)
        if theme:
            self.current_theme = theme
            return True
        return False
    
    def get_current_theme(self) -> Optional[Theme]:
        """Get the current theme."""
        return self.current_theme
    
    def create_custom_theme(self, name: str, base_theme: str = "Modern Light") -> Theme:
        """Create a custom theme based on an existing theme."""
        base = self.get_theme(base_theme)
        if not base:
            base = Theme()
        
        # Deep copy the base theme
        custom_theme = Theme(name)
        custom_theme.widget_styles = base.widget_styles.copy()
        custom_theme.global_styles = base.global_styles.copy()
        custom_theme.state_styles = base.state_styles.copy()
        
        if base.palette:
            custom_theme.palette = base.palette
        
        self.add_theme(custom_theme)
        return custom_theme
    
    def load_theme_from_file(self, filepath: Path):
        """Load a theme from file."""
        theme = Theme.load(filepath)
        self.add_theme(theme)
        return theme
    
    def export_theme(self, theme_name: str, filepath: Path) -> bool:
        """Export a theme to file."""
        theme = self.get_theme(theme_name)
        if theme:
            theme.save(filepath)
            return True
        return False
    
    def apply_theme_to_widget(self, widget, theme: Optional[Theme] = None):
        """Apply theme styles to a widget."""
        if not theme:
            theme = self.current_theme
        
        if not theme:
            return
        
        widget_type = widget.__class__.__name__.lower()
        styles = theme.get_widget_styles(widget_type)
        
        # Apply styles to widget
        for property_name, value in styles.items():
            if hasattr(widget, f'set_{property_name}'):
                getattr(widget, f'set_{property_name}')(value)
            elif hasattr(widget, property_name):
                setattr(widget, property_name, value)
    
    def get_color_schemes(self) -> Dict[str, Dict[str, str]]:
        """Get color schemes from all themes."""
        schemes = {}
        for name, theme in self.themes.items():
            if theme.palette:
                schemes[name] = theme.palette.to_dict()
        return schemes
