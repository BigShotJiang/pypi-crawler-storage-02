"""Styling system for VGI."""

from .theme import Theme, ThemeManager
from .color import Color, ColorPalette
from .animation import Animation, Transition
from .effects import Shadow, Gradient, Border

__all__ = ["Theme", "ThemeManager", "Color", "ColorPalette", "Animation", "Transition", "Shadow", "Gradient", "Border"]
