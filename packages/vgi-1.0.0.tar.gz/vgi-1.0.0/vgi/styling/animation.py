"""
Animation and transition system for VGI.
"""

import time
import threading
from typing import Dict, Any, Callable, Optional, Union
from abc import ABC, abstractmethod
import math


class EasingFunction(ABC):
    """Base class for easing functions."""
    
    @abstractmethod
    def ease(self, t: float) -> float:
        """Apply easing to time value (0.0 to 1.0)."""
        pass


class LinearEasing(EasingFunction):
    """Linear easing (no easing)."""
    
    def ease(self, t: float) -> float:
        return t


class EaseInQuad(EasingFunction):
    """Quadratic ease-in."""
    
    def ease(self, t: float) -> float:
        return t * t


class EaseOutQuad(EasingFunction):
    """Quadratic ease-out."""
    
    def ease(self, t: float) -> float:
        return t * (2 - t)


class EaseInOutQuad(EasingFunction):
    """Quadratic ease-in-out."""
    
    def ease(self, t: float) -> float:
        if t < 0.5:
            return 2 * t * t
        return -1 + (4 - 2 * t) * t


class EaseInCubic(EasingFunction):
    """Cubic ease-in."""
    
    def ease(self, t: float) -> float:
        return t * t * t


class EaseOutCubic(EasingFunction):
    """Cubic ease-out."""
    
    def ease(self, t: float) -> float:
        t -= 1
        return t * t * t + 1


class EaseInOutCubic(EasingFunction):
    """Cubic ease-in-out."""
    
    def ease(self, t: float) -> float:
        if t < 0.5:
            return 4 * t * t * t
        t = 2 * t - 2
        return 1 + t * t * t / 2


class EaseInElastic(EasingFunction):
    """Elastic ease-in."""
    
    def ease(self, t: float) -> float:
        if t == 0 or t == 1:
            return t
        return -math.pow(2, 10 * (t - 1)) * math.sin((t - 1.1) * 5 * math.pi)


class EaseOutElastic(EasingFunction):
    """Elastic ease-out."""
    
    def ease(self, t: float) -> float:
        if t == 0 or t == 1:
            return t
        return math.pow(2, -10 * t) * math.sin((t - 0.1) * 5 * math.pi) + 1


class EaseInBounce(EasingFunction):
    """Bounce ease-in."""
    
    def ease(self, t: float) -> float:
        return 1 - EaseOutBounce().ease(1 - t)


class EaseOutBounce(EasingFunction):
    """Bounce ease-out."""
    
    def ease(self, t: float) -> float:
        if t < 1 / 2.75:
            return 7.5625 * t * t
        elif t < 2 / 2.75:
            t -= 1.5 / 2.75
            return 7.5625 * t * t + 0.75
        elif t < 2.5 / 2.75:
            t -= 2.25 / 2.75
            return 7.5625 * t * t + 0.9375
        else:
            t -= 2.625 / 2.75
            return 7.5625 * t * t + 0.984375


# Easing function registry
EASING_FUNCTIONS = {
    'linear': LinearEasing(),
    'ease_in_quad': EaseInQuad(),
    'ease_out_quad': EaseOutQuad(),
    'ease_in_out_quad': EaseInOutQuad(),
    'ease_in_cubic': EaseInCubic(),
    'ease_out_cubic': EaseOutCubic(),
    'ease_in_out_cubic': EaseInOutCubic(),
    'ease_in_elastic': EaseInElastic(),
    'ease_out_elastic': EaseOutElastic(),
    'ease_in_bounce': EaseInBounce(),
    'ease_out_bounce': EaseOutBounce(),
}


class Animation:
    """
    Represents an animation that can modify widget properties over time.
    """
    
    def __init__(
        self,
        target: Any,
        duration: float = 1.0,
        easing: Union[str, EasingFunction] = 'ease_in_out_quad',
        delay: float = 0.0,
        repeat: int = 1,
        reverse: bool = False,
        on_update: Optional[Callable] = None,
        on_complete: Optional[Callable] = None,
        **properties
    ):
        self.target = target
        self.duration = duration
        self.delay = delay
        self.repeat = repeat
        self.reverse = reverse
        self.properties = properties
        self.on_update = on_update
        self.on_complete = on_complete
        
        # Set easing function
        if isinstance(easing, str):
            self.easing = EASING_FUNCTIONS.get(easing, LinearEasing())
        else:
            self.easing = easing
        
        # Animation state
        self.start_time = None
        self.is_running = False
        self.is_paused = False
        self.current_repeat = 0
        self.is_reversed = False
        
        # Store initial values
        self.initial_values = {}
        self.target_values = {}
        
        # Animation thread
        self.thread = None
        self.stop_flag = threading.Event()
    
    def _prepare_animation(self):
        """Prepare animation by getting initial values."""
        for prop_name, target_value in self.properties.items():
            # Get current value from target
            if hasattr(self.target, prop_name):
                current_value = getattr(self.target, prop_name)
                self.initial_values[prop_name] = current_value
                self.target_values[prop_name] = target_value
            elif hasattr(self.target, f'get_{prop_name}'):
                current_value = getattr(self.target, f'get_{prop_name}')()
                self.initial_values[prop_name] = current_value
                self.target_values[prop_name] = target_value
    
    def _interpolate_value(self, start_value, end_value, progress):
        """Interpolate between start and end values."""
        if isinstance(start_value, (int, float)) and isinstance(end_value, (int, float)):
            return start_value + (end_value - start_value) * progress
        elif isinstance(start_value, tuple) and isinstance(end_value, tuple):
            # Handle tuples (e.g., positions, colors)
            if len(start_value) == len(end_value):
                return tuple(
                    start_value[i] + (end_value[i] - start_value[i]) * progress
                    for i in range(len(start_value))
                )
        # For other types, just switch at 50% progress
        return end_value if progress > 0.5 else start_value
    
    def _apply_values(self, values):
        """Apply interpolated values to target."""
        for prop_name, value in values.items():
            try:
                if hasattr(self.target, f'set_{prop_name}'):
                    getattr(self.target, f'set_{prop_name}')(value)
                elif hasattr(self.target, prop_name):
                    setattr(self.target, prop_name, value)
                elif hasattr(self.target, '_tk_widget'):
                    # Try to apply to underlying Tkinter widget
                    tk_widget = self.target._tk_widget
                    if tk_widget and hasattr(tk_widget, 'configure'):
                        tk_widget.configure(**{prop_name: value})
            except Exception as e:
                print(f"Error applying animation value {prop_name}={value}: {e}")
    
    def _animation_loop(self):
        """Main animation loop."""
        while not self.stop_flag.is_set() and self.current_repeat < self.repeat:
            if self.delay > 0:
                self.stop_flag.wait(self.delay)
                if self.stop_flag.is_set():
                    break
            
            self.start_time = time.time()
            
            while not self.stop_flag.is_set():
                if self.is_paused:
                    time.sleep(0.016)  # ~60 FPS
                    continue
                
                current_time = time.time()
                elapsed = current_time - self.start_time
                
                if elapsed >= self.duration:
                    # Animation complete for this cycle
                    progress = 1.0
                else:
                    progress = elapsed / self.duration
                
                # Apply easing
                eased_progress = self.easing.ease(progress)
                
                # Handle reverse
                if self.is_reversed:
                    eased_progress = 1.0 - eased_progress
                
                # Interpolate values
                current_values = {}
                for prop_name in self.properties:
                    start_val = self.initial_values[prop_name]
                    end_val = self.target_values[prop_name]
                    
                    if self.is_reversed:
                        start_val, end_val = end_val, start_val
                    
                    current_values[prop_name] = self._interpolate_value(
                        start_val, end_val, eased_progress
                    )
                
                # Apply values to target
                self._apply_values(current_values)
                
                # Call update callback
                if self.on_update:
                    try:
                        self.on_update(self, progress)
                    except Exception as e:
                        print(f"Error in animation update callback: {e}")
                
                if progress >= 1.0:
                    break
                
                time.sleep(0.016)  # ~60 FPS
            
            self.current_repeat += 1
            
            # Handle reverse option
            if self.reverse and self.current_repeat < self.repeat:
                self.is_reversed = not self.is_reversed
        
        # Animation complete
        self.is_running = False
        
        # Call completion callback
        if self.on_complete:
            try:
                self.on_complete(self)
            except Exception as e:
                print(f"Error in animation complete callback: {e}")
    
    def start(self):
        """Start the animation."""
        if self.is_running:
            return
        
        self._prepare_animation()
        self.is_running = True
        self.stop_flag.clear()
        
        # Start animation thread
        self.thread = threading.Thread(target=self._animation_loop, daemon=True)
        self.thread.start()
    
    def pause(self):
        """Pause the animation."""
        self.is_paused = True
    
    def resume(self):
        """Resume the animation."""
        self.is_paused = False
    
    def stop(self):
        """Stop the animation."""
        self.stop_flag.set()
        self.is_running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)
    
    def reset(self):
        """Reset the animation to initial state."""
        self.stop()
        self.current_repeat = 0
        self.is_reversed = False
        self.is_paused = False


class Transition:
    """
    Convenience class for common UI transitions.
    """
    
    @staticmethod
    def fade_in(widget, duration: float = 0.3) -> Animation:
        """Fade in animation."""
        return Animation(
            widget,
            duration=duration,
            opacity=1.0,
            easing='ease_out_quad'
        )
    
    @staticmethod
    def fade_out(widget, duration: float = 0.3) -> Animation:
        """Fade out animation."""
        return Animation(
            widget,
            duration=duration,
            opacity=0.0,
            easing='ease_in_quad'
        )
    
    @staticmethod
    def slide_in_left(widget, duration: float = 0.4) -> Animation:
        """Slide in from left animation."""
        initial_x = getattr(widget, 'x', 0) - getattr(widget, 'width', 100)
        target_x = getattr(widget, 'x', 0)
        
        # Set initial position off-screen
        if hasattr(widget, 'set_x'):
            widget.set_x(initial_x)
        
        return Animation(
            widget,
            duration=duration,
            x=target_x,
            easing='ease_out_cubic'
        )
    
    @staticmethod
    def slide_in_right(widget, duration: float = 0.4) -> Animation:
        """Slide in from right animation."""
        initial_x = getattr(widget, 'x', 0) + getattr(widget, 'width', 100)
        target_x = getattr(widget, 'x', 0)
        
        # Set initial position off-screen
        if hasattr(widget, 'set_x'):
            widget.set_x(initial_x)
        
        return Animation(
            widget,
            duration=duration,
            x=target_x,
            easing='ease_out_cubic'
        )
    
    @staticmethod
    def slide_in_up(widget, duration: float = 0.4) -> Animation:
        """Slide in from top animation."""
        initial_y = getattr(widget, 'y', 0) - getattr(widget, 'height', 50)
        target_y = getattr(widget, 'y', 0)
        
        # Set initial position off-screen
        if hasattr(widget, 'set_y'):
            widget.set_y(initial_y)
        
        return Animation(
            widget,
            duration=duration,
            y=target_y,
            easing='ease_out_cubic'
        )
    
    @staticmethod
    def slide_in_down(widget, duration: float = 0.4) -> Animation:
        """Slide in from bottom animation."""
        initial_y = getattr(widget, 'y', 0) + getattr(widget, 'height', 50)
        target_y = getattr(widget, 'y', 0)
        
        # Set initial position off-screen
        if hasattr(widget, 'set_y'):
            widget.set_y(initial_y)
        
        return Animation(
            widget,
            duration=duration,
            y=target_y,
            easing='ease_out_cubic'
        )
    
    @staticmethod
    def scale_in(widget, duration: float = 0.3) -> Animation:
        """Scale in animation."""
        return Animation(
            widget,
            duration=duration,
            scale_x=1.0,
            scale_y=1.0,
            easing='ease_out_back'
        )
    
    @staticmethod
    def scale_out(widget, duration: float = 0.3) -> Animation:
        """Scale out animation."""
        return Animation(
            widget,
            duration=duration,
            scale_x=0.0,
            scale_y=0.0,
            easing='ease_in_back'
        )
    
    @staticmethod
    def bounce_in(widget, duration: float = 0.6) -> Animation:
        """Bounce in animation."""
        return Animation(
            widget,
            duration=duration,
            scale_x=1.0,
            scale_y=1.0,
            easing='ease_out_bounce'
        )
    
    @staticmethod
    def pulse(widget, duration: float = 0.5, scale: float = 1.1) -> Animation:
        """Pulse animation."""
        return Animation(
            widget,
            duration=duration,
            scale_x=scale,
            scale_y=scale,
            repeat=2,
            reverse=True,
            easing='ease_in_out_quad'
        )
    
    @staticmethod
    def shake(widget, duration: float = 0.5, intensity: int = 10) -> Animation:
        """Shake animation."""
        original_x = getattr(widget, 'x', 0)
        
        return Animation(
            widget,
            duration=duration,
            x=original_x + intensity,
            repeat=4,
            reverse=True,
            easing='linear'
        )


class AnimationManager:
    """
    Manages multiple animations and provides batch operations.
    """
    
    def __init__(self):
        self.animations: Dict[str, Animation] = {}
        self.animation_groups: Dict[str, list] = {}
    
    def add_animation(self, name: str, animation: Animation):
        """Add an animation with a name."""
        self.animations[name] = animation
    
    def remove_animation(self, name: str):
        """Remove an animation."""
        if name in self.animations:
            self.animations[name].stop()
            del self.animations[name]
    
    def start_animation(self, name: str):
        """Start a named animation."""
        if name in self.animations:
            self.animations[name].start()
    
    def stop_animation(self, name: str):
        """Stop a named animation."""
        if name in self.animations:
            self.animations[name].stop()
    
    def pause_animation(self, name: str):
        """Pause a named animation."""
        if name in self.animations:
            self.animations[name].pause()
    
    def resume_animation(self, name: str):
        """Resume a named animation."""
        if name in self.animations:
            self.animations[name].resume()
    
    def create_group(self, group_name: str, animation_names: list):
        """Create a group of animations."""
        self.animation_groups[group_name] = animation_names
    
    def start_group(self, group_name: str):
        """Start all animations in a group."""
        if group_name in self.animation_groups:
            for name in self.animation_groups[group_name]:
                self.start_animation(name)
    
    def stop_group(self, group_name: str):
        """Stop all animations in a group."""
        if group_name in self.animation_groups:
            for name in self.animation_groups[group_name]:
                self.stop_animation(name)
    
    def stop_all(self):
        """Stop all animations."""
        for animation in self.animations.values():
            animation.stop()
    
    def get_running_animations(self) -> list:
        """Get list of currently running animation names."""
        return [name for name, anim in self.animations.items() if anim.is_running]
