"""
Visual effects and styling utilities for VGI.
"""

from typing import Union, Tuple, Optional, List
from dataclasses import dataclass

from .color import Color


@dataclass
class Shadow:
    """
    Represents a drop shadow effect.
    """
    
    offset_x: float = 0
    offset_y: float = 2
    blur_radius: float = 4
    spread_radius: float = 0
    color: Union[Color, str] = "rgba(0, 0, 0, 0.25)"
    inset: bool = False
    
    def __post_init__(self):
        if isinstance(self.color, str):
            self.color = Color.parse(self.color)
    
    def to_css(self) -> str:
        """Convert to CSS shadow string."""
        inset_str = "inset " if self.inset else ""
        return (f"{inset_str}{self.offset_x}px {self.offset_y}px "
                f"{self.blur_radius}px {self.spread_radius}px {self.color}")
    
    @classmethod
    def subtle(cls, color: Union[Color, str] = "rgba(0, 0, 0, 0.1)") -> 'Shadow':
        """Create a subtle shadow."""
        return cls(offset_y=1, blur_radius=2, color=color)
    
    @classmethod
    def medium(cls, color: Union[Color, str] = "rgba(0, 0, 0, 0.15)") -> 'Shadow':
        """Create a medium shadow."""
        return cls(offset_y=2, blur_radius=4, color=color)
    
    @classmethod
    def strong(cls, color: Union[Color, str] = "rgba(0, 0, 0, 0.25)") -> 'Shadow':
        """Create a strong shadow."""
        return cls(offset_y=4, blur_radius=8, color=color)
    
    @classmethod
    def glow(cls, color: Union[Color, str] = "#007ACC", intensity: float = 0.5) -> 'Shadow':
        """Create a glow effect."""
        if isinstance(color, str):
            color = Color.parse(color)
        glow_color = color.with_alpha(intensity)
        return cls(offset_x=0, offset_y=0, blur_radius=8, color=glow_color)


@dataclass
class Gradient:
    """
    Represents a gradient effect.
    """
    
    type: str = "linear"  # linear, radial, conic
    direction: Union[str, float] = "to bottom"  # for linear: angle or direction
    colors: List[Tuple[Union[Color, str], float]] = None  # (color, position)
    
    def __post_init__(self):
        if self.colors is None:
            self.colors = [
                (Color.parse("#ffffff"), 0.0),
                (Color.parse("#000000"), 1.0)
            ]
        
        # Convert string colors to Color objects
        processed_colors = []
        for color, position in self.colors:
            if isinstance(color, str):
                color = Color.parse(color)
            processed_colors.append((color, position))
        self.colors = processed_colors
    
    def add_stop(self, color: Union[Color, str], position: float):
        """Add a color stop to the gradient."""
        if isinstance(color, str):
            color = Color.parse(color)
        self.colors.append((color, position))
        # Sort by position
        self.colors.sort(key=lambda x: x[1])
    
    def to_css(self) -> str:
        """Convert to CSS gradient string."""
        if self.type == "linear":
            direction_str = self.direction if isinstance(self.direction, str) else f"{self.direction}deg"
            stops = ", ".join([f"{color} {pos*100}%" for color, pos in self.colors])
            return f"linear-gradient({direction_str}, {stops})"
        
        elif self.type == "radial":
            stops = ", ".join([f"{color} {pos*100}%" for color, pos in self.colors])
            return f"radial-gradient(circle, {stops})"
        
        elif self.type == "conic":
            stops = ", ".join([f"{color} {pos*360}deg" for color, pos in self.colors])
            return f"conic-gradient({stops})"
        
        return ""
    
    @classmethod
    def linear_vertical(cls, start_color: Union[Color, str], end_color: Union[Color, str]) -> 'Gradient':
        """Create a vertical linear gradient."""
        return cls(
            type="linear",
            direction="to bottom",
            colors=[(start_color, 0.0), (end_color, 1.0)]
        )
    
    @classmethod
    def linear_horizontal(cls, start_color: Union[Color, str], end_color: Union[Color, str]) -> 'Gradient':
        """Create a horizontal linear gradient."""
        return cls(
            type="linear",
            direction="to right",
            colors=[(start_color, 0.0), (end_color, 1.0)]
        )
    
    @classmethod
    def radial(cls, center_color: Union[Color, str], edge_color: Union[Color, str]) -> 'Gradient':
        """Create a radial gradient."""
        return cls(
            type="radial",
            colors=[(center_color, 0.0), (edge_color, 1.0)]
        )
    
    @classmethod
    def rainbow(cls, type: str = "linear", direction: str = "to right") -> 'Gradient':
        """Create a rainbow gradient."""
        colors = [
            ("#ff0000", 0.0),    # Red
            ("#ff8000", 0.17),   # Orange
            ("#ffff00", 0.33),   # Yellow
            ("#00ff00", 0.5),    # Green
            ("#0080ff", 0.67),   # Blue
            ("#8000ff", 0.83),   # Indigo
            ("#ff00ff", 1.0),    # Violet
        ]
        return cls(type=type, direction=direction, colors=colors)


@dataclass
class Border:
    """
    Represents a border style.
    """
    
    width: Union[float, Tuple[float, ...]] = 1
    style: str = "solid"  # solid, dashed, dotted, double, groove, ridge, inset, outset
    color: Union[Color, str] = "#000000"
    radius: Union[float, Tuple[float, ...]] = 0
    
    def __post_init__(self):
        if isinstance(self.color, str):
            self.color = Color.parse(self.color)
    
    def to_css(self) -> dict:
        """Convert to CSS border properties."""
        css = {}
        
        # Border width
        if isinstance(self.width, (int, float)):
            css['border-width'] = f"{self.width}px"
        else:
            css['border-width'] = " ".join([f"{w}px" for w in self.width])
        
        # Border style
        css['border-style'] = self.style
        
        # Border color
        css['border-color'] = str(self.color)
        
        # Border radius
        if isinstance(self.radius, (int, float)):
            if self.radius > 0:
                css['border-radius'] = f"{self.radius}px"
        else:
            css['border-radius'] = " ".join([f"{r}px" for r in self.radius])
        
        return css
    
    @classmethod
    def solid(cls, width: float = 1, color: Union[Color, str] = "#000000") -> 'Border':
        """Create a solid border."""
        return cls(width=width, style="solid", color=color)
    
    @classmethod
    def dashed(cls, width: float = 1, color: Union[Color, str] = "#000000") -> 'Border':
        """Create a dashed border."""
        return cls(width=width, style="dashed", color=color)
    
    @classmethod
    def dotted(cls, width: float = 1, color: Union[Color, str] = "#000000") -> 'Border':
        """Create a dotted border."""
        return cls(width=width, style="dotted", color=color)
    
    @classmethod
    def rounded(cls, radius: float = 4, width: float = 1, color: Union[Color, str] = "#000000") -> 'Border':
        """Create a rounded border."""
        return cls(width=width, style="solid", color=color, radius=radius)
    
    @classmethod
    def pill(cls, width: float = 1, color: Union[Color, str] = "#000000") -> 'Border':
        """Create a pill-shaped border (very rounded)."""
        return cls(width=width, style="solid", color=color, radius=999)


class VisualEffect:
    """
    Utility class for creating common visual effects.
    """
    
    @staticmethod
    def button_hover_effect() -> dict:
        """Get styles for button hover effect."""
        return {
            'transform': 'translateY(-1px)',
            'shadow': Shadow.medium(),
            'transition': 'all 0.2s ease'
        }
    
    @staticmethod
    def button_active_effect() -> dict:
        """Get styles for button active effect."""
        return {
            'transform': 'translateY(1px)',
            'shadow': Shadow.subtle(),
        }
    
    @staticmethod
    def card_style() -> dict:
        """Get styles for a card-like appearance."""
        return {
            'background': '#ffffff',
            'border': Border.solid(1, '#e0e0e0'),
            'border_radius': 8,
            'shadow': Shadow.medium(),
            'padding': 16
        }
    
    @staticmethod
    def glass_morphism() -> dict:
        """Get styles for glass morphism effect."""
        return {
            'background': 'rgba(255, 255, 255, 0.1)',
            'backdrop_filter': 'blur(10px)',
            'border': Border.solid(1, 'rgba(255, 255, 255, 0.2)'),
            'border_radius': 12
        }
    
    @staticmethod
    def neumorphism_raised() -> dict:
        """Get styles for raised neumorphism effect."""
        return {
            'background': '#e0e5ec',
            'border_radius': 12,
            'shadow': [
                Shadow(offset_x=-5, offset_y=-5, blur_radius=10, color='#ffffff'),
                Shadow(offset_x=5, offset_y=5, blur_radius=10, color='rgba(174, 174, 192, 0.4)')
            ]
        }
    
    @staticmethod
    def neumorphism_pressed() -> dict:
        """Get styles for pressed neumorphism effect."""
        return {
            'background': '#e0e5ec',
            'border_radius': 12,
            'shadow': [
                Shadow(offset_x=5, offset_y=5, blur_radius=10, color='#ffffff', inset=True),
                Shadow(offset_x=-5, offset_y=-5, blur_radius=10, color='rgba(174, 174, 192, 0.4)', inset=True)
            ]
        }
    
    @staticmethod
    def glow_effect(color: Union[Color, str] = "#007ACC") -> dict:
        """Get styles for glow effect."""
        return {
            'shadow': Shadow.glow(color),
            'transition': 'all 0.3s ease'
        }
    
    @staticmethod
    def gradient_text(gradient: Gradient) -> dict:
        """Get styles for gradient text."""
        return {
            'background': gradient.to_css(),
            'background_clip': 'text',
            'text_fill_color': 'transparent'
        }
    
    @staticmethod
    def floating_animation() -> dict:
        """Get styles for floating animation."""
        return {
            'animation': 'float 3s ease-in-out infinite',
            'keyframes': {
                '0%, 100%': {'transform': 'translateY(0px)'},
                '50%': {'transform': 'translateY(-10px)'}
            }
        }


class FilterEffect:
    """
    Represents CSS filter effects.
    """
    
    def __init__(self):
        self.filters = []
    
    def blur(self, radius: float) -> 'FilterEffect':
        """Add blur filter."""
        self.filters.append(f"blur({radius}px)")
        return self
    
    def brightness(self, value: float) -> 'FilterEffect':
        """Add brightness filter (1.0 = normal)."""
        self.filters.append(f"brightness({value})")
        return self
    
    def contrast(self, value: float) -> 'FilterEffect':
        """Add contrast filter (1.0 = normal)."""
        self.filters.append(f"contrast({value})")
        return self
    
    def grayscale(self, value: float = 1.0) -> 'FilterEffect':
        """Add grayscale filter (1.0 = full grayscale)."""
        self.filters.append(f"grayscale({value})")
        return self
    
    def hue_rotate(self, degrees: float) -> 'FilterEffect':
        """Add hue rotation filter."""
        self.filters.append(f"hue-rotate({degrees}deg)")
        return self
    
    def invert(self, value: float = 1.0) -> 'FilterEffect':
        """Add invert filter (1.0 = full invert)."""
        self.filters.append(f"invert({value})")
        return self
    
    def opacity(self, value: float) -> 'FilterEffect':
        """Add opacity filter (1.0 = opaque)."""
        self.filters.append(f"opacity({value})")
        return self
    
    def saturate(self, value: float) -> 'FilterEffect':
        """Add saturation filter (1.0 = normal)."""
        self.filters.append(f"saturate({value})")
        return self
    
    def sepia(self, value: float = 1.0) -> 'FilterEffect':
        """Add sepia filter (1.0 = full sepia)."""
        self.filters.append(f"sepia({value})")
        return self
    
    def drop_shadow(self, shadow: Shadow) -> 'FilterEffect':
        """Add drop shadow filter."""
        self.filters.append(
            f"drop-shadow({shadow.offset_x}px {shadow.offset_y}px "
            f"{shadow.blur_radius}px {shadow.color})"
        )
        return self
    
    def to_css(self) -> str:
        """Convert to CSS filter string."""
        return " ".join(self.filters) if self.filters else "none"
    
    def clear(self) -> 'FilterEffect':
        """Clear all filters."""
        self.filters.clear()
        return self
