"""
Color utilities and management for VGI.
"""

import colorsys
from typing import Union, Tuple, Dict, Optional
import re


class Color:
    """
    Represents a color with various format support and manipulation methods.
    
    Supports RGB, HSV, HSL color spaces and hex/named color formats.
    """
    
    # Common color names
    COLORS = {
        'black': (0, 0, 0),
        'white': (255, 255, 255),
        'red': (255, 0, 0),
        'green': (0, 255, 0),
        'blue': (0, 0, 255),
        'yellow': (255, 255, 0),
        'magenta': (255, 0, 255),
        'cyan': (0, 255, 255),
        'gray': (128, 128, 128),
        'grey': (128, 128, 128),
        'orange': (255, 165, 0),
        'purple': (128, 0, 128),
        'brown': (165, 42, 42),
        'pink': (255, 192, 203),
        'lime': (0, 255, 0),
        'navy': (0, 0, 128),
        'teal': (0, 128, 128),
        'silver': (192, 192, 192),
        'maroon': (128, 0, 0),
        'olive': (128, 128, 0),
    }
    
    def __init__(self, r: int = 0, g: int = 0, b: int = 0, a: float = 1.0):
        """
        Create a color.
        
        Args:
            r: Red component (0-255)
            g: Green component (0-255)
            b: Blue component (0-255)
            a: Alpha component (0.0-1.0)
        """
        self.r = max(0, min(255, int(r)))
        self.g = max(0, min(255, int(g)))
        self.b = max(0, min(255, int(b)))
        self.a = max(0.0, min(1.0, float(a)))
    
    @classmethod
    def from_hex(cls, hex_color: str) -> 'Color':
        """Create color from hex string."""
        hex_color = hex_color.strip('#')
        
        if len(hex_color) == 3:
            hex_color = ''.join([c*2 for c in hex_color])
        
        if len(hex_color) == 6:
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            return cls(r, g, b)
        elif len(hex_color) == 8:
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            a = int(hex_color[6:8], 16) / 255.0
            return cls(r, g, b, a)
        else:
            raise ValueError(f"Invalid hex color: {hex_color}")
    
    @classmethod
    def from_name(cls, name: str) -> 'Color':
        """Create color from name."""
        name = name.lower()
        if name in cls.COLORS:
            r, g, b = cls.COLORS[name]
            return cls(r, g, b)
        else:
            raise ValueError(f"Unknown color name: {name}")
    
    @classmethod
    def from_hsv(cls, h: float, s: float, v: float, a: float = 1.0) -> 'Color':
        """Create color from HSV values."""
        r, g, b = colorsys.hsv_to_rgb(h / 360.0, s / 100.0, v / 100.0)
        return cls(int(r * 255), int(g * 255), int(b * 255), a)
    
    @classmethod
    def from_hsl(cls, h: float, s: float, l: float, a: float = 1.0) -> 'Color':
        """Create color from HSL values."""
        r, g, b = colorsys.hls_to_rgb(h / 360.0, l / 100.0, s / 100.0)
        return cls(int(r * 255), int(g * 255), int(b * 255), a)
    
    @classmethod
    def parse(cls, color_string: str) -> 'Color':
        """Parse color from various string formats."""
        color_string = color_string.strip()
        
        # Hex format
        if color_string.startswith('#'):
            return cls.from_hex(color_string)
        
        # RGB format
        rgb_match = re.match(r'rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', color_string)
        if rgb_match:
            r, g, b = map(int, rgb_match.groups())
            return cls(r, g, b)
        
        # RGBA format
        rgba_match = re.match(r'rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([0-9.]+)\s*\)', color_string)
        if rgba_match:
            r, g, b, a = rgba_match.groups()
            return cls(int(r), int(g), int(b), float(a))
        
        # HSL format
        hsl_match = re.match(r'hsl\s*\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*\)', color_string)
        if hsl_match:
            h, s, l = map(int, hsl_match.groups())
            return cls.from_hsl(h, s, l)
        
        # Named color
        try:
            return cls.from_name(color_string)
        except ValueError:
            pass
        
        raise ValueError(f"Cannot parse color: {color_string}")
    
    def to_hex(self, include_alpha: bool = False) -> str:
        """Convert to hex string."""
        if include_alpha and self.a < 1.0:
            alpha_hex = format(int(self.a * 255), '02x')
            return f"#{self.r:02x}{self.g:02x}{self.b:02x}{alpha_hex}"
        else:
            return f"#{self.r:02x}{self.g:02x}{self.b:02x}"
    
    def to_rgb(self) -> str:
        """Convert to RGB string."""
        return f"rgb({self.r}, {self.g}, {self.b})"
    
    def to_rgba(self) -> str:
        """Convert to RGBA string."""
        return f"rgba({self.r}, {self.g}, {self.b}, {self.a})"
    
    def to_hsv(self) -> Tuple[float, float, float]:
        """Convert to HSV values."""
        h, s, v = colorsys.rgb_to_hsv(self.r / 255.0, self.g / 255.0, self.b / 255.0)
        return (h * 360, s * 100, v * 100)
    
    def to_hsl(self) -> Tuple[float, float, float]:
        """Convert to HSL values."""
        h, l, s = colorsys.rgb_to_hls(self.r / 255.0, self.g / 255.0, self.b / 255.0)
        return (h * 360, s * 100, l * 100)
    
    def lighten(self, amount: float = 0.1) -> 'Color':
        """Lighten the color by the given amount."""
        h, s, l = self.to_hsl()
        l = min(100, l + amount * 100)
        return Color.from_hsl(h, s, l, self.a)
    
    def darken(self, amount: float = 0.1) -> 'Color':
        """Darken the color by the given amount."""
        h, s, l = self.to_hsl()
        l = max(0, l - amount * 100)
        return Color.from_hsl(h, s, l, self.a)
    
    def saturate(self, amount: float = 0.1) -> 'Color':
        """Increase saturation by the given amount."""
        h, s, l = self.to_hsl()
        s = min(100, s + amount * 100)
        return Color.from_hsl(h, s, l, self.a)
    
    def desaturate(self, amount: float = 0.1) -> 'Color':
        """Decrease saturation by the given amount."""
        h, s, l = self.to_hsl()
        s = max(0, s - amount * 100)
        return Color.from_hsl(h, s, l, self.a)
    
    def with_alpha(self, alpha: float) -> 'Color':
        """Create a new color with different alpha."""
        return Color(self.r, self.g, self.b, alpha)
    
    def mix(self, other: 'Color', ratio: float = 0.5) -> 'Color':
        """Mix this color with another color."""
        r = int(self.r * (1 - ratio) + other.r * ratio)
        g = int(self.g * (1 - ratio) + other.g * ratio)
        b = int(self.b * (1 - ratio) + other.b * ratio)
        a = self.a * (1 - ratio) + other.a * ratio
        return Color(r, g, b, a)
    
    def complement(self) -> 'Color':
        """Get the complement color."""
        h, s, l = self.to_hsl()
        h = (h + 180) % 360
        return Color.from_hsl(h, s, l, self.a)
    
    def triadic(self) -> Tuple['Color', 'Color']:
        """Get triadic colors."""
        h, s, l = self.to_hsl()
        color1 = Color.from_hsl((h + 120) % 360, s, l, self.a)
        color2 = Color.from_hsl((h + 240) % 360, s, l, self.a)
        return (color1, color2)
    
    def analogous(self) -> Tuple['Color', 'Color']:
        """Get analogous colors."""
        h, s, l = self.to_hsl()
        color1 = Color.from_hsl((h + 30) % 360, s, l, self.a)
        color2 = Color.from_hsl((h - 30) % 360, s, l, self.a)
        return (color1, color2)
    
    def is_light(self) -> bool:
        """Check if the color is light (luminance > 0.5)."""
        luminance = (0.299 * self.r + 0.587 * self.g + 0.114 * self.b) / 255
        return luminance > 0.5
    
    def is_dark(self) -> bool:
        """Check if the color is dark."""
        return not self.is_light()
    
    def contrast_ratio(self, other: 'Color') -> float:
        """Calculate contrast ratio with another color."""
        def luminance(color):
            def adjust(c):
                c = c / 255.0
                return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
            
            r = adjust(color.r)
            g = adjust(color.g)
            b = adjust(color.b)
            return 0.2126 * r + 0.7152 * g + 0.0722 * b
        
        l1 = luminance(self)
        l2 = luminance(other)
        
        if l1 > l2:
            return (l1 + 0.05) / (l2 + 0.05)
        else:
            return (l2 + 0.05) / (l1 + 0.05)
    
    def __str__(self) -> str:
        if self.a < 1.0:
            return self.to_rgba()
        else:
            return self.to_hex()
    
    def __repr__(self) -> str:
        return f"Color({self.r}, {self.g}, {self.b}, {self.a})"
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, Color):
            return False
        return (self.r == other.r and self.g == other.g and 
                self.b == other.b and abs(self.a - other.a) < 1e-6)


class ColorPalette:
    """
    A collection of related colors forming a cohesive palette.
    """
    
    def __init__(self, name: str = "Custom Palette"):
        self.name = name
        self.colors: Dict[str, Color] = {}
        self.primary_color: Optional[str] = None
    
    def add_color(self, name: str, color: Union[Color, str], is_primary: bool = False):
        """Add a color to the palette."""
        if isinstance(color, str):
            color = Color.parse(color)
        
        self.colors[name] = color
        
        if is_primary or self.primary_color is None:
            self.primary_color = name
    
    def get_color(self, name: str) -> Optional[Color]:
        """Get a color from the palette."""
        return self.colors.get(name)
    
    def get_primary(self) -> Optional[Color]:
        """Get the primary color."""
        if self.primary_color:
            return self.colors.get(self.primary_color)
        return None
    
    def generate_variants(self, base_color_name: str) -> Dict[str, Color]:
        """Generate color variants from a base color."""
        base_color = self.get_color(base_color_name)
        if not base_color:
            return {}
        
        variants = {
            f"{base_color_name}_light": base_color.lighten(0.2),
            f"{base_color_name}_lighter": base_color.lighten(0.4),
            f"{base_color_name}_dark": base_color.darken(0.2),
            f"{base_color_name}_darker": base_color.darken(0.4),
            f"{base_color_name}_muted": base_color.desaturate(0.3),
        }
        
        # Add variants to palette
        for name, color in variants.items():
            self.colors[name] = color
        
        return variants
    
    def to_dict(self) -> Dict[str, str]:
        """Convert palette to dictionary of hex colors."""
        return {name: color.to_hex() for name, color in self.colors.items()}
    
    @classmethod
    def from_dict(cls, data: Dict[str, str], name: str = "Loaded Palette") -> 'ColorPalette':
        """Create palette from dictionary."""
        palette = cls(name)
        for color_name, hex_color in data.items():
            palette.add_color(color_name, Color.from_hex(hex_color))
        return palette
    
    @classmethod
    def create_material_palette(cls) -> 'ColorPalette':
        """Create a Material Design inspired palette."""
        palette = cls("Material Design")
        
        # Primary colors
        palette.add_color("primary", "#1976D2", True)
        palette.add_color("primary_light", "#42A5F5")
        palette.add_color("primary_dark", "#1565C0")
        
        # Secondary colors
        palette.add_color("secondary", "#DC004E")
        palette.add_color("secondary_light", "#F48FB1")
        palette.add_color("secondary_dark", "#C2185B")
        
        # Surface colors
        palette.add_color("background", "#FAFAFA")
        palette.add_color("surface", "#FFFFFF")
        palette.add_color("error", "#B00020")
        
        # Text colors
        palette.add_color("on_primary", "#FFFFFF")
        palette.add_color("on_secondary", "#FFFFFF")
        palette.add_color("on_background", "#000000")
        palette.add_color("on_surface", "#000000")
        palette.add_color("on_error", "#FFFFFF")
        
        return palette
    
    @classmethod
    def create_dark_palette(cls) -> 'ColorPalette':
        """Create a dark theme palette."""
        palette = cls("Dark Theme")
        
        # Primary colors
        palette.add_color("primary", "#BB86FC", True)
        palette.add_color("primary_variant", "#3700B3")
        
        # Secondary colors
        palette.add_color("secondary", "#03DAC6")
        
        # Surface colors
        palette.add_color("background", "#121212")
        palette.add_color("surface", "#1E1E1E")
        palette.add_color("error", "#CF6679")
        
        # Text colors
        palette.add_color("on_primary", "#000000")
        palette.add_color("on_secondary", "#000000")
        palette.add_color("on_background", "#FFFFFF")
        palette.add_color("on_surface", "#FFFFFF")
        palette.add_color("on_error", "#000000")
        
        return palette
