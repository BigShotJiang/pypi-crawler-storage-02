"""
Theme Demo - Showcases VGI's theming and styling capabilities.

This example shows:
- Switching between built-in themes
- Custom color palettes
- Style customization
- Real-time theme updates
"""

import vgi


def create_theme_demo():
    """Create theme demonstration application."""
    
    app = vgi.Application(theme="modern_light")
    
    window = app.create_window(
        title="VGI Theme Demo",
        size=(700, 500)
    )
    
    # Main layout
    main_layout = vgi.HBox(spacing=20, padding=20)
    
    # Left panel - theme controls
    control_panel = create_control_panel(app)
    main_layout.add(control_panel)
    
    # Right panel - preview area
    preview_panel = create_preview_panel()
    main_layout.add(preview_panel, expand=True, fill="both")
    
    window.add_widget(main_layout, fill="both", expand=True)
    
    return app


def create_control_panel(app):
    """Create theme control panel."""
    panel = vgi.Panel(title="Theme Controls", padding=15)
    panel.set_style(width=250)
    
    # Theme selection
    theme_section = vgi.VBox(spacing=10)
    theme_title = vgi.Heading3("Built-in Themes")
    theme_section.add(theme_title)
    
    themes = app.theme_manager.get_theme_names()
    
    def switch_theme(theme_name):
        app.set_theme(theme_name)
    
    for theme_name in themes:
        button = vgi.Button(
            text=theme_name,
            style="outline",
            on_click=lambda t=theme_name: switch_theme(t)
        )
        theme_section.add(button)
    
    panel.add(theme_section)
    
    # Color customization
    color_section = vgi.VBox(spacing=10)
    color_title = vgi.Heading3("Color Customization")
    color_section.add(color_title)
    
    # Primary color options
    primary_colors = [
        ("#007ACC", "Blue"),
        ("#28A745", "Green"),
        ("#DC3545", "Red"),
        ("#FFC107", "Yellow"),
        ("#6F42C1", "Purple"),
    ]
    
    color_grid = vgi.Grid(columns=2, spacing=5)
    
    for color, name in primary_colors:
        color_btn = vgi.Button(
            text=name,
            style="primary",
            on_click=lambda c=color: set_primary_color(app, c)
        )
        color_btn.set_style(background_color=color)
        color_grid.add(color_btn)
    
    color_section.add(color_grid)
    panel.add(color_section)
    
    # Style options
    style_section = vgi.VBox(spacing=10)
    style_title = vgi.Heading3("Style Options")
    style_section.add(style_title)
    
    # Border radius
    radius_label = vgi.Label("Border Radius:")
    style_section.add(radius_label)
    
    radius_buttons = vgi.HBox(spacing=5)
    for radius in [0, 4, 8, 16]:
        btn = vgi.Button(
            text=str(radius),
            style="outline",
            size="small",
            on_click=lambda r=radius: set_border_radius(app, r)
        )
        radius_buttons.add(btn)
    
    style_section.add(radius_buttons)
    panel.add(style_section)
    
    return panel


def create_preview_panel():
    """Create theme preview panel."""
    panel = vgi.Panel(title="Theme Preview", padding=20)
    
    # Sample content
    content = vgi.VBox(spacing=15)
    
    # Headings
    content.add(vgi.Heading1("Heading 1"))
    content.add(vgi.Heading2("Heading 2"))
    content.add(vgi.Heading3("Heading 3"))
    
    # Paragraph
    content.add(vgi.Label(
        text="This is a sample paragraph demonstrating how text appears "
             "with the current theme. Notice how the colors, fonts, and "
             "spacing adapt to the selected theme.",
        wrap=True
    ))
    
    # Buttons
    button_section = vgi.VBox(spacing=10)
    button_section.add(vgi.Label("Button Styles:"))
    
    button_row1 = vgi.HBox(spacing=10)
    button_row1.add(vgi.PrimaryButton("Primary"))
    button_row1.add(vgi.SecondaryButton("Secondary"))
    button_row1.add(vgi.OutlineButton("Outline"))
    
    button_row2 = vgi.HBox(spacing=10)
    button_row2.add(vgi.Button("Disabled", style="primary", disabled=True))
    button_row2.add(vgi.DangerButton("Danger"))
    
    button_section.add(button_row1)
    button_section.add(button_row2)
    content.add(button_section)
    
    # Form elements
    form_section = vgi.VBox(spacing=10)
    form_section.add(vgi.Label("Form Elements:"))
    
    form_section.add(vgi.Input(placeholder="Text input"))
    form_section.add(vgi.EmailInput(placeholder="Email input"))
    form_section.add(vgi.PasswordInput(placeholder="Password input"))
    
    # Checkboxes and radio buttons
    check_section = vgi.HBox(spacing=15)
    check_section.add(vgi.Checkbox("Checkbox option", checked=True))
    check_section.add(vgi.RadioButton("Radio option"))
    
    form_section.add(check_section)
    content.add(form_section)
    
    # Cards/panels
    card_section = vgi.VBox(spacing=10)
    card_section.add(vgi.Label("Panel Styles:"))
    
    sample_card = vgi.Panel(padding=15)
    sample_card.add(vgi.Label("This is a sample panel showing how containers "
                             "appear with the current theme.", wrap=True))
    
    card_section.add(sample_card)
    content.add(card_section)
    
    panel.add(content)
    return panel


def set_primary_color(app, color):
    """Set the primary color for the current theme."""
    current_theme = app.theme_manager.get_current_theme()
    if current_theme:
        current_theme.set_widget_style("button", "background_color", color)
        # Force refresh by switching to the same theme
        app.set_theme(current_theme.name)


def set_border_radius(app, radius):
    """Set the border radius for the current theme."""
    current_theme = app.theme_manager.get_current_theme()
    if current_theme:
        current_theme.set_global_style("border_radius", radius)
        # Apply to various widgets
        current_theme.set_widget_style("button", "border_radius", radius)
        current_theme.set_widget_style("input", "border_radius", radius)
        # Force refresh
        app.set_theme(current_theme.name)


def main():
    """Run the theme demo."""
    app = create_theme_demo()
    app.run()


if __name__ == "__main__":
    main()
