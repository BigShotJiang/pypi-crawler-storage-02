"""VGI Examples - Showcase applications demonstrating library features."""
