"""
VGI Demo Launcher - Main demo application showcasing all VGI features.

This comprehensive demo includes:
- All component showcases
- Theme demonstrations
- Layout examples
- Interactive tutorials
- Performance tests
"""

import vgi
from . import basic_example, layout_showcase, theme_demo


def create_demo_launcher():
    """Create the main demo launcher application."""
    
    app = vgi.Application(theme="modern_light")
    
    window = app.create_window(
        title="VGI Demo Launcher",
        size=(900, 650)
    )
    
    # Main layout
    main_layout = vgi.VBox(padding=30, spacing=20)
    
    # Header
    header = create_header()
    main_layout.add(header)
    
    # Demo grid
    demo_grid = create_demo_grid()
    main_layout.add(demo_grid, expand=True, fill="both")
    
    # Footer
    footer = create_footer()
    main_layout.add(footer)
    
    window.add_widget(main_layout, fill="both", expand=True)
    
    return app


def create_header():
    """Create the application header."""
    header = vgi.VBox(spacing=10, align="center")
    
    # Title
    title = vgi.Label(
        text="VGI Demo Launcher",
        font_size=32,
        font_weight="bold",
        text_align="center"
    )
    header.add(title)
    
    # Subtitle
    subtitle = vgi.Label(
        text="Professional Modern GUI Library for Python",
        font_size=16,
        text_color="#666666",
        text_align="center"
    )
    header.add(subtitle)
    
    # Version info
    version = vgi.Label(
        text="Version 1.0.0 - Comprehensive UI Framework",
        font_size=12,
        text_color="#999999",
        text_align="center"
    )
    header.add(version)
    
    return header


def create_demo_grid():
    """Create the demo selection grid."""
    container = vgi.VBox(spacing=20)
    
    # Section title
    title = vgi.Heading2("Featured Demos")
    container.add(title)
    
    # Demo cards grid
    demo_grid = vgi.Grid(columns=2, spacing=20, uniform_columns=True)
    
    # Demo definitions
    demos = [
        {
            "title": "Basic Example",
            "description": "Simple application showing core VGI features including buttons, inputs, layouts, and event handling.",
            "features": ["Basic Widgets", "Event Handling", "Form Validation", "Theme Toggle"],
            "action": lambda: basic_example.main()
        },
        {
            "title": "Layout Showcase",
            "description": "Comprehensive demonstration of VGI's powerful layout system with examples of all layout types.",
            "features": ["VBox & HBox", "Grid Layout", "Stack Layout", "Responsive Design"],
            "action": lambda: layout_showcase.main()
        },
        {
            "title": "Theme Demo",
            "description": "Interactive theme showcase demonstrating VGI's advanced styling and theming capabilities.",
            "features": ["Built-in Themes", "Color Customization", "Live Preview", "Style Options"],
            "action": lambda: theme_demo.main()
        },
        {
            "title": "Component Gallery",
            "description": "Complete gallery of all VGI components with interactive examples and customization options.",
            "features": ["All Components", "Interactive Examples", "Customization", "Code Samples"],
            "action": lambda: create_component_gallery().run()
        },
        {
            "title": "Professional App",
            "description": "Full-featured professional application demonstrating real-world VGI usage patterns.",
            "features": ["Complex Layouts", "Data Management", "Professional UI", "Best Practices"],
            "action": lambda: create_professional_demo().run()
        },
        {
            "title": "Animation Demo",
            "description": "Showcase of VGI's animation and transition system with smooth, modern effects.",
            "features": ["Smooth Animations", "Transitions", "Effects", "Interactive Demo"],
            "action": lambda: create_animation_demo().run()
        }
    ]
    
    for i, demo in enumerate(demos):
        card = create_demo_card(demo)
        row = i // 2
        col = i % 2
        demo_grid.add(card, row=row, column=col, sticky="nsew")
    
    container.add(demo_grid)
    
    return container


def create_demo_card(demo_info):
    """Create a demo card."""
    card = vgi.Panel(padding=20)
    
    content = vgi.VBox(spacing=12)
    
    # Title
    title = vgi.Heading3(demo_info["title"])
    content.add(title)
    
    # Description
    description = vgi.Label(
        text=demo_info["description"],
        wrap=True,
        text_color="#555555"
    )
    content.add(description)
    
    # Features list
    features_label = vgi.Label("Features:", font_weight="bold")
    content.add(features_label)
    
    features_container = vgi.VBox(spacing=3)
    for feature in demo_info["features"]:
        feature_item = vgi.Label(f"• {feature}", text_color="#666666")
        features_container.add(feature_item)
    
    content.add(features_container)
    
    # Launch button
    launch_btn = vgi.PrimaryButton(
        text="Launch Demo",
        on_click=demo_info["action"]
    )
    content.add(launch_btn)
    
    card.add(content)
    return card


def create_footer():
    """Create the application footer."""
    footer = vgi.VBox(spacing=10, align="center")
    
    # Links
    links = vgi.HBox(spacing=20, align="center")
    
    github_link = vgi.Link(
        text="GitHub Repository",
        on_click=lambda: print("Opening GitHub...")
    )
    links.add(github_link)
    
    docs_link = vgi.Link(
        text="Documentation",
        on_click=lambda: print("Opening Documentation...")
    )
    links.add(docs_link)
    
    examples_link = vgi.Link(
        text="More Examples",
        on_click=lambda: print("Opening Examples...")
    )
    links.add(examples_link)
    
    footer.add(links)
    
    # Copyright
    copyright_text = vgi.Caption(
        "VGI - Professional GUI Library for Python | MIT License"
    )
    footer.add(copyright_text)
    
    return footer


def create_component_gallery():
    """Create component gallery demo (placeholder)."""
    app = vgi.Application()
    window = app.create_window(title="Component Gallery", size=(800, 600))
    
    container = vgi.VBox(padding=20, spacing=20)
    
    title = vgi.Heading1("Component Gallery")
    container.add(title)
    
    description = vgi.Label(
        text="This demo showcases all VGI components. "
             "Full implementation coming soon!",
        wrap=True
    )
    container.add(description)
    
    # Sample components
    sample_grid = vgi.Grid(columns=3, spacing=15)
    
    # Buttons
    sample_grid.add(vgi.PrimaryButton("Primary Button"))
    sample_grid.add(vgi.SecondaryButton("Secondary"))
    sample_grid.add(vgi.OutlineButton("Outline"))
    
    # Inputs
    sample_grid.add(vgi.Input(placeholder="Text Input"))
    sample_grid.add(vgi.EmailInput(placeholder="Email"))
    sample_grid.add(vgi.PasswordInput(placeholder="Password"))
    
    container.add(sample_grid)
    
    window.add_widget(container, fill="both", expand=True)
    return app


def create_professional_demo():
    """Create professional application demo (placeholder)."""
    app = vgi.Application(theme="professional")
    window = app.create_window(title="Professional Demo", size=(1000, 700))
    
    container = vgi.VBox(padding=20)
    
    title = vgi.Heading1("Professional Application Demo")
    container.add(title)
    
    description = vgi.Label(
        text="This demo shows a complete professional application built with VGI. "
             "Features include data grids, charts, forms, and more. "
             "Full implementation coming soon!",
        wrap=True
    )
    container.add(description)
    
    window.add_widget(container, fill="both", expand=True)
    return app


def create_animation_demo():
    """Create animation demo (placeholder)."""
    app = vgi.Application()
    window = app.create_window(title="Animation Demo", size=(600, 500))
    
    container = vgi.VBox(padding=20, spacing=20)
    
    title = vgi.Heading1("Animation & Effects Demo")
    container.add(title)
    
    description = vgi.Label(
        text="This demo showcases VGI's animation system with smooth transitions, "
             "effects, and interactive animations. Full implementation coming soon!",
        wrap=True
    )
    container.add(description)
    
    # Sample animated button
    animate_btn = vgi.PrimaryButton(
        text="Click for Animation!",
        on_click=lambda: print("Animation triggered!")
    )
    container.add(animate_btn)
    
    window.add_widget(container, fill="both", expand=True)
    return app


def main():
    """Run the main demo launcher."""
    app = create_demo_launcher()
    app.run()


if __name__ == "__main__":
    main()
