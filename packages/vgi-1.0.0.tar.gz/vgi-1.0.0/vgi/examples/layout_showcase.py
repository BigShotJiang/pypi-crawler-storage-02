"""
Layout Showcase - Demonstrates VGI's powerful layout system.

This example shows:
- VBox and HBox layouts
- Grid layout with spanning
- Stack layout for tabs/pages
- Container padding and spacing
- Responsive layouts
"""

import vgi


def create_layout_showcase():
    """Create layout showcase application."""
    
    app = vgi.Application(theme="modern_light")
    
    window = app.create_window(
        title="VGI Layout Showcase",
        size=(800, 600)
    )
    
    # Main container
    main_container = vgi.VBox(padding=10, spacing=10)
    
    # Title
    title = vgi.Heading1("Layout System Showcase")
    main_container.add(title)
    
    # Create tab stack
    tab_stack = vgi.Stack()
    
    # Tab buttons container
    tab_buttons = vgi.HBox(spacing=5)
    
    def show_tab(tab_name):
        tab_stack.show(tab_name)
        # Update button styles (simplified)
        for i, button in enumerate(tab_buttons.children):
            if hasattr(button, 'button_style'):
                if button.text.lower().replace(" ", "_") == tab_name:
                    button.button_style = "primary"
                else:
                    button.button_style = "secondary"
    
    # Create tab buttons
    vbox_btn = vgi.Button("VBox Layout", on_click=lambda: show_tab("vbox_layout"))
    hbox_btn = vgi.Button("HBox Layout", on_click=lambda: show_tab("hbox_layout"))
    grid_btn = vgi.Button("Grid Layout", on_click=lambda: show_tab("grid_layout"))
    
    tab_buttons.add(vbox_btn)
    tab_buttons.add(hbox_btn)
    tab_buttons.add(grid_btn)
    
    main_container.add(tab_buttons)
    
    # VBox Layout Demo
    vbox_demo = create_vbox_demo()
    tab_stack.add(vbox_demo, "vbox_layout")
    
    # HBox Layout Demo
    hbox_demo = create_hbox_demo()
    tab_stack.add(hbox_demo, "hbox_layout")
    
    # Grid Layout Demo
    grid_demo = create_grid_demo()
    tab_stack.add(grid_demo, "grid_layout")
    
    main_container.add(tab_stack, expand=True, fill="both")
    
    # Show first tab
    show_tab("vbox_layout")
    
    window.add_widget(main_container, fill="both", expand=True)
    
    return app


def create_vbox_demo():
    """Create VBox layout demonstration."""
    container = vgi.Panel(title="VBox Layout", padding=20)
    
    # Description
    desc = vgi.Label(
        text="VBox arranges widgets vertically. This demo shows different "
             "alignment and spacing options.",
        wrap=True
    )
    container.add(desc)
    
    # Demo sections
    demo_container = vgi.HBox(spacing=20)
    
    # Left column - stretch alignment
    left_section = vgi.VBox(spacing=10)
    left_title = vgi.Heading3("Stretch Alignment")
    left_section.add(left_title)
    
    stretch_box = vgi.VBox(spacing=5, align="stretch")
    stretch_box.add(vgi.Button("Button 1", style="primary"))
    stretch_box.add(vgi.Button("Button 2", style="secondary"))
    stretch_box.add(vgi.Button("Button 3", style="outline"))
    
    left_section.add(stretch_box)
    demo_container.add(left_section)
    
    # Center column - center alignment
    center_section = vgi.VBox(spacing=10)
    center_title = vgi.Heading3("Center Alignment")
    center_section.add(center_title)
    
    center_box = vgi.VBox(spacing=5, align="center")
    center_box.add(vgi.Button("Short", style="primary"))
    center_box.add(vgi.Button("Medium Button", style="secondary"))
    center_box.add(vgi.Button("Very Long Button Text", style="outline"))
    
    center_section.add(center_box)
    demo_container.add(center_section)
    
    # Right column - different spacing
    right_section = vgi.VBox(spacing=10)
    right_title = vgi.Heading3("Large Spacing")
    right_section.add(right_title)
    
    spaced_box = vgi.VBox(spacing=20, align="start")
    spaced_box.add(vgi.Label("Item 1"))
    spaced_box.add(vgi.Label("Item 2"))
    spaced_box.add(vgi.Label("Item 3"))
    
    right_section.add(spaced_box)
    demo_container.add(right_section)
    
    container.add(demo_container)
    
    return container


def create_hbox_demo():
    """Create HBox layout demonstration."""
    container = vgi.Panel(title="HBox Layout", padding=20)
    
    # Description
    desc = vgi.Label(
        text="HBox arranges widgets horizontally. Perfect for toolbars, "
             "button groups, and navigation.",
        wrap=True
    )
    container.add(desc)
    
    # Toolbar example
    toolbar_section = vgi.VBox(spacing=10)
    toolbar_title = vgi.Heading3("Toolbar Example")
    toolbar_section.add(toolbar_title)
    
    toolbar = vgi.HBox(spacing=5, padding=10)
    toolbar.add(vgi.Button("New", style="primary", size="small"))
    toolbar.add(vgi.Button("Open", style="secondary", size="small"))
    toolbar.add(vgi.Button("Save", style="secondary", size="small"))
    toolbar.add(vgi.Label("  |  "))  # Separator
    toolbar.add(vgi.Button("Cut", style="outline", size="small"))
    toolbar.add(vgi.Button("Copy", style="outline", size="small"))
    toolbar.add(vgi.Button("Paste", style="outline", size="small"))
    
    toolbar_section.add(toolbar)
    container.add(toolbar_section)
    
    # Button group example
    group_section = vgi.VBox(spacing=10)
    group_title = vgi.Heading3("Button Groups")
    group_section.add(group_title)
    
    # Primary group
    primary_group = vgi.HBox(spacing=5)
    primary_group.add(vgi.Button("Option A", style="primary"))
    primary_group.add(vgi.Button("Option B", style="primary"))
    primary_group.add(vgi.Button("Option C", style="primary"))
    
    group_section.add(primary_group)
    
    # Mixed group
    mixed_group = vgi.HBox(spacing=5)
    mixed_group.add(vgi.Button("Cancel", style="secondary"))
    mixed_group.add(vgi.Button("Apply", style="outline"))
    mixed_group.add(vgi.Button("OK", style="primary"))
    
    group_section.add(mixed_group)
    container.add(group_section)
    
    return container


def create_grid_demo():
    """Create Grid layout demonstration."""
    container = vgi.Panel(title="Grid Layout", padding=20)
    
    # Description
    desc = vgi.Label(
        text="Grid layout provides precise control over widget positioning "
             "with rows, columns, and spanning.",
        wrap=True
    )
    container.add(desc)
    
    # Grid example
    grid_section = vgi.VBox(spacing=10)
    grid_title = vgi.Heading3("Form Layout Example")
    grid_section.add(grid_title)
    
    form_grid = vgi.Grid(columns=2, spacing=10, uniform_columns=False)
    
    # Row 1
    form_grid.add(vgi.Label("Name:"), row=0, column=0, sticky="e")
    form_grid.add(vgi.Input(placeholder="Enter name"), row=0, column=1, sticky="ew")
    
    # Row 2
    form_grid.add(vgi.Label("Email:"), row=1, column=0, sticky="e")
    form_grid.add(vgi.EmailInput(placeholder="Enter email"), row=1, column=1, sticky="ew")
    
    # Row 3
    form_grid.add(vgi.Label("Message:"), row=2, column=0, sticky="ne")
    form_grid.add(vgi.TextArea(placeholder="Enter message..."), row=2, column=1, sticky="ew")
    
    # Row 4 - buttons spanning both columns
    button_container = vgi.HBox(spacing=10)
    button_container.add(vgi.Button("Cancel", style="secondary"))
    button_container.add(vgi.Button("Submit", style="primary"))
    
    form_grid.add(button_container, row=3, column=0, columnspan=2, sticky="e")
    
    # Configure column weights
    form_grid.set_column_weight(1, 1)  # Make second column expandable
    
    grid_section.add(form_grid)
    container.add(grid_section)
    
    return container


def main():
    """Run the layout showcase."""
    app = create_layout_showcase()
    app.run()


if __name__ == "__main__":
    main()
