"""
Basic VGI Example - Simple application demonstrating core features.

This example shows:
- Creating an application and window
- Adding basic widgets (buttons, labels, inputs)
- Using layout containers
- Handling events
- Applying themes
"""

import vgi


def create_basic_app():
    """Create a basic VGI application."""
    
    # Create application
    app = vgi.Application(theme="modern_light")
    
    # Create main window
    window = app.create_window(
        title="VGI Basic Example",
        size=(600, 400),
        centered=True
    )
    
    # Create main container with padding
    main_container = vgi.VBox(padding=20, spacing=15)
    
    # Add title
    title = vgi.Label(
        text="Welcome to VGI!",
        font_size=24,
        font_weight="bold",
        text_align="center"
    )
    main_container.add(title)
    
    # Add description
    description = vgi.Label(
        text="VGI is a modern, professional GUI library for Python. "
             "This example demonstrates basic functionality including "
             "buttons, inputs, layouts, and event handling.",
        wrap=True,
        text_align="center"
    )
    main_container.add(description)
    
    # Create input section
    input_section = vgi.VBox(spacing=10)
    
    # Name input
    name_label = vgi.Label(text="Your Name:")
    name_input = vgi.Input(placeholder="Enter your name here...")
    input_section.add(name_label)
    input_section.add(name_input)
    
    # Email input with validation
    email_label = vgi.Label(text="Email Address:")
    email_input = vgi.EmailInput(placeholder="Enter your email...")
    input_section.add(email_label)
    input_section.add(email_input)
    
    main_container.add(input_section)
    
    # Create button section
    button_section = vgi.HBox(spacing=10, align="center")
    
    # Status label for displaying results
    status_label = vgi.Label(text="", text_color="#666666")
    
    def on_submit():
        """Handle form submission."""
        name = name_input.value.strip()
        email = email_input.value.strip()
        
        if not name:
            status_label.text = "Please enter your name"
            status_label.text_color = "#E74C3C"
        elif not email:
            status_label.text = "Please enter your email"
            status_label.text_color = "#E74C3C"
        elif not email_input.is_valid:
            status_label.text = "Please enter a valid email address"
            status_label.text_color = "#E74C3C"
        else:
            status_label.text = f"Hello {name}! We'll contact you at {email}"
            status_label.text_color = "#27AE60"
    
    def on_clear():
        """Clear the form."""
        name_input.value = ""
        email_input.value = ""
        status_label.text = ""
    
    def on_theme_toggle():
        """Toggle between light and dark themes."""
        current_theme = app.theme_manager.get_current_theme()
        if current_theme and current_theme.name == "Modern Light":
            app.set_theme("Modern Dark")
        else:
            app.set_theme("Modern Light")
    
    # Create buttons
    submit_btn = vgi.PrimaryButton(text="Submit", on_click=on_submit)
    clear_btn = vgi.SecondaryButton(text="Clear", on_click=on_clear)
    theme_btn = vgi.OutlineButton(text="Toggle Theme", on_click=on_theme_toggle)
    
    button_section.add(submit_btn)
    button_section.add(clear_btn)
    button_section.add(theme_btn)
    
    main_container.add(button_section)
    main_container.add(status_label)
    
    # Add main container to window
    window.add_widget(main_container, fill="both", expand=True)
    
    return app


def main():
    """Run the basic example."""
    app = create_basic_app()
    app.run()


if __name__ == "__main__":
    main()
