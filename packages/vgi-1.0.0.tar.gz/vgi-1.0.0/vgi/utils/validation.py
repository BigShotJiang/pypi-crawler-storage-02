"""
Validation utilities for VGI.
"""

import re
from typing import Any, Callable, Dict, List, Optional, Union
from abc import ABC, abstractmethod


class ValidationRule(ABC):
    """Base class for validation rules."""
    
    @abstractmethod
    def validate(self, value: Any) -> bool:
        """Validate a value."""
        pass
    
    @abstractmethod
    def get_error_message(self) -> str:
        """Get error message for failed validation."""
        pass


class RequiredRule(ValidationRule):
    """Rule that requires a non-empty value."""
    
    def validate(self, value: Any) -> bool:
        if value is None:
            return False
        if isinstance(value, str):
            return bool(value.strip())
        if isinstance(value, (list, dict, tuple)):
            return len(value) > 0
        return True
    
    def get_error_message(self) -> str:
        return "This field is required"


class MinLengthRule(ValidationRule):
    """Rule that requires minimum length."""
    
    def __init__(self, min_length: int):
        self.min_length = min_length
    
    def validate(self, value: Any) -> bool:
        if value is None:
            return False
        return len(str(value)) >= self.min_length
    
    def get_error_message(self) -> str:
        return f"Must be at least {self.min_length} characters long"


class MaxLengthRule(ValidationRule):
    """Rule that requires maximum length."""
    
    def __init__(self, max_length: int):
        self.max_length = max_length
    
    def validate(self, value: Any) -> bool:
        if value is None:
            return True
        return len(str(value)) <= self.max_length
    
    def get_error_message(self) -> str:
        return f"Must be no more than {self.max_length} characters long"


class RangeRule(ValidationRule):
    """Rule that requires value to be within a range."""
    
    def __init__(self, min_value: Union[int, float], max_value: Union[int, float]):
        self.min_value = min_value
        self.max_value = max_value
    
    def validate(self, value: Any) -> bool:
        try:
            num_value = float(value)
            return self.min_value <= num_value <= self.max_value
        except (ValueError, TypeError):
            return False
    
    def get_error_message(self) -> str:
        return f"Must be between {self.min_value} and {self.max_value}"


class EmailRule(ValidationRule):
    """Rule that validates email format."""
    
    def __init__(self):
        self.pattern = re.compile(
            r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
    
    def validate(self, value: Any) -> bool:
        if not isinstance(value, str):
            return False
        return bool(self.pattern.match(value))
    
    def get_error_message(self) -> str:
        return "Must be a valid email address"


class RegexRule(ValidationRule):
    """Rule that validates against a regular expression."""
    
    def __init__(self, pattern: str, message: str = "Invalid format"):
        self.pattern = re.compile(pattern)
        self.message = message
    
    def validate(self, value: Any) -> bool:
        if not isinstance(value, str):
            return False
        return bool(self.pattern.match(value))
    
    def get_error_message(self) -> str:
        return self.message


class CustomRule(ValidationRule):
    """Rule that uses a custom validation function."""
    
    def __init__(self, validator: Callable[[Any], bool], message: str):
        self.validator = validator
        self.message = message
    
    def validate(self, value: Any) -> bool:
        return self.validator(value)
    
    def get_error_message(self) -> str:
        return self.message


class Validator:
    """
    Validator class for validating input values.
    
    Supports multiple validation rules and provides detailed error messages.
    """
    
    def __init__(self):
        self.rules: List[ValidationRule] = []
    
    def add_rule(self, rule: ValidationRule) -> 'Validator':
        """Add a validation rule."""
        self.rules.append(rule)
        return self
    
    def required(self) -> 'Validator':
        """Add required rule."""
        return self.add_rule(RequiredRule())
    
    def min_length(self, length: int) -> 'Validator':
        """Add minimum length rule."""
        return self.add_rule(MinLengthRule(length))
    
    def max_length(self, length: int) -> 'Validator':
        """Add maximum length rule."""
        return self.add_rule(MaxLengthRule(length))
    
    def range(self, min_value: Union[int, float], max_value: Union[int, float]) -> 'Validator':
        """Add range rule."""
        return self.add_rule(RangeRule(min_value, max_value))
    
    def email(self) -> 'Validator':
        """Add email validation rule."""
        return self.add_rule(EmailRule())
    
    def regex(self, pattern: str, message: str = "Invalid format") -> 'Validator':
        """Add regex validation rule."""
        return self.add_rule(RegexRule(pattern, message))
    
    def custom(self, validator: Callable[[Any], bool], message: str) -> 'Validator':
        """Add custom validation rule."""
        return self.add_rule(CustomRule(validator, message))
    
    def validate(self, value: Any) -> bool:
        """Validate a value against all rules."""
        return all(rule.validate(value) for rule in self.rules)
    
    def get_errors(self, value: Any) -> List[str]:
        """Get all validation errors for a value."""
        errors = []
        for rule in self.rules:
            if not rule.validate(value):
                errors.append(rule.get_error_message())
        return errors
    
    def get_first_error(self, value: Any) -> Optional[str]:
        """Get the first validation error for a value."""
        for rule in self.rules:
            if not rule.validate(value):
                return rule.get_error_message()
        return None
    
    @staticmethod
    def create_email_validator() -> 'Validator':
        """Create a pre-configured email validator."""
        return Validator().required().email()
    
    @staticmethod
    def create_password_validator(min_length: int = 8) -> 'Validator':
        """Create a pre-configured password validator."""
        return (Validator()
                .required()
                .min_length(min_length)
                .regex(r'.*[A-Z].*', "Must contain at least one uppercase letter")
                .regex(r'.*[a-z].*', "Must contain at least one lowercase letter")
                .regex(r'.*\d.*', "Must contain at least one number"))
    
    @staticmethod
    def create_phone_validator() -> 'Validator':
        """Create a pre-configured phone number validator."""
        return (Validator()
                .required()
                .regex(r'^\+?[\d\s\-\(\)]{10,}$', "Must be a valid phone number"))
    
    @staticmethod
    def create_url_validator() -> 'Validator':
        """Create a pre-configured URL validator."""
        return (Validator()
                .required()
                .regex(r'^https?:\/\/[^\s]+$', "Must be a valid URL"))
