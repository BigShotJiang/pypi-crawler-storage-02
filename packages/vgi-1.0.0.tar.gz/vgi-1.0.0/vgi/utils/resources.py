"""
Resource management utilities for VGI.
"""

import os
import json
from typing import Dict, Any, Optional
from pathlib import Path
import tkinter as tk
from PIL import Image, ImageTk


class ResourceManager:
    """
    Manages application resources like images, fonts, and configuration files.
    
    Provides a centralized way to load and cache resources for better performance.
    """
    
    def __init__(self):
        self._image_cache: Dict[str, ImageTk.PhotoImage] = {}
        self._font_cache: Dict[str, tk.font.Font] = {}
        self._config_cache: Dict[str, Dict] = {}
        self._resource_paths: list = []
        
        # Add default resource paths
        self.add_resource_path(Path(__file__).parent.parent / "assets")
        self.add_resource_path(Path.cwd() / "assets")
    
    def add_resource_path(self, path: Path):
        """Add a path to search for resources."""
        if path.exists() and path not in self._resource_paths:
            self._resource_paths.append(path)
    
    def find_resource(self, filename: str) -> Optional[Path]:
        """Find a resource file in the search paths."""
        for path in self._resource_paths:
            full_path = path / filename
            if full_path.exists():
                return full_path
        return None
    
    def load_image(self, filename: str, size: Optional[tuple] = None) -> Optional[ImageTk.PhotoImage]:
        """
        Load an image resource.
        
        Args:
            filename: Image filename
            size: Optional tuple (width, height) to resize image
            
        Returns:
            PhotoImage object or None if not found
        """
        cache_key = f"{filename}_{size}" if size else filename
        
        if cache_key in self._image_cache:
            return self._image_cache[cache_key]
        
        resource_path = self.find_resource(filename)
        if not resource_path:
            return None
        
        try:
            image = Image.open(resource_path)
            
            if size:
                image = image.resize(size, Image.Resampling.LANCZOS)
            
            photo_image = ImageTk.PhotoImage(image)
            self._image_cache[cache_key] = photo_image
            return photo_image
            
        except Exception as e:
            print(f"Failed to load image {filename}: {e}")
            return None
    
    def load_font(self, family: str, size: int = 12, weight: str = "normal") -> Optional[tk.font.Font]:
        """
        Load a font resource.
        
        Args:
            family: Font family name
            size: Font size
            weight: Font weight (normal, bold)
            
        Returns:
            Font object
        """
        cache_key = f"{family}_{size}_{weight}"
        
        if cache_key in self._font_cache:
            return self._font_cache[cache_key]
        
        try:
            font = tk.font.Font(family=family, size=size, weight=weight)
            self._font_cache[cache_key] = font
            return font
            
        except Exception as e:
            print(f"Failed to load font {family}: {e}")
            return None
    
    def load_config(self, filename: str) -> Optional[Dict]:
        """
        Load a JSON configuration file.
        
        Args:
            filename: Config filename
            
        Returns:
            Configuration dictionary or None if not found
        """
        if filename in self._config_cache:
            return self._config_cache[filename]
        
        resource_path = self.find_resource(filename)
        if not resource_path:
            return None
        
        try:
            with open(resource_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            self._config_cache[filename] = config
            return config
            
        except Exception as e:
            print(f"Failed to load config {filename}: {e}")
            return None
    
    def save_config(self, filename: str, config: Dict):
        """
        Save a configuration to file.
        
        Args:
            filename: Config filename
            config: Configuration dictionary
        """
        try:
            # Save to first writable resource path
            for path in self._resource_paths:
                if path.exists() and os.access(path, os.W_OK):
                    config_path = path / filename
                    with open(config_path, 'w', encoding='utf-8') as f:
                        json.dump(config, f, indent=2)
                    
                    # Update cache
                    self._config_cache[filename] = config
                    return
            
            # If no writable path found, create in current directory
            config_path = Path.cwd() / filename
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2)
            
            self._config_cache[filename] = config
            
        except Exception as e:
            print(f"Failed to save config {filename}: {e}")
    
    def clear_cache(self):
        """Clear all resource caches."""
        self._image_cache.clear()
        self._font_cache.clear()
        self._config_cache.clear()
    
    def get_cache_info(self) -> Dict[str, int]:
        """Get information about cached resources."""
        return {
            "images": len(self._image_cache),
            "fonts": len(self._font_cache),
            "configs": len(self._config_cache)
        }
    
    def preload_images(self, image_list: list):
        """Preload a list of images."""
        for image_info in image_list:
            if isinstance(image_info, str):
                self.load_image(image_info)
            elif isinstance(image_info, dict):
                filename = image_info.get('filename')
                size = image_info.get('size')
                if filename:
                    self.load_image(filename, size)
    
    def create_placeholder_image(self, size: tuple, color: str = "#cccccc") -> ImageTk.PhotoImage:
        """
        Create a placeholder image.
        
        Args:
            size: Image size as (width, height)
            color: Background color
            
        Returns:
            PhotoImage object
        """
        cache_key = f"placeholder_{size}_{color}"
        
        if cache_key in self._image_cache:
            return self._image_cache[cache_key]
        
        try:
            image = Image.new('RGB', size, color)
            photo_image = ImageTk.PhotoImage(image)
            self._image_cache[cache_key] = photo_image
            return photo_image
            
        except Exception as e:
            print(f"Failed to create placeholder image: {e}")
            return None
