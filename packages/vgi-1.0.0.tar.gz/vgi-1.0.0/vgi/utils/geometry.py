"""
Geometric utility classes for VGI.
"""

from typing import Union, Tuple
from dataclasses import dataclass
import math


@dataclass
class Point:
    """Represents a 2D point with x and y coordinates."""
    
    x: float
    y: float
    
    def __init__(self, x: Union[int, float] = 0, y: Union[int, float] = 0):
        self.x = float(x)
        self.y = float(y)
    
    def distance_to(self, other: 'Point') -> float:
        """Calculate distance to another point."""
        dx = self.x - other.x
        dy = self.y - other.y
        return math.sqrt(dx * dx + dy * dy)
    
    def move(self, dx: float, dy: float) -> 'Point':
        """Move point by offset and return new point."""
        return Point(self.x + dx, self.y + dy)
    
    def __add__(self, other: 'Point') -> 'Point':
        return Point(self.x + other.x, self.y + other.y)
    
    def __sub__(self, other: 'Point') -> 'Point':
        return Point(self.x - other.x, self.y - other.y)
    
    def __mul__(self, scalar: float) -> 'Point':
        return Point(self.x * scalar, self.y * scalar)
    
    def __truediv__(self, scalar: float) -> 'Point':
        return Point(self.x / scalar, self.y / scalar)
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, Point):
            return False
        return abs(self.x - other.x) < 1e-6 and abs(self.y - other.y) < 1e-6
    
    def __repr__(self) -> str:
        return f"Point({self.x}, {self.y})"
    
    def to_tuple(self) -> Tuple[float, float]:
        """Convert to tuple."""
        return (self.x, self.y)
    
    def to_int_tuple(self) -> Tuple[int, int]:
        """Convert to integer tuple."""
        return (int(self.x), int(self.y))


@dataclass
class Size:
    """Represents a 2D size with width and height."""
    
    width: float
    height: float
    
    def __init__(self, width: Union[int, float] = 0, height: Union[int, float] = 0):
        self.width = float(width)
        self.height = float(height)
    
    @property
    def area(self) -> float:
        """Calculate area."""
        return self.width * self.height
    
    @property
    def aspect_ratio(self) -> float:
        """Calculate aspect ratio (width/height)."""
        return self.width / self.height if self.height != 0 else 0
    
    def scale(self, factor: float) -> 'Size':
        """Scale size by factor and return new size."""
        return Size(self.width * factor, self.height * factor)
    
    def scale_to_fit(self, target: 'Size') -> 'Size':
        """Scale to fit within target size while maintaining aspect ratio."""
        if self.width == 0 or self.height == 0:
            return Size(0, 0)
        
        scale_x = target.width / self.width
        scale_y = target.height / self.height
        scale = min(scale_x, scale_y)
        
        return Size(self.width * scale, self.height * scale)
    
    def scale_to_fill(self, target: 'Size') -> 'Size':
        """Scale to fill target size while maintaining aspect ratio."""
        if self.width == 0 or self.height == 0:
            return target
        
        scale_x = target.width / self.width
        scale_y = target.height / self.height
        scale = max(scale_x, scale_y)
        
        return Size(self.width * scale, self.height * scale)
    
    def __add__(self, other: 'Size') -> 'Size':
        return Size(self.width + other.width, self.height + other.height)
    
    def __sub__(self, other: 'Size') -> 'Size':
        return Size(self.width - other.width, self.height - other.height)
    
    def __mul__(self, scalar: float) -> 'Size':
        return Size(self.width * scalar, self.height * scalar)
    
    def __truediv__(self, scalar: float) -> 'Size':
        return Size(self.width / scalar, self.height / scalar)
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, Size):
            return False
        return abs(self.width - other.width) < 1e-6 and abs(self.height - other.height) < 1e-6
    
    def __repr__(self) -> str:
        return f"Size({self.width}, {self.height})"
    
    def to_tuple(self) -> Tuple[float, float]:
        """Convert to tuple."""
        return (self.width, self.height)
    
    def to_int_tuple(self) -> Tuple[int, int]:
        """Convert to integer tuple."""
        return (int(self.width), int(self.height))


@dataclass
class Rect:
    """Represents a rectangle with position and size."""
    
    x: float
    y: float
    width: float
    height: float
    
    def __init__(
        self, 
        x: Union[int, float] = 0, 
        y: Union[int, float] = 0, 
        width: Union[int, float] = 0, 
        height: Union[int, float] = 0
    ):
        self.x = float(x)
        self.y = float(y)
        self.width = float(width)
        self.height = float(height)
    
    @property
    def position(self) -> Point:
        """Get position as Point."""
        return Point(self.x, self.y)
    
    @position.setter
    def position(self, point: Point):
        """Set position from Point."""
        self.x = point.x
        self.y = point.y
    
    @property
    def size(self) -> Size:
        """Get size as Size."""
        return Size(self.width, self.height)
    
    @size.setter
    def size(self, size: Size):
        """Set size from Size."""
        self.width = size.width
        self.height = size.height
    
    @property
    def left(self) -> float:
        """Left edge x-coordinate."""
        return self.x
    
    @property
    def right(self) -> float:
        """Right edge x-coordinate."""
        return self.x + self.width
    
    @property
    def top(self) -> float:
        """Top edge y-coordinate."""
        return self.y
    
    @property
    def bottom(self) -> float:
        """Bottom edge y-coordinate."""
        return self.y + self.height
    
    @property
    def center(self) -> Point:
        """Center point."""
        return Point(self.x + self.width / 2, self.y + self.height / 2)
    
    @property
    def area(self) -> float:
        """Rectangle area."""
        return self.width * self.height
    
    def contains_point(self, point: Point) -> bool:
        """Check if rectangle contains a point."""
        return (self.x <= point.x <= self.right and 
                self.y <= point.y <= self.bottom)
    
    def contains_rect(self, other: 'Rect') -> bool:
        """Check if rectangle completely contains another rectangle."""
        return (self.x <= other.x and 
                self.y <= other.y and 
                self.right >= other.right and 
                self.bottom >= other.bottom)
    
    def intersects(self, other: 'Rect') -> bool:
        """Check if rectangle intersects with another rectangle."""
        return not (self.right < other.x or 
                   other.right < self.x or 
                   self.bottom < other.y or 
                   other.bottom < self.y)
    
    def intersection(self, other: 'Rect') -> Optional['Rect']:
        """Get intersection rectangle with another rectangle."""
        if not self.intersects(other):
            return None
        
        left = max(self.x, other.x)
        top = max(self.y, other.y)
        right = min(self.right, other.right)
        bottom = min(self.bottom, other.bottom)
        
        return Rect(left, top, right - left, bottom - top)
    
    def union(self, other: 'Rect') -> 'Rect':
        """Get union rectangle with another rectangle."""
        left = min(self.x, other.x)
        top = min(self.y, other.y)
        right = max(self.right, other.right)
        bottom = max(self.bottom, other.bottom)
        
        return Rect(left, top, right - left, bottom - top)
    
    def move(self, dx: float, dy: float) -> 'Rect':
        """Move rectangle by offset and return new rectangle."""
        return Rect(self.x + dx, self.y + dy, self.width, self.height)
    
    def resize(self, dw: float, dh: float) -> 'Rect':
        """Resize rectangle and return new rectangle."""
        return Rect(self.x, self.y, self.width + dw, self.height + dh)
    
    def inflate(self, dx: float, dy: float) -> 'Rect':
        """Inflate rectangle (grow/shrink from center) and return new rectangle."""
        return Rect(self.x - dx, self.y - dy, self.width + 2*dx, self.height + 2*dy)
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, Rect):
            return False
        return (abs(self.x - other.x) < 1e-6 and 
                abs(self.y - other.y) < 1e-6 and 
                abs(self.width - other.width) < 1e-6 and 
                abs(self.height - other.height) < 1e-6)
    
    def __repr__(self) -> str:
        return f"Rect({self.x}, {self.y}, {self.width}, {self.height})"
    
    def to_tuple(self) -> Tuple[float, float, float, float]:
        """Convert to tuple (x, y, width, height)."""
        return (self.x, self.y, self.width, self.height)
    
    def to_int_tuple(self) -> Tuple[int, int, int, int]:
        """Convert to integer tuple."""
        return (int(self.x), int(self.y), int(self.width), int(self.height))
