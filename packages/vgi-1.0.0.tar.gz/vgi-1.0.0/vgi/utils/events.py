"""
Event handling system for VGI.
"""

from typing import Any, Dict, Optional
from dataclasses import dataclass


@dataclass
class Event:
    """
    Represents an event in the VGI system.
    
    Events can bubble up through the widget hierarchy and be stopped
    at any point by setting the stopped property to True.
    """
    
    name: str
    source: Any
    data: Dict[str, Any]
    stopped: bool = False
    
    def __init__(self, name: str, source: Any, *args, **kwargs):
        self.name = name
        self.source = source
        self.data = kwargs
        self.stopped = False
        
        # Add positional arguments as numbered data
        for i, arg in enumerate(args):
            self.data[f'arg_{i}'] = arg
    
    def stop(self):
        """Stop event propagation."""
        self.stopped = True
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get event data."""
        return self.data.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set event data."""
        self.data[key] = value


class EventHandler:
    """
    Base class for handling events in VGI widgets.
    
    Provides a clean interface for registering and managing event handlers.
    """
    
    def __init__(self):
        self._handlers: Dict[str, list] = {}
    
    def on(self, event_name: str, handler):
        """Register an event handler."""
        if event_name not in self._handlers:
            self._handlers[event_name] = []
        self._handlers[event_name].append(handler)
    
    def off(self, event_name: str, handler=None):
        """Remove event handler(s)."""
        if event_name in self._handlers:
            if handler is None:
                self._handlers[event_name] = []
            elif handler in self._handlers[event_name]:
                self._handlers[event_name].remove(handler)
    
    def emit(self, event_name: str, *args, **kwargs):
        """Emit an event."""
        if event_name in self._handlers:
            event = Event(event_name, self, *args, **kwargs)
            for handler in self._handlers[event_name]:
                try:
                    handler(event)
                    if event.stopped:
                        break
                except Exception as e:
                    print(f"Error in event handler: {e}")
            return event
        return None
    
    def has_handler(self, event_name: str) -> bool:
        """Check if there are handlers for an event."""
        return event_name in self._handlers and len(self._handlers[event_name]) > 0
