"""
VGI - Professional Modern GUI Library for Python
A powerful, flexible, and easy-to-use GUI framework for creating stunning applications.
"""

from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="vgi",
    version="1.0.0",
    author="VGI Team",
    author_email="contact@vgi.dev",
    description="Professional Modern GUI Library for Python - Create stunning applications with ease",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/vgi-team/vgi",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Software Development :: User Interfaces",
        "Topic :: Desktop Environment",
    ],
    python_requires=">=3.8",
    install_requires=[
        "tkinter-modernui>=1.0.0",
        "Pillow>=9.0.0",
        "numpy>=1.21.0",
        "typing-extensions>=4.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.991",
        ],
        "examples": [
            "matplotlib>=3.5.0",
            "requests>=2.28.0",
        ],
    },
    include_package_data=True,
    package_data={
        "vgi": ["assets/*", "themes/*"],
    },
    entry_points={
        "console_scripts": [
            "vgi-demo=vgi.examples.demo:main",
        ],
    },
    keywords="gui, ui, interface, modern, professional, desktop, application, framework",
    project_urls={
        "Bug Reports": "https://github.com/vgi-team/vgi/issues",
        "Source": "https://github.com/vgi-team/vgi",
        "Documentation": "https://vgi.readthedocs.io/",
    },
)
