"""VGI Test Suite."""
