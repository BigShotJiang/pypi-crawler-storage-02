"""
Basic tests for VGI package installation and core functionality.
"""

import unittest
import sys
from unittest.mock import patch, MagicMock


class TestVGIImport(unittest.TestCase):
    """Test that VGI can be imported and basic components work."""
    
    def test_import_vgi(self):
        """Test that VGI can be imported without errors."""
        try:
            import vgi
            self.assertTrue(hasattr(vgi, '__version__'))
            self.assertEqual(vgi.__version__, "1.0.0")
        except ImportError as e:
            self.fail(f"Failed to import VGI: {e}")
    
    def test_import_core_components(self):
        """Test that core components can be imported."""
        try:
            import vgi
            # Test core classes
            self.assertTrue(hasattr(vgi, 'Application'))
            self.assertTrue(hasattr(vgi, 'Window'))
            self.assertTrue(hasattr(vgi, 'Widget'))
            
            # Test basic components
            self.assertTrue(hasattr(vgi, 'Button'))
            self.assertTrue(hasattr(vgi, 'Label'))
            self.assertTrue(hasattr(vgi, 'Input'))
            
            # Test layouts
            self.assertTrue(hasattr(vgi, 'VBox'))
            self.assertTrue(hasattr(vgi, 'HBox'))
            self.assertTrue(hasattr(vgi, 'Grid'))
            
        except Exception as e:
            self.fail(f"Failed to import core components: {e}")
    
    def test_create_application(self):
        """Test that Application can be created."""
        import vgi
        
        # Mock Tkinter to avoid GUI creation in tests
        with patch('tkinter.Tk') as mock_tk:
            mock_root = MagicMock()
            mock_tk.return_value = mock_root
            
            app = vgi.Application()
            self.assertIsNotNone(app)
            self.assertIsInstance(app, vgi.Application)
            mock_tk.assert_called_once()
    
    def test_create_button(self):
        """Test that Button can be created."""
        import vgi
        
        button = vgi.Button(text="Test Button")
        self.assertIsNotNone(button)
        self.assertEqual(button.text, "Test Button")
        self.assertIsInstance(button, vgi.Button)
    
    def test_create_label(self):
        """Test that Label can be created."""
        import vgi
        
        label = vgi.Label(text="Test Label")
        self.assertIsNotNone(label)
        self.assertEqual(label.text, "Test Label")
        self.assertIsInstance(label, vgi.Label)
    
    def test_create_input(self):
        """Test that Input can be created."""
        import vgi
        
        input_field = vgi.Input(placeholder="Test Input")
        self.assertIsNotNone(input_field)
        self.assertEqual(input_field.placeholder, "Test Input")
        self.assertIsInstance(input_field, vgi.Input)
    
    def test_create_layouts(self):
        """Test that layout containers can be created."""
        import vgi
        
        # Test VBox
        vbox = vgi.VBox(spacing=10)
        self.assertIsNotNone(vbox)
        self.assertIsInstance(vbox, vgi.VBox)
        
        # Test HBox
        hbox = vgi.HBox(spacing=10)
        self.assertIsNotNone(hbox)
        self.assertIsInstance(hbox, vgi.HBox)
        
        # Test Grid
        grid = vgi.Grid(rows=3, columns=3)
        self.assertIsNotNone(grid)
        self.assertIsInstance(grid, vgi.Grid)


class TestStylingSystem(unittest.TestCase):
    """Test the styling and theming system."""
    
    def test_color_creation(self):
        """Test Color class functionality."""
        import vgi
        
        # Test hex color
        color = vgi.Color.from_hex("#FF0000")
        self.assertEqual(color.r, 255)
        self.assertEqual(color.g, 0)
        self.assertEqual(color.b, 0)
        
        # Test named color
        blue = vgi.Color.from_name("blue")
        self.assertEqual(blue.r, 0)
        self.assertEqual(blue.g, 0)
        self.assertEqual(blue.b, 255)
        
        # Test color manipulation
        darker = color.darken(0.2)
        self.assertNotEqual(darker.to_hex(), color.to_hex())
    
    def test_theme_creation(self):
        """Test Theme functionality."""
        import vgi
        
        theme = vgi.Theme("Test Theme")
        self.assertEqual(theme.name, "Test Theme")
        
        # Test setting widget styles
        theme.set_widget_style("button", "background_color", "#FF0000")
        styles = theme.get_widget_styles("button")
        self.assertEqual(styles["background_color"], "#FF0000")


class TestValidationSystem(unittest.TestCase):
    """Test the validation system."""
    
    def test_validator_creation(self):
        """Test Validator functionality."""
        import vgi
        
        validator = vgi.Validator().required().min_length(3)
        
        # Test valid input
        self.assertTrue(validator.validate("hello"))
        
        # Test invalid input (too short)
        self.assertFalse(validator.validate("hi"))
        
        # Test invalid input (empty)
        self.assertFalse(validator.validate(""))
    
    def test_email_validator(self):
        """Test email validation."""
        import vgi
        
        validator = vgi.Validator.create_email_validator()
        
        # Test valid email
        self.assertTrue(validator.validate("test@example.com"))
        
        # Test invalid email
        self.assertFalse(validator.validate("invalid-email"))


if __name__ == '__main__':
    # Run tests
    unittest.main(verbosity=2)
