# Contributing to VGI

We welcome contributions to VGI! This document provides guidelines for contributing to the project.

## Getting Started

### Development Environment Setup

1. **Fork and clone the repository**
   ```bash
   git clone https://github.com/yourusername/vgi.git
   cd vgi
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install development dependencies**
   ```bash
   pip install -e .[dev]
   # or
   pip install -r requirements-dev.txt
   ```

4. **Verify installation**
   ```bash
   python -m vgi.examples.demo
   ```

### Development Workflow

1. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes**
   - Write code following our style guidelines
   - Add tests for new functionality
   - Update documentation as needed

3. **Run tests and checks**
   ```bash
   # Run tests
   pytest
   
   # Check code style
   black --check .
   flake8 .
   
   # Type checking
   mypy vgi/
   ```

4. **Commit your changes**
   ```bash
   git add .
   git commit -m "Add feature: description of your changes"
   ```

5. **Push and create pull request**
   ```bash
   git push origin feature/your-feature-name
   ```

## Code Style Guidelines

### Python Code Style

We follow PEP 8 with some specific preferences:

- **Line length**: 88 characters (Black default)
- **Imports**: Use isort for import organization
- **Type hints**: Required for all public APIs
- **Docstrings**: Google style docstrings

### Code Formatting

We use Black for automatic code formatting:

```bash
# Format all code
black .

# Check formatting
black --check .
```

### Import Organization

Use isort for consistent import ordering:

```bash
# Sort imports
isort .

# Check import sorting
isort --check-only .
```

## Testing Guidelines

### Test Structure

```
tests/
├── unit/                 # Unit tests
│   ├── test_components/
│   ├── test_styling/
│   └── test_core/
├── integration/          # Integration tests
└── conftest.py          # Pytest configuration
```

### Writing Tests

1. **Use descriptive test names**
   ```python
   def test_button_click_triggers_callback():
       # Test implementation
   ```

2. **Follow AAA pattern**
   ```python
   def test_input_validation():
       # Arrange
       validator = vgi.Validator().required().min_length(3)
       input_field = vgi.Input(validator=validator)
       
       # Act
       input_field.value = "ab"
       
       # Assert
       assert not input_field.is_valid
   ```

3. **Test edge cases**
   - Empty inputs
   - Boundary values
   - Error conditions

4. **Use fixtures for common setup**
   ```python
   @pytest.fixture
   def sample_app():
       app = vgi.Application()
       yield app
       app.quit()
   ```

### Running Tests

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/unit/test_components/test_button.py

# Run with coverage
pytest --cov=vgi --cov-report=html

# Run only fast tests
pytest -m "not slow"
```

## Documentation Guidelines

### Docstring Format

Use Google style docstrings:

```python
def create_button(text: str, style: str = "primary") -> Button:
    """Create a button with specified text and style.
    
    Args:
        text: The button text to display
        style: The button style ("primary", "secondary", etc.)
        
    Returns:
        A new Button instance
        
    Raises:
        ValueError: If style is not recognized
        
    Example:
        >>> button = create_button("Click Me", "primary")
        >>> button.text
        'Click Me'
    """
```

### README Updates

When adding new features:

1. Update the main README.md
2. Add examples showing the new feature
3. Update the API reference section
4. Add to the changelog

### Code Examples

All public APIs should have working examples:

```python
# Good: Complete, runnable example
import vgi

app = vgi.Application()
window = app.create_window(title="Example")
button = vgi.Button("Click Me", on_click=lambda: print("Clicked!"))
window.add_widget(button)
app.run()
```

## Component Development

### Creating New Components

1. **Inherit from Widget base class**
   ```python
   class MyComponent(Widget):
       def __init__(self, **kwargs):
           super().__init__(**kwargs)
           # Component-specific initialization
       
       def _create_tk_widget(self, parent_tk):
           # Create underlying Tkinter widget
           return tk.Label(parent_tk)
       
       def _apply_style(self):
           # Apply computed styles to widget
           pass
   ```

2. **Add to __init__.py**
   ```python
   from .my_component import MyComponent
   __all__.append("MyComponent")
   ```

3. **Create tests**
   ```python
   class TestMyComponent:
       def test_creation(self):
           component = MyComponent()
           assert component is not None
   ```

4. **Add documentation**
   - Docstrings with examples
   - Add to README component list
   - Create demo in examples

### Styling Integration

Components should integrate with the theming system:

```python
def _configure_default_styles(self):
    """Configure default component styles."""
    self._style.update({
        'background_color': '#FFFFFF',
        'text_color': '#000000',
        'border_width': 1,
        'border_radius': 4,
    })

def _apply_style(self):
    """Apply computed styles to the component."""
    if not self._tk_widget:
        return
    
    bg_color = self.get_style('background_color', '#FFFFFF')
    text_color = self.get_style('text_color', '#000000')
    
    self._tk_widget.config(bg=bg_color, fg=text_color)
```

## Issue Guidelines

### Reporting Bugs

When reporting bugs, include:

1. **Environment information**
   - Python version
   - VGI version
   - Operating system
   - Tkinter version

2. **Reproduction steps**
   - Minimal code example
   - Expected behavior
   - Actual behavior
   - Screenshots if applicable

3. **Error messages**
   - Full stack trace
   - Any relevant log output

### Feature Requests

For feature requests, provide:

1. **Use case description**
   - What problem does this solve?
   - Who would benefit?

2. **Proposed solution**
   - API design suggestions
   - Implementation ideas

3. **Alternatives considered**
   - Other approaches
   - Workarounds

## Pull Request Guidelines

### Before Submitting

1. **Ensure all tests pass**
   ```bash
   pytest
   ```

2. **Check code quality**
   ```bash
   black --check .
   flake8 .
   mypy vgi/
   ```

3. **Update documentation**
   - Add docstrings
   - Update README if needed
   - Add examples

4. **Add changelog entry**
   - Update CHANGELOG.md
   - Follow existing format

### Pull Request Format

Use this template for pull requests:

```markdown
## Description
Brief description of the changes.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Tests added/updated
- [ ] All tests pass
- [ ] Manual testing completed

## Documentation
- [ ] Docstrings added/updated
- [ ] README updated
- [ ] Examples added

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] No breaking changes (or documented)
```

### Review Process

1. **Automated checks**
   - All tests must pass
   - Code style checks
   - Type checking

2. **Manual review**
   - Code quality
   - Architecture consistency
   - Documentation completeness

3. **Testing**
   - Feature functionality
   - Edge cases
   - Cross-platform compatibility

## Architecture Guidelines

### Design Principles

1. **Consistency**: Follow established patterns
2. **Simplicity**: Keep APIs simple and intuitive
3. **Extensibility**: Design for future enhancements
4. **Performance**: Consider efficiency implications
5. **Compatibility**: Maintain backward compatibility

### Code Organization

```
vgi/
├── core/           # Core framework classes
├── components/     # UI components
├── styling/        # Theming and styling
├── utils/          # Utility functions
└── examples/       # Example applications
```

### Naming Conventions

- **Classes**: PascalCase (`Button`, `VBox`)
- **Functions/Methods**: snake_case (`create_window`, `set_style`)
- **Constants**: UPPER_SNAKE_CASE (`DEFAULT_THEME`)
- **Private members**: Leading underscore (`_internal_method`)

## Release Process

### Version Numbers

We follow Semantic Versioning:
- **Major** (1.0.0): Breaking changes
- **Minor** (1.1.0): New features (backward compatible)
- **Patch** (1.0.1): Bug fixes

### Release Checklist

1. **Update version numbers**
   - `pyproject.toml`
   - `vgi/__init__.py`

2. **Update documentation**
   - CHANGELOG.md
   - README.md version references

3. **Create release**
   - Git tag
   - GitHub release
   - PyPI upload

## Community Guidelines

### Code of Conduct

We are committed to providing a welcoming and inclusive environment:

1. **Be respectful** of different viewpoints and experiences
2. **Be collaborative** in discussions and reviews
3. **Be constructive** in feedback and criticism
4. **Be patient** with newcomers and questions

### Communication

- **GitHub Issues**: Bug reports and feature requests
- **GitHub Discussions**: General questions and ideas
- **Pull Requests**: Code contributions and reviews

## Getting Help

If you need help:

1. **Check documentation**: README and API docs
2. **Search issues**: Existing solutions
3. **Ask questions**: GitHub Discussions
4. **Contact maintainers**: For sensitive issues

Thank you for contributing to VGI!
