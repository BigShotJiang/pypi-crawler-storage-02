"""Test package for MCP Background Job Server."""
