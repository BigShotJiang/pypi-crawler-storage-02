"""Unit tests for MCP Background Job Server."""
