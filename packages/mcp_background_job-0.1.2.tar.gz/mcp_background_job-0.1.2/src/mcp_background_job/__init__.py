"""MCP Background Job Server - Asynchronous process management."""

__version__ = "0.1.0"
