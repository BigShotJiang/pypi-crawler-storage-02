"""Módulo da classe model para saldo da agressão."""

from .. import conf


class MediaMovelModel:
    """Classe model do saldo da agressao."""

    def __init__(self):
        """Construtor da média móvel."""
        pass
