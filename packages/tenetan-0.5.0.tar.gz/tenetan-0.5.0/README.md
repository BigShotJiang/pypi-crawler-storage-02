# Tenetan - *Te*mporal *Ne*twork *An*alysis library for Python


## Installation

Install this package from PyPI:

`python -m pip install tenetan`
