# Freqtrade Client

# ![freqtrade](https://raw.githubusercontent.com/freqtrade/freqtrade/develop/docs/assets/freqtrade_poweredby.svg)

Provides a minimal rest client for the freqtrade rest api.

Please check out the [main project](https://github.com/freqtrade/freqtrade) for more information or details.
