from ._emmett_core import __version__  # noqa: F401
