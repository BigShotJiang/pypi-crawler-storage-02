def main() -> None:
    print("Hello from sklearn-container!")
