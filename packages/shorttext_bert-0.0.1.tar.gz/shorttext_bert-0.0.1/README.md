# PyShortTextCategorization-BERT

This Python package receives the modules from
[PyShortTextCategorization](https://github.com/stephenhky/PyShortTextCategorization)
that uses PyTorch and HuggingFace.

## Installation

To install, type in command line:

```aiignore
pip install shorttext-bert
```

To know how to use it, please refer to the [documentation](https://pyshorttextcategorization-bert.readthedocs.io/).
