from setuptools import setup

setup(
    name="payday",
    version="0.1.0",
    description="a library for generating bind and reverse shell payloads across a disverse set of platforms",
    author="lewis patten",
    author_email="lpatten1729@gmail.com",
    maintainer="lewis patten",
    maintainer_email="lpatten1729@gmail.com",
    license="GPL2",
    packages=["payday"],
    requires=[],
    classifiers=[],
)
