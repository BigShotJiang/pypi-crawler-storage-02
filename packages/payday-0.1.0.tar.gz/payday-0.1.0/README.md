# payday

> "Guys, the thermal drill—go get it!"

payday is a python library for generating reverse and bind shell payloads, in a varienty of languages, for a variety of operating systems, and architectures.
it can generate bash/powershell one liners, source code, and compiled binaries.
garunteed to get those shells popping* 

(*terms and condtions apply)

## installation

TODO

## usage

TODO
