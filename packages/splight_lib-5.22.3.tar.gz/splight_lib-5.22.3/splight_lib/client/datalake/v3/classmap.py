COLLECTION_PREFIXS_MAP = {"routineEvaluations": "telemetry"}
