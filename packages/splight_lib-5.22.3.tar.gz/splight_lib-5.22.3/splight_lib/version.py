from importlib import metadata

__version__ = metadata.version("splight_lib")
