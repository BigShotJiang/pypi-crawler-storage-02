"""Artanis CLI package."""

from __future__ import annotations

__all__ = ["main"]

from .main import main
