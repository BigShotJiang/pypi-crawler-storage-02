from appodus_utils import Object


class Loci(Object):
    longitude: str
    latitude: str
