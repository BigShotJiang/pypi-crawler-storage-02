Welcome to selectolax's documentation!
======================================

API
===

.. toctree::
   :maxdepth: 2

   parser
   lexbor


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

