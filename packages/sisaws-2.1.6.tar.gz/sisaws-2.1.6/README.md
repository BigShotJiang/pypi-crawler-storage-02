[project]
name = "secmeasure"
version = "0.1.2"
description = "Librería oficial para interactuar con la API REST del SISA."
readme = { file = "README.md", content-type = "text/markdown" }
authors = [
    { name = "Conde", email = "billordowiyi@gmail.com" }
]
requires-python = ">=3.6"
license = { text = "MIT" }
