from .word_processor import WordProcessor
from .plural_agreement import IPluralAgreement