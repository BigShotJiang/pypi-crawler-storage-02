To be able to edit this field, the user needs to have access to the
group `Allow to change due date`.
