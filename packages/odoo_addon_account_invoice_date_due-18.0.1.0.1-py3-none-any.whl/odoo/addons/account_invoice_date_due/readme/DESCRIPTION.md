This module sets the invoice's due date field as editable (Even if the
invoice state is done and a Payment Term is set).

When the field is edited, the invoice's due date is updated, along with
the related invoice lines.
