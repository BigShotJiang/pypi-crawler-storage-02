Usage
=====

Here, there are a basic usage of this library in the following subsections.

For a more extensive example, see `pydwca-example repository <https://github.com/IEB-BIODATA/pydwca-examples>`_, which includes the data pipeline presented on the `SPNHC/TDWG 2024 conference <https://doi.org/10.3897/biss.8.137799>`_.

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   usage.dwca
   usage.eml
