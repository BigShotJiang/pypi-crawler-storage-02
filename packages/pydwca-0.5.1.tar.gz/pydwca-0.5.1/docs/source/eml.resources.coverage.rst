eml.resources.coverage package
==============================

GeographicCoverage Class
------------------------

.. automodule:: eml.resources.coverage.geo_coverage
   :members:
   :undoc-members:
   :show-inheritance:

TemporalCoverage Class
----------------------

.. automodule:: eml.resources.coverage.time_coverage
   :members:
   :undoc-members:
   :show-inheritance:

TaxonomicCoverage Class
-----------------------

.. automodule:: eml.resources.coverage.taxa_coverage
   :members:
   :undoc-members:
   :show-inheritance:
