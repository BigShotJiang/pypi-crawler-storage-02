from xml_common.xml_object import XMLObject
