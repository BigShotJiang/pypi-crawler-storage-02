from eml.base.metadata import EMLMetadata, EMLAdditionalMetadata
from eml.base.version import EMLVersion
from eml.base.eml import EML
