# flake8: noqa

from ubiops.api.core_api import CoreApi
