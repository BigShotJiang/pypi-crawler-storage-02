# coding: utf-8

"""
    UbiOps

    Client Library to interact with the UbiOps API.
"""


from ubiops.models.deployment_request_update import DeploymentRequestUpdate


class ExperimentRunUpdate(DeploymentRequestUpdate):
    pass
