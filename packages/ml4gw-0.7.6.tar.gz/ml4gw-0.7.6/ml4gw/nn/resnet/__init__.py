from .resnet_1d import ResNet1D
from .resnet_2d import ResNet2D
