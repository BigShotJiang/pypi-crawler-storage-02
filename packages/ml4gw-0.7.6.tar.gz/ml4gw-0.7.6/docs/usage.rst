Example Usage
=============

Below are some examples of the core functionality of `ml4gw`.
These are still a work in progress, and we will be adding more examples over time.

.. toctree::
   :maxdepth: 1
   :caption: Examples

   examples/augmentations
   examples/distributions
   examples/gw
   examples/transforms.qtransform
   examples/transforms.spectral
   examples/transforms.whitening
   
