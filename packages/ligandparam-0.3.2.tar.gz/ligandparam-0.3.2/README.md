# Ligand Parametrization

## Overview
This is a Python package designed to provide a simple workflow for ligand parameterization. It automates many of the 
key features encountered by users, including...

## Documentation

The online documentation is located here: https://ligandparam.readthedocs.io/en/latest/

