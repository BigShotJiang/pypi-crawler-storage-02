from dandy.intel import BaseIntel


class SmsIntel(BaseIntel):
    body: str