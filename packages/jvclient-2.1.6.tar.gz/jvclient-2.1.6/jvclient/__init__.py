"""
jvclient package initialization.

This package provides a library of utils and components for action ui development.
"""

from importlib.metadata import version

__version__ = version("jvclient")
