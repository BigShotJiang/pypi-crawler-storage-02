from .SVM import SVM
from .Bayes import Bayes
from .LogisticRegression import LogisticRegression