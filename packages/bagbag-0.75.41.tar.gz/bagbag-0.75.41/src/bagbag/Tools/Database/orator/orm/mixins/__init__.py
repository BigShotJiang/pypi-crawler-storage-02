# -*- coding: utf-8 -*-

from .soft_deletes import SoftDeletes
