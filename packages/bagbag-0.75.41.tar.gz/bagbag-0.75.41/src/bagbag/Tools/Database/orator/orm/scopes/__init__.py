# -*- coding: utf-8 -*-

from .scope import Scope
from .soft_deleting import SoftDeletingScope
