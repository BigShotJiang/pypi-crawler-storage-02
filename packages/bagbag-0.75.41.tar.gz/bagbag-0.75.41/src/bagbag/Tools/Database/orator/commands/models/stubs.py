# -*- coding: utf-8 -*-

MODEL_DEFAULT_STUB = """from orator import Model


class DummyClass(Model):

    pass
"""
