from .MetricServer import MetricServer
from .PushGateway import PushGateway
from . import Utils

class Prometheus:
    MetricServer
    PushGateway
    Utils