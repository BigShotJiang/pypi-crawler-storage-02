This module enables in-payment management for all your accounting.

Should not be installed with Enterprise Edition accounting.
