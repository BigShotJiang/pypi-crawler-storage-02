2025-02-10 Version: 1.0.9
- Update API GetEffectivePolicy: add param TagKeys.
- Update API GetEffectivePolicy: update response param.


2024-09-30 Version: 1.0.8
- Update API ListSupportResourceTypes: update response param.


2024-03-14 Version: 1.0.7
- Update API DisablePolicyType: add param OpenType.
- Update API EnablePolicyType: add param OpenType.
- Update API GetPolicyEnableStatus: add param OpenType.
- Update API ListTargetsForPolicy: update response param.
- Update API UntagResources: update param TagKey.


2023-12-08 Version: 1.0.6
- Generated python 2018-08-28 for Tag.

2023-06-14 Version: 1.0.5
- Add EnablePolicy APIs.

2022-07-06 Version: 1.0.4
- Add EnablePolicy APIs.

2022-06-30 Version: 1.0.3
- Add Policy APIs.

2021-08-29 Version: 1.0.2
- AMP Version Change.

2021-06-03 Version: 1.0.1
- Generated python 2018-08-28 for Tag.

2020-12-30 Version: 1.0.0
- AMP Version Change.

2020-12-30 Version: 1.0.0
- AMP Version Change.

