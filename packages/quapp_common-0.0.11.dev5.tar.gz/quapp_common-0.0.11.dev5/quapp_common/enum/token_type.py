"""
    QApp Platform Project token_type.py Copyright © CITYNOW Co. Ltd. All rights reserved.
"""
from ..enum.base_enum import BaseEnum


class TokenType(BaseEnum):
    BEARER = 'Bearer'
