from __future__ import annotations

from sqlalchemy.ext import declarative

ORMBase = declarative.declarative_base()
