__all__ = ['DottifyKNFError']

class DottifyKNFError(Exception):
    pass


