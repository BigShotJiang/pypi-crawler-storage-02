```{include} ../CHANGELOG.md
:relative-docs: docs/
:relative-images:
```
## Version 2.1

- Added pydantic data classes for the PPF section of the workflow.
- Added utility methods for data classes that allow for transformation from json to dataclasses, from datacalss to pandas and the other way, along with other utilities.
- Added tests for all the utility functions.
- Added first draft of Uncertainty data class.