# Authors

## Contributors to this package
* Joao F. D. Rodrigues (2.-0 LCA consultants)
* Valentin Starlinger (2.-0 LCA consultants)
* Jonas Lindberg (2.-0 LCA consultants)
* Sander van Nielen (Aalborg University)
* Simon Schulte (Aalborg University)
* Mathieu Delpierre (2.-0 LCA consultants)
* Kevin Nhan (2.-0 LCA consultants)
* Maik Budzinski (Aalborg University)
* Miguel F. Astudillo (2.-0 LCA consultants)

## Getting The Data Right team
This package is part of the Getting The Data Right project. The full list of team members can be found [here](http://bonsai.pages.coderefinery.org/documentation/miscellaneous/authors.html). 

## Contact
Email [admin.gettingthedataright@aau.dk](mailto:admin.gettingthedataright@aau.dk) for enquiries.
