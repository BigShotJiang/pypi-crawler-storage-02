def main():
    print("Hello from pypi-test-coltg5!")


if __name__ == "__main__":
    main()
