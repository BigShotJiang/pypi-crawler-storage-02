"""
Constants related to IMS Caliper and events transformation into Caliper.
"""

CALIPER_EVENT_CONTEXT = 'http://purl.imsglobal.org/ctx/caliper/v1p2'
