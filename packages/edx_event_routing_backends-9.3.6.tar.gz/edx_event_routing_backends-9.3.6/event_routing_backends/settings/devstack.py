"""
Development settings for the event_routing_backends app.
"""


def plugin_settings(settings):  # pylint: disable=unused-argument
    """
    Override the default event_routing_backends app settings with development settings.
    """
    pass  # lint-amnesty, pylint: disable=unnecessary-pass
