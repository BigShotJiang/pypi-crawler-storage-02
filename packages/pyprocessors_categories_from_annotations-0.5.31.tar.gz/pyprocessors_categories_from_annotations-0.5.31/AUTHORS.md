# Authors

Contributors to pyprocessors_categories_from_annotations include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
