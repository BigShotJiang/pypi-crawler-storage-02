.. _decorators:


Decorators
##########


.. automodule:: kinto.core.decorators
    :members:
