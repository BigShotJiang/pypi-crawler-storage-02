Changelog
=========

.. changelog::
    :changelog-url: https://docs.kinto-storage.org/en/stable/changelog.html
    :github: https://github.com/Kinto/kinto/releases/
    :pypi: https://pypi.org/project/kinto/
