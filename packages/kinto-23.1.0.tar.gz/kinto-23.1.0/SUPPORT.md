# Support

If you're looking for support for Kinto, use [Github issues](https://github.com/Kinto/kinto/issues).
