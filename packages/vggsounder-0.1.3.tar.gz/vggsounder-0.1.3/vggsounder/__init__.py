from .labels import VGGSounder, VideoData

__version__ = "0.1.0"
__author__ = "Daniil Zverev"
__email__ = "daniil.zverev@tum.de"

__all__ = ["VGGSounder", "VideoData"]
