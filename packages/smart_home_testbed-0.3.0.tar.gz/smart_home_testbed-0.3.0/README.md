# smart-home-testbed

Various Smart Home devices' APIs,
for testing and development purposes.
