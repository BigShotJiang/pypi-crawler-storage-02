"""Karoo Array Telescope accelerated signal processing tools."""


# Automatically added by katversion
__version__ = '1.10.0'
