
# Automatically added by katversion
__version__ = '1.10.0'
