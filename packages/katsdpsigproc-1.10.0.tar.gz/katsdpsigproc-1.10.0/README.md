Assorted radio astronomy signal processing routines, with hardware acceleration.

Documentation is available on
[readthedocs](https://katsdpsigproc.readthedocs.io/).
