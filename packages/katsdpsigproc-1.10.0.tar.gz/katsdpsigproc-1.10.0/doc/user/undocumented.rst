Undocumented topics
===================

This user guide is not complete. The following areas (and it is likely to be an
incomplete list) are not yet covered, and you'll need to consult the reference
documentation or the source code for more information:

- Allocators and raw buffers
- Shared Virtual Memory (CUDA Managed Memory)
- Macros for computing rank statistics
- The modules for Radio Frequency Interference (RFI) detection
