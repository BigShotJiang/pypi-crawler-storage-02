.. katsdpsigproc documentation master file, created by
   sphinx-quickstart on Tue Oct 21 13:49:46 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to katsdpsigproc's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   user/index
   changelog
   katsdpsigproc


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

