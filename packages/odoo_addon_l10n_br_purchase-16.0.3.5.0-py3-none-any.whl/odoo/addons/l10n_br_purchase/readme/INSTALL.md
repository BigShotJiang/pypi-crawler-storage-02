This module depends on:

- purchase
- l10n_br_account
