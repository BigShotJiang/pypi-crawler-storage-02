from django.dispatch import Signal

refresh_token_revoked = Signal()

refresh_token_rotated = Signal()
