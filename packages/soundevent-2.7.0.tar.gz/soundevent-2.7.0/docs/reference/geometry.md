# Geometry Module

???+ info "Additional dependencies"

    To use the `soundevent.geometry` module you need to install some
    additional dependencies. Make sure you have them installed by running the
    following command:

    ```bash
    pip install soundevent[geometry]
    ```

::: soundevent.geometry
