from .CowsABull import play_bulls_and_cows
from .GuessNum import guess_the_number
from .RockPaper import play_rps

__add__=["play_bulls_and_cows", "guess_the_number", "play_rps"]