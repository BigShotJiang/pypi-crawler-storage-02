"""Miscellaneous helper functions (currently empty)."""
