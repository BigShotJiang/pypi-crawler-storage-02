zope.app.appsetup README
========================

This package provides application setup helpers for the Zope3 appserver.
