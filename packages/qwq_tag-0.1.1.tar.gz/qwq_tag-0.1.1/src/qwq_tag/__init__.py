from qwq_tag.qwq_tag import QwqTag
__all__ = ["QwqTag"]