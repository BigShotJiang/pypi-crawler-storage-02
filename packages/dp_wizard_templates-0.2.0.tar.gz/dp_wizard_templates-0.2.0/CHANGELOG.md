# CHANGELOG

## 0.2.0

- Link to ghpages [#7](https://github.com/opendp/dp-wizard-templates/pull/7)
- Add black, and a generated index.html [#6](https://github.com/opendp/dp-wizard-templates/pull/6)

## 0.1.0

Initial release