def FUNCTION_NAME(PARAMS):
    """
    This demonstrates how larger blocks of code can be built compositionally.
    """
    INNER_BLOCK
