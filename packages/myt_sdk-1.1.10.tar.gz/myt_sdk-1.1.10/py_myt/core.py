# MYT SDK Core Module
# This file is reserved for future core functionality

"""
MYT SDK核心模块

此模块保留用于未来的核心功能实现。
当前版本主要通过sdk_manager.py提供SDK管理功能。
"""

__all__ = []
