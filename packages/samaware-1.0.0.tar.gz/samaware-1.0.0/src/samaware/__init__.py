__version__ = '1.0.0'

# pretalx permissions required to access all SamAware features
# TODO: Think about the required permissions
REQUIRED_PERMISSIONS = 'submission.orga_update_submission'
