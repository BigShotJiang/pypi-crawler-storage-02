class ConnectionLimitError(Exception):
    """
    The connection pool has run out of available connections
    """
