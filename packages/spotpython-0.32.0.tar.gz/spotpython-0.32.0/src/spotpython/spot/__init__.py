"""
This module implements the Spot class.

"""

from .spot import Spot

__all__ = [
    "Spot",
]
