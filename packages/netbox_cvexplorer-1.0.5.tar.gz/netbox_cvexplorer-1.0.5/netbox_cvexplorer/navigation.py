from netbox.plugins import PluginMenuItem

menu_items = (
    PluginMenuItem(
        link='netbox_cvexplorer:cve_list',
        link_text='CVE Übersicht',
    ),
)