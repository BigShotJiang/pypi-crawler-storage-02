"""
Step type-specific test variants for universal step builder tests.
"""
