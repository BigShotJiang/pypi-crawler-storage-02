# eventlog

A Python package providing a base logger class and two types of internal local event busses.

## Structure
- `logger_base.py`: Base class for logging
- `event_bus.py`: Local event bus implementations
