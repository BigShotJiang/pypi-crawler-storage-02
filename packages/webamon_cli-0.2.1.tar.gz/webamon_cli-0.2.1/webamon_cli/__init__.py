"""Webamon Search CLI - The Google of Threat Intelligence.

Command-line interface for deep threat hunting across the web. Unbiased & unfiltered search.
"""

__version__ = "0.2.1"
__author__ = "Webamon"
__email__ = "info@webamon.com"
__description__ = "The Google of Threat Intelligence"