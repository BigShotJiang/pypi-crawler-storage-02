# ESD services Api client

This repository contains connectors to internal services:
- Beast
- Boxer
- Crystal
