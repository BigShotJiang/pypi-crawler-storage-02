"""Entry point for running the package directly with python -m code_error_detector."""

from pybughunt.cli import main

if __name__ == "__main__":
    main()
