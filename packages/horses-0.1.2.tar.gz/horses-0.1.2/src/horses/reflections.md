# Reflections
Always test the code to see if there are any errors.
Always use meaningful names, clear docstrings and comments, to avoid confusion.
Make sure everything is correctly indented, as it can give errors.
Import random module in order to use the random function.
Import sys when we need to access command line arguments or when we need to exit the program.
Use with when opening a file, to make sure it will closed.
 __name__ == "__main__" Will make sure that code runs only when the script is executed directly, not when imported.
Use try...except to handle errors in our program without crashing.

# AI Use Statement
I did not use any AI tools to complete this lab.