cue computer builder's kit.
