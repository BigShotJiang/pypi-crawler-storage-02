text = """
Always retry disabled!
"""
