text = """
Template not available!
Please check the path or add it first. 📝
"""
