from .aiogram_router import AiogramRouter

__all__ = ["AiogramRouter"]
