// This is used to determine that we're running the real hardware (not emulated)
int chik_vdf_is_emu = 0;
