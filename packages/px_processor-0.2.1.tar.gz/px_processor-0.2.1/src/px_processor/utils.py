"""Helper functions for validators."""
