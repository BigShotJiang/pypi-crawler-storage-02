"""JSON validator."""

from .main import JSONValidator

__all__: list[str] = ["JSONValidator"]
