"""Respona Dashboard MCP Server implementation."""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional, Union

import mcp.types as types
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
import mcp.server.stdio

from .client import client, APIError
from .config import config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create the MCP server
server = Server("respona-dashboard")


@server.list_tools()
async def handle_list_tools() -> List[types.Tool]:
    """List all available tools for the Respona Dashboard API."""
    return [
        # Ticket Management Tools
        types.Tool(
            name="get_tickets",
            description="Retrieve tickets with optional filtering and pagination",
            inputSchema={
                "type": "object",
                "properties": {
                    "status": {
                        "type": "string",
                        "description": "Filter tickets by status"
                    },
                    "priority": {
                        "type": "string", 
                        "description": "Filter tickets by priority"
                    },
                    "category": {
                        "type": "string",
                        "description": "Filter tickets by category"
                    },
                    "sourceChannel": {
                        "type": "string",
                        "description": "Filter tickets by source channel"
                    },
                    "assignedTo": {
                        "type": "string",
                        "description": "Filter tickets assigned to specific user"
                    },
                    "assignedTeam": {
                        "type": "string",
                        "description": "Filter tickets assigned to specific team"
                    },
                    "customer": {
                        "type": "string",
                        "description": "Filter tickets by customer"
                    },
                    "tags": {
                        "type": "string",
                        "description": "Filter tickets by tags (comma-separated)"
                    },
                    "dateFrom": {
                        "type": "string",
                        "description": "Filter tickets from date (YYYY-MM-DD)"
                    },
                    "dateTo": {
                        "type": "string",
                        "description": "Filter tickets to date (YYYY-MM-DD)"
                    },
                    "search": {
                        "type": "string",
                        "description": "Search term for ticket content"
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination",
                        "default": 1
                    },
                    "limit": {
                        "type": "integer", 
                        "description": "Number of tickets per page",
                        "default": 20
                    },
                    "sortBy": {
                        "type": "string",
                        "description": "Field to sort by"
                    },
                    "sortOrder": {
                        "type": "string",
                        "description": "Sort order (asc/desc)"
                    }
                }
            }
        ),
        
        types.Tool(
            name="get_ticket_stats",
            description="Get ticket statistics and metrics",
            inputSchema={"type": "object", "properties": {}}
        ),
        
        types.Tool(
            name="get_ticket_by_id",
            description="Retrieve a specific ticket by its ID",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Ticket ID"
                    }
                },
                "required": ["id"]
            }
        ),
        
        types.Tool(
            name="get_ticket_ai_analysis",
            description="Get AI analysis for a specific ticket",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Ticket ID"
                    }
                },
                "required": ["id"]
            }
        ),
        
        # Analytics Tools
        types.Tool(
            name="get_ai_flags_distribution",
            description="Get AI flags distribution for analytics dashboard",
            inputSchema={"type": "object", "properties": {}}
        ),
        
        types.Tool(
            name="get_similar_incidents",
            description="Get count of similar incidents for analytics",
            inputSchema={"type": "object", "properties": {}}
        ),
        
        types.Tool(
            name="get_source_channels_distribution",
            description="Get distribution of ticket source channels",
            inputSchema={"type": "object", "properties": {}}
        ),
        
        types.Tool(
            name="get_priority_distribution",
            description="Get distribution of ticket priorities",
            inputSchema={"type": "object", "properties": {}}
        ),
        
        types.Tool(
            name="get_status_distribution",
            description="Get distribution of ticket statuses",
            inputSchema={"type": "object", "properties": {}}
        ),
        
        types.Tool(
            name="get_dashboard_analytics",
            description="Get comprehensive analytics for dashboard (all analytics in one response)",
            inputSchema={"type": "object", "properties": {}}
        ),
        
        # AI Flags Tools
        types.Tool(
            name="get_analysis_flags",
            description="Get all flags for a specific AI analysis",
            inputSchema={
                "type": "object",
                "properties": {
                    "analysisId": {
                        "type": "string",
                        "description": "AI analysis ID"
                    },
                    "status": {
                        "type": "string",
                        "description": "Filter flags by status"
                    },
                    "flagType": {
                        "type": "string",
                        "description": "Filter flags by type"
                    }
                },
                "required": ["analysisId"]
            }
        ),
        
        types.Tool(
            name="get_analysis_flag_stats",
            description="Get flag statistics for an AI analysis",
            inputSchema={
                "type": "object",
                "properties": {
                    "analysisId": {
                        "type": "string",
                        "description": "AI analysis ID"
                    }
                },
                "required": ["analysisId"]
            }
        ),
        
        types.Tool(
            name="get_all_flags",
            description="Get all flags with pagination (admin view)",
            inputSchema={
                "type": "object",
                "properties": {
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination",
                        "default": 1
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of flags per page",
                        "default": 20
                    },
                    "status": {
                        "type": "string",
                        "description": "Filter flags by status"
                    },
                    "flagType": {
                        "type": "string",
                        "description": "Filter flags by type"
                    },
                    "flaggedBy": {
                        "type": "string",
                        "description": "Filter flags by who flagged them"
                    }
                }
            }
        )
    ]


@server.call_tool()
async def handle_call_tool(
    name: str, arguments: Optional[Dict[str, Any]]
) -> List[Union[types.TextContent, types.ImageContent, types.EmbeddedResource]]:
    """Handle tool execution requests."""
    try:
        if name == "get_tickets":
            return await get_tickets(arguments or {})
        elif name == "get_ticket_stats":
            return await get_ticket_stats()
        elif name == "get_ticket_by_id":
            return await get_ticket_by_id(arguments or {})
        elif name == "get_ticket_ai_analysis":
            return await get_ticket_ai_analysis(arguments or {})
        elif name == "get_ai_flags_distribution":
            return await get_ai_flags_distribution()
        elif name == "get_similar_incidents":
            return await get_similar_incidents()
        elif name == "get_source_channels_distribution":
            return await get_source_channels_distribution()
        elif name == "get_priority_distribution":
            return await get_priority_distribution()
        elif name == "get_status_distribution":
            return await get_status_distribution()
        elif name == "get_dashboard_analytics":
            return await get_dashboard_analytics()
        elif name == "get_analysis_flags":
            return await get_analysis_flags(arguments or {})
        elif name == "get_analysis_flag_stats":
            return await get_analysis_flag_stats(arguments or {})
        elif name == "get_all_flags":
            return await get_all_flags(arguments or {})
        else:
            raise ValueError(f"Unknown tool: {name}")
            
    except APIError as e:
        error_msg = f"API Error: {e.message}"
        if e.status_code:
            error_msg += f" (Status: {e.status_code})"
        return [types.TextContent(type="text", text=error_msg)]
        
    except Exception as e:
        logger.error(f"Error executing tool {name}: {str(e)}")
        return [types.TextContent(type="text", text=f"Error: {str(e)}")]


# Tool Implementation Functions

async def get_tickets(args: Dict[str, Any]) -> List[types.TextContent]:
    """Retrieve tickets with optional filtering and pagination."""
    params = {}
    
    # Add all possible parameters
    param_fields = [
        'status', 'priority', 'category', 'sourceChannel', 'assignedTo',
        'assignedTeam', 'customer', 'tags', 'dateFrom', 'dateTo', 'search',
        'page', 'limit', 'sortBy', 'sortOrder'
    ]
    
    for field in param_fields:
        if field in args and args[field] is not None:
            params[field] = args[field]
    
    # Set defaults
    if 'page' not in params:
        params['page'] = 1
    if 'limit' not in params:
        params['limit'] = config.default_page_size
    
    response = await client.get("/api/tickets", params=params)
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_ticket_stats() -> List[types.TextContent]:
    """Get ticket statistics and metrics."""
    response = await client.get("/api/tickets/stats")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_ticket_by_id(args: Dict[str, Any]) -> List[types.TextContent]:
    """Retrieve a specific ticket by its ID."""
    if 'id' not in args:
        raise ValueError("Ticket ID is required")
    
    ticket_id = args['id']
    response = await client.get(f"/api/tickets/{ticket_id}")
    
    return [types.TextContent(
        type="text", 
        text=json.dumps(response, indent=2)
    )]


async def get_ticket_ai_analysis(args: Dict[str, Any]) -> List[types.TextContent]:
    """Get AI analysis for a specific ticket."""
    if 'id' not in args:
        raise ValueError("Ticket ID is required")
    
    ticket_id = args['id']
    response = await client.get(f"/api/tickets/{ticket_id}/ai-analysis")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_ai_flags_distribution() -> List[types.TextContent]:
    """Get AI flags distribution for analytics."""
    response = await client.get("/api/analytics/ai-flags")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_similar_incidents() -> List[types.TextContent]:
    """Get count of similar incidents."""
    response = await client.get("/api/analytics/similar-incidents")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_source_channels_distribution() -> List[types.TextContent]:
    """Get distribution of ticket source channels."""
    response = await client.get("/api/analytics/source-channels")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_priority_distribution() -> List[types.TextContent]:
    """Get distribution of ticket priorities."""
    response = await client.get("/api/analytics/priority-distribution")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_status_distribution() -> List[types.TextContent]:
    """Get distribution of ticket statuses."""
    response = await client.get("/api/analytics/status-distribution")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_dashboard_analytics() -> List[types.TextContent]:
    """Get comprehensive analytics for dashboard."""
    response = await client.get("/api/analytics/dashboard")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_analysis_flags(args: Dict[str, Any]) -> List[types.TextContent]:
    """Get all flags for a specific AI analysis."""
    if 'analysisId' not in args:
        raise ValueError("Analysis ID is required")
    
    analysis_id = args['analysisId']
    params = {}
    
    # Add optional filters
    if 'status' in args and args['status'] is not None:
        params['status'] = args['status']
    if 'flagType' in args and args['flagType'] is not None:
        params['flagType'] = args['flagType']
    
    response = await client.get(f"/api/ai-flags/analysis/{analysis_id}/flags", params=params)
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_analysis_flag_stats(args: Dict[str, Any]) -> List[types.TextContent]:
    """Get flag statistics for an AI analysis."""
    if 'analysisId' not in args:
        raise ValueError("Analysis ID is required")
    
    analysis_id = args['analysisId']
    response = await client.get(f"/api/ai-flags/analysis/{analysis_id}/flags/stats")
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def get_all_flags(args: Dict[str, Any]) -> List[types.TextContent]:
    """Get all flags with pagination (admin view)."""
    params = {}
    
    # Add pagination and filter parameters
    optional_params = ['page', 'limit', 'status', 'flagType', 'flaggedBy']
    for param in optional_params:
        if param in args and args[param] is not None:
            params[param] = args[param]
    
    # Set defaults
    if 'page' not in params:
        params['page'] = 1
    if 'limit' not in params:
        params['limit'] = config.default_page_size
    
    response = await client.get("/api/ai-flags/flags", params=params)
    
    return [types.TextContent(
        type="text",
        text=json.dumps(response, indent=2)
    )]


async def main():
    """Main entry point for the MCP server."""
    # Test API connectivity
    try:
        is_healthy = await client.health_check()
        if not is_healthy:
            logger.warning("API health check failed, but continuing...")
    except Exception as e:
        logger.warning(f"Could not perform health check: {str(e)}")
    
    # Run the server using stdin/stdout streams
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="respona-dashboard",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

def cli_main():
    """Synchronous entry point for CLI/uvx usage."""
    asyncio.run(main())


if __name__ == "__main__":
    asyncio.run(main()) 