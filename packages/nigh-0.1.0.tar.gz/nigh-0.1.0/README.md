# nu

## Installation

```bash
pip install nu
```
