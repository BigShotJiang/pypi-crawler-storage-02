"""
nu - A minimal package to reserve the name on PyPI
"""

__version__ = "0.0.1"