
from .renamer import GGUFEditorApp
import tkinter

root = tkinter.Tk()
app = GGUFEditorApp(root)
root.mainloop()