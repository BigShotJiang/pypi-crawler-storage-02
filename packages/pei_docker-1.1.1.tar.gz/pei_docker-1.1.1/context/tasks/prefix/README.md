# Task Prefix: Useful Information for Many Tasks

This directory contains the context information for many tasks, such as:
- Where is test data located
- How to set up the development environment
- Current file structure of the project
- Known facts and issues about the project

etc.

Prepend these information to the relevant tasks as needed.