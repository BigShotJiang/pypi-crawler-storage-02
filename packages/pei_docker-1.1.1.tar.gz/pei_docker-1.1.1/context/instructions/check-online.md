you are requested to check the online resources for the given task, before proceeding with the task, and during the task.

Follow these guidelines:

- for 3rd party libraries, check their official documentation in `context7`. If not found, check online for the version used in the project.
- for your given task, search for best practices online.