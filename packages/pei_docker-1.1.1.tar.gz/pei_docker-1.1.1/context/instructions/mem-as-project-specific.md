# Memorizing Project-Specific Information

you are tasked to memorize something specific to the project, follow these guidelines to write your memory.

## Project-Specific Memory Guidelines

- ALWAYS state explicitly that the memory is project-specific, use a mark like `# Project-Specific Memory` at the beginning of your memory section.