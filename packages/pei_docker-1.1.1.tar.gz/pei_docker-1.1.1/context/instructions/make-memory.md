you are tasked to remember something using promptx mcp, follow these guidelines

# Guidelines for Remembering with PromptX MCP

- in principal, you should remember the essential information, keep concise
- for code examples, you should remember them, but just with the essential parts, not the entire code, they do not need to be directly runnable
- you do not have to remember CI/CD pipelines
- if you what you are remembering come from a file or a link, you should also remember the file path or link name as reference