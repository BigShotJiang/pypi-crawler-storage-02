# Linux Environments

you are in a Linux environment

- your python env is managed by `pixi`, use `pixi run -e dev` for development tasks, and `pixi run` for deployment tasks
- DO NOT use unicode emojis in console output like print statements, as it may cause issues in some environments

# Tools

- for `playwright`, the browsers are already installed, you do not need to do `playwright install`