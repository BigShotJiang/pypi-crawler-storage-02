



def say_hi():
    '''
    to say hi only
    '''
    msg ='Hello World'
    print(msg)
    return msg

