from mat3ra.code.entity import InMemoryEntityPydantic


class BaseConfigurationPydantic(InMemoryEntityPydantic):
    pass
