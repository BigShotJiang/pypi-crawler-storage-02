from mat3ra.code.entity import InMemoryEntityPydantic


class BaseBuilderParameters(InMemoryEntityPydantic):
    pass
