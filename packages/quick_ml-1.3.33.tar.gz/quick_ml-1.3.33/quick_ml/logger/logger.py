

class Logger:

	def __init__(self):

		pass

	 
