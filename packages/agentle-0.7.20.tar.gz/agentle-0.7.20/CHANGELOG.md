# Changelog

## v0.7.20 

- Add tool execution results as proper parts in the user message
