def main():
    print("Hello from a5-py!")


if __name__ == "__main__":
    main()
