"""
Core functionality for A5.
""" 