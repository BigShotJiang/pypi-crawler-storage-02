Constants
=========

.. autoclass:: terminusgps.authorizenet.constants.AuthorizenetSubscriptionStatus
    :members:

.. autodata:: terminusgps.authorizenet.constants.ANET_XMLNS
