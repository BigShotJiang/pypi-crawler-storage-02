# Jupyterlab Hungarian (Hungary) Language Pack

Hungarian (Hungary) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-hu-HU
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-hu-HU
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
