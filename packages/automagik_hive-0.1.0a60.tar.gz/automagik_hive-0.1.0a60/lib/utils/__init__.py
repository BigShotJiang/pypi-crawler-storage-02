"""Automagik Hive Utils Module - Common utilities and helper functions."""
