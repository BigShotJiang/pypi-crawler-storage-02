from __future__ import annotations
from sqlalchemy import Column, String, Integer, ForeignKey
from sqlalchemy.orm import relationship

from vantage6.server.model.base import Base, DatabaseSessionManager


class AlgorithmStore(Base):
    """
    Table that describes which algorithm stores are available for which
    collaborations.

    Attributes
    ----------
    name: str
        The name of the algorithm store
    url: str
        The url of the algorithm store
    collaboration_id: int
        The id of the
        :class:`~vantage6.server.model.collaboration.Collaboration` that this
        algorithm store belongs to. If it is ``None``, then it is available for
        all collaborations.
    """

    # fields
    name = Column(String)
    url = Column(String)
    collaboration_id = Column(Integer, ForeignKey("collaboration.id"))

    collaboration = relationship("Collaboration", back_populates="algorithm_stores")
    tasks = relationship("Task", back_populates="algorithm_store")

    @classmethod
    def get_by_url(cls, url: str) -> list[AlgorithmStore]:
        """
        Get all algorithm store records with a certain url

        Parameters
        ----------
        url : str
            The url of the algorithm store

        Returns
        -------
        list[AlgorithmStore]
            List of algorithm store records with that URL
        """
        session = DatabaseSessionManager.get_session()
        return session.query(AlgorithmStore).filter_by(url=url).all()

    def is_for_all_collaborations(self) -> bool:
        """
        Check if the algorithm store is available for all collaborations

        Returns
        -------
        bool
            True if the algorithm store is available for all collaborations,
            False otherwise
        """
        return self.collaboration_id is None
