"""
Meta Objects for records and recordset for AsyncDB.
"""
