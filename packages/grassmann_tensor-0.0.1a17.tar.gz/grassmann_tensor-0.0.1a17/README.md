# A Grassmann algebra tensor package.
[![ci](https://github.com/USTC-KnowledgeComputingLab/grassmann-tensor/actions/workflows/pre-commit.yml/badge.svg)](https://github.com/USTC-KnowledgeComputingLab/grassmann-tensor/actions/workflows/pre-commit.yml)
[![codecov](https://codecov.io/gh/USTC-KnowledgeComputingLab/grassmann-tensor/graph/badge.svg?token=98Z1PJMVBZ)](https://codecov.io/gh/USTC-KnowledgeComputingLab/grassmann-tensor)
