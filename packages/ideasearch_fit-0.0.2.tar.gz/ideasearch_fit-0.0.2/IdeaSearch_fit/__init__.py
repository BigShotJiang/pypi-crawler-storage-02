from .i18n import set_language
from .i18n import init_language


__all__ = [
    "set_language",
    "init_language",
]