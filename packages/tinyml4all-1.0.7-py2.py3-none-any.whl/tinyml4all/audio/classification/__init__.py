from tinyml4all.audio.classification.ClassificationAlbum import (
    ClassificationAlbum as Album,
)
