from tinyml4all.tensorflow.Sequential import Sequential


class RNN(Sequential):
    """
    Custom implementation for Recurrent Network
    """

    pass
