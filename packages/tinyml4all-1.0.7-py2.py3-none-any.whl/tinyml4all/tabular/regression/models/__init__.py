from tinyml4all.tabular.regression.models.DecisionTree import DecisionTree
from tinyml4all.tabular.regression.models.RandomForest import RandomForest
from tinyml4all.tabular.regression.models.Linear import Linear
from tinyml4all.tabular.regression.models.Ridge import Ridge
from tinyml4all.tabular.regression.models.Lasso import Lasso
