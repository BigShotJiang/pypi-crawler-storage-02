from tinyml4all.tabular.classification.ClassificationTable import (
    ClassificationTable as Table,
)
from tinyml4all.tabular.classification.ClassificationChain import (
    ClassificationChain as Chain,
)
