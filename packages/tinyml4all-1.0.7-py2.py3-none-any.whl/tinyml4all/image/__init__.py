from tinyml4all.image.capture import capture_serial
from tinyml4all.image.debug import debug_serial
