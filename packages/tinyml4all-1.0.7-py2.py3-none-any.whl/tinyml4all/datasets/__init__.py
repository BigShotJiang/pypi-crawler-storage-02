from tinyml4all.datasets.Iris import Iris
from tinyml4all.datasets.Pets import Pets
