def hello():
    return "Reserved for future use"