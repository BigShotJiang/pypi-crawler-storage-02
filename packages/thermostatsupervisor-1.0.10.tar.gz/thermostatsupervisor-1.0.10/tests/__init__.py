"""Package identifier file"""

# local imports
from thermostatsupervisor.__init__ import __version__  # noqa F401

# package name
name = "tests"
