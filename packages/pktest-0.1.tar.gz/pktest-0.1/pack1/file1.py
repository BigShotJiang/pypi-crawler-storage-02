def user(name, age):
    print(f"your name is {name}")
    print(f"your age is {age}")