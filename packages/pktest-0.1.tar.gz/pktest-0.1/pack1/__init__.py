# games/__init__.py
from .cowbulls import play as cowbulls
from .rockpaper import play as rockpaper
from .guessno import play as guessno    
__all__ = ['rockpaper','cowbulls' ,'guessno'],