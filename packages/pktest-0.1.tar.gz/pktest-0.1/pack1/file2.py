def profile(age, city):
    print(f"your age is {age}")
    print(f"your city is {city}")

def user(name, age):
    print(f"your name is {name}")
    print(f"your age is {age}")