__version__ = "0.0.82"

from importlib_resources import files

PACKAGE_ROOT = files(__package__)
