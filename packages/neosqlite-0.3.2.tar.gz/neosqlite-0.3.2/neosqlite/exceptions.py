class MalformedQueryException(Exception):
    pass


class MalformedDocument(Exception):
    pass
