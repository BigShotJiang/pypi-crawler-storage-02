"""
TODO:
 - inline polymorph: 'ami: foo' -> 'image: {'ami': {'name': 'foo'}}
 - parse duration and size settings, "512k" or "10 seconds"
 - includes
 - substitutions ("foo" : ${bar}, "foo" : Hello ${who})
"""
