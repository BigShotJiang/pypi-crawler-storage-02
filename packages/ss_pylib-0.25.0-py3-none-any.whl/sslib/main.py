def main():
    print('SS Python LIB')
