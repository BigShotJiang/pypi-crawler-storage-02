"""
Main entry point for python -m llmbuilder command.
"""

from .cli import main

if __name__ == "__main__":
    main()
