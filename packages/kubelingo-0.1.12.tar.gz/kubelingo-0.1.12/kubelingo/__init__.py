"""Kubelingo package initialization."""
__version__ = '0.1.12'
# This file makes 'kubelingo' a Python package.
