# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Rivo Zängov ([@Eraser](https://crowdin.com/profile/Eraser))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
