# ABCI Counter AEA client

This agent uses the `http_client` connection 
and the `counter_client` skill
to interact with the ABCI Counter application through a Tendermint node. 
