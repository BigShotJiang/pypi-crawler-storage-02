<a id="packages.valory.skills.registration_abci.payloads"></a>

# packages.valory.skills.registration`_`abci.payloads

This module contains the transaction payloads for common apps.

<a id="packages.valory.skills.registration_abci.payloads.RegistrationPayload"></a>

## RegistrationPayload Objects

```python
@dataclass(frozen=True)
class RegistrationPayload(BaseTxPayload)
```

Represent a transaction payload of type 'registration'.

