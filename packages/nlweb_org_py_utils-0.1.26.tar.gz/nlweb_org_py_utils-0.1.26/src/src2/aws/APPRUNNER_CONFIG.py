class APPRUNNER_CONFIG:
    '''👉️ Configures the AppRunner service.'''
    
    def __init__(self):
        
        self.vCPUs = 1
        '''👉 The vCPU number of cores.'''

        self.MemoryInGB = 2
        '''👉 The memory in GB.'''