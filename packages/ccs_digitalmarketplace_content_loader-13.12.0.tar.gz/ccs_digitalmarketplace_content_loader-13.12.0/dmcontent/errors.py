# -*- coding: utf-8 -*-


class ContentNotFoundError(Exception):
    pass


class ContentTemplateError(Exception):
    pass


class QuestionNotFoundError(Exception):
    pass
