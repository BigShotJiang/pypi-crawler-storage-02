"""
TN-NT Templates init
"""

__version__ = "3.11.1"
__title__ = "Terra Nanotech Alliance Auth Template Overrides"
