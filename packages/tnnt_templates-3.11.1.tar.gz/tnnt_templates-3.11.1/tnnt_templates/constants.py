"""
TNNT Auth Templates Constants
"""

# All internal URLs need to start with this prefix
# to prevent conflicts with user-generated forum URLs
INTERNAL_URL_PREFIX = "-"
