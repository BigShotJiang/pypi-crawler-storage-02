API Reference
=============

.. toctree::
   :maxdepth: 2

   Core Module <_autosummary/macrostat.core.rst>
   Models Module <_autosummary/macrostat.models.rst>
   Utilities Module <_autosummary/macrostat.util.rst>
