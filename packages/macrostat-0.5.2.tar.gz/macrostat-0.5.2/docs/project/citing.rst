.. _citing_macrostat:

=================
Citing MacroStat
=================

.. note::
   **Under development**
