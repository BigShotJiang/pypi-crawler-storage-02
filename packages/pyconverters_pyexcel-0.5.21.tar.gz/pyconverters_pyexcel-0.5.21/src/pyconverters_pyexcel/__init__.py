"""Convert XLSX to 1-segment per row document"""
__version__ = "0.5.21"
