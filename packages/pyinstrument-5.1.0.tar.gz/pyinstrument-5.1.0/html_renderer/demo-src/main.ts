import DemoApp from "./DemoApp.svelte";

new DemoApp({
    target: document.body,
});
