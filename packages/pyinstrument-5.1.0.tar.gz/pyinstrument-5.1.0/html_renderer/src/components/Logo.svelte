<svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
<g opacity="0.5" filter="url(#filter0_f_67_262)">
<path fill-rule="evenodd" clip-rule="evenodd" d="M30 9H10V11.5H30V9ZM30 19H12.5V21.5H30V19ZM12.5 14H32.5V16.5H12.5V14ZM20 24H12.5V26.5H20V24ZM12.5 29H20V31.5H12.5V29ZM22.5 34H10V36.5H22.5V34Z" fill="url(#paint0_linear_67_262)"/>
</g>
<path fill-rule="evenodd" clip-rule="evenodd" d="M30 9H10V11.5H30V9ZM30 19H12.5V21.5H30V19ZM12.5 14H32.5V16.5H12.5V14ZM20 24H12.5V26.5H20V24ZM12.5 29H20V31.5H12.5V29ZM22.5 34H10V36.5H22.5V34Z" fill="url(#paint1_linear_67_262)"/>
<defs>
<filter id="filter0_f_67_262" x="3.2043" y="2.2043" width="36.0914" height="41.0914" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
<feGaussianBlur stdDeviation="3.39785" result="effect1_foregroundBlur_67_262"/>
</filter>
<linearGradient id="paint0_linear_67_262" x1="7.3769" y1="18.4566" x2="20.6583" y2="33.1038" gradientUnits="userSpaceOnUse">
<stop stop-color="#FFAA00"/>
<stop offset="0.514478" stop-color="#FFEB00"/>
<stop offset="1" stop-color="#98FF05"/>
</linearGradient>
<linearGradient id="paint1_linear_67_262" x1="7.3769" y1="18.4566" x2="20.6583" y2="33.1038" gradientUnits="userSpaceOnUse">
<stop stop-color="#FFC834"/>
<stop offset="0.514478" stop-color="#FAF534"/>
<stop offset="1" stop-color="#B8FF38"/>
</linearGradient>
</defs>
</svg>
