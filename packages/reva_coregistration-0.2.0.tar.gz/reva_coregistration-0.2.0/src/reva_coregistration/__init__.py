"""
Reva Coregistration Package

A Python package for image coregistration and coordinate transformation.
"""

__version__ = "0.2.0"
__author__ = "Robert Toth, PhD"
__email__ = "robert.toth@thetatech.ai"
