from .backends import EmailBackend
from .version import VERSION as VERSION_STRING

VERSION = VERSION_STRING.split('.')
