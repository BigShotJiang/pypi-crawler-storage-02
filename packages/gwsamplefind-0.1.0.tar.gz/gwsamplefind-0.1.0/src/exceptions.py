class GWSampleFindError(Exception):
    pass
