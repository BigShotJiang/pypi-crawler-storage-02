def test_test() -> None:
    """."""
