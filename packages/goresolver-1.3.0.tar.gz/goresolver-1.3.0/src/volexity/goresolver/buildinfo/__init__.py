"""Parses the BuildInfo of a Go binary."""
