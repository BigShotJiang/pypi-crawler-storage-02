To be able to select a specific Bill of Materials in a sale order, the
user needs the special permission: "Allows to define a BOM on sale order
lines".
