This modules allows to specify a Bill Of Materials directly inside a
sale order line. It is specially useful to select alternative
manufacturing and sub-contracting routings.
