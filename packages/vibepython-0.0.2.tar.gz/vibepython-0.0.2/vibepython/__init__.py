from .main import main

__version__ = "0.0.2"
