"""An extension of fabricatio."""
