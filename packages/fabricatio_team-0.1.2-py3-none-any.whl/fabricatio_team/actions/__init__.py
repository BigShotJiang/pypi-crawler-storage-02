"""Actions defined in fabricatio-team."""
