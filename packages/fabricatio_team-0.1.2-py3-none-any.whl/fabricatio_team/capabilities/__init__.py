"""Capabilities defined in fabricatio-team."""
