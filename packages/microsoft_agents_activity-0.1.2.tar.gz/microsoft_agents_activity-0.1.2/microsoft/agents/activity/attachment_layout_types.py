from enum import Enum


class AttachmentLayoutTypes(str, Enum):
    list = "list"
    carousel = "carousel"
