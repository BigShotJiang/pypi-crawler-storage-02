"""
Schemdraw MCP Server

Electronic circuit diagram drawing server using the Model Context Protocol (MCP).
"""

__version__ = "0.1.0"