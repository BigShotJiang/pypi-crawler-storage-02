from snowflake.cli._plugins.spcs.compute_pool.compute_pool_entity_model import (
    ComputePoolEntityModel,
)
from snowflake.cli.api.entities.common import EntityBase


class ComputePoolEntity(EntityBase[ComputePoolEntityModel]):
    pass
