from snowflake.cli._plugins.spcs.services.service_entity_model import ServiceEntityModel
from snowflake.cli.api.entities.common import EntityBase


class ServiceEntity(EntityBase[ServiceEntityModel]):
    pass
