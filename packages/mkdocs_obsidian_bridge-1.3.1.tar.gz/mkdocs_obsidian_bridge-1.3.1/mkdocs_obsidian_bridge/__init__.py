# SPDX-FileCopyrightText: © 2022 Serhii “GooRoo” Olendarenko
#
# SPDX-License-Identifier: BSD-3-Clause
