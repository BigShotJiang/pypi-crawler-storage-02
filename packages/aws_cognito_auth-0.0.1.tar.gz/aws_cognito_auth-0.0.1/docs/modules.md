# API Reference

## Client Module

::: aws_cognito_auth.client

## Admin Module

::: aws_cognito_auth.admin

## Lambda Function

::: aws_cognito_auth.lambda_function
