"""
Test package for AWS Cognito Authoriser

This package contains unit tests, integration tests, and fixtures for the
AWS Cognito authentication CLI tool.
"""
