class InvalidInputException(Exception):
    """Raised for invalid input."""
