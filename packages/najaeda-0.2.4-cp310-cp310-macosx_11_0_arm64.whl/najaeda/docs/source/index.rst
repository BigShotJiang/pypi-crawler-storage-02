.. najaeda documentation master file, created by
   sphinx-quickstart on Mon Dec 16 16:39:26 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

najaeda documentation
=====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   netlist_classes
   common_classes
   examples
   api