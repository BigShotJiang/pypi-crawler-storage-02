**Reaction plugin for TT Dimerization in KIMMDY**

