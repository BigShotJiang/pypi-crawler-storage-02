#
# DON'T CHANGE THIS FILE!!!!
#

AVAILABLE_RESULT_TYPES = ["counts", "quasi_dist", "expval"]
