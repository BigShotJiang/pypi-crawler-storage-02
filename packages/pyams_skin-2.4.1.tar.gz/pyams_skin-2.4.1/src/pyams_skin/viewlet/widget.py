#
# Copyright (c) 2015-2020 Thierry Florac <tflorac AT ulthar.net>
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#

"""PyAMS_skin.viewlet.widget module

This module provides a single "pyams.widget" content provider, which is used into forms to
render viewlets.
"""

from pyams_form.interfaces.widget import IWidget
from pyams_layer.interfaces import IPyAMSLayer
from pyams_template.template import template_config
from pyams_viewlet.viewlet import ViewContentProvider, contentprovider_config


__docformat__ = 'restructuredtext'


@contentprovider_config(name='pyams.widget', layer=IPyAMSLayer, view=IWidget)
@template_config(template='templates/widget.pt')
class WidgetViewlet(ViewContentProvider):
    """Widget renderer viewlet"""
