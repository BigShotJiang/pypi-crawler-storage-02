"""
Functions for comparing AudioSignal objects to one another.
"""
from . import distance
from . import quality
from . import spectral
