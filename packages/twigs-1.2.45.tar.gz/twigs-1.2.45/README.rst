=====
twigs
=====


.. image:: https://img.shields.io/pypi/v/twigs.svg
        :target: https://pypi.python.org/pypi/twigs

.. image:: https://readthedocs.org/projects/twigs/badge/?version=latest
        :target: https://twigs.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status
.. image:: https://github.com/threatworx/twigs/actions/workflows/build.yml/badge.svg
        :target: https://github.com/threatworx/twigs/actions/workflows/build.yml
        :alt: twigs build

ThreatWorx Information Gathering Script

https://threatworx.io/docs/twigs-intro/

* Free software: GNU General Public License v3

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
