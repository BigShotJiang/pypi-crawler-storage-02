## Aliyun ROS PAIPLUGIN Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as PAIPLUGIN from '@alicloud/ros-cdk-paiplugin';
```
