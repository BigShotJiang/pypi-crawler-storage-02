# Sentiment-Lite

A lightweight Python package for basic sentiment analysis using predefined positive, negative, and neutral word lists.

## Installation

```bash
pip install sentiment-lite
