from .core import analyze_sentiment

__version__ = "0.1.0"
__author__ = "Your Name"

__all__ = ["analyze_sentiment"]
