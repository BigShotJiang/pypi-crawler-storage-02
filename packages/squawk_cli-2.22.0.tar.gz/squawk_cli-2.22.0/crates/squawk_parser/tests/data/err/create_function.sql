-- regression partial definition
create function
