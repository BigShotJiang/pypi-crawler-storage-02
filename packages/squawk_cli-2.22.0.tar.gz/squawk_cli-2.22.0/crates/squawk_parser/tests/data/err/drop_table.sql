-- missing comma
drop table foo, bar buzz cascade;

-- missing name
drop table foo,   , buzz cascade;
