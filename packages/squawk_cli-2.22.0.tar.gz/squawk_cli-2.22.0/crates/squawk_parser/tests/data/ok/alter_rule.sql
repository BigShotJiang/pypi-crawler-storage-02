-- simple
alter rule r on t rename to n;

-- with_schema
alter rule r on schema.t rename to n;

