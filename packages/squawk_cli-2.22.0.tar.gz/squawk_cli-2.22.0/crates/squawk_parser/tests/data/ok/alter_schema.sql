-- rename
alter schema s rename to n;

-- owner
alter schema s owner to u;
alter schema s owner to current_user;

