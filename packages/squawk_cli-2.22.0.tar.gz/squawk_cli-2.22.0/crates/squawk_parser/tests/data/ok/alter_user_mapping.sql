-- full
alter user mapping for current_role
    server s
    options (add a 'v', set b 'w', drop c);

