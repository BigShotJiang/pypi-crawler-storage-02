-- simple
drop foreign data wrapper s;

-- full
drop foreign data wrapper if exists a, b, c cascade;
drop foreign data wrapper if exists a, b, c restrict;

