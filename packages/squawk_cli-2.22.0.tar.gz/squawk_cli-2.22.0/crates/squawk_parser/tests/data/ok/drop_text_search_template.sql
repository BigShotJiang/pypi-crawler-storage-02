-- simple
drop text search template foo;

-- full
drop text search template if exists bar cascade;

-- restrict
drop text search template bar restrict;

