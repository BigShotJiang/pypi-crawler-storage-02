-- rename
alter text search template t rename to u;

-- set_schema
alter text search template foo.t set schema s;

