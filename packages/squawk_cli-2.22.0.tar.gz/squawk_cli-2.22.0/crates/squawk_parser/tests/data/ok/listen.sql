-- pg_docs
listen foo;

LISTEN virtual;

