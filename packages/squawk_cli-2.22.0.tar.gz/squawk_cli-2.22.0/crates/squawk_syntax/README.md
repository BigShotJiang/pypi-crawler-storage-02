# squawk_syntax

## related

- https://github.com/rust-lang/rust-analyzer/blob/d2f17873ff19786a121fb3302f91779c1a1b957f/docs/book/src/contributing/syntax.md
