-- disallowed prefix operators
select *c;
select /d;
select <e;
select >f;
select =g;
select %l;
select ^m;
