create table t (
  x int,
  description
  --          ^^^^ missing type
);
