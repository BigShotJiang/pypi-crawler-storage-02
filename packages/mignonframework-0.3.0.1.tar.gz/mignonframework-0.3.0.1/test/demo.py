from mignonFramework import countSingleFileLines

print(countSingleFileLines("./res/output/海知汇专利_13.txt"))