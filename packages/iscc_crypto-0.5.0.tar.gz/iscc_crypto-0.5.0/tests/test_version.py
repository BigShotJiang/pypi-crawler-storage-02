import iscc_crypto


def test_version():
    assert iscc_crypto.__version__ == "0.5.0"
