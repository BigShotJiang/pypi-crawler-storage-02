# OpenLineage Python Client

Python client for [OpenLineage](https://openlineage.io).

Refer to the [documentation](https://openlineage.io/docs/client/python) for details.
