insert into operations (prompt_id, tool, reason, details, started_at)
  values (:prompt_id, :tool, :reason, :details, :started_at)
