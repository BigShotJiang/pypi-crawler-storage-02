import os

__version__ = "1.0.3"

# set Python env variable to keep track of example data dir
SNFit_dir = os.path.dirname(__file__)
DATADIR = os.path.join(SNFit_dir, "example_data/")


