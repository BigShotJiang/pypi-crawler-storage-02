import logging

logging.basicConfig(level=logging.INFO)


def main() -> None:
    logging.info("Hello, World!")


if __name__ == "__main__":
    main()
