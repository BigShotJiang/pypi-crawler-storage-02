class SrcNotExistsException(Exception):
    pass


class DstItemAlreadyExistsException(Exception):
    pass
