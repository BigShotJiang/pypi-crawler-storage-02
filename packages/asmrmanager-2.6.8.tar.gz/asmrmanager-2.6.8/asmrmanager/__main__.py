from asmrmanager.cli.main import main

main()
