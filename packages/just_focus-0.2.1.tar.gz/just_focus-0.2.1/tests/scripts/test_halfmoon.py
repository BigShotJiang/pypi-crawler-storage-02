from leb.just_focus.scripts.halfmoon import main


def test_halfmoon_script() -> None:
    main(plot=False)
