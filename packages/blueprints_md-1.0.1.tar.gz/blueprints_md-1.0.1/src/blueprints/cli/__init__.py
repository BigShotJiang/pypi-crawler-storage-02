"""CLI module for blueprints.md."""
