
# outsight

**WIP**

Async iterators over what happens in your code.
