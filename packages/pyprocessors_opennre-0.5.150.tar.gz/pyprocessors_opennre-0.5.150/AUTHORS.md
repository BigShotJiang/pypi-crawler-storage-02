# Authors

Contributors to pyprocessors_opennre include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
