from .math import *

from .parse_word_xml import parse_word_xml
from .set_rpr import set_rpr