"""io-type classes for workflow module."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Tuple, NamedTuple

class FeatureList(NamedTuple):
    name = "FeatureList"