!!! note
    This library will only ever raise the errors explicitly documented for each method. If you encounter any other error, please consider it a bug and report it.

::: atomicwriter.AtomicWriter
