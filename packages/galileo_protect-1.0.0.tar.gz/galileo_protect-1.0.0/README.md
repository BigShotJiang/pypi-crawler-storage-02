# galileo-protect

🛡️ Secure your Generative AI applications with [Galileo Protect](https://www.rungalileo.io/).
