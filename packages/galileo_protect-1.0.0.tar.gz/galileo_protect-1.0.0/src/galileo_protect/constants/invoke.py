from datetime import timedelta

TIMEOUT = timedelta(seconds=10).total_seconds()
TIMEOUT_MARGIN = timedelta(seconds=5).total_seconds()
