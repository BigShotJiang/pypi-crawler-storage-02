# ArtifactsMMO-S3-Wrapper - Examples

Here, you can find all sorts of examples, made by me (Veillax), and any community member.  
If you wish to contribute an example, please make an issue with the `New Example` template
