"""API module for Niamoto GUI."""
