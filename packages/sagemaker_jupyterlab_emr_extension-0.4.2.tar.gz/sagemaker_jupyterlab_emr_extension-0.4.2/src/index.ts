import { EmrClusterPlugin, DeepLinkingPlugin } from './plugins';

export default [EmrClusterPlugin, DeepLinkingPlugin];
