"""
Placeholder package for predicat-ui.
"""
__all__ = []
__version__ = "0.0.0a1"
