# __main__.py

from scraperapi_mcp_server import main

main()
