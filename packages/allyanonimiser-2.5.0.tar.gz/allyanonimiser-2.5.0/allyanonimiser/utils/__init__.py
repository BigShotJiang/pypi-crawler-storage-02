"""
Utils package for the Allyanonimiser package.
"""