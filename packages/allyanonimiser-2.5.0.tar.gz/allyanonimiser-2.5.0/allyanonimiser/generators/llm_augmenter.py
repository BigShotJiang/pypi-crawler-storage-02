"""
LLM augmenter stub for testing.
"""

class LLMAugmenter:
    """Stub class for testing."""
    def __init__(self):
        pass