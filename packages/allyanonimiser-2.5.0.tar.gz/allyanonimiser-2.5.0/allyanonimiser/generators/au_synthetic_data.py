"""
Australian synthetic data generator stub for testing.
"""

class AustralianSyntheticDataGenerator:
    """Stub class for testing."""
    def __init__(self):
        pass