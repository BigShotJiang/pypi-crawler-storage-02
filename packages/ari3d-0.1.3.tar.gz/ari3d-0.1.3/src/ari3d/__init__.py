"""Initialization file for the ari3d package."""
__version__ = "0.1.3"
__author__ = "Jan Philipp Albrecht, Jose Ricardo Assuncao Godinho"
