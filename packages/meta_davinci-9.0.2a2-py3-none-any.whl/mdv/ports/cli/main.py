from asyncio import run as asyncio_run
from pathlib import Path
from sys import argv
from typing import Any
import json

import rich_click as click
from mdv.adapters.repositories.service.token_generator import TokenGenerator
from agrobase.connectors.bio_archival._dtos import BioArchivalAssay
from agrobase.connectors.bio_archival.assay_factory import fetch_assays_list
from agrobase.enums import TaxaEnum
from aiohttp.client_exceptions import ClientConnectorError
from docker import DockerClient

from mdv.__version__ import version
from mdv.adapters.repositories.service.analysis_blob_registration import (
    AnalysisBlobRegistrationServiceRepo,
)
from mdv.adapters.repositories.service.raw_library_blob_registration import (
    RawLibraryBlobRegistrationServiceRepo,
)
from mdv.domain.dtos.blast_databases import ReferenceDatabases
from mdv.domain.dtos.bootstrap_handler import MetadataColNamesEnum
from mdv.domain.entities.qc.dereplicate import DerepStrategyEnum
from mdv.ports.cli.decorators import (
    with_chat_notification,
    with_docker_client,
    with_repositories,
)
from mdv.settings import (
    ASSAYS_URL,
    LOGGER,
    RAREFACTION_KUTTOFF_FOR_COMPLEX,
    RAREFACTION_KUTTOFF_FOR_ISOLATES,
    PRE_FILTERING_SAMPLE_SIZE,
)
from mdv.use_cases.persist_seq_result_to_blob_storage_provider import (
    persist_seq_results_to_blob_storage_provider,
)
from mdv.use_cases.build_backup_artifact_analysis_directory import (
    build_backup_artifact_analysis_directory,
)
from mdv.use_cases.run_analysis_pipeline._assign_taxonomy_from_blast import (
    TaxAssignmentTools,
)
from mdv.use_cases.shared.core import SingleStepPipelineRepositories

from agrobase.enums import TaxaEnum

from mdv.domain.dtos.analysis_config import AnalysisConfig
from mdv.domain.dtos.blast_databases import ReferenceDatabases
from mdv.use_cases.run_analysis_bootstrap import RunAnalysisBootstrap

# ? ----------------------------------------------------------------------------
# ? Initialize the CLI groups
# ? ----------------------------------------------------------------------------


@click.group()
@click.version_option(version)
def meta_da_vinci_cmd() -> None:
    pass


@meta_da_vinci_cmd.group(
    "check",
    help=(
        "Run before the pipeline. Commands used to perform system checks "
        + "before run meta-davinci tool."
    ),
)
def check_cmd() -> None:
    pass


@meta_da_vinci_cmd.group(
    "info",
    help="Show details of MDV sub-commands.",
)
def info_cmd() -> None:
    pass


@meta_da_vinci_cmd.group(
    "qc",
    help=(
        "Options to run the individual steps of pipeline. Type `mdv qc --help`"
        + "to see the available steps."
    ),
)
def qc_cmd() -> None:
    pass


@meta_da_vinci_cmd.group(
    "persist",
    help=("Options to persist sequencing elements to Bioinfo Cloud."),
)
def persist_cmd() -> None:
    pass


@meta_da_vinci_cmd.group(
    "dump",
    help=("Command to dump results from raw sequencings and analysis."),
)
def dump_cmd() -> None:
    pass


def __extend_options(options: list[Any]) -> Any:
    def _extend_options(func: Any) -> Any:
        for option in reversed(options):
            func = option(func)
        return func

    return _extend_options


class UnableToFetchAssaysList(Exception): ...


def __fetch_assays_list() -> list[BioArchivalAssay]:
    LOGGER.debug("Fetching assays from remote bio-archival API")

    assays: list[BioArchivalAssay] = []

    try:
        if (res := asyncio_run(fetch_assays_list(ASSAYS_URL))).is_left:
            raise UnableToFetchAssaysList(res.value.msg)

        assays.extend(
            sorted(
                [i for i in res.value],
                key=lambda x: (x.name, x.version),
            )
        )

    except ClientConnectorError as exc:
        LOGGER.critical("⚠️  IMPORTANT")
        LOGGER.critical("")
        LOGGER.critical(f"\033[91m{exc}\033[0m")
        LOGGER.critical("`mdv boot` command limited")
        LOGGER.critical("`mdv info assays` command limited")
        LOGGER.critical("")
        LOGGER.critical("⚠️  IMPORTANT")

    except Exception as exc:
        raise UnableToFetchAssaysList(
            "Unexpected error detected on fetch assays list: "
            + f"{exc.__class__.__name__}: {exc}",
        )

    LOGGER.debug("Successfully fetched assays from remote bio-archival API")

    return assays


__ENABLED_ASSAYS = __fetch_assays_list()


# ? ----------------------------------------------------------------------------
# ? Initialize the CLI shared options
# ? ----------------------------------------------------------------------------

__SOURCE_DIRECTORY = lambda required=True: click.option(  # noqa: E731
    "-sd",
    "--source-directory",
    required=required,
    prompt=required,
    show_default=required,
    type=click.Path(
        resolve_path=True,
        readable=True,
        exists=True,
        dir_okay=True,
    ),
    help="A directory containing the source FASTQ files.",
)


__FILE_DIR_CMD_LIST = [
    __SOURCE_DIRECTORY(),
    click.option(
        "-wd",
        "--work-directory",
        required=True,
        prompt=True,
        type=click.Path(
            resolve_path=True,
            readable=True,
            exists=True,
            dir_okay=True,
        ),
        help="A directory to save the pipeline outputs.",
    ),
    click.option(
        "-mf",
        "--metadata-file",
        required=True,
        prompt=True,
        type=click.Path(
            resolve_path=False,
            readable=True,
            exists=False,
        ),
        default="metadata.tsv",
        help="A file with sample name and FASTQ files name.",
    ),
]

__FILE_DIR_CMD_LIST_BOOTSTRAP = [
    __SOURCE_DIRECTORY(),
    click.option(
        "-wd",
        "--work-directory",
        required=True,
        prompt=True,
        type=click.Path(
            resolve_path=True,
            readable=True,
            exists=True,
            dir_okay=True,
        ),
        help="A directory to save the pipeline outputs.",
    ),
]


__SAMPLE_SHEET = click.option(
    "-ss",
    "--sample-sheet-path",
    required=True,
    prompt=True,
    type=click.Path(
        resolve_path=False,
        readable=True,
        exists=False,
    ),
    default="SampleSheet.csv",
    help="The Sanple Sheet used to configure the sequencing run.",
)


__BLOB_INDICES_MAPPING = click.option(
    "-m",
    "--blob-indices-mapping-path",
    required=True,
    prompt=True,
    type=click.Path(
        resolve_path=True,
        readable=True,
        exists=True,
    ),
    help="The file containing the mapping between sample codes and crops.",
)


__CONFIG_FILE_CMD = click.option(
    "-cf",
    "--config-file",
    required=True,
    type=click.Path(
        resolve_path=True,
        readable=True,
        exists=True,
        dir_okay=True,
    ),
    help="The file path of the JSON config file.",
)


__SILENCE_NOTIFICATION_CMD = click.option(
    "-s",
    "--silent-notifications",
    is_flag=True,
    show_default=True,
    default=False,
    help="If True, run without notify MS Teams.",
)


__FORCE_OVERWRITE_CMD = click.option(
    "-f",
    "--force-overwrite",
    is_flag=True,
    show_default=True,
    default=False,
    help="Force overwrite the output directory if `True`.",
)


__ADDITIONAL_QC_CMD_LIST = [
    click.option(
        "--sample-size",
        required=False,
        type=click.INT,
        default=PRE_FILTERING_SAMPLE_SIZE,
        show_default=True,
        help=(
            "QC (Pre-filtering): The number of reads to keep from the "
            + "sequencing data."
        ),
    ),
    click.option(
        "--head-crop",
        required=False,
        type=click.INT,
        default=13,
        show_default=True,
        help=(
            "QC (Trimming): Cut the specified number of bases from the "
            + "start of the read."
        ),
    ),
    click.option(
        "--leading-quality",
        required=False,
        type=click.INT,
        default=1,
        show_default=True,
        help=(
            "QC (Trimming): Cut bases off the start of a read, if below a "
            + "threshold quality."
        ),
    ),
    click.option(
        "--trailing-quality",
        required=False,
        type=click.INT,
        default=1,
        show_default=True,
        help=(
            "QC (Trimming): Cut bases off the end of a read, if below a "
            + "threshold quality."
        ),
    ),
    click.option(
        "--tail-crop",
        required=False,
        type=click.INT,
        default=1000,
        show_default=True,
        help=(
            "QC (Trimming): Cut the read to a specified length by removing "
            + "bases from the end."
        ),
    ),
    click.option(
        "--derep-strategy",
        required=False,
        type=click.Choice([i.value for i in DerepStrategyEnum]),
        default=DerepStrategyEnum.PREFIX.value,
        show_default=True,
        help=(
            "QC (Dereplication): Cut the read to a specified length by "
            + "removing bases from the end."
        ),
    ),
    click.option(
        "--min-cluster-size",
        required=False,
        type=click.INT,
        default=2,
        show_default=True,
        help=(
            "QC (Dereplication | denoise): The minimum size of the cluster to  "
            + "keep it into he next steps."
        ),
    ),
    click.option(
        "-se",
        "--single-end-recovery-strategy",
        type=click.BOOL,
        show_default=True,
        default=None,
        help=(
            "Recovery unpaired sequences from trimming and merge if True. "
            + "Ignore otherwise."
        ),
    ),
]


__ADDITIONAL_RAREFY_CMD_LIST = [
    click.option(
        "--rarefaction-kuttoff-isolates",
        required=False,
        type=click.INT,
        default=RAREFACTION_KUTTOFF_FOR_ISOLATES,
        show_default=True,
        help=(
            "QC (Dereplication | rarefy): The minimum diversity of isolate "
            + "samples to kept after rarefaction."
        ),
    ),
    click.option(
        "--rarefaction-kuttoff-complex",
        required=False,
        type=click.INT,
        default=RAREFACTION_KUTTOFF_FOR_COMPLEX,
        show_default=True,
        help=(
            "QC (Dereplication | rarefy): The minimum diversity of complex "
            + "samples to kept after rarefaction."
        ),
    ),
    click.option(
        "--with-sample-effectiveness",
        type=click.BOOL,
        show_default=True,
        default=None,
        help=("Run sample effectiveness at the end of the quality filter."),
    ),
]


__CHAT_NOTIFICATION_CMD_LIST = [
    click.option(
        "--user-email",
        "-e",
        required=True,
        prompt=True,
        type=click.STRING,
        help="The email of the user which executed the pipeline.",
    ),
    click.option(
        "--work-name",
        "-n",
        required=True,
        prompt=True,
        type=click.STRING,
        help="A short name for the current work. Example: OS001.",
    ),
]


__AVAILABLE_DATABASES = [
    db
    for db, available in ReferenceDatabases.check_dbs_availability()
    if available is True
]


# ? ----------------------------------------------------------------------------
# ? Create commands options
# ? ----------------------------------------------------------------------------


@info_cmd.command(
    "assays",
    help="List all available assays.",
)
@click.option(
    "-f",
    "--filter-by",
    required=False,
    type=click.STRING,
    help="Filter assays using text search. Searches by assay name and crops.",
)
def list_available_assays(
    filter_by: str | None,
) -> None:
    from datetime import datetime

    from rich.console import Console
    from rich.table import Table

    table = Table(title="Available Assays")
    table.add_column("Name")
    table.add_column("Slug", style="green")
    table.add_column("Description")
    table.add_column("Updated at", style="magenta")
    table.add_column("Crops")

    for assay in __ENABLED_ASSAYS:
        if filter_by is not None:
            if filter_by.lower() not in assay.name.lower() and not any(
                [filter_by.lower() in crop.name.lower() for crop in assay.crops]
            ):
                continue

        table.add_row(
            assay.name,
            str(assay),
            assay.description,
            datetime.fromisoformat(assay.updated_at)
            .strftime("%d/%m/%Y %H:%M")
            .__str__(),
            ", ".join(sorted([crop.name for crop in assay.crops])),
        )

    console = Console()
    console.print(table)


@info_cmd.command(
    "databases",
    help="List all available databases.",
)
@click.option(
    "-f",
    "--filter-by",
    required=False,
    type=click.STRING,
    help="Filter databases using text search. Searches by name.",
)
def list_available_databases(
    filter_by: str | None,
) -> None:
    from rich.console import Console
    from rich.table import Table

    from mdv.domain.dtos.blast_databases import ReferenceDatabases
    from mdv.settings import NTNR_DATABASES

    table = Table(title="Available Databases")
    table.add_column("Name")
    table.add_column("Slug", style="green")
    table.add_column("Available")
    table.add_column("Files", style="magenta")

    unavailable_databases: list[Path] = []
    get_symbol = lambda available: "✅" if available else "❌"  # noqa: E731

    for db, available in ReferenceDatabases.check_dbs_availability():
        if filter_by is not None:
            if (
                filter_by.lower() not in db.name.lower()
                and filter_by.lower() not in db.value[0].lower()
            ):
                continue

        sequence_file = NTNR_DATABASES.joinpath(
            db.value[1].blast_files.sequences_file_name
        )

        taxonomies_file = NTNR_DATABASES.joinpath(
            db.value[1].blast_files.taxonomies_file_name
        )

        if not sequence_file.is_file():
            unavailable_databases.append(sequence_file)

        if not taxonomies_file.is_file():
            unavailable_databases.append(taxonomies_file)

        table.add_row(
            db.name,
            db.value[0],
            f"{'yes' if available else 'no'} {get_symbol(available)}",
            f"{sequence_file}\n{taxonomies_file}",
        )

    console = Console()
    console.print(table)

    if unavailable_databases.__len__() > 0:
        print("-" * 80)
        print("⚠️  \033[91mUnavailable database files found:\033[0m")
        for db in unavailable_databases:
            print(f"  - {db}")

        print(
            "\n\033[93mNote: databases should be available on "
            + f"`{NTNR_DATABASES}` folder.\033[0m\n"
        )


@info_cmd.command(
    "metadata",
    help="Print example metadata file.",
)
def show_example_metadata() -> None:
    from rich.console import Console
    from rich.table import Table

    from mdv.domain.dtos.bootstrap_handler import MetadataColNamesEnum

    table = Table(title="Bootstrap metadata file")
    table.add_column(MetadataColNamesEnum.SAMPLE_CODE.value)
    table.add_column(MetadataColNamesEnum.FORWARD_FILE.value)
    table.add_column(MetadataColNamesEnum.REVERSE_FILE.value)
    table.add_column(MetadataColNamesEnum.SINGLE_END_RECOVERY.value)
    table.add_column(MetadataColNamesEnum.SERVICE_ORDER.value)
    table.add_column(MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value)

    table.add_row(
        "AGROBIO22001",
        "forward1.fastq.gz",
        "reverse1.fastq.gz",
        "OS001",
        "true",
        "",
    )

    table.add_row(
        "AGROBIO22002",
        "forward2.fastq.gz",
        "reverse2.fastq.gz",
        "OS001",
        "false",
        "false",
    )

    table.add_row(
        "AGROBIO22003",
        "forward3.fastq.gz",
        "reverse3.fastq.gz",
        "OS002",
        "false",
        "",
    )

    console = Console()
    console.print(table)


@info_cmd.command(
    "blob-indices",
    help="Print example blob index file.",
)
def show_example_blob_indices_file() -> None:
    from rich.console import Console
    from rich.table import Table

    table = Table(title="Blob indices file")
    table.add_column("sample")
    table.add_column("crop")
    table.add_column("country")
    table.add_column("state_province")

    table.add_row(
        "ITS-AGROBIO220055",
        "soybean",
        "Brazil",
        "SP",
    )

    table.add_row(
        "ITS-AGROBIO220056",
        "soybean",
        "Brazil",
        "SP",
    )

    table.add_row(
        "ITS-AGROBIO220057",
        "soybean",
        "Brazil",
        "SP",
    )

    console = Console()
    console.print(table)


@meta_da_vinci_cmd.command(
    "boot",
    help="Generate the configuration file needed for analysis start.",
)
@click.option(
    "--customer",
    required=True,
    prompt=True,
    type=click.UUID,
    help="The customer Universally Unique Identifier (UUID).",
)
@click.option(
    "--assay",
    required=True,
    prompt=True,
    type=click.Choice(
        [i.__str__() for i in __ENABLED_ASSAYS],
        case_sensitive=True,
    ),
    help="The assay name to perform comparisons.",
)
@click.option(
    "--taxon",
    required=True,
    prompt=True,
    type=click.Choice(
        sorted([i.value for i in TaxaEnum]),
        case_sensitive=True,
    ),
    help="The taxon used to select adequate analysis parameters.",
)
@click.option(
    "-db",
    "--reference-database",
    required=True,
    prompt=True,
    type=click.Choice(
        [i.value[0] for i in __AVAILABLE_DATABASES],
        case_sensitive=True,
    ),
)
@__extend_options(
    [
        *__FILE_DIR_CMD_LIST_BOOTSTRAP,
        __FORCE_OVERWRITE_CMD,
        __SILENCE_NOTIFICATION_CMD,
    ]
)
@click.option(
    "-mf",
    "--metadata-file",
    required=False,
    type=click.Path(
        resolve_path=False,
        readable=True,
        exists=False,
    ),
    default=None,
    help="Use metadata file for bootstrap (mutually exclusive with -iv)",
)
@click.option(
    "-iv",
    "--inventory-file",
    required=False,
    type=click.Path(
        resolve_path=False,
        readable=True,
        exists=False,
    ),
    default=None,
    help="Use inventory file for bootstrap (mutually exclusive with -mf)",
)
@click.option(
    "-l",
    "--legacy-boot",
    is_flag=True,
    show_default=True,
    default=False,
    help="Use legacy bootstrap.",
)
def generate_bootstrap_from_file_cmd(
    customer: str,
    assay: str,
    taxon: str,
    source_directory: str,
    work_directory: str,
    metadata_file: str | None,
    inventory_file: str | None,
    reference_database: str,
    force_overwrite: bool,
    legacy_boot: bool,
    **_: Any,
) -> None:
    """Generate the configuration file needed for analysis start.
        Args:
        assay (str): The assay name to perform comparisons.
        customer (str): The customer name.
        source_directory (str): A directory containing the source FASTQ files.
        work_directory (str): A directory to save the pipeline outputs.
        metadata_file (str): A directory to save the pipeline outputs.
        reference_database (str): The reference database to use.
        force_overwrite (bool): Force overwrite the output directory if `True`.
        legacy_boot (bool): Use legacy bootstrap.

    Raises:
        ValueError: If `assay` is not a valid assay name.
        ValueError: If `reference_database` is not a valid database name.
    """

    if not metadata_file and not inventory_file:
        raise click.UsageError(
            "You need inform --metadata-file OR --inventory-file"
        )
    if metadata_file and inventory_file:
        raise click.UsageError(
            "--metadata-file and --inventory-file are mutually exclusives"
        )

    if inventory_file:
        token_gen = TokenGenerator()
        token_gen.get_token()

    try:
        LOGGER.debug("Validating arguments")

        enabled_assays = [i.__str__() for i in __ENABLED_ASSAYS]

        if assay not in enabled_assays:
            raise ValueError(
                f"`assay` should be one of this: {enabled_assays}",
            )

        reference_database_enum = ReferenceDatabases.get_database_by_name(
            db_name=reference_database
        )

        if not reference_database_enum:
            raise ValueError(
                "`reference_database` should be one of this: "
                + f"{ReferenceDatabases.get_database_str_names()}",
            )

        LOGGER.info("Initialize bootstrap")

        inventory_file = Path(inventory_file) if inventory_file else None

        try:
            with open(inventory_file, "r", encoding="utf-8") as f:
                json_data = json.load(f)
            tax = TaxaEnum(taxon)
            metadata_file = RunAnalysisBootstrap.generate_metadata_tsv(
                json_data=json_data, taxa=tax
            )
        except TypeError:
            pass

        bootstrap = RunAnalysisBootstrap(
            customer=customer.__str__(),
            assay=assay,
            taxa=TaxaEnum(taxon),
            metadata_file=Path(metadata_file) if metadata_file else None,
            source_directory=Path(source_directory),
            work_directory=Path(work_directory),
            blast_database=reference_database_enum,
        )

        response_either = bootstrap.initialize_analysis_directory(
            overwrite=force_overwrite,
            legacy_boot=legacy_boot,
        )

        if response_either.is_left:
            LOGGER.error(response_either.value)
            raise Exception(
                "Unexpected error detected on create analysis artifact.",
            )

        response: tuple[Path, AnalysisConfig] = response_either.value
        config_file, _ = response

        LOGGER.info(f"Analysis config file is available at {config_file}\n")

        if inventory_file:
            metadata_file = Path(metadata_file)
            metadata_file.unlink()
        else:
            metadata_file = Path(metadata_file)

    except Exception as exc:
        raise exc


@__extend_options(
    [
        *__FILE_DIR_CMD_LIST,
        __FORCE_OVERWRITE_CMD,
        __SILENCE_NOTIFICATION_CMD,
    ]
)
@click.option(
    "-l",
    "--legacy-boot",
    is_flag=True,
    show_default=True,
    default=False,
    help="Use legacy bootstrap.",
)
@check_cmd.command(
    "sample-sheet",
    help="Check validity of a SampleSheet.csv file.",
)
@__SAMPLE_SHEET
@click.option(
    "-p",
    "--print-result",
    is_flag=True,
    show_default=True,
    default=False,
    help="Print loaded SampleSheet.csv as a JSON object.",
)
def check_sample_sheet(
    sample_sheet_path: str,
    print_result: bool,
) -> None:
    from json import dumps

    from mdv.domain.dtos.sample_sheet import SampleSheet

    if (
        res := SampleSheet.from_tabular_samplesheet(
            file_path=Path(sample_sheet_path)
        )
    ).is_left:
        raise Exception(res.value.msg)

    if print_result is True:
        print(dumps(res.value.to_dict(), default=str, indent=4))

    click.echo("Sample sheet is right!")


@check_cmd.command(
    "blob-indices-map",
    help="Check validity of a blob indices file.",
)
@__BLOB_INDICES_MAPPING
def check_blob_indiecs_map(
    blob_indices_mapping_path: str,
) -> None:
    from pandas import read_csv

    from mdv.domain.dtos.blob_indices import SampleCropMap

    SampleCropMap.validate(
        read_csv(blob_indices_mapping_path, sep="\t"),
    )

    click.echo("Blob indices is right!")


@check_cmd.command(
    "docker-images",
    help="Check if all docker-images are available on the host system.",
)
@click.option(
    "-p",
    "--pull-if-not-found",
    is_flag=True,
    show_default=True,
    default=False,
    help="Pull images if not found in the host system.",
)
@with_docker_client
def check_docker_images_cmd(
    docker_client: DockerClient,
    pull_if_not_found: bool,
    **_: Any,
) -> None:
    """Check if all docker images are available"""

    from mdv.adapters.executors.docker import (
        ProjectDockerImages,
        check_docker_images_availability,
    )

    LOGGER.info(" ".join(argv))

    try:
        check_docker_images_availability(
            client=docker_client,
            pull_if_not_found=pull_if_not_found,
            images=[i.value for i in ProjectDockerImages],
        )

    except Exception as exc:
        raise exc


@qc_cmd.command(
    "seq",
    help="Execute the quality control steps only.",
)
@__extend_options(
    [
        *__CHAT_NOTIFICATION_CMD_LIST,
        *__FILE_DIR_CMD_LIST,
        *__ADDITIONAL_QC_CMD_LIST,
        *__ADDITIONAL_RAREFY_CMD_LIST,
        __SILENCE_NOTIFICATION_CMD,
    ]
)
@with_docker_client
@with_repositories
@with_chat_notification
def run_seq_qc_cmd(
    source_directory: str,
    work_directory: str,
    metadata_file: str,
    single_step_repos: SingleStepPipelineRepositories,
    docker_client: DockerClient,
    **kwargs: Any,
) -> None:
    """Run Quality Control pipeline"""

    from pandas import read_csv

    from mdv.adapters.executors.docker import (
        ProjectDockerImages,
        check_docker_images_availability,
    )
    from mdv.domain.dtos.bootstrap_handler import BootstrapHandler
    from mdv.domain.entities.qc.dereplicate import DerepStrategyEnum
    from mdv.use_cases.run_quality_control_of_raw_sequencing_data import (
        RunQualityControlOfRawSequencingData,
    )
    from mdv.use_cases.shared.run_library_sample_effectiveness import (
        RarefactionParams,
    )
    from mdv.use_cases.shared.run_qc_on_single_sample import QcStepParams

    LOGGER.info(" ".join(argv))

    try:
        if (
            check_docker_images_availability(
                client=docker_client,
                images=[
                    ProjectDockerImages.TRIMMOMATIC.value,
                    ProjectDockerImages.BIO_UBUNTU.value,
                ],
            )
            is False
        ):
            raise Exception(
                "The required docker images are not available. "
                + "Please run `docker pull` to download them.",
            )

        samples_map = read_csv(metadata_file, sep="\t")

        if (
            MetadataColNamesEnum.SINGLE_END_RECOVERY.value
            in samples_map.columns
        ):
            samples_map[MetadataColNamesEnum.SINGLE_END_RECOVERY.value].fillna(
                False, inplace=True
            )

        if (
            MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value
            in samples_map.columns
        ):
            samples_map[MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value].fillna(
                False, inplace=True
            )

        runner = RunQualityControlOfRawSequencingData(
            source_directory=Path(source_directory),
            work_directory=Path(work_directory),
            bootstrap_handler=BootstrapHandler(
                samples_map=samples_map,
                source_directory=Path(source_directory),
            ),
            repos=single_step_repos,
            qc_params=QcStepParams(
                head_crop=kwargs.get("head_crop"),
                leading_quality=kwargs.get("leading_quality"),
                trailing_quality=kwargs.get("trailing_quality"),
                end_crop=kwargs.get("tail_crop"),
                derep_strategy=DerepStrategyEnum(kwargs.get("derep_strategy")),
                min_cluster_size=kwargs.get("min_cluster_size"),
                single_end_recovery_strategy=kwargs.get(
                    "single_end_recovery_strategy"
                ),
                sample_size=kwargs.get("sample_size"),
            ),
            rarefy_params=RarefactionParams(
                with_sample_effectiveness=kwargs.get(
                    "with_sample_effectiveness"
                ),
                rarefaction_kuttoff_isolates=kwargs.get(
                    "rarefaction_kuttoff_isolates"
                ),
                rarefaction_kuttoff_complex=kwargs.get(
                    "rarefaction_kuttoff_complex"
                ),
            ),
            **kwargs,
        )

        response_either = runner.run()

        if response_either.is_left:
            raise Exception(response_either.value.msg)

        (output_file_json, _) = response_either.value
        return output_file_json

    except Exception as exc:
        raise exc


@qc_cmd.command(
    "boot",
    help="Execute the quality control steps only.",
)
@__extend_options(
    [
        __CONFIG_FILE_CMD,
        __SOURCE_DIRECTORY(required=False),
        *__CHAT_NOTIFICATION_CMD_LIST,
        *__ADDITIONAL_QC_CMD_LIST,
        *__ADDITIONAL_RAREFY_CMD_LIST,
        __SILENCE_NOTIFICATION_CMD,
    ]
)
@with_docker_client
@with_repositories
@with_chat_notification
def run_boot_qc_cmd(
    config_file: str,
    single_step_repos: SingleStepPipelineRepositories,
    docker_client: DockerClient,
    source_directory: str | None,
    **kwargs: Any,
) -> Path:
    """Execute the quality control steps only.

    Args:
        config_file (str): The file path of the JSON config file.
        single_step_repos (SingleStepPipelineRepositoriesDTO): The repositories
            of the single step pipelines.

    Raises:
        Exception: If an unexpected error is detected.

    """

    from mdv.adapters.executors.docker import (
        ProjectDockerImages,
        check_docker_images_availability,
    )
    from mdv.domain.dtos.analysis_config import AnalysisConfig
    from mdv.domain.entities.qc.dereplicate import DerepStrategyEnum
    from mdv.use_cases.run_quality_control_step_from_bootstrap import (
        RunQualityControlStepFromBootstrap,
    )
    from mdv.use_cases.shared.run_library_sample_effectiveness import (
        RarefactionParams,
    )
    from mdv.use_cases.shared.run_qc_on_single_sample import QcStepParams

    LOGGER.info(" ".join(argv))

    try:
        if (
            check_docker_images_availability(
                client=docker_client,
                images=[
                    ProjectDockerImages.TRIMMOMATIC.value,
                    ProjectDockerImages.BIO_UBUNTU.value,
                ],
            )
            is False
        ):
            raise Exception(
                "The required docker images are not available. "
                + "Please run `docker pull` to download them.",
            )

        config_file_path = Path(config_file)

        sample_set_dto_either = AnalysisConfig.from_json(
            config_file_path=config_file_path,
            source_directory=(
                Path(source_directory) if source_directory is not None else None
            ),
        )

        if sample_set_dto_either.is_left:
            msg = (
                "Unexpected error detected on load analysis configuration: "
                + f"{sample_set_dto_either.value.msg}"
            )

            LOGGER.exception(msg)
            raise Exception(msg)

        analysis_config: AnalysisConfig = sample_set_dto_either.value

        runner = RunQualityControlStepFromBootstrap(
            sample_set=analysis_config,
            source_directory=(
                analysis_config.metadata_artifact.parent
                if analysis_config.legacy is True
                else analysis_config.source_directory
            ),
            work_directory=config_file_path.parent,
            single_step_repos=single_step_repos,
            qc_params=QcStepParams(
                head_crop=kwargs.get("head_crop"),
                leading_quality=kwargs.get("leading_quality"),
                trailing_quality=kwargs.get("trailing_quality"),
                end_crop=kwargs.get("tail_crop"),
                derep_strategy=DerepStrategyEnum(kwargs.get("derep_strategy")),
                min_cluster_size=kwargs.get("min_cluster_size"),
                single_end_recovery_strategy=kwargs.get(
                    "single_end_recovery_strategy"
                ),
                sample_size=kwargs.get("sample_size"),
            ),
            rarefy_params=RarefactionParams(
                with_sample_effectiveness=kwargs.get(
                    "with_sample_effectiveness"
                ),
                rarefaction_kuttoff_isolates=kwargs.get(
                    "rarefaction_kuttoff_isolates"
                ),
                rarefaction_kuttoff_complex=kwargs.get(
                    "rarefaction_kuttoff_complex"
                ),
            ),
            **kwargs,
        )

        response_either = runner.run_qc_steps()

        if response_either.is_left:
            raise Exception(response_either.value.msg)

        (output_file_json, _) = response_either.value

        return output_file_json

    except Exception as exc:
        raise exc


@meta_da_vinci_cmd.command(
    "pipe",
    help="Options to run the pipeline steps.",
)
@__extend_options(
    [
        __CONFIG_FILE_CMD,
        __SOURCE_DIRECTORY(required=False),
        *__CHAT_NOTIFICATION_CMD_LIST,
        *__ADDITIONAL_QC_CMD_LIST,
        *__ADDITIONAL_RAREFY_CMD_LIST,
    ]
)
@click.option(
    "--full-picrust-pipeline",
    is_flag=True,
    show_default=True,
    default=False,
    help=(
        "Execute the full pipeline of picrust for functional annotation. "
        + "Case `False` the step-by-step functional annotation pipeline will "
        + "be executed."
    ),
)
@click.option(
    "--chunk-size",
    required=False,
    type=click.INT,
    default=2000,
    show_default=True,
    help=(
        "FUNCTIONAL ANNOTATION (Place Seqs.): The number of sequences to "
        + "include into a single alignment and analysis during sequences "
        + "placement step."
    ),
)
@click.option(
    "--tax-assignment-tool",
    required=False,
    type=click.Choice([i.value for i in TaxAssignmentTools]),
    default=TaxAssignmentTools(None).value,
    show_default=True,
    help=(
        "TAX-ASSIGNMENT: Select the tool used to assign taxonomies to analysis "
        + "sequences."
    ),
)
@__extend_options([__SILENCE_NOTIFICATION_CMD])
@with_docker_client
@with_repositories
@with_chat_notification
def process_paired_end_sample_set_cmd(
    config_file: str,
    single_step_repos: SingleStepPipelineRepositories,
    docker_client: DockerClient,
    full_picrust_pipeline: bool,
    source_directory: str | None,
    **kwargs: Any,
) -> Path | None:
    """Run the pipeline steps on a sample set.

    Args:
        config_file (str): The file path of the JSON config file.
        single_step_repos (SingleStepPipelineRepositoriesDTO): The DTO with the
            repositories of the single steps.

    Raises:
        Exception: If an unexpected error is detected.

    """

    from mdv.adapters.executors.docker import (
        ProjectDockerImages,
        check_docker_images_availability,
    )
    from mdv.domain.dtos.analysis_config import AnalysisConfig
    from mdv.domain.entities.qc.dereplicate import DerepStrategyEnum
    from mdv.use_cases.run_analysis_pipeline import RunAnalysisPipeline
    from mdv.use_cases.run_analysis_pipeline._assign_taxonomy_from_blast import (
        TaxAssignmentTools,
    )
    from mdv.use_cases.shared.run_library_sample_effectiveness import (
        RarefactionParams,
    )
    from mdv.use_cases.shared.run_qc_on_single_sample import QcStepParams

    LOGGER.info(" ".join(argv))

    try:
        if (
            check_docker_images_availability(
                client=docker_client,
                images=[i.value for i in ProjectDockerImages],
            )
            is False
        ):
            raise Exception(
                "The required docker images are not available. "
                + "Please run `docker pull` to download them.",
            )

        config_file_path = Path(config_file)

        sample_set_dto_either = AnalysisConfig.from_json(
            config_file_path=config_file_path,
            source_directory=(
                Path(source_directory) if source_directory is not None else None
            ),
        )

        if sample_set_dto_either.is_left:
            LOGGER.exception(
                "Unexpected error detected on load analysis configuration: "
                + f"{sample_set_dto_either.value}",
            )

            return None

        sample_set_dto: AnalysisConfig = sample_set_dto_either.value

        runner = RunAnalysisPipeline(
            sample_set=sample_set_dto,
            work_directory=config_file_path.parent,
            source_directory=(
                sample_set_dto.metadata_artifact.parent
                if sample_set_dto.legacy is True
                else sample_set_dto.source_directory
            ),
            single_step_repos=single_step_repos,
            full_picrust_pipeline=full_picrust_pipeline,
            qc_params=QcStepParams(
                head_crop=kwargs.get("head_crop"),
                leading_quality=kwargs.get("leading_quality"),
                trailing_quality=kwargs.get("trailing_quality"),
                end_crop=kwargs.get("tail_crop"),
                derep_strategy=DerepStrategyEnum(kwargs.get("derep_strategy")),
                min_cluster_size=kwargs.get("min_cluster_size"),
                single_end_recovery_strategy=kwargs.get(
                    "single_end_recovery_strategy"
                ),
                sample_size=kwargs.get("sample_size"),
            ),
            rarefy_params=RarefactionParams(
                with_sample_effectiveness=kwargs.get(
                    "with_sample_effectiveness"
                ),
                rarefaction_kuttoff_isolates=kwargs.get(
                    "rarefaction_kuttoff_isolates"
                ),
                rarefaction_kuttoff_complex=kwargs.get(
                    "rarefaction_kuttoff_complex"
                ),
            ),
            **{
                **kwargs,
                "tax_assignment_tool": (
                    TaxAssignmentTools(val)
                    if (val := kwargs.get("tax_assignment_tool")) is not None
                    else None
                ),
            },
        )

        response_either = runner.run_by_sample_sequentially()

        if response_either.is_left:
            raise Exception(response_either.value.msg)

        return None

    except Exception as exc:
        raise exc


@persist_cmd.command(
    "seq",
    help="Persist sequencing results to cloud storage.",
)
@__SAMPLE_SHEET
@click.option(
    "-qc",
    "--default-qc-report-path",
    required=True,
    prompt=True,
    type=click.Path(
        resolve_path=True,
        readable=True,
        exists=True,
    ),
    help="The Quality Control file generated after run `mdv qc seq` command.",
)
@__BLOB_INDICES_MAPPING
@click.option(
    "-qcs",
    "--single-end-qc-report-path",
    required=False,
    type=click.Path(
        resolve_path=True,
        readable=True,
        exists=True,
    ),
    default=None,
    help=(
        "The Quality Control file generated after run `mdv qc seq` command "
        + "with single-end recovery strategy."
    ),
)
@click.option(
    "-sd",
    "--sequencing-directory",
    required=True,
    prompt=True,
    type=click.Path(
        resolve_path=True,
        readable=True,
        exists=True,
        dir_okay=True,
    ),
    help="A directory to save the pipeline outputs.",
)
@click.option(
    "-y",
    "--sequencing-year",
    required=True,
    prompt=True,
    type=click.INT,
    help="The year of the sequencing.",
)
@click.option(
    "--extra-index-kv",
    required=False,
    type=click.STRING,
    default=None,
    multiple=True,
)
@click.option(
    "--extra-metadata-kv",
    required=False,
    type=click.STRING,
    default=None,
    multiple=True,
)
def persist_sequencing_results(
    sequencing_year: int,
    sample_sheet_path: str,
    default_qc_report_path: str,
    sequencing_directory: str,
    blob_indices_mapping_path: str,
    single_end_qc_report_path: str | None,
    extra_index_kv: list[str],
    extra_metadata_kv: list[str],
) -> None:
    extra_index_kv_dict: dict[str, Any] = dict()
    index_keys: list[str] = []
    for pair in extra_index_kv:
        if pair.count("=") != 1:
            raise Exception(
                "Invalid key-value pair. "
                + "Please use the following format: `--extra-kv key=value`."
            )

        key, value = pair.split("=")

        if key in index_keys:
            raise Exception(
                f"Invalid key-value pair. Key `{key}` is duplicated."
            )

        index_keys.append(key)
        extra_index_kv_dict.update({key: value})

    extra_metadata_kv_dict: dict[str, Any] = dict()
    meta_keys: list[str] = []
    for pair in extra_metadata_kv:
        if pair.count("=") != 1:
            raise Exception(
                "Invalid key-value pair. "
                + "Please use the following format: `--extra-kv key=value`."
            )

        key, value = pair.split("=")

        if key in meta_keys:
            raise Exception(
                f"Invalid key-value pair. Key `{key}` is duplicated."
            )

        meta_keys.append(key)
        extra_metadata_kv_dict.update({key: value})

    if (
        res := persist_seq_results_to_blob_storage_provider(
            sequencing_year=sequencing_year,
            sample_sheet_path=Path(sample_sheet_path),
            default_qc_report_path=Path(default_qc_report_path),
            sequencing_directory=Path(sequencing_directory),
            single_end_qc_report_path=(
                Path(single_end_qc_report_path)
                if single_end_qc_report_path
                else None
            ),
            extra_index_kv=(
                extra_index_kv_dict
                if extra_index_kv_dict.__len__() > 0
                else None
            ),
            extra_metadata_kv=(
                extra_metadata_kv_dict
                if extra_metadata_kv_dict.__len__() > 0
                else None
            ),
            blob_indices_mapping_path=Path(blob_indices_mapping_path),
            raw_library_blob_registration_repo=RawLibraryBlobRegistrationServiceRepo(),
        )
    ).is_left:
        raise Exception(res.value.msg)


@dump_cmd.command(
    "analysis",
    help="Dump analysis.",
)
@click.option(
    "-d",
    "--analysis-directory",
    required=True,
    prompt=True,
    type=click.Path(
        resolve_path=True,
        readable=True,
        exists=True,
        dir_okay=True,
    ),
    help="A directory containing a set of results.",
)
@click.option(
    "-i",
    "--ignore-pattern",
    required=False,
    type=click.STRING,
    default=list(),
    multiple=True,
)
@click.option(
    "-y",
    "--analysis-year",
    required=True,
    prompt=True,
    type=click.INT,
    help="The year of the analysis.",
)
@click.option(
    "-n",
    "--analysis-name",
    required=True,
    prompt=True,
    type=click.STRING,
    help="The name of the analysis.",
)
def dump_analysis_results(
    analysis_directory: str,
    analysis_name: str,
    analysis_year: str,
    ignore_pattern: list[str],
) -> Any:
    if (
        res := build_backup_artifact_analysis_directory(
            analysis_directory=Path(analysis_directory),
            analysis_name=analysis_name,
            analysis_year=analysis_year,
            ignore_list=list(ignore_pattern),
            analysis_artifact_registration_repo=AnalysisBlobRegistrationServiceRepo(),
        )
    ).is_left:
        raise Exception(res.value.msg)
