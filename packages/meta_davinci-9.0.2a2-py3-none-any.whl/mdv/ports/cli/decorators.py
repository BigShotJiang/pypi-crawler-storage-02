from datetime import datetime
from json import dumps, load
from locale import LC_ALL, setlocale
from pathlib import Path
from typing import Any, Callable, NamedTuple

import requests
from docker import DockerClient, from_env
from mdv.adapters.executors.docker.qc.filtered_match import (
    FilteredMatchStepDockerRepository,
)
from mdv.adapters.executors.docker.qc.rarefaction_generator import (
    SingleSampleRarefactionGeneratorStepDockerRepository,
)

from mdv.adapters.executors.docker.qc.rarefaction_input_builder import (
    SingleSampleRarefactionInputBuildStepDockerRepository,
)
from mdv.adapters.executors.docker.qc.reads_pre_filtering import (
    PreFilterRawReadsStepDockerRepository,
)

from mdv.adapters.executors.docker import (
    AlignAndGeneratePhylogenyDockerRepository,
    CalculatePhylogeneticDiversityIndexesDockerRepository,
    ChimeraRemovalStepDockerRepository,
    DenoiseStepDockerRepository,
    DereplicateStepDockerRepository,
    ExportArtifactDockerRepository,
    FilterResultsDockerRepository,
    HiddenStatePredictionStepDockerRepository,
    ImportBlastOutputDockerRepository,
    ImportFeatureTableDockerRepository,
    ImportFromTSVFeatureTableDockerRepository,
    ImportRawFastaReadsDockerRepository,
    MergePairsStepDockerRepository,
    MetagenomePipelineRepository,
    PlaceSequencesRepository,
    QualityFilterStepDockerRepository,
    RarefyDiversityResultsDockerRepository,
    RunFullPipelineStepDockerRepository,
    SummarizeFeatureTableStepDockerRepository,
    TabulateMetadataStepDockerRepository,
    TabulateRepresentativeSeqsStepDockerRepository,
    TaxonomyPickingWithBioLinnaeusDockerRepository,
    TaxonomyPickingWithBlutilsDockerRepository,
    TrimmingStepDockerRepository,
)
from mdv.settings import BIOINFO_TEAMS_WEBHOOK_URL
from mdv.use_cases.shared.core import SingleStepPipelineRepositories


setlocale(LC_ALL, "")


def with_docker_client(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator to create a docker client and close it after the function

    Args:
        func (Callable[..., Any]): Function to decorate

    Returns:
        Callable[..., Any]: Decorated function

    """

    def wrapper(**kwargs: Any) -> None:
        """Wrapper function to create a docker client and close it after the
        function

        Args:
            **kwargs (Any): Arguments to pass to the function

        """

        try:
            __docker_client = from_env()
        except Exception as exc:
            raise exc
        finally:
            __docker_client.close()

        try:
            return func(**kwargs, docker_client=__docker_client)
        except Exception as exc:
            raise exc
        finally:
            __docker_client.close()

    return wrapper


def with_repositories(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator to create the repositories for the single step pipeline

    Args:
        func (Callable[..., Any]): Function to decorate

    Returns:
        Callable[..., Any]: Decorated function

    """

    def wrapper(docker_client: DockerClient, **kwargs: Any) -> None:
        """Wrapper function to create the repositories for the single step
        pipeline

        Args:
            docker_client (DockerClient): Docker client
            **kwargs (Any): Arguments to pass to the function

        """

        return func(
            **kwargs,
            docker_client=docker_client,
            single_step_repos=SingleStepPipelineRepositories(
                pre_filter_raw_reads=PreFilterRawReadsStepDockerRepository(
                    client=docker_client
                ),
                match_filtered_reads=FilteredMatchStepDockerRepository(
                    client=docker_client
                ),
                trim_paired_end_reads_repo=TrimmingStepDockerRepository(
                    client=docker_client
                ),
                merge_paired_end_reads_repo=MergePairsStepDockerRepository(
                    client=docker_client
                ),
                quality_filter_repo=QualityFilterStepDockerRepository(
                    client=docker_client
                ),
                dereplication_repo=DereplicateStepDockerRepository(
                    client=docker_client
                ),
                denoise_repo=DenoiseStepDockerRepository(client=docker_client),
                chimera_removal_repo=ChimeraRemovalStepDockerRepository(
                    client=docker_client
                ),
                summarize_feature_table_exec_repo=SummarizeFeatureTableStepDockerRepository(
                    client=docker_client
                ),
                summarize_repr_sequences_exec_repo=TabulateRepresentativeSeqsStepDockerRepository(
                    client=docker_client
                ),
                summarize_metadata_exec_repo=TabulateMetadataStepDockerRepository(
                    client=docker_client
                ),
                assign_taxonomy_with_bli_repo=TaxonomyPickingWithBioLinnaeusDockerRepository(
                    client=docker_client
                ),
                assign_taxonomy_with_blu_repo=TaxonomyPickingWithBlutilsDockerRepository(
                    client=docker_client
                ),
                import_raw_fasta_artifact=ImportRawFastaReadsDockerRepository(
                    client=docker_client
                ),
                phylogeny_generation_exec_repo=AlignAndGeneratePhylogenyDockerRepository(
                    client=docker_client
                ),
                diversity_filtration_exec_repo=FilterResultsDockerRepository(
                    client=docker_client
                ),
                diversity_rarefaction_exec_repo=RarefyDiversityResultsDockerRepository(
                    client=docker_client
                ),
                diversity_indexes_calculation_exec_repo=CalculatePhylogeneticDiversityIndexesDockerRepository(
                    client=docker_client
                ),
                function_annotation_exec_repo=RunFullPipelineStepDockerRepository(
                    client=docker_client
                ),
                place_sequences_in_tree_of_life_repo=PlaceSequencesRepository(
                    client=docker_client
                ),
                hidden_state_prediction_repo=HiddenStatePredictionStepDockerRepository(
                    client=docker_client
                ),
                metagenome_pipeline_repo=MetagenomePipelineRepository(
                    client=docker_client
                ),
                import_blast_output_artifact=ImportBlastOutputDockerRepository(
                    client=docker_client
                ),
                import_from_tsv_artifacts=ImportFromTSVFeatureTableDockerRepository(
                    client=docker_client
                ),
                import_from_biom_artifacts=ImportFeatureTableDockerRepository(
                    client=docker_client
                ),
                export_artifact=ExportArtifactDockerRepository(client=docker_client),
                build_rarefaction_input_repo=SingleSampleRarefactionInputBuildStepDockerRepository(
                    client=docker_client
                ),
                generate_rarefaction_repo=SingleSampleRarefactionGeneratorStepDockerRepository(
                    client=docker_client
                ),
            ),
        )

    return wrapper


def with_chat_notification(
    func: Callable[..., Path | None],
) -> Callable[..., Path]:
    """Decorator to send chat notification on MS teams

    Args:
        func (Callable[..., Any]): Function to decorate

    Returns:
        Callable[..., Any]: Decorated function

    """

    def format_message(
        success: bool,
        user_email: str,
        work_name: str,
        msg: str | None,
        customer_id: str | None = None,
        crop: str | None = None,
        taxa: str | None = None,
    ) -> dict[str, Any]:
        """Wrapper function to create send the chat notification

        Args:
            success (bool): The execution status.
            msg (str): The execution message.
            user_email (str): The email of the user which start the action.

        """

        status = "success"
        color = "56d700"
        if success is False:
            status = "error"
            color = "d71d00"

        summary = f"[ {status.upper()} ]`{func.__doc__}`"

        facts = [
            {
                "name": "User",
                "value": user_email,
            },
            {
                "name": "Pipeline",
                "value": "MetaDaVinci",
            },
            {
                "name": "Work Name",
                "value": work_name,
            },
            {
                "name": "Event Date",
                "value": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            },
        ]

        if customer_id is not None:
            facts.append(
                {
                    "name": "Customer ID",
                    "value": customer_id,
                }
            )

        if crop is not None:
            facts.append(
                {
                    "name": "Crop",
                    "value": crop,
                }
            )

        if taxa is not None:
            facts.append(
                {
                    "name": "Taxa",
                    "value": taxa,
                }
            )

        if msg is not None:
            facts.append(
                {
                    "name": "Message",
                    "value": str(msg),
                }
            )

        return {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": color,
            "summary": summary,
            "sections": [
                {
                    "activityTitle": summary,
                    "activitySubtitle": "The MetaDaVinci Project",
                    "facts": facts,
                    "markdown": True,
                }
            ],
        }

    def wrapper(
        user_email: str,
        **kwargs: Any,
    ) -> Any:
        """Wrapper function to run the decorated function and notify the MS
        Teams chat.

        Args:
            user_email (str): The email of the user which start the action.
            **kwargs (Any): Arguments to pass to the function

        """

        silent_notification = kwargs.get("silent_notifications", False)

        if silent_notification:
            return func(**kwargs)

        customer: str | None = None
        qc_stats: str = str()
        crop: str | None = None
        taxa: str | None = None
        work_name: str | None = None

        # ? --------------------------------------------------------------------
        # ? If the config file exists, try to load analysis metadata
        # ? --------------------------------------------------------------------

        if (work_name := kwargs.get("work_name")) is not None:
            work_name = str(work_name)

        if (config_file := kwargs.get("config_file")) is not None:
            config_file_path: Path = Path(str(config_file))

            if config_file_path.is_file():
                with config_file_path.open() as reader:
                    content = load(reader)
                    customer = content.get("customer")
                    crop = content.get("crop")
                    taxa = content.get("taxa")

        response: Any = None
        payload: dict[str, str] = dict()
        payload_params: dict[str, Any]
        success: bool = False
        exception: Exception | None = None

        try:
            response = func(**kwargs)
            success = True
            payload_params = dict(
                success=success,
                msg="Success",
                user_email=user_email,
                customer_id=customer,
                crop=crop,
                taxa=taxa,
                work_name=work_name,
            )

        except Exception as exc:
            exception = exc
            success = False
            payload_params = dict(
                success=success,
                msg=str(exception),
                user_email=user_email,
                customer_id=customer,
                crop=crop,
                taxa=taxa,
                work_name=work_name,
            )

        if isinstance(response, Path) and response.exists():
            with response.open() as reader:
                content = load(reader)

                if isinstance(content, dict):
                    for stat in __extract_qc_stats(content):
                        row = "\n\n".join(
                            [
                                f"{stat.sample}\t",
                                f"  RAW ( F | R ): {stat.raw_forward_reads:n} | {stat.raw_reverse_reads:n}",
                                f"  TRIM ( F | R ): {stat.trimming_forward_paired_reads:n} | {stat.trimming_reverse_paired_reads:n}",
                                f"  FINAL: {stat.chimera_free:n}",
                                "\n\n",
                            ]
                        )

                        qc_stats = qc_stats + "\n\n---\n\n" + row

                    payload_params["msg"] = payload_params["msg"] + "\n" + qc_stats

        payload = format_message(**payload_params)

        chat_response = requests.post(
            BIOINFO_TEAMS_WEBHOOK_URL,
            headers={"Content-Type": "application/json"},
            data=dumps(payload),
        )

        if chat_response.status_code != 200:
            raise Exception("Unable to send MS Teams chat notification")

        if exception is not None:
            raise exception
        return response

    return wrapper


class QCStats(NamedTuple):
    sample: str
    raw_forward_reads: int
    raw_reverse_reads: int
    trimming_forward_paired_reads: int
    trimming_reverse_paired_reads: int
    chimera_free: int


def __extract_qc_stats(
    content: dict[str, dict[str, dict[str, int]]],
) -> list[QCStats]:
    target_stats: dict[str, list[str]] = {
        "raw": ["forward_reads", "reverse_reads"],
        "trimming": ["forward_paired_reads", "reverse_paired_reads"],
        "chimera_free": ["chimera_free"],
    }

    qc_stats: list[QCStats] = []

    for sample, sample_stats in content.items():
        if (raw := sample_stats.get("raw")) is None:
            continue

        if (trimming := sample_stats.get("trimming")) is None:
            continue

        if (chimera_free := sample_stats.get("chimera_free")) is None:
            continue

        for key in target_stats.get("raw", []):
            if key not in raw:
                continue

        for key in target_stats.get("trimming", []):
            if key not in trimming:
                continue

        for key in target_stats.get("chimera_free", []):
            if key not in chimera_free:
                continue

        qc_stats.append(
            QCStats(
                sample=sample,
                raw_forward_reads=raw["forward_reads"],
                raw_reverse_reads=raw["reverse_reads"],
                trimming_forward_paired_reads=trimming["forward_paired_reads"],
                trimming_reverse_paired_reads=trimming["reverse_paired_reads"],
                chimera_free=chimera_free["chimera_free"],
            )
        )

    return qc_stats
