from datetime import datetime
from logging import (
    CRITICAL,
    DEBUG,
    ERROR,
    FATAL,
    INFO,
    NOTSET,
    WARN,
    WARNING,
    FileHandler,
    Formatter,
    StreamHandler,
    getLogger,
)
from os import environ, getenv
from pathlib import Path
from typing import Any

import pytz

# ? ----------------------------------------------------------------------------
# ? The `LOGGER` are propagated along the application.
# ? ----------------------------------------------------------------------------


LOGGING_LEVEL = INFO


ENV_LOGGING_LEVEL = getenv("LOGGING_LEVEL")


if ENV_LOGGING_LEVEL is not None:
    ENV_LOGGING_LEVEL = eval(ENV_LOGGING_LEVEL.upper())

    if ENV_LOGGING_LEVEL not in [
        CRITICAL,
        DEBUG,
        ERROR,
        FATAL,
        INFO,
        NOTSET,
        WARN,
        WARNING,
    ]:
        raise ValueError(
            f"Invalid `ENV_LOGGING_LEVEL` value from env: {ENV_LOGGING_LEVEL}"
        )

    LOGGING_LEVEL = ENV_LOGGING_LEVEL  # type: ignore


APP_NAME = "QUORUM-SENSING"


LOGGER = getLogger(APP_NAME)


LOGGER.setLevel(DEBUG)


class CFormatter(Formatter):
    def converter(self, timestamp: Any) -> Any:
        dt = datetime.fromtimestamp(timestamp, tz=pytz.UTC)
        return dt.astimezone(pytz.timezone("America/Sao_Paulo"))

    def formatTime(self, record: Any, datefmt: Any = None) -> str:
        dt = self.converter(record.created)
        if datefmt:
            s = dt.strftime(datefmt)
        else:
            try:
                s = dt.isoformat(timespec="milliseconds")
            except TypeError:
                s = dt.isoformat()
        return s


formatter = CFormatter(
    "%(levelname)s [ %(asctime)s ] %(message)s",
    datefmt="%Y-%d-%m %H:%M:%S",
)


file_handler = FileHandler(getenv("LOGGING_FILE", "mdv.log"))
file_handler.setLevel(DEBUG)
file_handler.setFormatter(formatter)
LOGGER.addHandler(file_handler)


stream_handler = StreamHandler()
stream_handler.setLevel(LOGGING_LEVEL)
stream_handler.setFormatter(formatter)
LOGGER.addHandler(stream_handler)


# ? ----------------------------------------------------------------------------
# ? BASE PATHS
# ? ----------------------------------------------------------------------------


BASE_PATH = Path("~/storage").expanduser()


ENV_BASE_PATH = getenv("BASE_PATH")


if ENV_BASE_PATH is not None:
    BASE_PATH = Path(ENV_BASE_PATH)

    if BASE_PATH.is_absolute() is False:
        BASE_PATH = BASE_PATH.expanduser()


LOGGER.debug(f"BASE_PATH: {BASE_PATH}")


# ? ----------------------------------------------------------------------------
# ? LOCK FILE ELEMENTS
# ? ----------------------------------------------------------------------------


LOCK_FILE = "finished.lock"


# ? ----------------------------------------------------------------------------
# ? CONFIG FILE ELEMENTS
# ? ----------------------------------------------------------------------------


BOOT_CONFIG_FILE_NAME = "analysis-config.json"


# ? ----------------------------------------------------------------------------
# ? DUMP CONFIG
# ? ----------------------------------------------------------------------------


DUMP_MAIN_DIRECTORY = "dump"


DUMP_MAPPING_FILE = "dump-mapping.json"


DUMP_FOLDER_SUFFIX = ".mdvdump.tar.bz2"


DUMP_FILE_SUFFIX = ".mdvdump.bz2"


# ? ----------------------------------------------------------------------------
# ? REFERENCE DATABASE ELEMENTS
#
# QIIME2 database - NTNR
# ? ----------------------------------------------------------------------------


NTNR_DATABASES = BASE_PATH.joinpath(
    getenv(
        "NTNR_DATABASES",
        "databases/thirdparty/ntnr/2022-04-16",
    )
)


# ? 16S ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_16S_SEQUENCES = NTNR_DATABASES.joinpath(
    "16S_ribosomal_RNA.fna"
)


DBS_THIRDPARTY_BIOLINNAEUS_16S_TAXONOMY = NTNR_DATABASES.joinpath(
    "16S_ribosomal_RNA_taxonomies.tsv"
)


# ? 18S ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_18S_FUNGAL_SEQUENCES = NTNR_DATABASES.joinpath(
    "18S_fungal_sequences.fna"
)


DBS_THIRDPARTY_BIOLINNAEUS_18S_FUNGAL_TAXONOMY = NTNR_DATABASES.joinpath(
    "18S_fungal_sequences_taxonomies.tsv"
)


# ? 28S ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_28S_FUNGAL_SEQUENCES = NTNR_DATABASES.joinpath(
    "28S_fungal_sequences.fna"
)


DBS_THIRDPARTY_BIOLINNAEUS_28S_FUNGAL_TAXONOMY = NTNR_DATABASES.joinpath(
    "28S_fungal_sequences_taxonomies.tsv"
)


# ? ITS ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_ITS_EUKARYOTE_SEQUENCES = NTNR_DATABASES.joinpath(
    "ITS_eukaryote_sequences.fna"
)


DBS_THIRDPARTY_BIOLINNAEUS_ITS_EUKARYOTE_TAXONOMY = NTNR_DATABASES.joinpath(
    "ITS_eukaryote_sequences_taxonomies.tsv"
)


# ? ITS refseq ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_ITS_REFSEQ_FUNGAL_SEQUENCES = (
    NTNR_DATABASES.joinpath("ITS_RefSeq_Fungi.fna")
)


DBS_THIRDPARTY_BIOLINNAEUS_ITS_REFSEQ_FUNGAL_TAXONOMY = NTNR_DATABASES.joinpath(
    "ITS_RefSeq_Fungi_taxonomies.tsv"
)


# ? LSU eukaryote ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_LSU_EUKARYOTE_SEQUENCES = NTNR_DATABASES.joinpath(
    "LSU_eukaryote_rRNA.fna"
)


DBS_THIRDPARTY_BIOLINNAEUS_LSU_EUKARYOTE_TAXONOMY = NTNR_DATABASES.joinpath(
    "LSU_eukaryote_rRNA_taxonomies.tsv"
)


# ? LSU prokaryote ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_LSU_PROKARYOTE_SEQUENCES = NTNR_DATABASES.joinpath(
    "LSU_prokaryote_rRNA.fna"
)


DBS_THIRDPARTY_BIOLINNAEUS_LSU_PROKARYOTE_TAXONOMY = NTNR_DATABASES.joinpath(
    "LSU_prokaryote_rRNA_taxonomies.tsv"
)


# ? SSU eukaryote ribosomal

DBS_THIRDPARTY_BIOLINNAEUS_SSU_EUKARYOTE_SEQUENCES = NTNR_DATABASES.joinpath(
    "SSU_eukaryote_rRNA.fna"
)


DBS_THIRDPARTY_BIOLINNAEUS_SSU_EUKARYOTE_TAXONOMY = NTNR_DATABASES.joinpath(
    "SSU_eukaryote_rRNA_taxonomies.tsv"
)


# ? ----------------------------------------------------------------------------
# ? WEB HOOKS
# ? ----------------------------------------------------------------------------

if "BIOINFO_TEAMS_WEBHOOK_URL" not in environ:
    LOGGER.debug("BIOINFO_TEAMS_WEBHOOK_URL not set, using default value")

BIOINFO_TEAMS_WEBHOOK_URL = getenv(
    "BIOINFO_TEAMS_WEBHOOK_URL",
    "https://prod-00.brazilsouth.logic.azure.com:443/workflows/4f257b0933e84dda8d5ba6a0c60aba98/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=bnIIj5-gh5jP4VwMnkNZPjoqnuaKhnX_8fpbrrQgRmw",
)


# ? ----------------------------------------------------------------------------
# ? HARDWARE CONFIGURATIONS
# ? ----------------------------------------------------------------------------


if "AVAILABLE_CORES" not in environ:
    LOGGER.debug("AVAILABLE_CORES not set, using default value of 6")

AVAILABLE_CORES = getenv("AVAILABLE_CORES", 6)


if "AVAILABLE_MEMORY" not in environ:
    LOGGER.debug("AVAILABLE_MEMORY not set, using default value of 6")

AVAILABLE_MEMORY = getenv("AVAILABLE_MEMORY", 6)


# ? ----------------------------------------------------------------------------
# ? BIO-ARCHIVAL CONFIGS
# ? ----------------------------------------------------------------------------

BIO_ARCHIVAL_BASE_URL = getenv(
    "BIO_ARCHIVAL_BASE_URL",
    "https://private.api.agrobiota.biotrop.agr.br/v1/gw/bio-archival-v2",
)

ASSAYS_URL = f"{BIO_ARCHIVAL_BASE_URL}/public/assays/"


# ? ----------------------------------------------------------------------------
# ? SAMPLE EFFECTIVENESS CONFIGS
# ? ----------------------------------------------------------------------------


RAREFACTION_KUTTOFF_FOR_COMPLEX = 100


RAREFACTION_KUTTOFF_FOR_ISOLATES = 1


PRE_FILTERING_SAMPLE_SIZE = 100_000


# ? ----------------------------------------------------------------------------
# ? DOCKER RELATED CONFIGS
# ? ----------------------------------------------------------------------------


DOCKER_BASE_URL = getenv(
    "DOCKER_BASE_URL",
    "unix://var/run/docker.sock",
)


DOCKER_USERNAME = getenv("DOCKER_USERNAME", "meta-davinci")


DOCKER_USER_AND_GROUP = f"{DOCKER_USERNAME}:{DOCKER_USERNAME}"


# ? ----------------------------------------------------------------------------
# ? BLOB STORAGE RELATED CONFIGS
# ? ----------------------------------------------------------------------------


AGROBIOTA_STORAGE_ACCOUNT_URL = getenv(
    "AGROBIOTA_STORAGE_ACCOUNT_URL",
    "https://sequencingresults.blob.core.windows.net",
)


AGROBIOTA_FASTQ_CONTAINER_NAME = getenv(
    "AGROBIOTA_FASTQ_CONTAINER_NAME",
    "fastqs-databases",
)


AGROBIOTA_RESULTS_CONTAINER_NAME = getenv(
    "AGROBIOTA_RESULTS_CONTAINER_NAME",
    "results-databases",
)


FASTQ_UPLOAD_MAX_ATTEMPTS = int(getenv("FASTQ_UPLOAD_MAX_ATTEMPTS", 5))


FASTQ_UPLOAD_BLOCK_SIZE = int(
    getenv("FASTQ_UPLOAD_BLOCK_SIZE", 1024 * 1024 * 5)  # 5MB
)


FASTQ_UPLOAD_TIMEOUT = int(getenv("FASTQ_UPLOAD_TIMEOUT", 60 * 2))
