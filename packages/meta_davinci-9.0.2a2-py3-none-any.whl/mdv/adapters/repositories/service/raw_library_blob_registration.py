from copy import deepcopy
from json import dumps
from time import sleep
from uuid import uuid4

from agrobase.either import Either, right
from agrobase.entities import CreateResponse
from agrobase.exceptions import CreationError
from agrobase.validations import slugify_string
from azure.core.exceptions import ServiceResponseError
from azure.storage.blob import BlobClient, BlobBlock

from mdv.domain.dtos.raw_library_blob_artifact import RawLibraryBlobArtifact
from mdv.domain.entities.raw_library_blob_registration import (
    RawLibraryBlobRegistration,
)
from mdv.settings import (
    AGROBIOTA_FASTQ_CONTAINER_NAME,
    FASTQ_UPLOAD_BLOCK_SIZE,
    FASTQ_UPLOAD_MAX_ATTEMPTS,
    FASTQ_UPLOAD_TIMEOUT,
    LOGGER,
)


class RawLibraryBlobRegistrationServiceRepo(RawLibraryBlobRegistration):
    def create(
        self,
        blob: RawLibraryBlobArtifact,
        connection_string: str,
    ) -> Either[CreationError, CreateResponse[RawLibraryBlobArtifact]]:
        try:
            blob_folder = slugify_string(
                blob.sequencing_metadata.sample_sheet_header.experiment_name
            )

            attempts = deepcopy(FASTQ_UPLOAD_MAX_ATTEMPTS)

            #
            # Tage should be used to indexing and filter blob containers
            #
            tags = blob.indexing_tags.to_dict()
            if blob.extra_index_kv is not None:
                for k, v in blob.extra_index_kv.items():
                    if k in tags:
                        LOGGER.warning(
                            f"Key {k} already exists in indexing tags. "
                            f"Value `{v}` will be ignored."
                        )
                        continue

                tags.update(
                    {k: str(v).lower() for k, v in blob.extra_index_kv.items()}
                )

            #
            # Metadata should be used during post filtrations
            #
            metadata = {
                "sequencing_metadata": dumps(
                    blob.sequencing_metadata.to_dict()
                ),
                "paired_end_qc_metadata": dumps(blob.paired_end_qc_metadata),
            }

            if blob.single_end_qc_metadata is not None:
                metadata.update(
                    {
                        "single_end_qc_metadata": dumps(
                            blob.single_end_qc_metadata
                        )
                    },
                )

            if blob.extra_metadata_kv is not None:
                metadata.update(
                    {k: str(v) for k, v in blob.extra_metadata_kv.items()}
                )

            while attempts > 0:
                try:
                    blob_client = BlobClient.from_connection_string(
                        conn_str=connection_string,
                        blob_name=f"{blob.indexing_tags.sequencing_year}/{blob_folder}/{blob.file.name}",
                        container_name=AGROBIOTA_FASTQ_CONTAINER_NAME,
                    )

                    if blob_client.exists():
                        return right(CreateResponse(False, blob))

                    block_ids: list[int] = []
                    with blob.file.open(mode="rb") as file_stream:
                        while True:
                            buffer = file_stream.read(FASTQ_UPLOAD_BLOCK_SIZE)

                            if not buffer:
                                LOGGER.debug("\tBlob upload partially finished")
                                break

                            block_id = uuid4().hex
                            block_ids.append(BlobBlock(block_id=block_id))

                            LOGGER.debug(f"\tStagging blob: {block_id}")

                            blob_client.stage_block(
                                block_id=block_id,
                                data=buffer,
                                length=len(buffer),
                            )

                        blob_client.commit_block_list(
                            block_list=block_ids,
                            timeout=FASTQ_UPLOAD_TIMEOUT,
                            tags=tags,
                            metadata=metadata,
                        )

                        LOGGER.debug(f"\tCommiting blob: {blob.file.name}")

                    return right(CreateResponse(True, blob))

                except ServiceResponseError as exc:
                    LOGGER.exception(exc)
                    LOGGER.warning(
                        f"Error creating storage blob artifact {blob.file}: "
                        + f"Attempt {FASTQ_UPLOAD_MAX_ATTEMPTS - attempts + 1}"
                        + f" of {FASTQ_UPLOAD_MAX_ATTEMPTS}. Retrying in 2 "
                        + "seconds."
                    )

                    # Check if exception contains TimeoutError error
                    if "TimeoutError" in str(exc):
                        LOGGER.warning(
                            f"Error creating storage blob artifact {blob.file}: "
                            f"Retrying in 2 seconds."
                        )

                    sleep(2)

                finally:
                    attempts -= 1

            return CreationError(
                f"Error creating storage blob artifact {blob.file}: "
                f"Maximum number of attempts reached.",
                logger=LOGGER,
            )()

        except Exception as exc:
            return CreationError(
                f"Error creating storage blob artifact {blob.file}: {exc}",
                logger=LOGGER,
            )()
