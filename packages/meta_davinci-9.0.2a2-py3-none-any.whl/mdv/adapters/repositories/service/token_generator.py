"""
These adaptor should be used to get access tokens during the inter-service
interaction with services from Agroreporter environment.
"""

from datetime import datetime
from os import getenv
from typing import Any, Self

from msal import PublicClientApplication

from mdv.settings import LOGGER


class TokenGenerator:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    __instance: Self | None = None
    __expires_in: int | None = None
    __access_token: str | None = None
    __refresh_token: str | None = None
    __azure_client_instance: PublicClientApplication | None = None
    __default_scope: str = "User.Read"

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __new__(cls) -> Self:
        if cls.__instance is None:
            azure_client_id_env = getenv(
                "AZURE_CLIENT_ID", "2e1852b0-4d34-4418-9060-19aa148cb658"
            )

            azure_tenant_id_env = getenv(
                "AZURE_TENANT_ID", "d6ab08d1-7c42-4d1f-ac22-3a998577bde8"
            )

            if azure_client_id_env is None:
                raise EnvironmentError(
                    "`AZURE_CLIENT_ID` not configured on environment. Please "
                    + "configure it before try to login."
                )

            if azure_tenant_id_env is None:
                raise EnvironmentError(
                    "`AZURE_TENANT_ID` not configured on environment. Please "
                    + "configure it before try to login."
                )

            cls.__azure_client_instance = PublicClientApplication(
                client_id=azure_client_id_env,
                authority=f"https://login.microsoftonline.com/{azure_tenant_id_env}",
            )

            cls.__instance = super(TokenGenerator, cls).__new__(cls)

        return cls.__instance  # type: ignore

    # ? ------------------------------------------------------------------------
    # ? INSTANCE PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def get_token(self) -> str:
        """Get the access token."""

        if self.__expires_in is None or (
            datetime.now() > datetime.fromtimestamp(self.__expires_in)
        ):
            token_response = self.__load_token()

            if token_response is False:
                raise ValueError("Could not load the token.")

        return self.__access_token  # type: ignore

    def get_bearer_as_header(self) -> dict[str, str]:
        """Get the access token as a header.

        Returns:
            dict[str, str]: The access token as a header.

        Raises:
            ValueError: If the token could not be loaded.

        """

        return {
            "Authorization": f"Bearer {self.get_token()}",
        }

    # ? ------------------------------------------------------------------------
    # ? INSTANCE PRIVATE METHODS
    # ? ------------------------------------------------------------------------

    def __load_token(
        self,
        on_constructor: bool = False,
    ) -> bool:
        """Load the token from the environment or from the user input.

        Args:
            on_constructor (bool, optional): If the method is being called
                from the constructor. Defaults to False.

        Returns:
            bool: True if the token was loaded successfully, False otherwise.

        """

        try:
            if self.__refresh_token is not None:
                token_binding = self.__azure_client_instance.acquire_token_by_refresh_token(  # type: ignore
                    refresh_token=self.__refresh_token,
                    scopes=[self.__default_scope],
                )

                if on_constructor is True:
                    return self.__load_internal_attributes_from_dict(
                        self=self,  # type: ignore
                        token_binding_content=token_binding,
                    )

                return self.__load_internal_attributes_from_dict(
                    token_binding_content=token_binding,
                )

            flow = self.__azure_client_instance.initiate_device_flow(  # type: ignore
                scopes=[self.__default_scope]
            )

            # ! WARNING
            #
            # This is a temporary solution to show the user the code to
            # authenticate on the browser. This should be replaced by a
            # better solution.
            # TODO: Replace this by a better solution.
            #
            # Please, do not remove this comment and the print of the below
            # line.
            LOGGER.warning("##################################################")
            LOGGER.warning("#                                                #")
            LOGGER.warning("#              ACTION REQUIRED                   #")
            LOGGER.warning("#                                                #")
            LOGGER.warning("# ---------------------------------------------- #")
            print()
            print(flow.get("message"))
            print()
            LOGGER.warning("##################################################")

            token_binding = self.__azure_client_instance.acquire_token_by_device_flow(  # type: ignore
                flow=flow,
            )

            if on_constructor is True:
                return self.__load_internal_attributes_from_dict(
                    self=self,  # type: ignore
                    token_binding_content=token_binding,
                )

            return self.__load_internal_attributes_from_dict(
                token_binding_content=token_binding,
            )

        except Exception as err:
            LOGGER.exception(err)
            return False

    def __load_internal_attributes_from_dict(
        self,
        token_binding_content: dict[str, Any],
    ) -> bool:
        """Load the internal attributes from the token binding content.

        Args:
            token_binding_content (dict[str, Any]): The token binding content.

        Returns:
            bool: True if the token was loaded successfully, False otherwise.

        Raises:
            ValueError: If the token binding content is missing some attribute.

        """

        for name in [
            "access_token",
            "refresh_token",
            "id_token_claims",
        ]:
            if name not in token_binding_content:
                raise ValueError(
                    f"Missing attribute `{name}` on token binding content."
                )

        if (
            id_token_claims := token_binding_content.get("id_token_claims")
        ) is None:
            raise ValueError(
                "Missing attribute `id_token_claims` on token binding content."
            )

        if "exp" not in id_token_claims:
            raise ValueError(
                "Missing attribute `exp` (expiration date) on token binding content."
            )

        self.__access_token = token_binding_content.get("access_token")
        self.__refresh_token = token_binding_content.get("refresh_token")
        self.__expires_in = id_token_claims.get("exp")

        return True
