from copy import deepcopy
from time import sleep
from uuid import uuid4

from agrobase.either import Either, right
from agrobase.entities import CreateResponse
from agrobase.exceptions import CreationError
from agrobase.validations import slugify_string
from azure.core.exceptions import ServiceResponseError
from azure.storage.blob import BlobClient, BlobBlock

from mdv.domain.dtos.analysis_blob_artifact import AnalysisBlobArtifact
from mdv.domain.entities.analysis_blob_registration import (
    AnalysisBlobRegistration,
)
from mdv.settings import (
    AGROBIOTA_RESULTS_CONTAINER_NAME,
    DUMP_FILE_SUFFIX,
    DUMP_FOLDER_SUFFIX,
    FASTQ_UPLOAD_BLOCK_SIZE,
    FASTQ_UPLOAD_MAX_ATTEMPTS,
    FASTQ_UPLOAD_TIMEOUT,
    LOGGER,
)


class AnalysisBlobRegistrationServiceRepo(AnalysisBlobRegistration):
    def create(
        self,
        blob: AnalysisBlobArtifact,
        connection_string: str,
    ) -> Either[CreationError, CreateResponse[AnalysisBlobArtifact]]:
        try:
            blob_folder = slugify_string(blob.results_folder)
            attempts = deepcopy(FASTQ_UPLOAD_MAX_ATTEMPTS)

            while attempts > 0:
                LOGGER.debug(f"Creating blob: {blob.dump_artifact.name}")

                try:
                    blob_client = BlobClient.from_connection_string(
                        conn_str=connection_string,
                        blob_name=f"{blob.year}/{blob_folder}/{blob.dump_artifact.name}",
                        container_name=AGROBIOTA_RESULTS_CONTAINER_NAME,
                    )

                    if blob_client.exists():
                        return right(CreateResponse(False, blob))

                    tags = {
                        "analysis_name": blob.results_folder.__str__(),
                        "analysis_year": blob.year.__str__(),
                    }

                    if blob.group is not None:
                        tags.update({"analysis_group": blob.group.value})

                    if any(
                        [
                            blob.dump_artifact.name.endswith(
                                DUMP_FOLDER_SUFFIX
                            ),
                            blob.dump_artifact.name.endswith(DUMP_FILE_SUFFIX),
                        ]
                    ):
                        block_ids: list[int] = []
                        with blob.dump_artifact.open(mode="rb") as file_stream:
                            while True:
                                buffer = file_stream.read(
                                    FASTQ_UPLOAD_BLOCK_SIZE
                                )

                                if not buffer:
                                    LOGGER.debug(
                                        "\tBlob upload partially finished"
                                    )
                                    break

                                block_id = uuid4().hex
                                block_ids.append(BlobBlock(block_id=block_id))

                                LOGGER.debug(f"\tStagging blob: {block_id}")

                                blob_client.stage_block(
                                    block_id=block_id,
                                    data=buffer,
                                    length=len(buffer),
                                )

                            blob_client.commit_block_list(
                                block_list=block_ids,
                                timeout=FASTQ_UPLOAD_TIMEOUT,
                                tags=tags,
                            )

                        LOGGER.debug(f"\tCommiting blob: {blob.file.name}")
                    else:
                        with blob.dump_artifact.open(mode="rb") as file:
                            blob_client.upload_blob(file, tags=tags)

                    return right(CreateResponse(True, blob))

                except ServiceResponseError as exc:
                    LOGGER.exception(exc)
                    LOGGER.warning(
                        f"Error creating storage blob artifact {blob.file}: "
                        + f"Attempt {FASTQ_UPLOAD_MAX_ATTEMPTS - attempts + 1}"
                        + f" of {FASTQ_UPLOAD_MAX_ATTEMPTS}. Retrying in 2 "
                        + "seconds."
                    )

                    # Check if exception contains TimeoutError error
                    if "TimeoutError" in str(exc):
                        LOGGER.warning(
                            f"Error creating storage blob artifact {blob.file}: "
                            f"Retrying in 2 seconds."
                        )

                    sleep(2)

                finally:
                    attempts -= 1

            return CreationError(
                f"Error creating storage blob artifact {blob.file}: "
                f"Maximum number of attempts reached.",
                logger=LOGGER,
            )()

        except Exception as exc:
            return CreationError(
                f"Error creating storage blob artifact {blob.file}: {exc}",
                logger=LOGGER,
            )()
