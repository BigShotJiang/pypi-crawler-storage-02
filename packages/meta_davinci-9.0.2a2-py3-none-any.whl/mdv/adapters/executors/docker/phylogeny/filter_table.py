from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import StepResponse
from mdv.domain.entities.phylogeny.filter_table import FilterResults
from mdv.settings import LOGGER


class FilterResultsDockerRepository(
    FilterResults,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_freq_table_artifact: str,
        input_blast_results_artifact: str,
        output_filtered_table_artifact: str,
        work_directory: Path,
        filtering_term: str = "d__Bacteria,d__Eukaryota",
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_freq_table_directory` should be a `Path` instance."
            )()

        source_directory = Path(source_directory)

        try:
            container_freq_table_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="phylogeny-filter-table",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.QIIME.value,
                command=[
                    "--i-table",
                    f"/input/{input_freq_table_artifact}",
                    "--i-taxonomy",
                    f"/input/{input_blast_results_artifact}",
                    "--p-mode",
                    "exact",
                    "--p-exclude",
                    str(filtering_term),
                    "--o-filtered-table",
                    f"/output/{output_filtered_table_artifact}",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=container_freq_table_directory,
                    ),
                ],
                output_dir=destination_directory,
                entrypoint="qiime taxa filter-table",
                expected_output_files=[
                    output_filtered_table_artifact,
                ],
            )

            return super()._execute(step, work_directory, **_)

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
