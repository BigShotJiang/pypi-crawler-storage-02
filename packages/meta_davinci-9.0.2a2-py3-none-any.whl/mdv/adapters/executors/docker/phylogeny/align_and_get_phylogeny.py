from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import StepResponse
from mdv.domain.entities.phylogeny.align_and_get_phylogeny import (
    AlignAndGeneratePhylogeny,
)
from mdv.settings import AVAILABLE_CORES, LOGGER


class AlignAndGeneratePhylogenyDockerRepository(
    AlignAndGeneratePhylogeny,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        input_repr_seqs_artifact: str,
        output_raw_alignment: str,
        output_masked_alignment: str,
        output_unrooted_tree: str,
        output_rooted_tree: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(input_source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        input_source_directory = Path(input_source_directory)

        try:
            # ? ----------------------------------------------------------------
            # ? Validate input files.
            # ? ----------------------------------------------------------------

            input_directory = Path("/input")

            # ? ----------------------------------------------------------------
            # ? Build the `StepDTO` object.
            # ? ----------------------------------------------------------------

            step = StepDTO(
                target=TargetDTO(
                    name="feat-classifier-consensus-blast",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.QIIME.value,
                command=[
                    "--i-sequences",
                    f"/input/{input_repr_seqs_artifact}",
                    "--o-alignment",
                    f"/output/{output_raw_alignment}",
                    "--o-masked-alignment",
                    f"/output/{output_masked_alignment}",
                    "--o-tree",
                    f"/output/{output_unrooted_tree}",
                    "--o-rooted-tree",
                    f"/output/{output_rooted_tree}",
                    "--p-n-threads",
                    f"{AVAILABLE_CORES}",
                    "--p-parttree",
                ],
                input_dir=[
                    InputDTO(
                        source=input_source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=destination_directory,
                entrypoint="qiime phylogeny align-to-tree-mafft-fasttree",
                expected_output_files=[
                    output_raw_alignment,
                    output_masked_alignment,
                    output_unrooted_tree,
                    output_rooted_tree,
                ],
            )

            # ? ----------------------------------------------------------------
            # ? Execute the step.
            # ? ----------------------------------------------------------------

            return super()._execute(
                step,
                work_directory,
                container_log_directory="/tmp",
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
