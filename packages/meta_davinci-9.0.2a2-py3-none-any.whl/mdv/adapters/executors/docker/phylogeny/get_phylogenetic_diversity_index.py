from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import StepDTO, StepType, TargetDTO
from mdv.domain.dtos.config_handler import InputDTO
from mdv.domain.entities.step_execution import StepResponse
from mdv.domain.entities.phylogeny.get_phylogenetic_diversity_index import (
    CalculatePhylogeneticDiversityIndexes,
)
from mdv.settings import LOGGER


class CalculatePhylogeneticDiversityIndexesDockerRepository(
    CalculatePhylogeneticDiversityIndexes,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_taxonomy_directory: Path,
        input_phylogeny_directory: Path,
        input_taxonomy_artifact: str,
        input_phylogeny_artifact: str,
        output_path: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(input_phylogeny_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        if not isinstance(input_taxonomy_directory, Path):
            return ExecutionError(
                "`input_blast_directory` should be a `Path` instance."
            )()

        try:
            container_taxonomy_directory = Path("/taxonomy")
            container_phylogeny_directory = Path("/phylogeny")

            step = StepDTO(
                target=TargetDTO(
                    name="phylogeny-alpha-phylogenetic",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.QIIME.value,
                command=[
                    "--i-table",
                    f"/taxonomy/{input_taxonomy_artifact}",
                    "--i-phylogeny",
                    f"/phylogeny/{input_phylogeny_artifact}",
                    "--o-alpha-diversity",
                    f"/output/{output_path}",
                    "--p-metric",
                    "faith_pd",
                    "--verbose",
                ],
                input_dir=[
                    InputDTO(
                        source=Path(input_taxonomy_directory),
                        destination=container_taxonomy_directory,
                    ),
                    InputDTO(
                        source=Path(input_phylogeny_directory),
                        destination=container_phylogeny_directory,
                    ),
                ],
                output_dir=destination_directory,
                entrypoint="qiime diversity alpha-phylogenetic",
                expected_output_files=[],
            )

            return super()._execute(step, work_directory, **_)  # type: ignore

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
