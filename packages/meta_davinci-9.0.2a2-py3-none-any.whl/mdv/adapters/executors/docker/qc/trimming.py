from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.qc.trimming import TrimmingStep
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.settings import LOGGER


class TrimmingStepDockerRepository(
    TrimmingStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_forward_file_path: Path,
        input_reverse_file_path: Path,
        output_forward_paired_artifact: str,
        output_forward_unpaired_artifact: str,
        output_reverse_paired_artifact: str,
        output_reverse_unpaired_artifact: str,
        # work_directory: Path,
        head_crop: int,
        leading_quality: int,
        trailing_quality: int,
        end_crop: int,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="trimming",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.TRIMMOMATIC.value,
                command=[
                    "PE",
                    "-threads",
                    "8",
                    "-phred33",
                    "-quiet",
                    f"/input/{input_forward_file_path}",
                    f"/input/{input_reverse_file_path}",
                    f"/output/{output_forward_paired_artifact}",
                    f"/output/{output_forward_unpaired_artifact}",
                    f"/output/{output_reverse_paired_artifact}",
                    f"/output/{output_reverse_unpaired_artifact}",
                    "ILLUMINACLIP:adapters/TruSeq3-PE.fa:2:30:10",
                    f"HEADCROP:{head_crop}",
                    "SLIDINGWINDOW:5:20",
                    f"CROP:{end_crop}",
                    f"LEADING:{leading_quality}",
                    f"TRAILING:{trailing_quality}",
                    "MINLEN:120",
                ],
                input_dir=[
                    InputDTO(
                        source=Path(params.source_directory),
                        destination=input_directory,
                    )
                ],
                output_dir=params.destination_directory,
                entrypoint="java -jar trimmomatic-0.39.jar",
                expected_output_files=[
                    output_forward_paired_artifact,
                    output_forward_unpaired_artifact,
                    output_reverse_paired_artifact,
                    output_reverse_unpaired_artifact,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
