from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.qc.reads_pre_filtering import PreFilterRawReadsStep
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.settings import LOGGER


class PreFilterRawReadsStepDockerRepository(
    PreFilterRawReadsStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_raw_fastq: Path,
        output_filtered_fastq: str,
        sample_size: int,
        # work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        input_source_directory = Path(params.source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="pre-filter-raw-reads",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    "sample",
                    "--number",
                    f"{sample_size + 150}",
                    str(input_directory.joinpath(input_raw_fastq.name)),
                    "--out-file",
                    f"/output/{output_filtered_fastq}",
                    "--rand-seed",
                    f"{123_456}",
                    "--two-pass",
                ],
                input_dir=[
                    InputDTO(
                        source=input_source_directory,
                        destination=input_directory,
                    ),
                ],
                output_dir=params.destination_directory,
                entrypoint="seqkit",
                expected_output_files=[
                    output_filtered_fastq,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
