from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.domain.entities.qc.summarize_feature_table import (
    SummarizeFeatureTableStep,
)
from mdv.settings import LOGGER


class SummarizeFeatureTableStepDockerRepository(
    SummarizeFeatureTableStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        input_source_directory: Path,
        input_metadata_directory: Path,
        input_table_artifact: str,
        input_feature_metadata: str,
        output_feature_table: str,
        # work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        input_source_directory = Path(input_source_directory)
        input_metadata_directory = Path(input_metadata_directory)

        try:
            input_directory = Path("/data")
            metadata_directory = Path("/metadata")

            step = StepDTO(
                target=TargetDTO(
                    name="feature-table-summarize",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.QIIME.value,
                command=[
                    "--i-table",
                    f"/data/{input_table_artifact}",
                    "--m-sample-metadata-file",
                    f"/metadata/{input_feature_metadata}",
                    "--o-visualization",
                    f"/output/{output_feature_table}",
                ],
                input_dir=[
                    InputDTO(
                        source=input_source_directory,
                        destination=input_directory,
                    ),
                    InputDTO(
                        source=input_metadata_directory,
                        destination=metadata_directory,
                    ),
                ],
                output_dir=params.group + "/qiime-feat-table-summarize",
                entrypoint="qiime feature-table summarize",
                expected_output_files=[
                    output_feature_table,
                    input_feature_metadata,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
