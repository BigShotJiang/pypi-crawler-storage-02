from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.domain.entities.qc.quality_filter import QualityFilterStep
from mdv.settings import LOGGER


class QualityFilterStepDockerRepository(
    QualityFilterStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_merged: Path,
        output_filtered_artifact: str,
        # work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="quality-filter",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    "--fastx_filter",
                    f"/input/{input_merged}",
                    "--fastaout",
                    f"/output/{output_filtered_artifact}",
                    "--fastq_maxee_rate",
                    "0.1",
                    "--log",
                    "/output/vsearch.log",
                ],
                input_dir=[
                    InputDTO(
                        source=Path(params.source_directory),
                        destination=input_directory,
                    )
                ],
                output_dir=params.destination_directory,
                entrypoint="vsearch",
                expected_output_files=[
                    output_filtered_artifact,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
