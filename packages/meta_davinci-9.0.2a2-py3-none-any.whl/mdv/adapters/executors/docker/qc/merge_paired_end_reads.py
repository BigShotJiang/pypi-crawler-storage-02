from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.domain.entities.qc.merge_paired_end_reads import MergePairsStep
from mdv.settings import LOGGER


class MergePairsStepDockerRepository(
    MergePairsStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_trimmed_forward: Path,
        input_trimmed_reverse: Path,
        output_merged_artifact: str,
        output_not_merged_fwd_artifact: str,
        output_not_merged_rev_artifact: str,
        # work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        source_directory = Path(params.source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="merge-pairs",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    "--fastq_mergepairs",
                    f"/input/{input_trimmed_forward}",
                    "--reverse",
                    f"/input/{input_trimmed_reverse}",
                    "--fastaout",
                    f"/output/{output_merged_artifact}",
                    "--fastqout_notmerged_fwd",
                    f"/output/{output_not_merged_fwd_artifact}",
                    "--fastqout_notmerged_rev",
                    f"/output/{output_not_merged_rev_artifact}",
                    "--log",
                    "/output/vsearch.log",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=params.destination_directory,
                entrypoint="vsearch",
                expected_output_files=[
                    output_merged_artifact,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
