from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.domain.entities.qc.dereplicate import DereplicateStep
from mdv.settings import LOGGER
from mdv.domain.entities.qc.dereplicate import DerepStrategyEnum


class DereplicateStepDockerRepository(
    DereplicateStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_filtered: Path,
        output_dereplicated_artifact: str,
        # work_directory: Path,
        min_cluster_size: int = 2,
        derep_strategy: DerepStrategyEnum | None = None,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        source_directory = Path(params.source_directory)

        if derep_strategy is None:
            derep_strategy = DerepStrategyEnum(None)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="dereplication",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    f"--{derep_strategy.value}",
                    f"/input/{input_filtered}",
                    "--output",
                    f"/output/{output_dereplicated_artifact}",
                    "--relabel_md5",
                    "--sizeout",
                    "--minuniquesize",
                    f"{min_cluster_size}",
                    "--log",
                    "/output/vsearch.log",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=params.destination_directory,
                entrypoint="vsearch",
                expected_output_files=[
                    output_dereplicated_artifact,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
