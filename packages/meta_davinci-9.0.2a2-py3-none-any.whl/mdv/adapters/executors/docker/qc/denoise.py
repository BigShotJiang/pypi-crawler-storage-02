from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker.base_step_executor import (
    StepExecutionDockerMixin,
    ProjectDockerImages,
)
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.dtos.config_handler import InputDTO
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.domain.entities.qc.denoise import DenoiseStep
from mdv.settings import LOGGER


class DenoiseStepDockerRepository(
    DenoiseStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_dereplicated: Path,
        output_denoised_artifact: str,
        # work_directory: Path,
        min_cluster_size: int = 2,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        source_directory = Path(params.source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="denoise",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    "--cluster_unoise",
                    f"/input/{input_dereplicated}",
                    "--minsize",
                    f"{min_cluster_size}",
                    "--unoise_alpha",
                    "2",
                    "--centroids",
                    f"/output/{output_denoised_artifact}",
                    "--log",
                    "/output/vsearch.log",
                    "--sizein",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=params.destination_directory,
                entrypoint="vsearch",
                expected_output_files=[
                    output_denoised_artifact,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
