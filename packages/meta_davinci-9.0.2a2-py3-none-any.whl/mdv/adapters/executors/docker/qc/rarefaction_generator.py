from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.qc.rarefaction_generator import (
    SingleSampleRarefactionGeneratorStep,
)
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.settings import LOGGER


class SingleSampleRarefactionGeneratorStepDockerRepository(
    SingleSampleRarefactionGeneratorStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_otu_table: Path,
        output_rarefaction: str,
        # work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        source_directory = Path(params.source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="rarefaction-generator",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.RAREFY.value,
                command=[
                    "--file",
                    f"/input/{input_otu_table}",
                    "--workname",
                    output_rarefaction.replace(".tsv", ""),
                    "--output",
                    f"/output/",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=params.destination_directory,
                expected_output_files=[],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
