from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.domain.entities.qc.tabulate_metadata import TabulateMetadataStep
from mdv.settings import LOGGER


class TabulateMetadataStepDockerRepository(
    TabulateMetadataStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # source_directory: Path,
        input_metadata_artifact: str,
        output_denoise_stats: str,
        # work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        source_directory = Path(params.source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="feature-table-tabulate-metadata",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.QIIME.value,
                command=[
                    "--m-input-file",
                    f"/input/{input_metadata_artifact}",
                    "--o-visualization",
                    f"/output/{output_denoise_stats}",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=params.group + "/qiime-tabulate-metadata",
                entrypoint="qiime metadata tabulate",
                expected_output_files=[
                    output_denoise_stats,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
