from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker.base_step_executor import (
    StepExecutionDockerMixin,
    ProjectDockerImages,
)
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.dtos.config_handler import InputDTO
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.domain.entities.qc.chimera_removal import ChimeraRemovalStep
from mdv.settings import LOGGER


class ChimeraRemovalStepDockerRepository(
    ChimeraRemovalStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # source_directory: Path,
        input_dereplicated: Path,
        output_denoised_artifact: str,
        # work_directory: Path,
        abskew: float = 1.5,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        try:
            input_destination = "/input"
            output_destination = "/output"

            step = StepDTO(
                target=TargetDTO(
                    name="chimera-removal",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    "--uchime3_denovo",
                    f"{input_destination}/{input_dereplicated}",
                    "--abskew",
                    f"{abskew}",
                    "--nonchimeras",
                    f"{output_destination}/{output_denoised_artifact}",
                    "--chimeras",
                    f"{output_destination}/chimeras.fasta",
                    "--fasta_width",
                    "0",
                    "--sizein",
                    "--log",
                    f"{output_destination}/vsearch.log",
                ],
                input_dir=[
                    InputDTO(
                        source=Path(params.source_directory),
                        destination=Path(input_destination),
                    )
                ],
                output_dir=params.destination_directory,
                entrypoint="vsearch",
                expected_output_files=[
                    output_denoised_artifact,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
