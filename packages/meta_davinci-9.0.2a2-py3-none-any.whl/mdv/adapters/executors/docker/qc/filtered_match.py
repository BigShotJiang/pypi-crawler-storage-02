from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.qc.filtered_match import FilteredMatchStep
from mdv.domain.entities.step_execution import DefaultStepParams, StepResponse
from mdv.settings import LOGGER


class FilteredMatchStepDockerRepository(
    FilteredMatchStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        source_directory_filtered: Path,
        source_directory_raw: Path,
        input_filtered_fastq: Path,
        input_complement_fastq: Path,
        output_forward_fastq: str,
        output_matching_files: str,
        # work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        input_source_directory_filtered = Path(source_directory_filtered)
        input_source_directory_raw = Path(source_directory_raw)

        try:
            input_directory_filtered = Path("/filtered")
            input_directory_raw = Path("/raw")

            step = StepDTO(
                target=TargetDTO(
                    name="match-filtered-reads",
                    mode=StepType.INDIVIDUAL,
                ),
                group=params.group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    "pair",
                    "-1",
                    f"/filtered/{input_filtered_fastq}",
                    "-2",
                    str(
                        input_directory_raw.joinpath(
                            input_complement_fastq.name
                        )
                    ),
                    "--out-dir",
                    f"/output/{output_matching_files}",
                    "--out-file",
                    f"{output_forward_fastq.split('.')[0]}",
                    "--force",
                ],
                input_dir=[
                    InputDTO(
                        source=input_source_directory_filtered,
                        destination=input_directory_filtered,
                    ),
                    InputDTO(
                        source=input_source_directory_raw,
                        destination=input_directory_raw,
                    ),
                ],
                output_dir=params.destination_directory,
                entrypoint="seqkit",
                expected_output_files=[
                    output_forward_fastq,
                ],
            )

            return super()._execute(
                step,
                params.work_directory,
                ignore_stdout=True,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
