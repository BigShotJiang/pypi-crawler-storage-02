from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.dtos.config_handler import ImageDTO
from mdv.domain.entities.shared.qiime_import import (
    ImportBlastOutput,
    ImportFeatureTable,
    ImportFromTSVFeatureTable,
    ImportRawFastaReads,
)
from mdv.domain.entities.step_execution import StepResponse
from mdv.settings import LOGGER


class ImportRawFastaReadsDockerRepository(
    ImportRawFastaReads,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        input_sequences: Path,
        output_artifact: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(input_source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        input_source_directory = Path(input_source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="feat-classifier-export",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ImageDTO("qiime2/core"),
                command=[
                    "--input-path",
                    f"/input/{input_sequences}",
                    "--output-path",
                    f"/output/{output_artifact}",
                    "--type",
                    "FeatureData[Sequence]",
                ],
                input_dir=[
                    InputDTO(
                        source=input_source_directory,
                        destination=input_directory,
                    ),
                ],
                output_dir=destination_directory,
                entrypoint="qiime tools import",
                expected_output_files=[
                    output_artifact,
                ],
            )

            return super()._execute(
                step,
                work_directory,
                ignore_lock_file=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()


class ImportFromTSVFeatureTableDockerRepository(
    ImportFromTSVFeatureTable,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_file: Path,
        output_artifact_name: str,
        work_directory: Path,
        skip_lock_file: bool = False,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        """Execute the date import using `QIIME tool import` functionality.

        Args:
            sample_code (str): The sample code to filter files of source
                directory.
            source_directory (Path): The source directory to collect FASTQ
                input files.
            output_artifact_name (str): The name of the QIIME output artifact.
            work_directory (Path): The work directory to persist the step
                output.

        Returns:
            Either[ExecutionError, StepResponse]: Return a step
                response execute this method successfully.
        """

        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        source_directory = Path(source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="import",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ImageDTO(
                    name="bioregistry.azurecr.io/bio-ubuntu",
                    tag="1.0",
                ),
                command=[
                    "convert",
                    "--input-fp",
                    f"/input/{input_file}",
                    "--output-fp",
                    f"/output/{output_artifact_name}",
                    "--table-type",
                    "OTU table",
                    "--to-hdf5",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=destination_directory,
                entrypoint="biom",
                expected_output_files=[
                    f"{output_artifact_name}",
                ],
            )

            return super()._execute(
                step,
                work_directory,
                skip_lock_file=skip_lock_file,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()


class ImportFeatureTableDockerRepository(
    ImportFeatureTable,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_file: Path,
        output_artifact_name: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        """Execute the date import using `QIIME tool import` functionality.

        Args:
            sample_code (str): The sample code to filter files of source
                directory.
            source_directory (Path): The source directory to collect FASTQ
                input files.
            output_artifact_name (str): The name of the QIIME output artifact.
            work_directory (Path): The work directory to persist the step
                output.

        Returns:
            Either[ExecutionError, StepResponse]: Return a step
                response execute this method successfully.
        """

        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        source_directory = Path(source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="import-frequency-table",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ImageDTO("qiime2/core"),
                command=[
                    "--input-path",
                    f"/input/{input_file}",
                    "--output-path",
                    f"/output/{output_artifact_name}",
                    "--type",
                    "FeatureTable[Frequency]",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=destination_directory,
                entrypoint="qiime tools import",
                expected_output_files=[
                    f"{output_artifact_name}",
                ],
            )

            return super()._execute(step, work_directory, **_)

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()


class ImportBlastOutputDockerRepository(
    ImportBlastOutput,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_file: Path,
        output_artifact_name: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        """Execute the date import using `QIIME tool import` functionality.

        Args:
            sample_code (str): The sample code to filter files of source
                directory.
            source_directory (Path): The source directory to collect FASTQ
                input files.
            output_artifact_name (str): The name of the QIIME output artifact.
            work_directory (Path): The work directory to persist the step
                output.

        Returns:
            Either[ExecutionError, StepResponse]: Return a step
                response execute this method successfully.
        """

        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        source_directory = Path(source_directory)

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="import-raw-reads",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ImageDTO("qiime2/core"),
                command=[
                    "--input-path",
                    f"/input/{input_file}",
                    "--output-path",
                    f"/output/{output_artifact_name}",
                    "--type",
                    "FeatureData[Taxonomy]",
                    "--input-format",
                    "TSVTaxonomyFormat",
                ],
                input_dir=[
                    InputDTO(
                        source=source_directory,
                        destination=input_directory,
                    )
                ],
                output_dir=destination_directory,
                entrypoint="qiime tools import",
                expected_output_files=[
                    f"{output_artifact_name}",
                ],
            )

            return super()._execute(
                step,
                work_directory,
                ignore_lock_file=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
