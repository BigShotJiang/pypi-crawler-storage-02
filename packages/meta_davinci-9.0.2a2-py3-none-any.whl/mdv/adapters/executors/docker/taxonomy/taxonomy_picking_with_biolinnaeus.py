from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.dtos.config_handler import ImageDTO
from mdv.domain.entities.step_execution import StepResponse
from mdv.domain.entities.taxonomy.taxonomy_picking_with_biolinnaeus import (
    TaxonomyPickingWithBioLinnaeus,
)
from mdv.settings import AVAILABLE_CORES, LOGGER


class TaxonomyPickingWithBioLinnaeusDockerRepository(
    TaxonomyPickingWithBioLinnaeus,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        databases_source_directory: Path,
        input_repr_seqs_artifact: str,
        reference_reads: str,
        reference_taxonomy: str,
        output_classification: str,
        work_directory: Path,
        max_target_seqs: float = 10,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(input_source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        try:
            input_directory = Path("/input")
            databases_directory = Path("/databases")

            step = StepDTO(
                target=TargetDTO(
                    name="feat-classifier-bli",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.BIO_LINNAEUS.value,
                command=[
                    "--query-sequences",
                    f"/input/{input_repr_seqs_artifact}",
                    "--subject-reads",
                    f"/databases/{reference_reads}",
                    "--reference-taxonomy",
                    f"/databases/{reference_taxonomy}",
                    "--output-file",
                    f"/output/{output_classification}",
                    "--max-target-seqs",
                    str(max_target_seqs),
                    "--max-parallel-procs",
                    str(AVAILABLE_CORES),
                ],
                input_dir=[
                    InputDTO(
                        source=Path(input_source_directory),
                        destination=input_directory,
                    ),
                    InputDTO(
                        source=databases_source_directory,
                        destination=databases_directory,
                    ),
                ],
                output_dir=destination_directory,
                entrypoint="bli run",
                expected_output_files=[
                    output_classification,
                ],
            )

            return super()._execute(
                step,
                work_directory,
                ignore_stdout=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()


class TaxonomyPickingWithBlastNDockerRepository(StepExecutionDockerMixin):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        databases_source_directory: Path,
        input_repr_seqs_artifact: str,
        reference_reads: str,
        reference_taxonomy: str,
        output_classification: str,
        work_directory: Path,
        identity_percentage: float = 0.97,
        query_coverage: float = 0.89,
        max_match_accepts: int = 1000,
        strand: str = "both",
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(input_source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        try:
            input_directory = Path("/input")
            databases_directory = Path("/databases")

            step = StepDTO(
                target=TargetDTO(
                    name="feat-classifier-consensus-blast",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ImageDTO("qiime2/core"),
                command=[
                    "--i-query",
                    f"/input/{input_repr_seqs_artifact}",
                    "--i-reference-reads",
                    f"/databases/{reference_reads}",
                    "--i-reference-taxonomy",
                    f"/databases/{reference_taxonomy}",
                    "--p-maxaccepts",
                    str(max_match_accepts),
                    "--p-perc-identity",
                    str(identity_percentage),
                    "--p-query-cov",
                    str(query_coverage),
                    "--p-strand",
                    str(strand),
                    "--o-classification",
                    f"/output/{output_classification}",
                    "--verbose",
                ],
                input_dir=[
                    InputDTO(
                        source=Path(input_source_directory),
                        destination=input_directory,
                    ),
                    InputDTO(
                        source=databases_source_directory,
                        destination=databases_directory,
                    ),
                ],
                output_dir=destination_directory,
                entrypoint="qiime feature-classifier classify-consensus-blast",
                expected_output_files=[
                    output_classification,
                ],
            )

            return super()._execute(step, work_directory, **_)

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
