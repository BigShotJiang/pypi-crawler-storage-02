from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.enums import TaxaEnum
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.step_execution import StepResponse
from mdv.domain.entities.taxonomy.taxonomy_picking_with_blutils import (
    TaxonomyPickingWithBlutils,
)
from mdv.settings import AVAILABLE_CORES, LOGGER


class TaxonomyPickingWithBlutilsDockerRepository(
    TaxonomyPickingWithBlutils,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        databases_source_directory: Path,
        input_repr_seqs_artifact: str,
        reference_reads: str,
        reference_taxonomy: str,
        output_classification: str,
        work_directory: Path,
        max_target_seqs: float = 10,
        word_size: int = 18,
        taxon: TaxaEnum | None = None,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(input_source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        if taxon is None or taxon == TaxaEnum.BOTH:
            return ExecutionError(
                "`taxon` should be one of `fungi` or `bacteria`."
            )()

        try:
            input_directory = Path("/input")
            databases_directory = Path("/databases")

            step = StepDTO(
                target=TargetDTO(
                    name="feat-classifier-blu",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.BIO_UBUNTU.value,
                command=[
                    "blast",
                    "run-with-consensus",
                    f"/input/{input_repr_seqs_artifact}",
                    f"/databases/{reference_reads}",
                    f"/databases/{reference_taxonomy}",
                    f"/output/",
                    "--threads",
                    str(AVAILABLE_CORES),
                    "--taxon",
                    f"{taxon.value}",
                    "--strategy",
                    "relaxed",
                    "--max-target-seqs",
                    f"{max_target_seqs}",
                    "--word-size",
                    f"{word_size}",
                ],
                input_dir=[
                    InputDTO(
                        source=Path(input_source_directory),
                        destination=input_directory,
                    ),
                    InputDTO(
                        source=databases_source_directory,
                        destination=databases_directory,
                    ),
                ],
                output_dir=destination_directory,
                entrypoint="blu",
                expected_output_files=[
                    output_classification,
                ],
            )

            return super()._execute(
                step,
                work_directory,
                ignore_stdout=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
