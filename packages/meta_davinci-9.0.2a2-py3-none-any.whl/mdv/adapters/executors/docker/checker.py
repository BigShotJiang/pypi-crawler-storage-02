from docker import DockerClient
from docker.errors import ImageNotFound

from mdv.domain.dtos.config_handler import ImageDTO
from mdv.settings import LOGGER


def check_docker_images_availability(
    client: DockerClient,
    images: list[ImageDTO],
    pull_if_not_found: bool = False,
) -> bool:
    """Checks if all the required docker images are available locally.

    Args:
        client (DockerClient): Docker client.
        images (list[ImageDTO]): List of images to check.
        pull_if_not_found (bool, optional): Pull images if not found. Defaults
            to False.

    Returns:
        bool: True if all images are available, False otherwise.

    """

    LOGGER.info(f"Checking Docker images availability")

    found_images: list[ImageDTO] = []
    not_found_images: list[ImageDTO] = []

    for image in images:
        try:
            client.images.get(image.full_name())
            found_images.append(image)
        except ImageNotFound:
            not_found_images.append(image)

    if len(found_images) > 0:
        LOGGER.info("Found images:")
        for image in found_images:
            LOGGER.info(f"-> {image.full_name()}")

    if len(not_found_images) > 0:
        LOGGER.error("Not found images:")
        for image in not_found_images:
            LOGGER.error(f"-> {image.full_name()}")

        if pull_if_not_found:
            LOGGER.info("Pulling images")
            for image in not_found_images:
                client.images.pull(
                    repository=image.name,
                    tag=image.tag,
                )
            LOGGER.info("Pulling finished")

    LOGGER.info(f"Checking finished")

    if len(not_found_images) > 0:
        return False
    return True
