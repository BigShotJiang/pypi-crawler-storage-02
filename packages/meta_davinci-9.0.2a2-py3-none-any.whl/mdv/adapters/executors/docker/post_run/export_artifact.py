from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import StepDTO, StepType, TargetDTO
from mdv.domain.dtos.config_handler import InputDTO
from mdv.domain.entities.step_execution import StepResponse
from mdv.domain.entities.post_run.export_artifact import ExportArtifact
from mdv.settings import LOGGER


class ExportArtifactDockerRepository(
    ExportArtifact,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        destination_directory: str,
        source_directory: Path,
        input_artifact: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        if not any(
            [
                input_artifact.endswith(".qza"),
                input_artifact.endswith(".qzv"),
            ]
        ):
            return ExecutionError(
                f"Provided argument `{input_artifact}` is not a valid artifact.",
                exp=True,
                logger=LOGGER,
            )()

        try:
            input_directory = Path("/input")

            step = StepDTO(
                target=TargetDTO(
                    name="post-run-artifact-export",
                    mode=StepType.INDIVIDUAL,
                ),
                group="post-run",
                image=ProjectDockerImages.QIIME.value,
                command=[
                    "--input-path",
                    f"/input/{input_artifact}",
                    "--output-path",
                    f"/output/",
                ],
                input_dir=[
                    InputDTO(
                        source=Path(source_directory),
                        destination=input_directory,
                    ),
                ],
                output_dir=destination_directory,
                entrypoint="qiime tools export",
                expected_output_files=[],
            )

            return super()._execute(
                step,
                work_directory,
                ignore_lock_file=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
