from enum import Enum
from logging import Logger, getLogger
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

from agrobase.either import Either, right
from agrobase.exceptions import ExecutionError
from docker import DockerClient
from docker.errors import ContainerError, NotFound
from docker.types import Mount

from mdv.domain.dtos import StepDTO
from mdv.domain.dtos.config_handler import ImageDTO
from mdv.domain.entities.step_execution import Step, StepResponse
from mdv.domain.utils import create_lock_file, has_lock_file
from mdv.settings import AVAILABLE_CORES, AVAILABLE_MEMORY


class ProjectDockerImages(Enum):
    PICRUST = ImageDTO(
        name="bioregistry.azurecr.io/picrust2",
        tag="2.0",
    )

    QIIME = ImageDTO(
        "qiime2/core",
    )

    BIO_LINNAEUS = ImageDTO(
        name="bioregistry.azurecr.io/bio-linnaeus",
        tag="1.4",
    )

    TRIMMOMATIC = ImageDTO(
        name="bioregistry.azurecr.io/trimmomatic",
        tag="0.39",
    )

    BIO_UBUNTU = ImageDTO(
        name="bioregistry.azurecr.io/bio-ubuntu",
        tag="2.4",
    )

    RAREFY = ImageDTO(
        name="bioregistry.azurecr.io/rarefy",
        tag="1.1",
    )


class StepExecutionDockerMixin(Step):
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    __logger: Logger = getLogger(__name__)

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        client: DockerClient,
        logger: Logger | None = None,
    ) -> None:
        self._client = client

        if isinstance(logger, Logger):
            self.__logger = logger

    # ? ------------------------------------------------------------------------
    # ? ABSTRACT METHODS IMPLEMENTATION
    # ? ------------------------------------------------------------------------

    def execute(
        self,
        group: str,
        source_directory: Path,
        work_directory: Path,
        destination_directory: str,
        **kwargs: Any,
    ) -> Either[ExecutionError, StepResponse]:
        return super().execute(
            group,
            source_directory,
            work_directory,
            destination_directory,
            **kwargs,
        )

    def _execute(  # type: ignore[override]
        self,
        step: StepDTO,
        work_directory: Path,
        container_log_directory: str | None = None,
        ignore_stdout: bool = False,
        return_container_stdout: bool = False,
        ignore_lock_file: bool = False,
        skip_lock_file: bool = False,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(work_directory, Path):
            return ExecutionError(
                "`work_directory` should be a `Path` instance.",
                exp=True,
                logger=self.__logger,
            )()

        try:
            # ? ----------------------------------------------------------------
            # ? Initialize basic variables and lock file
            #
            # Check if lock file exists. If `True` the use step execution is
            # finished with a `False` state (StepResponse.created = True),
            # indicating that the step execution already occurred during a
            # previous execution cycle.
            # ? ----------------------------------------------------------------

            name = "-".join(
                [
                    step.group,
                    step.target.name,
                    step.target.mode.value,
                    str(uuid4().hex)[:12],
                ]
            )

            work_directory = Path(work_directory)
            output_directory = work_directory.joinpath(step.output_dir)  # type: ignore

            if not output_directory.exists():
                output_directory.mkdir(parents=True, exist_ok=True)

            lock_either = has_lock_file(
                step_directory=output_directory,
                logger=self.__logger,
            )

            if lock_either.is_left:
                return ExecutionError(
                    "Unexpected error detected on check lock file.",
                    prev=lock_either.value,
                    logger=self.__logger,
                )()

            lock: bool = lock_either.value  # type: ignore

            if lock and not ignore_lock_file:
                return right(StepResponse(False, step))

            # ? ----------------------------------------------------------------
            # ? Mount output directories
            #
            # The output directories including the main output folder and the
            # logging folder. The main output folder includes the default
            # `/output` folder mapped inside the container. The Logging include
            # a optional system node that mapping the logging directory.
            # ? ----------------------------------------------------------------

            volumes: dict[str, Any] = {}

            volumes.update(
                {
                    str(output_directory): {
                        "bind": "/output",
                        "mode": "rw",
                    }
                }
            )

            logging_directory = output_directory.joinpath("log")

            if not logging_directory.exists():
                logging_directory.mkdir()

            if container_log_directory:
                volumes.update(
                    {
                        str(logging_directory): {
                            "bind": container_log_directory,
                            "mode": "rw",
                        }
                    }
                )

            logging_file = logging_directory.joinpath("step.log")

            # ? ----------------------------------------------------------------
            # ? Mount input directories
            #
            # Input directories consists of a list of mount parts.
            # ? ----------------------------------------------------------------

            mounts = [
                Mount(
                    source=str(mount.source),
                    target=str(mount.destination),
                    type="bind",
                    read_only=True,
                    consistency="delegated",
                )
                for mount in step.input_dir
            ]

            # ? ----------------------------------------------------------------
            # ? Populate parameters
            #
            # Populate all parameters as a dictionary.
            # ? ----------------------------------------------------------------

            params = dict(
                name=name,
                image=step.image.full_name(),
                command=step.command,
                volumes=volumes,
                mounts=mounts,
                detach=False,
                stdout=return_container_stdout,
                stderr=True,
                remove=True,
                nano_cpus=int(AVAILABLE_CORES) * 10 ^ 9,
                mem_limit=f"{AVAILABLE_MEMORY}g",
                # user=DOCKER_USER_AND_GROUP,
            )

            # ? ----------------------------------------------------------------
            # ? Include a entrypoint if available
            #
            # This element is a default docker entrypoint that allows modify the
            # default image entrypoint.
            # ? ----------------------------------------------------------------

            if step.entrypoint:
                params.update({"entrypoint": step.entrypoint})

            # ? ----------------------------------------------------------------
            # ? Execute the container step
            #
            # Literally execute the container using the above populated
            # configurations.
            # ? ----------------------------------------------------------------

            try:
                container = self._client.containers.run(**params)
            except (Exception, KeyboardInterrupt) as e:
                try:
                    if (
                        container := self._client.containers.get(name)
                    ) is not None:
                        container.stop(force=True)
                except (NotFound, Exception):
                    pass

                return ExecutionError(
                    "Unexpected error on execute step in container. "
                    + "Container exited with message: "
                    + f"{e}",
                    logger=self.__logger,
                )()

            # ? ----------------------------------------------------------------
            # ? Collect errors
            #
            # If some error occurred, force a `Left` response.
            # ? ----------------------------------------------------------------

            if len(container.decode("utf-8")) > 0:
                with logging_file.open("w+") as log:
                    log.write(container.decode("utf-8") + "\n")

                if not ignore_stdout:
                    return ExecutionError(
                        "Unexpected error on execute step in container. "
                        + "Container exited with message: "
                        + f"{container.decode('utf-8')}",
                        logger=self.__logger,
                    )()

            # ? ----------------------------------------------------------------
            # ? Lock directory
            #
            # Create the lock file in output directory indicating that the
            # analysis was successfully done.
            # ? ----------------------------------------------------------------

            if skip_lock_file is False:
                lock_either = create_lock_file(  # type: ignore
                    step_directory=output_directory,
                    logger=self.__logger,
                )

                if lock_either.is_left:
                    return ExecutionError(
                        "Unexpected error detected on create lock file.",
                        prev=lock_either.value,
                        logger=self.__logger,
                    )()

            # ? ----------------------------------------------------------------
            # ? Return a `Right` response
            #
            # A right response indicates that the full analysis and directory
            # locking were successfully performed.
            # ? ----------------------------------------------------------------

            if return_container_stdout:
                return right(StepResponse(True, container.decode("utf-8")))

            return right(StepResponse(True, step))

        except ContainerError as exc:
            return ExecutionError(
                exc.stderr.decode(encoding="utf-8"),
                logger=self.__logger,
            )()

        except Exception as exc:
            return ExecutionError(exc, logger=self.__logger)()

    def has_valid_outputs(  # type: ignore
        self,
        step: StepDTO,
        work_directory: Path,
    ) -> Either[ExecutionError, Literal[True]]:
        # ? Populate files to be expected at the step execution finish
        expected_output_files: list[Path] = []
        for path in step.expected_output_files:  # type: ignore
            expected_output_files.extend(
                list(Path(work_directory).joinpath(step.output_dir).glob(path))  # type: ignore
            )

        # ? Check if all expected files exists in output path
        if len(expected_output_files) < len(step.expected_output_files):  # type: ignore
            return ExecutionError(
                "Output files diverges from expected files:\n"
                + f"{step.expected_output_files} diverged from "
                + f"{expected_output_files}.",
                logger=self.__logger,
            )()

        return right(True)

    # ? ------------------------------------------------------------------------
    # ! NOT IMPLEMENTED ABSTRACT METHODS
    # ? ------------------------------------------------------------------------

    def has_valid_inputs(
        self, **_: Any
    ) -> Either[ExecutionError, Literal[True]]:
        raise NotImplementedError("")
