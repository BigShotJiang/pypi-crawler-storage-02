from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.enums import TaxaEnum
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.function_annotation.place_seqs import PlaceSequences
from mdv.domain.entities.step_execution import StepResponse
from mdv.settings import AVAILABLE_CORES, LOGGER


class PlaceSequencesRepository(
    PlaceSequences,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_fasta_sequences: str,
        output_tree: str,
        work_directory: Path,
        taxa: TaxaEnum,
        chunk_size: int = 2000,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance.",
                logger=LOGGER,
            )()

        if not isinstance(taxa, TaxaEnum):
            return ExecutionError(
                "`taxa` should be a `TaxaEnum` instance.",
                logger=LOGGER,
            )()

        try:
            # ? ----------------------------------------------------------------
            # ? Validate input files.
            # ? ----------------------------------------------------------------

            input_directory = Path("/input")

            # ? ----------------------------------------------------------------
            # ? Adjust params given the taxa
            # ? ----------------------------------------------------------------

            command = [
                "conda",
                "run",
                "-n",
                "picrust2",
                "place_seqs.py",
                "--study_fasta",
                f"/input/{input_fasta_sequences}",
                "--out_tree",
                f"/output/{output_tree}",
                "--chunk_size",
                f"{chunk_size}",
                "--print_cmds",
                "--processes",
                str(AVAILABLE_CORES),
            ]

            if taxa == TaxaEnum.FUNGI:
                command.append("--ref_dir")
                command.append(
                    "/opt/conda/envs/picrust2/lib/python3.6/site-packages/picrust2/default_files/fungi/fungi_ITS/"
                )

            # ? ----------------------------------------------------------------
            # ? Build the `StepDTO` object.
            # ? ----------------------------------------------------------------

            step = StepDTO(
                target=TargetDTO(
                    name="place-sequences-picrust2",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.PICRUST.value,
                command=["/bin/bash", "-c", " ".join(command)],
                input_dir=[
                    InputDTO(
                        source=Path(source_directory),
                        destination=input_directory,
                    )
                ],
                output_dir=destination_directory,
                expected_output_files=[
                    output_tree,
                ],
            )

            # ? ----------------------------------------------------------------
            # ? Execute the step.
            # ? ----------------------------------------------------------------

            return super()._execute(
                step,
                work_directory,
                ignore_stdout=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
