from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.function_annotation.full_pipeline_picrust import (
    RunFullPipelineStep,
)
from mdv.domain.entities.step_execution import StepResponse
from mdv.settings import AVAILABLE_CORES, LOGGER


class RunFullPipelineStepDockerRepository(
    RunFullPipelineStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(
        self,
        input_fasta_sequences: str,
        input_frequency_table: str,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        return super().execute(
            input_fasta_sequences, input_frequency_table, **_
        )

    def _execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_fasta_sequences: str,
        input_frequency_table: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance."
            )()

        try:
            # ? ----------------------------------------------------------------
            # ? Validate input files.
            # ? ----------------------------------------------------------------

            input_directory = Path("/input")

            # ? ----------------------------------------------------------------
            # ? Build the `StepDTO` object.
            # ? ----------------------------------------------------------------

            step = StepDTO(
                target=TargetDTO(
                    name="function-annotation-full-picrust2",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.PICRUST.value,
                command=[
                    "picrust2_pipeline.py",
                    "--study_fasta",
                    f"/input/{input_fasta_sequences}",
                    "--input",
                    f"/input/{input_frequency_table}",
                    "--output",
                    "/output/picrust",
                    "--stratified",
                    "--processes",
                    str(AVAILABLE_CORES),
                ],
                input_dir=[
                    InputDTO(
                        source=Path(source_directory),
                        destination=input_directory,
                    )
                ],
                output_dir=destination_directory,
                entrypoint="conda run -n picrust2",
                expected_output_files=[],
            )

            # ? ----------------------------------------------------------------
            # ? Execute the step.
            # ? ----------------------------------------------------------------

            return super()._execute(  # type: ignore
                step, work_directory, ignore_stdout=True, **_
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
