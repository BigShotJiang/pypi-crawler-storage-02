from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.function_annotation.metagenome_pipeline import (
    MetagenomePipeline,
)
from mdv.domain.entities.step_execution import StepResponse
from mdv.settings import LOGGER


class MetagenomePipelineRepository(
    MetagenomePipeline,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory_freq_table: Path,
        source_directory_hsp_marker: Path,
        source_directory_hsp_function: Path,
        input_frequency_table: str,
        input_function_table: str,
        input_marker_table: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(source_directory_hsp_marker, Path):
            return ExecutionError(
                "`source_directory_hsp_marker` should be a `Path` instance.",
                logger=LOGGER,
            )()

        if not isinstance(source_directory_hsp_function, Path):
            return ExecutionError(
                "`source_directory_hsp_function` should be a `Path` instance.",
                logger=LOGGER,
            )()

        try:
            # ? ----------------------------------------------------------------
            # ? Validate input files.
            # ? ----------------------------------------------------------------

            freq_table_path = "/freq-table"
            marker_path = "/marker"
            function_path = "/function"

            container_freq_table_directory = Path(freq_table_path)
            container_hsp_marker_directory = Path(marker_path)
            container_hsp_function_directory = Path(function_path)

            # ? ----------------------------------------------------------------
            # ? Build the `StepDTO` object.
            # ? ----------------------------------------------------------------

            step = StepDTO(
                target=TargetDTO(
                    name="metagenome-pipeline-picrust2",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.PICRUST.value,
                command=[
                    "/bin/bash",
                    "-c",
                    " ".join(
                        [
                            "conda",
                            "run",
                            "-n",
                            "picrust2",
                            "metagenome_pipeline.py",
                            "--input",
                            f"{freq_table_path}/{input_frequency_table}",
                            "--function",
                            f"{function_path}/{input_function_table}",
                            "--marker",
                            f"{marker_path}/{input_marker_table}",
                            "--out_dir",
                            "/output/EC_metagenome_out/",
                            "--strat_out",
                        ]
                    ),
                ],
                input_dir=[
                    InputDTO(
                        source=Path(source_directory_freq_table),
                        destination=container_freq_table_directory,
                    ),
                    InputDTO(
                        source=Path(source_directory_hsp_marker),
                        destination=container_hsp_marker_directory,
                    ),
                    InputDTO(
                        source=Path(source_directory_hsp_function),
                        destination=container_hsp_function_directory,
                    ),
                ],
                output_dir=destination_directory,
                expected_output_files=[],
            )

            # ? ----------------------------------------------------------------
            # ? Execute the step.
            # ? ----------------------------------------------------------------

            return super()._execute(
                step,
                work_directory,
                ignore_stdout=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
