from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.enums import TaxaEnum
from agrobase.exceptions import ExecutionError
from docker import DockerClient

from mdv.adapters.executors.docker import StepExecutionDockerMixin
from mdv.adapters.executors.docker.base_step_executor import ProjectDockerImages
from mdv.domain.dtos import InputDTO, StepDTO, StepType, TargetDTO
from mdv.domain.entities.function_annotation.hidden_state_prediction import (
    HiddenStatePredictionStep,
)
from mdv.domain.entities.step_execution import StepResponse
from mdv.settings import AVAILABLE_CORES, LOGGER


class HiddenStatePredictionStepDockerRepository(
    HiddenStatePredictionStep,
    StepExecutionDockerMixin,
):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(
        cls,
        client: DockerClient,
    ) -> None:
        return super().__init_subclass__(  # type: ignore
            client=client,
            logger=LOGGER,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_tree: str,
        output_prediction: str,
        work_directory: Path,
        taxa: TaxaEnum,
        is_ec: bool,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        if not isinstance(source_directory, Path):
            return ExecutionError(
                "`source_directory` should be a `Path` instance.",
                logger=LOGGER,
            )()

        if not isinstance(taxa, TaxaEnum):
            return ExecutionError(
                "`taxa` should be a `TaxaEnum` instance.",
                logger=LOGGER,
            )()

        try:
            # ? ----------------------------------------------------------------
            # ? Validate input files.
            # ? ----------------------------------------------------------------

            input_directory = Path("/input")

            # ? ----------------------------------------------------------------
            # ? Adjust params given the taxa
            # ? ----------------------------------------------------------------

            command = [
                "conda",
                "run",
                "-n",
                "picrust2",
                "hsp.py",
                "--tree",
                f"/input/{input_tree}",
                "--output",
                f"/output/{output_prediction}",
                "--processes",
                str(AVAILABLE_CORES),
            ]

            if taxa == TaxaEnum.FUNGI:
                command.append("--observed_trait_table")
                command.append(
                    "/opt/conda/envs/picrust2/lib/python3.6/site-packages/picrust2/default_files/fungi/ec_ITS_counts.txt.gz"
                    if is_ec is True
                    else "/opt/conda/envs/picrust2/lib/python3.6/site-packages/picrust2/default_files/fungi/ITS_counts.txt.gz"
                )
            else:
                command.append("--in_trait")
                command.append("EC" if is_ec is True else "16S")

            # ? ----------------------------------------------------------------
            # ? Build the `StepDTO` object.
            # ? ----------------------------------------------------------------

            step = StepDTO(
                target=TargetDTO(
                    name="hidden-state-prediction-picrust2",
                    mode=StepType.INDIVIDUAL,
                ),
                group=group,
                image=ProjectDockerImages.PICRUST.value,
                command=["/bin/bash", "-c", " ".join(command)],
                input_dir=[
                    InputDTO(
                        source=Path(source_directory),
                        destination=input_directory,
                    )
                ],
                output_dir=destination_directory,
                expected_output_files=[
                    output_prediction,
                ],
            )

            # ? ----------------------------------------------------------------
            # ? Execute the step.
            # ? ----------------------------------------------------------------

            return super()._execute(
                step,
                work_directory,
                ignore_stdout=True,
                **_,
            )

        except Exception as exc:
            return ExecutionError(exc, logger=LOGGER)()
