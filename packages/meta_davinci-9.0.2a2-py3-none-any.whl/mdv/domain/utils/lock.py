from logging import Logger
from pathlib import Path
from typing import Literal

from agrobase.either import Either, right
from agrobase.exceptions import LockFileError

from mdv.settings import LOCK_FILE, LOGGER


def create_lock_file(
    step_directory: Path,
    logger: Logger,
) -> Either[LockFileError, Literal[True]]:
    """Create a lock file containing a literal `1` byte. This file should be
    created if the step was successfully done.

    Args:
        step_directory (Path): The directory to create the lock file.

    Returns:
        Either[LockFileError, Literal[True]]: A `True` response if the lock
            file was created successfully.

    """

    try:
        if not step_directory.is_dir():
            return LockFileError(
                "`step_directory` should a existing directory.",
                logger=LOGGER,
            )()

        with step_directory.joinpath(LOCK_FILE).open("w") as lock:
            lock.write("1")

        return right(True)

    except Exception as exc:
        return LockFileError(
            f"Unexpected error detected on create lock file: {exc}",
            logger=LOGGER,
        )()


def has_lock_file(
    step_directory: Path,
    logger: Logger,
) -> Either[LockFileError, bool]:
    """Check if the `step_directory` contains a lock file.

    Args:
        step_directory (Path): The directory to be checked.

    Returns:
        Either[LockFileError, bool]: A `True` response if the lock file
            exists. A `False` response otherwise.

    """

    try:
        if not step_directory.is_dir():
            return LockFileError(
                "`step_directory` should a existing directory.",
                logger=LOGGER,
            )()

        content = 0
        lock_file_path = step_directory.joinpath(LOCK_FILE)

        if not lock_file_path.exists():
            return right(False)

        with step_directory.joinpath(LOCK_FILE).open("r") as lock:
            content = int(lock.read())

        if content == 1:
            return right(True)
        return right(False)

    except Exception as exc:
        return LockFileError(
            f"Unexpected error detected on check lock file: {exc}",
            logger=LOGGER,
        )()
