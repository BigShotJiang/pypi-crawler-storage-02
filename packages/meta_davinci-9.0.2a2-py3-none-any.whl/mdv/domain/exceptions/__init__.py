class InvalidQiimeMetadataException(ValueError):
    pass


class InvalidMdvMetadataException(Exception):
    pass
