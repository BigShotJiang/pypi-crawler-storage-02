from enum import Enum, unique
from typing import Any, NamedTuple, Self

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right

from mdv.settings import (
    DBS_THIRDPARTY_BIOLINNAEUS_16S_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_16S_TAXONOMY,
    DBS_THIRDPARTY_BIOLINNAEUS_18S_FUNGAL_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_18S_FUNGAL_TAXONOMY,
    DBS_THIRDPARTY_BIOLINNAEUS_28S_FUNGAL_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_28S_FUNGAL_TAXONOMY,
    DBS_THIRDPARTY_BIOLINNAEUS_ITS_EUKARYOTE_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_ITS_EUKARYOTE_TAXONOMY,
    DBS_THIRDPARTY_BIOLINNAEUS_ITS_REFSEQ_FUNGAL_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_ITS_REFSEQ_FUNGAL_TAXONOMY,
    DBS_THIRDPARTY_BIOLINNAEUS_LSU_EUKARYOTE_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_LSU_EUKARYOTE_TAXONOMY,
    DBS_THIRDPARTY_BIOLINNAEUS_LSU_PROKARYOTE_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_LSU_PROKARYOTE_TAXONOMY,
    DBS_THIRDPARTY_BIOLINNAEUS_SSU_EUKARYOTE_SEQUENCES,
    DBS_THIRDPARTY_BIOLINNAEUS_SSU_EUKARYOTE_TAXONOMY,
    LOGGER,
    NTNR_DATABASES,
)


class BlastFilesPair(NamedTuple):
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    sequences_file_name: str
    taxonomies_file_name: str

    # ? ------------------------------------------------------------------------
    # ? Public methods
    # ? ------------------------------------------------------------------------

    def as_dict(
        self,
    ) -> dict[str, Any]:
        return {
            "sequences_file_name": self.sequences_file_name,
            "taxonomies_file_name": self.taxonomies_file_name,
        }

    @classmethod
    def from_dict(
        cls,
        dict_content: dict[str, Any],
    ) -> Either[bio_exc.CreationError, Self]:
        required_keys = [
            "sequences_file_name",
            "taxonomies_file_name",
        ]

        try:
            for key in required_keys:
                if key not in dict_content:
                    return bio_exc.CreationError(
                        f"Required key empty in config JSON: `{key}`",
                        logger=LOGGER,
                    )()

            if (sequences_file_name := dict_content.get("sequences_file_name")) is None:
                return bio_exc.CreationError(
                    "Required key empty in config JSON: `sequences_file_name`",
                    logger=LOGGER,
                )()

            if (
                taxonomies_file_name := dict_content.get("taxonomies_file_name")
            ) is None:
                return bio_exc.CreationError(
                    "Required key empty in config JSON: `taxonomies_file_name`",
                    logger=LOGGER,
                )()

            return right(
                cls(
                    sequences_file_name=sequences_file_name,
                    taxonomies_file_name=taxonomies_file_name,
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


class BlastReferenceDatabase(NamedTuple):
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    name: str
    source: str
    version: str
    genomic_region: str
    blast_files: BlastFilesPair

    # ? ------------------------------------------------------------------------
    # ? Public methods
    # ? ------------------------------------------------------------------------

    def as_dict(
        self,
    ) -> dict[str, Any]:
        return {
            "name": self.name,
            "source": self.source,
            "version": self.version,
            "genomic_region": self.genomic_region,
            "blast_files": self.blast_files.as_dict(),
        }

    @classmethod
    def from_dict(
        cls,
        dict_content: dict[str, Any],
    ) -> Either[bio_exc.CreationError, Self]:
        required_keys = [
            "name",
            "source",
            "version",
            "genomic_region",
            "blast_files",
        ]

        try:
            for key in required_keys:
                if key not in dict_content:
                    return bio_exc.CreationError(
                        f"Required key empty in config JSON: `{key}`",
                        logger=LOGGER,
                    )()

            if (blast_files := dict_content.get("blast_files")) is None:
                return bio_exc.CreationError(
                    "Required key empty in config JSON: `blast_files`",
                    logger=LOGGER,
                )()

            blast_files_either = BlastFilesPair.from_dict(dict_content=blast_files)

            if blast_files_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create `BlastFilesPair`.",
                    prev=blast_files_either.value,
                    logger=LOGGER,
                )()

            blast_files_pair: BlastFilesPair = blast_files_either.value  # type: ignore

            return right(
                cls(
                    name=dict_content.get("name").__str__(),
                    source=dict_content.get("source").__str__(),
                    version=dict_content.get("version").__str__(),
                    genomic_region=dict_content.get("genomic_region").__str__(),
                    blast_files=blast_files_pair,
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


@unique
class ReferenceDatabases(Enum):
    # ? ------------------------------------------------------------------------
    # ? BACTERIA
    # ? ------------------------------------------------------------------------

    BACTERIAL_RIBOSOMAL_LSU_NTNR: tuple[str, BlastReferenceDatabase] = (
        "bacterial-LSU-ntnr",
        BlastReferenceDatabase(
            name="bacterial-26S-ntnr",
            source="NTNR",
            version="1.0",
            genomic_region="26S",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_LSU_PROKARYOTE_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_LSU_PROKARYOTE_TAXONOMY.name,
            ),
        ),
    )

    BACTERIAL_RIBOSOMAL_16S_NTNR: tuple[str, BlastReferenceDatabase] = (
        "bacterial-SSU-ntnr",
        BlastReferenceDatabase(
            name="bacterial-16S-ntnr",
            source="NTNR",
            version="1.0",
            genomic_region="16S",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_16S_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_16S_TAXONOMY.name,
            ),
        ),
    )

    # ? ------------------------------------------------------------------------
    # ? FUNGI
    # ? ------------------------------------------------------------------------

    FUNGAL_RIBOSOMAL_ITS_REFSEQ_NTNR: tuple[str, BlastReferenceDatabase] = (
        "fungal-ITS-ntnr-refseq",
        BlastReferenceDatabase(
            name="fungal-ITS-ntnr-refseq",
            source="NTNR",
            version="1.0",
            genomic_region="58S-fungi",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_ITS_REFSEQ_FUNGAL_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_ITS_REFSEQ_FUNGAL_TAXONOMY.name,
            ),
        ),
    )

    FUNGAL_RIBOSOMAL_28S_NTNR: tuple[str, BlastReferenceDatabase] = (
        "fungal-LSU-ntnr",
        BlastReferenceDatabase(
            name="fungal-28S-ntnr",
            source="NTNR",
            version="1.0",
            genomic_region="28S",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_28S_FUNGAL_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_28S_FUNGAL_TAXONOMY.name,
            ),
        ),
    )

    FUNGAL_RIBOSOMAL_18S_NTNR: tuple[str, BlastReferenceDatabase] = (
        "fungal-SSU-ntnr",
        BlastReferenceDatabase(
            name="fungal-18S-ntnr",
            source="NTNR",
            version="1.0",
            genomic_region="18S",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_18S_FUNGAL_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_18S_FUNGAL_TAXONOMY.name,
            ),
        ),
    )

    # ? ------------------------------------------------------------------------
    # ? EUKARYOTE
    # ? ------------------------------------------------------------------------

    EUKARYOTE_RIBOSOMAL_ITS_NTNR: tuple[str, BlastReferenceDatabase] = (
        "eukaryote-ITS-ntnr",
        BlastReferenceDatabase(
            name="eukaryote-58S-ntnr",
            source="NTNR",
            version="1.0",
            genomic_region="58S",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_ITS_EUKARYOTE_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_ITS_EUKARYOTE_TAXONOMY.name,
            ),
        ),
    )

    EUKARYOTE_RIBOSOMAL_LSU_NTNR: tuple[str, BlastReferenceDatabase] = (
        "eukaryote-LSU-ntnr",
        BlastReferenceDatabase(
            name="eukaryote-28S-ntnr",
            source="NTNR",
            version="1.0",
            genomic_region="28S",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_LSU_EUKARYOTE_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_LSU_EUKARYOTE_TAXONOMY.name,
            ),
        ),
    )

    EUKARYOTE_RIBOSOMAL_SSU_NTNR: tuple[str, BlastReferenceDatabase] = (
        "eukaryote-SSU-ntnr",
        BlastReferenceDatabase(
            name="eukaryote-18S-ntnr",
            source="NTNR",
            version="1.0",
            genomic_region="18S",
            blast_files=BlastFilesPair(
                sequences_file_name=DBS_THIRDPARTY_BIOLINNAEUS_SSU_EUKARYOTE_SEQUENCES.name,
                taxonomies_file_name=DBS_THIRDPARTY_BIOLINNAEUS_SSU_EUKARYOTE_TAXONOMY.name,
            ),
        ),
    )

    @classmethod
    def get_database_str_names(cls) -> list[str]:
        return [i.value[0] for i in cls]

    @classmethod
    def get_database_by_name(cls, db_name: str) -> BlastReferenceDatabase | None:
        for db in cls:
            if db.value[0] == db_name:
                return db.value[1]

        return None

    @classmethod
    def check_dbs_availability(cls) -> list[tuple[Self, bool]]:
        databases: list[tuple[Self, bool]] = []

        for db in cls:
            sequence_file = NTNR_DATABASES.joinpath(
                db.value[1].blast_files.sequences_file_name
            )

            taxonomies_file = NTNR_DATABASES.joinpath(
                db.value[1].blast_files.taxonomies_file_name
            )

            if sequence_file.is_file() and taxonomies_file.is_file():
                databases.append((db, True))
                continue
            databases.append((db, False))

        return databases
