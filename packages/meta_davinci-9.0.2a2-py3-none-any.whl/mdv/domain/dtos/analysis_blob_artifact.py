from __future__ import annotations

from enum import Enum
from hashlib import md5
from pathlib import Path
from re import search as re_search
from typing import Any, Literal, Self

from attrs import define, field
import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from clean_base.lock import has_named_lock, lock_named

from mdv.settings import (
    BOOT_CONFIG_FILE_NAME,
    DUMP_FILE_SUFFIX,
    DUMP_FOLDER_SUFFIX,
    DUMP_MAIN_DIRECTORY,
    LOGGER,
)


_MDV_DATE_REGEX = "^20[0-9]{2}[0-1][0-9][0-3][0-9]"
_MDV_TIME_REGEX = "[0-1][0-9][0-6][0-9][0-6][0-9]"
_MDV_UUID_SUFFIX = "[0-9a-zA-Z]{8}"

_COMPRESS_LOCK_NAME = "compress"
_UPLOAD_LOCK_NAME = "upload"
_LOCK_DIR = "locks"


class ArtifactGroup(Enum):
    MDV = "meta-davinci"
    QS = "quorum-sensing"
    MAP = "mapping"
    EXTRA = "extra"

    @classmethod
    def _missing_(cls, _: Any = None) -> ArtifactGroup:
        return ArtifactGroup.EXTRA


@define(kw_only=True)
class AnalysisBlobArtifact:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    results_folder: str = field()
    file: Path = field()
    year: int = field()
    dump_artifact: Path = field()
    compress_artifact: str = field()
    upload_artifact: str = field()
    group: ArtifactGroup | None = field(default=None)

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOK METHODS
    # ? ------------------------------------------------------------------------

    def __hash__(self) -> int:
        return self.file.__hash__()

    def __eq__(self, value: object) -> bool:
        if not isinstance(value, AnalysisBlobArtifact):
            return False

        return self.file.__hash__() == value.file.__hash__()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def hash_artifact(self) -> str:
        hash_md5 = md5()

        with open(self.dump_artifact, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)

        return hash_md5.hexdigest()

    def was_compressed(self, analysis_directory: Path) -> bool:
        return has_named_lock(
            self.__init_lock_dir(analysis_directory),
            self.compress_artifact,
        )

    def lock_compress(self, analysis_directory: Path) -> bool:
        return lock_named(
            self.__init_lock_dir(analysis_directory),
            self.compress_artifact,
        )

    def was_uploaded(self, analysis_directory: Path) -> bool:
        return has_named_lock(
            self.__init_lock_dir(analysis_directory),
            self.upload_artifact,
        )

    def lock_upload(self, analysis_directory: Path) -> bool:
        return lock_named(
            self.__init_lock_dir(analysis_directory),
            self.upload_artifact,
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC CLASS METHODS
    # ? ------------------------------------------------------------------------

    @classmethod
    def new(
        cls,
        file: Path,
        year: int,
        analysis_name: str,
        dump_dir: Path | None = None,
        include_parent_name: bool = False,
    ) -> Either[bio_exc.UseCaseError, Self]:
        if file.exists() is False:
            return bio_exc.UseCaseError(
                f"Invalid path: {file}",
                logger=LOGGER,
            )()

        if (
            dump_file_either := cls.__build_dump_artifact(
                file=file,
                dump_dir=dump_dir,
                include_parent_name=include_parent_name,
            )
        ).is_left:
            return dump_file_either
        dump_file = dump_file_either.value

        return right(
            cls(
                results_folder=analysis_name,
                file=file,
                year=year,
                dump_artifact=dump_file,
                compress_artifact=cls.__build_lock_file_name(
                    dump_file,
                    "compress",
                ),
                upload_artifact=cls.__build_lock_file_name(
                    dump_file,
                    "upload",
                ),
            )
        )

    # ? ------------------------------------------------------------------------
    # ? PUBLIC STATIC METHODS
    # ? ------------------------------------------------------------------------

    @staticmethod
    def match_mdv_directory(paths: list[Path]) -> bool:
        return AnalysisBlobArtifact.filter_mdv_directories(paths).__len__() > 0

    @staticmethod
    def filter_mdv_directories(paths: list[Path]) -> list[Path]:
        return [
            path
            for path in paths
            if AnalysisBlobArtifact.match_single_analysis_mdv_dir(path) is True
        ]

    @staticmethod
    def match_single_analysis_mdv_dir(path: Path) -> bool:
        return all(
            [
                re_search(
                    rf"{_MDV_DATE_REGEX}-{_MDV_TIME_REGEX}-{_MDV_UUID_SUFFIX}",
                    path.name,
                ),
                path.joinpath(BOOT_CONFIG_FILE_NAME).is_file(),
            ]
        )

    @staticmethod
    def match_qs_directory(paths: list[Path]) -> bool:
        return [
            match
            for path in paths
            if (
                match := any(
                    [
                        re_search("merged.json", path.name),
                        re_search("merged.tsv", path.name),
                    ]
                )
                is True
            )
        ].__len__() > 0

    @staticmethod
    def is_dump_artifact(file: Path) -> bool:
        return any(
            [
                file.__str__().endswith(DUMP_FILE_SUFFIX),
                file.__str__().endswith(DUMP_FOLDER_SUFFIX),
            ]
        )

    # ? ------------------------------------------------------------------------
    # ? PRIVATE STATIC METHODS
    # ? ------------------------------------------------------------------------

    @staticmethod
    def __build_dump_artifact(
        file: Path,
        dump_dir: Path | None,
        include_parent_name: bool = False,
    ) -> Either[bio_exc.UseCaseError, Path]:
        if dump_dir is None:
            dump_dir = file.parent.joinpath(DUMP_MAIN_DIRECTORY)

        if not dump_dir.exists():
            dump_dir.mkdir()

        file_name = (
            file.name
            if include_parent_name is False
            else (f"{file.parent.name}-{file.name}")
        )

        if file.is_file():
            return right(dump_dir.joinpath(file_name + DUMP_FILE_SUFFIX))
        elif file.is_dir():
            return right(dump_dir.joinpath(file_name + DUMP_FOLDER_SUFFIX))
        else:
            return bio_exc.UseCaseError(
                f"Invalid path. Only directories and files accepted: {file}",
                logger=LOGGER,
            )()

    @staticmethod
    def __build_lock_file_name(
        path: Path,
        step: Literal["compress"] | Literal["upload"],
    ) -> str:
        if step == "compress":
            return f"{path.name}.{_COMPRESS_LOCK_NAME}"
        if step == "upload":
            return f"{path.name}.{_UPLOAD_LOCK_NAME}"

        raise Exception(f"Invalid step: {step}")

    @staticmethod
    def __init_lock_dir(
        analysis_directory: Path,
    ) -> Path:
        path = analysis_directory.joinpath(DUMP_MAIN_DIRECTORY, _LOCK_DIR)

        if path.exists() is False:
            path.mkdir()

        return path
