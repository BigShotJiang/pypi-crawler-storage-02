from io import StringIO
from os import getenv
from pathlib import Path
from unittest import TestCase

from pandas import read_csv

from mdv.domain.dtos.bootstrap_handler import BootstrapHandler


class TestBootstrapHandlerSchema(TestCase):
    def setUp(self) -> None:
        self.__fastq_dir_path = Path(str(getenv("VALID_SOURCE_FASTQ_DIR")))
        fwd_file_path = Path(str(getenv("VALID_SOURCE_FASTQ_FWD_FILE")))
        rev_file_path = Path(str(getenv("VALID_SOURCE_FASTQ_REV_FILE")))

        if (
            not self.__fastq_dir_path.joinpath(fwd_file_path).is_file()
            or not self.__fastq_dir_path.joinpath(rev_file_path).is_file()
        ):
            raise FileNotFoundError(
                f"FASTQ files {fwd_file_path} or {rev_file_path} not found"
            )

        valid_boot_table = f"""
sample_code\tforward_file\treverse_file\tse_recovery
sample1\t{fwd_file_path}\t{rev_file_path}\ttrue
        """

        self.__valid_boot_table = read_csv(
            StringIO(valid_boot_table),
            sep="\t",
        )

    def test_handle_with_valid_data(self) -> None:
        BootstrapHandler(
            samples_map=self.__valid_boot_table,
            source_directory=self.__fastq_dir_path,
        )
