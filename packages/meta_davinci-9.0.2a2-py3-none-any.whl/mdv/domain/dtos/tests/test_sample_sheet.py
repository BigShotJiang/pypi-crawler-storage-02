from pathlib import Path
from unittest import TestCase

from mdv.domain.dtos.sample_sheet import SampleSheet


class TestSampleSheet(TestCase):
    def test_parse_sample_sheet(self) -> None:
        res = SampleSheet.from_tabular_samplesheet(
            Path("src/tests/mock/sample-sheet.tsv/SampleSheet.csv")
        )

        self.assertFalse(res.is_left)
        self.assertTrue(res.is_right)
        self.assertIsInstance(res.value, SampleSheet)
