import logging
from pathlib import Path
from unittest import TestCase

from mdv.domain.dtos import (
    ResultsConfig,
    FastqFiles,
    AnalysisConfig,
    SampleConfig,
    SequencingTemplateEnum,
)
from mdv.domain.dtos.blast_databases import ReferenceDatabases

logging.basicConfig(level=logging.INFO)


class TestResultsSetDTO(TestCase):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def setUp(self) -> None:
        self.__work_directory = Path("/home/samuel-elias/storage/results/test/")
        self.__raw_data_dir = self.__work_directory.joinpath("raw-data")

    # ? ------------------------------------------------------------------------
    # ? TEST CASES
    # ? ------------------------------------------------------------------------

    def test_create_from_sample_set(self) -> None:
        sample_set_dto = AnalysisConfig(
            set_name="20220406-172343-8dc909e8",
            customer="test-customer",
            assay="assay1::v1",
            metadata_artifact=self.__raw_data_dir.joinpath("metadata-16s.tsv"),
            samples=[
                SampleConfig(
                    name="16S-B4A0360",
                    files=FastqFiles(
                        template=SequencingTemplateEnum.PAIRED_END,
                        forward_file=self.__raw_data_dir.joinpath(
                            "16S-B4A0360_S64_L001_R1_001.fastq.gz"
                        ),
                        reverse_file=self.__raw_data_dir.joinpath(
                            "16S-B4A0360_S64_L001_R2_001.fastq.gz"
                        ),
                    ),
                    blast_database=(
                        ReferenceDatabases.BACTERIAL_RIBOSOMAL_16S_SILVA.value[
                            1
                        ]
                    ),
                )
            ],
        )

        results_set_either = ResultsConfig.build_from_sample_set(
            sample_set=sample_set_dto
        )

        self.assertFalse(results_set_either.is_left)
        self.assertTrue(results_set_either.is_right)
        self.assertIsInstance(results_set_either.value, ResultsConfig)
