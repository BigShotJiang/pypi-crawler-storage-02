from __future__ import annotations

from json import dumps
from pathlib import Path
from typing import Any, Literal, NamedTuple, Self

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from attr import define, field

from mdv.settings import LOGGER

from .analysis_config import AnalysisConfig, SampleConfig

# ? ----------------------------------------------------------------------------
# ? BASE OBJECTS AND VALIDATION METHODS
# ? ----------------------------------------------------------------------------


class BaseArtifactsObject(NamedTuple):
    folder: str
    anyone: str


def check_artifact_instance(candidate: Any) -> None:
    """Check if a given named tuple is compatible with the expected artifact.

    Args:
        candidate (Any): The candidate object.

    Raises:
        ValueError: If the candidate is not compatible.
    """

    if not all(
        [
            isinstance(candidate, tuple),
            # getattr(candidate, "_fields", None) is not None,
            # len(getattr(candidate, "_fields", None)) > 1,  # type: ignore
            "folder" in getattr(candidate, "_fields", None),  # type: ignore
        ]
    ):
        raise ValueError("candidate object is not a valid artifact namedtuple.")


# ? ----------------------------------------------------------------------------
# ? QUALITY CONTROL OBJECTS
# ? ----------------------------------------------------------------------------


class ForwardReadsPreFilterArtifacts(NamedTuple):
    folder: str
    forward_filtered: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "forward_filtered": self.forward_filtered,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="filtered-forward-reads",
            forward_filtered=f"{sample}.forward-filtered.fastq.gz",
        )


class RawReadsPairedMatchArtifacts(NamedTuple):
    folder: str
    sub_folder: str
    forward_filtered: str
    reverse_filtered: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "sub_folder": self.sub_folder,
            "forward_filtered": self.forward_filtered,
            "reverse_filtered": self.reverse_filtered,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="matching-raw-reads",
            sub_folder="seqkit",
            forward_filtered=f"{sample}.forward-match-filtered.fastq.gz",
            reverse_filtered=f"{sample}.reverse-match-filtered.fastq.gz",
        )


class TrimmingArtifacts(NamedTuple):
    folder: str
    forward_filtered: str
    forward_unpaired: str
    reverse_paired: str
    reverse_unpaired: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "forward_paired": self.forward_filtered,
            "forward_unpaired": self.forward_unpaired,
            "reverse_paired": self.reverse_paired,
            "reverse_unpaired": self.reverse_unpaired,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="trimming",
            forward_filtered=f"{sample}.forward-paired.fastq",
            forward_unpaired=f"{sample}.forward-unpaired.fastq",
            reverse_paired=f"{sample}.reverse-paired.fastq",
            reverse_unpaired=f"{sample}.reverse-unpaired.fastq",
        )


class MergingArtifacts(NamedTuple):
    folder: str
    merged_pairs: str
    not_merged_fwd: str
    not_merged_rev: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "merged_pairs": self.merged_pairs,
            "not_merged_fwd": self.not_merged_fwd,
            "not_merged_rev": self.not_merged_rev,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="merge-pairs",
            merged_pairs=f"{sample}.merged.fasta",
            not_merged_fwd=f"{sample}.not-merged-fwd.fastq",
            not_merged_rev=f"{sample}.not-merged-rev.fastq",
        )


class QualityFilteringArtifacts(NamedTuple):
    folder: str
    filtered: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "filtered": self.filtered,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="quality-filter",
            filtered=f"{sample}.filtered.fasta",
        )


class DereplicationArtifacts(NamedTuple):
    folder: str
    dereplicated: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "dereplicated": self.dereplicated,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="dereplication",
            dereplicated=f"{sample}.dereplicated.fasta",
        )


class ChimeraRemovalArtifacts(NamedTuple):
    folder: str
    chimera_free: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "chimera_free": self.chimera_free,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="chimera-removal",
            chimera_free=f"{sample}.chimera-free.fasta",
        )


class OtuTableArtifacts(NamedTuple):
    folder: str
    sampled_otu_table: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "otu_table": self.sampled_otu_table,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="otu-table",
            sampled_otu_table=f"{sample}.sampled-otu-table.tsv",
        )


class RarefactionArtifacts(NamedTuple):
    folder: str
    rarefaction_table: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "rarefaction_table": self.rarefaction_table,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="rarefaction",
            rarefaction_table=f"{sample}.rarefaction.tsv",
        )


class SingleSampleRarefactionArtifacts(NamedTuple):
    folder: str
    sampled_otu_table: OtuTableArtifacts
    rarefaction_table: RarefactionArtifacts

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "otu_table": self.sampled_otu_table.as_dict(),
            "rarefaction_table": self.rarefaction_table.as_dict(),
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="rarefaction",
            sampled_otu_table=OtuTableArtifacts.create(sample),
            rarefaction_table=RarefactionArtifacts.create(sample),
        )


class DenoiseArtifacts(NamedTuple):
    folder: str
    denoise: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "denoise": self.denoise,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="denoise",
            denoise=f"{sample}.denoise.fasta",
        )


class OutputPolishArtifacts(NamedTuple):
    folder: str
    polished_sequences: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "polished_sequences": self.polished_sequences,
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Self:
        return cls(
            folder="polishing",
            polished_sequences=f"{sample}.polished.fasta",
        )


class QualityControlArtifacts(NamedTuple):
    folder: str
    forward_filtering: ForwardReadsPreFilterArtifacts
    filtering_matching: RawReadsPairedMatchArtifacts
    trimming: TrimmingArtifacts
    merging: MergingArtifacts
    quality_filtering: QualityFilteringArtifacts
    dereplication: DereplicationArtifacts
    denoise: DenoiseArtifacts
    chimera_removal: ChimeraRemovalArtifacts
    rarefaction: SingleSampleRarefactionArtifacts
    output_polish: OutputPolishArtifacts

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "forward_filtering": self.forward_filtering.as_dict(),
            "filtering_matching": self.filtering_matching.as_dict(),
            "trimming": self.trimming.as_dict(),
            "merging": self.merging.as_dict(),
            "quality_filtering": self.quality_filtering.as_dict(),
            "dereplication": self.dereplication.as_dict(),
            "denoise": self.denoise.as_dict(),
            "chimera_removal": self.chimera_removal.as_dict(),
            "output_polish": self.output_polish.as_dict(),
        }

    @classmethod
    def create(
        cls,
        sample: str,
    ) -> Either[bio_exc.CreationError, Self]:
        try:
            return right(
                cls(
                    folder="quality-control",
                    forward_filtering=ForwardReadsPreFilterArtifacts.create(
                        sample
                    ),
                    filtering_matching=RawReadsPairedMatchArtifacts.create(
                        sample
                    ),
                    trimming=TrimmingArtifacts.create(sample),
                    merging=MergingArtifacts.create(sample),
                    quality_filtering=QualityFilteringArtifacts.create(sample),
                    dereplication=DereplicationArtifacts.create(sample),
                    denoise=DenoiseArtifacts.create(sample),
                    chimera_removal=ChimeraRemovalArtifacts.create(sample),
                    rarefaction=SingleSampleRarefactionArtifacts.create(sample),
                    output_polish=OutputPolishArtifacts.create(sample),
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


# ? ----------------------------------------------------------------------------
# ? FUNCTIONAL ANNOTATION ARTIFACTS
# ? ----------------------------------------------------------------------------


class PlaceSequencesArtifacts(NamedTuple):
    folder: str
    output_tree: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "output_tree": self.output_tree,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="place-sequences",
            output_tree=f"out.tree",
        )


class HiddenStatePredictionFunctionArtifacts(NamedTuple):
    folder: str
    predicted_function: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "predicted_function": self.predicted_function,
        }

    @classmethod
    def create(
        cls,
        **_: Any,
    ) -> Self:
        return cls(
            folder="hsp-ec",
            predicted_function=f"EC_predicted.tsv.gz",
        )


class HiddenStatePredictionMarkerArtifacts(NamedTuple):
    folder: str
    predicted_marker: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "predicted_marker": self.predicted_marker,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="hsp-marker",
            predicted_marker=f"marker_predicted_and_nsti.tsv.gz",
        )


class MetagenomePipelineArtifacts(NamedTuple):
    folder: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="metagenome-pipeline",
        )


class FunctionalAnnotationArtifacts(NamedTuple):
    folder: str

    # Fields used during full PICRUSt2 execution
    output_tree: str
    function_prediction: str
    marker_prediction: str

    # Fields used during step-by-step PICRUSt2 execution
    sequences_placement: PlaceSequencesArtifacts
    hsp_prediction_function: HiddenStatePredictionFunctionArtifacts
    hsp_prediction_marker: HiddenStatePredictionMarkerArtifacts
    metagenome_pipeline: MetagenomePipelineArtifacts

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "output_tree": self.output_tree,
            "function_prediction": self.function_prediction,
            "marker_prediction": self.marker_prediction,
            "sequences_placement": self.sequences_placement.as_dict(),
            "hsp_prediction_ec": self.hsp_prediction_function.as_dict(),
            "hsp_prediction_marker": self.hsp_prediction_marker.as_dict(),
            "metagenome_pipeline": self.metagenome_pipeline.as_dict(),
        }

    @classmethod
    def create(
        cls,
    ) -> Either[bio_exc.CreationError, Self]:
        try:
            return right(
                cls(
                    folder="functional-annotation",
                    output_tree="out.tree",
                    function_prediction="EC_predicted.tsv.gz",
                    marker_prediction="marker_predicted_and_nsti.tsv.gz",
                    sequences_placement=PlaceSequencesArtifacts.create(),
                    hsp_prediction_function=HiddenStatePredictionFunctionArtifacts.create(),
                    hsp_prediction_marker=HiddenStatePredictionMarkerArtifacts.create(),
                    metagenome_pipeline=MetagenomePipelineArtifacts.create(),
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


# ? ----------------------------------------------------------------------------
# ? AGGREGATION ARTIFACTS
# ? ----------------------------------------------------------------------------


class AggregationArtifacts(NamedTuple):
    folder: str
    frequency_table: str
    raw_fasta: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "frequency_table": self.frequency_table,
            "raw_fasta": self.raw_fasta,
        }

    @classmethod
    def create(
        cls,
    ) -> Either[bio_exc.CreationError, Self]:
        try:
            return right(
                cls(
                    folder="data-aggregation",
                    frequency_table="freq-table.tsv",
                    raw_fasta="raw-sequences.fna",
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


# ? ----------------------------------------------------------------------------
# ? TAXONOMY ASSIGNMENT OBJECTS
# ? ----------------------------------------------------------------------------


class TaxonomyAssignmentArtifacts(NamedTuple):
    folder: str
    blast_input: str
    blast_output: str
    bli_output: str
    blu_raw_output: str
    blu_output: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "blast_input": self.blast_input,
            "blast_output": self.blast_output,
            "bli_output": self.bli_output,
            "blu_raw_output": self.blu_raw_output,
            "blu_output": self.blu_output,
        }

    @classmethod
    def create(
        cls,
    ) -> Either[bio_exc.CreationError, Self]:
        try:
            return right(
                cls(
                    folder="tax-assignment",
                    blast_input="blast-in.qza",
                    blast_output="blast-out.qza",
                    bli_output="bli-out.tsv",
                    blu_raw_output="blutils.consensus.json",
                    blu_output="blu-out.tsv",
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


# ? ----------------------------------------------------------------------------
# ? PHYLOGENY AND DIVERSITY ARTIFACTS
# ? ----------------------------------------------------------------------------


class PreRunInputArtifactsArtifacts(NamedTuple):
    folder: str
    frequency_table_tsv: str
    frequency_table_biom: str
    raw_fasta_file: str
    blast_output: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "frequency_table_tsv": self.frequency_table_tsv,
            "frequency_table_biom": self.frequency_table_biom,
            "raw_fasta_file": self.raw_fasta_file,
            "blast_output": self.blast_output,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="pre-build",
            frequency_table_tsv="frequency-table.biom",
            frequency_table_biom="frequency-table.biom.qza",
            raw_fasta_file="raw-fasta.qza",
            blast_output="blast-output.qza",
        )


class PhylogeneticTreeArtifacts(NamedTuple):
    folder: str
    alignment_raw: str
    alignment_masked: str
    tree_rooted: str
    tree_unrooted: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "alignment_raw": self.alignment_raw,
            "alignment_masked": self.alignment_masked,
            "tree_rooted": self.tree_rooted,
            "tree_unrooted": self.tree_unrooted,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="phylogeny",
            alignment_raw="alignment-raw.qza",
            alignment_masked="alignment-masked.qza",
            tree_rooted="tree-rooted.qza",
            tree_unrooted="tree-unrooted.qza",
        )


class EcoDiversityFilteringTreeArtifacts(NamedTuple):
    folder: str
    filtered_table: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "filtered_table": self.filtered_table,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="eco-diversity-filtering",
            filtered_table="filtered-table.qza",
        )


class AlphaRarefactionArtifacts(NamedTuple):
    folder: str
    rarefied: str
    rarefied_raw_faith_pd: str
    rarefied_raw_observed: str
    rarefied_raw_shannon: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "rarefied": self.rarefied,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="alpha-rarefaction",
            rarefied="alpha-rarefaction.qzv",
            rarefied_raw_faith_pd="raw/alpha-rarefaction/faith_pd.csv",
            rarefied_raw_observed="raw/alpha-rarefaction/observed_features.csv",
            rarefied_raw_shannon="raw/alpha-rarefaction/shannon.csv",
        )


class AlphaDiversityArtifacts(NamedTuple):
    folder: str
    calculated_diversity: str
    calculated_diversity_raw: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "calculated_diversity": self.calculated_diversity,
        }

    @classmethod
    def create(
        cls,
    ) -> Self:
        return cls(
            folder="alpha-diversity-calculate",
            calculated_diversity="alpha-diversity.qza",
            calculated_diversity_raw="raw/alpha-diversity/alpha-diversity.tsv",
        )


class PhylogeneticDiversityArtifacts(NamedTuple):
    folder: str
    pre_build: PreRunInputArtifactsArtifacts
    phylogeny: PhylogeneticTreeArtifacts
    eco_diversity: EcoDiversityFilteringTreeArtifacts
    alpha_rarefaction: AlphaRarefactionArtifacts
    alpha_diversity: AlphaDiversityArtifacts

    def as_dict(self) -> dict[str, Any]:
        return {
            "folder": self.folder,
            "pre_build": self.pre_build,
            "phylogeny": self.phylogeny,
            "eco_diversity": self.eco_diversity,
            "alpha_rarefaction": self.alpha_rarefaction,
            "alpha_diversity": self.alpha_diversity,
        }

    @classmethod
    def create(
        cls,
    ) -> Either[bio_exc.CreationError, Self]:
        try:
            return right(
                cls(
                    folder="phy-diversity",
                    pre_build=PreRunInputArtifactsArtifacts.create(),
                    phylogeny=PhylogeneticTreeArtifacts.create(),
                    eco_diversity=EcoDiversityFilteringTreeArtifacts.create(),
                    alpha_rarefaction=AlphaRarefactionArtifacts.create(),
                    alpha_diversity=AlphaDiversityArtifacts.create(),
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


# ? ----------------------------------------------------------------------------
# ? RESULTS SET OBJECTS
# ? ----------------------------------------------------------------------------


class SampleResults(NamedTuple):
    specs: SampleConfig
    quality_control_artifacts: QualityControlArtifacts

    def as_dict(self) -> dict[str, Any]:
        return {
            "specs": self.specs.as_dict(),
            "quality_control_artifacts": self.quality_control_artifacts.as_dict(),
        }

    @classmethod
    def create_from_sample_specs(
        cls,
        sample_specs: SampleConfig,
    ) -> Either[bio_exc.CreationError, Self]:
        try:
            qc_artifacts_either = QualityControlArtifacts.create(
                sample_specs.name
            )

            if qc_artifacts_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create Quality Control "
                    + f"Artifacts object from sample specs: {sample_specs}",
                    prev=qc_artifacts_either.value,
                    logger=LOGGER,
                )()

            return right(
                cls(
                    specs=sample_specs,
                    quality_control_artifacts=qc_artifacts_either.value,  # type: ignore
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


@define
class ResultsConfig:
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    samples_results: list[SampleResults]
    aggregation_results: AggregationArtifacts
    taxonomy_results: TaxonomyAssignmentArtifacts
    phylogenetic_results: PhylogeneticDiversityArtifacts
    functional_annotation: FunctionalAnnotationArtifacts

    sample_file_name: str = field(default="results-config.json")

    # ? ------------------------------------------------------------------------
    # ? Public methods
    # ? ------------------------------------------------------------------------

    def to_json(
        self,
        output_directory: Path,
    ) -> Either[bio_exc.UseCaseError, Literal[True]]:
        try:
            with output_directory.joinpath(self.sample_file_name).open(
                "w+"
            ) as out_file:
                out_file.write(dumps(self.as_dict(), indent=4, default=str))

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def as_dict(self) -> dict[str, Any]:
        return {
            "samples_results": [i.as_dict() for i in self.samples_results],
            "aggregation_results": self.aggregation_results.as_dict(),
            "taxonomy_results": self.taxonomy_results.as_dict(),
            "phylogenetic_results": self.phylogenetic_results.as_dict(),
            "functional_annotation": self.functional_annotation.as_dict(),
        }

    @classmethod
    def build_from_sample_set(
        cls,
        sample_set: AnalysisConfig,
    ) -> Either[bio_exc.CreationError, Self]:
        try:
            # ? ----------------------------------------------------------------
            # ? BUILD SAMPLES RESULTS ARTIFACTS
            # ? ----------------------------------------------------------------

            samples_results: list[SampleResults] = []

            for sample_specs in sample_set.samples:
                sample_results_either = SampleResults.create_from_sample_specs(
                    sample_specs=sample_specs
                )

                if sample_results_either.is_left:
                    return bio_exc.CreationError(
                        "Unexpected error detected on create sample results "
                        + f"object object from sample specs: {sample_specs}",
                        prev=sample_results_either.value,
                        logger=LOGGER,
                    )()

                samples_results.append(sample_results_either.value)  # type: ignore

            # ? ----------------------------------------------------------------
            # ? BUILD AGGREGATION ARTIFACTS
            # ? ----------------------------------------------------------------

            aggregation_either = AggregationArtifacts.create()

            if aggregation_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create aggregation object.",
                    prev=aggregation_either.value,
                    logger=LOGGER,
                )()

            aggregation_results: AggregationArtifacts = aggregation_either.value  # type: ignore

            # ? ----------------------------------------------------------------
            # ? BUILD TAXONOMY ARTIFACTS
            # ? ----------------------------------------------------------------

            taxonomy_either = TaxonomyAssignmentArtifacts.create()

            if taxonomy_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create taxonomy object.",
                    prev=taxonomy_either.value,
                    logger=LOGGER,
                )()

            taxonomy_results: TaxonomyAssignmentArtifacts = (
                taxonomy_either.value  # type: ignore
            )

            # ? ----------------------------------------------------------------
            # ? BUILD PHYLOGENY ARTIFACTS
            # ? ----------------------------------------------------------------

            phylogeny_either = PhylogeneticDiversityArtifacts.create()

            if phylogeny_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create phylogeny object.",
                    prev=phylogeny_either.value,
                    logger=LOGGER,
                )()

            phylogeny_results: PhylogeneticDiversityArtifacts = (
                phylogeny_either.value  # type: ignore
            )

            # ? ----------------------------------------------------------------
            # ? BUILD FUNCTIONAL ANNOTATION ARTIFACT
            # ? ----------------------------------------------------------------

            functional_annotation_either = (
                FunctionalAnnotationArtifacts.create()
            )

            if functional_annotation_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create phylogeny object.",
                    prev=functional_annotation_either.value,
                    logger=LOGGER,
                )()

            functional_annotation_results: FunctionalAnnotationArtifacts = (
                functional_annotation_either.value  # type: ignore
            )

            # ? ----------------------------------------------------------------
            # ? BUILD RESULTS SET OUTPUT
            # ? ----------------------------------------------------------------

            return right(
                cls(
                    samples_results=samples_results,
                    aggregation_results=aggregation_results,
                    taxonomy_results=taxonomy_results,
                    phylogenetic_results=phylogeny_results,
                    functional_annotation=functional_annotation_results,
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()
