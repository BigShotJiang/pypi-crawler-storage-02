from enum import Enum
from pathlib import Path
from typing import Any

from attrs import define, field
from pandas import DataFrame
from pandera import Check, Column, DataFrameSchema
from pandera.errors import SchemaError

from mdv.domain.exceptions import InvalidMdvMetadataException


class MetadataColNamesEnum(Enum):
    SAMPLE_CODE = "sample_code"
    FORWARD_FILE = "forward_file"
    REVERSE_FILE = "reverse_file"
    SERVICE_ORDER = "service_order"
    SINGLE_END_RECOVERY = "se_recovery"
    SAMPLE_TYPE_COMPLEX = "complex"


__file_is_valid_check = Check(
    lambda x: str(x).endswith(".fastq.gz"),
    element_wise=True,
)


BasicBootstrapHandlerSchema = DataFrameSchema(
    columns={
        MetadataColNamesEnum.SAMPLE_CODE.value: Column(
            str,
            nullable=False,
            unique=True,
        ),
        MetadataColNamesEnum.FORWARD_FILE.value: Column(
            str,
            nullable=False,
            unique=True,
            checks=[__file_is_valid_check],
        ),
        MetadataColNamesEnum.REVERSE_FILE.value: Column(
            str,
            nullable=False,
            unique=True,
            checks=[__file_is_valid_check],
        ),
        MetadataColNamesEnum.SERVICE_ORDER.value: Column(
            str,
            nullable=True,
            required=False,
        ),
        MetadataColNamesEnum.SINGLE_END_RECOVERY.value: Column(
            bool,
            nullable=True,
            required=False,
        ),
        MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value: Column(
            bool,
            nullable=True,
            required=False,
        ),
    }
)


def bootstrap_file_has_valid_schema(
    instance: Any,
    attribute: Any,
    value: DataFrame,
) -> None:
    try:
        BasicBootstrapHandlerSchema.validate(value)
    except SchemaError as exc:
        raise InvalidMdvMetadataException(
            f"Invalid metadata format: {exc}"
        ) from exc


def path_is_valid(
    instance: Any,
    attribute: Any,
    value: Path,
) -> None:
    if not value.exists():
        raise ValueError(f"Path {value} does not exist")

    if not value.is_dir():
        raise ValueError(f"Path {value} is not a directory")


@define
class BootstrapHandler:
    # ? ------------------------------------------------------------------------
    # ? ATTRIBUTE DEFINITIONS
    # ? ------------------------------------------------------------------------

    source_directory: Path = field(validator=[path_is_valid])
    samples_map: DataFrame = field(validator=[bootstrap_file_has_valid_schema])
