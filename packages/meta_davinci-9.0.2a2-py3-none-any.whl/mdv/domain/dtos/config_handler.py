from __future__ import annotations

from enum import Enum
from pathlib import Path

from attr import define, field

# ? ----------------------------------------------------------------------------
# ? BASIC TYPES
# ? ----------------------------------------------------------------------------


class StepType(Enum):
    # ? Individual steps are executed over a single sample
    INDIVIDUAL = "individual"

    # ? Individual steps are executed over a group of samples
    COMPOSED = "composed"


# ? ----------------------------------------------------------------------------
# ? DATA TRANSFER OBJECTS
# ? ----------------------------------------------------------------------------


@define
class TargetDTO:
    # ? ------------------------------------------------------------------------
    # ? ATTRIBUTE DEFINITIONS
    # ? ------------------------------------------------------------------------

    name: str
    mode: StepType


@define
class InputDTO:
    # ? ------------------------------------------------------------------------
    # ? ATTRIBUTE DEFINITIONS
    # ? ------------------------------------------------------------------------

    source: Path = field(converter=Path)
    destination: Path = field(default=Path("input"), converter=Path)  # type: ignore

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    @classmethod
    def create(
        cls,
        source: Path,
        destination: Path | None = None,
    ) -> InputDTO:
        """The object creator.

        Args:
            source (OptionalPath): The local file system source destination.
            destination (OptionalPath, optional): The container file system
                target destination. Defaults to None.

        Raises:
            ValueError: If the `source` or `destination` arguments are not
                instance of `OptionalPath` type.

        Returns:
            InputDTO: A instance of itself.
        """

        if not isinstance(source, Path):
            raise ValueError("`source` should be a `OptionalPath` instance.")

        if destination:
            if not isinstance(destination, Path):
                raise ValueError(
                    "`target` should be a `OptionalPath` instance."
                )

        return InputDTO(
            source=Path(source.__str__()),
            destination=destination.__str__(),
        )


@define
class ImageDTO:
    # ? ------------------------------------------------------------------------
    # ? ATTRIBUTE DEFINITIONS
    # ? ------------------------------------------------------------------------

    name: str
    tag: str = "latest"

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def full_name(self) -> str:
        """Build the `name:tag` string.

        Returns:
            str: The compiled name of the image.
        """

        return f"{self.name}:{self.tag}"


@define
class StepDTO:
    # ? ------------------------------------------------------------------------
    # ? ATTRIBUTE DEFINITIONS
    # ? ------------------------------------------------------------------------

    target: TargetDTO
    group: str
    image: ImageDTO
    command: list[str]
    input_dir: list[InputDTO]
    output_dir: Path | None = field(converter=Path, default=None)
    entrypoint: str | None = None
    expected_output_files: list[Path | str] | None = None


@define
class ConfigHandlerDTO:
    # ? ------------------------------------------------------------------------
    # ? ATTRIBUTE DEFINITIONS
    # ? ------------------------------------------------------------------------

    work_directory: Path
    analysis_id: str
    steps: list[StepDTO] = []
