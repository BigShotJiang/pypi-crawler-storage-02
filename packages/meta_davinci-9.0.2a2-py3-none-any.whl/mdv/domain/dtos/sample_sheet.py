from json import loads
import re
from io import StringIO
from pathlib import Path
from typing import Any, Self

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from attrs import define, field
from pandas import Series as PandasSeries
from pandas import read_csv
from pandera import DataFrameModel, Field
from pandera.typing import Series

from mdv.settings import LOGGER


class SampleSheetDataAsFrame(DataFrameModel):
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    sample_id: Series[str] = Field(alias="Sample_ID")
    description: Series[str] = Field(alias="Description")
    i7_index_id: Series[str] = Field(alias="I7_Index_ID")
    index: Series[str] = Field(alias="index")
    i5_index_id: Series[str] = Field(alias="I5_Index_ID")
    index2: Series[str] = Field(alias="index2")
    sample_project: Series[str] = Field(alias="Sample_Project")
    target: Series[str] = Field(alias="Target")


@define(kw_only=True)
class SampleSheetDescriptionLine:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    sample: str = field()
    target: str = field()
    isolate: bool = field()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "sample": self.sample,
            "target": self.target,
            "isolate": self.isolate,
        }

    # ? ------------------------------------------------------------------------
    # ? PUBLIC CLASS METHODS
    # ? ------------------------------------------------------------------------

    @classmethod
    def from_dict(
        cld,
        dict_line: dict[str, Any],
    ) -> Either[bio_exc.MappedErrors, Self]:
        if (sample := dict_line.get("sample")) is None:
            return bio_exc.CreationError(
                f"Description line {dict_line} has not sample key",
                logger=LOGGER,
            )()

        if (target := dict_line.get("target")) is None:
            return bio_exc.CreationError(
                f"Description line {dict_line} has not target key",
                logger=LOGGER,
            )()

        if (isolate := dict_line.get("isolate")) is None:
            return bio_exc.CreationError(
                f"Description line {dict_line} has not isolage key",
                logger=LOGGER,
            )()

        return right(
            cld(
                sample=sample,
                target=target,
                isolate=loads(isolate.lower()),
            )
        )


@define(kw_only=True)
class SampleSheetData:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    sample_id: str = field()
    description: SampleSheetDescriptionLine = field()
    i7_index_id: str = field()
    index: str = field()
    i5_index_id: str = field()
    index2: str = field()
    sample_project: str = field()
    target: str = field()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "sample_id": self.sample_id,
            "description": self.description.to_dict(),
            "i7_index_id": self.i7_index_id,
            "index": self.index,
            "i5_index_id": self.i5_index_id,
            "index2": self.index2,
            "sample_project": self.sample_project,
            "target": self.target,
        }

    # ? ------------------------------------------------------------------------
    # ? PUBLIC CLASS METHODS
    # ? ------------------------------------------------------------------------

    @classmethod
    def from_sample_sheet_data_frame_row(
        cld,
        data_frame: PandasSeries,
    ) -> Either[bio_exc.MappedErrors, Self]:
        description_raw = data_frame.get(SampleSheetDataAsFrame.description)

        if description_raw is not None:
            if (
                description := cld.parse_biotrop_description_line(
                    description_raw
                )
            ).is_left:
                return description

            if (
                description := SampleSheetDescriptionLine.from_dict(
                    description.value
                )
            ).is_left:
                return description

        return right(
            cld(
                sample_id=data_frame.get(SampleSheetDataAsFrame.sample_id),
                description=description.value,
                i7_index_id=data_frame.get(SampleSheetDataAsFrame.i7_index_id),
                index=data_frame.get(SampleSheetDataAsFrame.index),
                i5_index_id=data_frame.get(SampleSheetDataAsFrame.i5_index_id),
                index2=data_frame.get(SampleSheetDataAsFrame.index2),
                sample_project=data_frame.get(
                    SampleSheetDataAsFrame.sample_project
                ),
                target=data_frame.get(SampleSheetDataAsFrame.target),
            )
        )

    @staticmethod
    def parse_biotrop_description_line(
        line: str,
    ) -> Either[bio_exc.MappedErrors, dict[str, Any]]:
        dict_line: dict[str, Any] = {}

        first_level_splitted_line = [i for i in line.split("@") if i]

        if first_level_splitted_line.__len__() == 0:
            return bio_exc.CreationError(
                f"Description line {line} has not description keys",
                logger=LOGGER,
            )()

        for part in first_level_splitted_line:
            second_level_splitted_line = [i for i in part.split("#") if i]

            if second_level_splitted_line.__len__() != 2:
                return bio_exc.CreationError(
                    f"Description line {line} key has not valid content",
                    logger=LOGGER,
                )()

            attr_key, attr_value = second_level_splitted_line
            dict_line.update({attr_key: attr_value})

        return right(dict_line)


@define(kw_only=True)
class SampleSheetHeader:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    experiment_name: str = field(alias="Experiment_Name")
    date: str = field(alias="Date")
    workflow: str = field(alias="Workflow")
    module: str = field(alias="Module")
    chemistry: str = field(alias="Chemistry")
    index_kit: str = field(alias="Index_Kit")
    library_prep_kit: str = field(alias="Library_Prep_Kit")
    description: str = field(alias="Description")

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "experiment_name": self.experiment_name,
            "date": self.date,
            "workflow": self.workflow,
            "module": self.module,
            "chemistry": self.chemistry,
            "index_kit": self.index_kit,
            "library_prep_kit": self.library_prep_kit,
            "description": self.description,
        }


@define(kw_only=True)
class SampleSheetReads:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    forward_size: int = field()
    reverse_size: int = field()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "forward_size": self.forward_size,
            "reverse_size": self.reverse_size,
        }


@define(kw_only=True)
class SampleSheetSettings:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    adapter: str = field(alias="adapter")

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {"adapter": self.adapter}


@define(kw_only=True)
class SampleSheet:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    header: SampleSheetHeader = field()
    reads: SampleSheetReads = field()
    settings: SampleSheetSettings = field()
    data: list[SampleSheetData] = field()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "header": self.header.to_dict(),
            "reads": self.reads.to_dict(),
            "settings": self.settings.to_dict(),
            "data": [sample.to_dict() for sample in self.data],
        }

    # ? ------------------------------------------------------------------------
    # ? PUBLIC CLASS METHODS
    # ? ------------------------------------------------------------------------

    @classmethod
    def from_tabular_samplesheet(
        cls, file_path: Path
    ) -> Either[bio_exc.MappedErrors, Self]:
        """Reads a sample sheet file and returns a pandas DataFrame.

        Args:
            file_path (str): The path to the sample sheet file.

        Returns:
            DataFrame: A pandas DataFrame with the sample sheet data.

        """

        if not file_path.is_file():
            return bio_exc.CreationError(
                f"File {file_path} not found.",
                logger=LOGGER,
            )

        reading_stage: str | None = None

        header_content: dict[str, Any] = {}
        reads_content: list[str] = []
        settings_content: dict[str, Any] = {}
        data_content: list[str] = []
        data_content_as_object: list[SampleSheetData] = []

        with file_path.open("r") as file:
            while line := file.readline():
                (
                    matching_section,
                    is_section_header,
                ) = cls.__matching_section(line)

                if is_section_header:
                    reading_stage = matching_section
                    continue

                if reading_stage == "header":
                    if (
                        parsed_line := cls.__process_key_value_row(line)
                    ).is_left:
                        return parsed_line

                    header_content.update(parsed_line.value)
                    continue

                if reading_stage == "reads":
                    reads_content.append(line.split(",")[0].strip())
                    continue

                if reading_stage == "settings":
                    if (
                        parsed_line := cls.__process_key_value_row(line)
                    ).is_left:
                        return parsed_line

                    settings_content.update(parsed_line.value)
                    continue

                if reading_stage == "data":
                    data_content.append(line)
                    continue

        try:
            data_content_as_df = SampleSheetDataAsFrame.validate(
                read_csv(StringIO("".join(data_content)), sep=",")
            )
        except Exception as exc:
            return bio_exc.CreationError(
                f"Error while parsing data section: {exc}",
                logger=LOGGER,
            )()

        for _, row in data_content_as_df.iterrows():
            if (
                parsed_row := SampleSheetData.from_sample_sheet_data_frame_row(
                    row
                )
            ).is_left:
                return parsed_row
            data_content_as_object.append(parsed_row.value)

        return right(
            cls(
                header=SampleSheetHeader(**header_content),
                reads=SampleSheetReads(
                    forward_size=int(reads_content[0]),
                    reverse_size=int(reads_content[1]),
                ),
                settings=SampleSheetSettings(**settings_content),
                data=data_content_as_object,
            )
        )

    # ? ------------------------------------------------------------------------
    # ? PRIVATE STATIC METHODS
    # ? ------------------------------------------------------------------------

    @staticmethod
    def __matching_section(line: str) -> (str | None, bool):
        """Returns the section name and if the line is a section header.

        Args:
            line (str): The line to be checked.

        Returns:
            (str, bool): The section name and if the line is a section header.

        """

        if (match := re.search(r"^\[(.*)\]", line)) is not None:
            return match.group(1).lower(), True
        return None, False

    @staticmethod
    def __process_key_value_row(
        row: str,
    ) -> Either[bio_exc.MappedErrors, dict[str, Any]]:
        stripped_row = [item.strip() for item in row.split(",") if item.strip()]

        if stripped_row.__len__() != 2:
            return bio_exc.CreationError(
                f"Row {row} is not a valid key-value row.",
                logger=LOGGER,
            )()

        key, value = stripped_row

        return right({key.replace(" ", "_"): value})
