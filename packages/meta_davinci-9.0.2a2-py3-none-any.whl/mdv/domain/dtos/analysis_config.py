from __future__ import annotations

from datetime import datetime
from enum import Enum
from json import loads
from pathlib import Path
from typing import Any, Callable
from uuid import uuid4

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from agrobase.enums import TaxaEnum
from attrs import define, field, validators
from pandas import DataFrame, read_csv
from pandera.errors import SchemaError

from mdv.domain.dtos import BlastReferenceDatabase
from mdv.domain.dtos.bootstrap_handler import (
    BasicBootstrapHandlerSchema,
    MetadataColNamesEnum,
)
from mdv.domain.exceptions import InvalidQiimeMetadataException
from mdv.settings import LOGGER


def build_default_set_name() -> tuple[Callable[..., str], str]:
    """Create a default sample name for `SampleSetDTO` class.

    Returns:
        str: A default string as a default sample name.
    """

    def get_validation_string() -> str:
        """Build the regex pattern to validate the sample name here generated.

        Returns:
            str: The regex pattern to validate the set name.
        """

        date_regex = "^20[0-9]{2}[0-1][0-9][0-3][0-9]"
        time_regex = "[0-1][0-9][0-6][0-9][0-6][0-9]"
        uuid_suffix = "[0-9a-zA-Z]{8}"

        return rf"{date_regex}-{time_regex}-{uuid_suffix}"

    return (
        get_validation_string,
        datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + str(uuid4().hex)[:8],
    )


def is_not_none(_: Any, attribute: Any, value: Any) -> None:
    """_summary_

    Args:
        _ (_type_): The object instance to be checked.
        attribute (_type_): The field attribute to be tested.
        value (_type_): The field value.

    Raises:
        ValueError: If the attribute value is `None` or `""`.
    """

    if any(
        [
            value == "",
            value is None,
        ]
    ):
        raise ValueError(f"`{attribute.name}` field could not be empty.")


class FastqDirectionEnum(Enum):
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    FORWARD = "1"
    REVERSE = "2"


class SequencingTemplateEnum(Enum):
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    SINGLE_END = "se"
    PAIRED_END = "pe"

    # ? ------------------------------------------------------------------------
    # ? Public methods
    # ? ------------------------------------------------------------------------

    @classmethod
    def get_values_list(cls) -> list[str]:
        return [i.value for i in cls]


@define
class FastqFiles:
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    template: SequencingTemplateEnum = field()
    forward_file: Path = field()
    reverse_file: Path = field()

    # ? ------------------------------------------------------------------------
    # ? Public methods
    # ? ------------------------------------------------------------------------

    def as_dict(
        self,
    ) -> dict[str, Any]:
        return {
            "template": self.template.value,
            "forward_file": self.forward_file,
            "reverse_file": self.reverse_file,
        }

    @classmethod
    def from_dict(
        cls,
        dict_content: dict[str, Any],
    ) -> Either[bio_exc.CreationError, FastqFiles]:
        required_keys = [
            "template",
            "forward_file",
            "reverse_file",
        ]

        try:
            for key in required_keys:
                if key not in dict_content:
                    return bio_exc.CreationError(
                        f"Required key empty in config JSON: `{key}`",
                        logger=LOGGER,
                    )()

            sample_fastqs = FastqFiles(
                template=SequencingTemplateEnum(dict_content.get("template")),
                forward_file=Path(dict_content.get("forward_file")),  # type: ignore
                reverse_file=Path(dict_content.get("reverse_file")),  # type: ignore
            )

            return right(sample_fastqs)

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()

    @template.validator
    def validate_files_from_template(
        self,
        _: Any,
        value: SequencingTemplateEnum,
    ) -> None:
        if all(
            [
                value == SequencingTemplateEnum.PAIRED_END,
                self.reverse_file is None,
            ]
        ):
            raise ValueError(
                "`reverse_file` could not be empty if `template` is `pe`."
            )

        if all(
            [
                value == SequencingTemplateEnum.SINGLE_END,
                self.reverse_file is not None,
            ]
        ):
            raise ValueError(
                "`reverse_file` should be empty if `template` is `se`."
            )


@define
class SampleConfig:
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    name: str
    files: FastqFiles
    blast_database: BlastReferenceDatabase
    recovery_single_end: bool = field(default=False)
    service_order: str | None = field(default=None)
    sample_is_complex: bool = field(default=True)

    # ? ------------------------------------------------------------------------
    # ? Public methods
    # ? ------------------------------------------------------------------------

    def as_dict(
        self,
    ) -> dict[str, Any]:
        return {
            "name": self.name,
            "files": self.files.as_dict(),
            "blast_database": self.blast_database.as_dict(),
            "recovery_single_end": self.recovery_single_end,
            "service_order": self.service_order,
            "sample_is_complex": self.sample_is_complex,
        }

    @classmethod
    def from_dict(
        cls,
        dict_content: dict[str, Any],
    ) -> Either[bio_exc.CreationError, SampleConfig]:
        required_keys: list[str] = [
            "name",
            "files",
            "blast_database",
        ]

        try:
            # ? Validate keys
            for key in required_keys:
                if key not in dict_content:
                    return bio_exc.CreationError(
                        f"Required key empty in config JSON: `{key}`",
                        logger=LOGGER,
                    )()

            # ? Load `SampleFastqFilesDTO` object
            sample_fastqs_either = FastqFiles.from_dict(
                dict_content=dict_content.get("files")  # type: ignore
            )

            if sample_fastqs_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create `SampleFastqFilesDTO`.",
                    prev=sample_fastqs_either.value,
                    logger=LOGGER,
                )()

            sample_fastqs: FastqFiles = sample_fastqs_either.value  # type: ignore

            # ? Load `BlastReferenceDatabase` object
            blast_database_either = BlastReferenceDatabase.from_dict(
                dict_content=dict_content.get("blast_database")  # type: ignore
            )

            if blast_database_either.is_left:
                return bio_exc.CreationError(
                    "Unexpected error detected on create `BlastReferenceDatabase`.",
                    prev=blast_database_either.value,
                    logger=LOGGER,
                )()

            if (
                sample_is_complex := dict_content.get("sample_is_complex")
            ) is None:
                sample_is_complex = True

            blast_database: BlastReferenceDatabase = blast_database_either.value  # type: ignore

            # ? Load `SampleSpecsDTO` object
            sample_spec = SampleConfig(
                name=dict_content.get("name"),  # type: ignore
                files=sample_fastqs,
                blast_database=blast_database,
                recovery_single_end=dict_content.get(
                    "recovery_single_end",
                    False,
                ),
                service_order=dict_content.get(
                    "service_order",
                ),
                sample_is_complex=sample_is_complex,
            )

            return right(sample_spec)

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()


@define
class AnalysisConfig:
    # ? ------------------------------------------------------------------------
    # ? Attribute definitions
    # ? ------------------------------------------------------------------------

    customer: str = field(
        validator=[
            validators.instance_of(str),
            is_not_none,
        ]
    )

    assay: str = field()
    taxa: TaxaEnum = field()
    source_directory: Path = field()
    metadata_artifact: Path = field()
    metadata_content: DataFrame | None = field(default=None)
    set_name: str = field()
    samples: list[SampleConfig] = field(default=[])
    legacy: bool = field(default=False)

    # ? ------------------------------------------------------------------------
    # ? Attribute validators
    # ? ------------------------------------------------------------------------

    @set_name.default
    def _build_set_name(self) -> str:
        _, set_name = build_default_set_name()
        return set_name

    @metadata_artifact.validator
    def _check_artifact_content(
        self,
        _: Any,
        value: str,
    ) -> None:
        """if not self.source_directory.joinpath(value).is_file():
        raise ValueError("`metadata_artifact` should exists.")"""

        if not Path(value).suffix == ".tsv":
            raise ValueError("`metadata_artifact` should be a TSV file.")

        try:
            self.validate_metadata_file_content(
                metadata_file=self.source_directory.joinpath(value),
                samples=self.samples,
            )
        except InvalidQiimeMetadataException as exc:
            try:
                df = read_csv(self.source_directory.joinpath(value), sep="\t")
                df[MetadataColNamesEnum.SINGLE_END_RECOVERY.value].fillna(
                    False,
                    inplace=True,
                )

                BasicBootstrapHandlerSchema.validate(df)

                return
            except SchemaError as exc:
                raise exc
        except Exception as exc:
            raise ValueError(
                f"Unexpected error on validate metadata file content: {exc}"
            ) from exc

    # ? ------------------------------------------------------------------------
    # ? Public instance methods
    # ? ------------------------------------------------------------------------

    def as_dict(
        self,
    ) -> dict[str, Any]:
        return {
            "customer": self.customer,
            "assay": self.assay,
            "taxa": self.taxa.value,
            "metadata_artifact": self.metadata_artifact,
            "metadata_content": (
                self.metadata_content.to_dict(orient="records")
                if self.metadata_content is not None
                else None
            ),
            "source_directory": self.source_directory,
            "set_name": self.set_name,
            "legacy": self.legacy,
            "samples": [sample.as_dict() for sample in self.samples],
        }

    # ? ------------------------------------------------------------------------
    # ? Public class methods
    # ? ------------------------------------------------------------------------

    @classmethod
    def from_json(
        cls,
        config_file_path: Path,
        source_directory: Path | None = None,
    ) -> Either[bio_exc.CreationError, AnalysisConfig]:
        required_keys = [
            "customer",
            "assay",
            "taxa",
            "metadata_artifact",
            "source_directory",
            "set_name",
            "samples",
            "legacy",
        ]

        try:
            if not isinstance(config_file_path, Path):
                return bio_exc.CreationError(
                    "`config_file_path` should be a `Path` instance.",
                    exp=True,
                    logger=LOGGER,
                )()

            if not config_file_path.is_file():
                return bio_exc.CreationError(
                    "`config_file_path` does not exists.",
                    exp=True,
                    logger=LOGGER,
                )()

            config_content = None
            with config_file_path.open() as config_file:
                config_content = loads(config_file.read())

            for key in required_keys:
                if key not in config_content:
                    return bio_exc.CreationError(
                        f"Required key empty in config JSON: `{key}`",
                        logger=LOGGER,
                    )()

            samples_dtos: list[SampleConfig] = []
            for sample in config_content.get("samples"):
                sample_specs = SampleConfig.from_dict(sample)

                if sample_specs.is_left:
                    return bio_exc.CreationError(
                        "Unexpected error detected on load `SampleSpecsDTO`.",
                        prev=sample_specs.value,
                        logger=LOGGER,
                    )()

                samples_dtos.append(sample_specs.value)  # type: ignore

            if (
                metadata_artifact := config_content.get("metadata_artifact")
            ) is None:
                return bio_exc.CreationError(
                    "`metadata_artifact` field could not be empty.",
                    logger=LOGGER,
                )()

            metadata_artifact = Path(metadata_artifact)

            if source_directory is not None:
                metadata_artifact = source_directory.joinpath(
                    metadata_artifact.name
                )

                if not metadata_artifact.is_file():
                    return bio_exc.CreationError(
                        f"`{metadata_artifact}` should exists.",
                        logger=LOGGER,
                    )()

            if (content := config_content.get("metadata_content")) is not None:
                metadata_content = cls.__load_metadata_content(content)
            else:
                content = read_csv(metadata_artifact, sep="\t").to_dict()
                metadata_content = cls.__load_metadata_content(content)

            return right(
                cls(
                    set_name=str(config_file_path.parent),
                    customer=config_content.get("customer"),
                    assay=config_content.get("assay"),
                    taxa=TaxaEnum(config_content.get("taxa")),
                    metadata_artifact=metadata_artifact,
                    metadata_content=metadata_content,
                    source_directory=(
                        source_directory
                        if source_directory is not None
                        else Path(config_content.get("source_directory"))
                    ),
                    samples=samples_dtos,
                    legacy=config_content.get("legacy"),
                )
            )

        except Exception as exc:
            return bio_exc.CreationError(exc, logger=LOGGER)()

    @classmethod
    def validate_metadata_file_content(
        cls,
        metadata_file: Path,
        samples: list[SampleConfig] = [],
    ) -> DataFrame:
        """Validate the metadata file content.

        Args:
            metadata_file (Path): The metadata file path.
            samples (list[SampleSpecsDTO], optional): The samples list.
                Defaults to [].

        Raises:
            InvalidMetadataException: If the metadata file is not a TSV file.
            InvalidMetadataException: If the metadata file does not contains the
                validation string.
            InvalidMetadataException: If the metadata file contains a sample id
                that does not exists in `samples` list attribute.

        """

        types_row = "#q2:types"
        metadata_df = read_csv(metadata_file, sep="\t")
        sample_names = [i.name for i in samples]
        metadata_samples: list[str] = []

        for index, row in metadata_df.iterrows():
            sample_id = row.get("sample-id")

            if index == 0:
                if sample_id != types_row:
                    raise InvalidQiimeMetadataException(
                        "The first line of the metadata table should contains"
                        + f"the validation string: `{types_row}`."
                    )
                continue

            if len(samples) == 0:
                break

            if sample_id not in sample_names:
                raise InvalidQiimeMetadataException(
                    "All sample ids in metadata file could exists in `samples` "
                    + f"list attribute. The sample {sample_id} was not found."
                )

            metadata_samples.append(sample_id)

        if len(metadata_samples) != len(samples):
            raise InvalidQiimeMetadataException(
                "The number of samples in metadata table differs from samples "
                + "informed in samples attribute:\n"
                + f"Metadata samples: {len(metadata_samples)}\n"
                + f"Object sample list: {len(samples)}\n"
            )

        return metadata_df

    # ? ------------------------------------------------------------------------
    # ? Private class methods
    # ? ------------------------------------------------------------------------

    @classmethod
    def __load_metadata_content(
        cls,
        metadata_dict_content: dict[str, Any],
    ) -> DataFrame:
        metadata_content = DataFrame.from_dict(metadata_dict_content)

        if (
            MetadataColNamesEnum.SINGLE_END_RECOVERY.value
            in metadata_content.columns
        ):
            metadata_content[
                MetadataColNamesEnum.SINGLE_END_RECOVERY.value
            ].fillna(
                value=False,
                inplace=True,
            )

        return metadata_content
