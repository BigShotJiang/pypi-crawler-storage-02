from pathlib import Path
from attrs import define, field

from mdv.domain.dtos.sample_sheet import (
    SampleSheetData,
    SampleSheetHeader,
    SampleSheetReads,
    SampleSheetSettings,
)


@define(kw_only=True)
class IndexingTags:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    sample_id: str = field()
    country: str = field()
    state_province: str = field()
    amplicon: str = field()
    sample_project: str = field()
    strand: str = field()
    isolate: bool = field()
    sequencing_year: str = field()
    matrix: str = field()
    crop: str | None = field()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, str]:
        return {
            "sample_id": self.sample_id,
            "country": self.country,
            "state_province": self.state_province,
            "amplicon": self.amplicon,
            "sample_project": self.sample_project,
            "strand": self.strand,
            "isolate": self.isolate.__str__().lower(),
            "sequencing_year": str(self.sequencing_year),
            "crop": self.crop,
            "matrix": self.matrix,
        }


@define(kw_only=True)
class SequencingMetadata:
    sample_sheet_data: SampleSheetData = field()
    sample_sheet_header: SampleSheetHeader = field()
    sample_sheet_reads: SampleSheetReads = field()
    sample_sheet_settings: SampleSheetSettings = field()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, str]:
        return {
            "sample_sheet_data": self.sample_sheet_data.to_dict(),
            "sample_sheet_header": self.sample_sheet_header.to_dict(),
            "sample_sheet_reads": self.sample_sheet_reads.to_dict(),
            "sample_sheet_settings": self.sample_sheet_settings.to_dict(),
        }


@define(kw_only=True)
class RawLibraryBlobArtifact:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    file: Path = field()
    indexing_tags: IndexingTags = field()
    sequencing_metadata: SequencingMetadata = field()
    paired_end_qc_metadata: dict[str, str] = field()
    single_end_qc_metadata: dict[str, str] | None = field(default=None)
    extra_index_kv: dict[str, str] | None = field(default=None)
    extra_metadata_kv: dict[str, str] | None = field(default=None)

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def to_dict(self) -> dict[str, str]:
        return {
            "file": str(self.file),
            "indexing_tags": self.indexing_tags,
            "sequencing_metadata": self.sequencing_metadata.to_dict(),
            "paired_end_qc_metadata": self.paired_end_qc_metadata,
            "single_end_qc_metadata": self.single_end_qc_metadata,
            "extra_index_kv": self.extra_index_kv,
            "extra_metadata_kv": self.extra_metadata_kv,
        }
