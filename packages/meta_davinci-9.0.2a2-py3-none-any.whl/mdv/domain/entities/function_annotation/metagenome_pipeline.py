from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class MetagenomePipeline(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory_freq_table: Path,
        source_directory_hsp_marker: Path,
        source_directory_hsp_function: Path,
        input_frequency_table: str,
        input_function_table: str,
        input_marker_table: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
