from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class RunFullPipelineStep(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_fasta_sequences: str,
        input_frequency_table: str,
        work_directory: Path,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
