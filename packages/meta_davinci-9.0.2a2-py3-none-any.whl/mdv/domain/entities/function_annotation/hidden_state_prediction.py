from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.enums import TaxaEnum
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class HiddenStatePredictionStep(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_tree: str,
        output_prediction: str,
        work_directory: Path,
        taxa: TaxaEnum,
        is_ec: bool,
        **_: Any,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
