from pathlib import Path

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class TaxonomyPickingWithBioLinnaeus(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        databases_source_directory: Path,
        input_repr_seqs_artifact: str,
        reference_reads: str,
        reference_taxonomy: str,
        output_classification: str,
        work_directory: Path,
        max_target_seqs: float = 10,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
