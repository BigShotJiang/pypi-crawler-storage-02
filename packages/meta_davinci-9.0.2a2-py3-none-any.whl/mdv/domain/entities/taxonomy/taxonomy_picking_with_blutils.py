from pathlib import Path

from agrobase.enums import TaxaEnum
from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class TaxonomyPickingWithBlutils(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        databases_source_directory: Path,
        input_repr_seqs_artifact: str,
        reference_reads: str,
        reference_taxonomy: str,
        output_classification: str,
        work_directory: Path,
        max_target_seqs: float = 10,
        word_size: int = 18,
        taxon: TaxaEnum | None = None,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
