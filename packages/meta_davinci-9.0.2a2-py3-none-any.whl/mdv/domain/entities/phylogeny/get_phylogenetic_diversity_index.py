from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class CalculatePhylogeneticDiversityIndexes(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_taxonomy_directory: Path,
        input_phylogeny_directory: Path,
        input_taxonomy_artifact: str,
        input_phylogeny_artifact: str,
        output_path: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
