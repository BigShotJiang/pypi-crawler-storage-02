from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class FilterResults(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_freq_table_artifact: str,
        input_blast_results_artifact: str,
        output_filtered_table_artifact: str,
        work_directory: Path,
        filtering_term: str = "d__Bacteria,d__Eukaryota",
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
