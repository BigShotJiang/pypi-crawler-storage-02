from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class AlignAndGeneratePhylogeny(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        input_repr_seqs_artifact: str,
        output_raw_alignment: str,
        output_masked_alignment: str,
        output_unrooted_tree: str,
        output_rooted_tree: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
