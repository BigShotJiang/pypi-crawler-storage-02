from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class RarefyDiversityResults(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_taxonomy_directory: Path,
        input_phylogeny_directory: Path,
        input_metadata_directory: Path,
        input_taxonomy_artifact: str,
        input_phylogeny_artifact: str,
        input_metadata_artifact: str,
        output_rarefaction_artifact: str,
        max_depth: int,
        work_directory: Path,
        min_depth: int = 1,
        steps: int = 10,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
