from typing import Any

from agrobase.either import Either
from agrobase.entities import (
    CreateManyResponse,
    CreateResponse,
    GetOrCreateResponse,
    Registration,
)
from agrobase.exceptions import CreationError

from mdv.domain.dtos.analysis_blob_artifact import AnalysisBlobArtifact


class AnalysisBlobRegistration(Registration):
    """The StorageBlobRegistration entity."""

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOK METHODS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(cls) -> None:
        super().__init_subclass__()

    # ? ------------------------------------------------------------------------
    # ? ABSTRACT METHODS DEFINITIONS
    # ? ------------------------------------------------------------------------

    def create(
        self,
        blob: AnalysisBlobArtifact,
        connection_string: str,
    ) -> Either[CreationError, CreateResponse[AnalysisBlobArtifact]]:
        raise NotImplementedError

    def create_many(
        self,
        **kwargs: Any,  # type: ignore
    ) -> Either[CreationError, CreateManyResponse[AnalysisBlobArtifact]]:
        raise NotImplementedError

    def get_or_create(
        self,
        **kwargs: Any,  # type: ignore
    ) -> Either[CreationError, GetOrCreateResponse[AnalysisBlobArtifact]]:
        raise NotImplementedError
