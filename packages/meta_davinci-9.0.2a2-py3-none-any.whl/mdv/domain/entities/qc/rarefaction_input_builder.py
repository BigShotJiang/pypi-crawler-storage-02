from pathlib import Path

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import (
    DefaultStepParams,
    Step,
    StepResponse,
)


class SingleSampleRarefactionInputBuildStep(Step):
    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # work_directory: Path,
        # source_directory: Path,
        input_chimera_free: Path,
        output_otu_table: str,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
