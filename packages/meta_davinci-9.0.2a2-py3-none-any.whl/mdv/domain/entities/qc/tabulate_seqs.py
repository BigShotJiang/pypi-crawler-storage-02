from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import (
    DefaultStepParams,
    Step,
    StepResponse,
)


class TabulateRepresentativeSeqsStep(Step):
    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # work_directory: Path,
        # source_directory: Path,
        input_repr_seqs_artifact: str,
        output_repr_seqs: str,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
