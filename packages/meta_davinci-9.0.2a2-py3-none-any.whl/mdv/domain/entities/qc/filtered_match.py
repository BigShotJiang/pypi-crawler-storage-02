from pathlib import Path

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class FilteredMatchStep(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory_filtered: Path,
        source_directory_raw: Path,
        input_filtered_fastq: Path,
        input_complement_fastq: Path,
        output_forward_fastq: str,
        output_matching_files: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
