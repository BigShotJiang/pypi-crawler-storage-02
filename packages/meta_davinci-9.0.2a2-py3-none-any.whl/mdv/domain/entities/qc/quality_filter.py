from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import (
    DefaultStepParams,
    Step,
    StepResponse,
)


class QualityFilterStep(Step):
    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # work_directory: Path,
        # source_directory: Path,
        input_merged: Path,
        output_filtered_artifact: str,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
