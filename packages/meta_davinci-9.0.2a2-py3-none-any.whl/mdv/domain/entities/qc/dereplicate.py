from enum import Enum
from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import (
    DefaultStepParams,
    Step,
    StepResponse,
)


class DerepStrategyEnum(Enum):
    FULL_LENGTH = "derep_fulllength"
    PREFIX = "derep_prefix"

    @classmethod
    def _missing_(cls, _: object) -> Any:
        return cls.PREFIX


class DereplicateStep(Step):
    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # work_directory: Path,
        # source_directory: Path,
        input_filtered: Path,
        output_dereplicated_artifact: str,
        min_cluster_size: int = 2,
        derep_strategy: DerepStrategyEnum | None = None,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
