from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import (
    DefaultStepParams,
    Step,
    StepResponse,
)


class TrimmingStep(Step):
    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # work_directory: Path,
        # source_directory: Path,
        input_forward_file_path: Path,
        input_reverse_file_path: Path,
        output_forward_paired_artifact: str,
        output_forward_unpaired_artifact: str,
        output_reverse_paired_artifact: str,
        output_reverse_unpaired_artifact: str,
        head_crop: int,
        leading_quality: int,
        trailing_quality: int,
        end_crop: int,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
