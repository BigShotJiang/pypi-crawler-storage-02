from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import (
    DefaultStepParams,
    Step,
    StepResponse,
)


class SummarizeFeatureTableStep(Step):
    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # work_directory: Path,
        # source_directory: Path,
        input_source_directory: Path,
        input_metadata_directory: Path,
        input_table_artifact: str,
        input_feature_metadata: str,
        output_feature_table: str,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
