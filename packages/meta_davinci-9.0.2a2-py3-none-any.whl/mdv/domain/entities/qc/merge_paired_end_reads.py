from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import (
    DefaultStepParams,
    Step,
    StepResponse,
)


class MergePairsStep(Step):
    def execute(  # type: ignore[override]
        self,
        params: DefaultStepParams,
        # group: str,
        # destination_directory: str,
        # work_directory: Path,
        # source_directory: Path,
        input_trimmed_forward: Path,
        input_trimmed_reverse: Path,
        output_merged_artifact: str,
        output_not_merged_fwd_artifact: str,
        output_not_merged_rev_artifact: str,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
