from typing import Any

from agrobase.either import Either
from agrobase.entities import (
    CreateManyResponse,
    CreateResponse,
    GetOrCreateResponse,
    Registration,
)
from agrobase.exceptions import CreationError

from mdv.domain.dtos.raw_library_blob_artifact import RawLibraryBlobArtifact


class RawLibraryBlobRegistration(Registration):
    """The StorageBlobRegistration entity."""

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOK METHODS
    # ? ------------------------------------------------------------------------

    def __init_subclass__(cls) -> None:
        super().__init_subclass__()

    # ? ------------------------------------------------------------------------
    # ? ABSTRACT METHODS DEFINITIONS
    # ? ------------------------------------------------------------------------

    def create(
        self,
        blob: RawLibraryBlobArtifact,
        connection_string: str,
    ) -> Either[CreationError, CreateResponse[RawLibraryBlobArtifact]]:
        raise NotImplementedError

    def create_many(
        self,
        **kwargs: Any,  # type: ignore
    ) -> Either[CreationError, CreateManyResponse[RawLibraryBlobArtifact]]:
        raise NotImplementedError

    def get_or_create(
        self,
        **kwargs: Any,  # type: ignore
    ) -> Either[CreationError, GetOrCreateResponse[RawLibraryBlobArtifact]]:
        raise NotImplementedError
