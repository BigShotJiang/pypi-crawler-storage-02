from pathlib import Path
from typing import Any

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class ExportArtifact(Step):
    def execute(  # type: ignore[override]
        self,
        destination_directory: str,
        source_directory: Path,
        input_artifact: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
