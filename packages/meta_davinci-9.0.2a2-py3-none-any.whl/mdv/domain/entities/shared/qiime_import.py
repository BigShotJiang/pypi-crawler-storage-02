from pathlib import Path

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class ImportRawFastaReads(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        input_source_directory: Path,
        input_sequences: Path,
        output_artifact: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()


class ImportFromTSVFeatureTable(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_file: Path,
        output_artifact_name: str,
        work_directory: Path,
        skip_lock_file: bool = False,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()


class ImportFeatureTable(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_file: Path,
        output_artifact_name: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()


class ImportBlastOutput(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        destination_directory: str,
        source_directory: Path,
        input_file: Path,
        output_artifact_name: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
