from pathlib import Path

from agrobase.either import Either
from agrobase.exceptions import ExecutionError

from mdv.domain.entities.step_execution import Step, StepResponse


class RawDataSummarizeStep(Step):
    def execute(  # type: ignore[override]
        self,
        group: str,
        source_directory: Path,
        input_artifact_name: str,
        output_artifact_name: str,
        work_directory: Path,
    ) -> Either[ExecutionError, StepResponse]:
        return NotImplementedError()
