from abc import ABCMeta, abstractmethod
from pathlib import Path
from typing import Any, Literal, NamedTuple, NoReturn, Union

from agrobase.either import Either
from agrobase.exceptions import ExecutionError
from attrs import frozen, field


class StepResponse(NamedTuple):
    """A interface for execution response."""

    executed: bool
    instance: Union[NoReturn, Any]


@frozen
class DefaultStepParams:
    group: str = field()
    work_directory: Path = field()
    destination_directory: str = field()
    source_directory: Path | None = field(default=None)

    @source_directory.validator
    def _check_source_directory(
        self,
        _: Any,
        value: Path | None,
    ) -> None:
        if value is None:
            return

        if not value.is_dir():
            raise ValueError(
                f"source_directory must be a valid directory, got {value}"
            )


class Step(metaclass=ABCMeta):
    """The execution abstract class."""

    # --------------------------------------------------------------------------
    # ABSTRACT METHODS
    # --------------------------------------------------------------------------

    @abstractmethod
    def _execute(
        self,
        **kwargs: Any,
    ) -> Either[ExecutionError, StepResponse]:
        raise NotImplementedError()

    @abstractmethod
    def execute(
        self,
        params: DefaultStepParams,
        **kwargs: Any,
    ) -> Either[ExecutionError, StepResponse]:
        raise NotImplementedError()

    @abstractmethod
    def has_valid_inputs(
        self, **kwargs: Any
    ) -> Either[ExecutionError, Literal[True]]:
        raise NotImplementedError()

    @abstractmethod
    def has_valid_outputs(
        self, **kwargs: Any
    ) -> Either[ExecutionError, Literal[True]]:
        raise NotImplementedError()
