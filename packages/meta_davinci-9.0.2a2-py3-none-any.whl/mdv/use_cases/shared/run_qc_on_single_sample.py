from __future__ import annotations

import re
from asyncio import AbstractEventLoop, BaseEventLoop
from pathlib import Path
import shutil
from typing import Any, AsyncGenerator, Generator, Literal

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from aiofile import async_open
from attrs import define, field
from Bio import SeqIO

from mdv.domain.dtos import QualityControlArtifacts, StepDTO
from mdv.domain.entities.qc.dereplicate import DerepStrategyEnum
from mdv.domain.entities.step_execution import DefaultStepParams
from mdv.domain.utils import create_lock_file, has_lock_file
from mdv.settings import LOGGER, PRE_FILTERING_SAMPLE_SIZE
from mdv.use_cases.shared.core import (
    BaseInnerClasses,
    BaseOuterClass,
    CallableLifeCycleHooks,
    CallableOutput,
    OnExitResponse,
    OnInitResponse,
    SingleSamplePipelineResponse,
    SingleStepPipelineRepositories,
    StepOutput,
)


@define(kw_only=True)
class QcStepParams:
    # ? Pre-filtering arguments
    sample_size: int = field(default=PRE_FILTERING_SAMPLE_SIZE)

    # ? Trimming related params
    head_crop: int = field(default=13)
    leading_quality: int = field(default=1)
    trailing_quality: int = field(default=1)
    end_crop: int = field(default=1000)

    # ? Dereplication related params
    derep_strategy: DerepStrategyEnum = field(default=DerepStrategyEnum(None))
    min_cluster_size: int = field(default=2)

    # ? Global qc related params
    single_end_recovery_strategy: bool | None = field(default=None)

    def __attrs_post_init__(self) -> None:
        self.sample_size = self.sample_size or PRE_FILTERING_SAMPLE_SIZE
        self.head_crop = self.head_crop or 13
        self.leading_quality = self.leading_quality or 1
        self.trailing_quality = self.trailing_quality or 1
        self.end_crop = self.end_crop or 1000
        self.derep_strategy = self.derep_strategy or DerepStrategyEnum(None)
        self.min_cluster_size = self.min_cluster_size or 2
        self.single_end_recovery_strategy = (
            self.single_end_recovery_strategy
            if self.single_end_recovery_strategy is None
            else self.single_end_recovery_strategy
        )


class RunQualityControlOnSingleSample:
    """Perform quality control of a single sample."""

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        sample_code: str,
        forward_file_path: Path,
        reverse_file_path: Path,
        source_directory: Path,
        work_directory: Path,
        quality_control_artifacts: QualityControlArtifacts,
        repos: SingleStepPipelineRepositories,
        qc_params: QcStepParams,
        **_: Any,
    ) -> None:
        # ? Protected/Internal attributes
        self._sample_code: str = sample_code
        self._forward_file_path: Path = forward_file_path
        self._reverse_file_path: Path = reverse_file_path
        self._source_directory: Path = Path(source_directory)
        self._work_directory: Path = Path(work_directory)
        self._qc_artifacts: QualityControlArtifacts = quality_control_artifacts
        self._repos = repos

        # ? Trimming
        self._qc_params: QcStepParams = qc_params

        # ? Composite inner classes
        self._quality_control_steps = self.__QcSteps(outer=self)

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
        loop: BaseEventLoop | AbstractEventLoop,
    ) -> Either[bio_exc.UseCaseError, SingleSamplePipelineResponse]:
        """Execute the pipeline steps/methods in a sequential mode.

        Returns:
            Either[
                Left[bio_exc.MappedErrors], Right[SingleSamplePipelineResponse]
            ]:
                A `SingleSamplePipelineResponse` if all is done.
        """

        try:
            LOGGER.info(f"START TO PROCESSING THE SAMPLE: {self._sample_code}")
            steps: BaseInnerClasses = self._quality_control_steps
            step: CallableOutput

            for step in steps.generate_steps():  # type: ignore
                step_either = BaseOuterClass(logger=LOGGER).run_single_step(
                    group=self._qc_artifacts.folder,
                    destination_directory=(
                        f"{self._qc_artifacts.folder}/{step.step_artifacts.folder}"  # type: ignore
                    ),
                    step=step,
                    loop=loop,
                )

                if step_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on execute use case.",
                        prev=step_either.value,
                        logger=LOGGER,
                    )()

                if step_either.value is False:
                    return right(
                        SingleSamplePipelineResponse(
                            finished_execution=False,
                            execution_message=(
                                "Quality control execution finished prematurely. "
                                + "This behavioral could be due to hook "
                                + "(`on_init` or `on_exit`) validations that "
                                + "were not satisfied."
                            ),
                        )
                    )

            LOGGER.info(f"FINISH TO PROCESSING THE SAMPLE: {self._sample_code}")

            return right(SingleSamplePipelineResponse(finished_execution=True))

        except Exception as exc:
            return bio_exc.UseCaseError(
                "Unexpected error detected on execute quality control. "
                + f"The message error was `{exc}`",
                logger=LOGGER,
            )()

    # ? ------------------------------------------------------------------------
    # ? INNER CLASSES
    # ? ------------------------------------------------------------------------

    class __QcSteps(BaseInnerClasses):
        # ? --------------------------------------------------------------------
        # ? INNER CLASS LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __init__(
            self,
            outer: RunQualityControlOnSingleSample,
        ) -> None:
            # ? ----------------------------------------------------------------
            # ? TURN OUTER CLASS A INTERNAL ATTRIBUTE
            # ? ----------------------------------------------------------------

            self.__out = outer

            # ? ----------------------------------------------------------------
            # ? SETUP FINAL FORMATTING ATTRIBUTES
            # ? ----------------------------------------------------------------

            self.formatted_output_artifact = (
                f"{self.__out._sample_code}.formatted.fasta"
            )
            self.formatted_data_dir = None

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PUBLIC METHODS
        # ? --------------------------------------------------------------------

        def generate_steps(self) -> Generator[CallableOutput, None, None]:  # type: ignore
            return super().generate_steps(
                steps=[
                    CallableOutput(
                        step_callable=self.__pre_filter_raw_forward_reads,
                        step_artifacts=self.__out._qc_artifacts.forward_filtering,  # type: ignore
                    ),
                    CallableOutput(
                        step_callable=self.__match_filtered_reads,
                        step_artifacts=self.__out._qc_artifacts.filtering_matching,  # type: ignore
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_exit=self.__ehook_rename_filtered_reads,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__trim_paired_end_reads,
                        step_artifacts=self.__out._qc_artifacts.trimming,  # type: ignore
                    ),
                    CallableOutput(
                        step_callable=self.__merge_paired_end_reads,
                        step_artifacts=self.__out._qc_artifacts.merging,  # type: ignore
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_exit=self.__ehook_could_continue_qc,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__perform_quality_filtering,
                        step_artifacts=self.__out._qc_artifacts.quality_filtering,  # type: ignore
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_exit=self.__ehook_has_enough_filtered_sequences,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__dereplicate_contigs,
                        step_artifacts=self.__out._qc_artifacts.dereplication,  # type: ignore
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_exit=self.__ehook_has_enough_dereplicated_sequences,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__denoise,
                        step_artifacts=self.__out._qc_artifacts.denoise,  # type: ignore
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_exit=self.__ehook_has_enough_denoise_sequences,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__remove_chimera,
                        step_artifacts=self.__out._qc_artifacts.chimera_removal,  # type: ignore
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_exit=self.__ehook_polish_output_sequences,
                        ),
                    ),
                ]
            )

        # ? --------------------------------------------------------------------
        # ? INNER CLASS STEP LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __ehook_polish_output_sequences(
            self,
            loop: BaseEventLoop,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnExitResponse]:
            """Perform a final polish on output sequences."""

            async def parse_fasta_records(
                input_file_path: Path,
            ) -> AsyncGenerator[
                Either[bio_exc.UseCaseError, str | None],
                None,
            ]:
                """Parse FASTA file content as a generator.

                Args:
                    input_file_path (Path): The system file path of the file to
                        be parsed.

                Yields:
                    AsyncGenerator[
                        Either[Left[bio_exc.UseCaseError], Right[Union[str, None]]],
                        None,
                    ]:
                        A iterator containing the `Either` response. If response
                            is left, a mapped error. The FASTA string if all is
                            done.
                """

                try:
                    async with async_open(input_file_path) as fasta:
                        sequences = await fasta.read()
                        sequences = re.split(
                            "^>", sequences, flags=re.MULTILINE
                        )

                        del sequences[0]

                        for record in sequences:
                            header, sequence = record.split("\n", 1)
                            sequence = sequence.replace("\n", "").upper()
                            yield right(f">{header}\n{sequence}\n")

                        await fasta.close()

                    yield right(None)

                except Exception as exc:
                    yield bio_exc.UseCaseError(exc, logger=LOGGER)()

            async def format_output_fasta(
                input_fasta: Path,
                output_fasta: Path,
            ) -> Either[bio_exc.UseCaseError, Literal[True]]:
                """Perform format operations in fasta file to adequate to
                downstream steps of the pipeline.

                Args:
                    input_fasta (Path): The system file path of the input FASTA
                        file to format.
                    output_fasta (Path): The system file path of the output
                        FASTA file to format.

                Returns:
                    Either[Left[bio_exc.MappedErrors], Right[Literal[True]]]:
                        A literal `True` response is the execution was
                        successfully done.
                """

                try:
                    async with async_open(output_fasta, "w+") as out:
                        async for record_either in parse_fasta_records(
                            input_file_path=input_fasta,
                        ):
                            if record_either.is_left:
                                return bio_exc.UseCaseError(
                                    "Unexpected error detected on parse "
                                    + "output FASTA file.",
                                    prev=record_either.value,
                                    logger=LOGGER,
                                )()

                            record: str | None = record_either.value  # type: ignore

                            if record is None:
                                break

                            await out.write(record)

                    return right(True)

                except Exception as exc:
                    return bio_exc.UseCaseError(exc, logger=LOGGER)()

            try:
                # ? ------------------------------------------------------------
                # ? Build IO file paths.
                # ? ------------------------------------------------------------

                in_fasta: Path = self.__out._work_directory.joinpath(
                    self.__out._quality_control_steps.chimera_removal_step_dto.output_dir,  # type: ignore
                    self.__out._qc_artifacts.chimera_removal.chimera_free,
                )

                out_fasta: Path = self.__out._work_directory.joinpath(
                    self.__out._quality_control_steps.chimera_removal_step_dto.output_dir.parent,  # type: ignore
                    self.__out._qc_artifacts.output_polish.folder,
                    self.__out._qc_artifacts.output_polish.polished_sequences,
                )

                if not out_fasta.parent.is_dir():
                    out_fasta.parent.mkdir(parents=True, exist_ok=True)

                self.formatted_data_dir = out_fasta.parent  # type: ignore

                # ? ------------------------------------------------------------
                # ? Check lock file.
                #
                # The lock file indicate that the current step was also
                # executed, thus if the `lock` variable is `True` after
                # execution of the `has_lock_file` function, the current step
                # execution will be already finished with a positive response.
                # ? ------------------------------------------------------------

                lock_either = has_lock_file(
                    step_directory=self.formatted_data_dir,  # type: ignore
                    logger=LOGGER,
                )

                if lock_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on check lock file.",
                        prev=lock_either.value,
                        logger=LOGGER,
                    )()

                lock: bool = lock_either.value  # type: ignore

                if lock:
                    return right(OnExitResponse(can_continue=True))

                # ? ------------------------------------------------------------
                # ? Perform FASTA formatting step.
                # ? ------------------------------------------------------------

                format_response_either = loop.run_until_complete(
                    format_output_fasta(
                        input_fasta=in_fasta,
                        output_fasta=out_fasta,
                    )
                )

                if format_response_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on format output "
                        + "oligotypes.",
                        prev=format_response_either.value,
                        logger=LOGGER,
                    )()

                # ? ------------------------------------------------------------
                # ? Lock directory
                #
                # Create the lock file in output directory indicating that the
                # analysis was successfully done.
                # ? ------------------------------------------------------------

                lock_either = create_lock_file(  # type: ignore
                    step_directory=self.formatted_data_dir,  # type: ignore
                    logger=LOGGER,
                )

                if lock_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on create lock file.",
                        prev=lock_either.value,
                        logger=LOGGER,
                    )()

                # ? ------------------------------------------------------------
                # ? Check if all is done and return a response.
                # ? ------------------------------------------------------------

                if all(
                    [
                        format_response_either.value is True,
                        lock_either.value is True,
                    ]
                ):
                    return right(OnExitResponse(can_continue=True))

                return right(
                    OnExitResponse(
                        can_continue=False,
                        message=(
                            "On-Exit hook: Unexpected error detected on "
                            + "format output FASTA file."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ehook_has_enough_filtered_sequences(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check the minimum requirements for MSA file building.

            Returns:
                Either[bio_exc.MappedErrors, OnInitResponse]: A response
                    indicating if the minimum requirements was met.

            """

            try:
                input_fasta_path: Path = self.__out._work_directory.joinpath(
                    self.__out._qc_artifacts.folder,
                    self.__out._qc_artifacts.quality_filtering.folder,
                    self.__out._qc_artifacts.quality_filtering.filtered,
                )

                enough_either = self.__has_enough_fasta_sequences(
                    input_fasta_path=input_fasta_path,
                )

                if enough_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error occurred on validate FASTA file.",
                        prev=enough_either.value,
                        logger=LOGGER,
                    )()

                if enough_either.value is True:
                    return right(OnInitResponse(can_continue=True))

                return right(
                    OnInitResponse(
                        can_continue=False,
                        message=(
                            "On-Init hook: Not enough sequences left after "
                            + "dereplication step."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ehook_rename_filtered_reads(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Renaming pre-filtering files before run trimming step.

            Returns:
                Either[bio_exc.MappedErrors, OnInitResponse]: A response
                    indicating if the minimum requirements was met.

            """

            try:
                input_fasta_dir: Path = self.__out._work_directory.joinpath(
                    self.__out._qc_artifacts.folder,
                    self.__out._qc_artifacts.filtering_matching.folder,
                )

                shutil.copy(
                    input_fasta_dir.joinpath(
                        self.__out._qc_artifacts.filtering_matching.sub_folder,
                        self.__out._reverse_file_path.name,
                    ),
                    input_fasta_dir.joinpath(
                        self.__out._qc_artifacts.filtering_matching.reverse_filtered
                    ),
                )

                shutil.copy(
                    input_fasta_dir.joinpath(
                        self.__out._qc_artifacts.filtering_matching.sub_folder,
                        self.__out._qc_artifacts.forward_filtering.forward_filtered,
                    ),
                    input_fasta_dir.joinpath(
                        self.__out._qc_artifacts.filtering_matching.forward_filtered
                    ),
                )

                if all(
                    [
                        input_fasta_dir.joinpath(
                            self.__out._qc_artifacts.filtering_matching.reverse_filtered
                        ),
                        input_fasta_dir.joinpath(
                            self.__out._qc_artifacts.filtering_matching.forward_filtered
                        ).is_file(),
                    ]
                ):
                    return right(OnInitResponse(can_continue=True))

                return right(
                    OnInitResponse(
                        can_continue=False,
                        message=(
                            "On-Exit hook: Could not generate filtered files "
                            + "before trimming."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ehook_could_continue_qc(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check the minimum requirements continuing quality control
            execution.

            Returns:
                Either[bio_exc.MappedErrors, OnInitResponse]: A response
                    indicating if the minimum requirements was met.

            """

            try:
                merged_fasta_path: Path = self.__out._work_directory.joinpath(
                    self.__out._qc_artifacts.folder,
                    self.__out._qc_artifacts.merging.folder,
                    self.__out._qc_artifacts.merging.merged_pairs,
                )

                LOGGER.debug(
                    f"Single-end recovery strategy: {self.__out._qc_params.single_end_recovery_strategy}"
                )

                LOGGER.debug(
                    f"Minimum Cluster Size: {self.__out._qc_params.min_cluster_size}"
                )

                # If single-end recovery strategy is enabled, sequences unpaired
                # sequences from trimmomatic step will be used together the
                # output of the merging step.
                if self.__out._qc_params.single_end_recovery_strategy is True:
                    trimming_forward_unpaired_path: Path = (
                        self.__out._work_directory.joinpath(
                            self.__out._qc_artifacts.folder,
                            self.__out._qc_artifacts.trimming.folder,
                            self.__out._qc_artifacts.trimming.forward_unpaired,
                        )
                    )

                    if not trimming_forward_unpaired_path.is_file():
                        return right(
                            OnInitResponse(
                                can_continue=False,
                                message=(
                                    "On-Exit hook: Single-end strategy enabled "
                                    + "but the forward unpaired file was not "
                                    + f"found: {trimming_forward_unpaired_path}"
                                ),
                            )
                        )

                    trimming_reverse_unpaired_path: Path = (
                        self.__out._work_directory.joinpath(
                            self.__out._qc_artifacts.folder,
                            self.__out._qc_artifacts.trimming.folder,
                            self.__out._qc_artifacts.trimming.reverse_unpaired,
                        )
                    )

                    if not trimming_reverse_unpaired_path.is_file():
                        return right(
                            OnInitResponse(
                                can_continue=False,
                                message=(
                                    "On-Exit hook: Single-end strategy enabled "
                                    + "but the reverse unpaired file was not "
                                    + f"found: {trimming_reverse_unpaired_path}"
                                ),
                            )
                        )

                    unmerged_forward_fasta_path: Path = (
                        self.__out._work_directory.joinpath(
                            self.__out._qc_artifacts.folder,
                            self.__out._qc_artifacts.merging.folder,
                            self.__out._qc_artifacts.merging.not_merged_fwd,
                        )
                    )

                    trimming_forward_unpaired_sequences = list(
                        SeqIO.parse(trimming_forward_unpaired_path, "fastq")
                    )

                    with merged_fasta_path.open("a") as merged:
                        SeqIO.write(
                            trimming_forward_unpaired_sequences, merged, "fasta"
                        )

                    trimming_reverse_unpaired_sequences = list(
                        SeqIO.parse(trimming_reverse_unpaired_path, "fastq")
                    )

                    with merged_fasta_path.open("a") as merged:
                        SeqIO.write(
                            trimming_reverse_unpaired_sequences, merged, "fasta"
                        )

                    unmerged_forward_fasta_sequences = list(
                        SeqIO.parse(unmerged_forward_fasta_path, "fastq")
                    )

                    with merged_fasta_path.open("a") as merged:
                        SeqIO.write(
                            unmerged_forward_fasta_sequences, merged, "fasta"
                        )

                enough_either = self.__has_enough_fasta_sequences(
                    input_fasta_path=merged_fasta_path,
                )

                if enough_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error occurred on validate FASTA file.",
                        prev=enough_either.value,
                        logger=LOGGER,
                    )()

                if enough_either.value is True:
                    return right(OnInitResponse(can_continue=True))

                return right(
                    OnInitResponse(
                        can_continue=False,
                        message=(
                            "On-Exit hook: Not enough sequences left after "
                            + "merging step."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ehook_has_enough_dereplicated_sequences(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check the minimum requirements for MSA file building.

            Returns:
                Either[bio_exc.MappedErrors, OnInitResponse]: A response
                    indicating if the minimum requirements was met.
            """

            try:
                input_fasta_path: Path = self.__out._work_directory.joinpath(
                    self.__out._quality_control_steps.dereplicated_step_dto.output_dir,  # type: ignore
                    self.__out._qc_artifacts.dereplication.dereplicated,
                )

                enough_either = self.__has_enough_fasta_sequences(
                    input_fasta_path=input_fasta_path,
                )

                if enough_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error occurred on validate FASTA file.",
                        prev=enough_either.value,
                        logger=LOGGER,
                    )()

                if enough_either.value is True:
                    return right(OnInitResponse(can_continue=True))

                return right(
                    OnInitResponse(
                        can_continue=False,
                        message=(
                            "On-Init hook: Not enough sequences left after "
                            + "dereplication step."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ehook_has_enough_denoise_sequences(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check the minimum requirements for MSA file building.

            Returns:
                Either[bio_exc.MappedErrors, OnInitResponse]: A response
                    indicating if the minimum requirements was met.
            """

            try:
                input_fasta_path: Path = self.__out._work_directory.joinpath(
                    self.__out._quality_control_steps.denoised_step_dto.output_dir,  # type: ignore
                    self.__out._qc_artifacts.denoise.denoise,
                )

                enough_either = self.__has_enough_fasta_sequences(
                    input_fasta_path=input_fasta_path,
                )

                if enough_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error occurred on validate FASTA file.",
                        prev=enough_either.value,
                        logger=LOGGER,
                    )()

                if enough_either.value is True:
                    return right(OnInitResponse(can_continue=True))

                return right(
                    OnInitResponse(
                        can_continue=False,
                        message=(
                            "On-Init hook: Not enough sequences left after "
                            + "denoise step."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __has_enough_fasta_sequences(
            self,
            input_fasta_path: Path,
        ) -> Either[bio_exc.UseCaseError, bool]:
            """Check if a FASTA file has enough sequences. This method is shared
            among QC hooks.

            Args:
                input_fasta_path (Path): _description_

            Returns:
                Either[bio_exc.UseCaseError, Literal[True]]: A literal `True`
                    if FASTA has one or more sequences in file.

            """

            try:
                if not input_fasta_path.is_file():
                    return bio_exc.UseCaseError(
                        f"Invalid path for FASTA file: {input_fasta_path}",
                        logger=LOGGER,
                    )()

                with input_fasta_path.open() as fasta:
                    sequences = fasta.read()
                    sequences = re.split("^>", sequences, flags=re.MULTILINE)  # type: ignore

                    del sequences[0]  # type: ignore
                    if len(sequences) > 0:
                        return right(True)

                return right(False)

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PRIVATE METHODS
        # ? --------------------------------------------------------------------

        def __pre_filter_raw_forward_reads(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Pre-filtering step for raw reads."""

            try:
                step_response = self.__out._repos.pre_filter_raw_reads.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._source_directory,
                        work_directory=self.__out._work_directory,
                    ),
                    input_raw_fastq=self.__out._forward_file_path,
                    output_filtered_fastq=self.__out._qc_artifacts.forward_filtering.forward_filtered,
                    sample_size=self.__out._qc_params.sample_size,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute trim paired end step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.forward_filtering_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __match_filtered_reads(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Call for complementary reads of pre-filtering step."""

            try:
                step_response = self.__out._repos.match_filtered_reads.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        work_directory=self.__out._work_directory,
                    ),
                    source_directory_filtered=self.__out._work_directory.joinpath(
                        self.forward_filtering_step_dto.output_dir  # type: ignore
                    ),
                    source_directory_raw=self.__out._source_directory,
                    input_filtered_fastq=self.__out._qc_artifacts.forward_filtering.forward_filtered,
                    input_complement_fastq=self.__out._reverse_file_path,
                    output_forward_fastq=self.__out._qc_artifacts.filtering_matching.forward_filtered,
                    output_matching_files=self.__out._qc_artifacts.filtering_matching.sub_folder,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute trim paired end step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.matching_filtered_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __trim_paired_end_reads(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Trim paired-end reads.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]]: A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.trim_paired_end_reads_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.matching_filtered_step_dto.output_dir  # type: ignore
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_forward_file_path=self.__out._qc_artifacts.filtering_matching.forward_filtered,
                    input_reverse_file_path=self.__out._qc_artifacts.filtering_matching.reverse_filtered,
                    output_forward_paired_artifact=self.__out._qc_artifacts.trimming.forward_filtered,
                    output_forward_unpaired_artifact=self.__out._qc_artifacts.trimming.forward_unpaired,
                    output_reverse_paired_artifact=self.__out._qc_artifacts.trimming.reverse_paired,
                    output_reverse_unpaired_artifact=self.__out._qc_artifacts.trimming.reverse_unpaired,
                    head_crop=self.__out._qc_params.head_crop,
                    leading_quality=self.__out._qc_params.leading_quality,
                    trailing_quality=self.__out._qc_params.trailing_quality,
                    end_crop=self.__out._qc_params.end_crop,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute trim paired end step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.trim_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __merge_paired_end_reads(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Merge paired end reads.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]]: A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.merge_paired_end_reads_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.trim_step_dto.output_dir  # type: ignore
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_trimmed_forward=self.__out._qc_artifacts.trimming.forward_filtered,
                    input_trimmed_reverse=self.__out._qc_artifacts.trimming.reverse_paired,
                    output_merged_artifact=self.__out._qc_artifacts.merging.merged_pairs,
                    output_not_merged_fwd_artifact=self.__out._qc_artifacts.merging.not_merged_fwd,
                    output_not_merged_rev_artifact=self.__out._qc_artifacts.merging.not_merged_rev,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute paired end merging step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.merged_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __perform_quality_filtering(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Apply reads quality filtering.

            Returns:
                Either[bio_exc.UseCaseError, StepOutputDTO]: A StepOutputDTO
                    instance if all step execution is successfully done.

            Raises:
                bio_exc.UseCaseError: If any error occurs.

            """

            try:
                step_response = self.__out._repos.quality_filter_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.merged_step_dto.output_dir  # type: ignore
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_merged=self.__out._qc_artifacts.merging.merged_pairs,
                    output_filtered_artifact=self.__out._qc_artifacts.quality_filtering.filtered,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute quality filtering step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.filtered_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __dereplicate_contigs(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Dereplicate contigs.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]]: A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.dereplication_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.filtered_step_dto.output_dir  # type: ignore
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_filtered=self.__out._qc_artifacts.quality_filtering.filtered,
                    output_dereplicated_artifact=self.__out._qc_artifacts.dereplication.dereplicated,
                    derep_strategy=self.__out._qc_params.derep_strategy,
                    min_cluster_size=self.__out._qc_params.min_cluster_size,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute dereplication step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.dereplicated_step_dto: StepDTO = (
                    step_response.value.instance  # type: ignore
                )

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __denoise(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Denoising contigs.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]]: A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.denoise_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.dereplicated_step_dto.output_dir  # type: ignore
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_dereplicated=self.__out._qc_artifacts.dereplication.dereplicated,
                    output_denoised_artifact=self.__out._qc_artifacts.denoise.denoise,
                    min_cluster_size=self.__out._qc_params.min_cluster_size,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute denoise step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.denoised_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __remove_chimera(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Remove chimera.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]]: A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.chimera_removal_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.denoised_step_dto.output_dir  # type: ignore
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_dereplicated=self.__out._qc_artifacts.denoise.denoise,
                    output_denoised_artifact=self.__out._qc_artifacts.chimera_removal.chimera_free,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute chimera removal step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.chimera_removal_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()
