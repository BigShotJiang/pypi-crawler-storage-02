from gzip import open as gz_open
from json import dumps
from math import floor
from pathlib import Path
from typing import Any, Literal

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from pandas import DataFrame, read_csv

from mdv.domain.dtos import ResultsConfig, SampleResults
from mdv.settings import LOGGER


class GenerateOutputArtifact:
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOK METHODS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        results_set: ResultsConfig,
        analysis_directory: Path,
        custom_source_directory: Path | None = None,
    ) -> None:
        self.__results_set = results_set
        self.__analysis_directory = analysis_directory
        self.__custom_source_directory = custom_source_directory

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def populate_partial_output_artifact(
        self,
    ) -> Either[bio_exc.UseCaseError, tuple[Path, Path]]:
        """Populate partial output artifact.

        Returns:
            Either[bio_exc.UseCaseError, tuple[Path, Path]]: A positive
                response with the path of the output files or a negative
                response with the error.

        Raises:
            bio_exc.UseCaseError: If an unexpected error is detected on
                populate partial output artifact.

        """

        try:
            # ? ----------------------------------------------------------------
            # ? Populate quality control statistics
            # ? ----------------------------------------------------------------

            LOGGER.info("Collecting Quality Control Statistics")

            qc_results_either = self.__get_quality_control_results()

            if qc_results_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on collect quality control "
                    + "statistics.",
                    prev=qc_results_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Persist statistics into files
            # ? ----------------------------------------------------------------

            persistence_response_either = self.__persist_statistics_as_files(
                statistics=qc_results_either.value,
            )

            if persistence_response_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on persist quality control "
                    + "statistics.",
                    prev=persistence_response_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Return a positive response
            # ? ----------------------------------------------------------------

            (
                output_file_json,
                output_file_tsv,
            ) = persistence_response_either.value

            for path in [output_file_json, output_file_tsv]:
                if not path.exists():
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on persist quality control "
                        + "statistics.",
                        logger=LOGGER,
                    )()

            return right(
                (
                    output_file_json,
                    output_file_tsv,
                )
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __persist_statistics_as_files(
        self,
        statistics: dict[str, dict[str, dict[str, int]]],
    ) -> Either[bio_exc.UseCaseError, tuple[Path, Path]]:
        try:
            # ? ----------------------------------------------------------------
            # ? Persist stats as a JSON file
            # ? ----------------------------------------------------------------

            output_file_json = self.__analysis_directory.joinpath(
                "qc_output.json"
            )

            LOGGER.info(
                f"Persisting Statistics into JSON file: {output_file_json}"
            )

            with output_file_json.open("w+") as output:
                output.write(
                    dumps(statistics, indent=4),
                )

            # ? ----------------------------------------------------------------
            # ? Persist stats as a pandas dataframe
            # ? ----------------------------------------------------------------

            output_file_tsv = self.__analysis_directory.joinpath(
                "qc_output.tsv"
            )

            LOGGER.info(
                f"Persisting Statistics into TSV file: {output_file_tsv}"
            )

            df_content = []
            for sample, sample_stats in statistics.items():
                for stat, stat_values in sample_stats.items():
                    for source, stats in stat_values.items():
                        df_content.append((sample, stat, source, stats))

            df = DataFrame(
                df_content,
                columns=["sample", "stat", "source", "value"],
            ).to_csv(
                output_file_tsv,
                sep="\t",
                index=False,
            )

            # ? ----------------------------------------------------------------
            # ? Return a positive response
            # ? ----------------------------------------------------------------

            return right(
                (
                    output_file_json,
                    output_file_tsv,
                )
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def run(
        self,
    ) -> Either[bio_exc.UseCaseError, Literal[True]]:
        try:
            # ? ----------------------------------------------------------------
            # ? Populate quality control statistics
            # ? ----------------------------------------------------------------

            LOGGER.info("Collecting Quality Control Statistics")

            qc_results_either = self.__get_quality_control_results()

            if qc_results_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on collect quality control "
                    + "statistics.",
                    prev=qc_results_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Populate alpha diversity statistics
            # ? ----------------------------------------------------------------

            LOGGER.info("Collecting Alpha Phylo Diversity Statistics")

            alpha_phylo_diversity_either = (
                self.__get_alpha_phylo_diversity_indices()
            )

            if alpha_phylo_diversity_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on collect phylogenetic "
                    + " diversity statistics.",
                    prev=alpha_phylo_diversity_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Populate rarefaction statistics
            # ? ----------------------------------------------------------------

            LOGGER.info("Collecting Alpha Rarefaction Statistics")

            alpha_rarefaction_either = (
                self.__get_alpha_phylo_rarefaction_results()
            )

            if alpha_rarefaction_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on collect phylogenetic "
                    + " rarefaction statistics.",
                    prev=alpha_rarefaction_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Persist statistics into file
            # ? ----------------------------------------------------------------

            output_file = self.__analysis_directory.joinpath("output.json")

            LOGGER.info(f"Persisting Statistics on file: {output_file}")

            with output_file.open("w+") as output:
                output.write(
                    dumps(
                        {
                            "qc_results": qc_results_either.value,
                            "alpha_phylo_diversity_results": alpha_phylo_diversity_either.value,
                            "alpha_phylo_rarefaction_results": alpha_rarefaction_either.value,
                        },
                        indent=4,
                    ),
                )

            # ? ----------------------------------------------------------------
            # ? Return a positive response
            # ? ----------------------------------------------------------------

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    # ? ------------------------------------------------------------------------
    # ? PRIVATE METHODS
    # ? ------------------------------------------------------------------------

    def __get_quality_control_results(
        self,
    ) -> Either[bio_exc.UseCaseError, dict[str, Any]]:
        """Collect quality control statistics from all samples.

        Returns:
            Either[Left[bio_exc.UseCaseError], Right[dict[str, Any]]]:
                The quality control statistics.

        Raises:
            bio_exc.UseCaseError: If an unexpected error is detected.

        """

        try:
            quality_control_stats = {}

            for sample in self.__results_set.samples_results:
                sample_stats_either = (
                    self.__get_single_sample_quality_control_results(
                        sample=sample
                    )
                )

                if sample_stats_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on collect statistics "
                        + f"from sample {sample.specs.name}",
                        prev=sample_stats_either.value,
                        logger=LOGGER,
                    )()

                quality_control_stats.update(
                    {sample.specs.name: sample_stats_either.value}
                )

            return right(quality_control_stats)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __get_single_sample_quality_control_results(
        self,
        sample: SampleResults,
    ) -> Either[bio_exc.UseCaseError, dict[str, Any]]:
        """Collect quality control statistics of a single sample.

        Args:
            sample (SampleResultsDTO): The sample object.

        Returns:
            Either[Left[bio_exc.UseCaseError], Right[dict[str, Any]]]:

        """

        def get_raw_stats() -> dict[str, Any]:
            forward_reads = Path()
            reverse_reads = Path()

            if (
                desired_forward_reads := self.__analysis_directory.joinpath(
                    sample.specs.name,
                    sample.specs.files.forward_file,
                )
            ).is_file():
                forward_reads = desired_forward_reads
            elif self.__custom_source_directory is not None:
                if (
                    desired_forward_reads := self.__custom_source_directory.joinpath(
                        sample.specs.files.forward_file,
                    )
                ).is_file():
                    forward_reads = desired_forward_reads

            if (
                desired_reverse_reads := self.__analysis_directory.joinpath(
                    sample.specs.name,
                    sample.specs.files.reverse_file,
                )
            ).is_file():
                reverse_reads = desired_reverse_reads
            elif self.__custom_source_directory is not None:
                if (
                    desired_reverse_reads := self.__custom_source_directory.joinpath(
                        sample.specs.files.reverse_file,
                    )
                ).is_file():
                    reverse_reads = desired_reverse_reads

            return {
                "forward_reads": self.__get_compressed_fastq_reads_count(
                    path=forward_reads,
                ),
                "reverse_reads": self.__get_compressed_fastq_reads_count(
                    path=reverse_reads,
                ),
            }

        def get_filtering_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.filtering_matching.folder,
            )

            return {
                "forward_filtered": self.__get_compressed_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.filtering_matching.forward_filtered,
                    ),
                ),
                "reverse_filtered": self.__get_compressed_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.filtering_matching.reverse_filtered,
                    ),
                ),
            }

        def get_trimming_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.trimming.folder,
            )

            return {
                "forward_paired_reads": self.__get_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.trimming.forward_filtered,
                    ),
                ),
                "forward_unpaired_reads": self.__get_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.trimming.forward_unpaired,
                    ),
                ),
                "reverse_paired_reads": self.__get_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.trimming.reverse_paired,
                    ),
                ),
                "reverse_unpaired_reads": self.__get_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.trimming.reverse_unpaired,
                    ),
                ),
            }

        def get_merge_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.merging.folder,
            )

            return {
                "merged": self.__get_fasta_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.merging.merged_pairs,
                    ),
                ),
                "not_merged_forward": self.__get_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.merging.not_merged_fwd,
                    ),
                ),
                "not_merged_reverse": self.__get_fastq_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.merging.not_merged_rev,
                    ),
                ),
            }

        def get_quality_filter_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.quality_filtering.folder,
            )

            return {
                "filtered": self.__get_fasta_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.quality_filtering.filtered,
                    ),
                )
            }

        def get_dereplication_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.dereplication.folder,
            )

            return {
                "dereplicated": self.__get_fasta_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.dereplication.dereplicated,
                    ),
                )
            }

        def get_denoise_removal_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.denoise.folder,
            )

            return {
                "denoise": self.__get_fasta_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.denoise.denoise,
                    ),
                )
            }

        def get_chimera_removal_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.chimera_removal.folder,
            )

            return {
                "chimera_free": self.__get_fasta_reads_count(
                    path=base_path.joinpath(
                        sample.quality_control_artifacts.chimera_removal.chimera_free,
                    ),
                )
            }

        def get_rarefaction_stats() -> dict[str, Any]:
            base_path = self.__analysis_directory.joinpath(
                sample.specs.name,
                sample.quality_control_artifacts.folder,
                sample.quality_control_artifacts.rarefaction.folder,
                sample.quality_control_artifacts.rarefaction.rarefaction_table.folder,
                sample.quality_control_artifacts.rarefaction.rarefaction_table.rarefaction_table,
            )

            if not base_path.is_file():
                return {"rarefaction": None}

            input_file = read_csv(
                base_path,
                sep="\t",
            )

            return {
                "rarefaction": input_file[
                    (input_file["Order.q"] == 0)
                    & (input_file["Method"] == "Observed")
                ]["qD"].values[0]
            }

        try:
            return right(
                dict(
                    raw=get_raw_stats(),
                    filtering=get_filtering_stats(),
                    trimming=get_trimming_stats(),
                    merging=get_merge_stats(),
                    quality_filtering=get_quality_filter_stats(),
                    dereplication=get_dereplication_stats(),
                    denoise=get_denoise_removal_stats(),
                    chimera_free=get_chimera_removal_stats(),
                    rarefaction=get_rarefaction_stats(),
                )
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    @staticmethod
    def __get_compressed_fastq_reads_count(path: Path) -> int:
        if not path.is_file():
            return 0

        return floor(sum(1 for l in gz_open(path, "rb") if l.startswith(b"@")))

    @staticmethod
    def __get_fastq_reads_count(path: Path) -> int:
        if not path.is_file():
            return 0

        return floor(sum(1 for l in path.open() if l.startswith("@")))

    @staticmethod
    def __get_fasta_reads_count(path: Path) -> int:
        if not path.is_file():
            return 0

        return floor(sum(1 for l in path.open() if l.startswith(">")))

    def __get_alpha_phylo_diversity_indices(
        self,
    ) -> Either[bio_exc.UseCaseError, dict[str, Any]]:
        try:
            return right(
                read_csv(
                    self.__analysis_directory.joinpath(
                        self.__results_set.phylogenetic_results.folder,
                        self.__results_set.phylogenetic_results.alpha_diversity.folder,
                        self.__results_set.phylogenetic_results.alpha_diversity.calculated_diversity_raw,
                    ),
                    sep="\t",
                    index_col=[0],
                ).to_dict(orient="index")
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __get_alpha_phylo_rarefaction_results(
        self,
    ) -> Either[bio_exc.UseCaseError, dict[str, Any]]:
        try:
            rarefied_faith_pd = read_csv(
                self.__analysis_directory.joinpath(
                    self.__results_set.phylogenetic_results.folder,
                    self.__results_set.phylogenetic_results.alpha_rarefaction.folder,
                    self.__results_set.phylogenetic_results.alpha_rarefaction.rarefied_raw_faith_pd,
                ),
                index_col=[0],
            ).to_dict(orient="index")

            rarefied_shannon = read_csv(
                self.__analysis_directory.joinpath(
                    self.__results_set.phylogenetic_results.folder,
                    self.__results_set.phylogenetic_results.alpha_rarefaction.folder,
                    self.__results_set.phylogenetic_results.alpha_rarefaction.rarefied_raw_shannon,
                ),
                index_col=[0],
            ).to_dict(orient="index")

            rarefied_observed = read_csv(
                self.__analysis_directory.joinpath(
                    self.__results_set.phylogenetic_results.folder,
                    self.__results_set.phylogenetic_results.alpha_rarefaction.folder,
                    self.__results_set.phylogenetic_results.alpha_rarefaction.rarefied_raw_observed,
                ),
                index_col=[0],
            ).to_dict(orient="index")

            return right(
                {
                    "faith_pd": rarefied_faith_pd,
                    "shannon": rarefied_shannon,
                    "observed": rarefied_observed,
                }
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()
