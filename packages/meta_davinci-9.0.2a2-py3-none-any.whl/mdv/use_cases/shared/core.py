from asyncio import BaseEventLoop
from logging import Logger
from pathlib import Path
from typing import Any, Callable, Generator, NamedTuple

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from attr import define, field

from mdv.domain.dtos import (
    BaseArtifactsObject,
    StepDTO,
    check_artifact_instance,
)
from mdv.domain.entities.function_annotation.full_pipeline_picrust import (
    RunFullPipelineStep,
)
from mdv.domain.entities.function_annotation.hidden_state_prediction import (
    HiddenStatePredictionStep,
)
from mdv.domain.entities.function_annotation.place_seqs import PlaceSequences
from mdv.domain.entities.phylogeny.align_and_get_phylogeny import (
    AlignAndGeneratePhylogeny,
)
from mdv.domain.entities.phylogeny.filter_table import FilterResults
from mdv.domain.entities.phylogeny.get_phylogenetic_diversity_index import (
    CalculatePhylogeneticDiversityIndexes,
)
from mdv.domain.entities.phylogeny.rarefy import RarefyDiversityResults
from mdv.domain.entities.post_run.export_artifact import ExportArtifact
from mdv.domain.entities.qc.chimera_removal import ChimeraRemovalStep
from mdv.domain.entities.qc.denoise import DenoiseStep
from mdv.domain.entities.qc.dereplicate import DereplicateStep
from mdv.domain.entities.qc.filtered_match import FilteredMatchStep
from mdv.domain.entities.qc.merge_paired_end_reads import MergePairsStep
from mdv.domain.entities.qc.quality_filter import QualityFilterStep
from mdv.domain.entities.qc.rarefaction_generator import (
    SingleSampleRarefactionGeneratorStep,
)
from mdv.domain.entities.qc.rarefaction_input_builder import (
    SingleSampleRarefactionInputBuildStep,
)
from mdv.domain.entities.qc.reads_pre_filtering import PreFilterRawReadsStep
from mdv.domain.entities.qc.summarize_feature_table import (
    SummarizeFeatureTableStep,
)
from mdv.domain.entities.qc.tabulate_metadata import TabulateMetadataStep
from mdv.domain.entities.qc.tabulate_seqs import TabulateRepresentativeSeqsStep
from mdv.domain.entities.qc.trimming import TrimmingStep
from mdv.domain.entities.shared.qiime_import import (
    ImportBlastOutput,
    ImportFeatureTable,
    ImportFromTSVFeatureTable,
    ImportRawFastaReads,
)
from mdv.domain.entities.taxonomy.taxonomy_picking_with_biolinnaeus import (
    TaxonomyPickingWithBioLinnaeus,
)
from mdv.domain.entities.taxonomy.taxonomy_picking_with_blutils import (
    TaxonomyPickingWithBlutils,
)

# ? ----------------------------------------------------------------------------
# ? DATA TRANSFER OBJECTS
# ? ----------------------------------------------------------------------------


class CallableLifeCycleHooks(NamedTuple):
    on_init: Callable[..., Any] | None = None
    on_exit: Callable[..., Any] | None = None


@define
class CallableOutput:
    step_callable: Any = field()
    step_bio: str | None = field()
    step_artifacts: BaseArtifactsObject | None = field(default=None)
    life_cycle_hooks: CallableLifeCycleHooks | None = field(default=None)

    @step_bio.default
    def _fill_from_callable(self) -> str:
        if self.step_callable.__doc__ is None:
            return "no description"

        return self.step_callable.__doc__.splitlines()[0]

    @step_artifacts.validator
    def _check_artifact(
        self,
        _: Any,
        value: Any,
    ) -> None:
        check_artifact_instance(value)


class SingleStepPipelineRepositories(NamedTuple):
    # Quality control attributes
    pre_filter_raw_reads: PreFilterRawReadsStep
    match_filtered_reads: FilteredMatchStep
    trim_paired_end_reads_repo: TrimmingStep
    merge_paired_end_reads_repo: MergePairsStep
    quality_filter_repo: QualityFilterStep
    dereplication_repo: DereplicateStep
    denoise_repo: DenoiseStep
    chimera_removal_repo: ChimeraRemovalStep
    summarize_feature_table_exec_repo: SummarizeFeatureTableStep
    summarize_repr_sequences_exec_repo: TabulateRepresentativeSeqsStep
    summarize_metadata_exec_repo: TabulateMetadataStep
    build_rarefaction_input_repo: SingleSampleRarefactionInputBuildStep
    generate_rarefaction_repo: SingleSampleRarefactionGeneratorStep

    # Taxonomic assignment attributes
    assign_taxonomy_with_bli_repo: TaxonomyPickingWithBioLinnaeus
    assign_taxonomy_with_blu_repo: TaxonomyPickingWithBlutils

    # Phylogeny related attributes
    phylogeny_generation_exec_repo: AlignAndGeneratePhylogeny
    diversity_filtration_exec_repo: FilterResults
    diversity_rarefaction_exec_repo: RarefyDiversityResults
    diversity_indexes_calculation_exec_repo: CalculatePhylogeneticDiversityIndexes

    # Function annotation attributes
    function_annotation_exec_repo: RunFullPipelineStep
    place_sequences_in_tree_of_life_repo: PlaceSequences
    hidden_state_prediction_repo: HiddenStatePredictionStep
    metagenome_pipeline_repo: PlaceSequences

    # Accessory attributes
    import_raw_fasta_artifact: ImportRawFastaReads
    import_blast_output_artifact: ImportBlastOutput
    import_from_tsv_artifacts: ImportFromTSVFeatureTable
    import_from_biom_artifacts: ImportFeatureTable
    export_artifact: ExportArtifact


class OnInitResponse(NamedTuple):
    can_continue: bool = True
    message: str | None = None


class OnExitResponse(NamedTuple):
    can_continue: bool = True
    message: str | None = None


class SingleSamplePipelineResponse(NamedTuple):
    finished_execution: bool
    execution_message: str | None = None


class StepOutput(NamedTuple):
    step: StepDTO
    artifacts: list[Path]
    graceful_stop: bool = False


# ? ----------------------------------------------------------------------------
# ? SUPER-CLASSES
# ? ----------------------------------------------------------------------------


class BaseInnerClasses:
    """This is a base class of the execution inner classes."""

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def generate_steps(
        self,
        steps: list[CallableOutput],
    ) -> Generator[CallableOutput, None, None]:
        for step in steps:
            yield step


class BaseOuterClass:
    """This is the base class for executing use cases outer classes."""

    def __init__(
        self,
        logger: Logger,
    ) -> None:
        self.__logger = logger

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run_steps_sequentially(
        self,
        loop: BaseEventLoop,
        steps: BaseInnerClasses,
        group: str,
        steps_group_name: str,
        start_log_message: str,
        stop_log_message: str,
        destination_directory: str | None = None,
    ) -> Either[bio_exc.UseCaseError, SingleSamplePipelineResponse]:
        try:
            self.__logger.info(start_log_message)
            step: CallableOutput

            for step in steps.generate_steps():  # type: ignore
                step_destination_directory: str | None = None

                if destination_directory is None:
                    step_destination_directory = (
                        f"{group}/{step.step_artifacts.folder}"  # type: ignore
                    )
                else:
                    step_destination_directory = destination_directory

                step_either = self.run_single_step(
                    group=group,
                    destination_directory=step_destination_directory,
                    step=step,
                    loop=loop,
                )

                if step_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on execute a single step.",
                        prev=step_either.value,
                        logger=self.__logger,
                    )()

            self.__logger.info(stop_log_message)

            return right(SingleSamplePipelineResponse(finished_execution=True))

        except Exception as exc:
            return bio_exc.UseCaseError(
                f"Unexpected error detected on execute {steps_group_name}. "
                + f"The message error was `{exc}`",
                logger=self.__logger,
            )()

    def run_single_step(
        self,
        group: str,
        destination_directory: str,
        step: CallableOutput,
        loop: BaseEventLoop,
    ) -> Either[bio_exc.UseCaseError, bool]:
        try:
            self.__logger.info(f"STEP STARTED: {step.step_bio}")

            # ? ----------------------------------------------------------------
            # ? Populate life cycle hooks
            # ? ----------------------------------------------------------------

            on_init: Callable[..., Any] | None = None
            on_exit: Callable[..., Any] | None = None

            if isinstance(step.life_cycle_hooks, CallableLifeCycleHooks):
                if callable(step.life_cycle_hooks.on_init):
                    on_init = step.life_cycle_hooks.on_init
                if callable(step.life_cycle_hooks.on_exit):
                    on_exit = step.life_cycle_hooks.on_exit

            # ? ----------------------------------------------------------------
            # ? Execute the on-init hook
            # ? ----------------------------------------------------------------

            if on_init:
                execution = on_init(loop=loop)

                if execution.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error occurred on execute `on_init` "
                        + f"hook previous step: {step.step_bio}",
                        prev=execution.value,
                        logger=self.__logger,
                    )()

                execution: OnInitResponse = execution.value  # type: ignore

                if not execution.can_continue:
                    self.__logger.warning(execution.message)
                    return right(False)

            # ? ----------------------------------------------------------------
            # ? Execute the step effectively
            # ? ----------------------------------------------------------------

            result = step.step_callable(
                group=group,
                destination_directory=destination_directory,
            )

            if result.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error occurred on use-case execution.",
                    prev=result.value,
                    logger=self.__logger,
                )()

            # ? ----------------------------------------------------------------
            # ? Execute the on-init hook
            # ? ----------------------------------------------------------------

            if on_exit:
                execution = on_exit(loop=loop)

                if execution.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error occurred on execute `on_exit` "
                        + f"hook previous step: {step.step_bio}",
                        prev=execution.value,
                        logger=self.__logger,
                    )()

                execution: OnInitResponse = execution.value  # type: ignore

                if not execution.can_continue:
                    self.__logger.warning(execution.message)
                    return right(False)

            # ? ----------------------------------------------------------------
            # ? Finish execution
            # ? ----------------------------------------------------------------

            self.__logger.info(f"STEP FINISHED: {step.step_bio}")

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(str(exc), logger=self.__logger)()
