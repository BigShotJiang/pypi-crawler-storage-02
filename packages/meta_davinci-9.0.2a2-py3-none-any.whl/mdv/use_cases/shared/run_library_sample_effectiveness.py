from __future__ import annotations

from asyncio import AbstractEventLoop, BaseEventLoop
from pathlib import Path
from typing import Any, Generator

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from attrs import define, field
from pandas import read_csv

from mdv.domain.dtos.config_handler import StepDTO
from mdv.domain.dtos.results_config import QualityControlArtifacts
from mdv.domain.entities.step_execution import DefaultStepParams
from mdv.settings import (
    LOGGER,
    RAREFACTION_KUTTOFF_FOR_COMPLEX,
    RAREFACTION_KUTTOFF_FOR_ISOLATES,
)
from mdv.use_cases.shared.core import (
    BaseInnerClasses,
    BaseOuterClass,
    CallableLifeCycleHooks,
    CallableOutput,
    OnExitResponse,
    OnInitResponse,
    SingleSamplePipelineResponse,
    SingleStepPipelineRepositories,
    StepOutput,
)


@define(kw_only=True)
class RarefactionParams:
    with_sample_effectiveness: bool = field(default=None)
    rarefaction_kuttoff_isolates: int = field(
        default=RAREFACTION_KUTTOFF_FOR_ISOLATES
    )
    rarefaction_kuttoff_complex: int = field(
        default=RAREFACTION_KUTTOFF_FOR_COMPLEX
    )

    def __attrs_post_init__(self) -> None:
        self.with_sample_effectiveness = (
            self.with_sample_effectiveness
            if self.with_sample_effectiveness is not None
            else True
        )

        self.rarefaction_kuttoff_isolates = (
            self.rarefaction_kuttoff_isolates
            or RAREFACTION_KUTTOFF_FOR_ISOLATES
        )

        self.rarefaction_kuttoff_complex = (
            self.rarefaction_kuttoff_complex or RAREFACTION_KUTTOFF_FOR_COMPLEX
        )


class RunLibrarySampleEffectiveness:
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        work_directory: Path,
        quality_control_artifacts: QualityControlArtifacts,
        repos: SingleStepPipelineRepositories,
        sample_is_complex: bool,
        configs: RarefactionParams = RarefactionParams(),
    ) -> None:
        # ? Protected/Internal attributes
        self._work_directory = Path(work_directory)
        self._qc_artifacts = quality_control_artifacts
        self._repos = repos
        self._config = configs
        self._sample_is_complex = sample_is_complex

        # ? Composite inner classes
        self._calculation_steps = self.__SampleEffectivenessCalculator(out=self)

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
        loop: BaseEventLoop | AbstractEventLoop,
    ) -> Either[bio_exc.UseCaseError, SingleSamplePipelineResponse]:
        try:
            LOGGER.info("START SAMPLE EFFECTIVENESS CALCULATION")
            steps: BaseInnerClasses = self._calculation_steps

            for step in steps.generate_steps():
                if (
                    step_either := BaseOuterClass(
                        logger=LOGGER
                    ).run_single_step(
                        group=self._qc_artifacts.folder,
                        destination_directory="/".join(
                            [
                                self._qc_artifacts.folder,
                                self._qc_artifacts.rarefaction.folder,
                                step.step_artifacts.folder,
                            ]
                        ),
                        step=step,
                        loop=loop,
                    )
                ).is_left:
                    return step_either

                if step_either.value is False:
                    return right(
                        SingleSamplePipelineResponse(
                            finished_execution=False,
                            execution_message=(
                                "Rarefaction execution finished prematurely. "
                                + "This behavioral could be due to hook "
                                + "(`on_init` or `on_exit`) validations that "
                                + "were not satisfied."
                            ),
                        )
                    )

            LOGGER.info("FINISH SAMPLE EFFECTIVENESS CALCULATION")

            return right(SingleSamplePipelineResponse(finished_execution=True))

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    # ? ------------------------------------------------------------------------
    # ? INNER CLASSES
    # ? ------------------------------------------------------------------------

    class __SampleEffectivenessCalculator(BaseInnerClasses):
        # ? --------------------------------------------------------------------
        # ? INNER CLASS LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __init__(
            self,
            out: RunLibrarySampleEffectiveness,
        ) -> None:
            # ? Outer class instance
            self.__out = out

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PUBLIC METHODS
        # ? --------------------------------------------------------------------

        def generate_steps(self) -> Generator[CallableOutput, None, None]:
            return super().generate_steps(
                steps=[
                    CallableOutput(
                        step_callable=self.__build_single_sample_rarefaction_input,
                        step_artifacts=self.__out._qc_artifacts.rarefaction.sampled_otu_table,
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_init=self.__ihook_has_enough_sequences,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__calculate_single_sample_rarefaction,
                        step_artifacts=self.__out._qc_artifacts.rarefaction.rarefaction_table,
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_exit=self.__ehook_has_enough_diversity,
                        ),
                    ),
                ]
            )

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PRIVATE INSTANCE METHODS
        # ? --------------------------------------------------------------------

        def __ihook_has_enough_sequences(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check if the input file has enough sequences to continue."""

            try:
                input_fasta_file = self.__out._work_directory.joinpath(
                    self.__out._qc_artifacts.folder,
                    self.__out._qc_artifacts.chimera_removal.folder,
                )

                if not input_fasta_file.is_file():
                    OnExitResponse(
                        can_continue=False,
                        message=("On-Init hook: Unable to find chimera file."),
                    )

                minimum_sequences = 3

                if (
                    enough_sequences := self.__has_enough_fasta_sequences(
                        input_fasta_path=input_fasta_file,
                        minimum_sequences=minimum_sequences,
                    )
                ).is_left:
                    return enough_sequences

                if enough_sequences.value is True:
                    return right(OnInitResponse(can_continue=True))

                return right(
                    OnExitResponse(
                        can_continue=False,
                        message=(
                            "On-Init hook: Not enough sequences found after "
                            + f"chimera removal (< {minimum_sequences})."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ehook_has_enough_diversity(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnExitResponse]:
            """Check the minimum requirements for MSA file building.

            Returns:
                Either[bio_exc.MappedErrors, OnInitResponse]: A response
                    indicating if the minimum requirements was met.
            """

            try:
                input_file_path: Path = self.__out._work_directory.joinpath(
                    self.__out._qc_artifacts.folder,
                    self.__out._qc_artifacts.rarefaction.folder,
                    self.__out._qc_artifacts.rarefaction.rarefaction_table.folder,
                    self.__out._qc_artifacts.rarefaction.rarefaction_table.rarefaction_table,
                )

                if not input_file_path.exists():
                    return right(
                        OnExitResponse(
                            can_continue=False,
                            message=(
                                "On-Exit hook: Rarefaction table file not found."
                            ),
                        )
                    )

                input_file = read_csv(input_file_path, sep="\t")

                q0_observed_value = input_file[
                    (input_file["Order.q"] == 0)
                    & (input_file["Method"] == "Observed")
                ]["qD"].values[0]

                if self.__out._sample_is_complex is True and (
                    q0_observed_value
                    >= self.__out._config.rarefaction_kuttoff_complex
                ):
                    return right(OnExitResponse(can_continue=True))

                if self.__out._sample_is_complex is False and (
                    q0_observed_value
                    >= self.__out._config.rarefaction_kuttoff_isolates
                ):
                    return right(OnExitResponse(can_continue=True))

                return right(
                    OnExitResponse(
                        can_continue=False,
                        message=(
                            "On-Exit hook: Not enough diversity found after "
                            + "sample filtration."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __build_single_sample_rarefaction_input(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Build single sample rarefaction input."""

            try:
                step_response = self.__out._repos.build_rarefaction_input_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.__out._qc_artifacts.folder,
                            self.__out._qc_artifacts.chimera_removal.folder,
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_chimera_free=self.__out._qc_artifacts.chimera_removal.chimera_free,
                    output_otu_table=self.__out._qc_artifacts.rarefaction.sampled_otu_table.sampled_otu_table,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute rarefaction input build step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.rarefaction_input_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __calculate_single_sample_rarefaction(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Build single sample rarefaction curve."""

            try:
                step_response = self.__out._repos.generate_rarefaction_repo.execute(
                    params=DefaultStepParams(
                        group=group,
                        destination_directory=destination_directory,
                        source_directory=self.__out._work_directory.joinpath(
                            self.__out._qc_artifacts.folder,
                            self.__out._qc_artifacts.rarefaction.folder,
                            self.__out._qc_artifacts.rarefaction.sampled_otu_table.folder,
                        ),
                        work_directory=self.__out._work_directory,
                    ),
                    input_otu_table=self.__out._qc_artifacts.rarefaction.sampled_otu_table.sampled_otu_table,
                    output_rarefaction=self.__out._qc_artifacts.rarefaction.rarefaction_table.rarefaction_table,
                )

                if step_response.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error on execute rarefaction calculation step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.rarefaction_output_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PRIVATE STATIC METHODS
        # ? --------------------------------------------------------------------

        @staticmethod
        def __has_enough_fasta_sequences(
            input_fasta_path: Path,
            minimum_sequences: int = 3,
        ) -> Either[bio_exc.UseCaseError, bool]:
            """Check if a FASTA file has enough sequences. This method is shared
            among QC hooks.

            Args:
                input_fasta_path (Path): _description_

            Returns:
                Either[bio_exc.UseCaseError, Literal[True]]: A literal `True`
                    if FASTA has one or more sequences in file.

            """

            try:
                if not input_fasta_path.is_file():
                    return bio_exc.UseCaseError(
                        f"Invalid path for FASTA file: {input_fasta_path}",
                        logger=LOGGER,
                    )()

                with input_fasta_path.open() as fasta:
                    sequences = fasta.read()
                    sequences = re.split("^>", sequences, flags=re.MULTILINE)  # type: ignore

                    del sequences[0]  # type: ignore
                    if len(sequences) > minimum_sequences:
                        return right(True)

                return right(False)

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()
