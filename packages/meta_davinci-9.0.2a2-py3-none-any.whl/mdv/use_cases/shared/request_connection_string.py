from os import getenv
from pathlib import Path
from typing import Any, Callable
from getpass import getpass


def request_connection_string(
    func: Callable[..., Path | None],
) -> Callable[..., Path]:
    connection_string: str | None = None

    def wrapper(**kwargs: Any) -> Any:
        nonlocal connection_string

        if connection_string is not None:
            return func(
                **kwargs,
                connection_string=connection_string,
            )

        if (conn := getenv("AGROBIOTA_STORAGE_CONNECTION_STRING")) is not None:
            return func(
                **kwargs,
                connection_string=conn,
            )

        connection_string = getpass(
            f"\n{'#' * 60}\n\n"
            + "AGROBIOTA_STORAGE_CONNECTION_STRING not found in environment "
            + "variables.\n\n"
            + "⚠️  Provide the connection string from the storage provider: "
        )

        print("\n" + "#" * 60)

        return func(
            **kwargs,
            connection_string=connection_string,
        )

    return wrapper
