import bz2
from json import dumps
from pathlib import Path
import tarfile
from typing import Literal

from agrobase.entities import CreateResponse
import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from mdv.domain.dtos.analysis_blob_artifact import (
    AnalysisBlobArtifact,
    ArtifactGroup,
)
from mdv.domain.entities.analysis_blob_registration import (
    AnalysisBlobRegistration,
)
from mdv.settings import DUMP_MAIN_DIRECTORY, DUMP_MAPPING_FILE, LOGGER
from mdv.use_cases.shared.request_connection_string import (
    request_connection_string,
)


@request_connection_string
def build_backup_artifact_analysis_directory(
    analysis_directory: Path,
    analysis_name: str,
    analysis_year: int,
    analysis_artifact_registration_repo: AnalysisBlobRegistration,
    ignore_list: list[str] = [],
    connection_string: str | None = None,
) -> Either[bio_exc.UseCaseError, Literal[True]]:
    try:
        # ? --------------------------------------------------------------------
        # ? Validate arguments
        # ? --------------------------------------------------------------------

        if analysis_directory.is_dir() is False:
            return bio_exc.InvalidArgumentError(
                f"Invalid directory: {analysis_directory}"
            )()

        if not isinstance(ignore_list, list):
            return bio_exc.InvalidArgumentError(
                f"Invalid ignore list: {ignore_list}"
            )()

        for item in ignore_list:
            if not isinstance(item, str):
                return bio_exc.InvalidArgumentError(
                    f"Invalid ignore list item: {item}"
                )()

        # ? --------------------------------------------------------------------
        # ? Collect file paths
        # ? --------------------------------------------------------------------

        LOGGER.info("Collecting file paths")

        mdv_paths: set[AnalysisBlobArtifact] = set()
        qc_paths: set[AnalysisBlobArtifact] = set()
        extra_dir_paths: set[AnalysisBlobArtifact] = set()
        extra_file_paths: set[AnalysisBlobArtifact] = set()

        for item in sorted(analysis_directory.iterdir()):
            if any(
                [
                    item.name in [*ignore_list, DUMP_MAIN_DIRECTORY, "tmp"],
                    (
                        item.name.startswith("finished")
                        and item.name.endswith(".lock")
                    ),
                    AnalysisBlobArtifact.is_dump_artifact(item),
                ]
            ):
                continue

            if (
                dump_artifact_either := AnalysisBlobArtifact.new(
                    file=item,
                    year=analysis_year,
                    analysis_name=analysis_name,
                )
            ).is_left:
                return dump_artifact_either
            dump_artifact = dump_artifact_either.value

            if item.is_file() is True:
                dump_artifact.group = ArtifactGroup.EXTRA
                extra_file_paths.add(dump_artifact)
                continue

            if item.is_dir() is True:
                dir_content = sorted(item.iterdir())

                if (
                    AnalysisBlobArtifact.match_mdv_directory(dir_content)
                    is True
                ):
                    #
                    # MetaDaVinci artifacts should contains multiple analysis
                    # runs. This step collect each analysis run in a separate
                    # artifact.
                    #
                    mdv_dirs = AnalysisBlobArtifact.filter_mdv_directories(
                        [i for i in dir_content if i.is_dir()]
                    )

                    for path in mdv_dirs:
                        if (
                            inner_artifact_either := AnalysisBlobArtifact.new(
                                file=path,
                                year=analysis_year,
                                analysis_name=analysis_name,
                                dump_dir=analysis_directory.joinpath(
                                    DUMP_MAIN_DIRECTORY
                                ),
                                include_parent_name=True,
                            )
                        ).is_left:
                            return inner_artifact_either

                        inner_dump_artifact = inner_artifact_either.value
                        inner_dump_artifact.group = ArtifactGroup.MDV
                        mdv_paths.add(inner_dump_artifact)

                    for path in [i for i in dir_content if i not in mdv_dirs]:
                        if (
                            inner_artifact_either := AnalysisBlobArtifact.new(
                                file=path,
                                year=analysis_year,
                                analysis_name=analysis_name,
                                dump_dir=analysis_directory.joinpath(
                                    DUMP_MAIN_DIRECTORY
                                ),
                                include_parent_name=True,
                            )
                        ).is_left:
                            return inner_artifact_either

                        inner_dump_artifact = inner_artifact_either.value
                        inner_dump_artifact.group = ArtifactGroup.EXTRA
                        mdv_paths.add(inner_dump_artifact)

                    continue

                if AnalysisBlobArtifact.match_qs_directory(dir_content) is True:
                    dump_artifact.group = ArtifactGroup.QS
                    qc_paths.add(dump_artifact)
                    continue

                extra_dir_paths.add(dump_artifact)

        LOGGER.info("\tFile paths collected")

        # ? --------------------------------------------------------------------
        # ? Compress artifacts
        # ? --------------------------------------------------------------------

        LOGGER.info("Compressing artifacts")

        compressing_artifacts = set(
            [*mdv_paths, *qc_paths, *extra_dir_paths, *extra_file_paths]
        )

        if (
            compression_either := __dehidrate_artifacts_list(
                artifacts=compressing_artifacts,
                analysis_directory=analysis_directory,
            )
        ).is_left:
            return compression_either

        LOGGER.info("\tArtifacts compressed")

        # ? --------------------------------------------------------------------
        # ? Building artifacts mapping
        # ? --------------------------------------------------------------------

        LOGGER.info("Building artifacts mapping")

        artifacts_mapping: dict[str, dict[str, str]] = {
            item.file.relative_to(analysis_directory).__str__(): {
                "file": item.dump_artifact.relative_to(
                    analysis_directory.joinpath(DUMP_MAIN_DIRECTORY)
                ).__str__(),
                "md5": item.hash_artifact(),
                "group": (
                    item.group.value
                    if item.group is not None
                    else ArtifactGroup(None).value
                ),
            }
            for item in compressing_artifacts
        }

        dump_mapping_file_path = analysis_directory.joinpath(
            DUMP_MAIN_DIRECTORY,
            DUMP_MAPPING_FILE,
        )

        with dump_mapping_file_path.open("w+") as artifact:
            artifact.write(
                dumps(
                    artifacts_mapping,
                    indent=4,
                    default=str,
                    sort_keys=True,
                )
            )

        LOGGER.info("\tArtifacts mapping built")

        # ? --------------------------------------------------------------------
        # ? Persist artifacts to blob storage
        # ? --------------------------------------------------------------------

        LOGGER.info("Persisting artifacts to blob storage")

        for artifact in [
            AnalysisBlobArtifact(
                file=dump_mapping_file_path,
                year=analysis_year,
                results_folder=analysis_name,
                dump_artifact=dump_mapping_file_path,
                compress_artifact=str(),
                upload_artifact=str(),
                group=ArtifactGroup.MAP,
            ),
            *sorted(
                compressing_artifacts,
                key=lambda x: (x.dump_artifact.name),
            ),
        ]:
            if (
                response_either := analysis_artifact_registration_repo.create(
                    blob=artifact,
                    connection_string=connection_string,
                )
            ).is_left:
                return response_either

            response: CreateResponse[
                AnalysisBlobArtifact
            ] = response_either.value

            if not response.created:
                LOGGER.warning(
                    f"❌  Blob {artifact.file.name} already registered in storage "
                    + "provider. Skipping..."
                )
                continue

            LOGGER.info(f"✅  Blob {artifact.file.name} registered")

        LOGGER.info("\tArtifacts persisted")

        # ? --------------------------------------------------------------------
        # ? Return a positive response
        # ? --------------------------------------------------------------------

        return right(True)

    except Exception as exc:
        return bio_exc.UseCaseError(exc, logger=LOGGER)()


def __dehidrate_file(
    artifact: AnalysisBlobArtifact,
) -> bool:
    if artifact.dump_artifact.exists() is True:
        artifact.dump_artifact.unlink()

    with bz2.open(artifact.dump_artifact, "wb") as file:
        file.write(artifact.file.read_bytes())

    return True


def __dehidrate_directory(
    artifact: AnalysisBlobArtifact,
) -> bool:
    if artifact.dump_artifact.exists() is True:
        artifact.dump_artifact.unlink()

    with tarfile.open(artifact.dump_artifact, "w:bz2") as tar:
        tar.add(artifact.file, arcname=artifact.file.name)

    return True


def __dehidrate_artifacts_list(
    artifacts: set[AnalysisBlobArtifact],
    analysis_directory: Path,
) -> Either[bio_exc.UseCaseError, Literal[True]]:
    try:
        for artifact in artifacts:
            LOGGER.info(f"Compressing artifact: {artifact.file}")

            if (
                artifact.was_compressed(analysis_directory=analysis_directory)
                is True
            ):
                continue

            if artifact.file.is_file() is True:
                __dehidrate_file(artifact=artifact)

            elif artifact.file.is_dir() is True:
                __dehidrate_directory(artifact=artifact)

            else:
                return bio_exc.UseCaseError(
                    f"Unsuported file type: {artifact.file}", logger=LOGGER
                )()

            artifact.lock_compress(analysis_directory=analysis_directory)
            LOGGER.info("\tArtifact compressed")

        return right(True)

    except Exception as exc:
        return bio_exc.UseCaseError(exc, logger=LOGGER)()
