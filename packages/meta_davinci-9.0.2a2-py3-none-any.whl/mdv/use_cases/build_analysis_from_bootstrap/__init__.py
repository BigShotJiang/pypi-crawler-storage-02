from pathlib import Path
from typing import Any, Literal

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right

from mdv.domain.dtos.analysis_config import AnalysisConfig, SampleConfig
from mdv.settings import LOGGER
from mdv.use_cases.shared.core import SingleStepPipelineRepositories


class BuildAnalysisFromBootstrap:
    # ? ------------------------------------------------------------------------
    # ? CLASS ATTRIBUTES
    # ? ------------------------------------------------------------------------

    _analysis_directory: Path

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        sample_set: AnalysisConfig,
        single_step_repos: SingleStepPipelineRepositories,
        source_directory: Path,
        work_directory: Path,
        **_: Any,
    ) -> None:
        # ? --------------------------------------------------------------------
        # ? Validate constructor arguments
        # ? --------------------------------------------------------------------

        for instance, repo in [
            (sample_set, AnalysisConfig),
            (single_step_repos, SingleStepPipelineRepositories),
        ]:
            if not isinstance(instance, repo):
                raise ValueError(
                    f"{instance} should be a instance of {type(repo)}"
                )

        if not all(
            [
                work_directory.exists(),
                work_directory.is_dir(),
            ]
        ):
            work_directory.mkdir(parents=True, exist_ok=True)

        if not source_directory.is_dir():
            raise ValueError("`source_directory` should be an exist directory.")

        # ? --------------------------------------------------------------------
        # ? Initialize instance attributes
        # ? --------------------------------------------------------------------

        self._sample_set = sample_set
        self._repos = single_step_repos
        self._source_directory = source_directory
        self._work_directory = work_directory

        # ? --------------------------------------------------------------------
        # ? Build base directory
        #
        # The base directory centralize all analysis steps of each sample
        # specified in `sample` attribute of the `__sample_set` element.
        # ? --------------------------------------------------------------------

        build_response_either = self.__build_base_directory()

        if build_response_either.is_left:
            raise Exception(
                "Unexpected error detected on build base directory: "
                + build_response_either.value.msg  # type: ignore
            )

    # ? ------------------------------------------------------------------------
    # ? PROTECTED METHODS
    # ? ------------------------------------------------------------------------

    def _build_sample_directory(
        self,
        sample: SampleConfig,
    ) -> Path:
        """Build sample directory.

        Description:
            This method build the directory for each sample. This directory is
            the parent directory of all analysis steps of each sample.

        Args:
            sample (SampleSpecsDTO): The sample to build the directory.

        Returns:
            Path: The directory path.

        Raises:
            Exception: If an unexpected error was detected.

        """

        sample_directory = self._analysis_directory.joinpath(sample.name)

        if not all(
            [
                sample_directory.exists(),
                sample_directory.is_dir(),
            ]
        ):
            sample_directory.mkdir(parents=True, exist_ok=True)

        return sample_directory

    # ? ------------------------------------------------------------------------
    # ? PRIVATE METHODS
    # ? ------------------------------------------------------------------------

    def __build_base_directory(
        self,
    ) -> Either[bio_exc.UseCaseError, Literal[True]]:
        """Build base directory for analysis.

        Description:
            This method build the base directory for analysis. This directory
            is the parent directory of all analysis steps of each sample
            specified in `sample` attribute of the `__sample_set` element.

        Returns:
            Either[bio_exc.UseCaseError, Literal[True]]: A positive response
                if the directory was created successfully or a negative
                response if an error was detected.

        Raises:
            Exception: If an unexpected error was detected.

        """

        try:
            self._analysis_directory = self._work_directory.joinpath(
                self._sample_set.set_name
            )

            if not all(
                [
                    self._analysis_directory.exists(),
                    self._analysis_directory.is_dir(),
                ]
            ):
                self._analysis_directory.mkdir(parents=True, exist_ok=True)

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()
