from asyncio import get_event_loop, new_event_loop, set_event_loop
from copy import deepcopy
from pathlib import Path
from typing import Any

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right

from mdv.domain.dtos.results_config import ResultsConfig, SampleResults
from mdv.settings import LOGGER
from mdv.use_cases.build_analysis_from_bootstrap import (
    BuildAnalysisFromBootstrap,
)
from mdv.use_cases.shared.generate_output_artifact import (
    GenerateOutputArtifact,
)
from mdv.use_cases.shared.run_library_sample_effectiveness import (
    RarefactionParams,
    RunLibrarySampleEffectiveness,
)
from mdv.use_cases.shared.run_qc_on_single_sample import (
    QcStepParams,
    RunQualityControlOnSingleSample,
)


class RunQualityControlStepFromBootstrap(BuildAnalysisFromBootstrap):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        qc_params: QcStepParams = QcStepParams(),
        rarefy_params: RarefactionParams = RarefactionParams(),
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)

        # ? Trimming
        self.__qc_params = qc_params

        # ? Rarefaction
        self.__rarefy_params = rarefy_params

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run_qc_steps(
        self,
    ) -> Either[bio_exc.UseCaseError, tuple[Path, Path]]:
        """Run quality control steps on each sample of the sample set.

        Description:
            This method is the main entry point of the use case. It is
            responsible for run all quality control steps on each sample of the
            sample set.

        Returns:
            Either[bio_exc.UseCaseError, tuple[Path, Path]]: A positive
                response with the path of the output files or a negative
                response with the error.

        Raises:
            Exception: If an unexpected error is detected on run quality
                control steps on each sample of the sample set.

        """

        try:
            loop = get_event_loop()
        except RuntimeError:
            loop = new_event_loop()
            set_event_loop(loop)
        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

        try:
            # ? ----------------------------------------------------------------
            # ? Initialize running objects
            # ? ----------------------------------------------------------------

            sample: SampleResults

            results_set_either = ResultsConfig.build_from_sample_set(
                sample_set=self._sample_set
            )

            if results_set_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on create results set from "
                    + "sample set.",
                    prev=results_set_either.value,
                    logger=LOGGER,
                )()

            results_set_dto: ResultsConfig = results_set_either.value  # type: ignore

            persistence_either = results_set_dto.to_json(
                output_directory=self._analysis_directory
            )

            if persistence_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on persist results set file to "
                    + "analysis directory",
                    prev=persistence_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Perform quality control
            #
            # This step samples are processed individually. All steps of quality
            # control use case are executed and the final results is
            # `single-sample-by-folder` set of results.
            # ? ----------------------------------------------------------------

            for sample in results_set_dto.samples_results:
                sample_directory = self._build_sample_directory(
                    sample=sample.specs
                )

                qc_params = deepcopy(self.__qc_params)

                qc_params.single_end_recovery_strategy = (
                    sample.specs.recovery_single_end
                    if self.__qc_params.single_end_recovery_strategy is None
                    else self.__qc_params.single_end_recovery_strategy
                )

                qc_runner = RunQualityControlOnSingleSample(
                    sample_code=sample.specs.name,
                    forward_file_path=self._source_directory.joinpath(
                        sample.specs.files.forward_file
                    ),
                    reverse_file_path=self._source_directory.joinpath(
                        sample.specs.files.reverse_file
                    ),
                    source_directory=self._source_directory,  # type: ignore
                    quality_control_artifacts=sample.quality_control_artifacts,
                    work_directory=sample_directory,
                    repos=self._repos,
                    qc_params=qc_params,
                )

                qc_response: Either = qc_runner.run(loop=loop)  # type: ignore

                if qc_response.is_left:
                    LOGGER.exception(qc_response.value)
                    return bio_exc.UseCaseError(
                        "Unexpected use error detected on run quality "
                        + f"control of sample: {sample.specs.name}",
                        prev=qc_response.value,
                    )()

                if self.__rarefy_params.with_sample_effectiveness is True:
                    calculator = RunLibrarySampleEffectiveness(
                        work_directory=sample_directory,
                        quality_control_artifacts=sample.quality_control_artifacts,
                        repos=self._repos,
                        configs=self.__rarefy_params,
                        sample_is_complex=sample.specs.sample_is_complex,
                    )

                    if (run_either := calculator.run(loop=loop)).is_left:
                        return run_either

            # ? ----------------------------------------------------------------
            # ? Generate QC artifact
            # ? ----------------------------------------------------------------

            output_generator = GenerateOutputArtifact(
                results_set=results_set_dto,
                analysis_directory=self._analysis_directory,
                custom_source_directory=self._source_directory,
            )

            output_artifact_either = (
                output_generator.populate_partial_output_artifact()
            )

            if output_artifact_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on generate JSON output file.",
                    prev=output_artifact_either.value,
                    logger=LOGGER,
                )()

            (
                output_file_json,
                output_file_tsv,
            ) = output_artifact_either.value

            # ? ----------------------------------------------------------------
            # ? Return a positive response
            # ? ----------------------------------------------------------------

            return right(
                (
                    output_file_json,
                    output_file_tsv,
                )
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

        finally:
            loop.close()
