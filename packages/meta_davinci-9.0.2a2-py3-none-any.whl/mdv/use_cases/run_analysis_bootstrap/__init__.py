from json import dumps
from os import rmdir
from pathlib import Path
from typing import Literal, Any
import ast
import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from agrobase.enums import TaxaEnum
from pandas import DataFrame, read_csv

from mdv.domain.dtos import (
    BlastReferenceDatabase,
    FastqDirectionEnum,
    FastqFiles,
    AnalysisConfig,
    SampleConfig,
    SequencingTemplateEnum,
)
from mdv.domain.dtos.bootstrap_handler import (
    BootstrapHandler,
    MetadataColNamesEnum,
)
from mdv.settings import BOOT_CONFIG_FILE_NAME, LOGGER


class RunAnalysisBootstrap:
    """Bootstrap class for running the analysis.

    This class is responsible for preparing the environment and configuration
    necessary for the analysis. It supports both legacy and non-legacy boot modes.
    """

    __samples: list[SampleConfig] = []
    __required_files: list[str] = [
        "sample-id",
        "sequencing-template",
    ]

    def __init__(
        self,
        customer: str,
        assay: str,
        taxa: TaxaEnum,
        metadata_file: Path,
        source_directory: Path,
        work_directory: Path,
        blast_database: BlastReferenceDatabase,
    ) -> None:
        """Initialize the RunAnalysisBootstrap class.

        Args:
            customer (str): Customer identifier.
            assay (str): Assay identifier.
            taxa (TaxaEnum): Taxa enumeration.
            metadata_file (Path): Path to the metadata file.
            source_directory (Path): Source directory with input files.
            work_directory (Path): Working directory for the analysis.
            blast_database (BlastReferenceDatabase): BLAST reference database.
        """
        self.__customer = customer
        self.__assay = assay
        self.__taxa = taxa
        self.__metadata_file = metadata_file
        self.__source_directory = source_directory
        self.__work_directory = work_directory
        self.__blast_database = blast_database

    def initialize_analysis_directory(
        self,
        overwrite: bool = False,
        legacy_boot: bool = False,
    ) -> Either[bio_exc.UseCaseError, tuple[Path, AnalysisConfig]]:
        """Initialize the analysis directory.

        Depending on the `legacy_boot` parameter, the corresponding boot routine is invoked.

        Args:
            overwrite (bool, optional): Indicates if an existing directory should be overwritten.
                Defaults to False.
            legacy_boot (bool, optional): Indicates if legacy boot should be used.
                Defaults to False.

        Returns:
            Either[bio_exc.UseCaseError, tuple[Path, AnalysisConfig]]:
                A tuple containing the configuration file path and the analysis configuration object on success,
                or an error on failure.
        """
        if legacy_boot is True:
            return self.__initialize_legacy_boot(overwrite=overwrite)

        return self.__initialize_boot(overwrite=overwrite)

    @staticmethod
    def generate_metadata_tsv(
        json_data: list[dict[str, Any]],
        taxa: TaxaEnum,
        output_file: str = "metadata.tsv",
    ) -> str:
        """Generate a metadata TSV file from JSON data.

        This method parses the JSON data and generates a metadata file containing
        information of samples with the highest total count. The `taxa` parameter
        is used to filter samples according to the assay (16S for BACTERIA, ITS for FUNGI, or BOTH to keep all samples).

        Args:
            json_data (list[dict[str, Any]]): Input data in JSON format.
            taxa (TaxaEnum): Taxa used for filtering the samples.
            output_file (str, optional): Output file name. Defaults to 'metadata.tsv'.

        Returns:
            str: The name of the generated output file.
        """
        aggregated_rows: dict[str, dict[str, Any]] = {}
        for entry in json_data:
            sample_code = entry["tags"]["sampleName"]
            raw_files_str = entry["metadata"]["stats_00_raw_files"]
            try:
                raw_files = ast.literal_eval(raw_files_str)
            except Exception:
                raw_files = []
            total_count = sum(item.get("count", 0) for item in raw_files)
            forward_file = next(
                (f["file"] for f in raw_files if "R1" in f["file"]), None
            )
            reverse_file = next(
                (f["file"] for f in raw_files if "R2" in f["file"]), None
            )
            current_entry = {
                "sample_code": sample_code,
                "forward_file": forward_file,
                "reverse_file": reverse_file,
                "se_recovery": (
                    "true" if forward_file and reverse_file else "false"
                ),
                "total_count": total_count,
            }
            if sample_code in aggregated_rows:
                if total_count > aggregated_rows[sample_code]["total_count"]:
                    aggregated_rows[sample_code] = current_entry
            else:
                aggregated_rows[sample_code] = current_entry

        if taxa == TaxaEnum.BACTERIA:
            filtered_rows = [
                row
                for row in aggregated_rows.values()
                if "16S" in row["sample_code"]
            ]
        elif taxa == TaxaEnum.FUNGI:
            filtered_rows = [
                row
                for row in aggregated_rows.values()
                if "ITS" in row["sample_code"]
            ]
        elif taxa == TaxaEnum.BOTH:
            filtered_rows = list(aggregated_rows.values())
        else:
            filtered_rows = list(aggregated_rows.values())

        sorted_rows = sorted(filtered_rows, key=lambda x: x["sample_code"])
        with open(output_file, "w", encoding="utf-8") as f:
            f.write("sample_code\tforward_file\treverse_file\tse_recovery\n")
            for row in sorted_rows:
                f.write(
                    f"{row['sample_code']}\t{row['forward_file']}\t{row['reverse_file']}\t{row['se_recovery']}\n"
                )
        return output_file

    def __initialize_boot(
        self,
        overwrite: bool = False,
    ) -> Either[bio_exc.UseCaseError, tuple[Path, AnalysisConfig]]:
        """Initialize boot in non-legacy mode.

        Reads the metadata CSV file, validates the necessary columns, and creates the sample configuration.
        Then, it generates the configuration JSON file in the output directory.

        Args:
            overwrite (bool, optional): Indicates if an existing directory should be overwritten.
                Defaults to False.

        Returns:
            Either[bio_exc.UseCaseError, tuple[Path, AnalysisConfig]]:
                A tuple containing the configuration file path and the analysis configuration object on success,
                or an error on failure.
        """
        try:
            samples_map: DataFrame = read_csv(self.__metadata_file, sep="\t")

            if (
                MetadataColNamesEnum.SINGLE_END_RECOVERY.value
                in samples_map.columns
            ):
                samples_map.loc[
                    :, MetadataColNamesEnum.SINGLE_END_RECOVERY.value
                ] = samples_map.loc[
                    :, MetadataColNamesEnum.SINGLE_END_RECOVERY.value
                ].fillna(
                    False
                )

            if (
                MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value
                in samples_map.columns
            ):
                samples_map.loc[
                    :, MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value
                ] = samples_map.loc[
                    :, MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value
                ].fillna(
                    True
                )

            bootstrap_handler = BootstrapHandler(
                samples_map=samples_map,
                source_directory=Path(self.__source_directory),
            )

            samples_specs: list[SampleConfig] = []

            for _, row in bootstrap_handler.samples_map.iterrows():
                sample_code = row.get(MetadataColNamesEnum.SAMPLE_CODE.value)
                if sample_code is None:
                    return bio_exc.UseCaseError(
                        "Unexpected error during quality control for sample: None"
                    )()

                fwd_file = row.get(MetadataColNamesEnum.FORWARD_FILE.value)
                if fwd_file is None:
                    return bio_exc.UseCaseError(
                        "Unexpected error during quality control: forward file missing"
                    )()

                rev_file = row.get(MetadataColNamesEnum.REVERSE_FILE.value)
                if rev_file is None:
                    return bio_exc.UseCaseError(
                        "Unexpected error during quality control: reverse file missing"
                    )()

                sample_is_complex = row.get(
                    MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value
                )
                if sample_is_complex is None:
                    LOGGER.warning(
                        "Sample type not defined. Assuming the sample is complex."
                    )
                    sample_is_complex = True

                samples_specs.append(
                    SampleConfig(
                        name=sample_code,
                        files=FastqFiles(
                            template=SequencingTemplateEnum.PAIRED_END,
                            forward_file=fwd_file,
                            reverse_file=rev_file,
                        ),
                        blast_database=self.__blast_database,
                        recovery_single_end=row.get(
                            MetadataColNamesEnum.SINGLE_END_RECOVERY.value,
                            False,
                        ),
                        service_order=row.get(
                            MetadataColNamesEnum.SERVICE_ORDER.value, None
                        ),
                        sample_is_complex=sample_is_complex,
                    )
                )

            sample_set = AnalysisConfig(
                customer=self.__customer,
                assay=self.__assay,
                taxa=self.__taxa,
                samples=samples_specs,
                metadata_artifact=self.__metadata_file.name,
                metadata_content=bootstrap_handler.samples_map,
                source_directory=self.__source_directory,
                legacy=False,
            )

            output_directory: Path = self.__work_directory.joinpath(
                sample_set.set_name
            )

            if output_directory.exists():
                if not overwrite:
                    return bio_exc.UseCaseError(
                        f"Output directory already exists: {output_directory}\n"
                        "Set force overwrite to create the directory.",
                        exp=True,
                        logger=LOGGER,
                    )()
                rmdir(output_directory)
            else:
                output_directory.mkdir(parents=True, exist_ok=True)

            output_file: Path = output_directory.joinpath(BOOT_CONFIG_FILE_NAME)

            with output_file.open("w") as config_json:
                config_json.write(
                    dumps(sample_set.as_dict(), indent=4, default=str)
                )

            return right((output_file, sample_set))

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __initialize_legacy_boot(
        self,
        overwrite: bool = False,
    ) -> Either[bio_exc.UseCaseError, tuple[Path, AnalysisConfig]]:
        """Initialize boot in legacy mode.

        Loads and validates the metadata, discovers the FASTQ files, and creates the analysis configuration.
        Then, it writes the configuration file in JSON format to the output directory.

        Args:
            overwrite (bool, optional): Indicates if an existing directory should be overwritten.
                Defaults to False.

        Returns:
            Either[bio_exc.UseCaseError, tuple[Path, AnalysisConfig]]:
                A tuple containing the configuration file path and the analysis configuration object on success,
                or an error on failure.
        """
        try:
            response = self.__load_and_validate_metadata()

            if response.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error while loading metadata.",
                    prev=response.value,
                    logger=LOGGER,
                )()

            response = self.__discovery_fastq_files()

            if response.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error during discovery of FASTQ files.",
                    prev=response.value,
                    logger=LOGGER,
                )()

            sample_set = AnalysisConfig(
                customer=self.__customer,
                assay=self.__assay,
                taxa=self.__taxa,
                samples=self.__samples,
                metadata_artifact=self.__metadata_file.name,
                metadata_content=None,
                source_directory=self.__source_directory,
                legacy=True,
            )

            output_directory: Path = self.__work_directory.joinpath(
                sample_set.set_name
            )

            if output_directory.exists():
                if not overwrite:
                    return bio_exc.UseCaseError(
                        f"Output directory already exists: {output_directory}\n"
                        "Set force overwrite to create the directory.",
                        exp=True,
                        logger=LOGGER,
                    )()
                rmdir(output_directory)
            else:
                output_directory.mkdir(parents=True, exist_ok=True)

            output_file: Path = output_directory.joinpath(BOOT_CONFIG_FILE_NAME)

            with output_file.open("w") as config_json:
                config_json.write(
                    dumps(sample_set.as_dict(), indent=4, default=str)
                )

            return right((output_file, sample_set))

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __discovery_fastq_files(
        self,
    ) -> Either[bio_exc.UseCaseError, Literal[True]]:
        """Discover FASTQ files based on the metadata.

        Validates the existence of required columns in the metadata DataFrame and the values
        present in the `sequencing-template` column. Then, for each sample, it collects the
        corresponding FASTQ files.

        Returns:
            Either[bio_exc.UseCaseError, Literal[True]]:
                Returns True on success or an error if discovery fails.
        """

        try:
            for column in self.__metadata_df.columns:
                if column not in self.__required_files:
                    return bio_exc.UseCaseError(
                        f"Required column does not exist in the metadata file: {column}",
                        exp=True,
                        logger=LOGGER,
                    )()

            if all(
                [
                    v not in SequencingTemplateEnum.get_values_list()
                    for v in self.__metadata_df.get("sequencing-template")
                ]
            ):
                return bio_exc.UseCaseError(
                    "Invalid value encountered in `sequencing-template` column.",
                    exp=True,
                    logger=LOGGER,
                )()

            for index, row in self.__metadata_df.iterrows():
                if index == 0:
                    continue

                sample_id = row.get("sample-id")

                forward_file = self.__get_fastq_file(
                    sample_id=sample_id,
                    direction=FastqDirectionEnum.FORWARD,
                )

                reverse_file = self.__get_fastq_file(
                    sample_id=sample_id,
                    direction=FastqDirectionEnum.REVERSE,
                )

                for file in [forward_file, reverse_file]:
                    if file.is_left:
                        return bio_exc.UseCaseError(
                            "Unexpected error while collecting FASTQ files.",
                            prev="",
                        )()

                self.__samples.append(
                    SampleConfig(
                        name=sample_id,
                        files=FastqFiles(
                            template=SequencingTemplateEnum.PAIRED_END,
                            forward_file=forward_file.value,
                            reverse_file=reverse_file.value,
                        ),
                        blast_database=self.__blast_database,
                    )
                )

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __get_fastq_file(
        self,
        sample_id: str,
        direction: FastqDirectionEnum,
    ) -> Either[bio_exc.UseCaseError, Path]:
        """Collect a single FASTQ file for a given sample and direction.

        Args:
            sample_id (str): Unique sample identifier.
            direction (FastqDirectionEnum): Direction of the read (FORWARD or REVERSE).

        Returns:
            Either[bio_exc.UseCaseError, Path]:
                Returns the path of the FASTQ file on success or an error otherwise.
        """
        try:
            file_glob = f"{sample_id}*{direction.value}*.fastq.gz"
            sample_blobs = list(self.__source_directory.glob(file_glob))

            if len(sample_blobs) != 1:
                return bio_exc.UseCaseError(
                    "The number of files matching the sample id is not 1: "
                    f"{file_glob}",
                    exp=True,
                    logger=LOGGER,
                )()

            return right(sample_blobs[0])

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __load_and_validate_metadata(
        self,
    ) -> Either[bio_exc.UseCaseError, DataFrame]:
        """Load and validate the metadata file content.

        Checks if the metadata file exists and then validates its content.

        Returns:
            Either[bio_exc.UseCaseError, DataFrame]:
                Returns the DataFrame containing the metadata on success or an error otherwise.
        """
        try:
            if not self.__metadata_file.is_file():
                return bio_exc.UseCaseError(
                    "`metadata_file` must be an existing file. "
                    f"The specified path does not exist: {self.__metadata_file}",
                    exp=True,
                    logger=LOGGER,
                )()

            self.__metadata_df = AnalysisConfig.validate_metadata_file_content(
                metadata_file=self.__source_directory.joinpath(
                    self.__metadata_file
                )
            )

            return right(self.__metadata_df)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()
