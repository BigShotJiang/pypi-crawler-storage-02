from asyncio import get_event_loop, new_event_loop, set_event_loop
from copy import deepcopy
from pathlib import Path
from typing import Any

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right

from mdv.domain.dtos.bootstrap_handler import (
    BootstrapHandler,
    MetadataColNamesEnum,
)
from mdv.domain.dtos.results_config import (
    QualityControlArtifacts,
    ResultsConfig,
    SampleResults,
)
from mdv.domain.dtos.analysis_config import (
    FastqFiles,
    SampleConfig,
    SequencingTemplateEnum,
)
from mdv.settings import LOGGER
from mdv.use_cases.shared.generate_output_artifact import (
    GenerateOutputArtifact,
)
from mdv.use_cases.shared.run_library_sample_effectiveness import (
    RarefactionParams,
    RunLibrarySampleEffectiveness,
)
from mdv.use_cases.shared.run_qc_on_single_sample import (
    QcStepParams,
    RunQualityControlOnSingleSample,
)
from mdv.use_cases.shared.core import (
    SingleStepPipelineRepositories,
)


class RunQualityControlOfRawSequencingData:
    __quality_control_artifacts: dict[str, QualityControlArtifacts] = dict()

    def __init__(
        self,
        source_directory: Path,
        work_directory: Path,
        bootstrap_handler: BootstrapHandler,
        repos: SingleStepPipelineRepositories,
        qc_params: QcStepParams = QcStepParams(),
        rarefy_params: RarefactionParams = RarefactionParams(),
        **_: Any,
    ):
        # ? Internal attributes
        self.__source_directory = source_directory
        self.__work_directory = work_directory
        self.__bootstrap_handler = bootstrap_handler
        self.__repos = repos

        # ? Trimming
        self.__qc_params = qc_params

        # ? Rarefaction
        self.__rarefy_params = rarefy_params

        # ? Initialize analysis artifacts
        self.__initialize_analysis_artifacts()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
    ) -> Either[bio_exc.UseCaseError, tuple[Path, Path]]:
        """Run quality checks.

        Description:
            This method is the main entry point of the use case. It is
            responsible for run all quality control steps on each sample of the
            sample set.

        """

        try:
            loop = get_event_loop()
        except RuntimeError:
            loop = new_event_loop()
            set_event_loop(loop)
        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

        try:
            samples_results: list[SampleResults] = list()

            for _, row in self.__bootstrap_handler.samples_map.iterrows():
                # ? ------------------------------------------------------------
                # ? Validate row content
                # ? ------------------------------------------------------------

                if (
                    sample_code := row.get(
                        MetadataColNamesEnum.SAMPLE_CODE.value
                    )
                ) is None:
                    return bio_exc.UseCaseError(
                        "Unexpected use error detected on run quality "
                        + f"control of sample: {sample_code}",
                    )()

                if (
                    fwd_file := row.get(MetadataColNamesEnum.FORWARD_FILE.value)
                ) is None:
                    return bio_exc.UseCaseError(
                        "Unexpected use error detected on run quality "
                        + f"control of sample: {fwd_file}",
                    )()

                if (
                    rev_file := row.get(MetadataColNamesEnum.REVERSE_FILE.value)
                ) is None:
                    return bio_exc.UseCaseError(
                        "Unexpected use error detected on run quality "
                        + f"control of sample: {rev_file}",
                    )()

                if (
                    qc_artifact := self.__quality_control_artifacts.get(
                        sample_code
                    )
                ) is None:
                    return bio_exc.UseCaseError(
                        "Unexpected use error detected on run quality "
                        + f"control of sample: {row.get(MetadataColNamesEnum.SAMPLE_CODE)}",
                    )()

                if (
                    sample_is_complex := row.get(
                        MetadataColNamesEnum.SAMPLE_TYPE_COMPLEX.value
                    )
                ) is None:
                    LOGGER.warning(
                        "Sample type was not defined. Assuming that the sample "
                        + "is complex."
                    )

                    sample_is_complex = True

                qc_params = deepcopy(self.__qc_params)

                qc_params.single_end_recovery_strategy = (
                    row.get(MetadataColNamesEnum.SINGLE_END_RECOVERY.value)
                    if self.__qc_params.single_end_recovery_strategy is None
                    else self.__qc_params.single_end_recovery_strategy
                )

                # ? ------------------------------------------------------------
                # ? Build and run quality control pipeline
                # ? ------------------------------------------------------------

                qc_runner = RunQualityControlOnSingleSample(
                    sample_code=sample_code,
                    forward_file_path=self.__bootstrap_handler.source_directory.joinpath(
                        fwd_file
                    ),
                    reverse_file_path=self.__bootstrap_handler.source_directory.joinpath(
                        rev_file
                    ),
                    source_directory=self.__source_directory,  # type: ignore
                    quality_control_artifacts=qc_artifact,
                    work_directory=self.__work_directory.joinpath(sample_code),
                    repos=self.__repos,
                    qc_params=qc_params,
                )

                qc_response: Either = qc_runner.run(loop=loop)  # type: ignore

                if qc_response.is_left:
                    LOGGER.exception(qc_response.value)
                    return bio_exc.UseCaseError(
                        "Unexpected use error detected on run quality "
                        + f"control of sample: {sample_code}",
                        prev=qc_response.value,
                    )()

                samples_results.append(
                    SampleResults(
                        specs=SampleConfig(
                            name=sample_code,
                            files=FastqFiles(
                                template=SequencingTemplateEnum.PAIRED_END,
                                forward_file=fwd_file,
                                reverse_file=rev_file,
                            ),
                            blast_database=None,
                            recovery_single_end=qc_params.single_end_recovery_strategy,
                            service_order=row.get(
                                MetadataColNamesEnum.SERVICE_ORDER.value
                            ),
                        ),
                        quality_control_artifacts=qc_artifact,
                    ),
                )

                if self.__rarefy_params.with_sample_effectiveness is True:
                    calculator = RunLibrarySampleEffectiveness(
                        work_directory=self.__work_directory.joinpath(
                            sample_code
                        ),
                        quality_control_artifacts=qc_artifact,
                        repos=self.__repos,
                        configs=self.__rarefy_params,
                        sample_is_complex=sample_is_complex,
                    )

                    if (run_either := calculator.run(loop=loop)).is_left:
                        return run_either

            output_generator = GenerateOutputArtifact(
                analysis_directory=self.__work_directory,
                custom_source_directory=self.__source_directory,
                results_set=ResultsConfig(
                    samples_results=samples_results,
                    aggregation_results=None,
                    taxonomy_results=None,
                    phylogenetic_results=None,
                    functional_annotation=None,
                ),
            )

            output_artifact_either = (
                output_generator.populate_partial_output_artifact()
            )

            if output_artifact_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on generate JSON output file.",
                    prev=output_artifact_either.value,
                    logger=LOGGER,
                )()

            (
                output_file_json,
                output_file_tsv,
            ) = output_artifact_either.value

            # ? ----------------------------------------------------------------
            # ? Return a positive response
            # ? ----------------------------------------------------------------

            return right(
                (
                    output_file_json,
                    output_file_tsv,
                )
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    # ? ------------------------------------------------------------------------
    # ? PRIVATE INSTANCE METHODS
    # ? ------------------------------------------------------------------------

    def __initialize_analysis_artifacts(self) -> None:
        try:
            for row in self.__bootstrap_handler.samples_map.itertuples(False):
                qc_artifact_either = QualityControlArtifacts.create(
                    sample=row.sample_code.__str__(),
                )

                if qc_artifact_either.is_left:
                    return qc_artifact_either

                self.__quality_control_artifacts.update(
                    {row.sample_code.__str__(): qc_artifact_either.value}
                )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()
