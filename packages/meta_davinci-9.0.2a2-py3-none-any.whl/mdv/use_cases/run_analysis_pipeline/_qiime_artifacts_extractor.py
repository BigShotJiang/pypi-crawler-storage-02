from pathlib import Path
from typing import Literal

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right

from mdv.settings import LOGGER
from mdv.use_cases.shared.core import (
    SingleStepPipelineRepositories,
)


class QiimeArtifactsExtractor:
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        single_step_repos: SingleStepPipelineRepositories,
    ) -> None:
        # ? --------------------------------------------------------------------
        # ? Initialize instance attributes
        # ? --------------------------------------------------------------------

        self._repos = single_step_repos

    # ? ------------------------------------------------------------------------
    # ? PRIVATE METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
        analysis_directory: Path,
        target_paths: dict[Path, list[str]],
    ) -> Either[bio_exc.UseCaseError, Literal[True]]:
        try:
            LOGGER.info("STARTED EXTRACTING ARTIFACTS")

            for folder, paths in target_paths.items():
                LOGGER.info(f"EXTRACTING ARTIFACTS FROM {folder}")

                for path in paths:
                    # ? Build the path of the destination directory and file
                    raw_folder = folder.joinpath("raw", path.split(".")[0])
                    raw_folder.mkdir(exist_ok=True, parents=True)

                    if all(
                        [
                            raw_folder.is_dir(),
                            len([i for i in raw_folder.iterdir()]) > 2,
                        ]
                    ):
                        LOGGER.info(f"Artifact already extracted: {path}")
                        continue

                    extraction_either = self.__extract_single_artifact_content(
                        artifact_path=Path(path),
                        artifact_directory=folder,
                        destination_directory=str(raw_folder),
                        analysis_directory=analysis_directory,
                    )

                    if extraction_either.is_left:
                        return bio_exc.UseCaseError(
                            "Unexpected error detected on extract results "
                            + f"artifact from {path}",
                            prev=extraction_either.value,
                            logger=LOGGER,
                        )()

            LOGGER.info("FINISHED EXTRACTING ARTIFACTS")

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    def __extract_single_artifact_content(
        self,
        artifact_path: Path,
        artifact_directory: Path,
        destination_directory: str,
        analysis_directory: Path,
    ) -> Either[bio_exc.UseCaseError, Literal[True]]:
        try:
            step_response = self._repos.export_artifact.execute(
                input_artifact=str(artifact_path),
                source_directory=artifact_directory,
                destination_directory=destination_directory,
                output_directory=str(artifact_directory),
                work_directory=Path(analysis_directory),
            )

            if step_response.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on export a single artifact.",
                    prev=step_response.value,
                    logger=LOGGER,
                )()

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()
