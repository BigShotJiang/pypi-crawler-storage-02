from __future__ import annotations

from asyncio import AbstractEventLoop, BaseEventLoop
from enum import Enum
from json import load
from pathlib import Path
from typing import Any, Generator

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from agrobase.enums import TaxaEnum

from mdv.domain.dtos import BlastFilesPair, ResultsConfig
from mdv.settings import LOGGER, NTNR_DATABASES
from mdv.use_cases.shared.core import (
    BaseInnerClasses,
    BaseOuterClass,
    CallableLifeCycleHooks,
    CallableOutput,
    OnExitResponse,
    OnInitResponse,
    SingleSamplePipelineResponse,
    SingleStepPipelineRepositories,
    StepOutput,
)


class TaxAssignmentTools(Enum):
    BIO_LINNAEUS = "bio-linnaeus"
    BLUTILS = "blutils"

    @classmethod
    def _missing_(cls, _: object) -> Any:
        return cls.BLUTILS


class AssignTaxonomyFromBlast:
    """Perform a taxonomic attribution using a BlastN search."""

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        work_directory: Path,
        results_set: ResultsConfig,
        repos: SingleStepPipelineRepositories,
        blast_database: BlastFilesPair,
        taxon: TaxaEnum,
        tax_assignment_tool: TaxAssignmentTools = TaxAssignmentTools(None),
    ) -> None:
        # ? Protected/Internal attributes
        self._work_directory: Path = Path(work_directory)
        self._results_set: ResultsConfig = results_set
        self._repos: SingleStepPipelineRepositories = repos
        self._blast_database: BlastFilesPair = blast_database
        self._taxon = taxon
        self._tax_assignment_tool = tax_assignment_tool

        # ? Composite inner classes
        self._taxonomy_steps = self.__TaxonomySteps(out=self)

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
        loop: BaseEventLoop | AbstractEventLoop,
    ) -> Either[bio_exc.UseCaseError, SingleSamplePipelineResponse]:
        return BaseOuterClass(logger=LOGGER).run_steps_sequentially(
            loop=loop,
            group=self._results_set.taxonomy_results.folder,
            destination_directory=self._results_set.taxonomy_results.folder,
            steps=self._taxonomy_steps,
            steps_group_name="Taxonomy Assignment",
            start_log_message="START TAX ASSIGNMENT",
            stop_log_message="FINISH TAX ASSIGNMENT",
        )

    # ? ------------------------------------------------------------------------
    # ? INNER CLASSES
    # ? ------------------------------------------------------------------------

    class __TaxonomySteps(BaseInnerClasses):
        # ? --------------------------------------------------------------------
        # ? INNER CLASS LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __init__(
            self,
            out: AssignTaxonomyFromBlast,
        ) -> None:
            # ? Outer class instance
            self.__out = out

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PUBLIC METHODS
        # ? --------------------------------------------------------------------

        def generate_steps(self) -> Generator[CallableOutput, None, None]:  # type: ignore
            if self.__out._tax_assignment_tool == TaxAssignmentTools.BLUTILS:
                return super().generate_steps(
                    steps=[
                        CallableOutput(
                            step_callable=self.__assign_taxonomy_with_blu,
                            step_artifacts=self.__out._results_set.taxonomy_results,  # type: ignore
                            life_cycle_hooks=CallableLifeCycleHooks(
                                on_exit=self.__ehook_parse_blutils_output_file,
                            ),
                        ),
                    ]
                )

            return super().generate_steps(
                steps=[
                    CallableOutput(
                        step_callable=self.__assign_taxonomy_with_bli,
                        step_artifacts=self.__out._results_set.taxonomy_results,  # type: ignore
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_init=self.__ihook_check_input_files,
                        ),
                    ),
                ]
            )

        # ? --------------------------------------------------------------------
        # ? INNER CLASS LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __ihook_check_input_files(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check the minimum requirements for MSA file building.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[OnInitResponse]]: A
                    positive response if all requirements for the MSA building
                    were satisfied.
            """

            try:
                artifact_path: Path = self.__out._work_directory.joinpath(
                    self.__out._results_set.aggregation_results.folder,
                    self.__out._results_set.aggregation_results.raw_fasta,
                )

                if not artifact_path.is_file():
                    return right(
                        OnInitResponse(
                            can_continue=False,
                            message=(
                                "On-Init hook: Formatted data file not created."
                            ),
                        )
                    )

                with artifact_path.open() as fasta:
                    header = fasta.readline().strip()
                    sequence = fasta.readline().strip()

                    if all(
                        [
                            header.startswith(">"),
                            len(header) > 2,
                            len(sequence) > 2,
                        ]
                    ):
                        return right(OnInitResponse(can_continue=True))

                return right(
                    OnInitResponse(
                        can_continue=False,
                        message=(
                            "On-Init hook: Not enough sequences left after "
                            + "dereplication step."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ehook_parse_blutils_output_file(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check the minimum requirements for MSA file building.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[OnInitResponse]]: A
                    positive response if all requirements for the MSA building
                    were satisfied.
            """

            try:
                artifact_path: Path = self.__out._work_directory.joinpath(
                    self.__out._results_set.taxonomy_results.folder,
                    self.__out._results_set.taxonomy_results.blu_raw_output,
                )

                if not artifact_path.is_file():
                    return right(
                        OnInitResponse(
                            can_continue=False,
                            message=(
                                f"On-Exit hook: Blutils output artifact not found ({artifact_path})"
                            ),
                        )
                    )

                content = None
                with artifact_path.open() as response:
                    content = load(response)

                    if not isinstance(content, list):
                        return right(
                            OnInitResponse(
                                can_continue=False,
                                message=(
                                    "On-Exit hook: Blutils output artifact is not a list."
                                ),
                            )
                        )

                parsed_content: list[str] = []

                for record in content:
                    if (query := record.pop("query")) is None:
                        return right(
                            OnExitResponse(
                                can_continue=False,
                                message=(
                                    "On-Exit hook: Unable to find query in Blutils output."
                                ),
                            )
                        )

                    query = query.split(";")[0]

                    if (taxon := record.pop("taxon")) is None:
                        parsed_content.append(f"{query}\tUnidentified\t0")
                        continue

                    if (taxonomy := taxon.pop("taxonomy")) is None:
                        return right(
                            OnExitResponse(
                                can_continue=False,
                                message=(
                                    "On-Exit hook: Unable to find taxonomy in Blutils output."
                                ),
                            )
                        )

                    if (perc_identity := taxon.pop("percIdentity")) is None:
                        return right(
                            OnExitResponse(
                                can_continue=False,
                                message=(
                                    "On-Exit hook: Unable to find percIdentity in Blutils output."
                                ),
                            )
                        )

                    parsed_content.append(
                        f"{query}\t{taxonomy}\t{perc_identity}"
                    )

                with self.__out._work_directory.joinpath(
                    self.__out._results_set.taxonomy_results.folder,
                    self.__out._results_set.taxonomy_results.blu_output,
                ).open("w") as response:
                    response.write("Feature ID\tTaxon\tPerfSimilarity\n")
                    response.write("\n".join(parsed_content))

                return right(OnExitResponse(can_continue=True))

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PRIVATE METHODS
        # ? --------------------------------------------------------------------

        def __assign_taxonomy_with_bli(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Annotate taxonomies with BioLinnaeus.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.assign_taxonomy_with_bli_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    input_source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.aggregation_results.folder,
                    ),
                    databases_source_directory=NTNR_DATABASES,
                    input_repr_seqs_artifact=self.__out._results_set.aggregation_results.raw_fasta,
                    reference_reads=self.__out._blast_database.sequences_file_name,
                    reference_taxonomy=self.__out._blast_database.taxonomies_file_name,
                    output_classification=self.__out._results_set.taxonomy_results.bli_output,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute taxonomy picking step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __assign_taxonomy_with_blu(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Annotate taxonomies with Blutils.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.assign_taxonomy_with_blu_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    input_source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.aggregation_results.folder,
                    ),
                    databases_source_directory=NTNR_DATABASES,
                    input_repr_seqs_artifact=self.__out._results_set.aggregation_results.raw_fasta,
                    reference_reads=self.__out._blast_database.sequences_file_name,
                    reference_taxonomy=self.__out._blast_database.taxonomies_file_name,
                    output_classification=self.__out._results_set.taxonomy_results.blu_raw_output,
                    work_directory=self.__out._work_directory,
                    taxon=self.__out._taxon,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute taxonomy picking step.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()
