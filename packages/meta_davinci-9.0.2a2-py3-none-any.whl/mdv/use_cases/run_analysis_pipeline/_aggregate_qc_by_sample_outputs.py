from pathlib import Path
from typing import Dict, Literal

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from pandas import DataFrame, concat

from mdv.domain.dtos import ResultsConfig
from mdv.domain.utils import create_lock_file, has_lock_file
from mdv.settings import LOGGER


class AggregateQualityControlOutputs:
    """Aggregate outputs of multiple samples quality controls."""

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        work_directory: Path,
        results_set: ResultsConfig,
    ) -> None:
        self._work_directory: Path = Path(work_directory)
        self._results_set: ResultsConfig = results_set

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
    ) -> Either[type[bio_exc.MappedErrors], Literal[True]]:
        try:
            LOGGER.info("STEP STARTED: aggregating sample results")

            # ? ----------------------------------------------------------------
            # ? Build IO paths and variables
            # ? ----------------------------------------------------------------

            feature_table: DataFrame = None

            output_dir: Path = self._work_directory.joinpath(
                self._results_set.aggregation_results.folder,
            )

            if not output_dir.is_dir():
                output_dir.mkdir(parents=True, exist_ok=True)

            freq_table_path = output_dir.joinpath(
                self._results_set.aggregation_results.frequency_table,
            )

            raw_fasta_path = output_dir.joinpath(
                self._results_set.aggregation_results.raw_fasta,
            )

            # ? ----------------------------------------------------------------
            # ? Check lock file.
            #
            # The lock file indicate that the current step was also executed,
            # thus if the `lock` variable is `True` after execution of the
            # `has_lock_file` function, the current step execution will be
            # already finished with a positive response.
            # ? ----------------------------------------------------------------

            lock_either = has_lock_file(
                step_directory=output_dir,
                logger=LOGGER,
            )

            if lock_either.is_left:
                return bio_exc.ExecutionError(  # type: ignore
                    "Unexpected error detected on check lock file.",
                    prev=lock_either.value,
                    logger=LOGGER,
                )()

            lock: bool = lock_either.value  # type: ignore

            if lock is True:
                LOGGER.info("Lock file find. Skip step")
                LOGGER.info("STEP FINISHED: aggregating sample results")
                return right(True)

            # ? ----------------------------------------------------------------
            # ? Populate frequency table content
            # ? ----------------------------------------------------------------

            LOGGER.info("Populating sample contents")

            for sample in self._results_set.samples_results:
                LOGGER.info(f"Populating from: {sample.specs.name}")

                sample_df: DataFrame = None

                input_sequences = self._work_directory.joinpath(
                    sample.specs.name,
                    sample.quality_control_artifacts.folder,
                    sample.quality_control_artifacts.output_polish.folder,
                    sample.quality_control_artifacts.output_polish.polished_sequences,
                )

                if input_sequences.is_file():
                    headers_either = self.__import_fasta_headers(
                        fasta_path=input_sequences,
                        sample_name=sample.specs.name,
                    )

                    if headers_either.is_left:
                        return bio_exc.CreationError(  # type: ignore
                            "Unexpected error detected on parse headers "
                            + "frequencies as a pandas DataFrame.",
                            prev=headers_either.value,
                            logger=LOGGER,
                        )()

                    sample_df = headers_either.value

                else:
                    sample_df = DataFrame(columns=[sample.specs.name])

                if feature_table is None:
                    feature_table = sample_df
                    continue

                feature_table = concat(
                    [
                        feature_table,
                        sample_df,
                    ],
                    axis=1,
                )

            # ? ----------------------------------------------------------------
            # ? Persist raw FASTA content
            # ? ----------------------------------------------------------------

            LOGGER.info("Writing aggregated fasta:")
            LOGGER.info(f"\t{raw_fasta_path}")

            with raw_fasta_path.open("w+") as out:
                for seq in [f">{h}\n{s}\n" for h, s in feature_table.index]:
                    out.write(seq)

            # ? ----------------------------------------------------------------
            # ? Persist feature table content
            # ? ----------------------------------------------------------------

            LOGGER.info("Writing aggregated frequency table:")
            LOGGER.info(f"\t{raw_fasta_path}")

            feature_table.index = [i[0] for i in feature_table.index]

            feature_table.fillna("0").astype(int).to_csv(
                freq_table_path, sep="\t"
            )

            # ? ----------------------------------------------------------------
            # ? Lock directory
            #
            # Create the lock file in output directory indicating that the
            # analysis was successfully done.
            # ? ----------------------------------------------------------------

            lock_either = create_lock_file(  # type: ignore
                step_directory=output_dir,
                logger=LOGGER,
            )

            if lock_either.is_left:  # type: ignore
                return bio_exc.ExecutionError(  # type: ignore
                    "Unexpected error detected on create lock file.",
                    prev=lock_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Return a positive response
            # ? ----------------------------------------------------------------

            LOGGER.info("STEP FINISHED: aggregating sample results")

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def __import_fasta_headers(
        self,
        sample_name: str,
        fasta_path: Path,
    ) -> Either[bio_exc.UseCaseError, DataFrame]:
        try:
            if not fasta_path.is_file():
                return bio_exc.UseCaseError(
                    "Invalid FASTA path.",
                    exp=True,
                    logger=LOGGER,
                )()

            fasta_headers_dict: Dict[tuple[str, str], int] = {}

            with fasta_path.open() as fasta:
                header: str | None = None
                sequence: str | None = None

                while True:
                    header = fasta.readline().strip()
                    sequence = fasta.readline().strip()

                    if len(header) == 0:
                        break

                    if not header.startswith(">"):
                        return bio_exc.UseCaseError(
                            f"FASTA file has invalid header: {header}",
                            exp=True,
                            logger=LOGGER,
                        )()

                    try:
                        header, count = header.replace(">", "").split(";")
                        count = count.split("=")[1]
                    except ValueError as exc:
                        return bio_exc.UseCaseError(
                            f"FASTA records should have the count implicit "
                            + f"in headers: {header}",
                            exp=True,
                            logger=LOGGER,
                        )()

                    fasta_headers_dict.update({(header, sequence): int(count)})

            return right(
                DataFrame.from_dict(
                    fasta_headers_dict,
                    orient="index",
                    columns=[sample_name],
                )
            )

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()
