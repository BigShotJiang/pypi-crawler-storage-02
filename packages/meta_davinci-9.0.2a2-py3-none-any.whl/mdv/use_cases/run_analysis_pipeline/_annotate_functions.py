from __future__ import annotations

from asyncio import AbstractEventLoop, BaseEventLoop
from pathlib import Path
from typing import Generator

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from agrobase.enums import TaxaEnum

from mdv.domain.dtos import ResultsConfig
from mdv.domain.dtos.config_handler import StepDTO
from mdv.settings import LOGGER
from mdv.use_cases.shared.core import (
    BaseInnerClasses,
    BaseOuterClass,
    CallableOutput,
    SingleSamplePipelineResponse,
    SingleStepPipelineRepositories,
    StepOutput,
)


class AnnotateFunctions:
    """Perform function annotation based on PICRUSt2 output."""

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        work_directory: Path,
        results_set: ResultsConfig,
        repos: SingleStepPipelineRepositories,
        taxa: TaxaEnum,
        step_by_step: bool = True,
        chunk_size: int = 2000,
    ) -> None:
        # ? Protected/Internal attributes
        self._work_directory = Path(work_directory)
        self._results_set = results_set
        self._repos = repos
        self._taxa = taxa
        self._step_by_step = step_by_step
        self._chunk_size = chunk_size

        # ? Composite inner classes
        self._function_annotation_steps = self.__FunctionalAnnotation(out=self)

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
        loop: BaseEventLoop | AbstractEventLoop,
    ) -> Either[bio_exc.UseCaseError, SingleSamplePipelineResponse]:
        # This logic should be called on try to execute the full picrust
        # pipeline.
        if self._step_by_step is False:
            return BaseOuterClass(logger=LOGGER).run_steps_sequentially(
                loop=loop,
                group=self._results_set.functional_annotation.folder,
                destination_directory=self._results_set.functional_annotation.folder,
                steps=self._function_annotation_steps,
                steps_group_name="Functional annotation with PICRUSt2",
                start_log_message="START FUNCTIONAL ANNOTATION",
                stop_log_message="FINISH FUNCTIONAL ANNOTATION",
            )

        try:
            LOGGER.info("START FUNCTIONAL ANNOTATION")
            steps: BaseInnerClasses = self._function_annotation_steps
            step: CallableOutput

            for step in steps.generate_steps():  # type: ignore
                step_either = BaseOuterClass(logger=LOGGER).run_single_step(
                    group=self._results_set.functional_annotation.folder,
                    destination_directory=(
                        f"{self._results_set.functional_annotation.folder}/{step.step_artifacts.folder}"  # type: ignore
                    ),
                    step=step,
                    loop=loop,
                )

                if step_either.is_left:
                    return bio_exc.UseCaseError(
                        "Unexpected error detected on execute use case.",
                        prev=step_either.value,
                        logger=LOGGER,
                    )()

                if step_either.value is False:
                    return right(
                        SingleSamplePipelineResponse(
                            finished_execution=False,
                            execution_message=(
                                "Functional annotation execution finished prematurely. "
                                + "This behavioral could be due to hook "
                                + "(`on_init` or `on_exit`) validations that "
                                + "were not satisfied."
                            ),
                        )
                    )

            LOGGER.info("FINISH THE FUNCTIONAL ANNOTATION")

            return right(SingleSamplePipelineResponse(finished_execution=True))

        except Exception as exc:
            return exc

    # ? ------------------------------------------------------------------------
    # ? INNER CLASSES
    # ? ------------------------------------------------------------------------

    class __FunctionalAnnotation(BaseInnerClasses):
        # ? --------------------------------------------------------------------
        # ? INNER CLASS LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __init__(
            self,
            out: AnnotateFunctions,
        ) -> None:
            # ? Outer class instance
            self.__out = out

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PUBLIC METHODS
        # ? --------------------------------------------------------------------

        def generate_steps(self) -> Generator[CallableOutput, None, None]:  # type: ignore
            if self.__out._step_by_step is True:
                return super().generate_steps(
                    steps=[
                        CallableOutput(
                            step_callable=self.__place_sequences_in_phylogeny,
                            step_artifacts=self.__out._results_set.functional_annotation.sequences_placement,
                        ),
                        CallableOutput(
                            step_callable=self.__predict_hidden_state_of_marker,
                            step_artifacts=self.__out._results_set.functional_annotation.hsp_prediction_function,
                        ),
                        CallableOutput(
                            step_callable=self.__predict_hidden_state_of_function,
                            step_artifacts=self.__out._results_set.functional_annotation.hsp_prediction_marker,
                        ),
                        CallableOutput(
                            step_callable=self.__run_metagenome_pipeline,
                            step_artifacts=self.__out._results_set.functional_annotation.metagenome_pipeline,
                        ),
                    ]
                )

            return super().generate_steps(
                steps=[
                    CallableOutput(
                        step_callable=self.__run_picrust_pipeline,
                        step_artifacts=self.__out._results_set.functional_annotation,  # type: ignore
                    ),
                ]
            )

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PRIVATE METHODS
        # ? --------------------------------------------------------------------

        def __run_picrust_pipeline(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Execute the entire picrust pipeline.

            Args:
                group (str): The group name.
                destination_directory (str): The destination directory.

            Returns:
                Either[bio_exc.UseCaseError, StepOutputDTO]: The step output
                    data transfer object.

            """

            try:
                step_response = self.__out._repos.function_annotation_exec_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.aggregation_results.folder,
                    ),
                    input_fasta_sequences=self.__out._results_set.aggregation_results.raw_fasta,
                    input_frequency_table=self.__out._results_set.aggregation_results.frequency_table,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute gene families estimation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __place_sequences_in_phylogeny(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Place sequences in the tree of life.

            Args:
                group (str): The group name.
                destination_directory (str): The destination directory.

            Returns:
                Either[bio_exc.UseCaseError, StepOutputDTO]: The step output

            """

            try:
                step_response = self.__out._repos.place_sequences_in_tree_of_life_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.aggregation_results.folder,
                    ),
                    input_fasta_sequences=self.__out._results_set.aggregation_results.raw_fasta,
                    output_tree=self.__out._results_set.functional_annotation.sequences_placement.output_tree,
                    work_directory=self.__out._work_directory,
                    taxa=self.__out._taxa,
                    chunk_size=self.__out._chunk_size,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute sequences placement.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.placed_seqs_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __predict_hidden_state_of_marker(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Predict hidden state of marker.

            Args:
                group (str): The group name.
                destination_directory (str): The destination directory.

            Returns:
                Either[bio_exc.UseCaseError, StepOutputDTO]: The step output

            """

            try:
                step_response = self.__out._repos.hidden_state_prediction_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.placed_seqs_step_dto.output_dir,
                    ),
                    input_tree=self.__out._results_set.functional_annotation.sequences_placement.output_tree,
                    output_prediction=self.__out._results_set.functional_annotation.hsp_prediction_marker.predicted_marker,
                    work_directory=self.__out._work_directory,
                    taxa=self.__out._taxa,
                    is_ec=False,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on predict hidden state of marker.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.marker_hidden_state_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __predict_hidden_state_of_function(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Predict hidden state of function.

            Args:
                group (str): The group name.
                destination_directory (str): The destination directory.

            Returns:
                Either[bio_exc.UseCaseError, StepOutputDTO]: The step output

            """

            try:
                step_response = self.__out._repos.hidden_state_prediction_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.placed_seqs_step_dto.output_dir,
                    ),
                    input_tree=self.__out._results_set.functional_annotation.sequences_placement.output_tree,
                    output_prediction=self.__out._results_set.functional_annotation.hsp_prediction_function.predicted_function,
                    work_directory=self.__out._work_directory,
                    taxa=self.__out._taxa,
                    is_ec=True,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on predict hidden state of function.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                self.function_hidden_state_step_dto: StepDTO = step_response.value.instance  # type: ignore

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __run_metagenome_pipeline(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Run metagenome pipeline.

            Args:
                group (str): The group name.
                destination_directory (str): The destination directory.

            Returns:
                Either[bio_exc.UseCaseError, StepOutputDTO]: The step output

            """

            try:
                step_response = self.__out._repos.metagenome_pipeline_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory_freq_table=self.__out._work_directory.joinpath(
                        self.__out._results_set.aggregation_results.folder,
                    ),
                    source_directory_hsp_marker=self.__out._work_directory.joinpath(
                        self.marker_hidden_state_step_dto.output_dir,
                    ),
                    source_directory_hsp_function=self.__out._work_directory.joinpath(
                        self.function_hidden_state_step_dto.output_dir,
                    ),
                    input_frequency_table=self.__out._results_set.aggregation_results.frequency_table,
                    input_function_table=self.__out._results_set.functional_annotation.function_prediction,
                    input_marker_table=self.__out._results_set.functional_annotation.marker_prediction,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on run metagenome pipeline.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()
