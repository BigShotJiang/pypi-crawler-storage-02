from __future__ import annotations

from asyncio import AbstractEventLoop, BaseEventLoop
from itertools import zip_longest
from pathlib import Path
from typing import Any, Generator

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from pandas import read_csv
from uuid import uuid4

from mdv.domain.dtos import ResultsConfig
from mdv.domain.dtos.bootstrap_handler import MetadataColNamesEnum
from mdv.settings import LOGGER
from mdv.use_cases.shared.core import (
    BaseInnerClasses,
    BaseOuterClass,
    CallableLifeCycleHooks,
    CallableOutput,
    OnInitResponse,
    SingleSamplePipelineResponse,
    SingleStepPipelineRepositories,
    StepOutput,
)


class CalculatePhylogeneticDiversity:
    """Generate a base phylogeny and calculate diversity indices."""

    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        work_directory: Path,
        results_set: ResultsConfig,
        repos: SingleStepPipelineRepositories,
        metadata_artifact: Path,
        legacy_metadata: bool = False,
    ) -> None:
        # ? Protected/Internal attributes
        self._work_directory: Path = Path(work_directory)
        self._results_set: ResultsConfig = results_set
        self._repos: SingleStepPipelineRepositories = repos
        self._metadata_artifact = metadata_artifact
        self._legacy_metadata = legacy_metadata

        # ? Composite inner classes
        self._phylogeny_steps = self.__Phylogeny(out=self)

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run(
        self,
        loop: BaseEventLoop | AbstractEventLoop,
    ) -> Either[bio_exc.UseCaseError, SingleSamplePipelineResponse]:
        return BaseOuterClass(logger=LOGGER).run_steps_sequentially(
            loop=loop,
            group=self._results_set.phylogenetic_results.folder,
            steps=self._phylogeny_steps,
            steps_group_name="Phylogenetic Diversity Calculation",
            start_log_message="START PHYLO-DIVERSITY",
            stop_log_message="FINISH PHYLO-DIVERSITY",
        )

    # ? ------------------------------------------------------------------------
    # ? INNER CLASSES
    # ? ------------------------------------------------------------------------

    class __Phylogeny(BaseInnerClasses):
        # ? --------------------------------------------------------------------
        # ? INNER CLASS ATTRIBUTES
        # ? --------------------------------------------------------------------

        __qiime_metadata_artifact: Path = Path(f"metadata-{uuid4()}.tsv")
        __max_depth: int | None = None

        # ? --------------------------------------------------------------------
        # ? INNER CLASS LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __init__(
            self,
            out: CalculatePhylogeneticDiversity,
        ) -> None:
            # ? Outer class instance
            self.__out = out

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PUBLIC METHODS
        # ? --------------------------------------------------------------------

        def generate_steps(self) -> Generator[CallableOutput, None, None]:  # type: ignore
            return super().generate_steps(
                steps=[
                    CallableOutput(
                        step_callable=self.__import_feature_table_from_tsv,
                        step_artifacts=self.__out._results_set.phylogenetic_results.pre_build,  # type: ignore
                    ),
                    CallableOutput(
                        step_callable=self.__import_feature_table_from_biom,
                        step_artifacts=self.__out._results_set.phylogenetic_results.pre_build,  # type: ignore
                    ),
                    CallableOutput(
                        step_callable=self.__import_raw_sequences,
                        step_artifacts=self.__out._results_set.phylogenetic_results.pre_build,  # type: ignore
                    ),
                    CallableOutput(
                        step_callable=self.__import_blast_output,
                        step_artifacts=self.__out._results_set.phylogenetic_results.pre_build,  # type: ignore
                    ),
                    CallableOutput(
                        step_callable=self.__align_and_generate_phylogeny,
                        step_artifacts=(
                            self.__out._results_set.phylogenetic_results.phylogeny  # type: ignore
                        ),
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_init=self.__ihook_could_build_msa_alignment,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__filter_diversity_results,
                        step_artifacts=self.__out._results_set.phylogenetic_results.eco_diversity,  # type: ignore
                    ),
                    CallableOutput(
                        step_callable=self.__build_rarefaction_curve,
                        step_artifacts=(
                            self.__out._results_set.phylogenetic_results.alpha_rarefaction  # type: ignore
                        ),
                        life_cycle_hooks=CallableLifeCycleHooks(
                            on_init=self.__ihook_adjust_max_depth_and_build_metadata_table,
                        ),
                    ),
                    CallableOutput(
                        step_callable=self.__calculate_phylogenetic_alpha_diversity,
                        step_artifacts=(
                            self.__out._results_set.phylogenetic_results.alpha_diversity  # type: ignore
                        ),
                    ),
                ]
            )

        # ? --------------------------------------------------------------------
        # ? INNER CLASS LIFE CYCLE HOOKS
        # ? --------------------------------------------------------------------

        def __ihook_could_build_msa_alignment(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            """Check the minimum requirements for MSA file building.

            Returns:
                Either[Left[bio_exc.MappedErrors], Right[OnInitResponse]]: A
                    positive response if all requirements for the MSA building
                    were satisfied.
            """

            try:
                input_fasta_path: Path = self.__out._work_directory.joinpath(
                    self.__out._results_set.aggregation_results.folder,
                    self.__out._results_set.aggregation_results.raw_fasta,
                )

                if not input_fasta_path.is_file():
                    return bio_exc.UseCaseError(
                        f"Invalid path for FASTA file: {input_fasta_path}",
                        logger=LOGGER,
                    )()

                counter = 0
                with input_fasta_path.open() as fasta:
                    header: str

                    for header, _ in zip_longest(*[fasta] * 2):  # type: ignore
                        header = header.strip()

                        if not header.startswith(">"):
                            return right(
                                OnInitResponse(
                                    can_continue=False,
                                    message=f"Invalid fasta header: {header}",
                                )
                            )

                        counter += 1
                        if counter > 1:
                            return right(OnInitResponse(can_continue=True))

                return right(
                    OnInitResponse(
                        can_continue=False,
                        message=(
                            "On-Init hook would not be able to classify the "
                            + "multiple sequence file as a valid FASTA file."
                        ),
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __ihook_adjust_max_depth_and_build_metadata_table(
            self,
            **_: Any,
        ) -> Either[bio_exc.UseCaseError, OnInitResponse]:
            try:
                # ? ------------------------------------------------------------
                # ? Adjust max depth
                # ? ------------------------------------------------------------

                input_frequency_table: Path = self.__out._work_directory.joinpath(
                    self.__out._results_set.aggregation_results.folder,
                    self.__out._results_set.aggregation_results.frequency_table,
                )

                if not input_frequency_table.is_file():
                    return bio_exc.UseCaseError(
                        f"Invalid path for FASTA file: {input_frequency_table}",
                        logger=LOGGER,
                    )()

                feature_table_df = read_csv(
                    input_frequency_table, sep="\t", index_col=[0]
                )

                self.__max_depth = int(feature_table_df.max(axis=0).max())

                if self.__max_depth <= 1:
                    return right(
                        OnInitResponse(
                            can_continue=False,
                            message=(
                                "On-Init hook would not be able to determine the "
                                + "the maximum depth for analysis results."
                            ),
                        )
                    )

                # ? ------------------------------------------------------------
                # ? Build metadata table
                # ? ------------------------------------------------------------

                metadata_headers = "\n".join(
                    [
                        "sample-id\tsequencing-template",
                        "#q2:types\tcategorical\n",
                    ]
                )

                metadata_body = "\n".join(
                    [
                        f"{row.get(MetadataColNamesEnum.SAMPLE_CODE.value)}\tpe"
                        for _, row in read_csv(
                            self.__out._metadata_artifact, sep="\t"
                        ).iterrows()
                    ]
                )

                tmp_metadata_artifact = (
                    self.__out._metadata_artifact.parent.joinpath(
                        self.__qiime_metadata_artifact
                    )
                )

                LOGGER.debug(
                    f"Temporary metadata artifact: {tmp_metadata_artifact}"
                )

                with tmp_metadata_artifact.open("+w") as mf:
                    mf.write(metadata_headers)
                    mf.write(metadata_body)

                # ? ------------------------------------------------------------
                # ? Return a positive response for OnInit hook
                # ? ------------------------------------------------------------

                return right(OnInitResponse(can_continue=True))

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        # ? --------------------------------------------------------------------
        # ? INNER CLASS PRIVATE METHODS
        # ? --------------------------------------------------------------------

        def __import_feature_table_from_tsv(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Build the input artifact from TSV file.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.import_from_tsv_artifacts.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.aggregation_results.folder,
                    ),
                    input_file=(
                        self.__out._results_set.aggregation_results.frequency_table
                    ),
                    output_artifact_name=(
                        self.__out._results_set.phylogenetic_results.pre_build.frequency_table_tsv
                    ),
                    skip_lock_file=True,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __import_feature_table_from_biom(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Build the input artifact from BIOM file.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.import_from_biom_artifacts.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.phylogenetic_results.folder,
                        self.__out._results_set.phylogenetic_results.pre_build.folder,
                    ),
                    input_file=(
                        self.__out._results_set.phylogenetic_results.pre_build.frequency_table_tsv
                    ),
                    output_artifact_name=(
                        self.__out._results_set.phylogenetic_results.pre_build.frequency_table_biom
                    ),
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __import_raw_sequences(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Import raw sequences from aggregation step.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.import_raw_fasta_artifact.execute(
                    group=group,
                    destination_directory=destination_directory,
                    input_source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.aggregation_results.folder,
                    ),
                    input_sequences=self.__out._results_set.aggregation_results.raw_fasta,
                    output_artifact=self.__out._results_set.phylogenetic_results.pre_build.raw_fasta_file,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __import_blast_output(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Import blast output from blast step.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                blast_output: Path

                if self.__out._work_directory.joinpath(
                    self.__out._results_set.taxonomy_results.folder,
                    self.__out._results_set.taxonomy_results.bli_output,
                ).is_file():
                    blast_output = (
                        self.__out._results_set.taxonomy_results.bli_output
                    )
                elif self.__out._work_directory.joinpath(
                    self.__out._results_set.taxonomy_results.folder,
                    self.__out._results_set.taxonomy_results.blu_output,
                ).is_file():
                    blast_output = (
                        self.__out._results_set.taxonomy_results.blu_output
                    )
                else:
                    return bio_exc.UseCaseError(
                        "Unable to find blast output file inside folder: "
                        + f"{self.__out._results_set.taxonomy_results}",
                        logger=LOGGER,
                    )()

                step_response = self.__out._repos.import_blast_output_artifact.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.taxonomy_results.folder,
                    ),
                    input_file=blast_output,
                    output_artifact_name=self.__out._results_set.phylogenetic_results.pre_build.blast_output,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __align_and_generate_phylogeny(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Align sequences and generate phylogeny.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.phylogeny_generation_exec_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    input_source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.phylogenetic_results.folder,
                        self.__out._results_set.phylogenetic_results.pre_build.folder,
                    ),
                    input_repr_seqs_artifact=self.__out._results_set.phylogenetic_results.pre_build.raw_fasta_file,
                    output_raw_alignment=self.__out._results_set.phylogenetic_results.phylogeny.alignment_raw,
                    output_masked_alignment=self.__out._results_set.phylogenetic_results.phylogeny.alignment_masked,
                    output_unrooted_tree=self.__out._results_set.phylogenetic_results.phylogeny.tree_unrooted,
                    output_rooted_tree=self.__out._results_set.phylogenetic_results.phylogeny.tree_rooted,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __filter_diversity_results(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Filter diversity results.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.diversity_filtration_exec_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    source_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.phylogenetic_results.folder,
                        self.__out._results_set.phylogenetic_results.pre_build.folder,
                    ),
                    input_freq_table_artifact=self.__out._results_set.phylogenetic_results.pre_build.frequency_table_biom,
                    input_blast_results_artifact=self.__out._results_set.phylogenetic_results.pre_build.blast_output,
                    output_filtered_table_artifact=self.__out._results_set.phylogenetic_results.eco_diversity.filtered_table,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __build_rarefaction_curve(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Rarefy diversity results.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.diversity_rarefaction_exec_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    input_taxonomy_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.phylogenetic_results.folder,
                        self.__out._results_set.phylogenetic_results.pre_build.folder,
                    ),
                    input_phylogeny_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.phylogenetic_results.folder,
                        self.__out._results_set.phylogenetic_results.phylogeny.folder,
                    ),
                    input_metadata_directory=self.__out._metadata_artifact.parent,
                    input_taxonomy_artifact=self.__out._results_set.phylogenetic_results.pre_build.frequency_table_biom,
                    input_phylogeny_artifact=self.__out._results_set.phylogenetic_results.phylogeny.tree_rooted,
                    input_metadata_artifact=(
                        self.__out._metadata_artifact
                        if self.__out._legacy_metadata is True
                        else self.__qiime_metadata_artifact
                    ).name,
                    output_rarefaction_artifact=self.__out._results_set.phylogenetic_results.alpha_rarefaction.rarefied,
                    max_depth=self.__max_depth,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()

        def __calculate_phylogenetic_alpha_diversity(
            self,
            group: str,
            destination_directory: str,
        ) -> Either[bio_exc.UseCaseError, StepOutput]:
            """Calculate phylogenetic diversity indexes.

            Returns:
                Either[Left[bio_exc.UseCaseError], Right[__StepOutputDTO]] A
                    literal `True` if all step execution is successfully done.
            """

            try:
                step_response = self.__out._repos.diversity_indexes_calculation_exec_repo.execute(
                    group=group,
                    destination_directory=destination_directory,
                    input_taxonomy_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.phylogenetic_results.folder,
                        self.__out._results_set.phylogenetic_results.pre_build.folder,
                    ),
                    input_phylogeny_directory=self.__out._work_directory.joinpath(
                        self.__out._results_set.phylogenetic_results.folder,
                        self.__out._results_set.phylogenetic_results.phylogeny.folder,
                    ),
                    input_taxonomy_artifact=self.__out._results_set.phylogenetic_results.pre_build.frequency_table_biom,
                    input_phylogeny_artifact=self.__out._results_set.phylogenetic_results.phylogeny.tree_rooted,
                    output_path=self.__out._results_set.phylogenetic_results.alpha_diversity.calculated_diversity,
                    work_directory=self.__out._work_directory,
                )

                if step_response.is_left:
                    LOGGER.exception(step_response.value.msg)  # type: ignore

                    return bio_exc.UseCaseError(
                        "Unexpected error on execute results exportation.",
                        prev=step_response.value,
                        logger=LOGGER,
                    )()

                return right(
                    StepOutput(
                        step=step_response.value.instance,  # type: ignore
                        artifacts=[],
                    )
                )

            except Exception as exc:
                return bio_exc.UseCaseError(exc, logger=LOGGER)()
