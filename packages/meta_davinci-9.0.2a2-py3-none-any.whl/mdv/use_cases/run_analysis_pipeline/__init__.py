from asyncio import get_event_loop, new_event_loop, set_event_loop
from copy import deepcopy
from pathlib import Path
from typing import Any, Literal

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right

from mdv.domain.dtos import ResultsConfig
from mdv.domain.dtos.blast_databases import BlastReferenceDatabase
from mdv.domain.dtos.results_config import SampleResults
from mdv.settings import LOGGER
from mdv.use_cases.build_analysis_from_bootstrap import (
    BuildAnalysisFromBootstrap,
)
from mdv.use_cases.shared.generate_output_artifact import (
    GenerateOutputArtifact,
)
from mdv.use_cases.shared.run_library_sample_effectiveness import (
    RarefactionParams,
    RunLibrarySampleEffectiveness,
)
from mdv.use_cases.shared.run_qc_on_single_sample import (
    QcStepParams,
    RunQualityControlOnSingleSample,
)

from ._aggregate_qc_by_sample_outputs import AggregateQualityControlOutputs
from ._annotate_functions import AnnotateFunctions
from ._assign_taxonomy_from_blast import (
    AssignTaxonomyFromBlast,
    TaxAssignmentTools,
)
from ._calculate_phylogenetic_diversity import CalculatePhylogeneticDiversity
from ._qiime_artifacts_extractor import QiimeArtifactsExtractor


class RunAnalysisPipeline(BuildAnalysisFromBootstrap):
    # ? ------------------------------------------------------------------------
    # ? LIFE CYCLE HOOKS
    # ? ------------------------------------------------------------------------

    def __init__(
        self,
        full_picrust_pipeline: bool = False,
        tax_assignment_tool: TaxAssignmentTools = TaxAssignmentTools(None),
        chunk_size: int = 2000,
        qc_params: QcStepParams = QcStepParams(),
        rarefy_params: RarefactionParams = RarefactionParams(),
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)

        self._full_picrust_pipeline = full_picrust_pipeline
        self._tax_assignment_tool = tax_assignment_tool
        self._chunk_size = chunk_size

        # ? Trimming
        self._qc_params = qc_params

        # ? Rarefaction
        self.__rarefy_params = rarefy_params

    # ? ------------------------------------------------------------------------
    # ? PUBLIC METHODS
    # ? ------------------------------------------------------------------------

    def run_by_sample_sequentially(
        self,
    ) -> Either[bio_exc.UseCaseError, Literal[True]]:
        """Execute the `RunPipelineOnSingleSample` use case for all samples.

        Returns:
            Either[Left[bio_exc.UseCaseError], Right[Literal[True]]]: A
                literal `True` if all step execution is successfully done.
        """

        try:
            loop = get_event_loop()
        except RuntimeError:
            loop = new_event_loop()
            set_event_loop(loop)
        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

        try:
            # ? ----------------------------------------------------------------
            # ? Initialize running objects
            # ? ----------------------------------------------------------------

            marker_name_set: set[str] = set()
            database: BlastReferenceDatabase | None = None
            sample: SampleResults

            if (
                results_set_either := ResultsConfig.build_from_sample_set(
                    sample_set=self._sample_set
                )
            ).is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on create results set from "
                    + "sample set.",
                    prev=results_set_either.value,
                    logger=LOGGER,
                )()

            results_set_dto: ResultsConfig = results_set_either.value  # type: ignore

            if (
                persistence_either := results_set_dto.to_json(
                    output_directory=self._analysis_directory
                )
            ).is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on persist results set file to "
                    + "analysis directory",
                    prev=persistence_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Perform quality control
            #
            # This step samples are processed individually. All steps of quality
            # control use case are executed and the final results is
            # `single-sample-by-folder` set of results.
            # ? ----------------------------------------------------------------

            for sample in results_set_dto.samples_results:
                marker_name_set.add(sample.specs.blast_database.genomic_region)
                database = sample.specs.blast_database

                sample_directory = self._build_sample_directory(
                    sample=sample.specs
                )

                qc_params = deepcopy(self._qc_params)

                qc_params.single_end_recovery_strategy = (
                    sample.specs.recovery_single_end
                    if self._qc_params.single_end_recovery_strategy is None
                    else self._qc_params.single_end_recovery_strategy
                )

                qc_runner = RunQualityControlOnSingleSample(
                    sample_code=sample.specs.name,
                    forward_file_path=sample.specs.files.forward_file,
                    reverse_file_path=Path(sample.specs.files.reverse_file),  # type: ignore
                    source_directory=self._source_directory,  # type: ignore
                    quality_control_artifacts=sample.quality_control_artifacts,
                    work_directory=sample_directory,
                    repos=self._repos,
                    qc_params=qc_params,
                )

                if (qc_response := qc_runner.run(loop=loop)).is_left:
                    LOGGER.exception(qc_response.value)
                    return bio_exc.UseCaseError(
                        "Unexpected use error detected on run quality "
                        + f"control of sample: {sample.specs.name}",
                        prev=qc_response.value,
                    )()

                if self.__rarefy_params.with_sample_effectiveness is True:
                    calculator = RunLibrarySampleEffectiveness(
                        work_directory=sample_directory,
                        quality_control_artifacts=sample.quality_control_artifacts,
                        repos=self._repos,
                        configs=self.__rarefy_params,
                        sample_is_complex=sample.specs.sample_is_complex,
                    )

                    if (run_either := calculator.run(loop=loop)).is_left:
                        return run_either

            # ? ----------------------------------------------------------------
            # ? Aggregate results
            #
            # This step perform the aggregation of the quality control results,
            # providing a feature table like for the next steps.
            # ? ----------------------------------------------------------------

            aggregator = AggregateQualityControlOutputs(
                work_directory=self._analysis_directory,
                results_set=results_set_dto,
            )

            if (aggregation_either := aggregator.run()).is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error detected on aggregate QC results.",
                    prev=aggregation_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Assign taxonomy
            #
            # Perform the taxonomy identification based on BlastN results.
            # ? ----------------------------------------------------------------

            tax_assigner = AssignTaxonomyFromBlast(
                work_directory=self._analysis_directory,
                results_set=results_set_dto,
                repos=self._repos,
                blast_database=database.blast_files,  # type: ignore
                taxon=self._sample_set.taxa,
                tax_assignment_tool=self._tax_assignment_tool,
            )

            if (blast_either := tax_assigner.run(loop=loop)).is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error occurred on execute taxonomy assignment.",
                    prev=blast_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Generate phylogenetic diversity indices
            #
            # This step create the `Multiple Sequences Alignment` of the
            # oligotypes find at the previous steps and use this to estimate
            # diversity phylogenetic indices. Here, the rarefaction curve is
            # already estimated to check if the sampling size was effective.
            # ? ----------------------------------------------------------------

            phylo_diversity_calculator = CalculatePhylogeneticDiversity(
                work_directory=self._analysis_directory,
                results_set=results_set_dto,
                repos=self._repos,
                metadata_artifact=(
                    self._sample_set.metadata_artifact
                    if self._sample_set.metadata_artifact.is_file()
                    else self._source_directory.joinpath(
                        self._sample_set.metadata_artifact
                    )
                ),
            )

            if (
                diversity_either := phylo_diversity_calculator.run(loop=loop)
            ).is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error occurred on calculate phylo-diversity.",
                    prev=diversity_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Extract results artifacts to raw files
            #
            # QIIME2 artifacts are composed of gunzipped files, and are not
            # readable by other pipelines. Here, QIIME2 artifacts are extracted
            # to raw files.
            # ? ----------------------------------------------------------------

            extractor = QiimeArtifactsExtractor(
                single_step_repos=self._repos,
            )

            extraction_either = extractor.run(
                analysis_directory=self._analysis_directory,
                target_paths={
                    self._analysis_directory.joinpath(
                        results_set_dto.phylogenetic_results.folder,
                        results_set_dto.phylogenetic_results.alpha_diversity.folder,
                    ): [
                        results_set_dto.phylogenetic_results.alpha_diversity.calculated_diversity
                    ],
                    self._analysis_directory.joinpath(
                        results_set_dto.phylogenetic_results.folder,
                        results_set_dto.phylogenetic_results.alpha_rarefaction.folder,
                    ): [
                        results_set_dto.phylogenetic_results.alpha_rarefaction.rarefied
                    ],
                    self._analysis_directory.joinpath(
                        results_set_dto.phylogenetic_results.folder,
                        results_set_dto.phylogenetic_results.eco_diversity.folder,
                    ): [
                        results_set_dto.phylogenetic_results.eco_diversity.filtered_table
                    ],
                    self._analysis_directory.joinpath(
                        results_set_dto.phylogenetic_results.folder,
                        results_set_dto.phylogenetic_results.phylogeny.folder,
                    ): [
                        results_set_dto.phylogenetic_results.phylogeny.alignment_raw,
                        results_set_dto.phylogenetic_results.phylogeny.alignment_masked,
                        results_set_dto.phylogenetic_results.phylogeny.tree_rooted,
                        results_set_dto.phylogenetic_results.phylogeny.tree_unrooted,
                    ],
                },
            )

            if extraction_either.is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on extract results files.",
                    prev=extraction_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Run function annotation using PICRUSt2
            #
            # Steps performed by PICRUSt2 places the oligotypes here collected
            # into the Tree of Life and perform functional annotations based in
            # known attributes of sequences already present at the reference
            # tree.
            # ? ----------------------------------------------------------------

            annotator = AnnotateFunctions(
                work_directory=self._analysis_directory,
                results_set=results_set_dto,
                repos=self._repos,
                taxa=self._sample_set.taxa,
                step_by_step=not self._full_picrust_pipeline,
                chunk_size=self._chunk_size,
            )

            if (annotation_either := annotator.run(loop=loop)).is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on annotate metagenome functions.",
                    prev=annotation_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Generate final artifact
            #
            # Here a final JSON artifacts containing pipeline execution stats
            # are created from results here produced.
            # ? ----------------------------------------------------------------

            output_generator = GenerateOutputArtifact(
                results_set=results_set_dto,
                analysis_directory=self._analysis_directory,
                custom_source_directory=self._source_directory,
            )

            if (output_artifact_either := output_generator.run()).is_left:
                return bio_exc.UseCaseError(
                    "Unexpected error on generate JSON output file.",
                    prev=output_artifact_either.value,
                    logger=LOGGER,
                )()

            # ? ----------------------------------------------------------------
            # ? Return a positive response
            # ? ----------------------------------------------------------------

            return right(True)

        except Exception as exc:
            return bio_exc.UseCaseError(exc, logger=LOGGER)()

        finally:
            loop.close()
