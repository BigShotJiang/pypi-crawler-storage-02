from json import load
from pathlib import Path
from typing import Any

import agrobase.exceptions as bio_exc
from agrobase.either import Either, right
from agrobase.entities import CreateResponse
from pandas import DataFrame, read_csv

from mdv.domain.dtos.blob_indices import SampleCropMap
from mdv.domain.dtos.sample_sheet import SampleSheet
from mdv.domain.dtos.raw_library_blob_artifact import (
    IndexingTags,
    SequencingMetadata,
    RawLibraryBlobArtifact,
)
from mdv.domain.entities.raw_library_blob_registration import (
    RawLibraryBlobRegistration,
)
from mdv.settings import LOGGER
from mdv.use_cases.shared.request_connection_string import (
    request_connection_string,
)


@request_connection_string
def persist_seq_results_to_blob_storage_provider(
    sequencing_year: int,
    sample_sheet_path: Path,
    default_qc_report_path: Path,
    sequencing_directory: Path,
    blob_indices_mapping_path: Path,
    raw_library_blob_registration_repo: RawLibraryBlobRegistration,
    single_end_qc_report_path: Path | None = None,
    metadata_path: Path | None = None,
    extra_index_kv: dict[str, Any] | None = None,
    extra_metadata_kv: dict[str, Any] | None = None,
    connection_string: str | None = None,
) -> Either[bool, bio_exc.UseCaseError]:
    try:
        # ? --------------------------------------------------------------------
        # ? Validate input data
        # ? --------------------------------------------------------------------

        if not sample_sheet_path.is_file():
            return bio_exc.UseCaseError(
                f"Sample sheet file {sample_sheet_path} does not exist",
                logger=LOGGER,
            )()

        if not default_qc_report_path.is_file():
            return bio_exc.UseCaseError(
                f"QC report file {default_qc_report_path} does not exist",
                logger=LOGGER,
            )()

        if (
            single_end_qc_report_path is not None
            and not single_end_qc_report_path.is_file()
        ):
            return bio_exc.UseCaseError(
                f"Single end QC report file {single_end_qc_report_path} does not exist",
                logger=LOGGER,
            )()

        if not blob_indices_mapping_path.is_file():
            return bio_exc.UseCaseError(
                f"Sample indices mapping file {blob_indices_mapping_path} does not exist",
                logger=LOGGER,
            )()

        if not sequencing_directory.is_dir():
            return bio_exc.UseCaseError(
                f"FASTQ reads directory {sequencing_directory} does not exist",
                logger=LOGGER,
            )()

        if metadata_path is not None and not metadata_path.is_file():
            return bio_exc.UseCaseError(
                f"Metadata file {metadata_path} does not exist",
                logger=LOGGER,
            )()

        if not isinstance(
            raw_library_blob_registration_repo, RawLibraryBlobRegistration
        ):
            return bio_exc.UseCaseError(
                "Invalid storage account registration repository",
                logger=LOGGER,
            )()

        # ? --------------------------------------------------------------------
        # ? Load SampleSheet
        # ? --------------------------------------------------------------------

        if (
            sample_sheet_either := SampleSheet.from_tabular_samplesheet(
                file_path=sample_sheet_path
            )
        ).is_left:
            return bio_exc.UseCaseError(
                sample_sheet_either.value,
                logger=LOGGER,
            )()

        sample_sheet: SampleSheet = sample_sheet_either.value

        # ? --------------------------------------------------------------------
        # ? Load QC report
        # ? --------------------------------------------------------------------

        qc_report: dict[str, Any] | None = None
        with default_qc_report_path.open() as qc_report_file:
            qc_report = load(qc_report_file)

        if qc_report is not None and not isinstance(qc_report, dict):
            return bio_exc.UseCaseError(
                f"Invalid QC report file {default_qc_report_path}",
                logger=LOGGER,
            )()

        for sample in sample_sheet.data:
            if sample.sample_id not in qc_report:
                return bio_exc.UseCaseError(
                    f"Sample {sample.sample_id} not found in QC report",
                    logger=LOGGER,
                )()

        single_end_qc_report: dict[str, Any] | None = None
        if single_end_qc_report_path is not None:
            with single_end_qc_report_path.open() as single_end_qc_report_file:
                single_end_qc_report = load(single_end_qc_report_file)

            if single_end_qc_report is not None and not isinstance(
                single_end_qc_report, dict
            ):
                return bio_exc.UseCaseError(
                    f"Invalid single end QC report file {single_end_qc_report_path}",
                    logger=LOGGER,
                )()

            for sample in sample_sheet.data:
                if sample.sample_id not in single_end_qc_report:
                    return bio_exc.UseCaseError(
                        f"Sample {sample.sample_id} not found in single end QC report",
                        logger=LOGGER,
                    )()

        # ? --------------------------------------------------------------------
        # ? Load sample crop mapping
        # ? --------------------------------------------------------------------

        blob_indices_mapping: DataFrame = SampleCropMap.validate(
            read_csv(blob_indices_mapping_path, sep="\t"),
        )

        desired_samples = list(
            blob_indices_mapping[SampleCropMap.sample].unique()
        )

        for sample in [i.sample_id for i in sample_sheet.data]:
            if sample not in desired_samples:
                return bio_exc.UseCaseError(
                    f"Sample {sample} not found in `{blob_indices_mapping_path}`",
                    logger=LOGGER,
                )()

        indices_mapping_dict: dict[str, str] = blob_indices_mapping.set_index(
            SampleCropMap.sample
        ).to_dict(orient="index")

        # ? --------------------------------------------------------------------
        # ? Parse fastq files given the sample sheet
        # ? --------------------------------------------------------------------

        blobs: list[RawLibraryBlobArtifact] = []

        for sample in sample_sheet.data:
            # Ty to collect forward file
            if (
                forward_file := list(
                    sequencing_directory.joinpath(sample.sample_project).glob(
                        f"{sample.sample_id}*_[R1][1]_*.fastq.gz"
                    )
                )
            ).__len__() != 1:
                return bio_exc.UseCaseError(
                    (
                        f"Forward FASTQ file for sample {sample.sample_id} not "
                        + "found or multiple files found"
                    ),
                    logger=LOGGER,
                )()

            # Ty to collect reverse file
            if (
                reverse_file := list(
                    sequencing_directory.joinpath(sample.sample_project).glob(
                        f"{sample.sample_id}*_[R2][2]_*.fastq.gz"
                    )
                )
            ).__len__() != 1:
                return bio_exc.UseCaseError(
                    (
                        f"Reverse FASTQ file for sample {sample.sample_id} not "
                        + "found or multiple files found"
                    ),
                    logger=LOGGER,
                )()

            for strand, file in [
                ("R1", forward_file.pop()),
                ("R2", reverse_file.pop()),
            ]:
                if (
                    sample_indices := indices_mapping_dict.get(sample.sample_id)
                ) is None:
                    return bio_exc.UseCaseError(
                        (
                            f"Sample {sample.sample_id} indices not found in "
                            + f"`{blob_indices_mapping_path}`"
                        ),
                        logger=LOGGER,
                    )()

                if (matrix := sample_indices.get(SampleCropMap.matrix)) is None:
                    return bio_exc.UseCaseError(
                        (
                            f"{sample.sample_id} matrix not found in "
                            + f"`{blob_indices_mapping_path}`"
                        ),
                        logger=LOGGER,
                    )()

                if (
                    country := sample_indices.get(SampleCropMap.country)
                ) is None:
                    return bio_exc.UseCaseError(
                        (
                            f"{sample.sample_id} country not found in "
                            + f"`{blob_indices_mapping_path}`"
                        ),
                        logger=LOGGER,
                    )()

                if (
                    state_province := sample_indices.get(
                        SampleCropMap.state_province
                    )
                ) is None:
                    return bio_exc.UseCaseError(
                        (
                            f"{sample.sample_id} country not found in "
                            + f"`{blob_indices_mapping_path}`"
                        ),
                        logger=LOGGER,
                    )()

                blobs.append(
                    RawLibraryBlobArtifact(
                        file=file,
                        indexing_tags=IndexingTags(
                            sequencing_year=sequencing_year,
                            sample_id=sample.description.sample,
                            country=country,
                            state_province=state_province,
                            amplicon=sample.description.target,
                            sample_project=sample.sample_project,
                            strand=strand,
                            isolate=sample.description.isolate,
                            crop=sample_indices.get(SampleCropMap.crop),
                            matrix=matrix,
                        ),
                        sequencing_metadata=SequencingMetadata(
                            sample_sheet_data=sample,
                            sample_sheet_header=sample_sheet.header,
                            sample_sheet_reads=sample_sheet.reads,
                            sample_sheet_settings=sample_sheet.settings,
                        ),
                        paired_end_qc_metadata=qc_report.get(sample.sample_id),
                        single_end_qc_metadata=(
                            single_end_qc_report.get(sample.sample_id)
                            if single_end_qc_report
                            else None
                        ),
                        extra_index_kv=(
                            extra_index_kv if extra_index_kv else None
                        ),
                        extra_metadata_kv=(
                            extra_metadata_kv if extra_metadata_kv else None
                        ),
                    )
                )

        # ? --------------------------------------------------------------------
        # ? Register blobs
        # ? --------------------------------------------------------------------

        for blob in blobs:
            if (
                storage_blob_registration_either := (
                    raw_library_blob_registration_repo.create(
                        blob=blob,
                        connection_string=connection_string,
                    )
                )
            ).is_left:
                return bio_exc.UseCaseError(
                    storage_blob_registration_either.value,
                    logger=LOGGER,
                )()

            creation_response: CreateResponse[
                RawLibraryBlobArtifact
            ] = storage_blob_registration_either.value

            if not creation_response.created:
                LOGGER.warning(
                    f"❌  Blob {blob.file.name} already registered in storage "
                    + "provider. Skipping..."
                )
                continue

            LOGGER.info(f"✅  Blob {blob.file.name} registered")

        # ? --------------------------------------------------------------------
        # ? Return a positive response
        # ? --------------------------------------------------------------------

        return right(True)

    except Exception as exc:
        return bio_exc.UseCaseError(exc, logger=LOGGER)()
