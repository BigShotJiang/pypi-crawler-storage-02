from .gene_thesaurus import GeneThesaurus

__all__ = ["GeneThesaurus"]
