def main():
    print("Hello from mellea!")


if __name__ == "__main__":
    main()
