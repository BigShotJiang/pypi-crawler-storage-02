"""URLs for learning_credentials."""

# from django.urls import re_path  # noqa: ERA001, RUF100
# from django.views.generic import TemplateView  # noqa: ERA001, RUF100

urlpatterns = [  # pragma: no cover
    # TODO: Fill in URL patterns and views here.
    # re_path(r'', TemplateView.as_view(template_name="learning_credentials/base.html")),  # noqa: ERA001, RUF100
]
