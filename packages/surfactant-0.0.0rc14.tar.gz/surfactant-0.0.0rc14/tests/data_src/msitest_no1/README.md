To recreate msi file:
1. Create a wxs file
2. Build using `wixl -v test.wxs`, which creates the msi file
