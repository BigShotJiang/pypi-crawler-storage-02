# Contribution Guide

General information on contributing to Surfactant and setting up a development environment
can be found in the [CONTRIBUTING.md](https://github.com/LLNL/Surfactant/blob/main/CONTRIBUTING.md)
file in the GitHub repository.

Surfactant is released under the MIT license. See the [LICENSE](./LICENSE)
and [NOTICE](./NOTICE) files for details. All new contributions must be made
under this license.
