# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.x   | :white_check_mark: |

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities using the GitHub project
`Security` tab for Surfactant.
