## Databricks Feature Lookup for Feature Store

Copyright (2021) Databricks, Inc.

This Software includes software developed at Databricks (https://www.databricks.com/) and its use is subject
to the included LICENSE.md file.

Additionally, this Software contains code from the following open source projects:

* MLflow - Apache 2
* PyYAML - MIT License
* SQLAlchemy - MIT License
* PyMysql - MIT License
* PyODBC - MIT License