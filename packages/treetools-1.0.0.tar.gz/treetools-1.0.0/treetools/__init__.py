"""
treetools: Tools for transforming treebank trees.

Author: Wolfgang Maier <maierw@hhu.de>
"""
