from .decoder import TextureArrayDecoder


__all__ = ("TextureArrayDecoder",)
