from enum import Enum


class ResponseFormat(Enum):
    JSON_OBJECT = {"type": "json_object"}
