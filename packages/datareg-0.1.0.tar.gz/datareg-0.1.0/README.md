# Data Regularization

Custom data regularization and augmentation layers separated by domain (vision, text, audio).

## Installation

```bash
pip install datareg
