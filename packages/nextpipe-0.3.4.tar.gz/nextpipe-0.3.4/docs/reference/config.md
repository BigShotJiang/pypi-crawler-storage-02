# Config Module

This module contains configuration-related functionality.

::: nextpipe.config
