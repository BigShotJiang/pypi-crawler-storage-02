"""
Utility modules for emailer-inao application.
"""
