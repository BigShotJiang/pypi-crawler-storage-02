"""
Core functionality for emailer-inao application.
"""
