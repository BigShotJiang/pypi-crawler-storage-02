from .main import run_study
__version__ = "0.1.0"