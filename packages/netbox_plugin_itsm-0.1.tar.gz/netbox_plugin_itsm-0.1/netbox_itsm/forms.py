from django import forms
from netbox.forms import NetBoxModelForm, NetBoxModelBulkEditForm, NetBoxModelFilterSetForm
from tenancy.models import Tenant

from django.contrib.contenttypes.models import ContentType
from utilities.forms.fields import CommentField, DynamicModelChoiceField, ContentTypeChoiceField

from .models import *

class ProductForm(NetBoxModelForm):
    """
    group = DynamicModelChoiceField(
        queryset=ProductGroup.objects.all()
    )
    """
    comments = CommentField()

    class Meta:
        model = Product
        fields = ('name', 'number', 'group', 'unit', 'description', 'tags', 'comments')

class ProductFilterForm(NetBoxModelFilterSetForm):
    model = Product

    name = forms.CharField(
        required=False
    )
    number = forms.CharField(
        required=False
    )
    group = forms.ModelMultipleChoiceField(
        queryset=ProductGroup.objects.all(),
        required=False
    )
    unit = forms.MultipleChoiceField(
        choices=UnitChoices,
        required=False
    )
    description = forms.CharField(
        required=False
    )

class ProductGroupForm(NetBoxModelForm):
    comments = CommentField()

    class Meta:
        model = ProductGroup
        fields = ('name', 'description', 'tags', 'comments')

class ContractForm(NetBoxModelForm):
    tenant = DynamicModelChoiceField(
        queryset=Tenant.objects.all()
    )
    comments = CommentField()

    class Meta:
        model = Contract
        fields = ('name', 'number', 'tenant', 'status', 'description', 'tags', 'comments')

class ContractFilterForm(NetBoxModelFilterSetForm):
    model = Contract

    name = forms.CharField(
        required=False
    )
    number = forms.CharField(
        required=False
    )
    tenant = forms.ModelMultipleChoiceField(
        queryset=Tenant.objects.all(),
        required=False
    )
    status = forms.MultipleChoiceField(
        choices=StatusChoices,
        required=False
    )
    description = forms.CharField(
        required=False
    )

class ContractServiceForm(NetBoxModelForm):
    """
    contract = DynamicModelChoiceField(
        queryset=Contract.objects.all()
    )
    product = DynamicModelChoiceField(
        queryset=Product.objects.all()
    )
    """
    comments = CommentField()

    class Meta:
        model = ContractService
        fields = ('name', 'contract', 'product', 'status', 'description', 'amount', 'tags', 'comments')

class ContractServiceFilterForm(NetBoxModelFilterSetForm):
    model = ContractService

    name = forms.CharField(
        required=False
    )
    contract = forms.ModelMultipleChoiceField(
        queryset=Contract.objects.all(),
        required=False
    )
    product = forms.ModelMultipleChoiceField(
        queryset=Product.objects.all(),
        required=False
    )
    status = forms.MultipleChoiceField(
        choices=StatusChoices,
        required=False
    )
    amount = forms.IntegerField(
        required=False
    )
    description = forms.CharField(
        required=False
    )

class ContractServiceItemForm(NetBoxModelForm):
    """
    service = DynamicModelChoiceField(
        queryset=ContractService.objects.all()
    )
    """
    content_type = forms.ModelChoiceField(
        queryset=ContentType.objects.filter(app_label__in=["dcim", "ipam", "virtualization", "circuits"]),
        label="Object Type"
    )
    object_id = forms.ChoiceField(
        label="Object",
        choices=[]
    )

    class Meta:
        model = ContractServiceItem
        fields = ('service', 'content_type', 'object_id')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        initial = self.initial or {}
        data = self.data or {}

        # 1. Determine content_type and object_id from data or instance
        content_type = (
            data.get('content_type')
            or initial.get('content_type')
            or getattr(getattr(self.instance, 'content_type', None), 'pk', None)
        )
        object_id = (
            data.get('object_id')
            or initial.get('object_id')
            or getattr(self.instance, 'object_id', None)
        )

        # 2. Populate choices for object_id based on existing object
        if content_type and object_id:
            try:
                ct = ContentType.objects.get(pk=content_type)
                model_class = ct.model_class()
                obj = model_class.objects.get(pk=object_id)

                self.fields['object_id'].choices = [(obj.pk, str(obj))]
            except Exception as e:
                print(f"⚠️ Failed to load initial object choice: {e}")
                pass

class ContractServiceItemFilterForm(NetBoxModelFilterSetForm):
    model = ContractServiceItem

    service = forms.ModelMultipleChoiceField(
        queryset=ContractService.objects.all(),
        required=False
    )
