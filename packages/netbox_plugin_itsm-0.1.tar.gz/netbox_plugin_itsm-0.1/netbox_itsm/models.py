from django.contrib.postgres.fields import ArrayField
from django.db import models
from django.urls import reverse

from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

from netbox.models import NetBoxModel
from utilities.choices import ChoiceSet

class StatusChoices(ChoiceSet):
    ACTIVE = 'active'
    TERMINATED = 'terminated'
    PLANNED = 'planned'

    CHOICES = [
        (ACTIVE, 'Active', 'green'),
        (TERMINATED, 'Terminated', 'red'),
        (PLANNED, 'Planned', 'orange')
    ]

class UnitChoices(ChoiceSet):
    CHOICES = [
        ('#', 'Pcs'),
        ('mbps', 'Mbps'),
        ('gb', 'Gigabyte'),
        ('w', 'Watt')
    ]

class ProductGroup(NetBoxModel):
    name = models.CharField()
    description = models.CharField(
        blank=True,
        null=True
    )

    class Meta:
        ordering = ('name', )

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('plugins:netbox_itsm:productgroup', args=[self.pk])

class Product(NetBoxModel):
    name = models.CharField()
    number = models.CharField(
        blank=True,
        null=True
    )
    group = models.ForeignKey(
        to=ProductGroup,
        on_delete=models.PROTECT,
        related_name='products'
    )
    unit = models.CharField(
        choices=UnitChoices,
        blank=True,
        null=True
    )
    description = models.CharField(
        blank=True,
        null=False
    )
    comments = models.TextField(
        blank=True
    )

    class Meta:
        ordering = ('name', 'number')

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('plugins:netbox_itsm:product', args=[self.pk])

class Contract(NetBoxModel):
    name = models.CharField()
    number = models.CharField(
        blank=True,
        null=True
    )
    tenant = models.ForeignKey(
        to='tenancy.tenant',
        on_delete=models.PROTECT,
        related_name='contracts'
    )
    status = models.CharField(
        choices=StatusChoices,
        default=StatusChoices.ACTIVE
    )
    description = models.CharField(
        blank=True,
        null=False
    )
    comments = models.TextField(
        blank=True
    )

    class Meta:
        ordering = ('name', 'number', 'tenant', 'status')

    def __str__(self):
        return f"{self.tenant.name} - {self.name}"

    def get_absolute_url(self):
        return reverse('plugins:netbox_itsm:contract', args=[self.pk])
    
    def get_status_color(self):
        return StatusChoices.colors.get(self.status)


class ContractService(NetBoxModel):
    name = models.CharField(
        blank=True,
        null=True
    )
    contract = models.ForeignKey(
        to=Contract,
        on_delete=models.CASCADE,
        related_name='services'
    )
    product = models.ForeignKey(
        to=Product,
        on_delete=models.PROTECT,
        related_name='services'
    )
    status = models.CharField(
        choices=StatusChoices,
        default=StatusChoices.ACTIVE
    )
    amount = models.IntegerField(
        blank=True,
        null=True
    )
    description = models.CharField(
        blank=True,
        null=False
    )
    comments = models.TextField(
        blank=True
    )

    class Meta:
        ordering = ('name', 'contract', 'product')

    def __str__(self):
        if self.name != None:
            return f"{self.contract.tenant.name} - {self.contract.name} - {self.name}"
        else:
            return f"{self.contract.tenant.name} - {self.contract.name} - {self.product.name}"

    def get_absolute_url(self):
        return reverse('plugins:netbox_itsm:contractservice', args=[self.pk])
    
    def get_status_color(self):
        return StatusChoices.colors.get(self.status)

class ContractServiceItem(NetBoxModel):
    service = models.ForeignKey(
        to=ContractService,
        on_delete=models.CASCADE,
        related_name='items'
    )
    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.CASCADE,
        related_name='+'
    )
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    class Meta:
        ordering = ('service', 'content_type', 'object_id')

    def __str__(self):
        return f"{self.service.contract} - {self.content_object}"

    def get_absolute_url(self):
        return reverse('plugins:netbox_itsm:contractserviceitem', args=[self.pk])
