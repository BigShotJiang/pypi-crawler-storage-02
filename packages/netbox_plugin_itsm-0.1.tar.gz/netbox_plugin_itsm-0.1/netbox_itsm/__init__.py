from netbox.plugins import PluginConfig

class NetBoxAccessListsConfig(PluginConfig):
	name = 'netbox_itsm'
	verbose_name = 'NetBox ITSM'
	version = '0.1'
	description = 'Manage contracts and services in NetBox.'
	author = 'level66.network UG (haftungsbeschränkt)'
	author_email = 'support@level66.network'
	base_url = 'itsm'
	min_version = '3.4.0'

config = NetBoxAccessListsConfig
