import django_tables2 as tables
from netbox.tables import NetBoxTable, ChoiceFieldColumn

from .models import *

class ProductTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    group = tables.Column(
        linkify=True
    )
    unit = ChoiceFieldColumn()

    class Meta(NetBoxTable.Meta):
        model = Product
        fields = ('pk', 'id', 'name', 'number', 'unit', 'group', 'description')
        default_columns = ('name', 'number', 'group', 'unit', 'description')

class ProductGroupTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )

    class Meta(NetBoxTable.Meta):
        model = ProductGroup
        fields = ('pk', 'id', 'name', 'description')
        default_columns = ('name', 'description')

class ContractTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    tenant = tables.Column(
        linkify=True
    )
    status = ChoiceFieldColumn()

    class Meta(NetBoxTable.Meta):
        model = Contract
        fields = ('pk', 'id', 'name', 'number', 'tenant', 'status', 'description')
        default_columns = ('name', 'number', 'tenant', 'status', 'description')

class ContractServiceTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    contract = tables.Column(
        linkify=True
    )
    product = tables.Column(
        linkify=True
    )
    status = ChoiceFieldColumn()

    class Meta(NetBoxTable.Meta):
        model = ContractService
        fields = ('pk', 'id', 'name', 'contract', 'product', 'amount', 'status', 'description')
        default_columns = ('name', 'contract', 'product', 'amount', 'status', 'description')

class ContractServiceItemTable(NetBoxTable):
    service = tables.Column(
        linkify=True
    )
    content_object = tables.Column(
        linkify=True
    )

    class Meta(NetBoxTable.Meta):
        model = ContractServiceItem
        fields = ('pk', 'id', 'service', 'content_type', 'content_object')
        default_columns = ('service', 'content_type', 'content_object')
