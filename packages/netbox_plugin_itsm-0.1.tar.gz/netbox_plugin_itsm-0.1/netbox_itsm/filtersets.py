from netbox.filtersets import NetBoxModelFilterSet

from .models import *

class ProductFilterSet(NetBoxModelFilterSet):
    class Meta:
        model = Product
        fields = ('id', 'name', 'number', 'group', 'unit', 'description')

    def search(self, queryset, name, value):
        return queryset.filter(
            name__icontains=value,
            description__icontains=value
        )

class ContractFilterSet(NetBoxModelFilterSet):
    class Meta:
        model = Contract
        fields = ('id', 'name', 'number', 'tenant', 'status', 'description')

    def search(self, queryset, name, value):
        return queryset.filter(
            name__icontains=value,
            description__icontains=value
        )

class ContractServiceFilterSet(NetBoxModelFilterSet):
    class Meta:
        model = ContractService
        fields = ('id', 'name', 'contract', 'product', 'status', 'amount', 'description')

    def search(self, queryset, name, value):
        return queryset.filter(
            name__icontains=value,
            description__icontains=value
        )

class ContractServiceItemFilterSet(NetBoxModelFilterSet):
    class Meta:
        model = ContractServiceItem
        fields = ('id', 'service')
