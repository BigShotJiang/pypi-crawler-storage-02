from netbox.choices import ButtonColorChoices
from netbox.plugins import PluginMenu, PluginMenuButton, PluginMenuItem

menu = PluginMenu(
    label='ITSM',
    groups=(
        ('Product Management', (
            PluginMenuItem(
                link='plugins:netbox_itsm:product_list',
                link_text='Products',
                buttons=[
                    PluginMenuButton(
                        link='plugins:netbox_itsm:product_add',
                        title='Add',
                        icon_class='mdi mdi-plus-thick'
                    ),
                ]
            ),
            PluginMenuItem(
                link='plugins:netbox_itsm:productgroup_list',
                link_text='Product Groups',
                buttons=[
                    PluginMenuButton(
                        link='plugins:netbox_itsm:productgroup_add',
                        title='Add',
                        icon_class='mdi mdi-plus-thick'
                    ),
                ]
            )
        )),
        ('Contract Management', (
            PluginMenuItem(
                link='plugins:netbox_itsm:contract_list',
                link_text='Contracts',
                buttons=[
                    PluginMenuButton(
                        link='plugins:netbox_itsm:contract_add',
                        title='Add',
                        icon_class='mdi mdi-plus-thick'
                    ),
                ]
            ),
            PluginMenuItem(
                link='plugins:netbox_itsm:contractservice_list',
                link_text='Contract Services',
                buttons=[
                    PluginMenuButton(
                        link='plugins:netbox_itsm:contractservice_add',
                        title='Add',
                        icon_class='mdi mdi-plus-thick'
                    ),
                ]
            ),
            PluginMenuItem(
                link='plugins:netbox_itsm:contractserviceitem_list',
                link_text='Contract Service Items',
                buttons=[
                    PluginMenuButton(
                        link='plugins:netbox_itsm:contractserviceitem_add',
                        title='Add',
                        icon_class='mdi mdi-plus-thick'
                    ),
                ]
            )
        ))
    ),
    icon_class='mdi mdi-bank'
)
