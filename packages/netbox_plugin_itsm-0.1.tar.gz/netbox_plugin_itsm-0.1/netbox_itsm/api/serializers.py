from netbox.api.serializers import NetBoxModelSerializer
from rest_framework import serializers

from ..models import *

class ProductSerializer(NetBoxModelSerializer):
    class Meta:
        model = Product
        fields = ('id', 'url', 'display', 'name', 'group', 'unit', 'description', 'comments', 'tags', 'custom_fields', 'created', 'last_updated')

class ProductGroupSerializer(NetBoxModelSerializer):
    class Meta:
        model = ProductGroup
        fields = ('id', 'display', 'name', 'description', 'tags', 'custom_fields', 'created', 'last_updated')

class ContractSerializer(NetBoxModelSerializer):
    class Meta:
        model = Contract
        fields = ('id', 'display', 'name', 'number', 'tenant', 'status', 'description', 'comments', 'tags', 'custom_fields', 'created', 'last_updated')

class ContractServiceSerializer(NetBoxModelSerializer):
    class Meta:
        model = ContractService
        fields = ('id', 'display', 'name', 'contract', 'product', 'status', 'description', 'amount', 'comments', 'tags', 'custom_fields', 'created', 'last_updated')

class ContractServiceItemSerializer(NetBoxModelSerializer):
    class Meta:
        model = ContractServiceItem
        fields = ('id', 'display', 'service', 'content_type', 'object_id', 'tags', 'custom_fields', 'created', 'last_updated')
