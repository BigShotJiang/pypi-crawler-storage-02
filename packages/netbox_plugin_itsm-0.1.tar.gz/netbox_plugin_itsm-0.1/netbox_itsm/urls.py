from django.urls import path
from netbox.views.generic import ObjectChangeLogView

from . import models, views

urlpatterns = (
    # Product
    path('product/', views.ProductListView.as_view(), name='product_list'),
    path('product/add/', views.ProductEditView.as_view(), name='product_add'),
    path('product/<int:pk>/', views.ProductView.as_view(), name='product'),
    path('product/<int:pk>/edit/', views.ProductEditView.as_view(), name='product_edit'),
    path('product/<int:pk>/delete/', views.ProductDeleteView.as_view(), name='product_delete'),
    path('product/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='product_changelog', kwargs={'model': models.Product}),

    # ProductGroup
    path('productgroup/', views.ProductGroupListView.as_view(), name='productgroup_list'),
    path('productgroup/add/', views.ProductGroupEditView.as_view(), name='productgroup_add'),
    path('productgroup/<int:pk>/', views.ProductGroupView.as_view(), name='productgroup'),
    path('productgroup/<int:pk>/edit/', views.ProductGroupEditView.as_view(), name='productgroup_edit'),
    path('productgroup/<int:pk>/delete/', views.ProductGroupDeleteView.as_view(), name='productgroup_delete'),
    path('productgroup/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='productgroup_changelog', kwargs={'model': models.ProductGroup}),

    # Contract
    path('contract/', views.ContractListView.as_view(), name='contract_list'),
    path('contract/add/', views.ContractEditView.as_view(), name='contract_add'),
    path('contract/<int:pk>/', views.ContractView.as_view(), name='contract'),
    path('contract/<int:pk>/edit/', views.ContractEditView.as_view(), name='contract_edit'),
    path('contract/<int:pk>/delete/', views.ContractDeleteView.as_view(), name='contract_delete'),
    path('contract/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='contract_changelog', kwargs={'model': models.Contract}),

    # ContractService
    path('contractservice/', views.ContractServiceListView.as_view(), name='contractservice_list'),
    path('contractservice/add/', views.ContractServiceEditView.as_view(), name='contractservice_add'),
    path('contractservice/<int:pk>/', views.ContractServiceView.as_view(), name='contractservice'),
    path('contractservice/<int:pk>/edit/', views.ContractServiceEditView.as_view(), name='contractservice_edit'),
    path('contractservice/<int:pk>/delete/', views.ContractServiceDeleteView.as_view(), name='contractservice_delete'),
    path('contractservice/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='contractservice_changelog', kwargs={'model': models.ContractService}),

    # ContractServiceItem
    path('contractserviceitem/', views.ContractServiceItemListView.as_view(), name='contractserviceitem_list'),
    path('contractserviceitem/add/', views.ContractServiceItemEditView.as_view(), name='contractserviceitem_add'),
    path('contractserviceitem/<int:pk>/', views.ContractServiceItemView.as_view(), name='contractserviceitem'),
    path('contractserviceitem/<int:pk>/edit/', views.ContractServiceItemEditView.as_view(), name='contractserviceitem_edit'),
    path('contractserviceitem/<int:pk>/delete/', views.ContractServiceItemDeleteView.as_view(), name='contractserviceitem_delete'),
    path('contractserviceitem/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='contractserviceitem_changelog', kwargs={'model': models.ContractServiceItem}),
    path("contractserviceitem/object-choices/", views.ContractServiceItemGetObjects, name="contractserviceitem_object_choices"),
)
