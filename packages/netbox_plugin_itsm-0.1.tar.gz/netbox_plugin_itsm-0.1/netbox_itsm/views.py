from netbox.views import generic

from django.http import JsonResponse
from django.contrib.contenttypes.models import ContentType

from . import forms, models, tables, filtersets

# Product
class ProductView(generic.ObjectView):
    queryset = models.Product.objects.all()

class ProductListView(generic.ObjectListView):
    queryset = models.Product.objects.all()
    table = tables.ProductTable
    filterset = filtersets.ProductFilterSet
    filterset_form = forms.ProductFilterForm

class ProductEditView(generic.ObjectEditView):
    queryset = models.Product.objects.all()
    form = forms.ProductForm

class ProductDeleteView(generic.ObjectDeleteView):
    queryset = models.Product.objects.all()

# ProductGroup
class ProductGroupView(generic.ObjectView):
    queryset = models.ProductGroup.objects.all()

    def get_extra_context(self, request, instance):
        table = tables.ProductTable(instance.products.all())
        table.configure(request)

        return {
            'product_table': table,
        }

class ProductGroupListView(generic.ObjectListView):
    queryset = models.ProductGroup.objects.all()
    table = tables.ProductGroupTable

class ProductGroupEditView(generic.ObjectEditView):
    queryset = models.ProductGroup.objects.all()
    form = forms.ProductGroupForm

class ProductGroupDeleteView(generic.ObjectDeleteView):
    queryset = models.ProductGroup.objects.all()

# Contract
class ContractView(generic.ObjectView):
    queryset = models.Contract.objects.all()
    
    def get_extra_context(self, request, instance):
        table = tables.ContractServiceTable(instance.services.all())
        table.configure(request)

        return {
            'service_table': table,
        }

class ContractListView(generic.ObjectListView):
    queryset = models.Contract.objects.all()
    table = tables.ContractTable
    filterset = filtersets.ContractFilterSet
    filterset_form = forms.ContractFilterForm

class ContractEditView(generic.ObjectEditView):
    queryset = models.Contract.objects.all()
    form = forms.ContractForm

class ContractDeleteView(generic.ObjectDeleteView):
    queryset = models.Contract.objects.all()

# ContractService
class ContractServiceView(generic.ObjectView):
    queryset = models.ContractService.objects.all()

    def get_extra_context(self, request, instance):
        table = tables.ContractServiceItemTable(instance.items.all())
        table.configure(request)

        return {
            'item_table': table,
        }

class ContractServiceListView(generic.ObjectListView):
    queryset = models.ContractService.objects.all()
    table = tables.ContractServiceTable
    filterset = filtersets.ContractServiceFilterSet
    filterset_form = forms.ContractServiceFilterForm

class ContractServiceEditView(generic.ObjectEditView):
    queryset = models.ContractService.objects.all()
    form = forms.ContractServiceForm

class ContractServiceDeleteView(generic.ObjectDeleteView):
    queryset = models.ContractService.objects.all()

# ContractServiceItem
class ContractServiceItemView(generic.ObjectView):
    queryset = models.ContractServiceItem.objects.all()

class ContractServiceItemListView(generic.ObjectListView):
    queryset = models.ContractServiceItem.objects.all()
    table = tables.ContractServiceItemTable
    filterset = filtersets.ContractServiceItemFilterSet
    filterset_form = forms.ContractServiceItemFilterForm

class ContractServiceItemEditView(generic.ObjectEditView):
    queryset = models.ContractServiceItem.objects.all()
    form = forms.ContractServiceItemForm
    template_name = 'netbox_itsm/contractserviceitem_edit.html'

class ContractServiceItemDeleteView(generic.ObjectDeleteView):
    queryset = models.ContractServiceItem.objects.all()

def ContractServiceItemGetObjects(request):
    content_type_id = request.GET.get("content_type")
    if not content_type_id:
        return JsonResponse({"choices": []})

    try:
        ct = ContentType.objects.get(id=content_type_id)
        model_class = ct.model_class()
        if not model_class:
            return JsonResponse({"choices": []})

        objects = model_class.objects.all()[:200]
        choices = [{"id": obj.id, "name": str(obj)} for obj in objects]
        return JsonResponse({"choices": choices})
    except ContentType.DoesNotExist:
        return JsonResponse({"choices": []})
