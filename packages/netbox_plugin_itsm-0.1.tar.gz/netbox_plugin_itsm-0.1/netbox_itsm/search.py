from netbox.search import SearchIndex, register_search

from .models import *

@register_search
class AccessListIndex(SearchIndex):
    model = Product
    fields = (
        ('name', 100),
        ('number', 500),
        ('description', 500),
        ('comments', 5000)
    )
    display_attrs = ('name', 'number', 'description')

@register_search
class ContractIndex(SearchIndex):
    model = Contract
    fields = (
        ('name', 100),
        ('number', 500),
        ('description', 500),
        ('comments', 5000)
    )
    display_attrs = ('name', 'number', 'description')

@register_search
class ContractServiceIndex(SearchIndex):
    model = ContractService
    fields = (
        ('name', 100),
        ('description', 500),
        ('comments', 5000)
    )
    display_attrs = ('name', 'description')
