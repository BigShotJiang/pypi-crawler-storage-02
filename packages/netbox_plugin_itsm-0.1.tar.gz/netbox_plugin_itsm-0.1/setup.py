from setuptools import find_packages, setup

setup(
    name='netbox-plugin-itsm',
    version='0.1',
    description='Manage contracts and services in NetBox.',
    install_requires=[],
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
)
