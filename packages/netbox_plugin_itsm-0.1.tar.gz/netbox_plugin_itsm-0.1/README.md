# netbox-plugin-itsm
Plugin to manage products, contracts and services and link them to specific objects within NetBox.

## Developement
Add plugin to the NetBox Python virtual environment.

```
source /opt/netbox/venv/bin/activate
pip3 install setuptools
python3 setup.py develop
```

Enable the plugin in NetBox.

```
cat /opt/netbox/netbox/netbox/configuration.py | grep -A 2 PLUGINS
PLUGINS = [
        'netbox_itsm'
]
```

Run migrations to add Django data models.

```
python3 /opt/netbox/netbox/manage.py migrate
```

## FAQ
### Changes to the data models
```
python3 /opt/netbox/netbox/manage.py makemigrations netbox_itsm
python3 /opt/netbox/netbox/manage.py migrate
```

### Other commands
```
python3 /opt/netbox/netbox/manage.py collectstatic
python3 /opt/netbox/netbox/manage.py nbshell

python3 /opt/netbox/netbox/manage.py runserver 127.0.0.1:8001
```
