from .oriented_matroid import OrientedMatroid
from .abstract_oriented_matroid import AbstractOrientedMatroid

# from sage.misc.lazy_import import lazy_import
# lazy_import('sage.matroids.oriented_matroids',
#            'oriented_matroids_catalog', 'oriented_matroids')
