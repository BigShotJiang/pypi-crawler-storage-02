r"""
Catalog of oriented matroids

A module containing constructors for several common oriented matroids

"""

# Do not add code to this file, only imports.

# user-accessible:
# from oriented_matroids.catalog import ...
