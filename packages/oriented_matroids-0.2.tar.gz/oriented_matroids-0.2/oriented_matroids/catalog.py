r"""
Documentation for the oriented matroids in the catalog

AUTHORS:

- Aram Dermenjian (): initial version
"""
