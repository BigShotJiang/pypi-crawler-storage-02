.. nodoctest

Real Hyperplane Arrangement Oriented Matroids
=============================================

.. automodule:: oriented_matroids.real_hyperplane_arrangement_oriented_matroid
    :members:
    :undoc-members:
    :show-inheritance:
