.. nodoctest

Oriented Matroids
=================

.. automodule:: oriented_matroids.oriented_matroid
    :members:
    :undoc-members:
    :show-inheritance:
