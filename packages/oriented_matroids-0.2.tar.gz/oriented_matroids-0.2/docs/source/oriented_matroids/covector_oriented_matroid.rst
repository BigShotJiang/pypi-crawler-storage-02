.. nodoctest

Covector Oriented Matroids
==========================

.. automodule:: oriented_matroids.covector_oriented_matroid
    :members:
    :undoc-members:
    :show-inheritance:
