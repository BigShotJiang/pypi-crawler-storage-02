.. nodoctest

Abstract Oriented Matroids
==========================

.. automodule:: oriented_matroids.abstract_oriented_matroid
    :members:
    :undoc-members:
    :show-inheritance:
