.. nodoctest

Circuit Oriented Matroids
=========================

.. automodule:: oriented_matroids.circuit_oriented_matroid
    :members:
    :undoc-members:
    :show-inheritance:
