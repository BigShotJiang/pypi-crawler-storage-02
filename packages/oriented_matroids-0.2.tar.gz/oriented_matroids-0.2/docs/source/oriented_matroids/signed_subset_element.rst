.. nodoctest

Signed Subsets
==============

.. automodule:: oriented_matroids.signed_subset_element
    :members:
    :undoc-members:
    :show-inheritance:
