.. nodoctest

Vector Oriented Matroids
========================

.. automodule:: oriented_matroids.vector_oriented_matroid
    :members:
    :undoc-members:
    :show-inheritance:
