import logging
from typing import Final

__all__ = ["LOGGER"]
LOGGER: Final = logging.getLogger("stompman")
