'<!--SKIP_FIX-->'
# pypaq

Little Python tools, mainly useful for tasks related to machine learning, etc.

-----------------

#### Naming conventions used
          
`n_*` - number of *<br>
`*L` - list<br>
`*D` - dictionary<br>
`*_ix` - index (int)<br>
`*_id` - ID (int or str)<br> 
`*_dir` `*_DIR` - directory, folder, relative or absolute<br>
`*_fn` `*_FN` - file name (without directory)<br>
`*_fp` `*_FP` - full path (directory + file name), relative or absolute<br>