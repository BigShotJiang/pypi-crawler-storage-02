class PyPaqException(Exception):
    pass