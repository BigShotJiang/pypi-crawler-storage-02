# ngtools-pyscript

 This is a pure python version of [ngtools](https://github.com/neuroscales/ngtools) that can be run in [pyscript](https://github.com/pyscript/pyscript).
