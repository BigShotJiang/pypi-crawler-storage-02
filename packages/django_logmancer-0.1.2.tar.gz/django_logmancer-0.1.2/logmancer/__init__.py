"""
Logmancer - Advanced logging and monitoring for Django applications.
"""

__version__ = "0.1.2"
__author__ = "Abdulsamet TATAR"
__email__ = "abdulsamettatar@gmail.com"

default_app_config = "logmancer.apps.LogmancerConfig"
