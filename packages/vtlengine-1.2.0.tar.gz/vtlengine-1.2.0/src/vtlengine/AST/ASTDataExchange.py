"""
AST.ASTDataExchange.py
=================

Description
-----------
Used to rewrite an operator across AST.
"""

de_ruleset_elements = {}
