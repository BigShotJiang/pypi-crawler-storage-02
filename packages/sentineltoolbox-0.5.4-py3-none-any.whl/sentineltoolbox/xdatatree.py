__all__ = ["xDataTree", "xDataTreeType"]

from typing import TypeAlias

from xarray import DataTree as xDataTree

xDataTreeType: TypeAlias = xDataTree
