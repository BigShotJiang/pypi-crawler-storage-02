from evidently.cli import app
from evidently.cli.ui import ui

__all__ = ["app", "ui"]

app()
