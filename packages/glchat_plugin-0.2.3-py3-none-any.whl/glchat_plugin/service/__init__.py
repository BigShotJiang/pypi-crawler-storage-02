"""Module for glchat_plugin custom service."""
