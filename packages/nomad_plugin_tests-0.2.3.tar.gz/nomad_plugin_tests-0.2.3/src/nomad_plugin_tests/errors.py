class PackageTestError(Exception):
    """Custom exception for package testing failures."""

    pass
