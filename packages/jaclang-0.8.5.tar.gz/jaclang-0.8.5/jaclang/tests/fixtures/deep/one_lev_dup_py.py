"""One level deeper py."""


def olpyprint() -> str:
    """One level deeper py."""
    return "one level deeper py"
