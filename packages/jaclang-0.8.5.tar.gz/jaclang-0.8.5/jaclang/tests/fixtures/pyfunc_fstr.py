




name = 'Peter'
relation = 'mother'
mom_name = 'Mary'


print(f"Hello {name}")
print(f"Hello {name} {name}")
print(f"{name} squared is {name} {name}")


print(f"{name.upper()}!  wrong poem.")
print(f"Hello {name} , yoo {relation} is {mom_name}. Myself, I am {name}.")



item = "Apple"
price = 1.23

print(f"Left aligned: {item:<10} | Price: {price:.2f}")
print(f"{name = } 🤔") 