def underscore_to_hyphen(name: str) -> str:
    return f"-{name.replace('_', '-')}"
