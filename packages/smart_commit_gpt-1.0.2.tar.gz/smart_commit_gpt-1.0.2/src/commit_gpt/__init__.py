"""Commit-GPT: AI-powered git commit message generator."""

__version__ = "0.1.0"
