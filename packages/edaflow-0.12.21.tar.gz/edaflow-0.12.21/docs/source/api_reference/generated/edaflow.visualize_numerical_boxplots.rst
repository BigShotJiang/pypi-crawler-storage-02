﻿edaflow.visualize\_numerical\_boxplots
======================================

.. currentmodule:: edaflow

.. autofunction:: visualize_numerical_boxplots