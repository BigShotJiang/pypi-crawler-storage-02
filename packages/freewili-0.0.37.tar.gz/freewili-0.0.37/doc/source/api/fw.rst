fw
========

.. automodule:: freewili.fw
   :members:
   :undoc-members:
   :show-inheritance: