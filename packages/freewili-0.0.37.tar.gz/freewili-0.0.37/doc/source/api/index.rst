API Reference
=============

Python API to interact with Free-Wili devices.

.. toctree::
   :maxdepth: 2

   fw
   framing
   image
   types