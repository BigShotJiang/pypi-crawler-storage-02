"""
Tests for pzserver/catalog.py
"""

# from pzserver.catalog import Catalog


def test_init():
    """
    Test initialization
    """
    value = 42
    assert value == 42
