"""
Version info for MSG91 Python Library
"""

__version__ = "0.1.6"
