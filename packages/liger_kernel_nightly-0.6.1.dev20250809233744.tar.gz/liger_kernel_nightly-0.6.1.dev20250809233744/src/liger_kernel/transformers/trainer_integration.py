# To not break HF Trainer integration
from liger_kernel.transformers.monkey_patch import _apply_liger_kernel  # noqa: F401
