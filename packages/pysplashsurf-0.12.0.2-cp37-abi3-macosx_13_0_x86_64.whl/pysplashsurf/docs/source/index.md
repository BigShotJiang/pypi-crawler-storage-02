```{include} ../../../README.md
```

```{toctree}
:caption: Table of Contents
methods
classes
api
```