class TablesBase:
    User = "User"
    Role = "Role"
    UserRole = "UserRole"
    Image = "Image"
