# LiteLLM Extension for PandasAI

This extension integrates LiteLLM with PandasAI.

## Installation

You can install this extension using poetry:

```bash
poetry add pandasai-litellm
```
