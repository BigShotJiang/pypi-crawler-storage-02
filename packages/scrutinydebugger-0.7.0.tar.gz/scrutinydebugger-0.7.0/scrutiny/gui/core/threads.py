#    threads.py
#        Some threading global definition used to enforce thread
#
#   - License : MIT - See LICENSE file.
#   - Project :  Scrutiny Debugger (github.com/scrutinydebugger/scrutiny-main)
#
#   Copyright (c) 2022 Scrutiny Debugger

QT_THREAD_NAME = "QT"
SERVER_MANAGER_THREAD_NAME = "ServerManager"
