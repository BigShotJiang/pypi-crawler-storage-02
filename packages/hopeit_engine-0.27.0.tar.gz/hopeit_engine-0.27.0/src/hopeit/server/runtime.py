"""
Server runtime: module to keep a reference to current runtime hopeit engine Server object
"""

from hopeit.server.engine import Server


server = Server()
