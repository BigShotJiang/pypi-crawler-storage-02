"""Handles data from Bruker MRI scan machines and converts them to
aind-data-schema models"""
