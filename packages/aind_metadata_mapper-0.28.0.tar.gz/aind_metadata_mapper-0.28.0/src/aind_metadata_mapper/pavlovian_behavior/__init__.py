"""Maps Pavlovian Behavior metadata into a session model"""
