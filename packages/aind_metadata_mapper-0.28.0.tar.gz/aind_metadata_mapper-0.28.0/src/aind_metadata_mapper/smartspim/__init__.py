"""SmartSPIM package"""
