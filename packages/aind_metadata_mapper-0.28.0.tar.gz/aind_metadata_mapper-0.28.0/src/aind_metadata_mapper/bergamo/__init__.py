"""Maps bergamo metadata into a session model"""
