"""Maps Fiber photometry metadata into a session model"""
