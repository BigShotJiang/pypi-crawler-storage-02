"""Maps dynamic_routing related metadata."""


class NeuropixelsRigException(Exception):
    """General error for Neuropixels rig."""
