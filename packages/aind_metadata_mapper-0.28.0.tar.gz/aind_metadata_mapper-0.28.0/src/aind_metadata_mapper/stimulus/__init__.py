"""
Stimulus utils
"""
