"""Maps open_ephys metadata into a session model"""
