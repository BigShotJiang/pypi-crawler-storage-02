"""Shared utility functions for AIND metadata mappers.

This package contains utility functions used by multiple metadata mapper
modules.
"""
