from .variable import TextVariable, NumericalVariable

__all__ = ("TextVariable", "NumericalVariable")
