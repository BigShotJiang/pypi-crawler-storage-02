standard_name_core_pattern = r'^[a-z0-9]+(?:_[a-z0-9]+)*$'
raise_error_on_unparsable_unit = True
