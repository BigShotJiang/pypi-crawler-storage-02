# Syntax:  from "file (without .py)" import "function name"

from .quality500 import qualitystatus500
