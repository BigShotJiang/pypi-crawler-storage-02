__version__ = "1.8.8"

from .module1 import *
from .updatestatistics import upd
from . import gencockpitsubV0001   # directory
from . import migV0001   # directory
from . import cleanupV0001
from . import sumV0001
