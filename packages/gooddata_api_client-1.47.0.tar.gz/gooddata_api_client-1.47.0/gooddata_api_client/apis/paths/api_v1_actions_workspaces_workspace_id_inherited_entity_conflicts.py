from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_inherited_entity_conflicts.get import ApiForget


class ApiV1ActionsWorkspacesWorkspaceIdInheritedEntityConflicts(
    ApiForget,
):
    pass
