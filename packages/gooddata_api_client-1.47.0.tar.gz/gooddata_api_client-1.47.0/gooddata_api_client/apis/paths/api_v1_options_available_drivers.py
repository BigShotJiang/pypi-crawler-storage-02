from gooddata_api_client.paths.api_v1_options_available_drivers.get import ApiForget


class ApiV1OptionsAvailableDrivers(
    ApiForget,
):
    pass
