from gooddata_api_client.paths.api_v1_entities_organization_settings.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_organization_settings.post import ApiForpost


class ApiV1EntitiesOrganizationSettings(
    ApiForget,
    ApiForpost,
):
    pass
