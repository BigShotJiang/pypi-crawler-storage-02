from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_data_filter_settings_object_id.get import ApiForget


class ApiV1EntitiesWorkspacesWorkspaceIdWorkspaceDataFilterSettingsObjectId(
    ApiForget,
):
    pass
