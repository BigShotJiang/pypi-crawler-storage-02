# -*- coding: utf-8 -*-

"""
AWS related tools.
"""