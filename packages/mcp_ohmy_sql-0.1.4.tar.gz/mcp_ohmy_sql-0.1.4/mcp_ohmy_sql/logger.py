# -*- coding: utf-8 -*-

from vislog import VisLog

logger = VisLog(
    name="mcp_ohmy_sql",
    log_format="%(message)s",
)
