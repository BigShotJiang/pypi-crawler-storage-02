ALTER TABLE identities ADD COLUMN first_eligible_ud integer not null default 0;
