ALTER TABLE identities ADD COLUMN name varchar(255);
