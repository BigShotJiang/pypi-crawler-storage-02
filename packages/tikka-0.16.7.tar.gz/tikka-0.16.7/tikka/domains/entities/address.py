# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
class DisplayAddress:
    """
    Class to handle display of wallet address
    """

    def __init__(self, address: str) -> None:
        """
        Init a DisplayAddress instance from the address

        :param address: Wallet address
        """
        self.address = address

    @property
    def shorten(self) -> str:
        """
        Return a shorten version of address (first 4 and last 4 characters)

        :return:
        """
        return f"{self.address[0:4]}…{self.address[-4:]}"

    def __str__(self) -> str:
        """
        Return string representation of instance

        :return:
        """
        return f"{self.address}"

    def __eq__(self, other) -> bool:
        """
        Test PublicKey equality

        :param other: Other PublicKey instance
        :return:
        """
        if not isinstance(other, DisplayAddress):
            return False

        if self.address == other.address:
            return True

        return False

    def __hash__(self):
        return self.address
