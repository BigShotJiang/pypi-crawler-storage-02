"""kpf - Kubectl Port-Forward Utility."""

__version__ = "0.1.14"
__author__ = "Jesse Goodier"
__description__ = "A Python utility to run kubectl port-forward and automatically restart it when endpoint changes are detected"
