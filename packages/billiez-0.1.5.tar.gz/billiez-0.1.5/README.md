# billiez

Generates rhymes using NVIDIA's AI API

## Installation
```bash
pip install billiez