from setuptools import setup

setup(packages=['safep'])
