from .cli import main

__all__ = ["main"]


# test with: python -m dodal
if __name__ == "__main__":
    main()
