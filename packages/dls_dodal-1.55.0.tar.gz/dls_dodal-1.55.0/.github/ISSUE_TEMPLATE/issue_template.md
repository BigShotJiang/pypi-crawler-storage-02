---
name: issue_template
about: The standard template to use
title: " "
labels: ''
assignees: ''

---

A brief description of the issue, if it's for a specific beamline say which beamline and why they want it

## Acceptance Criteria
* Specific criteria that will be used to judge if the issue is fixed
