fake_zocalo
===========================

.. note::

    This is meant to be used for testing hyperion. Don't try to process any real
    data with it! You will just get back (1.2, 2.3, 3.4).

## To run:

* Run `dls_start_fake_zocalo.sh`
* For Hyperion to connect to this you will need to run `module load dials/latest` in the terminal you're runnign Hyperion in
