from ..modules import *
from ..utils import *

class FilesManager():
    def __init__(self):
        self.overwrite      = False
        self.fast_mode      = False