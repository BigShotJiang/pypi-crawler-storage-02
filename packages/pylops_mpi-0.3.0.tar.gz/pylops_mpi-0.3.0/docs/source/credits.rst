.. _credits:

Contributors
============

*  `Rohan Babbar <https://github.com/rohanbabbar04>`_, rohanbabbar04
*  `Yuxi Hong <https://github.com/hongyx11>`_, hongyx11
*  `Matteo Ravasi <https://github.com/mrava87>`_, mrava87
*  `Tharit Tangkijwanichakul <https://github.com/tharittk>`_, tharittk