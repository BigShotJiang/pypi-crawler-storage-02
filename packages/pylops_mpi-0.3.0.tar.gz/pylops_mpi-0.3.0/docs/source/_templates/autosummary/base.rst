{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. auto{{ objtype }}:: {{ objname }}

.. raw:: html

      <div style='clear:both'></div>
