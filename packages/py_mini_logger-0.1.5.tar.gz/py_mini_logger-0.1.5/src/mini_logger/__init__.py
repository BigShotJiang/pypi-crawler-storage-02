#!/usr/bin/env python3

# Copyright 2024 (author: lamnguyenx)

from .mini_logger import getLogger
