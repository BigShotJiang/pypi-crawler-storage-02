# v0.1.7
- just changed some file structure stuff and changed the line to get config file path

# v0.1.6
- Dnf support
- Custom sudobin support

# v0.1.5
- Added a loading animation when listing updates
- `--no-spinner` argument to not show spinner
- Warns when `pacman-contrib` is missing if using pacman

# v0.1.4
- Added support for arguments, see [README.md](./README.md)
- Now uses path to package manager's executable
- Prints the full command used when updating
- Uses aur helper instead of pacman for updating if enabled
- `-v`, `--version` to print package version

# v0.1.0
- Initial release
