from .azure_alert_parser import Azure
__all__ = ["Azure"]
