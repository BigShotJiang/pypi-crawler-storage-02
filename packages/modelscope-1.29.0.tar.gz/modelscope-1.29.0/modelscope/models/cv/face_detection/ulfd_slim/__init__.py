# Copyright (c) Alibaba, Inc. and its affiliates.
from .detection import UlfdFaceDetector
