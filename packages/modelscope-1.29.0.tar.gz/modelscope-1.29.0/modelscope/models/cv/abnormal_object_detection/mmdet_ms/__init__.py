# Copyright (c) Alibaba, Inc. and its affiliates.
from .roi_head import MaskScoringNRoIHead, SingleRoINExtractor
