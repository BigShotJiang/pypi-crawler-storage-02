2025-07-22 Version: 4.0.2
- Update API CreateFlowLog: add request parameters ResourceGroupId.
- Update API CreateFlowLog: add request parameters Tag.
- Update API DescribeFlowLogs: add request parameters ResourceGroupId.
- Update API DescribeFlowLogs: add request parameters Tag.


2025-02-17 Version: 4.0.0
- Support API ActivateFlowLog.
- Support API CreateFlowLog.
- Support API DeactivateFlowLog.
- Support API DeleteFlowlog.
- Support API DescribeFlowLogs.
- Support API ModifyFlowLogAttribute.
- Update API AttachExpressConnectRouterChildInstance: add param Description.
- Update API CreateExpressConnectRouter: add param Tag.
- Update API CreateExpressConnectRouter: delete param Tags.
- Update API CreateExpressConnectRouterAssociation: add param AllowedPrefixesMode.
- Update API CreateExpressConnectRouterAssociation: add param Description.
- Update API DescribeExpressConnectRouter: add param Tag.
- Update API DescribeExpressConnectRouter: delete param TagModels.
- Update API DescribeExpressConnectRouter: update response param.
- Update API DescribeExpressConnectRouterAssociation: update response param.
- Update API DescribeExpressConnectRouterChildInstance: update response param.
- Update API DescribeExpressConnectRouterRouteEntries: update response param.
- Update API DescribeInstanceGrantedToExpressConnectRouter: add param CallerType.
- Update API DescribeInstanceGrantedToExpressConnectRouter: update response param.
- Update API ListTagResources: update param Tag.
- Update API ModifyExpressConnectRouterAssociationAllowedPrefix: add param AllowedPrefixesMode.


2024-06-17 Version: 3.1.0
- Support API ListTagResources.
- Support API MoveResourceGroup.
- Support API TagResources.
- Support API UntagResources.


2024-05-16 Version: 3.0.2
- Update API CreateExpressConnectRouter: add param Tags.
- Update API CreateExpressConnectRouterAssociation: update param AllowedPrefixes.
- Update API ModifyExpressConnectRouterAssociationAllowedPrefix: update param AllowedPrefixes.


2024-03-26 Version: 3.0.1
- Update API DescribeExpressConnectRouterChildInstance: update response param.


2024-03-22 Version: 3.0.0
- Update API DescribeExpressConnectRouterAllowedPrefixHistory: add param AssociationId.
- Update API DescribeExpressConnectRouterAllowedPrefixHistory: delete param AssociatonId.


2024-03-19 Version: 2.0.0
- Delete API GetExpressConnectRouter.


2024-03-12 Version: 1.0.0
- Generated python 2023-09-01 for ExpressConnectRouter.

