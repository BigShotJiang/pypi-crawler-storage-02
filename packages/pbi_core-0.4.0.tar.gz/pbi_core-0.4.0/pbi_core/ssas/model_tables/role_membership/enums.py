from enum import IntEnum


class MemberType(IntEnum):
    Auto = 1
    User = 2
    Group = 3
