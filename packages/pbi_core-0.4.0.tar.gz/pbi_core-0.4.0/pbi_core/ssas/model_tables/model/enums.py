from enum import IntEnum


class DefaultDataView(IntEnum):
    Full = 0
    Sample = 1
    Default = 3
