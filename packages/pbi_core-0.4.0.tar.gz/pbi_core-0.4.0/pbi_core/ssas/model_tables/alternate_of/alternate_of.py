from pbi_core.ssas.model_tables.base import SsasReadonlyRecord


class AlternateOf(SsasReadonlyRecord):
    """TBD.

    SSAS spec:
    """
