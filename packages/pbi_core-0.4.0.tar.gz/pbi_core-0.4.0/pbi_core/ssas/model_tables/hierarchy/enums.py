from enum import IntEnum


class HideMembers(IntEnum):
    Default = 0
    HideBlankMembers = 1
