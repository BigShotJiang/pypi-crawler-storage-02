# Role Membership


::: pbi_core.ssas.model_tables.role_membership.RoleMembership