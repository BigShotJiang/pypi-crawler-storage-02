# Expression


::: pbi_core.ssas.model_tables.expression.Expression