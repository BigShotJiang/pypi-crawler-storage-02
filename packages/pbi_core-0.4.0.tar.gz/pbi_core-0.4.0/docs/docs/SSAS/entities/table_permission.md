# Table Permission


::: pbi_core.ssas.model_tables.table_permission.TablePermission