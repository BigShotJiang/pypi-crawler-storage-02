import { createRoot } from "react-dom/client";
import AuthCallback from "./authCallback";

createRoot(document.getElementById("root")!).render(<AuthCallback />);
