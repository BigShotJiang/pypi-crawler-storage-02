"""
Solace Agent Mesh Initialization
"""
from .common.utils.initializer import initialize
initialize()
