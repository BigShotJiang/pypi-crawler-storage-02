"""Common utilities and types shared across A2A components."""
