from django.apps import AppConfig


class LocalcosmosServerConfig(AppConfig):
    name = 'localcosmos_server'
