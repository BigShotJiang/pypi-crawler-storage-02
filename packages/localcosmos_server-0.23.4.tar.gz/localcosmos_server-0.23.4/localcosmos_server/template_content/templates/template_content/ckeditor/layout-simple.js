{ 
	toolbar: ['bold', 'italic', 'underline', '|', 'undo', 'redo']
}
