"""Tests for the coursemap Python package."""
