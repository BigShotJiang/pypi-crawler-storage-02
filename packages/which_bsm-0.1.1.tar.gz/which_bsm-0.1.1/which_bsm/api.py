# -*- coding: utf-8 -*-

from .impl import get_aws_account_id_in_ci
from .impl import BaseBotoSesEnum
