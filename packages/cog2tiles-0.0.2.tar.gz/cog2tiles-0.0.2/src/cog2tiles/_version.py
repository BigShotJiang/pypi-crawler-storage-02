"""Version information for cog2tiles."""

__version__ = "0.0.2"
