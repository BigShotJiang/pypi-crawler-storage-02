## v0.0.2 (2025-08-14)

### Fix

- **cz**: adds cz version
- **ci**: adds ci to publish the package
