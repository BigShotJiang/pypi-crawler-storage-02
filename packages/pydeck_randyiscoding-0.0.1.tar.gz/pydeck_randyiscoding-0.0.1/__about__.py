# --------------------------------------------------------
# Name: Randy Easton
# Date: 8/3/2025
# Assignment: [Insert Assignment Name or Number Here]
# --------------------------------------------------------
# Purpose:
# [Brief one-sentence description of what the program does]
# --------------------------------------------------------

__version__ = "0.0.1"
__author__ = "Randy H. Easton Jr"
__email__ = "reaston@my365.bellevue.edu"
__license__ = "MIT"
__description__ = "A playing card deck module for use in Python games."
