# --------------------------------------------------------
# Name: Randy Easton
# Date: 8/2/2025
# Assignment: [Insert Assignment Name or Number Here]
# --------------------------------------------------------
# Purpose:
# [Brief one-sentence description of what the program does]
# --------------------------------------------------------
from pydeck.src.pydeck_randyiscoding.deck_of_cards import Deck



def main():
    # Main function to control program flow
    pass


# Function definitions go here
# Use descriptive names and explain any non-obvious logic
# Example:
def example_function():
    """
    Describe what this function does.
    """
    pass


# Program starts here
if __name__ == "__main__":
    main()
