"""Measurement constants"""

# -- Constants ----------------------------------------------------------------

ADC_MAX_VALUE = 0xFFFF
"""Maximum value of (16 bit) ADC"""
