"""Support code for EEPROM data"""
