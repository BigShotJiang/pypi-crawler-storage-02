* Michael Tietz (MT Software) <mtietz@mt-software.de>
* Jacques-Etienne Baudoux (BCIM) <je@bcim.be>
