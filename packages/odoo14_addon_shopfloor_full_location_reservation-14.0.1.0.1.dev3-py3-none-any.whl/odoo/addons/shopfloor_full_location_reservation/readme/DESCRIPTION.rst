Adds a configuration to the shopfloor scenario which allows to trigger the stock full location reservation
