"""The casm-map commands"""
