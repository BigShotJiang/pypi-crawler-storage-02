"""
term – Transparent Easy Rule Model
"""
from .rule import Rule

__all__ = ["Rule"]
__version__ = "0.1.0"
