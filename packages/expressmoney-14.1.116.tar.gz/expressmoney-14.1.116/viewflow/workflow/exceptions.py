class FlowRuntimeError(Exception):
    """Unrecoverable flow runtime error."""


class FlowLockFailed(Exception):
    """Flow lock failed."""
