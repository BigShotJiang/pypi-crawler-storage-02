"""
Test suite for DoorDash Python Client
"""