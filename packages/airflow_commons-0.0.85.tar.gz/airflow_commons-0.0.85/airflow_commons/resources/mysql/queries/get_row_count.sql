SELECT COUNT(*) FROM
    `{table_name}`
{where_clause}
    {where_statement};