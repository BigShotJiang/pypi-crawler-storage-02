from petrus._api import *  # main, run
from petrus.tests import *  # test

if __name__ == "__main__":
    main()
