Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass -File `"$PSScriptRoot\mulch-workspace.ps1`"" -WindowStyle Hidden
