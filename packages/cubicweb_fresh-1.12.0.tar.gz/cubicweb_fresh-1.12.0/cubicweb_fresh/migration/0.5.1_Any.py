sync_schema_props_perms("spent_for", syncprops=False)
