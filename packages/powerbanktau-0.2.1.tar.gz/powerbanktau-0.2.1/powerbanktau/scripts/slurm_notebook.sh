#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<EOF
Usage: $0 <workdir> [options]

<workdir>             : directory in which to start Jupyter Lab
--partition  <name>   : SLURM partition (default: engineering)
--mem        <size>   : RAM per node, e.g. 30G (default: 5G)
--cpus       <n>      : number of CPUs (default: 2)
--time      <HH:MM:SS>: job time (default: 04:00:00)
--jobname   <name>    : SLURM job name (default: jupyter)
--port      <port>    : Jupyter Lab port (default: 8888)
EOF
  exit 1
}

# defaults
partition="engineering"
mem="5G"
cpus=2
time="04:00:00"
jobname="jupyter"
base_port=8888

# require at least one arg
if [ $# -lt 1 ]; then
  usage
fi

# first positional is workdir
workdir=$1
shift

# parse optional flags
while [ $# -gt 0 ]; do
  case $1 in
    --partition)  partition=$2; shift 2;;
    --mem)        mem=$2;       shift 2;;
    --cpus)       cpus=$2;      shift 2;;
    --time)       time=$2;      shift 2;;
    --jobname)    jobname=$2;   shift 2;;
    --port)       base_port=$2; shift 2;;
    -h|--help)    usage;;
    *)
      echo "Unknown option: $1"; usage;;
  esac
done

# make sure workdir exists
if [ ! -d "$workdir" ]; then
  echo "Error: workdir '$workdir' not found."
  exit 1
fi

# ensure logging directories exist
outdir="${HOME}/logging/output"
errdir="${HOME}/logging/error"
mkdir -p "$outdir" "$errdir"

# submit the SLURM job
sbatch <<EOF
#!/bin/bash
#SBATCH --partition=$partition
#SBATCH --cpus-per-task=$cpus
#SBATCH --mem=$mem
#SBATCH --time=$time
#SBATCH --job-name=$jobname
#SBATCH --output=$outdir/slurm-%j.out
#SBATCH --error=$errdir/slurm-%j.err

echo "=== Allocated on \$(hostname) ==="
echo "Job ID: \$SLURM_JOB_ID"
echo "CPUs:   $cpus   Memory: $mem"
echo "Partition:  $partition   Time: $time"
echo "Starting in: $workdir"
echo

# load conda and activate
source /tamir2/nicolaslynn/home/miniconda3/etc/profile.d/conda.sh
conda activate base

# go to the workdir
cd $workdir

# launch Jupyter Lab
echo "Launching Jupyter Lab on port $base_port..."
jupyter lab --ip=0.0.0.0 --port=$base_port --no-browser
EOF

echo "Submitted SLURM job '$jobname' in partition '$partition' with $cpus CPUs, $mem RAM, time $time."
echo "Logs will go to $outdir and $errdir.  Jupyter on port $base_port."