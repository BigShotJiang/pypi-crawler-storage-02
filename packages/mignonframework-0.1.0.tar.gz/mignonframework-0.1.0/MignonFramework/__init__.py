"""
这是关于mignon的 Python FrameWork
Queue 顺序打乱器,支持数组或者range
ConfigReader 配置文件读取以及写入
CountLinesInFolder  统计单文件或者文件夹内的行数(支持正则,前缀后缀匹配)
Deduplicate 去重
Logger 日志类
PortForwarding 端口转发
Curl2Request Curl转Request
"""




