[![doi](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.13352143-red.svg)](https://zenodo.org/records/13352143)

# PyXMake
> This subpackage belongs to [PyXMake](https://gitlab.com/dlr-sy/pyxmake) and provides various web services using [fastapi](https://fastapi.tiangolo.com/) as an optional dependency. It can be installed together with the parent project. However, it is also separately available to ensure backwards compatibility. Please refer to the linked [repository](https://gitlab.com/dlr-sy/pyxmake) for documentation and application examples.
