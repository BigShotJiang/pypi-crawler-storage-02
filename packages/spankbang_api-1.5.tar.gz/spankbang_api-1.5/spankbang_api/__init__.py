__all__ = ['Client', "Search", "Callback", "consts"]

from spankbang_api.spankbang_api import Client, Search, Callback, Video
from spankbang_api.modules import consts