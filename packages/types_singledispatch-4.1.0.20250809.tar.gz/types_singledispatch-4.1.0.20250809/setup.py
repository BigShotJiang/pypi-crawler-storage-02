
from setuptools import setup

setup(package_data={'singledispatch-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
