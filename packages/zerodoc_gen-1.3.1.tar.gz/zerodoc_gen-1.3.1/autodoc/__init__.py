"""AutoDoc - Zero-config documentation generator with beautiful UI."""

__version__ = "1.3.1"
__author__ = "AutoDoc Team"
__license__ = "MIT"