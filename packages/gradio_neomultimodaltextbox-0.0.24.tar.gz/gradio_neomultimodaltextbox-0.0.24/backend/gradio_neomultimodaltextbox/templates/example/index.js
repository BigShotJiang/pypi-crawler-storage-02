const { setContext: Eu, getContext: Gn } = window.__gradio__svelte__internal, $n = "WORKER_PROXY_CONTEXT_KEY";
function Kn() {
  return Gn($n);
}
const Vn = "lite.local";
function Hn(n) {
  return n.host === window.location.host || n.host === "localhost:7860" || n.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  n.host === Vn;
}
function Wn(n, e) {
  const t = e.toLowerCase();
  for (const [s, i] of Object.entries(n))
    if (s.toLowerCase() === t)
      return i;
}
function Yn(n) {
  const e = typeof window < "u";
  if (n == null || !e)
    return !1;
  const t = new URL(n, window.location.href);
  return !(!Hn(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let ht;
async function Sr(n) {
  const e = typeof window < "u";
  if (n == null || !e || !Yn(n))
    return n;
  if (ht == null)
    try {
      ht = Kn();
    } catch {
      return n;
    }
  if (ht == null)
    return n;
  const s = new URL(n, window.location.href).pathname;
  return ht.httpRequest({
    method: "GET",
    path: s,
    headers: {},
    query_string: ""
  }).then((i) => {
    if (i.status !== 200)
      throw new Error(`Failed to get file ${s} from the Wasm worker.`);
    const r = new Blob([i.body], {
      type: Wn(i.headers, "content-type")
    });
    return URL.createObjectURL(r);
  });
}
const {
  SvelteComponent: qn,
  assign: Es,
  bubble: jn,
  claim_element: zn,
  compute_rest_props: ti,
  detach: Xn,
  element: Qn,
  exclude_internal_props: Jn,
  get_spread_update: Zn,
  init: ea,
  insert_hydration: ta,
  listen: sa,
  noop: si,
  safe_not_equal: ia,
  set_attributes: ii,
  src_url_equal: ra,
  toggle_class: ri
} = window.__gradio__svelte__internal;
function na(n) {
  let e, t, s, i, r = [
    {
      src: t = /*resolved_src*/
      n[0]
    },
    /*$$restProps*/
    n[1]
  ], a = {};
  for (let o = 0; o < r.length; o += 1)
    a = Es(a, r[o]);
  return {
    c() {
      e = Qn("img"), this.h();
    },
    l(o) {
      e = zn(o, "IMG", { src: !0 }), this.h();
    },
    h() {
      ii(e, a), ri(e, "svelte-kxeri3", !0);
    },
    m(o, l) {
      ta(o, e, l), s || (i = sa(
        e,
        "load",
        /*load_handler*/
        n[4]
      ), s = !0);
    },
    p(o, [l]) {
      ii(e, a = Zn(r, [
        l & /*resolved_src*/
        1 && !ra(e.src, t = /*resolved_src*/
        o[0]) && { src: t },
        l & /*$$restProps*/
        2 && /*$$restProps*/
        o[1]
      ])), ri(e, "svelte-kxeri3", !0);
    },
    i: si,
    o: si,
    d(o) {
      o && Xn(e), s = !1, i();
    }
  };
}
function aa(n, e, t) {
  const s = ["src"];
  let i = ti(e, s), { src: r = void 0 } = e, a, o;
  function l(c) {
    jn.call(this, n, c);
  }
  return n.$$set = (c) => {
    e = Es(Es({}, e), Jn(c)), t(1, i = ti(e, s)), "src" in c && t(2, r = c.src);
  }, n.$$.update = () => {
    if (n.$$.dirty & /*src, latest_src*/
    12) {
      t(0, a = r), t(3, o = r);
      const c = r;
      Sr(c).then((h) => {
        o === c && t(0, a = h);
      });
    }
  }, [a, i, r, o, l];
}
class oa extends qn {
  constructor(e) {
    super(), ea(this, e, aa, na, ia, { src: 2 });
  }
}
const la = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ni = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
la.reduce(
  (n, { color: e, primary: t, secondary: s }) => ({
    ...n,
    [e]: {
      primary: ni[e][t],
      secondary: ni[e][s]
    }
  }),
  {}
);
var ai;
(function(n) {
  n.LOAD = "LOAD", n.EXEC = "EXEC", n.WRITE_FILE = "WRITE_FILE", n.READ_FILE = "READ_FILE", n.DELETE_FILE = "DELETE_FILE", n.RENAME = "RENAME", n.CREATE_DIR = "CREATE_DIR", n.LIST_DIR = "LIST_DIR", n.DELETE_DIR = "DELETE_DIR", n.ERROR = "ERROR", n.DOWNLOAD = "DOWNLOAD", n.PROGRESS = "PROGRESS", n.LOG = "LOG", n.MOUNT = "MOUNT", n.UNMOUNT = "UNMOUNT";
})(ai || (ai = {}));
function ca(n, { autoplay: e }) {
  async function t() {
    e && await n.play();
  }
  return n.addEventListener("loadeddata", t), {
    destroy() {
      n.removeEventListener("loadeddata", t);
    }
  };
}
function ha(n) {
  return n && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n;
}
var vr = { exports: {} };
(function(n, e) {
  (function(t) {
    var s = /^(?=((?:[a-zA-Z0-9+\-.]+:)?))\1(?=((?:\/\/[^\/?#]*)?))\2(?=((?:(?:[^?#\/]*\/)*[^;?#\/]*)?))\3((?:;[^?#]*)?)(\?[^#]*)?(#[^]*)?$/, i = /^(?=([^\/?#]*))\1([^]*)$/, r = /(?:\/|^)\.(?=\/)/g, a = /(?:\/|^)\.\.\/(?!\.\.\/)[^\/]*(?=\/)/g, o = {
      // If opts.alwaysNormalize is true then the path will always be normalized even when it starts with / or //
      // E.g
      // With opts.alwaysNormalize = false (default, spec compliant)
      // http://a.com/b/cd + /e/f/../g => http://a.com/e/f/../g
      // With opts.alwaysNormalize = true (not spec compliant)
      // http://a.com/b/cd + /e/f/../g => http://a.com/e/g
      buildAbsoluteURL: function(l, c, h) {
        if (h = h || {}, l = l.trim(), c = c.trim(), !c) {
          if (!h.alwaysNormalize)
            return l;
          var u = o.parseURL(l);
          if (!u)
            throw new Error("Error trying to parse base URL.");
          return u.path = o.normalizePath(
            u.path
          ), o.buildURLFromParts(u);
        }
        var d = o.parseURL(c);
        if (!d)
          throw new Error("Error trying to parse relative URL.");
        if (d.scheme)
          return h.alwaysNormalize ? (d.path = o.normalizePath(d.path), o.buildURLFromParts(d)) : c;
        var f = o.parseURL(l);
        if (!f)
          throw new Error("Error trying to parse base URL.");
        if (!f.netLoc && f.path && f.path[0] !== "/") {
          var g = i.exec(f.path);
          f.netLoc = g[1], f.path = g[2];
        }
        f.netLoc && !f.path && (f.path = "/");
        var m = {
          // 2c) Otherwise, the embedded URL inherits the scheme of
          // the base URL.
          scheme: f.scheme,
          netLoc: d.netLoc,
          path: null,
          params: d.params,
          query: d.query,
          fragment: d.fragment
        };
        if (!d.netLoc && (m.netLoc = f.netLoc, d.path[0] !== "/"))
          if (!d.path)
            m.path = f.path, d.params || (m.params = f.params, d.query || (m.query = f.query));
          else {
            var E = f.path, T = E.substring(0, E.lastIndexOf("/") + 1) + d.path;
            m.path = o.normalizePath(T);
          }
        return m.path === null && (m.path = h.alwaysNormalize ? o.normalizePath(d.path) : d.path), o.buildURLFromParts(m);
      },
      parseURL: function(l) {
        var c = s.exec(l);
        return c ? {
          scheme: c[1] || "",
          netLoc: c[2] || "",
          path: c[3] || "",
          params: c[4] || "",
          query: c[5] || "",
          fragment: c[6] || ""
        } : null;
      },
      normalizePath: function(l) {
        for (l = l.split("").reverse().join("").replace(r, ""); l.length !== (l = l.replace(a, "")).length; )
          ;
        return l.split("").reverse().join("");
      },
      buildURLFromParts: function(l) {
        return l.scheme + l.netLoc + l.path + l.params + l.query + l.fragment;
      }
    };
    n.exports = o;
  })();
})(vr);
var Ns = vr.exports;
function oi(n, e) {
  var t = Object.keys(n);
  if (Object.getOwnPropertySymbols) {
    var s = Object.getOwnPropertySymbols(n);
    e && (s = s.filter(function(i) {
      return Object.getOwnPropertyDescriptor(n, i).enumerable;
    })), t.push.apply(t, s);
  }
  return t;
}
function oe(n) {
  for (var e = 1; e < arguments.length; e++) {
    var t = arguments[e] != null ? arguments[e] : {};
    e % 2 ? oi(Object(t), !0).forEach(function(s) {
      fa(n, s, t[s]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(t)) : oi(Object(t)).forEach(function(s) {
      Object.defineProperty(n, s, Object.getOwnPropertyDescriptor(t, s));
    });
  }
  return n;
}
function ua(n, e) {
  if (typeof n != "object" || !n) return n;
  var t = n[Symbol.toPrimitive];
  if (t !== void 0) {
    var s = t.call(n, e || "default");
    if (typeof s != "object") return s;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(n);
}
function da(n) {
  var e = ua(n, "string");
  return typeof e == "symbol" ? e : String(e);
}
function fa(n, e, t) {
  return e = da(e), e in n ? Object.defineProperty(n, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : n[e] = t, n;
}
function se() {
  return se = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var s in t)
        Object.prototype.hasOwnProperty.call(t, s) && (n[s] = t[s]);
    }
    return n;
  }, se.apply(this, arguments);
}
const M = Number.isFinite || function(n) {
  return typeof n == "number" && isFinite(n);
}, ga = Number.isSafeInteger || function(n) {
  return typeof n == "number" && Math.abs(n) <= ma;
}, ma = Number.MAX_SAFE_INTEGER || 9007199254740991;
let p = /* @__PURE__ */ function(n) {
  return n.MEDIA_ATTACHING = "hlsMediaAttaching", n.MEDIA_ATTACHED = "hlsMediaAttached", n.MEDIA_DETACHING = "hlsMediaDetaching", n.MEDIA_DETACHED = "hlsMediaDetached", n.BUFFER_RESET = "hlsBufferReset", n.BUFFER_CODECS = "hlsBufferCodecs", n.BUFFER_CREATED = "hlsBufferCreated", n.BUFFER_APPENDING = "hlsBufferAppending", n.BUFFER_APPENDED = "hlsBufferAppended", n.BUFFER_EOS = "hlsBufferEos", n.BUFFER_FLUSHING = "hlsBufferFlushing", n.BUFFER_FLUSHED = "hlsBufferFlushed", n.MANIFEST_LOADING = "hlsManifestLoading", n.MANIFEST_LOADED = "hlsManifestLoaded", n.MANIFEST_PARSED = "hlsManifestParsed", n.LEVEL_SWITCHING = "hlsLevelSwitching", n.LEVEL_SWITCHED = "hlsLevelSwitched", n.LEVEL_LOADING = "hlsLevelLoading", n.LEVEL_LOADED = "hlsLevelLoaded", n.LEVEL_UPDATED = "hlsLevelUpdated", n.LEVEL_PTS_UPDATED = "hlsLevelPtsUpdated", n.LEVELS_UPDATED = "hlsLevelsUpdated", n.AUDIO_TRACKS_UPDATED = "hlsAudioTracksUpdated", n.AUDIO_TRACK_SWITCHING = "hlsAudioTrackSwitching", n.AUDIO_TRACK_SWITCHED = "hlsAudioTrackSwitched", n.AUDIO_TRACK_LOADING = "hlsAudioTrackLoading", n.AUDIO_TRACK_LOADED = "hlsAudioTrackLoaded", n.SUBTITLE_TRACKS_UPDATED = "hlsSubtitleTracksUpdated", n.SUBTITLE_TRACKS_CLEARED = "hlsSubtitleTracksCleared", n.SUBTITLE_TRACK_SWITCH = "hlsSubtitleTrackSwitch", n.SUBTITLE_TRACK_LOADING = "hlsSubtitleTrackLoading", n.SUBTITLE_TRACK_LOADED = "hlsSubtitleTrackLoaded", n.SUBTITLE_FRAG_PROCESSED = "hlsSubtitleFragProcessed", n.CUES_PARSED = "hlsCuesParsed", n.NON_NATIVE_TEXT_TRACKS_FOUND = "hlsNonNativeTextTracksFound", n.INIT_PTS_FOUND = "hlsInitPtsFound", n.FRAG_LOADING = "hlsFragLoading", n.FRAG_LOAD_EMERGENCY_ABORTED = "hlsFragLoadEmergencyAborted", n.FRAG_LOADED = "hlsFragLoaded", n.FRAG_DECRYPTED = "hlsFragDecrypted", n.FRAG_PARSING_INIT_SEGMENT = "hlsFragParsingInitSegment", n.FRAG_PARSING_USERDATA = "hlsFragParsingUserdata", n.FRAG_PARSING_METADATA = "hlsFragParsingMetadata", n.FRAG_PARSED = "hlsFragParsed", n.FRAG_BUFFERED = "hlsFragBuffered", n.FRAG_CHANGED = "hlsFragChanged", n.FPS_DROP = "hlsFpsDrop", n.FPS_DROP_LEVEL_CAPPING = "hlsFpsDropLevelCapping", n.MAX_AUTO_LEVEL_UPDATED = "hlsMaxAutoLevelUpdated", n.ERROR = "hlsError", n.DESTROYING = "hlsDestroying", n.KEY_LOADING = "hlsKeyLoading", n.KEY_LOADED = "hlsKeyLoaded", n.LIVE_BACK_BUFFER_REACHED = "hlsLiveBackBufferReached", n.BACK_BUFFER_REACHED = "hlsBackBufferReached", n.STEERING_MANIFEST_LOADED = "hlsSteeringManifestLoaded", n;
}({}), K = /* @__PURE__ */ function(n) {
  return n.NETWORK_ERROR = "networkError", n.MEDIA_ERROR = "mediaError", n.KEY_SYSTEM_ERROR = "keySystemError", n.MUX_ERROR = "muxError", n.OTHER_ERROR = "otherError", n;
}({}), L = /* @__PURE__ */ function(n) {
  return n.KEY_SYSTEM_NO_KEYS = "keySystemNoKeys", n.KEY_SYSTEM_NO_ACCESS = "keySystemNoAccess", n.KEY_SYSTEM_NO_SESSION = "keySystemNoSession", n.KEY_SYSTEM_NO_CONFIGURED_LICENSE = "keySystemNoConfiguredLicense", n.KEY_SYSTEM_LICENSE_REQUEST_FAILED = "keySystemLicenseRequestFailed", n.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED = "keySystemServerCertificateRequestFailed", n.KEY_SYSTEM_SERVER_CERTIFICATE_UPDATE_FAILED = "keySystemServerCertificateUpdateFailed", n.KEY_SYSTEM_SESSION_UPDATE_FAILED = "keySystemSessionUpdateFailed", n.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED = "keySystemStatusOutputRestricted", n.KEY_SYSTEM_STATUS_INTERNAL_ERROR = "keySystemStatusInternalError", n.MANIFEST_LOAD_ERROR = "manifestLoadError", n.MANIFEST_LOAD_TIMEOUT = "manifestLoadTimeOut", n.MANIFEST_PARSING_ERROR = "manifestParsingError", n.MANIFEST_INCOMPATIBLE_CODECS_ERROR = "manifestIncompatibleCodecsError", n.LEVEL_EMPTY_ERROR = "levelEmptyError", n.LEVEL_LOAD_ERROR = "levelLoadError", n.LEVEL_LOAD_TIMEOUT = "levelLoadTimeOut", n.LEVEL_PARSING_ERROR = "levelParsingError", n.LEVEL_SWITCH_ERROR = "levelSwitchError", n.AUDIO_TRACK_LOAD_ERROR = "audioTrackLoadError", n.AUDIO_TRACK_LOAD_TIMEOUT = "audioTrackLoadTimeOut", n.SUBTITLE_LOAD_ERROR = "subtitleTrackLoadError", n.SUBTITLE_TRACK_LOAD_TIMEOUT = "subtitleTrackLoadTimeOut", n.FRAG_LOAD_ERROR = "fragLoadError", n.FRAG_LOAD_TIMEOUT = "fragLoadTimeOut", n.FRAG_DECRYPT_ERROR = "fragDecryptError", n.FRAG_PARSING_ERROR = "fragParsingError", n.FRAG_GAP = "fragGap", n.REMUX_ALLOC_ERROR = "remuxAllocError", n.KEY_LOAD_ERROR = "keyLoadError", n.KEY_LOAD_TIMEOUT = "keyLoadTimeOut", n.BUFFER_ADD_CODEC_ERROR = "bufferAddCodecError", n.BUFFER_INCOMPATIBLE_CODECS_ERROR = "bufferIncompatibleCodecsError", n.BUFFER_APPEND_ERROR = "bufferAppendError", n.BUFFER_APPENDING_ERROR = "bufferAppendingError", n.BUFFER_STALLED_ERROR = "bufferStalledError", n.BUFFER_FULL_ERROR = "bufferFullError", n.BUFFER_SEEK_OVER_HOLE = "bufferSeekOverHole", n.BUFFER_NUDGE_ON_STALL = "bufferNudgeOnStall", n.INTERNAL_EXCEPTION = "internalException", n.INTERNAL_ABORTED = "aborted", n.UNKNOWN = "unknown", n;
}({});
const Ue = function() {
}, Ts = {
  trace: Ue,
  debug: Ue,
  log: Ue,
  warn: Ue,
  info: Ue,
  error: Ue
};
let at = Ts;
function pa(n) {
  const e = self.console[n];
  return e ? e.bind(self.console, `[${n}] >`) : Ue;
}
function Ea(n, ...e) {
  e.forEach(function(t) {
    at[t] = n[t] ? n[t].bind(n) : pa(t);
  });
}
function Ta(n, e) {
  if (typeof console == "object" && n === !0 || typeof n == "object") {
    Ea(
      n,
      // Remove out from list here to hard-disable a log-level
      // 'trace',
      "debug",
      "log",
      "info",
      "warn",
      "error"
    );
    try {
      at.log(`Debug logs enabled for "${e}" in hls.js version 1.5.17`);
    } catch {
      at = Ts;
    }
  } else
    at = Ts;
}
const v = at, ya = /^(\d+)x(\d+)$/, li = /(.+?)=(".*?"|.*?)(?:,|$)/g;
class ee {
  constructor(e) {
    typeof e == "string" && (e = ee.parseAttrList(e)), se(this, e);
  }
  get clientAttrs() {
    return Object.keys(this).filter((e) => e.substring(0, 2) === "X-");
  }
  decimalInteger(e) {
    const t = parseInt(this[e], 10);
    return t > Number.MAX_SAFE_INTEGER ? 1 / 0 : t;
  }
  hexadecimalInteger(e) {
    if (this[e]) {
      let t = (this[e] || "0x").slice(2);
      t = (t.length & 1 ? "0" : "") + t;
      const s = new Uint8Array(t.length / 2);
      for (let i = 0; i < t.length / 2; i++)
        s[i] = parseInt(t.slice(i * 2, i * 2 + 2), 16);
      return s;
    } else
      return null;
  }
  hexadecimalIntegerAsNumber(e) {
    const t = parseInt(this[e], 16);
    return t > Number.MAX_SAFE_INTEGER ? 1 / 0 : t;
  }
  decimalFloatingPoint(e) {
    return parseFloat(this[e]);
  }
  optionalFloat(e, t) {
    const s = this[e];
    return s ? parseFloat(s) : t;
  }
  enumeratedString(e) {
    return this[e];
  }
  bool(e) {
    return this[e] === "YES";
  }
  decimalResolution(e) {
    const t = ya.exec(this[e]);
    if (t !== null)
      return {
        width: parseInt(t[1], 10),
        height: parseInt(t[2], 10)
      };
  }
  static parseAttrList(e) {
    let t;
    const s = {}, i = '"';
    for (li.lastIndex = 0; (t = li.exec(e)) !== null; ) {
      let r = t[2];
      r.indexOf(i) === 0 && r.lastIndexOf(i) === r.length - 1 && (r = r.slice(1, -1));
      const a = t[1].trim();
      s[a] = r;
    }
    return s;
  }
}
function xa(n) {
  return n !== "ID" && n !== "CLASS" && n !== "START-DATE" && n !== "DURATION" && n !== "END-DATE" && n !== "END-ON-NEXT";
}
function Sa(n) {
  return n === "SCTE35-OUT" || n === "SCTE35-IN";
}
class Ar {
  constructor(e, t) {
    if (this.attr = void 0, this._startDate = void 0, this._endDate = void 0, this._badValueForSameId = void 0, t) {
      const s = t.attr;
      for (const i in s)
        if (Object.prototype.hasOwnProperty.call(e, i) && e[i] !== s[i]) {
          v.warn(`DATERANGE tag attribute: "${i}" does not match for tags with ID: "${e.ID}"`), this._badValueForSameId = i;
          break;
        }
      e = se(new ee({}), s, e);
    }
    if (this.attr = e, this._startDate = new Date(e["START-DATE"]), "END-DATE" in this.attr) {
      const s = new Date(this.attr["END-DATE"]);
      M(s.getTime()) && (this._endDate = s);
    }
  }
  get id() {
    return this.attr.ID;
  }
  get class() {
    return this.attr.CLASS;
  }
  get startDate() {
    return this._startDate;
  }
  get endDate() {
    if (this._endDate)
      return this._endDate;
    const e = this.duration;
    return e !== null ? new Date(this._startDate.getTime() + e * 1e3) : null;
  }
  get duration() {
    if ("DURATION" in this.attr) {
      const e = this.attr.decimalFloatingPoint("DURATION");
      if (M(e))
        return e;
    } else if (this._endDate)
      return (this._endDate.getTime() - this._startDate.getTime()) / 1e3;
    return null;
  }
  get plannedDuration() {
    return "PLANNED-DURATION" in this.attr ? this.attr.decimalFloatingPoint("PLANNED-DURATION") : null;
  }
  get endOnNext() {
    return this.attr.bool("END-ON-NEXT");
  }
  get isValid() {
    return !!this.id && !this._badValueForSameId && M(this.startDate.getTime()) && (this.duration === null || this.duration >= 0) && (!this.endOnNext || !!this.class);
  }
}
class Vt {
  constructor() {
    this.aborted = !1, this.loaded = 0, this.retry = 0, this.total = 0, this.chunkCount = 0, this.bwEstimate = 0, this.loading = {
      start: 0,
      first: 0,
      end: 0
    }, this.parsing = {
      start: 0,
      end: 0
    }, this.buffering = {
      start: 0,
      first: 0,
      end: 0
    };
  }
}
var Q = {
  AUDIO: "audio",
  VIDEO: "video",
  AUDIOVIDEO: "audiovideo"
};
class Lr {
  constructor(e) {
    this._byteRange = null, this._url = null, this.baseurl = void 0, this.relurl = void 0, this.elementaryStreams = {
      [Q.AUDIO]: null,
      [Q.VIDEO]: null,
      [Q.AUDIOVIDEO]: null
    }, this.baseurl = e;
  }
  // setByteRange converts a EXT-X-BYTERANGE attribute into a two element array
  setByteRange(e, t) {
    const s = e.split("@", 2);
    let i;
    s.length === 1 ? i = (t == null ? void 0 : t.byteRangeEndOffset) || 0 : i = parseInt(s[1]), this._byteRange = [i, parseInt(s[0]) + i];
  }
  get byteRange() {
    return this._byteRange ? this._byteRange : [];
  }
  get byteRangeStartOffset() {
    return this.byteRange[0];
  }
  get byteRangeEndOffset() {
    return this.byteRange[1];
  }
  get url() {
    return !this._url && this.baseurl && this.relurl && (this._url = Ns.buildAbsoluteURL(this.baseurl, this.relurl, {
      alwaysNormalize: !0
    })), this._url || "";
  }
  set url(e) {
    this._url = e;
  }
}
class qt extends Lr {
  constructor(e, t) {
    super(t), this._decryptdata = null, this.rawProgramDateTime = null, this.programDateTime = null, this.tagList = [], this.duration = 0, this.sn = 0, this.levelkeys = void 0, this.type = void 0, this.loader = null, this.keyLoader = null, this.level = -1, this.cc = 0, this.startPTS = void 0, this.endPTS = void 0, this.startDTS = void 0, this.endDTS = void 0, this.start = 0, this.deltaPTS = void 0, this.maxStartPTS = void 0, this.minEndPTS = void 0, this.stats = new Vt(), this.data = void 0, this.bitrateTest = !1, this.title = null, this.initSegment = null, this.endList = void 0, this.gap = void 0, this.urlId = 0, this.type = e;
  }
  get decryptdata() {
    const {
      levelkeys: e
    } = this;
    if (!e && !this._decryptdata)
      return null;
    if (!this._decryptdata && this.levelkeys && !this.levelkeys.NONE) {
      const t = this.levelkeys.identity;
      if (t)
        this._decryptdata = t.getDecryptData(this.sn);
      else {
        const s = Object.keys(this.levelkeys);
        if (s.length === 1)
          return this._decryptdata = this.levelkeys[s[0]].getDecryptData(this.sn);
      }
    }
    return this._decryptdata;
  }
  get end() {
    return this.start + this.duration;
  }
  get endProgramDateTime() {
    if (this.programDateTime === null || !M(this.programDateTime))
      return null;
    const e = M(this.duration) ? this.duration : 0;
    return this.programDateTime + e * 1e3;
  }
  get encrypted() {
    var e;
    if ((e = this._decryptdata) != null && e.encrypted)
      return !0;
    if (this.levelkeys) {
      const t = Object.keys(this.levelkeys), s = t.length;
      if (s > 1 || s === 1 && this.levelkeys[t[0]].encrypted)
        return !0;
    }
    return !1;
  }
  setKeyFormat(e) {
    if (this.levelkeys) {
      const t = this.levelkeys[e];
      t && !this._decryptdata && (this._decryptdata = t.getDecryptData(this.sn));
    }
  }
  abortRequests() {
    var e, t;
    (e = this.loader) == null || e.abort(), (t = this.keyLoader) == null || t.abort();
  }
  setElementaryStreamInfo(e, t, s, i, r, a = !1) {
    const {
      elementaryStreams: o
    } = this, l = o[e];
    if (!l) {
      o[e] = {
        startPTS: t,
        endPTS: s,
        startDTS: i,
        endDTS: r,
        partial: a
      };
      return;
    }
    l.startPTS = Math.min(l.startPTS, t), l.endPTS = Math.max(l.endPTS, s), l.startDTS = Math.min(l.startDTS, i), l.endDTS = Math.max(l.endDTS, r);
  }
  clearElementaryStreamInfo() {
    const {
      elementaryStreams: e
    } = this;
    e[Q.AUDIO] = null, e[Q.VIDEO] = null, e[Q.AUDIOVIDEO] = null;
  }
}
class va extends Lr {
  constructor(e, t, s, i, r) {
    super(s), this.fragOffset = 0, this.duration = 0, this.gap = !1, this.independent = !1, this.relurl = void 0, this.fragment = void 0, this.index = void 0, this.stats = new Vt(), this.duration = e.decimalFloatingPoint("DURATION"), this.gap = e.bool("GAP"), this.independent = e.bool("INDEPENDENT"), this.relurl = e.enumeratedString("URI"), this.fragment = t, this.index = i;
    const a = e.enumeratedString("BYTERANGE");
    a && this.setByteRange(a, r), r && (this.fragOffset = r.fragOffset + r.duration);
  }
  get start() {
    return this.fragment.start + this.fragOffset;
  }
  get end() {
    return this.start + this.duration;
  }
  get loaded() {
    const {
      elementaryStreams: e
    } = this;
    return !!(e.audio || e.video || e.audiovideo);
  }
}
const Aa = 10;
class La {
  constructor(e) {
    this.PTSKnown = !1, this.alignedSliding = !1, this.averagetargetduration = void 0, this.endCC = 0, this.endSN = 0, this.fragments = void 0, this.fragmentHint = void 0, this.partList = null, this.dateRanges = void 0, this.live = !0, this.ageHeader = 0, this.advancedDateTime = void 0, this.updated = !0, this.advanced = !0, this.availabilityDelay = void 0, this.misses = 0, this.startCC = 0, this.startSN = 0, this.startTimeOffset = null, this.targetduration = 0, this.totalduration = 0, this.type = null, this.url = void 0, this.m3u8 = "", this.version = null, this.canBlockReload = !1, this.canSkipUntil = 0, this.canSkipDateRanges = !1, this.skippedSegments = 0, this.recentlyRemovedDateranges = void 0, this.partHoldBack = 0, this.holdBack = 0, this.partTarget = 0, this.preloadHint = void 0, this.renditionReports = void 0, this.tuneInGoal = 0, this.deltaUpdateFailed = void 0, this.driftStartTime = 0, this.driftEndTime = 0, this.driftStart = 0, this.driftEnd = 0, this.encryptedFragments = void 0, this.playlistParsingError = null, this.variableList = null, this.hasVariableRefs = !1, this.fragments = [], this.encryptedFragments = [], this.dateRanges = {}, this.url = e;
  }
  reloaded(e) {
    if (!e) {
      this.advanced = !0, this.updated = !0;
      return;
    }
    const t = this.lastPartSn - e.lastPartSn, s = this.lastPartIndex - e.lastPartIndex;
    this.updated = this.endSN !== e.endSN || !!s || !!t || !this.live, this.advanced = this.endSN > e.endSN || t > 0 || t === 0 && s > 0, this.updated || this.advanced ? this.misses = Math.floor(e.misses * 0.6) : this.misses = e.misses + 1, this.availabilityDelay = e.availabilityDelay;
  }
  get hasProgramDateTime() {
    return this.fragments.length ? M(this.fragments[this.fragments.length - 1].programDateTime) : !1;
  }
  get levelTargetDuration() {
    return this.averagetargetduration || this.targetduration || Aa;
  }
  get drift() {
    const e = this.driftEndTime - this.driftStartTime;
    return e > 0 ? (this.driftEnd - this.driftStart) * 1e3 / e : 1;
  }
  get edge() {
    return this.partEnd || this.fragmentEnd;
  }
  get partEnd() {
    var e;
    return (e = this.partList) != null && e.length ? this.partList[this.partList.length - 1].end : this.fragmentEnd;
  }
  get fragmentEnd() {
    var e;
    return (e = this.fragments) != null && e.length ? this.fragments[this.fragments.length - 1].end : 0;
  }
  get age() {
    return this.advancedDateTime ? Math.max(Date.now() - this.advancedDateTime, 0) / 1e3 : 0;
  }
  get lastPartIndex() {
    var e;
    return (e = this.partList) != null && e.length ? this.partList[this.partList.length - 1].index : -1;
  }
  get lastPartSn() {
    var e;
    return (e = this.partList) != null && e.length ? this.partList[this.partList.length - 1].fragment.sn : this.endSN;
  }
}
function Us(n) {
  return Uint8Array.from(atob(n), (e) => e.charCodeAt(0));
}
function Ra(n) {
  const e = ys(n).subarray(0, 16), t = new Uint8Array(16);
  return t.set(e, 16 - e.length), t;
}
function ba(n) {
  const e = function(s, i, r) {
    const a = s[i];
    s[i] = s[r], s[r] = a;
  };
  e(n, 0, 3), e(n, 1, 2), e(n, 4, 5), e(n, 6, 7);
}
function Ia(n) {
  const e = n.split(":");
  let t = null;
  if (e[0] === "data" && e.length === 2) {
    const s = e[1].split(";"), i = s[s.length - 1].split(",");
    if (i.length === 2) {
      const r = i[0] === "base64", a = i[1];
      r ? (s.splice(-1, 1), t = Us(a)) : t = Ra(a);
    }
  }
  return t;
}
function ys(n) {
  return Uint8Array.from(unescape(encodeURIComponent(n)), (e) => e.charCodeAt(0));
}
const Je = typeof self < "u" ? self : void 0;
var Z = {
  CLEARKEY: "org.w3.clearkey",
  FAIRPLAY: "com.apple.fps",
  PLAYREADY: "com.microsoft.playready",
  WIDEVINE: "com.widevine.alpha"
}, fe = {
  CLEARKEY: "org.w3.clearkey",
  FAIRPLAY: "com.apple.streamingkeydelivery",
  PLAYREADY: "com.microsoft.playready",
  WIDEVINE: "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"
};
function ci(n) {
  switch (n) {
    case fe.FAIRPLAY:
      return Z.FAIRPLAY;
    case fe.PLAYREADY:
      return Z.PLAYREADY;
    case fe.WIDEVINE:
      return Z.WIDEVINE;
    case fe.CLEARKEY:
      return Z.CLEARKEY;
  }
}
var nt = {
  CENC: "1077efecc0b24d02ace33c1e52e2fb4b",
  CLEARKEY: "e2719d58a985b3c9781ab030af78d30e",
  FAIRPLAY: "94ce86fb07ff4f43adb893d2fa968ca2",
  PLAYREADY: "9a04f07998404286ab92e65be0885f95",
  WIDEVINE: "edef8ba979d64acea3c827dcd51d21ed"
};
function hi(n) {
  if (n === nt.WIDEVINE)
    return Z.WIDEVINE;
  if (n === nt.PLAYREADY)
    return Z.PLAYREADY;
  if (n === nt.CENC || n === nt.CLEARKEY)
    return Z.CLEARKEY;
}
function ui(n) {
  switch (n) {
    case Z.FAIRPLAY:
      return fe.FAIRPLAY;
    case Z.PLAYREADY:
      return fe.PLAYREADY;
    case Z.WIDEVINE:
      return fe.WIDEVINE;
    case Z.CLEARKEY:
      return fe.CLEARKEY;
  }
}
function jt(n) {
  const {
    drmSystems: e,
    widevineLicenseUrl: t
  } = n, s = e ? [Z.FAIRPLAY, Z.WIDEVINE, Z.PLAYREADY, Z.CLEARKEY].filter((i) => !!e[i]) : [];
  return !s[Z.WIDEVINE] && t && s.push(Z.WIDEVINE), s;
}
const Rr = function(n) {
  return Je != null && (n = Je.navigator) != null && n.requestMediaKeySystemAccess ? self.navigator.requestMediaKeySystemAccess.bind(self.navigator) : null;
}();
function Da(n, e, t, s) {
  let i;
  switch (n) {
    case Z.FAIRPLAY:
      i = ["cenc", "sinf"];
      break;
    case Z.WIDEVINE:
    case Z.PLAYREADY:
      i = ["cenc"];
      break;
    case Z.CLEARKEY:
      i = ["cenc", "keyids"];
      break;
    default:
      throw new Error(`Unknown key-system: ${n}`);
  }
  return Ca(i, e, t, s);
}
function Ca(n, e, t, s) {
  return [{
    initDataTypes: n,
    persistentState: s.persistentState || "optional",
    distinctiveIdentifier: s.distinctiveIdentifier || "optional",
    sessionTypes: s.sessionTypes || [s.sessionType || "temporary"],
    audioCapabilities: e.map((r) => ({
      contentType: `audio/mp4; codecs="${r}"`,
      robustness: s.audioRobustness || "",
      encryptionScheme: s.audioEncryptionScheme || null
    })),
    videoCapabilities: t.map((r) => ({
      contentType: `video/mp4; codecs="${r}"`,
      robustness: s.videoRobustness || "",
      encryptionScheme: s.videoEncryptionScheme || null
    }))
  }];
}
function Ge(n, e, t) {
  return Uint8Array.prototype.slice ? n.slice(e, t) : new Uint8Array(Array.prototype.slice.call(n, e, t));
}
const Bs = (n, e) => e + 10 <= n.length && n[e] === 73 && n[e + 1] === 68 && n[e + 2] === 51 && n[e + 3] < 255 && n[e + 4] < 255 && n[e + 6] < 128 && n[e + 7] < 128 && n[e + 8] < 128 && n[e + 9] < 128, br = (n, e) => e + 10 <= n.length && n[e] === 51 && n[e + 1] === 68 && n[e + 2] === 73 && n[e + 3] < 255 && n[e + 4] < 255 && n[e + 6] < 128 && n[e + 7] < 128 && n[e + 8] < 128 && n[e + 9] < 128, ot = (n, e) => {
  const t = e;
  let s = 0;
  for (; Bs(n, e); ) {
    s += 10;
    const i = Ht(n, e + 6);
    s += i, br(n, e + 10) && (s += 10), e += s;
  }
  if (s > 0)
    return n.subarray(t, t + s);
}, Ht = (n, e) => {
  let t = 0;
  return t = (n[e] & 127) << 21, t |= (n[e + 1] & 127) << 14, t |= (n[e + 2] & 127) << 7, t |= n[e + 3] & 127, t;
}, _a = (n, e) => Bs(n, e) && Ht(n, e + 6) + 10 <= n.length - e, Gs = (n) => {
  const e = Dr(n);
  for (let t = 0; t < e.length; t++) {
    const s = e[t];
    if (Ir(s))
      return Ma(s);
  }
}, Ir = (n) => n && n.key === "PRIV" && n.info === "com.apple.streaming.transportStreamTimestamp", ka = (n) => {
  const e = String.fromCharCode(n[0], n[1], n[2], n[3]), t = Ht(n, 4), s = 10;
  return {
    type: e,
    size: t,
    data: n.subarray(s, s + t)
  };
}, Dr = (n) => {
  let e = 0;
  const t = [];
  for (; Bs(n, e); ) {
    const s = Ht(n, e + 6);
    e += 10;
    const i = e + s;
    for (; e + 8 < i; ) {
      const r = ka(n.subarray(e)), a = wa(r);
      a && t.push(a), e += r.size + 10;
    }
    br(n, e) && (e += 10);
  }
  return t;
}, wa = (n) => n.type === "PRIV" ? Pa(n) : n.type[0] === "W" ? Oa(n) : Fa(n), Pa = (n) => {
  if (n.size < 2)
    return;
  const e = Ie(n.data, !0), t = new Uint8Array(n.data.subarray(e.length + 1));
  return {
    key: n.type,
    info: e,
    data: t.buffer
  };
}, Fa = (n) => {
  if (n.size < 2)
    return;
  if (n.type === "TXXX") {
    let t = 1;
    const s = Ie(n.data.subarray(t), !0);
    t += s.length + 1;
    const i = Ie(n.data.subarray(t));
    return {
      key: n.type,
      info: s,
      data: i
    };
  }
  const e = Ie(n.data.subarray(1));
  return {
    key: n.type,
    data: e
  };
}, Oa = (n) => {
  if (n.type === "WXXX") {
    if (n.size < 2)
      return;
    let t = 1;
    const s = Ie(n.data.subarray(t), !0);
    t += s.length + 1;
    const i = Ie(n.data.subarray(t));
    return {
      key: n.type,
      info: s,
      data: i
    };
  }
  const e = Ie(n.data);
  return {
    key: n.type,
    data: e
  };
}, Ma = (n) => {
  if (n.data.byteLength === 8) {
    const e = new Uint8Array(n.data), t = e[3] & 1;
    let s = (e[4] << 23) + (e[5] << 15) + (e[6] << 7) + e[7];
    return s /= 45, t && (s += 4772185884e-2), Math.round(s);
  }
}, Ie = (n, e = !1) => {
  const t = Na();
  if (t) {
    const c = t.decode(n);
    if (e) {
      const h = c.indexOf("\0");
      return h !== -1 ? c.substring(0, h) : c;
    }
    return c.replace(/\0/g, "");
  }
  const s = n.length;
  let i, r, a, o = "", l = 0;
  for (; l < s; ) {
    if (i = n[l++], i === 0 && e)
      return o;
    if (i === 0 || i === 3)
      continue;
    switch (i >> 4) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
        o += String.fromCharCode(i);
        break;
      case 12:
      case 13:
        r = n[l++], o += String.fromCharCode((i & 31) << 6 | r & 63);
        break;
      case 14:
        r = n[l++], a = n[l++], o += String.fromCharCode((i & 15) << 12 | (r & 63) << 6 | (a & 63) << 0);
        break;
    }
  }
  return o;
};
let zt;
function Na() {
  if (!navigator.userAgent.includes("PlayStation 4"))
    return !zt && typeof self.TextDecoder < "u" && (zt = new self.TextDecoder("utf-8")), zt;
}
const Ae = {
  hexDump: function(n) {
    let e = "";
    for (let t = 0; t < n.length; t++) {
      let s = n[t].toString(16);
      s.length < 2 && (s = "0" + s), e += s;
    }
    return e;
  }
}, kt = Math.pow(2, 32) - 1, Ua = [].push, Cr = {
  video: 1,
  audio: 2,
  id3: 3,
  text: 4
};
function ie(n) {
  return String.fromCharCode.apply(null, n);
}
function _r(n, e) {
  const t = n[e] << 8 | n[e + 1];
  return t < 0 ? 65536 + t : t;
}
function B(n, e) {
  const t = kr(n, e);
  return t < 0 ? 4294967296 + t : t;
}
function di(n, e) {
  let t = B(n, e);
  return t *= Math.pow(2, 32), t += B(n, e + 4), t;
}
function kr(n, e) {
  return n[e] << 24 | n[e + 1] << 16 | n[e + 2] << 8 | n[e + 3];
}
function Xt(n, e, t) {
  n[e] = t >> 24, n[e + 1] = t >> 16 & 255, n[e + 2] = t >> 8 & 255, n[e + 3] = t & 255;
}
function Ba(n) {
  const e = n.byteLength;
  for (let t = 0; t < e; ) {
    const s = B(n, t);
    if (s > 8 && n[t + 4] === 109 && n[t + 5] === 111 && n[t + 6] === 111 && n[t + 7] === 102)
      return !0;
    t = s > 1 ? t + s : e;
  }
  return !1;
}
function H(n, e) {
  const t = [];
  if (!e.length)
    return t;
  const s = n.byteLength;
  for (let i = 0; i < s; ) {
    const r = B(n, i), a = ie(n.subarray(i + 4, i + 8)), o = r > 1 ? i + r : s;
    if (a === e[0])
      if (e.length === 1)
        t.push(n.subarray(i + 8, o));
      else {
        const l = H(n.subarray(i + 8, o), e.slice(1));
        l.length && Ua.apply(t, l);
      }
    i = o;
  }
  return t;
}
function Ga(n) {
  const e = [], t = n[0];
  let s = 8;
  const i = B(n, s);
  s += 4;
  let r = 0, a = 0;
  t === 0 ? (r = B(n, s), a = B(n, s + 4), s += 8) : (r = di(n, s), a = di(n, s + 8), s += 16), s += 2;
  let o = n.length + a;
  const l = _r(n, s);
  s += 2;
  for (let c = 0; c < l; c++) {
    let h = s;
    const u = B(n, h);
    h += 4;
    const d = u & 2147483647;
    if ((u & 2147483648) >>> 31 === 1)
      return v.warn("SIDX has hierarchical references (not supported)"), null;
    const g = B(n, h);
    h += 4, e.push({
      referenceSize: d,
      subsegmentDuration: g,
      // unscaled
      info: {
        duration: g / i,
        start: o,
        end: o + d - 1
      }
    }), o += d, h += 4, s = h;
  }
  return {
    earliestPresentationTime: r,
    timescale: i,
    version: t,
    referencesCount: l,
    references: e
  };
}
function wr(n) {
  const e = [], t = H(n, ["moov", "trak"]);
  for (let i = 0; i < t.length; i++) {
    const r = t[i], a = H(r, ["tkhd"])[0];
    if (a) {
      let o = a[0];
      const l = B(a, o === 0 ? 12 : 20), c = H(r, ["mdia", "mdhd"])[0];
      if (c) {
        o = c[0];
        const h = B(c, o === 0 ? 12 : 20), u = H(r, ["mdia", "hdlr"])[0];
        if (u) {
          const d = ie(u.subarray(8, 12)), f = {
            soun: Q.AUDIO,
            vide: Q.VIDEO
          }[d];
          if (f) {
            const g = H(r, ["mdia", "minf", "stbl", "stsd"])[0], m = $a(g);
            e[l] = {
              timescale: h,
              type: f
            }, e[f] = oe({
              timescale: h,
              id: l
            }, m);
          }
        }
      }
    }
  }
  return H(n, ["moov", "mvex", "trex"]).forEach((i) => {
    const r = B(i, 4), a = e[r];
    a && (a.default = {
      duration: B(i, 12),
      flags: B(i, 20)
    });
  }), e;
}
function $a(n) {
  const e = n.subarray(8), t = e.subarray(86), s = ie(e.subarray(4, 8));
  let i = s;
  const r = s === "enca" || s === "encv";
  if (r) {
    const o = H(e, [s])[0].subarray(s === "enca" ? 28 : 78);
    H(o, ["sinf"]).forEach((c) => {
      const h = H(c, ["schm"])[0];
      if (h) {
        const u = ie(h.subarray(4, 8));
        if (u === "cbcs" || u === "cenc") {
          const d = H(c, ["frma"])[0];
          d && (i = ie(d));
        }
      }
    });
  }
  switch (i) {
    case "avc1":
    case "avc2":
    case "avc3":
    case "avc4": {
      const a = H(t, ["avcC"])[0];
      i += "." + ut(a[1]) + ut(a[2]) + ut(a[3]);
      break;
    }
    case "mp4a": {
      const a = H(e, [s])[0], o = H(a.subarray(28), ["esds"])[0];
      if (o && o.length > 12) {
        let l = 4;
        if (o[l++] !== 3)
          break;
        l = Qt(o, l), l += 2;
        const c = o[l++];
        if (c & 128 && (l += 2), c & 64 && (l += o[l++]), o[l++] !== 4)
          break;
        l = Qt(o, l);
        const h = o[l++];
        if (h === 64)
          i += "." + ut(h);
        else
          break;
        if (l += 12, o[l++] !== 5)
          break;
        l = Qt(o, l);
        const u = o[l++];
        let d = (u & 248) >> 3;
        d === 31 && (d += 1 + ((u & 7) << 3) + ((o[l] & 224) >> 5)), i += "." + d;
      }
      break;
    }
    case "hvc1":
    case "hev1": {
      const a = H(t, ["hvcC"])[0], o = a[1], l = ["", "A", "B", "C"][o >> 6], c = o & 31, h = B(a, 2), u = (o & 32) >> 5 ? "H" : "L", d = a[12], f = a.subarray(6, 12);
      i += "." + l + c, i += "." + h.toString(16).toUpperCase(), i += "." + u + d;
      let g = "";
      for (let m = f.length; m--; ) {
        const E = f[m];
        (E || g) && (g = "." + E.toString(16).toUpperCase() + g);
      }
      i += g;
      break;
    }
    case "dvh1":
    case "dvhe": {
      const a = H(t, ["dvcC"])[0], o = a[2] >> 1 & 127, l = a[2] << 5 & 32 | a[3] >> 3 & 31;
      i += "." + ve(o) + "." + ve(l);
      break;
    }
    case "vp09": {
      const a = H(t, ["vpcC"])[0], o = a[4], l = a[5], c = a[6] >> 4 & 15;
      i += "." + ve(o) + "." + ve(l) + "." + ve(c);
      break;
    }
    case "av01": {
      const a = H(t, ["av1C"])[0], o = a[1] >>> 5, l = a[1] & 31, c = a[2] >>> 7 ? "H" : "M", h = (a[2] & 64) >> 6, u = (a[2] & 32) >> 5, d = o === 2 && h ? u ? 12 : 10 : h ? 10 : 8, f = (a[2] & 16) >> 4, g = (a[2] & 8) >> 3, m = (a[2] & 4) >> 2, E = a[2] & 3;
      i += "." + o + "." + ve(l) + c + "." + ve(d) + "." + f + "." + g + m + E + "." + ve(1) + "." + ve(1) + "." + ve(1) + "." + 0;
      break;
    }
  }
  return {
    codec: i,
    encrypted: r
  };
}
function Qt(n, e) {
  const t = e + 5;
  for (; n[e++] & 128 && e < t; )
    ;
  return e;
}
function ut(n) {
  return ("0" + n.toString(16).toUpperCase()).slice(-2);
}
function ve(n) {
  return (n < 10 ? "0" : "") + n;
}
function Ka(n, e) {
  if (!n || !e)
    return n;
  const t = e.keyId;
  return t && e.isCommonEncryption && H(n, ["moov", "trak"]).forEach((i) => {
    const a = H(i, ["mdia", "minf", "stbl", "stsd"])[0].subarray(8);
    let o = H(a, ["enca"]);
    const l = o.length > 0;
    l || (o = H(a, ["encv"])), o.forEach((c) => {
      const h = l ? c.subarray(28) : c.subarray(78);
      H(h, ["sinf"]).forEach((d) => {
        const f = Pr(d);
        if (f) {
          const g = f.subarray(8, 24);
          g.some((m) => m !== 0) || (v.log(`[eme] Patching keyId in 'enc${l ? "a" : "v"}>sinf>>tenc' box: ${Ae.hexDump(g)} -> ${Ae.hexDump(t)}`), f.set(t, 8));
        }
      });
    });
  }), n;
}
function Pr(n) {
  const e = H(n, ["schm"])[0];
  if (e) {
    const t = ie(e.subarray(4, 8));
    if (t === "cbcs" || t === "cenc")
      return H(n, ["schi", "tenc"])[0];
  }
  return null;
}
function Va(n, e) {
  return H(e, ["moof", "traf"]).reduce((t, s) => {
    const i = H(s, ["tfdt"])[0], r = i[0], a = H(s, ["tfhd"]).reduce((o, l) => {
      const c = B(l, 4), h = n[c];
      if (h) {
        let u = B(i, 4);
        if (r === 1) {
          if (u === kt)
            return v.warn("[mp4-demuxer]: Ignoring assumed invalid signed 64-bit track fragment decode time"), o;
          u *= kt + 1, u += B(i, 8);
        }
        const d = h.timescale || 9e4, f = u / d;
        if (M(f) && (o === null || f < o))
          return f;
      }
      return o;
    }, null);
    return a !== null && M(a) && (t === null || a < t) ? a : t;
  }, null);
}
function Ha(n, e) {
  let t = 0, s = 0, i = 0;
  const r = H(n, ["moof", "traf"]);
  for (let a = 0; a < r.length; a++) {
    const o = r[a], l = H(o, ["tfhd"])[0], c = B(l, 4), h = e[c];
    if (!h)
      continue;
    const u = h.default, d = B(l, 0) | (u == null ? void 0 : u.flags);
    let f = u == null ? void 0 : u.duration;
    d & 8 && (d & 2 ? f = B(l, 12) : f = B(l, 8));
    const g = h.timescale || 9e4, m = H(o, ["trun"]);
    for (let E = 0; E < m.length; E++) {
      if (t = Wa(m[E]), !t && f) {
        const T = B(m[E], 4);
        t = f * T;
      }
      h.type === Q.VIDEO ? s += t / g : h.type === Q.AUDIO && (i += t / g);
    }
  }
  if (s === 0 && i === 0) {
    let a = 1 / 0, o = 0, l = 0;
    const c = H(n, ["sidx"]);
    for (let h = 0; h < c.length; h++) {
      const u = Ga(c[h]);
      if (u != null && u.references) {
        a = Math.min(a, u.earliestPresentationTime / u.timescale);
        const d = u.references.reduce((f, g) => f + g.info.duration || 0, 0);
        o = Math.max(o, d + u.earliestPresentationTime / u.timescale), l = o - a;
      }
    }
    if (l && M(l))
      return l;
  }
  return s || i;
}
function Wa(n) {
  const e = B(n, 0);
  let t = 8;
  e & 1 && (t += 4), e & 4 && (t += 4);
  let s = 0;
  const i = B(n, 4);
  for (let r = 0; r < i; r++) {
    if (e & 256) {
      const a = B(n, t);
      s += a, t += 4;
    }
    e & 512 && (t += 4), e & 1024 && (t += 4), e & 2048 && (t += 4);
  }
  return s;
}
function Ya(n, e, t) {
  H(e, ["moof", "traf"]).forEach((s) => {
    H(s, ["tfhd"]).forEach((i) => {
      const r = B(i, 4), a = n[r];
      if (!a)
        return;
      const o = a.timescale || 9e4;
      H(s, ["tfdt"]).forEach((l) => {
        const c = l[0], h = t * o;
        if (h) {
          let u = B(l, 4);
          if (c === 0)
            u -= h, u = Math.max(u, 0), Xt(l, 4, u);
          else {
            u *= Math.pow(2, 32), u += B(l, 8), u -= h, u = Math.max(u, 0);
            const d = Math.floor(u / (kt + 1)), f = Math.floor(u % (kt + 1));
            Xt(l, 4, d), Xt(l, 8, f);
          }
        }
      });
    });
  });
}
function qa(n) {
  const e = {
    valid: null,
    remainder: null
  }, t = H(n, ["moof"]);
  if (t.length < 2)
    return e.remainder = n, e;
  const s = t[t.length - 1];
  return e.valid = Ge(n, 0, s.byteOffset - 8), e.remainder = Ge(n, s.byteOffset - 8), e;
}
function Te(n, e) {
  const t = new Uint8Array(n.length + e.length);
  return t.set(n), t.set(e, n.length), t;
}
function fi(n, e) {
  const t = [], s = e.samples, i = e.timescale, r = e.id;
  let a = !1;
  return H(s, ["moof"]).map((l) => {
    const c = l.byteOffset - 8;
    H(l, ["traf"]).map((u) => {
      const d = H(u, ["tfdt"]).map((f) => {
        const g = f[0];
        let m = B(f, 4);
        return g === 1 && (m *= Math.pow(2, 32), m += B(f, 8)), m / i;
      })[0];
      return d !== void 0 && (n = d), H(u, ["tfhd"]).map((f) => {
        const g = B(f, 4), m = B(f, 0) & 16777215, E = (m & 1) !== 0, T = (m & 2) !== 0, y = (m & 8) !== 0;
        let x = 0;
        const b = (m & 16) !== 0;
        let S = 0;
        const D = (m & 32) !== 0;
        let R = 8;
        g === r && (E && (R += 8), T && (R += 4), y && (x = B(f, R), R += 4), b && (S = B(f, R), R += 4), D && (R += 4), e.type === "video" && (a = ja(e.codec)), H(u, ["trun"]).map((_) => {
          const P = _[0], I = B(_, 0) & 16777215, k = (I & 1) !== 0;
          let V = 0;
          const F = (I & 4) !== 0, w = (I & 256) !== 0;
          let $ = 0;
          const U = (I & 512) !== 0;
          let W = 0;
          const z = (I & 1024) !== 0, N = (I & 2048) !== 0;
          let O = 0;
          const j = B(_, 4);
          let Y = 8;
          k && (V = B(_, Y), Y += 4), F && (Y += 4);
          let X = V + c;
          for (let te = 0; te < j; te++) {
            if (w ? ($ = B(_, Y), Y += 4) : $ = x, U ? (W = B(_, Y), Y += 4) : W = S, z && (Y += 4), N && (P === 0 ? O = B(_, Y) : O = kr(_, Y), Y += 4), e.type === Q.VIDEO) {
              let re = 0;
              for (; re < W; ) {
                const le = B(s, X);
                if (X += 4, za(a, s[X])) {
                  const ge = s.subarray(X, X + le);
                  Fr(ge, a ? 2 : 1, n + O / i, t);
                }
                X += le, re += le + 4;
              }
            }
            n += $ / i;
          }
        }));
      });
    });
  }), t;
}
function ja(n) {
  if (!n)
    return !1;
  const e = n.indexOf("."), t = e < 0 ? n : n.substring(0, e);
  return t === "hvc1" || t === "hev1" || // Dolby Vision
  t === "dvh1" || t === "dvhe";
}
function za(n, e) {
  if (n) {
    const t = e >> 1 & 63;
    return t === 39 || t === 40;
  } else
    return (e & 31) === 6;
}
function Fr(n, e, t, s) {
  const i = Or(n);
  let r = 0;
  r += e;
  let a = 0, o = 0, l = 0;
  for (; r < i.length; ) {
    a = 0;
    do {
      if (r >= i.length)
        break;
      l = i[r++], a += l;
    } while (l === 255);
    o = 0;
    do {
      if (r >= i.length)
        break;
      l = i[r++], o += l;
    } while (l === 255);
    const c = i.length - r;
    let h = r;
    if (o < c)
      r += o;
    else if (o > c) {
      v.error(`Malformed SEI payload. ${o} is too small, only ${c} bytes left to parse.`);
      break;
    }
    if (a === 4) {
      if (i[h++] === 181) {
        const d = _r(i, h);
        if (h += 2, d === 49) {
          const f = B(i, h);
          if (h += 4, f === 1195456820) {
            const g = i[h++];
            if (g === 3) {
              const m = i[h++], E = 31 & m, T = 64 & m, y = T ? 2 + E * 3 : 0, x = new Uint8Array(y);
              if (T) {
                x[0] = m;
                for (let b = 1; b < y; b++)
                  x[b] = i[h++];
              }
              s.push({
                type: g,
                payloadType: a,
                pts: t,
                bytes: x
              });
            }
          }
        }
      }
    } else if (a === 5 && o > 16) {
      const u = [];
      for (let g = 0; g < 16; g++) {
        const m = i[h++].toString(16);
        u.push(m.length == 1 ? "0" + m : m), (g === 3 || g === 5 || g === 7 || g === 9) && u.push("-");
      }
      const d = o - 16, f = new Uint8Array(d);
      for (let g = 0; g < d; g++)
        f[g] = i[h++];
      s.push({
        payloadType: a,
        pts: t,
        uuid: u.join(""),
        userData: Ie(f),
        userDataBytes: f
      });
    }
  }
}
function Or(n) {
  const e = n.byteLength, t = [];
  let s = 1;
  for (; s < e - 2; )
    n[s] === 0 && n[s + 1] === 0 && n[s + 2] === 3 ? (t.push(s + 2), s += 2) : s++;
  if (t.length === 0)
    return n;
  const i = e - t.length, r = new Uint8Array(i);
  let a = 0;
  for (s = 0; s < i; a++, s++)
    a === t[0] && (a++, t.shift()), r[s] = n[a];
  return r;
}
function Xa(n) {
  const e = n[0];
  let t = "", s = "", i = 0, r = 0, a = 0, o = 0, l = 0, c = 0;
  if (e === 0) {
    for (; ie(n.subarray(c, c + 1)) !== "\0"; )
      t += ie(n.subarray(c, c + 1)), c += 1;
    for (t += ie(n.subarray(c, c + 1)), c += 1; ie(n.subarray(c, c + 1)) !== "\0"; )
      s += ie(n.subarray(c, c + 1)), c += 1;
    s += ie(n.subarray(c, c + 1)), c += 1, i = B(n, 12), r = B(n, 16), o = B(n, 20), l = B(n, 24), c = 28;
  } else if (e === 1) {
    c += 4, i = B(n, c), c += 4;
    const u = B(n, c);
    c += 4;
    const d = B(n, c);
    for (c += 4, a = 2 ** 32 * u + d, ga(a) || (a = Number.MAX_SAFE_INTEGER, v.warn("Presentation time exceeds safe integer limit and wrapped to max safe integer in parsing emsg box")), o = B(n, c), c += 4, l = B(n, c), c += 4; ie(n.subarray(c, c + 1)) !== "\0"; )
      t += ie(n.subarray(c, c + 1)), c += 1;
    for (t += ie(n.subarray(c, c + 1)), c += 1; ie(n.subarray(c, c + 1)) !== "\0"; )
      s += ie(n.subarray(c, c + 1)), c += 1;
    s += ie(n.subarray(c, c + 1)), c += 1;
  }
  const h = n.subarray(c, n.byteLength);
  return {
    schemeIdUri: t,
    value: s,
    timeScale: i,
    presentationTime: a,
    presentationTimeDelta: r,
    eventDuration: o,
    id: l,
    payload: h
  };
}
function Qa(n, ...e) {
  const t = e.length;
  let s = 8, i = t;
  for (; i--; )
    s += e[i].byteLength;
  const r = new Uint8Array(s);
  for (r[0] = s >> 24 & 255, r[1] = s >> 16 & 255, r[2] = s >> 8 & 255, r[3] = s & 255, r.set(n, 4), i = 0, s = 8; i < t; i++)
    r.set(e[i], s), s += e[i].byteLength;
  return r;
}
function Ja(n, e, t) {
  if (n.byteLength !== 16)
    throw new RangeError("Invalid system id");
  let s, i;
  s = 0, i = new Uint8Array();
  let r;
  s > 0 ? (r = new Uint8Array(4), e.length > 0 && new DataView(r.buffer).setUint32(0, e.length, !1)) : r = new Uint8Array();
  const a = new Uint8Array(4);
  return t && t.byteLength > 0 && new DataView(a.buffer).setUint32(0, t.byteLength, !1), Qa(
    [112, 115, 115, 104],
    new Uint8Array([
      s,
      0,
      0,
      0
      // Flags
    ]),
    n,
    // 16 bytes
    r,
    i,
    a,
    t || new Uint8Array()
  );
}
function Za(n) {
  const e = [];
  if (n instanceof ArrayBuffer) {
    const t = n.byteLength;
    let s = 0;
    for (; s + 32 < t; ) {
      const i = new DataView(n, s), r = eo(i);
      e.push(r), s += r.size;
    }
  }
  return e;
}
function eo(n) {
  const e = n.getUint32(0), t = n.byteOffset, s = n.byteLength;
  if (s < e)
    return {
      offset: t,
      size: s
    };
  if (n.getUint32(4) !== 1886614376)
    return {
      offset: t,
      size: e
    };
  const r = n.getUint32(8) >>> 24;
  if (r !== 0 && r !== 1)
    return {
      offset: t,
      size: e
    };
  const a = n.buffer, o = Ae.hexDump(new Uint8Array(a, t + 12, 16)), l = n.getUint32(28);
  let c = null, h = null;
  if (r === 0) {
    if (e - 32 < l || l < 22)
      return {
        offset: t,
        size: e
      };
    h = new Uint8Array(a, t + 32, l);
  } else if (r === 1) {
    if (!l || s < t + 32 + l * 16 + 16)
      return {
        offset: t,
        size: e
      };
    c = [];
    for (let u = 0; u < l; u++)
      c.push(new Uint8Array(a, t + 32 + u * 16, 16));
  }
  return {
    version: r,
    systemId: o,
    kids: c,
    data: h,
    offset: t,
    size: e
  };
}
let dt = {};
class lt {
  static clearKeyUriToKeyIdMap() {
    dt = {};
  }
  constructor(e, t, s, i = [1], r = null) {
    this.uri = void 0, this.method = void 0, this.keyFormat = void 0, this.keyFormatVersions = void 0, this.encrypted = void 0, this.isCommonEncryption = void 0, this.iv = null, this.key = null, this.keyId = null, this.pssh = null, this.method = e, this.uri = t, this.keyFormat = s, this.keyFormatVersions = i, this.iv = r, this.encrypted = e ? e !== "NONE" : !1, this.isCommonEncryption = this.encrypted && e !== "AES-128";
  }
  isSupported() {
    if (this.method) {
      if (this.method === "AES-128" || this.method === "NONE")
        return !0;
      if (this.keyFormat === "identity")
        return this.method === "SAMPLE-AES";
      switch (this.keyFormat) {
        case fe.FAIRPLAY:
        case fe.WIDEVINE:
        case fe.PLAYREADY:
        case fe.CLEARKEY:
          return ["ISO-23001-7", "SAMPLE-AES", "SAMPLE-AES-CENC", "SAMPLE-AES-CTR"].indexOf(this.method) !== -1;
      }
    }
    return !1;
  }
  getDecryptData(e) {
    if (!this.encrypted || !this.uri)
      return null;
    if (this.method === "AES-128" && this.uri && !this.iv) {
      typeof e != "number" && (this.method === "AES-128" && !this.iv && v.warn(`missing IV for initialization segment with method="${this.method}" - compliance issue`), e = 0);
      const s = to(e);
      return new lt(this.method, this.uri, "identity", this.keyFormatVersions, s);
    }
    const t = Ia(this.uri);
    if (t)
      switch (this.keyFormat) {
        case fe.WIDEVINE:
          this.pssh = t, t.length >= 22 && (this.keyId = t.subarray(t.length - 22, t.length - 6));
          break;
        case fe.PLAYREADY: {
          const s = new Uint8Array([154, 4, 240, 121, 152, 64, 66, 134, 171, 146, 230, 91, 224, 136, 95, 149]);
          this.pssh = Ja(s, null, t);
          const i = new Uint16Array(t.buffer, t.byteOffset, t.byteLength / 2), r = String.fromCharCode.apply(null, Array.from(i)), a = r.substring(r.indexOf("<"), r.length), c = new DOMParser().parseFromString(a, "text/xml").getElementsByTagName("KID")[0];
          if (c) {
            const h = c.childNodes[0] ? c.childNodes[0].nodeValue : c.getAttribute("VALUE");
            if (h) {
              const u = Us(h).subarray(0, 16);
              ba(u), this.keyId = u;
            }
          }
          break;
        }
        default: {
          let s = t.subarray(0, 16);
          if (s.length !== 16) {
            const i = new Uint8Array(16);
            i.set(s, 16 - s.length), s = i;
          }
          this.keyId = s;
          break;
        }
      }
    if (!this.keyId || this.keyId.byteLength !== 16) {
      let s = dt[this.uri];
      if (!s) {
        const i = Object.keys(dt).length % Number.MAX_SAFE_INTEGER;
        s = new Uint8Array(16), new DataView(s.buffer, 12, 4).setUint32(0, i), dt[this.uri] = s;
      }
      this.keyId = s;
    }
    return this;
  }
}
function to(n) {
  const e = new Uint8Array(16);
  for (let t = 12; t < 16; t++)
    e[t] = n >> 8 * (15 - t) & 255;
  return e;
}
const Mr = /\{\$([a-zA-Z0-9-_]+)\}/g;
function gi(n) {
  return Mr.test(n);
}
function de(n, e, t) {
  if (n.variableList !== null || n.hasVariableRefs)
    for (let s = t.length; s--; ) {
      const i = t[s], r = e[i];
      r && (e[i] = xs(n, r));
    }
}
function xs(n, e) {
  if (n.variableList !== null || n.hasVariableRefs) {
    const t = n.variableList;
    return e.replace(Mr, (s) => {
      const i = s.substring(2, s.length - 1), r = t == null ? void 0 : t[i];
      return r === void 0 ? (n.playlistParsingError || (n.playlistParsingError = new Error(`Missing preceding EXT-X-DEFINE tag for Variable Reference: "${i}"`)), s) : r;
    });
  }
  return e;
}
function mi(n, e, t) {
  let s = n.variableList;
  s || (n.variableList = s = {});
  let i, r;
  if ("QUERYPARAM" in e) {
    i = e.QUERYPARAM;
    try {
      const a = new self.URL(t).searchParams;
      if (a.has(i))
        r = a.get(i);
      else
        throw new Error(`"${i}" does not match any query parameter in URI: "${t}"`);
    } catch (a) {
      n.playlistParsingError || (n.playlistParsingError = new Error(`EXT-X-DEFINE QUERYPARAM: ${a.message}`));
    }
  } else
    i = e.NAME, r = e.VALUE;
  i in s ? n.playlistParsingError || (n.playlistParsingError = new Error(`EXT-X-DEFINE duplicate Variable Name declarations: "${i}"`)) : s[i] = r || "";
}
function so(n, e, t) {
  const s = e.IMPORT;
  if (t && s in t) {
    let i = n.variableList;
    i || (n.variableList = i = {}), i[s] = t[s];
  } else
    n.playlistParsingError || (n.playlistParsingError = new Error(`EXT-X-DEFINE IMPORT attribute not found in Multivariant Playlist: "${s}"`));
}
function Ve(n = !0) {
  return typeof self > "u" ? void 0 : (n || !self.MediaSource) && self.ManagedMediaSource || self.MediaSource || self.WebKitMediaSource;
}
function io(n) {
  return typeof self < "u" && n === self.ManagedMediaSource;
}
const wt = {
  audio: {
    a3ds: 1,
    "ac-3": 0.95,
    "ac-4": 1,
    alac: 0.9,
    alaw: 1,
    dra1: 1,
    "dts+": 1,
    "dts-": 1,
    dtsc: 1,
    dtse: 1,
    dtsh: 1,
    "ec-3": 0.9,
    enca: 1,
    fLaC: 0.9,
    // MP4-RA listed codec entry for FLAC
    flac: 0.9,
    // legacy browser codec name for FLAC
    FLAC: 0.9,
    // some manifests may list "FLAC" with Apple's tools
    g719: 1,
    g726: 1,
    m4ae: 1,
    mha1: 1,
    mha2: 1,
    mhm1: 1,
    mhm2: 1,
    mlpa: 1,
    mp4a: 1,
    "raw ": 1,
    Opus: 1,
    opus: 1,
    // browsers expect this to be lowercase despite MP4RA says 'Opus'
    samr: 1,
    sawb: 1,
    sawp: 1,
    sevc: 1,
    sqcp: 1,
    ssmv: 1,
    twos: 1,
    ulaw: 1
  },
  video: {
    avc1: 1,
    avc2: 1,
    avc3: 1,
    avc4: 1,
    avcp: 1,
    av01: 0.8,
    drac: 1,
    dva1: 1,
    dvav: 1,
    dvh1: 0.7,
    dvhe: 0.7,
    encv: 1,
    hev1: 0.75,
    hvc1: 0.75,
    mjp2: 1,
    mp4v: 1,
    mvc1: 1,
    mvc2: 1,
    mvc3: 1,
    mvc4: 1,
    resv: 1,
    rv60: 1,
    s263: 1,
    svc1: 1,
    svc2: 1,
    "vc-1": 1,
    vp08: 1,
    vp09: 0.9
  },
  text: {
    stpp: 1,
    wvtt: 1
  }
};
function ro(n, e) {
  const t = wt[e];
  return !!t && !!t[n.slice(0, 4)];
}
function Jt(n, e, t = !0) {
  return !n.split(",").some((s) => !Nr(s, e, t));
}
function Nr(n, e, t = !0) {
  var s;
  const i = Ve(t);
  return (s = i == null ? void 0 : i.isTypeSupported(ct(n, e))) != null ? s : !1;
}
function ct(n, e) {
  return `${e}/mp4;codecs="${n}"`;
}
function pi(n) {
  if (n) {
    const e = n.substring(0, 4);
    return wt.video[e];
  }
  return 2;
}
function Pt(n) {
  return n.split(",").reduce((e, t) => {
    const s = wt.video[t];
    return s ? (s * 2 + e) / (e ? 3 : 2) : (wt.audio[t] + e) / (e ? 2 : 1);
  }, 0);
}
const Zt = {};
function no(n, e = !0) {
  if (Zt[n])
    return Zt[n];
  const t = {
    flac: ["flac", "fLaC", "FLAC"],
    opus: ["opus", "Opus"]
  }[n];
  for (let s = 0; s < t.length; s++)
    if (Nr(t[s], "audio", e))
      return Zt[n] = t[s], t[s];
  return n;
}
const ao = /flac|opus/i;
function Ft(n, e = !0) {
  return n.replace(ao, (t) => no(t.toLowerCase(), e));
}
function Ei(n, e) {
  return n && n !== "mp4a" ? n : e && e.split(",")[0];
}
function oo(n) {
  const e = n.split(",");
  for (let t = 0; t < e.length; t++) {
    const s = e[t].split(".");
    if (s.length > 2) {
      let i = s.shift() + ".";
      i += parseInt(s.shift()).toString(16), i += ("000" + parseInt(s.shift()).toString(16)).slice(-4), e[t] = i;
    }
  }
  return e.join(",");
}
const Ti = /#EXT-X-STREAM-INF:([^\r\n]*)(?:[\r\n](?:#[^\r\n]*)?)*([^\r\n]+)|#EXT-X-(SESSION-DATA|SESSION-KEY|DEFINE|CONTENT-STEERING|START):([^\r\n]*)[\r\n]+/g, yi = /#EXT-X-MEDIA:(.*)/g, lo = /^#EXT(?:INF|-X-TARGETDURATION):/m, xi = new RegExp([
  /#EXTINF:\s*(\d*(?:\.\d+)?)(?:,(.*)\s+)?/.source,
  // duration (#EXTINF:<duration>,<title>), group 1 => duration, group 2 => title
  /(?!#) *(\S[^\r\n]*)/.source,
  // segment URI, group 3 => the URI (note newline is not eaten)
  /#EXT-X-BYTERANGE:*(.+)/.source,
  // next segment's byterange, group 4 => range spec (x@y)
  /#EXT-X-PROGRAM-DATE-TIME:(.+)/.source,
  // next segment's program date/time group 5 => the datetime spec
  /#.*/.source
  // All other non-segment oriented tags will match with all groups empty
].join("|"), "g"), co = new RegExp([/#(EXTM3U)/.source, /#EXT-X-(DATERANGE|DEFINE|KEY|MAP|PART|PART-INF|PLAYLIST-TYPE|PRELOAD-HINT|RENDITION-REPORT|SERVER-CONTROL|SKIP|START):(.+)/.source, /#EXT-X-(BITRATE|DISCONTINUITY-SEQUENCE|MEDIA-SEQUENCE|TARGETDURATION|VERSION): *(\d+)/.source, /#EXT-X-(DISCONTINUITY|ENDLIST|GAP|INDEPENDENT-SEGMENTS)/.source, /(#)([^:]*):(.*)/.source, /(#)(.*)(?:.*)\r?\n?/.source].join("|"));
class Re {
  static findGroup(e, t) {
    for (let s = 0; s < e.length; s++) {
      const i = e[s];
      if (i.id === t)
        return i;
    }
  }
  static resolve(e, t) {
    return Ns.buildAbsoluteURL(t, e, {
      alwaysNormalize: !0
    });
  }
  static isMediaPlaylist(e) {
    return lo.test(e);
  }
  static parseMasterPlaylist(e, t) {
    const s = gi(e), i = {
      contentSteering: null,
      levels: [],
      playlistParsingError: null,
      sessionData: null,
      sessionKeys: null,
      startTimeOffset: null,
      variableList: null,
      hasVariableRefs: s
    }, r = [];
    Ti.lastIndex = 0;
    let a;
    for (; (a = Ti.exec(e)) != null; )
      if (a[1]) {
        var o;
        const c = new ee(a[1]);
        de(i, c, ["CODECS", "SUPPLEMENTAL-CODECS", "ALLOWED-CPC", "PATHWAY-ID", "STABLE-VARIANT-ID", "AUDIO", "VIDEO", "SUBTITLES", "CLOSED-CAPTIONS", "NAME"]);
        const h = xs(i, a[2]), u = {
          attrs: c,
          bitrate: c.decimalInteger("BANDWIDTH") || c.decimalInteger("AVERAGE-BANDWIDTH"),
          name: c.NAME,
          url: Re.resolve(h, t)
        }, d = c.decimalResolution("RESOLUTION");
        d && (u.width = d.width, u.height = d.height), ho(c.CODECS, u), (o = u.unknownCodecs) != null && o.length || r.push(u), i.levels.push(u);
      } else if (a[3]) {
        const c = a[3], h = a[4];
        switch (c) {
          case "SESSION-DATA": {
            const u = new ee(h);
            de(i, u, ["DATA-ID", "LANGUAGE", "VALUE", "URI"]);
            const d = u["DATA-ID"];
            d && (i.sessionData === null && (i.sessionData = {}), i.sessionData[d] = u);
            break;
          }
          case "SESSION-KEY": {
            const u = Si(h, t, i);
            u.encrypted && u.isSupported() ? (i.sessionKeys === null && (i.sessionKeys = []), i.sessionKeys.push(u)) : v.warn(`[Keys] Ignoring invalid EXT-X-SESSION-KEY tag: "${h}"`);
            break;
          }
          case "DEFINE": {
            {
              const u = new ee(h);
              de(i, u, ["NAME", "VALUE", "QUERYPARAM"]), mi(i, u, t);
            }
            break;
          }
          case "CONTENT-STEERING": {
            const u = new ee(h);
            de(i, u, ["SERVER-URI", "PATHWAY-ID"]), i.contentSteering = {
              uri: Re.resolve(u["SERVER-URI"], t),
              pathwayId: u["PATHWAY-ID"] || "."
            };
            break;
          }
          case "START": {
            i.startTimeOffset = vi(h);
            break;
          }
        }
      }
    const l = r.length > 0 && r.length < i.levels.length;
    return i.levels = l ? r : i.levels, i.levels.length === 0 && (i.playlistParsingError = new Error("no levels found in manifest")), i;
  }
  static parseMasterPlaylistMedia(e, t, s) {
    let i;
    const r = {}, a = s.levels, o = {
      AUDIO: a.map((c) => ({
        id: c.attrs.AUDIO,
        audioCodec: c.audioCodec
      })),
      SUBTITLES: a.map((c) => ({
        id: c.attrs.SUBTITLES,
        textCodec: c.textCodec
      })),
      "CLOSED-CAPTIONS": []
    };
    let l = 0;
    for (yi.lastIndex = 0; (i = yi.exec(e)) !== null; ) {
      const c = new ee(i[1]), h = c.TYPE;
      if (h) {
        const u = o[h], d = r[h] || [];
        r[h] = d, de(s, c, ["URI", "GROUP-ID", "LANGUAGE", "ASSOC-LANGUAGE", "STABLE-RENDITION-ID", "NAME", "INSTREAM-ID", "CHARACTERISTICS", "CHANNELS"]);
        const f = c.LANGUAGE, g = c["ASSOC-LANGUAGE"], m = c.CHANNELS, E = c.CHARACTERISTICS, T = c["INSTREAM-ID"], y = {
          attrs: c,
          bitrate: 0,
          id: l++,
          groupId: c["GROUP-ID"] || "",
          name: c.NAME || f || "",
          type: h,
          default: c.bool("DEFAULT"),
          autoselect: c.bool("AUTOSELECT"),
          forced: c.bool("FORCED"),
          lang: f,
          url: c.URI ? Re.resolve(c.URI, t) : ""
        };
        if (g && (y.assocLang = g), m && (y.channels = m), E && (y.characteristics = E), T && (y.instreamId = T), u != null && u.length) {
          const x = Re.findGroup(u, y.groupId) || u[0];
          Ai(y, x, "audioCodec"), Ai(y, x, "textCodec");
        }
        d.push(y);
      }
    }
    return r;
  }
  static parseLevelPlaylist(e, t, s, i, r, a) {
    const o = new La(t), l = o.fragments;
    let c = null, h = 0, u = 0, d = 0, f = 0, g = null, m = new qt(i, t), E, T, y, x = -1, b = !1, S = null;
    for (xi.lastIndex = 0, o.m3u8 = e, o.hasVariableRefs = gi(e); (E = xi.exec(e)) !== null; ) {
      b && (b = !1, m = new qt(i, t), m.start = d, m.sn = h, m.cc = f, m.level = s, c && (m.initSegment = c, m.rawProgramDateTime = c.rawProgramDateTime, c.rawProgramDateTime = null, S && (m.setByteRange(S), S = null)));
      const P = E[1];
      if (P) {
        m.duration = parseFloat(P);
        const I = (" " + E[2]).slice(1);
        m.title = I || null, m.tagList.push(I ? ["INF", P, I] : ["INF", P]);
      } else if (E[3]) {
        if (M(m.duration)) {
          m.start = d, y && bi(m, y, o), m.sn = h, m.level = s, m.cc = f, l.push(m);
          const I = (" " + E[3]).slice(1);
          m.relurl = xs(o, I), Li(m, g), g = m, d += m.duration, h++, u = 0, b = !0;
        }
      } else if (E[4]) {
        const I = (" " + E[4]).slice(1);
        g ? m.setByteRange(I, g) : m.setByteRange(I);
      } else if (E[5])
        m.rawProgramDateTime = (" " + E[5]).slice(1), m.tagList.push(["PROGRAM-DATE-TIME", m.rawProgramDateTime]), x === -1 && (x = l.length);
      else {
        if (E = E[0].match(co), !E) {
          v.warn("No matches on slow regex match for level playlist!");
          continue;
        }
        for (T = 1; T < E.length && !(typeof E[T] < "u"); T++)
          ;
        const I = (" " + E[T]).slice(1), k = (" " + E[T + 1]).slice(1), V = E[T + 2] ? (" " + E[T + 2]).slice(1) : "";
        switch (I) {
          case "PLAYLIST-TYPE":
            o.type = k.toUpperCase();
            break;
          case "MEDIA-SEQUENCE":
            h = o.startSN = parseInt(k);
            break;
          case "SKIP": {
            const F = new ee(k);
            de(o, F, ["RECENTLY-REMOVED-DATERANGES"]);
            const w = F.decimalInteger("SKIPPED-SEGMENTS");
            if (M(w)) {
              o.skippedSegments = w;
              for (let U = w; U--; )
                l.unshift(null);
              h += w;
            }
            const $ = F.enumeratedString("RECENTLY-REMOVED-DATERANGES");
            $ && (o.recentlyRemovedDateranges = $.split("	"));
            break;
          }
          case "TARGETDURATION":
            o.targetduration = Math.max(parseInt(k), 1);
            break;
          case "VERSION":
            o.version = parseInt(k);
            break;
          case "INDEPENDENT-SEGMENTS":
          case "EXTM3U":
            break;
          case "ENDLIST":
            o.live = !1;
            break;
          case "#":
            (k || V) && m.tagList.push(V ? [k, V] : [k]);
            break;
          case "DISCONTINUITY":
            f++, m.tagList.push(["DIS"]);
            break;
          case "GAP":
            m.gap = !0, m.tagList.push([I]);
            break;
          case "BITRATE":
            m.tagList.push([I, k]);
            break;
          case "DATERANGE": {
            const F = new ee(k);
            de(o, F, ["ID", "CLASS", "START-DATE", "END-DATE", "SCTE35-CMD", "SCTE35-OUT", "SCTE35-IN"]), de(o, F, F.clientAttrs);
            const w = new Ar(F, o.dateRanges[F.ID]);
            w.isValid || o.skippedSegments ? o.dateRanges[w.id] = w : v.warn(`Ignoring invalid DATERANGE tag: "${k}"`), m.tagList.push(["EXT-X-DATERANGE", k]);
            break;
          }
          case "DEFINE": {
            {
              const F = new ee(k);
              de(o, F, ["NAME", "VALUE", "IMPORT", "QUERYPARAM"]), "IMPORT" in F ? so(o, F, a) : mi(o, F, t);
            }
            break;
          }
          case "DISCONTINUITY-SEQUENCE":
            f = parseInt(k);
            break;
          case "KEY": {
            const F = Si(k, t, o);
            if (F.isSupported()) {
              if (F.method === "NONE") {
                y = void 0;
                break;
              }
              y || (y = {}), y[F.keyFormat] && (y = se({}, y)), y[F.keyFormat] = F;
            } else
              v.warn(`[Keys] Ignoring invalid EXT-X-KEY tag: "${k}"`);
            break;
          }
          case "START":
            o.startTimeOffset = vi(k);
            break;
          case "MAP": {
            const F = new ee(k);
            if (de(o, F, ["BYTERANGE", "URI"]), m.duration) {
              const w = new qt(i, t);
              Ri(w, F, s, y), c = w, m.initSegment = c, c.rawProgramDateTime && !m.rawProgramDateTime && (m.rawProgramDateTime = c.rawProgramDateTime);
            } else {
              const w = m.byteRangeEndOffset;
              if (w) {
                const $ = m.byteRangeStartOffset;
                S = `${w - $}@${$}`;
              } else
                S = null;
              Ri(m, F, s, y), c = m, b = !0;
            }
            break;
          }
          case "SERVER-CONTROL": {
            const F = new ee(k);
            o.canBlockReload = F.bool("CAN-BLOCK-RELOAD"), o.canSkipUntil = F.optionalFloat("CAN-SKIP-UNTIL", 0), o.canSkipDateRanges = o.canSkipUntil > 0 && F.bool("CAN-SKIP-DATERANGES"), o.partHoldBack = F.optionalFloat("PART-HOLD-BACK", 0), o.holdBack = F.optionalFloat("HOLD-BACK", 0);
            break;
          }
          case "PART-INF": {
            const F = new ee(k);
            o.partTarget = F.decimalFloatingPoint("PART-TARGET");
            break;
          }
          case "PART": {
            let F = o.partList;
            F || (F = o.partList = []);
            const w = u > 0 ? F[F.length - 1] : void 0, $ = u++, U = new ee(k);
            de(o, U, ["BYTERANGE", "URI"]);
            const W = new va(U, m, t, $, w);
            F.push(W), m.duration += W.duration;
            break;
          }
          case "PRELOAD-HINT": {
            const F = new ee(k);
            de(o, F, ["URI"]), o.preloadHint = F;
            break;
          }
          case "RENDITION-REPORT": {
            const F = new ee(k);
            de(o, F, ["URI"]), o.renditionReports = o.renditionReports || [], o.renditionReports.push(F);
            break;
          }
          default:
            v.warn(`line parsed but not handled: ${E}`);
            break;
        }
      }
    }
    g && !g.relurl ? (l.pop(), d -= g.duration, o.partList && (o.fragmentHint = g)) : o.partList && (Li(m, g), m.cc = f, o.fragmentHint = m, y && bi(m, y, o));
    const D = l.length, R = l[0], _ = l[D - 1];
    if (d += o.skippedSegments * o.targetduration, d > 0 && D && _) {
      o.averagetargetduration = d / D;
      const P = _.sn;
      o.endSN = P !== "initSegment" ? P : 0, o.live || (_.endList = !0), R && (o.startCC = R.cc);
    } else
      o.endSN = 0, o.startCC = 0;
    return o.fragmentHint && (d += o.fragmentHint.duration), o.totalduration = d, o.endCC = f, x > 0 && uo(l, x), o;
  }
}
function Si(n, e, t) {
  var s, i;
  const r = new ee(n);
  de(t, r, ["KEYFORMAT", "KEYFORMATVERSIONS", "URI", "IV", "URI"]);
  const a = (s = r.METHOD) != null ? s : "", o = r.URI, l = r.hexadecimalInteger("IV"), c = r.KEYFORMATVERSIONS, h = (i = r.KEYFORMAT) != null ? i : "identity";
  o && r.IV && !l && v.error(`Invalid IV: ${r.IV}`);
  const u = o ? Re.resolve(o, e) : "", d = (c || "1").split("/").map(Number).filter(Number.isFinite);
  return new lt(a, u, h, d, l);
}
function vi(n) {
  const t = new ee(n).decimalFloatingPoint("TIME-OFFSET");
  return M(t) ? t : null;
}
function ho(n, e) {
  let t = (n || "").split(/[ ,]+/).filter((s) => s);
  ["video", "audio", "text"].forEach((s) => {
    const i = t.filter((r) => ro(r, s));
    i.length && (e[`${s}Codec`] = i.join(","), t = t.filter((r) => i.indexOf(r) === -1));
  }), e.unknownCodecs = t;
}
function Ai(n, e, t) {
  const s = e[t];
  s && (n[t] = s);
}
function uo(n, e) {
  let t = n[e];
  for (let s = e; s--; ) {
    const i = n[s];
    if (!i)
      return;
    i.programDateTime = t.programDateTime - i.duration * 1e3, t = i;
  }
}
function Li(n, e) {
  n.rawProgramDateTime ? n.programDateTime = Date.parse(n.rawProgramDateTime) : e != null && e.programDateTime && (n.programDateTime = e.endProgramDateTime), M(n.programDateTime) || (n.programDateTime = null, n.rawProgramDateTime = null);
}
function Ri(n, e, t, s) {
  n.relurl = e.URI, e.BYTERANGE && n.setByteRange(e.BYTERANGE), n.level = t, n.sn = "initSegment", s && (n.levelkeys = s), n.initSegment = null;
}
function bi(n, e, t) {
  n.levelkeys = e;
  const {
    encryptedFragments: s
  } = t;
  (!s.length || s[s.length - 1].levelkeys !== e) && Object.keys(e).some((i) => e[i].isCommonEncryption) && s.push(n);
}
var q = {
  MANIFEST: "manifest",
  LEVEL: "level",
  AUDIO_TRACK: "audioTrack",
  SUBTITLE_TRACK: "subtitleTrack"
}, G = {
  MAIN: "main",
  AUDIO: "audio",
  SUBTITLE: "subtitle"
};
function Ii(n) {
  const {
    type: e
  } = n;
  switch (e) {
    case q.AUDIO_TRACK:
      return G.AUDIO;
    case q.SUBTITLE_TRACK:
      return G.SUBTITLE;
    default:
      return G.MAIN;
  }
}
function es(n, e) {
  let t = n.url;
  return (t === void 0 || t.indexOf("data:") === 0) && (t = e.url), t;
}
class fo {
  constructor(e) {
    this.hls = void 0, this.loaders = /* @__PURE__ */ Object.create(null), this.variableList = null, this.hls = e, this.registerListeners();
  }
  startLoad(e) {
  }
  stopLoad() {
    this.destroyInternalLoaders();
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.LEVEL_LOADING, this.onLevelLoading, this), e.on(p.AUDIO_TRACK_LOADING, this.onAudioTrackLoading, this), e.on(p.SUBTITLE_TRACK_LOADING, this.onSubtitleTrackLoading, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.LEVEL_LOADING, this.onLevelLoading, this), e.off(p.AUDIO_TRACK_LOADING, this.onAudioTrackLoading, this), e.off(p.SUBTITLE_TRACK_LOADING, this.onSubtitleTrackLoading, this);
  }
  /**
   * Returns defaults or configured loader-type overloads (pLoader and loader config params)
   */
  createInternalLoader(e) {
    const t = this.hls.config, s = t.pLoader, i = t.loader, r = s || i, a = new r(t);
    return this.loaders[e.type] = a, a;
  }
  getInternalLoader(e) {
    return this.loaders[e.type];
  }
  resetInternalLoader(e) {
    this.loaders[e] && delete this.loaders[e];
  }
  /**
   * Call `destroy` on all internal loader instances mapped (one per context type)
   */
  destroyInternalLoaders() {
    for (const e in this.loaders) {
      const t = this.loaders[e];
      t && t.destroy(), this.resetInternalLoader(e);
    }
  }
  destroy() {
    this.variableList = null, this.unregisterListeners(), this.destroyInternalLoaders();
  }
  onManifestLoading(e, t) {
    const {
      url: s
    } = t;
    this.variableList = null, this.load({
      id: null,
      level: 0,
      responseType: "text",
      type: q.MANIFEST,
      url: s,
      deliveryDirectives: null
    });
  }
  onLevelLoading(e, t) {
    const {
      id: s,
      level: i,
      pathwayId: r,
      url: a,
      deliveryDirectives: o
    } = t;
    this.load({
      id: s,
      level: i,
      pathwayId: r,
      responseType: "text",
      type: q.LEVEL,
      url: a,
      deliveryDirectives: o
    });
  }
  onAudioTrackLoading(e, t) {
    const {
      id: s,
      groupId: i,
      url: r,
      deliveryDirectives: a
    } = t;
    this.load({
      id: s,
      groupId: i,
      level: null,
      responseType: "text",
      type: q.AUDIO_TRACK,
      url: r,
      deliveryDirectives: a
    });
  }
  onSubtitleTrackLoading(e, t) {
    const {
      id: s,
      groupId: i,
      url: r,
      deliveryDirectives: a
    } = t;
    this.load({
      id: s,
      groupId: i,
      level: null,
      responseType: "text",
      type: q.SUBTITLE_TRACK,
      url: r,
      deliveryDirectives: a
    });
  }
  load(e) {
    var t;
    const s = this.hls.config;
    let i = this.getInternalLoader(e);
    if (i) {
      const c = i.context;
      if (c && c.url === e.url && c.level === e.level) {
        v.trace("[playlist-loader]: playlist request ongoing");
        return;
      }
      v.log(`[playlist-loader]: aborting previous loader for type: ${e.type}`), i.abort();
    }
    let r;
    if (e.type === q.MANIFEST ? r = s.manifestLoadPolicy.default : r = se({}, s.playlistLoadPolicy.default, {
      timeoutRetry: null,
      errorRetry: null
    }), i = this.createInternalLoader(e), M((t = e.deliveryDirectives) == null ? void 0 : t.part)) {
      let c;
      if (e.type === q.LEVEL && e.level !== null ? c = this.hls.levels[e.level].details : e.type === q.AUDIO_TRACK && e.id !== null ? c = this.hls.audioTracks[e.id].details : e.type === q.SUBTITLE_TRACK && e.id !== null && (c = this.hls.subtitleTracks[e.id].details), c) {
        const h = c.partTarget, u = c.targetduration;
        if (h && u) {
          const d = Math.max(h * 3, u * 0.8) * 1e3;
          r = se({}, r, {
            maxTimeToFirstByteMs: Math.min(d, r.maxTimeToFirstByteMs),
            maxLoadTimeMs: Math.min(d, r.maxTimeToFirstByteMs)
          });
        }
      }
    }
    const a = r.errorRetry || r.timeoutRetry || {}, o = {
      loadPolicy: r,
      timeout: r.maxLoadTimeMs,
      maxRetry: a.maxNumRetry || 0,
      retryDelay: a.retryDelayMs || 0,
      maxRetryDelay: a.maxRetryDelayMs || 0
    }, l = {
      onSuccess: (c, h, u, d) => {
        const f = this.getInternalLoader(u);
        this.resetInternalLoader(u.type);
        const g = c.data;
        if (g.indexOf("#EXTM3U") !== 0) {
          this.handleManifestParsingError(c, u, new Error("no EXTM3U delimiter"), d || null, h);
          return;
        }
        h.parsing.start = performance.now(), Re.isMediaPlaylist(g) ? this.handleTrackOrLevelPlaylist(c, h, u, d || null, f) : this.handleMasterPlaylist(c, h, u, d);
      },
      onError: (c, h, u, d) => {
        this.handleNetworkError(h, u, !1, c, d);
      },
      onTimeout: (c, h, u) => {
        this.handleNetworkError(h, u, !0, void 0, c);
      }
    };
    i.load(e, o, l);
  }
  handleMasterPlaylist(e, t, s, i) {
    const r = this.hls, a = e.data, o = es(e, s), l = Re.parseMasterPlaylist(a, o);
    if (l.playlistParsingError) {
      this.handleManifestParsingError(e, s, l.playlistParsingError, i, t);
      return;
    }
    const {
      contentSteering: c,
      levels: h,
      sessionData: u,
      sessionKeys: d,
      startTimeOffset: f,
      variableList: g
    } = l;
    this.variableList = g;
    const {
      AUDIO: m = [],
      SUBTITLES: E,
      "CLOSED-CAPTIONS": T
    } = Re.parseMasterPlaylistMedia(a, o, l);
    m.length && !m.some((x) => !x.url) && h[0].audioCodec && !h[0].attrs.AUDIO && (v.log("[playlist-loader]: audio codec signaled in quality level, but no embedded audio track signaled, create one"), m.unshift({
      type: "main",
      name: "main",
      groupId: "main",
      default: !1,
      autoselect: !1,
      forced: !1,
      id: -1,
      attrs: new ee({}),
      bitrate: 0,
      url: ""
    })), r.trigger(p.MANIFEST_LOADED, {
      levels: h,
      audioTracks: m,
      subtitles: E,
      captions: T,
      contentSteering: c,
      url: o,
      stats: t,
      networkDetails: i,
      sessionData: u,
      sessionKeys: d,
      startTimeOffset: f,
      variableList: g
    });
  }
  handleTrackOrLevelPlaylist(e, t, s, i, r) {
    const a = this.hls, {
      id: o,
      level: l,
      type: c
    } = s, h = es(e, s), u = 0, d = M(l) ? l : M(o) ? o : 0, f = Ii(s), g = Re.parseLevelPlaylist(e.data, h, d, f, u, this.variableList);
    if (c === q.MANIFEST) {
      const m = {
        attrs: new ee({}),
        bitrate: 0,
        details: g,
        name: "",
        url: h
      };
      a.trigger(p.MANIFEST_LOADED, {
        levels: [m],
        audioTracks: [],
        url: h,
        stats: t,
        networkDetails: i,
        sessionData: null,
        sessionKeys: null,
        contentSteering: null,
        startTimeOffset: null,
        variableList: null
      });
    }
    t.parsing.end = performance.now(), s.levelDetails = g, this.handlePlaylistLoaded(g, e, t, s, i, r);
  }
  handleManifestParsingError(e, t, s, i, r) {
    this.hls.trigger(p.ERROR, {
      type: K.NETWORK_ERROR,
      details: L.MANIFEST_PARSING_ERROR,
      fatal: t.type === q.MANIFEST,
      url: e.url,
      err: s,
      error: s,
      reason: s.message,
      response: e,
      context: t,
      networkDetails: i,
      stats: r
    });
  }
  handleNetworkError(e, t, s = !1, i, r) {
    let a = `A network ${s ? "timeout" : "error" + (i ? " (status " + i.code + ")" : "")} occurred while loading ${e.type}`;
    e.type === q.LEVEL ? a += `: ${e.level} id: ${e.id}` : (e.type === q.AUDIO_TRACK || e.type === q.SUBTITLE_TRACK) && (a += ` id: ${e.id} group-id: "${e.groupId}"`);
    const o = new Error(a);
    v.warn(`[playlist-loader]: ${a}`);
    let l = L.UNKNOWN, c = !1;
    const h = this.getInternalLoader(e);
    switch (e.type) {
      case q.MANIFEST:
        l = s ? L.MANIFEST_LOAD_TIMEOUT : L.MANIFEST_LOAD_ERROR, c = !0;
        break;
      case q.LEVEL:
        l = s ? L.LEVEL_LOAD_TIMEOUT : L.LEVEL_LOAD_ERROR, c = !1;
        break;
      case q.AUDIO_TRACK:
        l = s ? L.AUDIO_TRACK_LOAD_TIMEOUT : L.AUDIO_TRACK_LOAD_ERROR, c = !1;
        break;
      case q.SUBTITLE_TRACK:
        l = s ? L.SUBTITLE_TRACK_LOAD_TIMEOUT : L.SUBTITLE_LOAD_ERROR, c = !1;
        break;
    }
    h && this.resetInternalLoader(e.type);
    const u = {
      type: K.NETWORK_ERROR,
      details: l,
      fatal: c,
      url: e.url,
      loader: h,
      context: e,
      error: o,
      networkDetails: t,
      stats: r
    };
    if (i) {
      const d = (t == null ? void 0 : t.url) || e.url;
      u.response = oe({
        url: d,
        data: void 0
      }, i);
    }
    this.hls.trigger(p.ERROR, u);
  }
  handlePlaylistLoaded(e, t, s, i, r, a) {
    const o = this.hls, {
      type: l,
      level: c,
      id: h,
      groupId: u,
      deliveryDirectives: d
    } = i, f = es(t, i), g = Ii(i), m = typeof i.level == "number" && g === G.MAIN ? c : void 0;
    if (!e.fragments.length) {
      const T = new Error("No Segments found in Playlist");
      o.trigger(p.ERROR, {
        type: K.NETWORK_ERROR,
        details: L.LEVEL_EMPTY_ERROR,
        fatal: !1,
        url: f,
        error: T,
        reason: T.message,
        response: t,
        context: i,
        level: m,
        parent: g,
        networkDetails: r,
        stats: s
      });
      return;
    }
    e.targetduration || (e.playlistParsingError = new Error("Missing Target Duration"));
    const E = e.playlistParsingError;
    if (E) {
      o.trigger(p.ERROR, {
        type: K.NETWORK_ERROR,
        details: L.LEVEL_PARSING_ERROR,
        fatal: !1,
        url: f,
        error: E,
        reason: E.message,
        response: t,
        context: i,
        level: m,
        parent: g,
        networkDetails: r,
        stats: s
      });
      return;
    }
    switch (e.live && a && (a.getCacheAge && (e.ageHeader = a.getCacheAge() || 0), (!a.getCacheAge || isNaN(e.ageHeader)) && (e.ageHeader = 0)), l) {
      case q.MANIFEST:
      case q.LEVEL:
        o.trigger(p.LEVEL_LOADED, {
          details: e,
          level: m || 0,
          id: h || 0,
          stats: s,
          networkDetails: r,
          deliveryDirectives: d
        });
        break;
      case q.AUDIO_TRACK:
        o.trigger(p.AUDIO_TRACK_LOADED, {
          details: e,
          id: h || 0,
          groupId: u || "",
          stats: s,
          networkDetails: r,
          deliveryDirectives: d
        });
        break;
      case q.SUBTITLE_TRACK:
        o.trigger(p.SUBTITLE_TRACK_LOADED, {
          details: e,
          id: h || 0,
          groupId: u || "",
          stats: s,
          networkDetails: r,
          deliveryDirectives: d
        });
        break;
    }
  }
}
function Ur(n, e) {
  let t;
  try {
    t = new Event("addtrack");
  } catch {
    t = document.createEvent("Event"), t.initEvent("addtrack", !1, !1);
  }
  t.track = n, e.dispatchEvent(t);
}
function Br(n, e) {
  const t = n.mode;
  if (t === "disabled" && (n.mode = "hidden"), n.cues && !n.cues.getCueById(e.id))
    try {
      if (n.addCue(e), !n.cues.getCueById(e.id))
        throw new Error(`addCue is failed for: ${e}`);
    } catch (s) {
      v.debug(`[texttrack-utils]: ${s}`);
      try {
        const i = new self.TextTrackCue(e.startTime, e.endTime, e.text);
        i.id = e.id, n.addCue(i);
      } catch (i) {
        v.debug(`[texttrack-utils]: Legacy TextTrackCue fallback failed: ${i}`);
      }
    }
  t === "disabled" && (n.mode = t);
}
function ze(n) {
  const e = n.mode;
  if (e === "disabled" && (n.mode = "hidden"), n.cues)
    for (let t = n.cues.length; t--; )
      n.removeCue(n.cues[t]);
  e === "disabled" && (n.mode = e);
}
function Ss(n, e, t, s) {
  const i = n.mode;
  if (i === "disabled" && (n.mode = "hidden"), n.cues && n.cues.length > 0) {
    const r = mo(n.cues, e, t);
    for (let a = 0; a < r.length; a++)
      (!s || s(r[a])) && n.removeCue(r[a]);
  }
  i === "disabled" && (n.mode = i);
}
function go(n, e) {
  if (e < n[0].startTime)
    return 0;
  const t = n.length - 1;
  if (e > n[t].endTime)
    return -1;
  let s = 0, i = t;
  for (; s <= i; ) {
    const r = Math.floor((i + s) / 2);
    if (e < n[r].startTime)
      i = r - 1;
    else if (e > n[r].startTime && s < t)
      s = r + 1;
    else
      return r;
  }
  return n[s].startTime - e < e - n[i].startTime ? s : i;
}
function mo(n, e, t) {
  const s = [], i = go(n, e);
  if (i > -1)
    for (let r = i, a = n.length; r < a; r++) {
      const o = n[r];
      if (o.startTime >= e && o.endTime <= t)
        s.push(o);
      else if (o.startTime > t)
        return s;
    }
  return s;
}
function At(n) {
  const e = [];
  for (let t = 0; t < n.length; t++) {
    const s = n[t];
    (s.kind === "subtitles" || s.kind === "captions") && s.label && e.push(n[t]);
  }
  return e;
}
var Se = {
  audioId3: "org.id3",
  dateRange: "com.apple.quicktime.HLS",
  emsg: "https://aomedia.org/emsg/ID3"
};
const po = 0.25;
function vs() {
  if (!(typeof self > "u"))
    return self.VTTCue || self.TextTrackCue;
}
function Di(n, e, t, s, i) {
  let r = new n(e, t, "");
  try {
    r.value = s, i && (r.type = i);
  } catch {
    r = new n(e, t, JSON.stringify(i ? oe({
      type: i
    }, s) : s));
  }
  return r;
}
const ft = (() => {
  const n = vs();
  try {
    n && new n(0, Number.POSITIVE_INFINITY, "");
  } catch {
    return Number.MAX_VALUE;
  }
  return Number.POSITIVE_INFINITY;
})();
function ts(n, e) {
  return n.getTime() / 1e3 - e;
}
function Eo(n) {
  return Uint8Array.from(n.replace(/^0x/, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")).buffer;
}
class To {
  constructor(e) {
    this.hls = void 0, this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {}, this.hls = e, this._registerListeners();
  }
  destroy() {
    this._unregisterListeners(), this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {}, this.hls = null;
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.FRAG_PARSING_METADATA, this.onFragParsingMetadata, this), e.on(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.on(p.LEVEL_UPDATED, this.onLevelUpdated, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.FRAG_PARSING_METADATA, this.onFragParsingMetadata, this), e.off(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.off(p.LEVEL_UPDATED, this.onLevelUpdated, this);
  }
  // Add ID3 metatadata text track.
  onMediaAttached(e, t) {
    this.media = t.media;
  }
  onMediaDetaching() {
    this.id3Track && (ze(this.id3Track), this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {});
  }
  onManifestLoading() {
    this.dateRangeCuesAppended = {};
  }
  createTrack(e) {
    const t = this.getID3Track(e.textTracks);
    return t.mode = "hidden", t;
  }
  getID3Track(e) {
    if (this.media) {
      for (let t = 0; t < e.length; t++) {
        const s = e[t];
        if (s.kind === "metadata" && s.label === "id3")
          return Ur(s, this.media), s;
      }
      return this.media.addTextTrack("metadata", "id3");
    }
  }
  onFragParsingMetadata(e, t) {
    if (!this.media)
      return;
    const {
      hls: {
        config: {
          enableEmsgMetadataCues: s,
          enableID3MetadataCues: i
        }
      }
    } = this;
    if (!s && !i)
      return;
    const {
      samples: r
    } = t;
    this.id3Track || (this.id3Track = this.createTrack(this.media));
    const a = vs();
    if (a)
      for (let o = 0; o < r.length; o++) {
        const l = r[o].type;
        if (l === Se.emsg && !s || !i)
          continue;
        const c = Dr(r[o].data);
        if (c) {
          const h = r[o].pts;
          let u = h + r[o].duration;
          u > ft && (u = ft), u - h <= 0 && (u = h + po);
          for (let f = 0; f < c.length; f++) {
            const g = c[f];
            if (!Ir(g)) {
              this.updateId3CueEnds(h, l);
              const m = Di(a, h, u, g, l);
              m && this.id3Track.addCue(m);
            }
          }
        }
      }
  }
  updateId3CueEnds(e, t) {
    var s;
    const i = (s = this.id3Track) == null ? void 0 : s.cues;
    if (i)
      for (let r = i.length; r--; ) {
        const a = i[r];
        a.type === t && a.startTime < e && a.endTime === ft && (a.endTime = e);
      }
  }
  onBufferFlushing(e, {
    startOffset: t,
    endOffset: s,
    type: i
  }) {
    const {
      id3Track: r,
      hls: a
    } = this;
    if (!a)
      return;
    const {
      config: {
        enableEmsgMetadataCues: o,
        enableID3MetadataCues: l
      }
    } = a;
    if (r && (o || l)) {
      let c;
      i === "audio" ? c = (h) => h.type === Se.audioId3 && l : i === "video" ? c = (h) => h.type === Se.emsg && o : c = (h) => h.type === Se.audioId3 && l || h.type === Se.emsg && o, Ss(r, t, s, c);
    }
  }
  onLevelUpdated(e, {
    details: t
  }) {
    if (!this.media || !t.hasProgramDateTime || !this.hls.config.enableDateRangeMetadataCues)
      return;
    const {
      dateRangeCuesAppended: s,
      id3Track: i
    } = this, {
      dateRanges: r
    } = t, a = Object.keys(r);
    if (i) {
      const h = Object.keys(s).filter((u) => !a.includes(u));
      for (let u = h.length; u--; ) {
        const d = h[u];
        Object.keys(s[d].cues).forEach((f) => {
          i.removeCue(s[d].cues[f]);
        }), delete s[d];
      }
    }
    const o = t.fragments[t.fragments.length - 1];
    if (a.length === 0 || !M(o == null ? void 0 : o.programDateTime))
      return;
    this.id3Track || (this.id3Track = this.createTrack(this.media));
    const l = o.programDateTime / 1e3 - o.start, c = vs();
    for (let h = 0; h < a.length; h++) {
      const u = a[h], d = r[u], f = ts(d.startDate, l), g = s[u], m = (g == null ? void 0 : g.cues) || {};
      let E = (g == null ? void 0 : g.durationKnown) || !1, T = ft;
      const y = d.endDate;
      if (y)
        T = ts(y, l), E = !0;
      else if (d.endOnNext && !E) {
        const b = a.reduce((S, D) => {
          if (D !== d.id) {
            const R = r[D];
            if (R.class === d.class && R.startDate > d.startDate && (!S || d.startDate < S.startDate))
              return R;
          }
          return S;
        }, null);
        b && (T = ts(b.startDate, l), E = !0);
      }
      const x = Object.keys(d.attr);
      for (let b = 0; b < x.length; b++) {
        const S = x[b];
        if (!xa(S))
          continue;
        const D = m[S];
        if (D)
          E && !g.durationKnown && (D.endTime = T);
        else if (c) {
          let R = d.attr[S];
          Sa(S) && (R = Eo(R));
          const _ = Di(c, f, T, {
            key: S,
            data: R
          }, Se.dateRange);
          _ && (_.id = u, this.id3Track.addCue(_), m[S] = _);
        }
      }
      s[u] = {
        cues: m,
        dateRange: d,
        durationKnown: E
      };
    }
  }
}
class yo {
  constructor(e) {
    this.hls = void 0, this.config = void 0, this.media = null, this.levelDetails = null, this.currentTime = 0, this.stallCount = 0, this._latency = null, this.timeupdateHandler = () => this.timeupdate(), this.hls = e, this.config = e.config, this.registerListeners();
  }
  get latency() {
    return this._latency || 0;
  }
  get maxLatency() {
    const {
      config: e,
      levelDetails: t
    } = this;
    return e.liveMaxLatencyDuration !== void 0 ? e.liveMaxLatencyDuration : t ? e.liveMaxLatencyDurationCount * t.targetduration : 0;
  }
  get targetLatency() {
    const {
      levelDetails: e
    } = this;
    if (e === null)
      return null;
    const {
      holdBack: t,
      partHoldBack: s,
      targetduration: i
    } = e, {
      liveSyncDuration: r,
      liveSyncDurationCount: a,
      lowLatencyMode: o
    } = this.config, l = this.hls.userConfig;
    let c = o && s || t;
    (l.liveSyncDuration || l.liveSyncDurationCount || c === 0) && (c = r !== void 0 ? r : a * i);
    const h = i;
    return c + Math.min(this.stallCount * 1, h);
  }
  get liveSyncPosition() {
    const e = this.estimateLiveEdge(), t = this.targetLatency, s = this.levelDetails;
    if (e === null || t === null || s === null)
      return null;
    const i = s.edge, r = e - t - this.edgeStalled, a = i - s.totalduration, o = i - (this.config.lowLatencyMode && s.partTarget || s.targetduration);
    return Math.min(Math.max(a, r), o);
  }
  get drift() {
    const {
      levelDetails: e
    } = this;
    return e === null ? 1 : e.drift;
  }
  get edgeStalled() {
    const {
      levelDetails: e
    } = this;
    if (e === null)
      return 0;
    const t = (this.config.lowLatencyMode && e.partTarget || e.targetduration) * 3;
    return Math.max(e.age - t, 0);
  }
  get forwardBufferLength() {
    const {
      media: e,
      levelDetails: t
    } = this;
    if (!e || !t)
      return 0;
    const s = e.buffered.length;
    return (s ? e.buffered.end(s - 1) : t.edge) - this.currentTime;
  }
  destroy() {
    this.unregisterListeners(), this.onMediaDetaching(), this.levelDetails = null, this.hls = this.timeupdateHandler = null;
  }
  registerListeners() {
    this.hls.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), this.hls.on(p.MANIFEST_LOADING, this.onManifestLoading, this), this.hls.on(p.LEVEL_UPDATED, this.onLevelUpdated, this), this.hls.on(p.ERROR, this.onError, this);
  }
  unregisterListeners() {
    this.hls.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), this.hls.off(p.MANIFEST_LOADING, this.onManifestLoading, this), this.hls.off(p.LEVEL_UPDATED, this.onLevelUpdated, this), this.hls.off(p.ERROR, this.onError, this);
  }
  onMediaAttached(e, t) {
    this.media = t.media, this.media.addEventListener("timeupdate", this.timeupdateHandler);
  }
  onMediaDetaching() {
    this.media && (this.media.removeEventListener("timeupdate", this.timeupdateHandler), this.media = null);
  }
  onManifestLoading() {
    this.levelDetails = null, this._latency = null, this.stallCount = 0;
  }
  onLevelUpdated(e, {
    details: t
  }) {
    this.levelDetails = t, t.advanced && this.timeupdate(), !t.live && this.media && this.media.removeEventListener("timeupdate", this.timeupdateHandler);
  }
  onError(e, t) {
    var s;
    t.details === L.BUFFER_STALLED_ERROR && (this.stallCount++, (s = this.levelDetails) != null && s.live && v.warn("[playback-rate-controller]: Stall detected, adjusting target latency"));
  }
  timeupdate() {
    const {
      media: e,
      levelDetails: t
    } = this;
    if (!e || !t)
      return;
    this.currentTime = e.currentTime;
    const s = this.computeLatency();
    if (s === null)
      return;
    this._latency = s;
    const {
      lowLatencyMode: i,
      maxLiveSyncPlaybackRate: r
    } = this.config;
    if (!i || r === 1 || !t.live)
      return;
    const a = this.targetLatency;
    if (a === null)
      return;
    const o = s - a, l = Math.min(this.maxLatency, a + t.targetduration);
    if (o < l && o > 0.05 && this.forwardBufferLength > 1) {
      const h = Math.min(2, Math.max(1, r)), u = Math.round(2 / (1 + Math.exp(-0.75 * o - this.edgeStalled)) * 20) / 20;
      e.playbackRate = Math.min(h, Math.max(1, u));
    } else e.playbackRate !== 1 && e.playbackRate !== 0 && (e.playbackRate = 1);
  }
  estimateLiveEdge() {
    const {
      levelDetails: e
    } = this;
    return e === null ? null : e.edge + e.age;
  }
  computeLatency() {
    const e = this.estimateLiveEdge();
    return e === null ? null : e - this.currentTime;
  }
}
const As = ["NONE", "TYPE-0", "TYPE-1", null];
function xo(n) {
  return As.indexOf(n) > -1;
}
const Ot = ["SDR", "PQ", "HLG"];
function So(n) {
  return !!n && Ot.indexOf(n) > -1;
}
var Lt = {
  No: "",
  Yes: "YES",
  v2: "v2"
};
function Ci(n) {
  const {
    canSkipUntil: e,
    canSkipDateRanges: t,
    age: s
  } = n, i = s < e / 2;
  return e && i ? t ? Lt.v2 : Lt.Yes : Lt.No;
}
class _i {
  constructor(e, t, s) {
    this.msn = void 0, this.part = void 0, this.skip = void 0, this.msn = e, this.part = t, this.skip = s;
  }
  addDirectives(e) {
    const t = new self.URL(e);
    return this.msn !== void 0 && t.searchParams.set("_HLS_msn", this.msn.toString()), this.part !== void 0 && t.searchParams.set("_HLS_part", this.part.toString()), this.skip && t.searchParams.set("_HLS_skip", this.skip), t.href;
  }
}
class Ze {
  constructor(e) {
    this._attrs = void 0, this.audioCodec = void 0, this.bitrate = void 0, this.codecSet = void 0, this.url = void 0, this.frameRate = void 0, this.height = void 0, this.id = void 0, this.name = void 0, this.videoCodec = void 0, this.width = void 0, this.details = void 0, this.fragmentError = 0, this.loadError = 0, this.loaded = void 0, this.realBitrate = 0, this.supportedPromise = void 0, this.supportedResult = void 0, this._avgBitrate = 0, this._audioGroups = void 0, this._subtitleGroups = void 0, this._urlId = 0, this.url = [e.url], this._attrs = [e.attrs], this.bitrate = e.bitrate, e.details && (this.details = e.details), this.id = e.id || 0, this.name = e.name, this.width = e.width || 0, this.height = e.height || 0, this.frameRate = e.attrs.optionalFloat("FRAME-RATE", 0), this._avgBitrate = e.attrs.decimalInteger("AVERAGE-BANDWIDTH"), this.audioCodec = e.audioCodec, this.videoCodec = e.videoCodec, this.codecSet = [e.videoCodec, e.audioCodec].filter((t) => !!t).map((t) => t.substring(0, 4)).join(","), this.addGroupId("audio", e.attrs.AUDIO), this.addGroupId("text", e.attrs.SUBTITLES);
  }
  get maxBitrate() {
    return Math.max(this.realBitrate, this.bitrate);
  }
  get averageBitrate() {
    return this._avgBitrate || this.realBitrate || this.bitrate;
  }
  get attrs() {
    return this._attrs[0];
  }
  get codecs() {
    return this.attrs.CODECS || "";
  }
  get pathwayId() {
    return this.attrs["PATHWAY-ID"] || ".";
  }
  get videoRange() {
    return this.attrs["VIDEO-RANGE"] || "SDR";
  }
  get score() {
    return this.attrs.optionalFloat("SCORE", 0);
  }
  get uri() {
    return this.url[0] || "";
  }
  hasAudioGroup(e) {
    return ki(this._audioGroups, e);
  }
  hasSubtitleGroup(e) {
    return ki(this._subtitleGroups, e);
  }
  get audioGroups() {
    return this._audioGroups;
  }
  get subtitleGroups() {
    return this._subtitleGroups;
  }
  addGroupId(e, t) {
    if (t) {
      if (e === "audio") {
        let s = this._audioGroups;
        s || (s = this._audioGroups = []), s.indexOf(t) === -1 && s.push(t);
      } else if (e === "text") {
        let s = this._subtitleGroups;
        s || (s = this._subtitleGroups = []), s.indexOf(t) === -1 && s.push(t);
      }
    }
  }
  // Deprecated methods (retained for backwards compatibility)
  get urlId() {
    return 0;
  }
  set urlId(e) {
  }
  get audioGroupIds() {
    return this.audioGroups ? [this.audioGroupId] : void 0;
  }
  get textGroupIds() {
    return this.subtitleGroups ? [this.textGroupId] : void 0;
  }
  get audioGroupId() {
    var e;
    return (e = this.audioGroups) == null ? void 0 : e[0];
  }
  get textGroupId() {
    var e;
    return (e = this.subtitleGroups) == null ? void 0 : e[0];
  }
  addFallback() {
  }
}
function ki(n, e) {
  return !e || !n ? !1 : n.indexOf(e) !== -1;
}
function ss(n, e) {
  const t = e.startPTS;
  if (M(t)) {
    let s = 0, i;
    e.sn > n.sn ? (s = t - n.start, i = n) : (s = n.start - t, i = e), i.duration !== s && (i.duration = s);
  } else e.sn > n.sn ? n.cc === e.cc && n.minEndPTS ? e.start = n.start + (n.minEndPTS - n.start) : e.start = n.start + n.duration : e.start = Math.max(n.start - e.duration, 0);
}
function Gr(n, e, t, s, i, r) {
  s - t <= 0 && (v.warn("Fragment should have a positive duration", e), s = t + e.duration, r = i + e.duration);
  let o = t, l = s;
  const c = e.startPTS, h = e.endPTS;
  if (M(c)) {
    const E = Math.abs(c - t);
    M(e.deltaPTS) ? e.deltaPTS = Math.max(E, e.deltaPTS) : e.deltaPTS = E, o = Math.max(t, c), t = Math.min(t, c), i = Math.min(i, e.startDTS), l = Math.min(s, h), s = Math.max(s, h), r = Math.max(r, e.endDTS);
  }
  const u = t - e.start;
  e.start !== 0 && (e.start = t), e.duration = s - e.start, e.startPTS = t, e.maxStartPTS = o, e.startDTS = i, e.endPTS = s, e.minEndPTS = l, e.endDTS = r;
  const d = e.sn;
  if (!n || d < n.startSN || d > n.endSN)
    return 0;
  let f;
  const g = d - n.startSN, m = n.fragments;
  for (m[g] = e, f = g; f > 0; f--)
    ss(m[f], m[f - 1]);
  for (f = g; f < m.length - 1; f++)
    ss(m[f], m[f + 1]);
  return n.fragmentHint && ss(m[m.length - 1], n.fragmentHint), n.PTSKnown = n.alignedSliding = !0, u;
}
function vo(n, e) {
  let t = null;
  const s = n.fragments;
  for (let l = s.length - 1; l >= 0; l--) {
    const c = s[l].initSegment;
    if (c) {
      t = c;
      break;
    }
  }
  n.fragmentHint && delete n.fragmentHint.endPTS;
  let i = 0, r;
  if (Ro(n, e, (l, c) => {
    l.relurl && (i = l.cc - c.cc), M(l.startPTS) && M(l.endPTS) && (c.start = c.startPTS = l.startPTS, c.startDTS = l.startDTS, c.maxStartPTS = l.maxStartPTS, c.endPTS = l.endPTS, c.endDTS = l.endDTS, c.minEndPTS = l.minEndPTS, c.duration = l.endPTS - l.startPTS, c.duration && (r = c), e.PTSKnown = e.alignedSliding = !0), c.elementaryStreams = l.elementaryStreams, c.loader = l.loader, c.stats = l.stats, l.initSegment && (c.initSegment = l.initSegment, t = l.initSegment);
  }), t && (e.fragmentHint ? e.fragments.concat(e.fragmentHint) : e.fragments).forEach((c) => {
    var h;
    c && (!c.initSegment || c.initSegment.relurl === ((h = t) == null ? void 0 : h.relurl)) && (c.initSegment = t);
  }), e.skippedSegments)
    if (e.deltaUpdateFailed = e.fragments.some((l) => !l), e.deltaUpdateFailed) {
      v.warn("[level-helper] Previous playlist missing segments skipped in delta playlist");
      for (let l = e.skippedSegments; l--; )
        e.fragments.shift();
      e.startSN = e.fragments[0].sn, e.startCC = e.fragments[0].cc;
    } else e.canSkipDateRanges && (e.dateRanges = Ao(n.dateRanges, e.dateRanges, e.recentlyRemovedDateranges));
  const a = e.fragments;
  if (i) {
    v.warn("discontinuity sliding from playlist, take drift into account");
    for (let l = 0; l < a.length; l++)
      a[l].cc += i;
  }
  e.skippedSegments && (e.startCC = e.fragments[0].cc), Lo(n.partList, e.partList, (l, c) => {
    c.elementaryStreams = l.elementaryStreams, c.stats = l.stats;
  }), r ? Gr(e, r, r.startPTS, r.endPTS, r.startDTS, r.endDTS) : $r(n, e), a.length && (e.totalduration = e.edge - a[0].start), e.driftStartTime = n.driftStartTime, e.driftStart = n.driftStart;
  const o = e.advancedDateTime;
  if (e.advanced && o) {
    const l = e.edge;
    e.driftStart || (e.driftStartTime = o, e.driftStart = l), e.driftEndTime = o, e.driftEnd = l;
  } else
    e.driftEndTime = n.driftEndTime, e.driftEnd = n.driftEnd, e.advancedDateTime = n.advancedDateTime;
}
function Ao(n, e, t) {
  const s = se({}, n);
  return t && t.forEach((i) => {
    delete s[i];
  }), Object.keys(e).forEach((i) => {
    const r = new Ar(e[i].attr, s[i]);
    r.isValid ? s[i] = r : v.warn(`Ignoring invalid Playlist Delta Update DATERANGE tag: "${JSON.stringify(e[i].attr)}"`);
  }), s;
}
function Lo(n, e, t) {
  if (n && e) {
    let s = 0;
    for (let i = 0, r = n.length; i <= r; i++) {
      const a = n[i], o = e[i + s];
      a && o && a.index === o.index && a.fragment.sn === o.fragment.sn ? t(a, o) : s--;
    }
  }
}
function Ro(n, e, t) {
  const s = e.skippedSegments, i = Math.max(n.startSN, e.startSN) - e.startSN, r = (n.fragmentHint ? 1 : 0) + (s ? e.endSN : Math.min(n.endSN, e.endSN)) - e.startSN, a = e.startSN - n.startSN, o = e.fragmentHint ? e.fragments.concat(e.fragmentHint) : e.fragments, l = n.fragmentHint ? n.fragments.concat(n.fragmentHint) : n.fragments;
  for (let c = i; c <= r; c++) {
    const h = l[a + c];
    let u = o[c];
    s && !u && c < s && (u = e.fragments[c] = h), h && u && t(h, u);
  }
}
function $r(n, e) {
  const t = e.startSN + e.skippedSegments - n.startSN, s = n.fragments;
  t < 0 || t >= s.length || Ls(e, s[t].start);
}
function Ls(n, e) {
  if (e) {
    const t = n.fragments;
    for (let s = n.skippedSegments; s < t.length; s++)
      t[s].start += e;
    n.fragmentHint && (n.fragmentHint.start += e);
  }
}
function bo(n, e = 1 / 0) {
  let t = 1e3 * n.targetduration;
  if (n.updated) {
    const s = n.fragments;
    if (s.length && t * 4 > e) {
      const r = s[s.length - 1].duration * 1e3;
      r < t && (t = r);
    }
  } else
    t /= 2;
  return Math.round(t);
}
function Io(n, e, t) {
  if (!(n != null && n.details))
    return null;
  const s = n.details;
  let i = s.fragments[e - s.startSN];
  return i || (i = s.fragmentHint, i && i.sn === e) ? i : e < s.startSN && t && t.sn === e ? t : null;
}
function wi(n, e, t) {
  var s;
  return n != null && n.details ? Kr((s = n.details) == null ? void 0 : s.partList, e, t) : null;
}
function Kr(n, e, t) {
  if (n)
    for (let s = n.length; s--; ) {
      const i = n[s];
      if (i.index === t && i.fragment.sn === e)
        return i;
    }
  return null;
}
function Vr(n) {
  n.forEach((e, t) => {
    const {
      details: s
    } = e;
    s != null && s.fragments && s.fragments.forEach((i) => {
      i.level = t;
    });
  });
}
function Mt(n) {
  switch (n.details) {
    case L.FRAG_LOAD_TIMEOUT:
    case L.KEY_LOAD_TIMEOUT:
    case L.LEVEL_LOAD_TIMEOUT:
    case L.MANIFEST_LOAD_TIMEOUT:
      return !0;
  }
  return !1;
}
function Pi(n, e) {
  const t = Mt(e);
  return n.default[`${t ? "timeout" : "error"}Retry`];
}
function $s(n, e) {
  const t = n.backoff === "linear" ? 1 : Math.pow(2, e);
  return Math.min(t * n.retryDelayMs, n.maxRetryDelayMs);
}
function Fi(n) {
  return oe(oe({}, n), {
    errorRetry: null,
    timeoutRetry: null
  });
}
function Nt(n, e, t, s) {
  if (!n)
    return !1;
  const i = s == null ? void 0 : s.code, r = e < n.maxNumRetry && (Do(i) || !!t);
  return n.shouldRetry ? n.shouldRetry(n, e, t, s, r) : r;
}
function Do(n) {
  return n === 0 && navigator.onLine === !1 || !!n && (n < 400 || n > 499);
}
const Hr = {
  /**
   * Searches for an item in an array which matches a certain condition.
   * This requires the condition to only match one item in the array,
   * and for the array to be ordered.
   *
   * @param list The array to search.
   * @param comparisonFn
   *      Called and provided a candidate item as the first argument.
   *      Should return:
   *          > -1 if the item should be located at a lower index than the provided item.
   *          > 1 if the item should be located at a higher index than the provided item.
   *          > 0 if the item is the item you're looking for.
   *
   * @returns the object if found, otherwise returns null
   */
  search: function(n, e) {
    let t = 0, s = n.length - 1, i = null, r = null;
    for (; t <= s; ) {
      i = (t + s) / 2 | 0, r = n[i];
      const a = e(r);
      if (a > 0)
        t = i + 1;
      else if (a < 0)
        s = i - 1;
      else
        return r;
    }
    return null;
  }
};
function Co(n, e, t) {
  if (e === null || !Array.isArray(n) || !n.length || !M(e))
    return null;
  const s = n[0].programDateTime;
  if (e < (s || 0))
    return null;
  const i = n[n.length - 1].endProgramDateTime;
  if (e >= (i || 0))
    return null;
  t = t || 0;
  for (let r = 0; r < n.length; ++r) {
    const a = n[r];
    if (ko(e, t, a))
      return a;
  }
  return null;
}
function Ut(n, e, t = 0, s = 0, i = 5e-3) {
  let r = null;
  if (n) {
    r = e[n.sn - e[0].sn + 1] || null;
    const o = n.endDTS - t;
    o > 0 && o < 15e-7 && (t += 15e-7);
  } else t === 0 && e[0].start === 0 && (r = e[0]);
  if (r && ((!n || n.level === r.level) && Rs(t, s, r) === 0 || _o(r, n, Math.min(i, s))))
    return r;
  const a = Hr.search(e, Rs.bind(null, t, s));
  return a && (a !== n || !r) ? a : r;
}
function _o(n, e, t) {
  if (e && e.start === 0 && e.level < n.level && (e.endPTS || 0) > 0) {
    const s = e.tagList.reduce((i, r) => (r[0] === "INF" && (i += parseFloat(r[1])), i), t);
    return n.start <= s;
  }
  return !1;
}
function Rs(n = 0, e = 0, t) {
  if (t.start <= n && t.start + t.duration > n)
    return 0;
  const s = Math.min(e, t.duration + (t.deltaPTS ? t.deltaPTS : 0));
  return t.start + t.duration - s <= n ? 1 : t.start - s > n && t.start ? -1 : 0;
}
function ko(n, e, t) {
  const s = Math.min(e, t.duration + (t.deltaPTS ? t.deltaPTS : 0)) * 1e3;
  return (t.endProgramDateTime || 0) - s > n;
}
function wo(n, e) {
  return Hr.search(n, (t) => t.cc < e ? 1 : t.cc > e ? -1 : 0);
}
var ce = {
  DoNothing: 0,
  SendEndCallback: 1,
  SendAlternateToPenaltyBox: 2,
  RemoveAlternatePermanently: 3,
  InsertDiscontinuity: 4,
  RetryRequest: 5
}, ye = {
  None: 0,
  MoveAllAlternatesMatchingHost: 1,
  MoveAllAlternatesMatchingHDCP: 2,
  SwitchToSDR: 4
};
class Po {
  constructor(e) {
    this.hls = void 0, this.playlistError = 0, this.penalizedRenditions = {}, this.log = void 0, this.warn = void 0, this.error = void 0, this.hls = e, this.log = v.log.bind(v, "[info]:"), this.warn = v.warn.bind(v, "[warning]:"), this.error = v.error.bind(v, "[error]:"), this.registerListeners();
  }
  registerListeners() {
    const e = this.hls;
    e.on(p.ERROR, this.onError, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.LEVEL_UPDATED, this.onLevelUpdated, this);
  }
  unregisterListeners() {
    const e = this.hls;
    e && (e.off(p.ERROR, this.onError, this), e.off(p.ERROR, this.onErrorOut, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.LEVEL_UPDATED, this.onLevelUpdated, this));
  }
  destroy() {
    this.unregisterListeners(), this.hls = null, this.penalizedRenditions = {};
  }
  startLoad(e) {
  }
  stopLoad() {
    this.playlistError = 0;
  }
  getVariantLevelIndex(e) {
    return (e == null ? void 0 : e.type) === G.MAIN ? e.level : this.hls.loadLevel;
  }
  onManifestLoading() {
    this.playlistError = 0, this.penalizedRenditions = {};
  }
  onLevelUpdated() {
    this.playlistError = 0;
  }
  onError(e, t) {
    var s, i;
    if (t.fatal)
      return;
    const r = this.hls, a = t.context;
    switch (t.details) {
      case L.FRAG_LOAD_ERROR:
      case L.FRAG_LOAD_TIMEOUT:
      case L.KEY_LOAD_ERROR:
      case L.KEY_LOAD_TIMEOUT:
        t.errorAction = this.getFragRetryOrSwitchAction(t);
        return;
      case L.FRAG_PARSING_ERROR:
        if ((s = t.frag) != null && s.gap) {
          t.errorAction = {
            action: ce.DoNothing,
            flags: ye.None
          };
          return;
        }
      case L.FRAG_GAP:
      case L.FRAG_DECRYPT_ERROR: {
        t.errorAction = this.getFragRetryOrSwitchAction(t), t.errorAction.action = ce.SendAlternateToPenaltyBox;
        return;
      }
      case L.LEVEL_EMPTY_ERROR:
      case L.LEVEL_PARSING_ERROR:
        {
          var o, l;
          const c = t.parent === G.MAIN ? t.level : r.loadLevel;
          t.details === L.LEVEL_EMPTY_ERROR && ((o = t.context) != null && (l = o.levelDetails) != null && l.live) ? t.errorAction = this.getPlaylistRetryOrSwitchAction(t, c) : (t.levelRetry = !1, t.errorAction = this.getLevelSwitchAction(t, c));
        }
        return;
      case L.LEVEL_LOAD_ERROR:
      case L.LEVEL_LOAD_TIMEOUT:
        typeof (a == null ? void 0 : a.level) == "number" && (t.errorAction = this.getPlaylistRetryOrSwitchAction(t, a.level));
        return;
      case L.AUDIO_TRACK_LOAD_ERROR:
      case L.AUDIO_TRACK_LOAD_TIMEOUT:
      case L.SUBTITLE_LOAD_ERROR:
      case L.SUBTITLE_TRACK_LOAD_TIMEOUT:
        if (a) {
          const c = r.levels[r.loadLevel];
          if (c && (a.type === q.AUDIO_TRACK && c.hasAudioGroup(a.groupId) || a.type === q.SUBTITLE_TRACK && c.hasSubtitleGroup(a.groupId))) {
            t.errorAction = this.getPlaylistRetryOrSwitchAction(t, r.loadLevel), t.errorAction.action = ce.SendAlternateToPenaltyBox, t.errorAction.flags = ye.MoveAllAlternatesMatchingHost;
            return;
          }
        }
        return;
      case L.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED:
        {
          const c = r.levels[r.loadLevel], h = c == null ? void 0 : c.attrs["HDCP-LEVEL"];
          h ? t.errorAction = {
            action: ce.SendAlternateToPenaltyBox,
            flags: ye.MoveAllAlternatesMatchingHDCP,
            hdcpLevel: h
          } : this.keySystemError(t);
        }
        return;
      case L.BUFFER_ADD_CODEC_ERROR:
      case L.REMUX_ALLOC_ERROR:
      case L.BUFFER_APPEND_ERROR:
        t.errorAction = this.getLevelSwitchAction(t, (i = t.level) != null ? i : r.loadLevel);
        return;
      case L.INTERNAL_EXCEPTION:
      case L.BUFFER_APPENDING_ERROR:
      case L.BUFFER_FULL_ERROR:
      case L.LEVEL_SWITCH_ERROR:
      case L.BUFFER_STALLED_ERROR:
      case L.BUFFER_SEEK_OVER_HOLE:
      case L.BUFFER_NUDGE_ON_STALL:
        t.errorAction = {
          action: ce.DoNothing,
          flags: ye.None
        };
        return;
    }
    t.type === K.KEY_SYSTEM_ERROR && this.keySystemError(t);
  }
  keySystemError(e) {
    const t = this.getVariantLevelIndex(e.frag);
    e.levelRetry = !1, e.errorAction = this.getLevelSwitchAction(e, t);
  }
  getPlaylistRetryOrSwitchAction(e, t) {
    const s = this.hls, i = Pi(s.config.playlistLoadPolicy, e), r = this.playlistError++;
    if (Nt(i, r, Mt(e), e.response))
      return {
        action: ce.RetryRequest,
        flags: ye.None,
        retryConfig: i,
        retryCount: r
      };
    const o = this.getLevelSwitchAction(e, t);
    return i && (o.retryConfig = i, o.retryCount = r), o;
  }
  getFragRetryOrSwitchAction(e) {
    const t = this.hls, s = this.getVariantLevelIndex(e.frag), i = t.levels[s], {
      fragLoadPolicy: r,
      keyLoadPolicy: a
    } = t.config, o = Pi(e.details.startsWith("key") ? a : r, e), l = t.levels.reduce((h, u) => h + u.fragmentError, 0);
    if (i && (e.details !== L.FRAG_GAP && i.fragmentError++, Nt(o, l, Mt(e), e.response)))
      return {
        action: ce.RetryRequest,
        flags: ye.None,
        retryConfig: o,
        retryCount: l
      };
    const c = this.getLevelSwitchAction(e, s);
    return o && (c.retryConfig = o, c.retryCount = l), c;
  }
  getLevelSwitchAction(e, t) {
    const s = this.hls;
    t == null && (t = s.loadLevel);
    const i = this.hls.levels[t];
    if (i) {
      var r, a;
      const c = e.details;
      i.loadError++, c === L.BUFFER_APPEND_ERROR && i.fragmentError++;
      let h = -1;
      const {
        levels: u,
        loadLevel: d,
        minAutoLevel: f,
        maxAutoLevel: g
      } = s;
      s.autoLevelEnabled || (s.loadLevel = -1);
      const m = (r = e.frag) == null ? void 0 : r.type, T = (m === G.AUDIO && c === L.FRAG_PARSING_ERROR || e.sourceBufferName === "audio" && (c === L.BUFFER_ADD_CODEC_ERROR || c === L.BUFFER_APPEND_ERROR)) && u.some(({
        audioCodec: D
      }) => i.audioCodec !== D), x = e.sourceBufferName === "video" && (c === L.BUFFER_ADD_CODEC_ERROR || c === L.BUFFER_APPEND_ERROR) && u.some(({
        codecSet: D,
        audioCodec: R
      }) => i.codecSet !== D && i.audioCodec === R), {
        type: b,
        groupId: S
      } = (a = e.context) != null ? a : {};
      for (let D = u.length; D--; ) {
        const R = (D + d) % u.length;
        if (R !== d && R >= f && R <= g && u[R].loadError === 0) {
          var o, l;
          const _ = u[R];
          if (c === L.FRAG_GAP && m === G.MAIN && e.frag) {
            const P = u[R].details;
            if (P) {
              const I = Ut(e.frag, P.fragments, e.frag.start);
              if (I != null && I.gap)
                continue;
            }
          } else {
            if (b === q.AUDIO_TRACK && _.hasAudioGroup(S) || b === q.SUBTITLE_TRACK && _.hasSubtitleGroup(S))
              continue;
            if (m === G.AUDIO && (o = i.audioGroups) != null && o.some((P) => _.hasAudioGroup(P)) || m === G.SUBTITLE && (l = i.subtitleGroups) != null && l.some((P) => _.hasSubtitleGroup(P)) || T && i.audioCodec === _.audioCodec || !T && i.audioCodec !== _.audioCodec || x && i.codecSet === _.codecSet)
              continue;
          }
          h = R;
          break;
        }
      }
      if (h > -1 && s.loadLevel !== h)
        return e.levelRetry = !0, this.playlistError = 0, {
          action: ce.SendAlternateToPenaltyBox,
          flags: ye.None,
          nextAutoLevel: h
        };
    }
    return {
      action: ce.SendAlternateToPenaltyBox,
      flags: ye.MoveAllAlternatesMatchingHost
    };
  }
  onErrorOut(e, t) {
    var s;
    switch ((s = t.errorAction) == null ? void 0 : s.action) {
      case ce.DoNothing:
        break;
      case ce.SendAlternateToPenaltyBox:
        this.sendAlternateToPenaltyBox(t), !t.errorAction.resolved && t.details !== L.FRAG_GAP ? t.fatal = !0 : /MediaSource readyState: ended/.test(t.error.message) && (this.warn(`MediaSource ended after "${t.sourceBufferName}" sourceBuffer append error. Attempting to recover from media error.`), this.hls.recoverMediaError());
        break;
    }
    if (t.fatal) {
      this.hls.stopLoad();
      return;
    }
  }
  sendAlternateToPenaltyBox(e) {
    const t = this.hls, s = e.errorAction;
    if (!s)
      return;
    const {
      flags: i,
      hdcpLevel: r,
      nextAutoLevel: a
    } = s;
    switch (i) {
      case ye.None:
        this.switchLevel(e, a);
        break;
      case ye.MoveAllAlternatesMatchingHDCP:
        r && (t.maxHdcpLevel = As[As.indexOf(r) - 1], s.resolved = !0), this.warn(`Restricting playback to HDCP-LEVEL of "${t.maxHdcpLevel}" or lower`);
        break;
    }
    s.resolved || this.switchLevel(e, a);
  }
  switchLevel(e, t) {
    t !== void 0 && e.errorAction && (this.warn(`switching to level ${t} after ${e.details}`), this.hls.nextAutoLevel = t, e.errorAction.resolved = !0, this.hls.nextLoadLevel = this.hls.nextAutoLevel);
  }
}
class Ks {
  constructor(e, t) {
    this.hls = void 0, this.timer = -1, this.requestScheduled = -1, this.canLoad = !1, this.log = void 0, this.warn = void 0, this.log = v.log.bind(v, `${t}:`), this.warn = v.warn.bind(v, `${t}:`), this.hls = e;
  }
  destroy() {
    this.clearTimer(), this.hls = this.log = this.warn = null;
  }
  clearTimer() {
    this.timer !== -1 && (self.clearTimeout(this.timer), this.timer = -1);
  }
  startLoad() {
    this.canLoad = !0, this.requestScheduled = -1, this.loadPlaylist();
  }
  stopLoad() {
    this.canLoad = !1, this.clearTimer();
  }
  switchParams(e, t, s) {
    const i = t == null ? void 0 : t.renditionReports;
    if (i) {
      let r = -1;
      for (let a = 0; a < i.length; a++) {
        const o = i[a];
        let l;
        try {
          l = new self.URL(o.URI, t.url).href;
        } catch (c) {
          v.warn(`Could not construct new URL for Rendition Report: ${c}`), l = o.URI || "";
        }
        if (l === e) {
          r = a;
          break;
        } else l === e.substring(0, l.length) && (r = a);
      }
      if (r !== -1) {
        const a = i[r], o = parseInt(a["LAST-MSN"]) || (t == null ? void 0 : t.lastPartSn);
        let l = parseInt(a["LAST-PART"]) || (t == null ? void 0 : t.lastPartIndex);
        if (this.hls.config.lowLatencyMode) {
          const h = Math.min(t.age - t.partTarget, t.targetduration);
          l >= 0 && h > t.partTarget && (l += 1);
        }
        const c = s && Ci(s);
        return new _i(o, l >= 0 ? l : void 0, c);
      }
    }
  }
  loadPlaylist(e) {
    this.requestScheduled === -1 && (this.requestScheduled = self.performance.now());
  }
  shouldLoadPlaylist(e) {
    return this.canLoad && !!e && !!e.url && (!e.details || e.details.live);
  }
  shouldReloadPlaylist(e) {
    return this.timer === -1 && this.requestScheduled === -1 && this.shouldLoadPlaylist(e);
  }
  playlistLoaded(e, t, s) {
    const {
      details: i,
      stats: r
    } = t, a = self.performance.now(), o = r.loading.first ? Math.max(0, a - r.loading.first) : 0;
    if (i.advancedDateTime = Date.now() - o, i.live || s != null && s.live) {
      if (i.reloaded(s), s && this.log(`live playlist ${e} ${i.advanced ? "REFRESHED " + i.lastPartSn + "-" + i.lastPartIndex : i.updated ? "UPDATED" : "MISSED"}`), s && i.fragments.length > 0 && vo(s, i), !this.canLoad || !i.live)
        return;
      let l, c, h;
      if (i.canBlockReload && i.endSN && i.advanced) {
        const E = this.hls.config.lowLatencyMode, T = i.lastPartSn, y = i.endSN, x = i.lastPartIndex, b = x !== -1, S = T === y, D = E ? 0 : x;
        b ? (c = S ? y + 1 : T, h = S ? D : x + 1) : c = y + 1;
        const R = i.age, _ = R + i.ageHeader;
        let P = Math.min(_ - i.partTarget, i.targetduration * 1.5);
        if (P > 0) {
          if (s && P > s.tuneInGoal)
            this.warn(`CDN Tune-in goal increased from: ${s.tuneInGoal} to: ${P} with playlist age: ${i.age}`), P = 0;
          else {
            const I = Math.floor(P / i.targetduration);
            if (c += I, h !== void 0) {
              const k = Math.round(P % i.targetduration / i.partTarget);
              h += k;
            }
            this.log(`CDN Tune-in age: ${i.ageHeader}s last advanced ${R.toFixed(2)}s goal: ${P} skip sn ${I} to part ${h}`);
          }
          i.tuneInGoal = P;
        }
        if (l = this.getDeliveryDirectives(i, t.deliveryDirectives, c, h), E || !S) {
          this.loadPlaylist(l);
          return;
        }
      } else (i.canBlockReload || i.canSkipUntil) && (l = this.getDeliveryDirectives(i, t.deliveryDirectives, c, h));
      const u = this.hls.mainForwardBufferInfo, d = u ? u.end - u.len : 0, f = (i.edge - d) * 1e3, g = bo(i, f);
      i.updated && a > this.requestScheduled + g && (this.requestScheduled = r.loading.start), c !== void 0 && i.canBlockReload ? this.requestScheduled = r.loading.first + g - (i.partTarget * 1e3 || 1e3) : this.requestScheduled === -1 || this.requestScheduled + g < a ? this.requestScheduled = a : this.requestScheduled - a <= 0 && (this.requestScheduled += g);
      let m = this.requestScheduled - a;
      m = Math.max(0, m), this.log(`reload live playlist ${e} in ${Math.round(m)} ms`), this.timer = self.setTimeout(() => this.loadPlaylist(l), m);
    } else
      this.clearTimer();
  }
  getDeliveryDirectives(e, t, s, i) {
    let r = Ci(e);
    return t != null && t.skip && e.deltaUpdateFailed && (s = t.msn, i = t.part, r = Lt.No), new _i(s, i, r);
  }
  checkRetry(e) {
    const t = e.details, s = Mt(e), i = e.errorAction, {
      action: r,
      retryCount: a = 0,
      retryConfig: o
    } = i || {}, l = !!i && !!o && (r === ce.RetryRequest || !i.resolved && r === ce.SendAlternateToPenaltyBox);
    if (l) {
      var c;
      if (this.requestScheduled = -1, a >= o.maxNumRetry)
        return !1;
      if (s && (c = e.context) != null && c.deliveryDirectives)
        this.warn(`Retrying playlist loading ${a + 1}/${o.maxNumRetry} after "${t}" without delivery-directives`), this.loadPlaylist();
      else {
        const h = $s(o, a);
        this.timer = self.setTimeout(() => this.loadPlaylist(), h), this.warn(`Retrying playlist loading ${a + 1}/${o.maxNumRetry} after "${t}" in ${h}ms`);
      }
      e.levelRetry = !0, i.resolved = !0;
    }
    return l;
  }
}
class He {
  //  About half of the estimated value will be from the last |halfLife| samples by weight.
  constructor(e, t = 0, s = 0) {
    this.halfLife = void 0, this.alpha_ = void 0, this.estimate_ = void 0, this.totalWeight_ = void 0, this.halfLife = e, this.alpha_ = e ? Math.exp(Math.log(0.5) / e) : 0, this.estimate_ = t, this.totalWeight_ = s;
  }
  sample(e, t) {
    const s = Math.pow(this.alpha_, e);
    this.estimate_ = t * (1 - s) + s * this.estimate_, this.totalWeight_ += e;
  }
  getTotalWeight() {
    return this.totalWeight_;
  }
  getEstimate() {
    if (this.alpha_) {
      const e = 1 - Math.pow(this.alpha_, this.totalWeight_);
      if (e)
        return this.estimate_ / e;
    }
    return this.estimate_;
  }
}
class Fo {
  constructor(e, t, s, i = 100) {
    this.defaultEstimate_ = void 0, this.minWeight_ = void 0, this.minDelayMs_ = void 0, this.slow_ = void 0, this.fast_ = void 0, this.defaultTTFB_ = void 0, this.ttfb_ = void 0, this.defaultEstimate_ = s, this.minWeight_ = 1e-3, this.minDelayMs_ = 50, this.slow_ = new He(e), this.fast_ = new He(t), this.defaultTTFB_ = i, this.ttfb_ = new He(e);
  }
  update(e, t) {
    const {
      slow_: s,
      fast_: i,
      ttfb_: r
    } = this;
    s.halfLife !== e && (this.slow_ = new He(e, s.getEstimate(), s.getTotalWeight())), i.halfLife !== t && (this.fast_ = new He(t, i.getEstimate(), i.getTotalWeight())), r.halfLife !== e && (this.ttfb_ = new He(e, r.getEstimate(), r.getTotalWeight()));
  }
  sample(e, t) {
    e = Math.max(e, this.minDelayMs_);
    const s = 8 * t, i = e / 1e3, r = s / i;
    this.fast_.sample(i, r), this.slow_.sample(i, r);
  }
  sampleTTFB(e) {
    const t = e / 1e3, s = Math.sqrt(2) * Math.exp(-Math.pow(t, 2) / 2);
    this.ttfb_.sample(s, Math.max(e, 5));
  }
  canEstimate() {
    return this.fast_.getTotalWeight() >= this.minWeight_;
  }
  getEstimate() {
    return this.canEstimate() ? Math.min(this.fast_.getEstimate(), this.slow_.getEstimate()) : this.defaultEstimate_;
  }
  getEstimateTTFB() {
    return this.ttfb_.getTotalWeight() >= this.minWeight_ ? this.ttfb_.getEstimate() : this.defaultTTFB_;
  }
  destroy() {
  }
}
const Wr = {
  supported: !0,
  configurations: [],
  decodingInfoResults: [{
    supported: !0,
    powerEfficient: !0,
    smooth: !0
  }]
}, Oi = {};
function Oo(n, e, t, s, i, r) {
  const a = n.audioCodec ? n.audioGroups : null, o = r == null ? void 0 : r.audioCodec, l = r == null ? void 0 : r.channels, c = l ? parseInt(l) : o ? 1 / 0 : 2;
  let h = null;
  if (a != null && a.length)
    try {
      a.length === 1 && a[0] ? h = e.groups[a[0]].channels : h = a.reduce((u, d) => {
        if (d) {
          const f = e.groups[d];
          if (!f)
            throw new Error(`Audio track group ${d} not found`);
          Object.keys(f.channels).forEach((g) => {
            u[g] = (u[g] || 0) + f.channels[g];
          });
        }
        return u;
      }, {
        2: 0
      });
    } catch {
      return !0;
    }
  return n.videoCodec !== void 0 && (n.width > 1920 && n.height > 1088 || n.height > 1920 && n.width > 1088 || n.frameRate > Math.max(s, 30) || n.videoRange !== "SDR" && n.videoRange !== t || n.bitrate > Math.max(i, 8e6)) || !!h && M(c) && Object.keys(h).some((u) => parseInt(u) > c);
}
function Mo(n, e, t) {
  const s = n.videoCodec, i = n.audioCodec;
  if (!s || !i || !t)
    return Promise.resolve(Wr);
  const r = {
    width: n.width,
    height: n.height,
    bitrate: Math.ceil(Math.max(n.bitrate * 0.9, n.averageBitrate)),
    // Assume a framerate of 30fps since MediaCapabilities will not accept Level default of 0.
    framerate: n.frameRate || 30
  }, a = n.videoRange;
  a !== "SDR" && (r.transferFunction = a.toLowerCase());
  const o = s.split(",").map((l) => ({
    type: "media-source",
    video: oe(oe({}, r), {}, {
      contentType: ct(l, "video")
    })
  }));
  return i && n.audioGroups && n.audioGroups.forEach((l) => {
    var c;
    l && ((c = e.groups[l]) == null || c.tracks.forEach((h) => {
      if (h.groupId === l) {
        const u = h.channels || "", d = parseFloat(u);
        M(d) && d > 2 && o.push.apply(o, i.split(",").map((f) => ({
          type: "media-source",
          audio: {
            contentType: ct(f, "audio"),
            channels: "" + d
            // spatialRendering:
            //   audioCodec === 'ec-3' && channels.indexOf('JOC'),
          }
        })));
      }
    }));
  }), Promise.all(o.map((l) => {
    const c = No(l);
    return Oi[c] || (Oi[c] = t.decodingInfo(l));
  })).then((l) => ({
    supported: !l.some((c) => !c.supported),
    configurations: o,
    decodingInfoResults: l
  })).catch((l) => ({
    supported: !1,
    configurations: o,
    decodingInfoResults: [],
    error: l
  }));
}
function No(n) {
  const {
    audio: e,
    video: t
  } = n, s = t || e;
  if (s) {
    const i = s.contentType.split('"')[1];
    if (t)
      return `r${t.height}x${t.width}f${Math.ceil(t.framerate)}${t.transferFunction || "sd"}_${i}_${Math.ceil(t.bitrate / 1e5)}`;
    if (e)
      return `c${e.channels}${e.spatialRendering ? "s" : "n"}_${i}`;
  }
  return "";
}
function Uo() {
  if (typeof matchMedia == "function") {
    const n = matchMedia("(dynamic-range: high)"), e = matchMedia("bad query");
    if (n.media !== e.media)
      return n.matches === !0;
  }
  return !1;
}
function Bo(n, e) {
  let t = !1, s = [];
  return n && (t = n !== "SDR", s = [n]), e && (s = e.allowedVideoRanges || Ot.slice(0), t = e.preferHDR !== void 0 ? e.preferHDR : Uo(), t ? s = s.filter((i) => i !== "SDR") : s = ["SDR"]), {
    preferHDR: t,
    allowedVideoRanges: s
  };
}
function Go(n, e, t, s, i) {
  const r = Object.keys(n), a = s == null ? void 0 : s.channels, o = s == null ? void 0 : s.audioCodec, l = a && parseInt(a) === 2;
  let c = !0, h = !1, u = 1 / 0, d = 1 / 0, f = 1 / 0, g = 0, m = [];
  const {
    preferHDR: E,
    allowedVideoRanges: T
  } = Bo(e, i);
  for (let S = r.length; S--; ) {
    const D = n[r[S]];
    c = D.channels[2] > 0, u = Math.min(u, D.minHeight), d = Math.min(d, D.minFramerate), f = Math.min(f, D.minBitrate);
    const R = T.filter((_) => D.videoRanges[_] > 0);
    R.length > 0 && (h = !0, m = R);
  }
  u = M(u) ? u : 0, d = M(d) ? d : 0;
  const y = Math.max(1080, u), x = Math.max(30, d);
  return f = M(f) ? f : t, t = Math.max(f, t), h || (e = void 0, m = []), {
    codecSet: r.reduce((S, D) => {
      const R = n[D];
      if (D === S)
        return S;
      if (R.minBitrate > t)
        return Ce(D, `min bitrate of ${R.minBitrate} > current estimate of ${t}`), S;
      if (!R.hasDefaultAudio)
        return Ce(D, "no renditions with default or auto-select sound found"), S;
      if (o && D.indexOf(o.substring(0, 4)) % 5 !== 0)
        return Ce(D, `audio codec preference "${o}" not found`), S;
      if (a && !l) {
        if (!R.channels[a])
          return Ce(D, `no renditions with ${a} channel sound found (channels options: ${Object.keys(R.channels)})`), S;
      } else if ((!o || l) && c && R.channels[2] === 0)
        return Ce(D, "no renditions with stereo sound found"), S;
      return R.minHeight > y ? (Ce(D, `min resolution of ${R.minHeight} > maximum of ${y}`), S) : R.minFramerate > x ? (Ce(D, `min framerate of ${R.minFramerate} > maximum of ${x}`), S) : m.some((_) => R.videoRanges[_] > 0) ? R.maxScore < g ? (Ce(D, `max score of ${R.maxScore} < selected max of ${g}`), S) : S && (Pt(D) >= Pt(S) || R.fragmentError > n[S].fragmentError) ? S : (g = R.maxScore, D) : (Ce(D, `no variants with VIDEO-RANGE of ${JSON.stringify(m)} found`), S);
    }, void 0),
    videoRanges: m,
    preferHDR: E,
    minFramerate: d,
    minBitrate: f
  };
}
function Ce(n, e) {
  v.log(`[abr] start candidates with "${n}" ignored because ${e}`);
}
function $o(n) {
  return n.reduce((e, t) => {
    let s = e.groups[t.groupId];
    s || (s = e.groups[t.groupId] = {
      tracks: [],
      channels: {
        2: 0
      },
      hasDefault: !1,
      hasAutoSelect: !1
    }), s.tracks.push(t);
    const i = t.channels || "2";
    return s.channels[i] = (s.channels[i] || 0) + 1, s.hasDefault = s.hasDefault || t.default, s.hasAutoSelect = s.hasAutoSelect || t.autoselect, s.hasDefault && (e.hasDefaultAudio = !0), s.hasAutoSelect && (e.hasAutoSelectAudio = !0), e;
  }, {
    hasDefaultAudio: !1,
    hasAutoSelectAudio: !1,
    groups: {}
  });
}
function Ko(n, e, t, s) {
  return n.slice(t, s + 1).reduce((i, r) => {
    if (!r.codecSet)
      return i;
    const a = r.audioGroups;
    let o = i[r.codecSet];
    o || (i[r.codecSet] = o = {
      minBitrate: 1 / 0,
      minHeight: 1 / 0,
      minFramerate: 1 / 0,
      maxScore: 0,
      videoRanges: {
        SDR: 0
      },
      channels: {
        2: 0
      },
      hasDefaultAudio: !a,
      fragmentError: 0
    }), o.minBitrate = Math.min(o.minBitrate, r.bitrate);
    const l = Math.min(r.height, r.width);
    return o.minHeight = Math.min(o.minHeight, l), o.minFramerate = Math.min(o.minFramerate, r.frameRate), o.maxScore = Math.max(o.maxScore, r.score), o.fragmentError += r.fragmentError, o.videoRanges[r.videoRange] = (o.videoRanges[r.videoRange] || 0) + 1, a && a.forEach((c) => {
      if (!c)
        return;
      const h = e.groups[c];
      h && (o.hasDefaultAudio = o.hasDefaultAudio || e.hasDefaultAudio ? h.hasDefault : h.hasAutoSelect || !e.hasDefaultAudio && !e.hasAutoSelectAudio, Object.keys(h.channels).forEach((u) => {
        o.channels[u] = (o.channels[u] || 0) + h.channels[u];
      }));
    }), i;
  }, {});
}
function be(n, e, t) {
  if ("attrs" in n) {
    const s = e.indexOf(n);
    if (s !== -1)
      return s;
  }
  for (let s = 0; s < e.length; s++) {
    const i = e[s];
    if (Xe(n, i, t))
      return s;
  }
  return -1;
}
function Xe(n, e, t) {
  const {
    groupId: s,
    name: i,
    lang: r,
    assocLang: a,
    characteristics: o,
    default: l
  } = n, c = n.forced;
  return (s === void 0 || e.groupId === s) && (i === void 0 || e.name === i) && (r === void 0 || e.lang === r) && (r === void 0 || e.assocLang === a) && (l === void 0 || e.default === l) && (c === void 0 || e.forced === c) && (o === void 0 || Vo(o, e.characteristics)) && (t === void 0 || t(n, e));
}
function Vo(n, e = "") {
  const t = n.split(","), s = e.split(",");
  return t.length === s.length && !t.some((i) => s.indexOf(i) === -1);
}
function We(n, e) {
  const {
    audioCodec: t,
    channels: s
  } = n;
  return (t === void 0 || (e.audioCodec || "").substring(0, 4) === t.substring(0, 4)) && (s === void 0 || s === (e.channels || "2"));
}
function Ho(n, e, t, s, i) {
  const r = e[s], o = e.reduce((d, f, g) => {
    const m = f.uri;
    return (d[m] || (d[m] = [])).push(g), d;
  }, {})[r.uri];
  o.length > 1 && (s = Math.max.apply(Math, o));
  const l = r.videoRange, c = r.frameRate, h = r.codecSet.substring(0, 4), u = Mi(e, s, (d) => {
    if (d.videoRange !== l || d.frameRate !== c || d.codecSet.substring(0, 4) !== h)
      return !1;
    const f = d.audioGroups, g = t.filter((m) => !f || f.indexOf(m.groupId) !== -1);
    return be(n, g, i) > -1;
  });
  return u > -1 ? u : Mi(e, s, (d) => {
    const f = d.audioGroups, g = t.filter((m) => !f || f.indexOf(m.groupId) !== -1);
    return be(n, g, i) > -1;
  });
}
function Mi(n, e, t) {
  for (let s = e; s > -1; s--)
    if (t(n[s]))
      return s;
  for (let s = e + 1; s < n.length; s++)
    if (t(n[s]))
      return s;
  return -1;
}
class Wo {
  constructor(e) {
    this.hls = void 0, this.lastLevelLoadSec = 0, this.lastLoadedFragLevel = -1, this.firstSelection = -1, this._nextAutoLevel = -1, this.nextAutoLevelKey = "", this.audioTracksByGroup = null, this.codecTiers = null, this.timer = -1, this.fragCurrent = null, this.partCurrent = null, this.bitrateTestDelay = 0, this.bwEstimator = void 0, this._abandonRulesCheck = () => {
      const {
        fragCurrent: t,
        partCurrent: s,
        hls: i
      } = this, {
        autoLevelEnabled: r,
        media: a
      } = i;
      if (!t || !a)
        return;
      const o = performance.now(), l = s ? s.stats : t.stats, c = s ? s.duration : t.duration, h = o - l.loading.start, u = i.minAutoLevel;
      if (l.aborted || l.loaded && l.loaded === l.total || t.level <= u) {
        this.clearTimer(), this._nextAutoLevel = -1;
        return;
      }
      if (!r || a.paused || !a.playbackRate || !a.readyState)
        return;
      const d = i.mainForwardBufferInfo;
      if (d === null)
        return;
      const f = this.bwEstimator.getEstimateTTFB(), g = Math.abs(a.playbackRate);
      if (h <= Math.max(f, 1e3 * (c / (g * 2))))
        return;
      const m = d.len / g, E = l.loading.first ? l.loading.first - l.loading.start : -1, T = l.loaded && E > -1, y = this.getBwEstimate(), x = i.levels, b = x[t.level], S = l.total || Math.max(l.loaded, Math.round(c * b.averageBitrate / 8));
      let D = T ? h - E : h;
      D < 1 && T && (D = Math.min(h, l.loaded * 8 / y));
      const R = T ? l.loaded * 1e3 / D : 0, _ = R ? (S - l.loaded) / R : S * 8 / y + f / 1e3;
      if (_ <= m)
        return;
      const P = R ? R * 8 : y;
      let I = Number.POSITIVE_INFINITY, k;
      for (k = t.level - 1; k > u; k--) {
        const F = x[k].maxBitrate;
        if (I = this.getTimeToLoadFrag(f / 1e3, P, c * F, !x[k].details), I < m)
          break;
      }
      if (I >= _ || I > c * 10)
        return;
      i.nextLoadLevel = i.nextAutoLevel = k, T ? this.bwEstimator.sample(h - Math.min(f, E), l.loaded) : this.bwEstimator.sampleTTFB(h);
      const V = x[k].maxBitrate;
      this.getBwEstimate() * this.hls.config.abrBandWidthUpFactor > V && this.resetEstimator(V), this.clearTimer(), v.warn(`[abr] Fragment ${t.sn}${s ? " part " + s.index : ""} of level ${t.level} is loading too slowly;
      Time to underbuffer: ${m.toFixed(3)} s
      Estimated load time for current fragment: ${_.toFixed(3)} s
      Estimated load time for down switch fragment: ${I.toFixed(3)} s
      TTFB estimate: ${E | 0} ms
      Current BW estimate: ${M(y) ? y | 0 : "Unknown"} bps
      New BW estimate: ${this.getBwEstimate() | 0} bps
      Switching to level ${k} @ ${V | 0} bps`), i.trigger(p.FRAG_LOAD_EMERGENCY_ABORTED, {
        frag: t,
        part: s,
        stats: l
      });
    }, this.hls = e, this.bwEstimator = this.initEstimator(), this.registerListeners();
  }
  resetEstimator(e) {
    e && (v.log(`setting initial bwe to ${e}`), this.hls.config.abrEwmaDefaultEstimate = e), this.firstSelection = -1, this.bwEstimator = this.initEstimator();
  }
  initEstimator() {
    const e = this.hls.config;
    return new Fo(e.abrEwmaSlowVoD, e.abrEwmaFastVoD, e.abrEwmaDefaultEstimate);
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.FRAG_LOADING, this.onFragLoading, this), e.on(p.FRAG_LOADED, this.onFragLoaded, this), e.on(p.FRAG_BUFFERED, this.onFragBuffered, this), e.on(p.LEVEL_SWITCHING, this.onLevelSwitching, this), e.on(p.LEVEL_LOADED, this.onLevelLoaded, this), e.on(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(p.MAX_AUTO_LEVEL_UPDATED, this.onMaxAutoLevelUpdated, this), e.on(p.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e && (e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.FRAG_LOADING, this.onFragLoading, this), e.off(p.FRAG_LOADED, this.onFragLoaded, this), e.off(p.FRAG_BUFFERED, this.onFragBuffered, this), e.off(p.LEVEL_SWITCHING, this.onLevelSwitching, this), e.off(p.LEVEL_LOADED, this.onLevelLoaded, this), e.off(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(p.MAX_AUTO_LEVEL_UPDATED, this.onMaxAutoLevelUpdated, this), e.off(p.ERROR, this.onError, this));
  }
  destroy() {
    this.unregisterListeners(), this.clearTimer(), this.hls = this._abandonRulesCheck = null, this.fragCurrent = this.partCurrent = null;
  }
  onManifestLoading(e, t) {
    this.lastLoadedFragLevel = -1, this.firstSelection = -1, this.lastLevelLoadSec = 0, this.fragCurrent = this.partCurrent = null, this.onLevelsUpdated(), this.clearTimer();
  }
  onLevelsUpdated() {
    this.lastLoadedFragLevel > -1 && this.fragCurrent && (this.lastLoadedFragLevel = this.fragCurrent.level), this._nextAutoLevel = -1, this.onMaxAutoLevelUpdated(), this.codecTiers = null, this.audioTracksByGroup = null;
  }
  onMaxAutoLevelUpdated() {
    this.firstSelection = -1, this.nextAutoLevelKey = "";
  }
  onFragLoading(e, t) {
    const s = t.frag;
    if (!this.ignoreFragment(s)) {
      if (!s.bitrateTest) {
        var i;
        this.fragCurrent = s, this.partCurrent = (i = t.part) != null ? i : null;
      }
      this.clearTimer(), this.timer = self.setInterval(this._abandonRulesCheck, 100);
    }
  }
  onLevelSwitching(e, t) {
    this.clearTimer();
  }
  onError(e, t) {
    if (!t.fatal)
      switch (t.details) {
        case L.BUFFER_ADD_CODEC_ERROR:
        case L.BUFFER_APPEND_ERROR:
          this.lastLoadedFragLevel = -1, this.firstSelection = -1;
          break;
        case L.FRAG_LOAD_TIMEOUT: {
          const s = t.frag, {
            fragCurrent: i,
            partCurrent: r
          } = this;
          if (s && i && s.sn === i.sn && s.level === i.level) {
            const a = performance.now(), o = r ? r.stats : s.stats, l = a - o.loading.start, c = o.loading.first ? o.loading.first - o.loading.start : -1;
            if (o.loaded && c > -1) {
              const u = this.bwEstimator.getEstimateTTFB();
              this.bwEstimator.sample(l - Math.min(u, c), o.loaded);
            } else
              this.bwEstimator.sampleTTFB(l);
          }
          break;
        }
      }
  }
  getTimeToLoadFrag(e, t, s, i) {
    const r = e + s / t, a = i ? this.lastLevelLoadSec : 0;
    return r + a;
  }
  onLevelLoaded(e, t) {
    const s = this.hls.config, {
      loading: i
    } = t.stats, r = i.end - i.start;
    M(r) && (this.lastLevelLoadSec = r / 1e3), t.details.live ? this.bwEstimator.update(s.abrEwmaSlowLive, s.abrEwmaFastLive) : this.bwEstimator.update(s.abrEwmaSlowVoD, s.abrEwmaFastVoD);
  }
  onFragLoaded(e, {
    frag: t,
    part: s
  }) {
    const i = s ? s.stats : t.stats;
    if (t.type === G.MAIN && this.bwEstimator.sampleTTFB(i.loading.first - i.loading.start), !this.ignoreFragment(t)) {
      if (this.clearTimer(), t.level === this._nextAutoLevel && (this._nextAutoLevel = -1), this.firstSelection = -1, this.hls.config.abrMaxWithRealBitrate) {
        const r = s ? s.duration : t.duration, a = this.hls.levels[t.level], o = (a.loaded ? a.loaded.bytes : 0) + i.loaded, l = (a.loaded ? a.loaded.duration : 0) + r;
        a.loaded = {
          bytes: o,
          duration: l
        }, a.realBitrate = Math.round(8 * o / l);
      }
      if (t.bitrateTest) {
        const r = {
          stats: i,
          frag: t,
          part: s,
          id: t.type
        };
        this.onFragBuffered(p.FRAG_BUFFERED, r), t.bitrateTest = !1;
      } else
        this.lastLoadedFragLevel = t.level;
    }
  }
  onFragBuffered(e, t) {
    const {
      frag: s,
      part: i
    } = t, r = i != null && i.stats.loaded ? i.stats : s.stats;
    if (r.aborted || this.ignoreFragment(s))
      return;
    const a = r.parsing.end - r.loading.start - Math.min(r.loading.first - r.loading.start, this.bwEstimator.getEstimateTTFB());
    this.bwEstimator.sample(a, r.loaded), r.bwEstimate = this.getBwEstimate(), s.bitrateTest ? this.bitrateTestDelay = a / 1e3 : this.bitrateTestDelay = 0;
  }
  ignoreFragment(e) {
    return e.type !== G.MAIN || e.sn === "initSegment";
  }
  clearTimer() {
    this.timer > -1 && (self.clearInterval(this.timer), this.timer = -1);
  }
  get firstAutoLevel() {
    const {
      maxAutoLevel: e,
      minAutoLevel: t
    } = this.hls, s = this.getBwEstimate(), i = this.hls.config.maxStarvationDelay, r = this.findBestLevel(s, t, e, 0, i, 1, 1);
    if (r > -1)
      return r;
    const a = this.hls.firstLevel, o = Math.min(Math.max(a, t), e);
    return v.warn(`[abr] Could not find best starting auto level. Defaulting to first in playlist ${a} clamped to ${o}`), o;
  }
  get forcedAutoLevel() {
    return this.nextAutoLevelKey ? -1 : this._nextAutoLevel;
  }
  // return next auto level
  get nextAutoLevel() {
    const e = this.forcedAutoLevel, s = this.bwEstimator.canEstimate(), i = this.lastLoadedFragLevel > -1;
    if (e !== -1 && (!s || !i || this.nextAutoLevelKey === this.getAutoLevelKey()))
      return e;
    const r = s && i ? this.getNextABRAutoLevel() : this.firstAutoLevel;
    if (e !== -1) {
      const a = this.hls.levels;
      if (a.length > Math.max(e, r) && a[e].loadError <= a[r].loadError)
        return e;
    }
    return this._nextAutoLevel = r, this.nextAutoLevelKey = this.getAutoLevelKey(), r;
  }
  getAutoLevelKey() {
    return `${this.getBwEstimate()}_${this.getStarvationDelay().toFixed(2)}`;
  }
  getNextABRAutoLevel() {
    const {
      fragCurrent: e,
      partCurrent: t,
      hls: s
    } = this, {
      maxAutoLevel: i,
      config: r,
      minAutoLevel: a
    } = s, o = t ? t.duration : e ? e.duration : 0, l = this.getBwEstimate(), c = this.getStarvationDelay();
    let h = r.abrBandWidthFactor, u = r.abrBandWidthUpFactor;
    if (c) {
      const E = this.findBestLevel(l, a, i, c, 0, h, u);
      if (E >= 0)
        return E;
    }
    let d = o ? Math.min(o, r.maxStarvationDelay) : r.maxStarvationDelay;
    if (!c) {
      const E = this.bitrateTestDelay;
      E && (d = (o ? Math.min(o, r.maxLoadingDelay) : r.maxLoadingDelay) - E, v.info(`[abr] bitrate test took ${Math.round(1e3 * E)}ms, set first fragment max fetchDuration to ${Math.round(1e3 * d)} ms`), h = u = 1);
    }
    const f = this.findBestLevel(l, a, i, c, d, h, u);
    if (v.info(`[abr] ${c ? "rebuffering expected" : "buffer is empty"}, optimal quality level ${f}`), f > -1)
      return f;
    const g = s.levels[a], m = s.levels[s.loadLevel];
    return (g == null ? void 0 : g.bitrate) < (m == null ? void 0 : m.bitrate) ? a : s.loadLevel;
  }
  getStarvationDelay() {
    const e = this.hls, t = e.media;
    if (!t)
      return 1 / 0;
    const s = t && t.playbackRate !== 0 ? Math.abs(t.playbackRate) : 1, i = e.mainForwardBufferInfo;
    return (i ? i.len : 0) / s;
  }
  getBwEstimate() {
    return this.bwEstimator.canEstimate() ? this.bwEstimator.getEstimate() : this.hls.config.abrEwmaDefaultEstimate;
  }
  findBestLevel(e, t, s, i, r, a, o) {
    var l;
    const c = i + r, h = this.lastLoadedFragLevel, u = h === -1 ? this.hls.firstLevel : h, {
      fragCurrent: d,
      partCurrent: f
    } = this, {
      levels: g,
      allAudioTracks: m,
      loadLevel: E,
      config: T
    } = this.hls;
    if (g.length === 1)
      return 0;
    const y = g[u], x = !!(y != null && (l = y.details) != null && l.live), b = E === -1 || h === -1;
    let S, D = "SDR", R = (y == null ? void 0 : y.frameRate) || 0;
    const {
      audioPreference: _,
      videoPreference: P
    } = T, I = this.audioTracksByGroup || (this.audioTracksByGroup = $o(m));
    if (b) {
      if (this.firstSelection !== -1)
        return this.firstSelection;
      const $ = this.codecTiers || (this.codecTiers = Ko(g, I, t, s)), U = Go($, D, e, _, P), {
        codecSet: W,
        videoRanges: z,
        minFramerate: N,
        minBitrate: O,
        preferHDR: j
      } = U;
      S = W, D = j ? z[z.length - 1] : z[0], R = N, e = Math.max(e, O), v.log(`[abr] picked start tier ${JSON.stringify(U)}`);
    } else
      S = y == null ? void 0 : y.codecSet, D = y == null ? void 0 : y.videoRange;
    const k = f ? f.duration : d ? d.duration : 0, V = this.bwEstimator.getEstimateTTFB() / 1e3, F = [];
    for (let $ = s; $ >= t; $--) {
      var w;
      const U = g[$], W = $ > u;
      if (!U)
        continue;
      if (T.useMediaCapabilities && !U.supportedResult && !U.supportedPromise) {
        const te = navigator.mediaCapabilities;
        typeof (te == null ? void 0 : te.decodingInfo) == "function" && Oo(U, I, D, R, e, _) ? (U.supportedPromise = Mo(U, I, te), U.supportedPromise.then((re) => {
          if (!this.hls)
            return;
          U.supportedResult = re;
          const le = this.hls.levels, ge = le.indexOf(U);
          re.error ? v.warn(`[abr] MediaCapabilities decodingInfo error: "${re.error}" for level ${ge} ${JSON.stringify(re)}`) : re.supported || (v.warn(`[abr] Unsupported MediaCapabilities decodingInfo result for level ${ge} ${JSON.stringify(re)}`), ge > -1 && le.length > 1 && (v.log(`[abr] Removing unsupported level ${ge}`), this.hls.removeLevel(ge)));
        })) : U.supportedResult = Wr;
      }
      if (S && U.codecSet !== S || D && U.videoRange !== D || W && R > U.frameRate || !W && R > 0 && R < U.frameRate || U.supportedResult && !((w = U.supportedResult.decodingInfoResults) != null && w[0].smooth)) {
        F.push($);
        continue;
      }
      const z = U.details, N = (f ? z == null ? void 0 : z.partTarget : z == null ? void 0 : z.averagetargetduration) || k;
      let O;
      W ? O = o * e : O = a * e;
      const j = k && i >= k * 2 && r === 0 ? g[$].averageBitrate : g[$].maxBitrate, Y = this.getTimeToLoadFrag(V, O, j * N, z === void 0);
      if (
        // if adjusted bw is greater than level bitrate AND
        O >= j && // no level change, or new level has no error history
        ($ === h || U.loadError === 0 && U.fragmentError === 0) && // fragment fetchDuration unknown OR live stream OR fragment fetchDuration less than max allowed fetch duration, then this level matches
        // we don't account for max Fetch Duration for live streams, this is to avoid switching down when near the edge of live sliding window ...
        // special case to support startLevel = -1 (bitrateTest) on live streams : in that case we should not exit loop so that findBestLevel will return -1
        (Y <= V || !M(Y) || x && !this.bitrateTestDelay || Y < c)
      ) {
        const te = this.forcedAutoLevel;
        return $ !== E && (te === -1 || te !== E) && (F.length && v.trace(`[abr] Skipped level(s) ${F.join(",")} of ${s} max with CODECS and VIDEO-RANGE:"${g[F[0]].codecs}" ${g[F[0]].videoRange}; not compatible with "${y.codecs}" ${D}`), v.info(`[abr] switch candidate:${u}->${$} adjustedbw(${Math.round(O)})-bitrate=${Math.round(O - j)} ttfb:${V.toFixed(1)} avgDuration:${N.toFixed(1)} maxFetchDuration:${c.toFixed(1)} fetchDuration:${Y.toFixed(1)} firstSelection:${b} codecSet:${S} videoRange:${D} hls.loadLevel:${E}`)), b && (this.firstSelection = $), $;
      }
    }
    return -1;
  }
  set nextAutoLevel(e) {
    const {
      maxAutoLevel: t,
      minAutoLevel: s
    } = this.hls, i = Math.min(Math.max(e, s), t);
    this._nextAutoLevel !== i && (this.nextAutoLevelKey = "", this._nextAutoLevel = i);
  }
}
class Yo {
  constructor() {
    this._boundTick = void 0, this._tickTimer = null, this._tickInterval = null, this._tickCallCount = 0, this._boundTick = this.tick.bind(this);
  }
  destroy() {
    this.onHandlerDestroying(), this.onHandlerDestroyed();
  }
  onHandlerDestroying() {
    this.clearNextTick(), this.clearInterval();
  }
  onHandlerDestroyed() {
  }
  hasInterval() {
    return !!this._tickInterval;
  }
  hasNextTick() {
    return !!this._tickTimer;
  }
  /**
   * @param millis - Interval time (ms)
   * @eturns True when interval has been scheduled, false when already scheduled (no effect)
   */
  setInterval(e) {
    return this._tickInterval ? !1 : (this._tickCallCount = 0, this._tickInterval = self.setInterval(this._boundTick, e), !0);
  }
  /**
   * @returns True when interval was cleared, false when none was set (no effect)
   */
  clearInterval() {
    return this._tickInterval ? (self.clearInterval(this._tickInterval), this._tickInterval = null, !0) : !1;
  }
  /**
   * @returns True when timeout was cleared, false when none was set (no effect)
   */
  clearNextTick() {
    return this._tickTimer ? (self.clearTimeout(this._tickTimer), this._tickTimer = null, !0) : !1;
  }
  /**
   * Will call the subclass doTick implementation in this main loop tick
   * or in the next one (via setTimeout(,0)) in case it has already been called
   * in this tick (in case this is a re-entrant call).
   */
  tick() {
    this._tickCallCount++, this._tickCallCount === 1 && (this.doTick(), this._tickCallCount > 1 && this.tickImmediate(), this._tickCallCount = 0);
  }
  tickImmediate() {
    this.clearNextTick(), this._tickTimer = self.setTimeout(this._boundTick, 0);
  }
  /**
   * For subclass to implement task logic
   * @abstract
   */
  doTick() {
  }
}
var ae = {
  NOT_LOADED: "NOT_LOADED",
  APPENDING: "APPENDING",
  PARTIAL: "PARTIAL",
  OK: "OK"
};
class qo {
  constructor(e) {
    this.activePartLists = /* @__PURE__ */ Object.create(null), this.endListFragments = /* @__PURE__ */ Object.create(null), this.fragments = /* @__PURE__ */ Object.create(null), this.timeRanges = /* @__PURE__ */ Object.create(null), this.bufferPadding = 0.2, this.hls = void 0, this.hasGaps = !1, this.hls = e, this._registerListeners();
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.BUFFER_APPENDED, this.onBufferAppended, this), e.on(p.FRAG_BUFFERED, this.onFragBuffered, this), e.on(p.FRAG_LOADED, this.onFragLoaded, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.BUFFER_APPENDED, this.onBufferAppended, this), e.off(p.FRAG_BUFFERED, this.onFragBuffered, this), e.off(p.FRAG_LOADED, this.onFragLoaded, this);
  }
  destroy() {
    this._unregisterListeners(), this.fragments = // @ts-ignore
    this.activePartLists = // @ts-ignore
    this.endListFragments = this.timeRanges = null;
  }
  /**
   * Return a Fragment or Part with an appended range that matches the position and levelType
   * Otherwise, return null
   */
  getAppendedFrag(e, t) {
    const s = this.activePartLists[t];
    if (s)
      for (let i = s.length; i--; ) {
        const r = s[i];
        if (!r)
          break;
        const a = r.end;
        if (r.start <= e && a !== null && e <= a)
          return r;
      }
    return this.getBufferedFrag(e, t);
  }
  /**
   * Return a buffered Fragment that matches the position and levelType.
   * A buffered Fragment is one whose loading, parsing and appending is done (completed or "partial" meaning aborted).
   * If not found any Fragment, return null
   */
  getBufferedFrag(e, t) {
    const {
      fragments: s
    } = this, i = Object.keys(s);
    for (let r = i.length; r--; ) {
      const a = s[i[r]];
      if ((a == null ? void 0 : a.body.type) === t && a.buffered) {
        const o = a.body;
        if (o.start <= e && e <= o.end)
          return o;
      }
    }
    return null;
  }
  /**
   * Partial fragments effected by coded frame eviction will be removed
   * The browser will unload parts of the buffer to free up memory for new buffer data
   * Fragments will need to be reloaded when the buffer is freed up, removing partial fragments will allow them to reload(since there might be parts that are still playable)
   */
  detectEvictedFragments(e, t, s, i) {
    this.timeRanges && (this.timeRanges[e] = t);
    const r = (i == null ? void 0 : i.fragment.sn) || -1;
    Object.keys(this.fragments).forEach((a) => {
      const o = this.fragments[a];
      if (!o || r >= o.body.sn)
        return;
      if (!o.buffered && !o.loaded) {
        o.body.type === s && this.removeFragment(o.body);
        return;
      }
      const l = o.range[e];
      l && l.time.some((c) => {
        const h = !this.isTimeBuffered(c.startPTS, c.endPTS, t);
        return h && this.removeFragment(o.body), h;
      });
    });
  }
  /**
   * Checks if the fragment passed in is loaded in the buffer properly
   * Partially loaded fragments will be registered as a partial fragment
   */
  detectPartialFragments(e) {
    const t = this.timeRanges, {
      frag: s,
      part: i
    } = e;
    if (!t || s.sn === "initSegment")
      return;
    const r = Ye(s), a = this.fragments[r];
    if (!a || a.buffered && s.gap)
      return;
    const o = !s.relurl;
    Object.keys(t).forEach((l) => {
      const c = s.elementaryStreams[l];
      if (!c)
        return;
      const h = t[l], u = o || c.partial === !0;
      a.range[l] = this.getBufferedTimes(s, i, u, h);
    }), a.loaded = null, Object.keys(a.range).length ? (a.buffered = !0, (a.body.endList = s.endList || a.body.endList) && (this.endListFragments[a.body.type] = a), gt(a) || this.removeParts(s.sn - 1, s.type)) : this.removeFragment(a.body);
  }
  removeParts(e, t) {
    const s = this.activePartLists[t];
    s && (this.activePartLists[t] = s.filter((i) => i.fragment.sn >= e));
  }
  fragBuffered(e, t) {
    const s = Ye(e);
    let i = this.fragments[s];
    !i && t && (i = this.fragments[s] = {
      body: e,
      appendedPTS: null,
      loaded: null,
      buffered: !1,
      range: /* @__PURE__ */ Object.create(null)
    }, e.gap && (this.hasGaps = !0)), i && (i.loaded = null, i.buffered = !0);
  }
  getBufferedTimes(e, t, s, i) {
    const r = {
      time: [],
      partial: s
    }, a = e.start, o = e.end, l = e.minEndPTS || o, c = e.maxStartPTS || a;
    for (let h = 0; h < i.length; h++) {
      const u = i.start(h) - this.bufferPadding, d = i.end(h) + this.bufferPadding;
      if (c >= u && l <= d) {
        r.time.push({
          startPTS: Math.max(a, i.start(h)),
          endPTS: Math.min(o, i.end(h))
        });
        break;
      } else if (a < d && o > u) {
        const f = Math.max(a, i.start(h)), g = Math.min(o, i.end(h));
        g > f && (r.partial = !0, r.time.push({
          startPTS: f,
          endPTS: g
        }));
      } else if (o <= u)
        break;
    }
    return r;
  }
  /**
   * Gets the partial fragment for a certain time
   */
  getPartialFragment(e) {
    let t = null, s, i, r, a = 0;
    const {
      bufferPadding: o,
      fragments: l
    } = this;
    return Object.keys(l).forEach((c) => {
      const h = l[c];
      h && gt(h) && (i = h.body.start - o, r = h.body.end + o, e >= i && e <= r && (s = Math.min(e - i, r - e), a <= s && (t = h.body, a = s)));
    }), t;
  }
  isEndListAppended(e) {
    const t = this.endListFragments[e];
    return t !== void 0 && (t.buffered || gt(t));
  }
  getState(e) {
    const t = Ye(e), s = this.fragments[t];
    return s ? s.buffered ? gt(s) ? ae.PARTIAL : ae.OK : ae.APPENDING : ae.NOT_LOADED;
  }
  isTimeBuffered(e, t, s) {
    let i, r;
    for (let a = 0; a < s.length; a++) {
      if (i = s.start(a) - this.bufferPadding, r = s.end(a) + this.bufferPadding, e >= i && t <= r)
        return !0;
      if (t <= i)
        return !1;
    }
    return !1;
  }
  onFragLoaded(e, t) {
    const {
      frag: s,
      part: i
    } = t;
    if (s.sn === "initSegment" || s.bitrateTest)
      return;
    const r = i ? null : t, a = Ye(s);
    this.fragments[a] = {
      body: s,
      appendedPTS: null,
      loaded: r,
      buffered: !1,
      range: /* @__PURE__ */ Object.create(null)
    };
  }
  onBufferAppended(e, t) {
    const {
      frag: s,
      part: i,
      timeRanges: r
    } = t;
    if (s.sn === "initSegment")
      return;
    const a = s.type;
    if (i) {
      let o = this.activePartLists[a];
      o || (this.activePartLists[a] = o = []), o.push(i);
    }
    this.timeRanges = r, Object.keys(r).forEach((o) => {
      const l = r[o];
      this.detectEvictedFragments(o, l, a, i);
    });
  }
  onFragBuffered(e, t) {
    this.detectPartialFragments(t);
  }
  hasFragment(e) {
    const t = Ye(e);
    return !!this.fragments[t];
  }
  hasParts(e) {
    var t;
    return !!((t = this.activePartLists[e]) != null && t.length);
  }
  removeFragmentsInRange(e, t, s, i, r) {
    i && !this.hasGaps || Object.keys(this.fragments).forEach((a) => {
      const o = this.fragments[a];
      if (!o)
        return;
      const l = o.body;
      l.type !== s || i && !l.gap || l.start < t && l.end > e && (o.buffered || r) && this.removeFragment(l);
    });
  }
  removeFragment(e) {
    const t = Ye(e);
    e.stats.loaded = 0, e.clearElementaryStreamInfo();
    const s = this.activePartLists[e.type];
    if (s) {
      const i = e.sn;
      this.activePartLists[e.type] = s.filter((r) => r.fragment.sn !== i);
    }
    delete this.fragments[t], e.endList && delete this.endListFragments[e.type];
  }
  removeAllFragments() {
    this.fragments = /* @__PURE__ */ Object.create(null), this.endListFragments = /* @__PURE__ */ Object.create(null), this.activePartLists = /* @__PURE__ */ Object.create(null), this.hasGaps = !1;
  }
}
function gt(n) {
  var e, t, s;
  return n.buffered && (n.body.gap || ((e = n.range.video) == null ? void 0 : e.partial) || ((t = n.range.audio) == null ? void 0 : t.partial) || ((s = n.range.audiovideo) == null ? void 0 : s.partial));
}
function Ye(n) {
  return `${n.type}_${n.level}_${n.sn}`;
}
const jo = {
  length: 0,
  start: () => 0,
  end: () => 0
};
class J {
  /**
   * Return true if `media`'s buffered include `position`
   */
  static isBuffered(e, t) {
    try {
      if (e) {
        const s = J.getBuffered(e);
        for (let i = 0; i < s.length; i++)
          if (t >= s.start(i) && t <= s.end(i))
            return !0;
      }
    } catch {
    }
    return !1;
  }
  static bufferInfo(e, t, s) {
    try {
      if (e) {
        const i = J.getBuffered(e), r = [];
        let a;
        for (a = 0; a < i.length; a++)
          r.push({
            start: i.start(a),
            end: i.end(a)
          });
        return this.bufferedInfo(r, t, s);
      }
    } catch {
    }
    return {
      len: 0,
      start: t,
      end: t,
      nextStart: void 0
    };
  }
  static bufferedInfo(e, t, s) {
    t = Math.max(0, t), e.sort(function(c, h) {
      const u = c.start - h.start;
      return u || h.end - c.end;
    });
    let i = [];
    if (s)
      for (let c = 0; c < e.length; c++) {
        const h = i.length;
        if (h) {
          const u = i[h - 1].end;
          e[c].start - u < s ? e[c].end > u && (i[h - 1].end = e[c].end) : i.push(e[c]);
        } else
          i.push(e[c]);
      }
    else
      i = e;
    let r = 0, a, o = t, l = t;
    for (let c = 0; c < i.length; c++) {
      const h = i[c].start, u = i[c].end;
      if (t + s >= h && t < u)
        o = h, l = u, r = l - t;
      else if (t + s < h) {
        a = h;
        break;
      }
    }
    return {
      len: r,
      start: o || 0,
      end: l || 0,
      nextStart: a
    };
  }
  /**
   * Safe method to get buffered property.
   * SourceBuffer.buffered may throw if SourceBuffer is removed from it's MediaSource
   */
  static getBuffered(e) {
    try {
      return e.buffered;
    } catch (t) {
      return v.log("failed to get media.buffered", t), jo;
    }
  }
}
class Vs {
  constructor(e, t, s, i = 0, r = -1, a = !1) {
    this.level = void 0, this.sn = void 0, this.part = void 0, this.id = void 0, this.size = void 0, this.partial = void 0, this.transmuxing = mt(), this.buffering = {
      audio: mt(),
      video: mt(),
      audiovideo: mt()
    }, this.level = e, this.sn = t, this.id = s, this.size = i, this.part = r, this.partial = a;
  }
}
function mt() {
  return {
    start: 0,
    executeStart: 0,
    executeEnd: 0,
    end: 0
  };
}
function Rt(n, e) {
  for (let s = 0, i = n.length; s < i; s++) {
    var t;
    if (((t = n[s]) == null ? void 0 : t.cc) === e)
      return n[s];
  }
  return null;
}
function zo(n, e, t) {
  return !!(e && (t.endCC > t.startCC || n && n.cc < t.startCC));
}
function Xo(n, e) {
  const t = n.fragments, s = e.fragments;
  if (!s.length || !t.length) {
    v.log("No fragments to align");
    return;
  }
  const i = Rt(t, s[0].cc);
  if (!i || i && !i.startPTS) {
    v.log("No frag in previous level to align on");
    return;
  }
  return i;
}
function Ni(n, e) {
  if (n) {
    const t = n.start + e;
    n.start = n.startPTS = t, n.endPTS = t + n.duration;
  }
}
function Yr(n, e) {
  const t = e.fragments;
  for (let s = 0, i = t.length; s < i; s++)
    Ni(t[s], n);
  e.fragmentHint && Ni(e.fragmentHint, n), e.alignedSliding = !0;
}
function Qo(n, e, t) {
  e && (Jo(n, t, e), !t.alignedSliding && e && Bt(t, e), !t.alignedSliding && e && !t.skippedSegments && $r(e, t));
}
function Jo(n, e, t) {
  if (zo(n, t, e)) {
    const s = Xo(t, e);
    s && M(s.start) && (v.log(`Adjusting PTS using last level due to CC increase within current level ${e.url}`), Yr(s.start, e));
  }
}
function Bt(n, e) {
  if (!n.hasProgramDateTime || !e.hasProgramDateTime)
    return;
  const t = n.fragments, s = e.fragments;
  if (!t.length || !s.length)
    return;
  let i, r;
  const a = Math.min(e.endCC, n.endCC);
  e.startCC < a && n.startCC < a && (i = Rt(s, a), r = Rt(t, a)), (!i || !r) && (i = s[Math.floor(s.length / 2)], r = Rt(t, i.cc) || t[Math.floor(t.length / 2)]);
  const o = i.programDateTime, l = r.programDateTime;
  if (!o || !l)
    return;
  const c = (l - o) / 1e3 - (r.start - i.start);
  Yr(c, n);
}
const Ui = Math.pow(2, 17);
class Zo {
  constructor(e) {
    this.config = void 0, this.loader = null, this.partLoadTimeout = -1, this.config = e;
  }
  destroy() {
    this.loader && (this.loader.destroy(), this.loader = null);
  }
  abort() {
    this.loader && this.loader.abort();
  }
  load(e, t) {
    const s = e.url;
    if (!s)
      return Promise.reject(new ke({
        type: K.NETWORK_ERROR,
        details: L.FRAG_LOAD_ERROR,
        fatal: !1,
        frag: e,
        error: new Error(`Fragment does not have a ${s ? "part list" : "url"}`),
        networkDetails: null
      }));
    this.abort();
    const i = this.config, r = i.fLoader, a = i.loader;
    return new Promise((o, l) => {
      if (this.loader && this.loader.destroy(), e.gap)
        if (e.tagList.some((f) => f[0] === "GAP")) {
          l(Gi(e));
          return;
        } else
          e.gap = !1;
      const c = this.loader = e.loader = r ? new r(i) : new a(i), h = Bi(e), u = Fi(i.fragLoadPolicy.default), d = {
        loadPolicy: u,
        timeout: u.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0,
        highWaterMark: e.sn === "initSegment" ? 1 / 0 : Ui
      };
      e.stats = c.stats, c.load(h, d, {
        onSuccess: (f, g, m, E) => {
          this.resetLoader(e, c);
          let T = f.data;
          m.resetIV && e.decryptdata && (e.decryptdata.iv = new Uint8Array(T.slice(0, 16)), T = T.slice(16)), o({
            frag: e,
            part: null,
            payload: T,
            networkDetails: E
          });
        },
        onError: (f, g, m, E) => {
          this.resetLoader(e, c), l(new ke({
            type: K.NETWORK_ERROR,
            details: L.FRAG_LOAD_ERROR,
            fatal: !1,
            frag: e,
            response: oe({
              url: s,
              data: void 0
            }, f),
            error: new Error(`HTTP Error ${f.code} ${f.text}`),
            networkDetails: m,
            stats: E
          }));
        },
        onAbort: (f, g, m) => {
          this.resetLoader(e, c), l(new ke({
            type: K.NETWORK_ERROR,
            details: L.INTERNAL_ABORTED,
            fatal: !1,
            frag: e,
            error: new Error("Aborted"),
            networkDetails: m,
            stats: f
          }));
        },
        onTimeout: (f, g, m) => {
          this.resetLoader(e, c), l(new ke({
            type: K.NETWORK_ERROR,
            details: L.FRAG_LOAD_TIMEOUT,
            fatal: !1,
            frag: e,
            error: new Error(`Timeout after ${d.timeout}ms`),
            networkDetails: m,
            stats: f
          }));
        },
        onProgress: (f, g, m, E) => {
          t && t({
            frag: e,
            part: null,
            payload: m,
            networkDetails: E
          });
        }
      });
    });
  }
  loadPart(e, t, s) {
    this.abort();
    const i = this.config, r = i.fLoader, a = i.loader;
    return new Promise((o, l) => {
      if (this.loader && this.loader.destroy(), e.gap || t.gap) {
        l(Gi(e, t));
        return;
      }
      const c = this.loader = e.loader = r ? new r(i) : new a(i), h = Bi(e, t), u = Fi(i.fragLoadPolicy.default), d = {
        loadPolicy: u,
        timeout: u.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0,
        highWaterMark: Ui
      };
      t.stats = c.stats, c.load(h, d, {
        onSuccess: (f, g, m, E) => {
          this.resetLoader(e, c), this.updateStatsFromPart(e, t);
          const T = {
            frag: e,
            part: t,
            payload: f.data,
            networkDetails: E
          };
          s(T), o(T);
        },
        onError: (f, g, m, E) => {
          this.resetLoader(e, c), l(new ke({
            type: K.NETWORK_ERROR,
            details: L.FRAG_LOAD_ERROR,
            fatal: !1,
            frag: e,
            part: t,
            response: oe({
              url: h.url,
              data: void 0
            }, f),
            error: new Error(`HTTP Error ${f.code} ${f.text}`),
            networkDetails: m,
            stats: E
          }));
        },
        onAbort: (f, g, m) => {
          e.stats.aborted = t.stats.aborted, this.resetLoader(e, c), l(new ke({
            type: K.NETWORK_ERROR,
            details: L.INTERNAL_ABORTED,
            fatal: !1,
            frag: e,
            part: t,
            error: new Error("Aborted"),
            networkDetails: m,
            stats: f
          }));
        },
        onTimeout: (f, g, m) => {
          this.resetLoader(e, c), l(new ke({
            type: K.NETWORK_ERROR,
            details: L.FRAG_LOAD_TIMEOUT,
            fatal: !1,
            frag: e,
            part: t,
            error: new Error(`Timeout after ${d.timeout}ms`),
            networkDetails: m,
            stats: f
          }));
        }
      });
    });
  }
  updateStatsFromPart(e, t) {
    const s = e.stats, i = t.stats, r = i.total;
    if (s.loaded += i.loaded, r) {
      const l = Math.round(e.duration / t.duration), c = Math.min(Math.round(s.loaded / r), l), u = (l - c) * Math.round(s.loaded / c);
      s.total = s.loaded + u;
    } else
      s.total = Math.max(s.loaded, s.total);
    const a = s.loading, o = i.loading;
    a.start ? a.first += o.first - o.start : (a.start = o.start, a.first = o.first), a.end = o.end;
  }
  resetLoader(e, t) {
    e.loader = null, this.loader === t && (self.clearTimeout(this.partLoadTimeout), this.loader = null), t.destroy();
  }
}
function Bi(n, e = null) {
  const t = e || n, s = {
    frag: n,
    part: e,
    responseType: "arraybuffer",
    url: t.url,
    headers: {},
    rangeStart: 0,
    rangeEnd: 0
  }, i = t.byteRangeStartOffset, r = t.byteRangeEndOffset;
  if (M(i) && M(r)) {
    var a;
    let o = i, l = r;
    if (n.sn === "initSegment" && ((a = n.decryptdata) == null ? void 0 : a.method) === "AES-128") {
      const c = r - i;
      c % 16 && (l = r + (16 - c % 16)), i !== 0 && (s.resetIV = !0, o = i - 16);
    }
    s.rangeStart = o, s.rangeEnd = l;
  }
  return s;
}
function Gi(n, e) {
  const t = new Error(`GAP ${n.gap ? "tag" : "attribute"} found`), s = {
    type: K.MEDIA_ERROR,
    details: L.FRAG_GAP,
    fatal: !1,
    frag: n,
    error: t,
    networkDetails: null
  };
  return e && (s.part = e), (e || n).stats.aborted = !0, new ke(s);
}
class ke extends Error {
  constructor(e) {
    super(e.error.message), this.data = void 0, this.data = e;
  }
}
class el {
  constructor(e, t) {
    this.subtle = void 0, this.aesIV = void 0, this.subtle = e, this.aesIV = t;
  }
  decrypt(e, t) {
    return this.subtle.decrypt({
      name: "AES-CBC",
      iv: this.aesIV
    }, t, e);
  }
}
class tl {
  constructor(e, t) {
    this.subtle = void 0, this.key = void 0, this.subtle = e, this.key = t;
  }
  expandKey() {
    return this.subtle.importKey("raw", this.key, {
      name: "AES-CBC"
    }, !1, ["encrypt", "decrypt"]);
  }
}
function sl(n) {
  const e = n.byteLength, t = e && new DataView(n.buffer).getUint8(e - 1);
  return t ? Ge(n, 0, e - t) : n;
}
class il {
  constructor() {
    this.rcon = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54], this.subMix = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)], this.invSubMix = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)], this.sBox = new Uint32Array(256), this.invSBox = new Uint32Array(256), this.key = new Uint32Array(0), this.ksRows = 0, this.keySize = 0, this.keySchedule = void 0, this.invKeySchedule = void 0, this.initTable();
  }
  // Using view.getUint32() also swaps the byte order.
  uint8ArrayToUint32Array_(e) {
    const t = new DataView(e), s = new Uint32Array(4);
    for (let i = 0; i < 4; i++)
      s[i] = t.getUint32(i * 4);
    return s;
  }
  initTable() {
    const e = this.sBox, t = this.invSBox, s = this.subMix, i = s[0], r = s[1], a = s[2], o = s[3], l = this.invSubMix, c = l[0], h = l[1], u = l[2], d = l[3], f = new Uint32Array(256);
    let g = 0, m = 0, E = 0;
    for (E = 0; E < 256; E++)
      E < 128 ? f[E] = E << 1 : f[E] = E << 1 ^ 283;
    for (E = 0; E < 256; E++) {
      let T = m ^ m << 1 ^ m << 2 ^ m << 3 ^ m << 4;
      T = T >>> 8 ^ T & 255 ^ 99, e[g] = T, t[T] = g;
      const y = f[g], x = f[y], b = f[x];
      let S = f[T] * 257 ^ T * 16843008;
      i[g] = S << 24 | S >>> 8, r[g] = S << 16 | S >>> 16, a[g] = S << 8 | S >>> 24, o[g] = S, S = b * 16843009 ^ x * 65537 ^ y * 257 ^ g * 16843008, c[T] = S << 24 | S >>> 8, h[T] = S << 16 | S >>> 16, u[T] = S << 8 | S >>> 24, d[T] = S, g ? (g = y ^ f[f[f[b ^ y]]], m ^= f[f[m]]) : g = m = 1;
    }
  }
  expandKey(e) {
    const t = this.uint8ArrayToUint32Array_(e);
    let s = !0, i = 0;
    for (; i < t.length && s; )
      s = t[i] === this.key[i], i++;
    if (s)
      return;
    this.key = t;
    const r = this.keySize = t.length;
    if (r !== 4 && r !== 6 && r !== 8)
      throw new Error("Invalid aes key size=" + r);
    const a = this.ksRows = (r + 6 + 1) * 4;
    let o, l;
    const c = this.keySchedule = new Uint32Array(a), h = this.invKeySchedule = new Uint32Array(a), u = this.sBox, d = this.rcon, f = this.invSubMix, g = f[0], m = f[1], E = f[2], T = f[3];
    let y, x;
    for (o = 0; o < a; o++) {
      if (o < r) {
        y = c[o] = t[o];
        continue;
      }
      x = y, o % r === 0 ? (x = x << 8 | x >>> 24, x = u[x >>> 24] << 24 | u[x >>> 16 & 255] << 16 | u[x >>> 8 & 255] << 8 | u[x & 255], x ^= d[o / r | 0] << 24) : r > 6 && o % r === 4 && (x = u[x >>> 24] << 24 | u[x >>> 16 & 255] << 16 | u[x >>> 8 & 255] << 8 | u[x & 255]), c[o] = y = (c[o - r] ^ x) >>> 0;
    }
    for (l = 0; l < a; l++)
      o = a - l, l & 3 ? x = c[o] : x = c[o - 4], l < 4 || o <= 4 ? h[l] = x : h[l] = g[u[x >>> 24]] ^ m[u[x >>> 16 & 255]] ^ E[u[x >>> 8 & 255]] ^ T[u[x & 255]], h[l] = h[l] >>> 0;
  }
  // Adding this as a method greatly improves performance.
  networkToHostOrderSwap(e) {
    return e << 24 | (e & 65280) << 8 | (e & 16711680) >> 8 | e >>> 24;
  }
  decrypt(e, t, s) {
    const i = this.keySize + 6, r = this.invKeySchedule, a = this.invSBox, o = this.invSubMix, l = o[0], c = o[1], h = o[2], u = o[3], d = this.uint8ArrayToUint32Array_(s);
    let f = d[0], g = d[1], m = d[2], E = d[3];
    const T = new Int32Array(e), y = new Int32Array(T.length);
    let x, b, S, D, R, _, P, I, k, V, F, w, $, U;
    const W = this.networkToHostOrderSwap;
    for (; t < T.length; ) {
      for (k = W(T[t]), V = W(T[t + 1]), F = W(T[t + 2]), w = W(T[t + 3]), R = k ^ r[0], _ = w ^ r[1], P = F ^ r[2], I = V ^ r[3], $ = 4, U = 1; U < i; U++)
        x = l[R >>> 24] ^ c[_ >> 16 & 255] ^ h[P >> 8 & 255] ^ u[I & 255] ^ r[$], b = l[_ >>> 24] ^ c[P >> 16 & 255] ^ h[I >> 8 & 255] ^ u[R & 255] ^ r[$ + 1], S = l[P >>> 24] ^ c[I >> 16 & 255] ^ h[R >> 8 & 255] ^ u[_ & 255] ^ r[$ + 2], D = l[I >>> 24] ^ c[R >> 16 & 255] ^ h[_ >> 8 & 255] ^ u[P & 255] ^ r[$ + 3], R = x, _ = b, P = S, I = D, $ = $ + 4;
      x = a[R >>> 24] << 24 ^ a[_ >> 16 & 255] << 16 ^ a[P >> 8 & 255] << 8 ^ a[I & 255] ^ r[$], b = a[_ >>> 24] << 24 ^ a[P >> 16 & 255] << 16 ^ a[I >> 8 & 255] << 8 ^ a[R & 255] ^ r[$ + 1], S = a[P >>> 24] << 24 ^ a[I >> 16 & 255] << 16 ^ a[R >> 8 & 255] << 8 ^ a[_ & 255] ^ r[$ + 2], D = a[I >>> 24] << 24 ^ a[R >> 16 & 255] << 16 ^ a[_ >> 8 & 255] << 8 ^ a[P & 255] ^ r[$ + 3], y[t] = W(x ^ f), y[t + 1] = W(D ^ g), y[t + 2] = W(S ^ m), y[t + 3] = W(b ^ E), f = k, g = V, m = F, E = w, t = t + 4;
    }
    return y.buffer;
  }
}
const rl = 16;
class Hs {
  constructor(e, {
    removePKCS7Padding: t = !0
  } = {}) {
    if (this.logEnabled = !0, this.removePKCS7Padding = void 0, this.subtle = null, this.softwareDecrypter = null, this.key = null, this.fastAesKey = null, this.remainderData = null, this.currentIV = null, this.currentResult = null, this.useSoftware = void 0, this.useSoftware = e.enableSoftwareAES, this.removePKCS7Padding = t, t)
      try {
        const s = self.crypto;
        s && (this.subtle = s.subtle || s.webkitSubtle);
      } catch {
      }
    this.useSoftware = !this.subtle;
  }
  destroy() {
    this.subtle = null, this.softwareDecrypter = null, this.key = null, this.fastAesKey = null, this.remainderData = null, this.currentIV = null, this.currentResult = null;
  }
  isSync() {
    return this.useSoftware;
  }
  flush() {
    const {
      currentResult: e,
      remainderData: t
    } = this;
    if (!e || t)
      return this.reset(), null;
    const s = new Uint8Array(e);
    return this.reset(), this.removePKCS7Padding ? sl(s) : s;
  }
  reset() {
    this.currentResult = null, this.currentIV = null, this.remainderData = null, this.softwareDecrypter && (this.softwareDecrypter = null);
  }
  decrypt(e, t, s) {
    return this.useSoftware ? new Promise((i, r) => {
      this.softwareDecrypt(new Uint8Array(e), t, s);
      const a = this.flush();
      a ? i(a.buffer) : r(new Error("[softwareDecrypt] Failed to decrypt data"));
    }) : this.webCryptoDecrypt(new Uint8Array(e), t, s);
  }
  // Software decryption is progressive. Progressive decryption may not return a result on each call. Any cached
  // data is handled in the flush() call
  softwareDecrypt(e, t, s) {
    const {
      currentIV: i,
      currentResult: r,
      remainderData: a
    } = this;
    this.logOnce("JS AES decrypt"), a && (e = Te(a, e), this.remainderData = null);
    const o = this.getValidChunk(e);
    if (!o.length)
      return null;
    i && (s = i);
    let l = this.softwareDecrypter;
    l || (l = this.softwareDecrypter = new il()), l.expandKey(t);
    const c = r;
    return this.currentResult = l.decrypt(o.buffer, 0, s), this.currentIV = Ge(o, -16).buffer, c || null;
  }
  webCryptoDecrypt(e, t, s) {
    if (this.key !== t || !this.fastAesKey) {
      if (!this.subtle)
        return Promise.resolve(this.onWebCryptoError(e, t, s));
      this.key = t, this.fastAesKey = new tl(this.subtle, t);
    }
    return this.fastAesKey.expandKey().then((i) => this.subtle ? (this.logOnce("WebCrypto AES decrypt"), new el(this.subtle, new Uint8Array(s)).decrypt(e.buffer, i)) : Promise.reject(new Error("web crypto not initialized"))).catch((i) => (v.warn(`[decrypter]: WebCrypto Error, disable WebCrypto API, ${i.name}: ${i.message}`), this.onWebCryptoError(e, t, s)));
  }
  onWebCryptoError(e, t, s) {
    this.useSoftware = !0, this.logEnabled = !0, this.softwareDecrypt(e, t, s);
    const i = this.flush();
    if (i)
      return i.buffer;
    throw new Error("WebCrypto and softwareDecrypt: failed to decrypt data");
  }
  getValidChunk(e) {
    let t = e;
    const s = e.length - e.length % rl;
    return s !== e.length && (t = Ge(e, 0, s), this.remainderData = Ge(e, s)), t;
  }
  logOnce(e) {
    this.logEnabled && (v.log(`[decrypter]: ${e}`), this.logEnabled = !1);
  }
}
const nl = {
  toString: function(n) {
    let e = "";
    const t = n.length;
    for (let s = 0; s < t; s++)
      e += `[${n.start(s).toFixed(3)}-${n.end(s).toFixed(3)}]`;
    return e;
  }
}, C = {
  STOPPED: "STOPPED",
  IDLE: "IDLE",
  KEY_LOADING: "KEY_LOADING",
  FRAG_LOADING: "FRAG_LOADING",
  FRAG_LOADING_WAITING_RETRY: "FRAG_LOADING_WAITING_RETRY",
  WAITING_TRACK: "WAITING_TRACK",
  PARSING: "PARSING",
  PARSED: "PARSED",
  ENDED: "ENDED",
  ERROR: "ERROR",
  WAITING_INIT_PTS: "WAITING_INIT_PTS",
  WAITING_LEVEL: "WAITING_LEVEL"
};
class Ws extends Yo {
  constructor(e, t, s, i, r) {
    super(), this.hls = void 0, this.fragPrevious = null, this.fragCurrent = null, this.fragmentTracker = void 0, this.transmuxer = null, this._state = C.STOPPED, this.playlistType = void 0, this.media = null, this.mediaBuffer = null, this.config = void 0, this.bitrateTest = !1, this.lastCurrentTime = 0, this.nextLoadPosition = 0, this.startPosition = 0, this.startTimeOffset = null, this.loadedmetadata = !1, this.retryDate = 0, this.levels = null, this.fragmentLoader = void 0, this.keyLoader = void 0, this.levelLastLoaded = null, this.startFragRequested = !1, this.decrypter = void 0, this.initPTS = [], this.onvseeking = null, this.onvended = null, this.logPrefix = "", this.log = void 0, this.warn = void 0, this.playlistType = r, this.logPrefix = i, this.log = v.log.bind(v, `${i}:`), this.warn = v.warn.bind(v, `${i}:`), this.hls = e, this.fragmentLoader = new Zo(e.config), this.keyLoader = s, this.fragmentTracker = t, this.config = e.config, this.decrypter = new Hs(e.config), e.on(p.MANIFEST_LOADED, this.onManifestLoaded, this);
  }
  doTick() {
    this.onTickEnd();
  }
  onTickEnd() {
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  startLoad(e) {
  }
  stopLoad() {
    this.fragmentLoader.abort(), this.keyLoader.abort(this.playlistType);
    const e = this.fragCurrent;
    e != null && e.loader && (e.abortRequests(), this.fragmentTracker.removeFragment(e)), this.resetTransmuxer(), this.fragCurrent = null, this.fragPrevious = null, this.clearInterval(), this.clearNextTick(), this.state = C.STOPPED;
  }
  _streamEnded(e, t) {
    if (t.live || e.nextStart || !e.end || !this.media)
      return !1;
    const s = t.partList;
    if (s != null && s.length) {
      const r = s[s.length - 1];
      return J.isBuffered(this.media, r.start + r.duration / 2);
    }
    const i = t.fragments[t.fragments.length - 1].type;
    return this.fragmentTracker.isEndListAppended(i);
  }
  getLevelDetails() {
    if (this.levels && this.levelLastLoaded !== null) {
      var e;
      return (e = this.levelLastLoaded) == null ? void 0 : e.details;
    }
  }
  onMediaAttached(e, t) {
    const s = this.media = this.mediaBuffer = t.media;
    this.onvseeking = this.onMediaSeeking.bind(this), this.onvended = this.onMediaEnded.bind(this), s.addEventListener("seeking", this.onvseeking), s.addEventListener("ended", this.onvended);
    const i = this.config;
    this.levels && i.autoStartLoad && this.state === C.STOPPED && this.startLoad(i.startPosition);
  }
  onMediaDetaching() {
    const e = this.media;
    e != null && e.ended && (this.log("MSE detaching and video ended, reset startPosition"), this.startPosition = this.lastCurrentTime = 0), e && this.onvseeking && this.onvended && (e.removeEventListener("seeking", this.onvseeking), e.removeEventListener("ended", this.onvended), this.onvseeking = this.onvended = null), this.keyLoader && this.keyLoader.detach(), this.media = this.mediaBuffer = null, this.loadedmetadata = !1, this.fragmentTracker.removeAllFragments(), this.stopLoad();
  }
  onMediaSeeking() {
    const {
      config: e,
      fragCurrent: t,
      media: s,
      mediaBuffer: i,
      state: r
    } = this, a = s ? s.currentTime : 0, o = J.bufferInfo(i || s, a, e.maxBufferHole);
    if (this.log(`media seeking to ${M(a) ? a.toFixed(3) : a}, state: ${r}`), this.state === C.ENDED)
      this.resetLoadingState();
    else if (t) {
      const l = e.maxFragLookUpTolerance, c = t.start - l, h = t.start + t.duration + l;
      if (!o.len || h < o.start || c > o.end) {
        const u = a > h;
        (a < c || u) && (u && t.loader && (this.log("seeking outside of buffer while fragment load in progress, cancel fragment load"), t.abortRequests(), this.resetLoadingState()), this.fragPrevious = null);
      }
    }
    s && (this.fragmentTracker.removeFragmentsInRange(a, 1 / 0, this.playlistType, !0), this.lastCurrentTime = a), !this.loadedmetadata && !o.len && (this.nextLoadPosition = this.startPosition = a), this.tickImmediate();
  }
  onMediaEnded() {
    this.startPosition = this.lastCurrentTime = 0;
  }
  onManifestLoaded(e, t) {
    this.startTimeOffset = t.startTimeOffset, this.initPTS = [];
  }
  onHandlerDestroying() {
    this.hls.off(p.MANIFEST_LOADED, this.onManifestLoaded, this), this.stopLoad(), super.onHandlerDestroying(), this.hls = null;
  }
  onHandlerDestroyed() {
    this.state = C.STOPPED, this.fragmentLoader && this.fragmentLoader.destroy(), this.keyLoader && this.keyLoader.destroy(), this.decrypter && this.decrypter.destroy(), this.hls = this.log = this.warn = this.decrypter = this.keyLoader = this.fragmentLoader = this.fragmentTracker = null, super.onHandlerDestroyed();
  }
  loadFragment(e, t, s) {
    this._loadFragForPlayback(e, t, s);
  }
  _loadFragForPlayback(e, t, s) {
    const i = (r) => {
      if (this.fragContextChanged(e)) {
        this.warn(`Fragment ${e.sn}${r.part ? " p: " + r.part.index : ""} of level ${e.level} was dropped during download.`), this.fragmentTracker.removeFragment(e);
        return;
      }
      e.stats.chunkCount++, this._handleFragmentLoadProgress(r);
    };
    this._doFragLoad(e, t, s, i).then((r) => {
      if (!r)
        return;
      const a = this.state;
      if (this.fragContextChanged(e)) {
        (a === C.FRAG_LOADING || !this.fragCurrent && a === C.PARSING) && (this.fragmentTracker.removeFragment(e), this.state = C.IDLE);
        return;
      }
      "payload" in r && (this.log(`Loaded fragment ${e.sn} of level ${e.level}`), this.hls.trigger(p.FRAG_LOADED, r)), this._handleFragmentLoadComplete(r);
    }).catch((r) => {
      this.state === C.STOPPED || this.state === C.ERROR || (this.warn(`Frag error: ${(r == null ? void 0 : r.message) || r}`), this.resetFragmentLoading(e));
    });
  }
  clearTrackerIfNeeded(e) {
    var t;
    const {
      fragmentTracker: s
    } = this;
    if (s.getState(e) === ae.APPENDING) {
      const r = e.type, a = this.getFwdBufferInfo(this.mediaBuffer, r), o = Math.max(e.duration, a ? a.len : this.config.maxBufferLength), l = this.backtrackFragment;
      ((l ? e.sn - l.sn : 0) === 1 || this.reduceMaxBufferLength(o, e.duration)) && s.removeFragment(e);
    } else ((t = this.mediaBuffer) == null ? void 0 : t.buffered.length) === 0 ? s.removeAllFragments() : s.hasParts(e.type) && (s.detectPartialFragments({
      frag: e,
      part: null,
      stats: e.stats,
      id: e.type
    }), s.getState(e) === ae.PARTIAL && s.removeFragment(e));
  }
  checkLiveUpdate(e) {
    if (e.updated && !e.live) {
      const t = e.fragments[e.fragments.length - 1];
      this.fragmentTracker.detectPartialFragments({
        frag: t,
        part: null,
        stats: t.stats,
        id: t.type
      });
    }
    e.fragments[0] || (e.deltaUpdateFailed = !0);
  }
  flushMainBuffer(e, t, s = null) {
    if (!(e - t))
      return;
    const i = {
      startOffset: e,
      endOffset: t,
      type: s
    };
    this.hls.trigger(p.BUFFER_FLUSHING, i);
  }
  _loadInitSegment(e, t) {
    this._doFragLoad(e, t).then((s) => {
      if (!s || this.fragContextChanged(e) || !this.levels)
        throw new Error("init load aborted");
      return s;
    }).then((s) => {
      const {
        hls: i
      } = this, {
        payload: r
      } = s, a = e.decryptdata;
      if (r && r.byteLength > 0 && a != null && a.key && a.iv && a.method === "AES-128") {
        const o = self.performance.now();
        return this.decrypter.decrypt(new Uint8Array(r), a.key.buffer, a.iv.buffer).catch((l) => {
          throw i.trigger(p.ERROR, {
            type: K.MEDIA_ERROR,
            details: L.FRAG_DECRYPT_ERROR,
            fatal: !1,
            error: l,
            reason: l.message,
            frag: e
          }), l;
        }).then((l) => {
          const c = self.performance.now();
          return i.trigger(p.FRAG_DECRYPTED, {
            frag: e,
            payload: l,
            stats: {
              tstart: o,
              tdecrypt: c
            }
          }), s.payload = l, this.completeInitSegmentLoad(s);
        });
      }
      return this.completeInitSegmentLoad(s);
    }).catch((s) => {
      this.state === C.STOPPED || this.state === C.ERROR || (this.warn(s), this.resetFragmentLoading(e));
    });
  }
  completeInitSegmentLoad(e) {
    const {
      levels: t
    } = this;
    if (!t)
      throw new Error("init load aborted, missing levels");
    const s = e.frag.stats;
    this.state = C.IDLE, e.frag.data = new Uint8Array(e.payload), s.parsing.start = s.buffering.start = self.performance.now(), s.parsing.end = s.buffering.end = self.performance.now(), this.tick();
  }
  fragContextChanged(e) {
    const {
      fragCurrent: t
    } = this;
    return !e || !t || e.sn !== t.sn || e.level !== t.level;
  }
  fragBufferedComplete(e, t) {
    var s, i, r, a;
    const o = this.mediaBuffer ? this.mediaBuffer : this.media;
    if (this.log(`Buffered ${e.type} sn: ${e.sn}${t ? " part: " + t.index : ""} of ${this.playlistType === G.MAIN ? "level" : "track"} ${e.level} (frag:[${((s = e.startPTS) != null ? s : NaN).toFixed(3)}-${((i = e.endPTS) != null ? i : NaN).toFixed(3)}] > buffer:${o ? nl.toString(J.getBuffered(o)) : "(detached)"})`), e.sn !== "initSegment") {
      var l;
      if (e.type !== G.SUBTITLE) {
        const h = e.elementaryStreams;
        if (!Object.keys(h).some((u) => !!h[u])) {
          this.state = C.IDLE;
          return;
        }
      }
      const c = (l = this.levels) == null ? void 0 : l[e.level];
      c != null && c.fragmentError && (this.log(`Resetting level fragment error count of ${c.fragmentError} on frag buffered`), c.fragmentError = 0);
    }
    this.state = C.IDLE, o && (!this.loadedmetadata && e.type == G.MAIN && o.buffered.length && ((r = this.fragCurrent) == null ? void 0 : r.sn) === ((a = this.fragPrevious) == null ? void 0 : a.sn) && (this.loadedmetadata = !0, this.seekToStartPos()), this.tick());
  }
  seekToStartPos() {
  }
  _handleFragmentLoadComplete(e) {
    const {
      transmuxer: t
    } = this;
    if (!t)
      return;
    const {
      frag: s,
      part: i,
      partsLoaded: r
    } = e, a = !r || r.length === 0 || r.some((l) => !l), o = new Vs(s.level, s.sn, s.stats.chunkCount + 1, 0, i ? i.index : -1, !a);
    t.flush(o);
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _handleFragmentLoadProgress(e) {
  }
  _doFragLoad(e, t, s = null, i) {
    var r;
    const a = t == null ? void 0 : t.details;
    if (!this.levels || !a)
      throw new Error(`frag load aborted, missing level${a ? "" : " detail"}s`);
    let o = null;
    if (e.encrypted && !((r = e.decryptdata) != null && r.key) ? (this.log(`Loading key for ${e.sn} of [${a.startSN}-${a.endSN}], ${this.logPrefix === "[stream-controller]" ? "level" : "track"} ${e.level}`), this.state = C.KEY_LOADING, this.fragCurrent = e, o = this.keyLoader.load(e).then((h) => {
      if (!this.fragContextChanged(h.frag))
        return this.hls.trigger(p.KEY_LOADED, h), this.state === C.KEY_LOADING && (this.state = C.IDLE), h;
    }), this.hls.trigger(p.KEY_LOADING, {
      frag: e
    }), this.fragCurrent === null && (o = Promise.reject(new Error("frag load aborted, context changed in KEY_LOADING")))) : !e.encrypted && a.encryptedFragments.length && this.keyLoader.loadClear(e, a.encryptedFragments), s = Math.max(e.start, s || 0), this.config.lowLatencyMode && e.sn !== "initSegment") {
      const h = a.partList;
      if (h && i) {
        s > e.end && a.fragmentHint && (e = a.fragmentHint);
        const u = this.getNextPart(h, e, s);
        if (u > -1) {
          const d = h[u];
          this.log(`Loading part sn: ${e.sn} p: ${d.index} cc: ${e.cc} of playlist [${a.startSN}-${a.endSN}] parts [0-${u}-${h.length - 1}] ${this.logPrefix === "[stream-controller]" ? "level" : "track"}: ${e.level}, target: ${parseFloat(s.toFixed(3))}`), this.nextLoadPosition = d.start + d.duration, this.state = C.FRAG_LOADING;
          let f;
          return o ? f = o.then((g) => !g || this.fragContextChanged(g.frag) ? null : this.doFragPartsLoad(e, d, t, i)).catch((g) => this.handleFragLoadError(g)) : f = this.doFragPartsLoad(e, d, t, i).catch((g) => this.handleFragLoadError(g)), this.hls.trigger(p.FRAG_LOADING, {
            frag: e,
            part: d,
            targetBufferTime: s
          }), this.fragCurrent === null ? Promise.reject(new Error("frag load aborted, context changed in FRAG_LOADING parts")) : f;
        } else if (!e.url || this.loadedEndOfParts(h, s))
          return Promise.resolve(null);
      }
    }
    this.log(`Loading fragment ${e.sn} cc: ${e.cc} ${a ? "of [" + a.startSN + "-" + a.endSN + "] " : ""}${this.logPrefix === "[stream-controller]" ? "level" : "track"}: ${e.level}, target: ${parseFloat(s.toFixed(3))}`), M(e.sn) && !this.bitrateTest && (this.nextLoadPosition = e.start + e.duration), this.state = C.FRAG_LOADING;
    const l = this.config.progressive;
    let c;
    return l && o ? c = o.then((h) => !h || this.fragContextChanged(h == null ? void 0 : h.frag) ? null : this.fragmentLoader.load(e, i)).catch((h) => this.handleFragLoadError(h)) : c = Promise.all([this.fragmentLoader.load(e, l ? i : void 0), o]).then(([h]) => (!l && h && i && i(h), h)).catch((h) => this.handleFragLoadError(h)), this.hls.trigger(p.FRAG_LOADING, {
      frag: e,
      targetBufferTime: s
    }), this.fragCurrent === null ? Promise.reject(new Error("frag load aborted, context changed in FRAG_LOADING")) : c;
  }
  doFragPartsLoad(e, t, s, i) {
    return new Promise((r, a) => {
      var o;
      const l = [], c = (o = s.details) == null ? void 0 : o.partList, h = (u) => {
        this.fragmentLoader.loadPart(e, u, i).then((d) => {
          l[u.index] = d;
          const f = d.part;
          this.hls.trigger(p.FRAG_LOADED, d);
          const g = wi(s, e.sn, u.index + 1) || Kr(c, e.sn, u.index + 1);
          if (g)
            h(g);
          else
            return r({
              frag: e,
              part: f,
              partsLoaded: l
            });
        }).catch(a);
      };
      h(t);
    });
  }
  handleFragLoadError(e) {
    if ("data" in e) {
      const t = e.data;
      e.data && t.details === L.INTERNAL_ABORTED ? this.handleFragLoadAborted(t.frag, t.part) : this.hls.trigger(p.ERROR, t);
    } else
      this.hls.trigger(p.ERROR, {
        type: K.OTHER_ERROR,
        details: L.INTERNAL_EXCEPTION,
        err: e,
        error: e,
        fatal: !0
      });
    return null;
  }
  _handleTransmuxerFlush(e) {
    const t = this.getCurrentContext(e);
    if (!t || this.state !== C.PARSING) {
      !this.fragCurrent && this.state !== C.STOPPED && this.state !== C.ERROR && (this.state = C.IDLE);
      return;
    }
    const {
      frag: s,
      part: i,
      level: r
    } = t, a = self.performance.now();
    s.stats.parsing.end = a, i && (i.stats.parsing.end = a), this.updateLevelTiming(s, i, r, e.partial);
  }
  getCurrentContext(e) {
    const {
      levels: t,
      fragCurrent: s
    } = this, {
      level: i,
      sn: r,
      part: a
    } = e;
    if (!(t != null && t[i]))
      return this.warn(`Levels object was unset while buffering fragment ${r} of level ${i}. The current chunk will not be buffered.`), null;
    const o = t[i], l = a > -1 ? wi(o, r, a) : null, c = l ? l.fragment : Io(o, r, s);
    return c ? (s && s !== c && (c.stats = s.stats), {
      frag: c,
      part: l,
      level: o
    }) : null;
  }
  bufferFragmentData(e, t, s, i, r) {
    var a;
    if (!e || this.state !== C.PARSING)
      return;
    const {
      data1: o,
      data2: l
    } = e;
    let c = o;
    if (o && l && (c = Te(o, l)), !((a = c) != null && a.length))
      return;
    const h = {
      type: e.type,
      frag: t,
      part: s,
      chunkMeta: i,
      parent: t.type,
      data: c
    };
    if (this.hls.trigger(p.BUFFER_APPENDING, h), e.dropped && e.independent && !s) {
      if (r)
        return;
      this.flushBufferGap(t);
    }
  }
  flushBufferGap(e) {
    const t = this.media;
    if (!t)
      return;
    if (!J.isBuffered(t, t.currentTime)) {
      this.flushMainBuffer(0, e.start);
      return;
    }
    const s = t.currentTime, i = J.bufferInfo(t, s, 0), r = e.duration, a = Math.min(this.config.maxFragLookUpTolerance * 2, r * 0.25), o = Math.max(Math.min(e.start - a, i.end - a), s + a);
    e.start - o > a && this.flushMainBuffer(o, e.start);
  }
  getFwdBufferInfo(e, t) {
    const s = this.getLoadPosition();
    return M(s) ? this.getFwdBufferInfoAtPos(e, s, t) : null;
  }
  getFwdBufferInfoAtPos(e, t, s) {
    const {
      config: {
        maxBufferHole: i
      }
    } = this, r = J.bufferInfo(e, t, i);
    if (r.len === 0 && r.nextStart !== void 0) {
      const a = this.fragmentTracker.getBufferedFrag(t, s);
      if (a && r.nextStart < a.end)
        return J.bufferInfo(e, t, Math.max(r.nextStart, i));
    }
    return r;
  }
  getMaxBufferLength(e) {
    const {
      config: t
    } = this;
    let s;
    return e ? s = Math.max(8 * t.maxBufferSize / e, t.maxBufferLength) : s = t.maxBufferLength, Math.min(s, t.maxMaxBufferLength);
  }
  reduceMaxBufferLength(e, t) {
    const s = this.config, i = Math.max(Math.min(e - t, s.maxBufferLength), t), r = Math.max(e - t * 3, s.maxMaxBufferLength / 2, i);
    return r >= i ? (s.maxMaxBufferLength = r, this.warn(`Reduce max buffer length to ${r}s`), !0) : !1;
  }
  getAppendedFrag(e, t = G.MAIN) {
    const s = this.fragmentTracker.getAppendedFrag(e, G.MAIN);
    return s && "fragment" in s ? s.fragment : s;
  }
  getNextFragment(e, t) {
    const s = t.fragments, i = s.length;
    if (!i)
      return null;
    const {
      config: r
    } = this, a = s[0].start;
    let o;
    if (t.live) {
      const l = r.initialLiveManifestSize;
      if (i < l)
        return this.warn(`Not enough fragments to start playback (have: ${i}, need: ${l})`), null;
      (!t.PTSKnown && !this.startFragRequested && this.startPosition === -1 || e < a) && (o = this.getInitialLiveFragment(t, s), this.startPosition = this.nextLoadPosition = o ? this.hls.liveSyncPosition || o.start : e);
    } else e <= a && (o = s[0]);
    if (!o) {
      const l = r.lowLatencyMode ? t.partEnd : t.fragmentEnd;
      o = this.getFragmentAtPosition(e, l, t);
    }
    return this.mapToInitFragWhenRequired(o);
  }
  isLoopLoading(e, t) {
    const s = this.fragmentTracker.getState(e);
    return (s === ae.OK || s === ae.PARTIAL && !!e.gap) && this.nextLoadPosition > t;
  }
  getNextFragmentLoopLoading(e, t, s, i, r) {
    const a = e.gap, o = this.getNextFragment(this.nextLoadPosition, t);
    if (o === null)
      return o;
    if (e = o, a && e && !e.gap && s.nextStart) {
      const l = this.getFwdBufferInfoAtPos(this.mediaBuffer ? this.mediaBuffer : this.media, s.nextStart, i);
      if (l !== null && s.len + l.len >= r)
        return this.log(`buffer full after gaps in "${i}" playlist starting at sn: ${e.sn}`), null;
    }
    return e;
  }
  mapToInitFragWhenRequired(e) {
    return e != null && e.initSegment && !(e != null && e.initSegment.data) && !this.bitrateTest ? e.initSegment : e;
  }
  getNextPart(e, t, s) {
    let i = -1, r = !1, a = !0;
    for (let o = 0, l = e.length; o < l; o++) {
      const c = e[o];
      if (a = a && !c.independent, i > -1 && s < c.start)
        break;
      const h = c.loaded;
      h ? i = -1 : (r || c.independent || a) && c.fragment === t && (i = o), r = h;
    }
    return i;
  }
  loadedEndOfParts(e, t) {
    const s = e[e.length - 1];
    return s && t > s.start && s.loaded;
  }
  /*
   This method is used find the best matching first fragment for a live playlist. This fragment is used to calculate the
   "sliding" of the playlist, which is its offset from the start of playback. After sliding we can compute the real
   start and end times for each fragment in the playlist (after which this method will not need to be called).
  */
  getInitialLiveFragment(e, t) {
    const s = this.fragPrevious;
    let i = null;
    if (s) {
      if (e.hasProgramDateTime && (this.log(`Live playlist, switching playlist, load frag with same PDT: ${s.programDateTime}`), i = Co(t, s.endProgramDateTime, this.config.maxFragLookUpTolerance)), !i) {
        const r = s.sn + 1;
        if (r >= e.startSN && r <= e.endSN) {
          const a = t[r - e.startSN];
          s.cc === a.cc && (i = a, this.log(`Live playlist, switching playlist, load frag with next SN: ${i.sn}`));
        }
        i || (i = wo(t, s.cc), i && this.log(`Live playlist, switching playlist, load frag with same CC: ${i.sn}`));
      }
    } else {
      const r = this.hls.liveSyncPosition;
      r !== null && (i = this.getFragmentAtPosition(r, this.bitrateTest ? e.fragmentEnd : e.edge, e));
    }
    return i;
  }
  /*
  This method finds the best matching fragment given the provided position.
   */
  getFragmentAtPosition(e, t, s) {
    const {
      config: i
    } = this;
    let {
      fragPrevious: r
    } = this, {
      fragments: a,
      endSN: o
    } = s;
    const {
      fragmentHint: l
    } = s, {
      maxFragLookUpTolerance: c
    } = i, h = s.partList, u = !!(i.lowLatencyMode && h != null && h.length && l);
    u && l && !this.bitrateTest && (a = a.concat(l), o = l.sn);
    let d;
    if (e < t) {
      const f = e > t - c ? 0 : c;
      d = Ut(r, a, e, f);
    } else
      d = a[a.length - 1];
    if (d) {
      const f = d.sn - s.startSN, g = this.fragmentTracker.getState(d);
      if ((g === ae.OK || g === ae.PARTIAL && d.gap) && (r = d), r && d.sn === r.sn && (!u || h[0].fragment.sn > d.sn) && r && d.level === r.level) {
        const E = a[f + 1];
        d.sn < o && this.fragmentTracker.getState(E) !== ae.OK ? d = E : d = null;
      }
    }
    return d;
  }
  synchronizeToLiveEdge(e) {
    const {
      config: t,
      media: s
    } = this;
    if (!s)
      return;
    const i = this.hls.liveSyncPosition, r = s.currentTime, a = e.fragments[0].start, o = e.edge, l = r >= a - t.maxFragLookUpTolerance && r <= o;
    if (i !== null && s.duration > i && (r < i || !l)) {
      const c = t.liveMaxLatencyDuration !== void 0 ? t.liveMaxLatencyDuration : t.liveMaxLatencyDurationCount * e.targetduration;
      (!l && s.readyState < 4 || r < o - c) && (this.loadedmetadata || (this.nextLoadPosition = i), s.readyState && (this.warn(`Playback: ${r.toFixed(3)} is located too far from the end of live sliding playlist: ${o}, reset currentTime to : ${i.toFixed(3)}`), s.currentTime = i));
    }
  }
  alignPlaylists(e, t, s) {
    const i = e.fragments.length;
    if (!i)
      return this.warn("No fragments in live playlist"), 0;
    const r = e.fragments[0].start, a = !t, o = e.alignedSliding && M(r);
    if (a || !o && !r) {
      const {
        fragPrevious: l
      } = this;
      Qo(l, s, e);
      const c = e.fragments[0].start;
      return this.log(`Live playlist sliding: ${c.toFixed(2)} start-sn: ${t ? t.startSN : "na"}->${e.startSN} prev-sn: ${l ? l.sn : "na"} fragments: ${i}`), c;
    }
    return r;
  }
  waitForCdnTuneIn(e) {
    return e.live && e.canBlockReload && e.partTarget && e.tuneInGoal > Math.max(e.partHoldBack, e.partTarget * 3);
  }
  setStartPosition(e, t) {
    let s = this.startPosition;
    if (s < t && (s = -1), s === -1 || this.lastCurrentTime === -1) {
      const i = this.startTimeOffset !== null, r = i ? this.startTimeOffset : e.startTimeOffset;
      r !== null && M(r) ? (s = t + r, r < 0 && (s += e.totalduration), s = Math.min(Math.max(t, s), t + e.totalduration), this.log(`Start time offset ${r} found in ${i ? "multivariant" : "media"} playlist, adjust startPosition to ${s}`), this.startPosition = s) : e.live ? s = this.hls.liveSyncPosition || t : this.startPosition = s = 0, this.lastCurrentTime = s;
    }
    this.nextLoadPosition = s;
  }
  getLoadPosition() {
    const {
      media: e
    } = this;
    let t = 0;
    return this.loadedmetadata && e ? t = e.currentTime : this.nextLoadPosition && (t = this.nextLoadPosition), t;
  }
  handleFragLoadAborted(e, t) {
    this.transmuxer && e.sn !== "initSegment" && e.stats.aborted && (this.warn(`Fragment ${e.sn}${t ? " part " + t.index : ""} of level ${e.level} was aborted`), this.resetFragmentLoading(e));
  }
  resetFragmentLoading(e) {
    (!this.fragCurrent || !this.fragContextChanged(e) && this.state !== C.FRAG_LOADING_WAITING_RETRY) && (this.state = C.IDLE);
  }
  onFragmentOrKeyLoadError(e, t) {
    if (t.chunkMeta && !t.frag) {
      const h = this.getCurrentContext(t.chunkMeta);
      h && (t.frag = h.frag);
    }
    const s = t.frag;
    if (!s || s.type !== e || !this.levels)
      return;
    if (this.fragContextChanged(s)) {
      var i;
      this.warn(`Frag load error must match current frag to retry ${s.url} > ${(i = this.fragCurrent) == null ? void 0 : i.url}`);
      return;
    }
    const r = t.details === L.FRAG_GAP;
    r && this.fragmentTracker.fragBuffered(s, !0);
    const a = t.errorAction, {
      action: o,
      retryCount: l = 0,
      retryConfig: c
    } = a || {};
    if (a && o === ce.RetryRequest && c) {
      this.resetStartWhenNotLoaded(this.levelLastLoaded);
      const h = $s(c, l);
      this.warn(`Fragment ${s.sn} of ${e} ${s.level} errored with ${t.details}, retrying loading ${l + 1}/${c.maxNumRetry} in ${h}ms`), a.resolved = !0, this.retryDate = self.performance.now() + h, this.state = C.FRAG_LOADING_WAITING_RETRY;
    } else if (c && a)
      if (this.resetFragmentErrors(e), l < c.maxNumRetry)
        !r && o !== ce.RemoveAlternatePermanently && (a.resolved = !0);
      else {
        v.warn(`${t.details} reached or exceeded max retry (${l})`);
        return;
      }
    else (a == null ? void 0 : a.action) === ce.SendAlternateToPenaltyBox ? this.state = C.WAITING_LEVEL : this.state = C.ERROR;
    this.tickImmediate();
  }
  reduceLengthAndFlushBuffer(e) {
    if (this.state === C.PARSING || this.state === C.PARSED) {
      const t = e.frag, s = e.parent, i = this.getFwdBufferInfo(this.mediaBuffer, s), r = i && i.len > 0.5;
      r && this.reduceMaxBufferLength(i.len, (t == null ? void 0 : t.duration) || 10);
      const a = !r;
      return a && this.warn(`Buffer full error while media.currentTime is not buffered, flush ${s} buffer`), t && (this.fragmentTracker.removeFragment(t), this.nextLoadPosition = t.start), this.resetLoadingState(), a;
    }
    return !1;
  }
  resetFragmentErrors(e) {
    e === G.AUDIO && (this.fragCurrent = null), this.loadedmetadata || (this.startFragRequested = !1), this.state !== C.STOPPED && (this.state = C.IDLE);
  }
  afterBufferFlushed(e, t, s) {
    if (!e)
      return;
    const i = J.getBuffered(e);
    this.fragmentTracker.detectEvictedFragments(t, i, s), this.state === C.ENDED && this.resetLoadingState();
  }
  resetLoadingState() {
    this.log("Reset loading state"), this.fragCurrent = null, this.fragPrevious = null, this.state = C.IDLE;
  }
  resetStartWhenNotLoaded(e) {
    if (!this.loadedmetadata) {
      this.startFragRequested = !1;
      const t = e ? e.details : null;
      t != null && t.live ? (this.startPosition = -1, this.setStartPosition(t, 0), this.resetLoadingState()) : this.nextLoadPosition = this.startPosition;
    }
  }
  resetWhenMissingContext(e) {
    this.warn(`The loading context changed while buffering fragment ${e.sn} of level ${e.level}. This chunk will not be buffered.`), this.removeUnbufferedFrags(), this.resetStartWhenNotLoaded(this.levelLastLoaded), this.resetLoadingState();
  }
  removeUnbufferedFrags(e = 0) {
    this.fragmentTracker.removeFragmentsInRange(e, 1 / 0, this.playlistType, !1, !0);
  }
  updateLevelTiming(e, t, s, i) {
    var r;
    const a = s.details;
    if (!a) {
      this.warn("level.details undefined");
      return;
    }
    if (!Object.keys(e.elementaryStreams).reduce((l, c) => {
      const h = e.elementaryStreams[c];
      if (h) {
        const u = h.endPTS - h.startPTS;
        if (u <= 0)
          return this.warn(`Could not parse fragment ${e.sn} ${c} duration reliably (${u})`), l || !1;
        const d = i ? 0 : Gr(a, e, h.startPTS, h.endPTS, h.startDTS, h.endDTS);
        return this.hls.trigger(p.LEVEL_PTS_UPDATED, {
          details: a,
          level: s,
          drift: d,
          type: c,
          frag: e,
          start: h.startPTS,
          end: h.endPTS
        }), !0;
      }
      return l;
    }, !1) && ((r = this.transmuxer) == null ? void 0 : r.error) === null) {
      const l = new Error(`Found no media in fragment ${e.sn} of level ${e.level} resetting transmuxer to fallback to playlist timing`);
      if (s.fragmentError === 0 && (s.fragmentError++, e.gap = !0, this.fragmentTracker.removeFragment(e), this.fragmentTracker.fragBuffered(e, !0)), this.warn(l.message), this.hls.trigger(p.ERROR, {
        type: K.MEDIA_ERROR,
        details: L.FRAG_PARSING_ERROR,
        fatal: !1,
        error: l,
        frag: e,
        reason: `Found no media in msn ${e.sn} of level "${s.url}"`
      }), !this.hls)
        return;
      this.resetTransmuxer();
    }
    this.state = C.PARSED, this.hls.trigger(p.FRAG_PARSED, {
      frag: e,
      part: t
    });
  }
  resetTransmuxer() {
    this.transmuxer && (this.transmuxer.destroy(), this.transmuxer = null);
  }
  recoverWorkerError(e) {
    e.event === "demuxerWorker" && (this.fragmentTracker.removeAllFragments(), this.resetTransmuxer(), this.resetStartWhenNotLoaded(this.levelLastLoaded), this.resetLoadingState());
  }
  set state(e) {
    const t = this._state;
    t !== e && (this._state = e, this.log(`${t}->${e}`));
  }
  get state() {
    return this._state;
  }
}
class qr {
  constructor() {
    this.chunks = [], this.dataLength = 0;
  }
  push(e) {
    this.chunks.push(e), this.dataLength += e.length;
  }
  flush() {
    const {
      chunks: e,
      dataLength: t
    } = this;
    let s;
    if (e.length)
      e.length === 1 ? s = e[0] : s = al(e, t);
    else return new Uint8Array(0);
    return this.reset(), s;
  }
  reset() {
    this.chunks.length = 0, this.dataLength = 0;
  }
}
function al(n, e) {
  const t = new Uint8Array(e);
  let s = 0;
  for (let i = 0; i < n.length; i++) {
    const r = n[i];
    t.set(r, s), s += r.length;
  }
  return t;
}
function ol() {
  return typeof __HLS_WORKER_BUNDLE__ == "function";
}
function ll() {
  const n = new self.Blob([`var exports={};var module={exports:exports};function define(f){f()};define.amd=true;(${__HLS_WORKER_BUNDLE__.toString()})(true);`], {
    type: "text/javascript"
  }), e = self.URL.createObjectURL(n);
  return {
    worker: new self.Worker(e),
    objectURL: e
  };
}
function cl(n) {
  const e = new self.URL(n, self.location.href).href;
  return {
    worker: new self.Worker(e),
    scriptURL: e
  };
}
function Le(n = "", e = 9e4) {
  return {
    type: n,
    id: -1,
    pid: -1,
    inputTimeScale: e,
    sequenceNumber: -1,
    samples: [],
    dropped: 0
  };
}
class Ys {
  constructor() {
    this._audioTrack = void 0, this._id3Track = void 0, this.frameIndex = 0, this.cachedData = null, this.basePTS = null, this.initPTS = null, this.lastPTS = null;
  }
  resetInitSegment(e, t, s, i) {
    this._id3Track = {
      type: "id3",
      id: 3,
      pid: -1,
      inputTimeScale: 9e4,
      sequenceNumber: 0,
      samples: [],
      dropped: 0
    };
  }
  resetTimeStamp(e) {
    this.initPTS = e, this.resetContiguity();
  }
  resetContiguity() {
    this.basePTS = null, this.lastPTS = null, this.frameIndex = 0;
  }
  canParse(e, t) {
    return !1;
  }
  appendFrame(e, t, s) {
  }
  // feed incoming data to the front of the parsing pipeline
  demux(e, t) {
    this.cachedData && (e = Te(this.cachedData, e), this.cachedData = null);
    let s = ot(e, 0), i = s ? s.length : 0, r;
    const a = this._audioTrack, o = this._id3Track, l = s ? Gs(s) : void 0, c = e.length;
    for ((this.basePTS === null || this.frameIndex === 0 && M(l)) && (this.basePTS = hl(l, t, this.initPTS), this.lastPTS = this.basePTS), this.lastPTS === null && (this.lastPTS = this.basePTS), s && s.length > 0 && o.samples.push({
      pts: this.lastPTS,
      dts: this.lastPTS,
      data: s,
      type: Se.audioId3,
      duration: Number.POSITIVE_INFINITY
    }); i < c; ) {
      if (this.canParse(e, i)) {
        const h = this.appendFrame(a, e, i);
        h ? (this.frameIndex++, this.lastPTS = h.sample.pts, i += h.length, r = i) : i = c;
      } else _a(e, i) ? (s = ot(e, i), o.samples.push({
        pts: this.lastPTS,
        dts: this.lastPTS,
        data: s,
        type: Se.audioId3,
        duration: Number.POSITIVE_INFINITY
      }), i += s.length, r = i) : i++;
      if (i === c && r !== c) {
        const h = Ge(e, r);
        this.cachedData ? this.cachedData = Te(this.cachedData, h) : this.cachedData = h;
      }
    }
    return {
      audioTrack: a,
      videoTrack: Le(),
      id3Track: o,
      textTrack: Le()
    };
  }
  demuxSampleAes(e, t, s) {
    return Promise.reject(new Error(`[${this}] This demuxer does not support Sample-AES decryption`));
  }
  flush(e) {
    const t = this.cachedData;
    return t && (this.cachedData = null, this.demux(t, 0)), {
      audioTrack: this._audioTrack,
      videoTrack: Le(),
      id3Track: this._id3Track,
      textTrack: Le()
    };
  }
  destroy() {
  }
}
const hl = (n, e, t) => {
  if (M(n))
    return n * 90;
  const s = t ? t.baseTime * 9e4 / t.timescale : 0;
  return e * 9e4 + s;
};
function ul(n, e, t, s) {
  let i, r, a, o;
  const l = navigator.userAgent.toLowerCase(), c = s, h = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350];
  i = ((e[t + 2] & 192) >>> 6) + 1;
  const u = (e[t + 2] & 60) >>> 2;
  if (u > h.length - 1) {
    const d = new Error(`invalid ADTS sampling index:${u}`);
    n.emit(p.ERROR, p.ERROR, {
      type: K.MEDIA_ERROR,
      details: L.FRAG_PARSING_ERROR,
      fatal: !0,
      error: d,
      reason: d.message
    });
    return;
  }
  return a = (e[t + 2] & 1) << 2, a |= (e[t + 3] & 192) >>> 6, v.log(`manifest codec:${s}, ADTS type:${i}, samplingIndex:${u}`), /firefox/i.test(l) ? u >= 6 ? (i = 5, o = new Array(4), r = u - 3) : (i = 2, o = new Array(2), r = u) : l.indexOf("android") !== -1 ? (i = 2, o = new Array(2), r = u) : (i = 5, o = new Array(4), s && (s.indexOf("mp4a.40.29") !== -1 || s.indexOf("mp4a.40.5") !== -1) || !s && u >= 6 ? r = u - 3 : ((s && s.indexOf("mp4a.40.2") !== -1 && (u >= 6 && a === 1 || /vivaldi/i.test(l)) || !s && a === 1) && (i = 2, o = new Array(2)), r = u)), o[0] = i << 3, o[0] |= (u & 14) >> 1, o[1] |= (u & 1) << 7, o[1] |= a << 3, i === 5 && (o[1] |= (r & 14) >> 1, o[2] = (r & 1) << 7, o[2] |= 8, o[3] = 0), {
    config: o,
    samplerate: h[u],
    channelCount: a,
    codec: "mp4a.40." + i,
    manifestCodec: c
  };
}
function jr(n, e) {
  return n[e] === 255 && (n[e + 1] & 246) === 240;
}
function zr(n, e) {
  return n[e + 1] & 1 ? 7 : 9;
}
function qs(n, e) {
  return (n[e + 3] & 3) << 11 | n[e + 4] << 3 | (n[e + 5] & 224) >>> 5;
}
function dl(n, e) {
  return e + 5 < n.length;
}
function Gt(n, e) {
  return e + 1 < n.length && jr(n, e);
}
function fl(n, e) {
  return dl(n, e) && jr(n, e) && qs(n, e) <= n.length - e;
}
function gl(n, e) {
  if (Gt(n, e)) {
    const t = zr(n, e);
    if (e + t >= n.length)
      return !1;
    const s = qs(n, e);
    if (s <= t)
      return !1;
    const i = e + s;
    return i === n.length || Gt(n, i);
  }
  return !1;
}
function Xr(n, e, t, s, i) {
  if (!n.samplerate) {
    const r = ul(e, t, s, i);
    if (!r)
      return;
    n.config = r.config, n.samplerate = r.samplerate, n.channelCount = r.channelCount, n.codec = r.codec, n.manifestCodec = r.manifestCodec, v.log(`parsed codec:${n.codec}, rate:${r.samplerate}, channels:${r.channelCount}`);
  }
}
function Qr(n) {
  return 1024 * 9e4 / n;
}
function ml(n, e) {
  const t = zr(n, e);
  if (e + t <= n.length) {
    const s = qs(n, e) - t;
    if (s > 0)
      return {
        headerLength: t,
        frameLength: s
      };
  }
}
function Jr(n, e, t, s, i) {
  const r = Qr(n.samplerate), a = s + i * r, o = ml(e, t);
  let l;
  if (o) {
    const {
      frameLength: u,
      headerLength: d
    } = o, f = d + u, g = Math.max(0, t + f - e.length);
    g ? (l = new Uint8Array(f - d), l.set(e.subarray(t + d, e.length), 0)) : l = e.subarray(t + d, t + f);
    const m = {
      unit: l,
      pts: a
    };
    return g || n.samples.push(m), {
      sample: m,
      length: f,
      missing: g
    };
  }
  const c = e.length - t;
  return l = new Uint8Array(c), l.set(e.subarray(t, e.length), 0), {
    sample: {
      unit: l,
      pts: a
    },
    length: c,
    missing: -1
  };
}
let pt = null;
const pl = [32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], El = [44100, 48e3, 32e3, 22050, 24e3, 16e3, 11025, 12e3, 8e3], Tl = [
  // MPEG 2.5
  [
    0,
    // Reserved
    72,
    // Layer3
    144,
    // Layer2
    12
    // Layer1
  ],
  // Reserved
  [
    0,
    // Reserved
    0,
    // Layer3
    0,
    // Layer2
    0
    // Layer1
  ],
  // MPEG 2
  [
    0,
    // Reserved
    72,
    // Layer3
    144,
    // Layer2
    12
    // Layer1
  ],
  // MPEG 1
  [
    0,
    // Reserved
    144,
    // Layer3
    144,
    // Layer2
    12
    // Layer1
  ]
], yl = [
  0,
  // Reserved
  1,
  // Layer3
  1,
  // Layer2
  4
  // Layer1
];
function Zr(n, e, t, s, i) {
  if (t + 24 > e.length)
    return;
  const r = en(e, t);
  if (r && t + r.frameLength <= e.length) {
    const a = r.samplesPerFrame * 9e4 / r.sampleRate, o = s + i * a, l = {
      unit: e.subarray(t, t + r.frameLength),
      pts: o,
      dts: o
    };
    return n.config = [], n.channelCount = r.channelCount, n.samplerate = r.sampleRate, n.samples.push(l), {
      sample: l,
      length: r.frameLength,
      missing: 0
    };
  }
}
function en(n, e) {
  const t = n[e + 1] >> 3 & 3, s = n[e + 1] >> 1 & 3, i = n[e + 2] >> 4 & 15, r = n[e + 2] >> 2 & 3;
  if (t !== 1 && i !== 0 && i !== 15 && r !== 3) {
    const a = n[e + 2] >> 1 & 1, o = n[e + 3] >> 6, l = t === 3 ? 3 - s : s === 3 ? 3 : 4, c = pl[l * 14 + i - 1] * 1e3, u = El[(t === 3 ? 0 : t === 2 ? 1 : 2) * 3 + r], d = o === 3 ? 1 : 2, f = Tl[t][s], g = yl[s], m = f * 8 * g, E = Math.floor(f * c / u + a) * g;
    if (pt === null) {
      const x = (navigator.userAgent || "").match(/Chrome\/(\d+)/i);
      pt = x ? parseInt(x[1]) : 0;
    }
    return !!pt && pt <= 87 && s === 2 && c >= 224e3 && o === 0 && (n[e + 3] = n[e + 3] | 128), {
      sampleRate: u,
      channelCount: d,
      frameLength: E,
      samplesPerFrame: m
    };
  }
}
function js(n, e) {
  return n[e] === 255 && (n[e + 1] & 224) === 224 && (n[e + 1] & 6) !== 0;
}
function tn(n, e) {
  return e + 1 < n.length && js(n, e);
}
function xl(n, e) {
  return js(n, e) && 4 <= n.length - e;
}
function sn(n, e) {
  if (e + 1 < n.length && js(n, e)) {
    const s = en(n, e);
    let i = 4;
    s != null && s.frameLength && (i = s.frameLength);
    const r = e + i;
    return r === n.length || tn(n, r);
  }
  return !1;
}
class Sl extends Ys {
  constructor(e, t) {
    super(), this.observer = void 0, this.config = void 0, this.observer = e, this.config = t;
  }
  resetInitSegment(e, t, s, i) {
    super.resetInitSegment(e, t, s, i), this._audioTrack = {
      container: "audio/adts",
      type: "audio",
      id: 2,
      pid: -1,
      sequenceNumber: 0,
      segmentCodec: "aac",
      samples: [],
      manifestCodec: t,
      duration: i,
      inputTimeScale: 9e4,
      dropped: 0
    };
  }
  // Source for probe info - https://wiki.multimedia.cx/index.php?title=ADTS
  static probe(e) {
    if (!e)
      return !1;
    const t = ot(e, 0);
    let s = (t == null ? void 0 : t.length) || 0;
    if (sn(e, s))
      return !1;
    for (let i = e.length; s < i; s++)
      if (gl(e, s))
        return v.log("ADTS sync word found !"), !0;
    return !1;
  }
  canParse(e, t) {
    return fl(e, t);
  }
  appendFrame(e, t, s) {
    Xr(e, this.observer, t, s, e.manifestCodec);
    const i = Jr(e, t, s, this.basePTS, this.frameIndex);
    if (i && i.missing === 0)
      return i;
  }
}
const vl = /\/emsg[-/]ID3/i;
class Al {
  constructor(e, t) {
    this.remainderData = null, this.timeOffset = 0, this.config = void 0, this.videoTrack = void 0, this.audioTrack = void 0, this.id3Track = void 0, this.txtTrack = void 0, this.config = t;
  }
  resetTimeStamp() {
  }
  resetInitSegment(e, t, s, i) {
    const r = this.videoTrack = Le("video", 1), a = this.audioTrack = Le("audio", 1), o = this.txtTrack = Le("text", 1);
    if (this.id3Track = Le("id3", 1), this.timeOffset = 0, !(e != null && e.byteLength))
      return;
    const l = wr(e);
    if (l.video) {
      const {
        id: c,
        timescale: h,
        codec: u
      } = l.video;
      r.id = c, r.timescale = o.timescale = h, r.codec = u;
    }
    if (l.audio) {
      const {
        id: c,
        timescale: h,
        codec: u
      } = l.audio;
      a.id = c, a.timescale = h, a.codec = u;
    }
    o.id = Cr.text, r.sampleDuration = 0, r.duration = a.duration = i;
  }
  resetContiguity() {
    this.remainderData = null;
  }
  static probe(e) {
    return Ba(e);
  }
  demux(e, t) {
    this.timeOffset = t;
    let s = e;
    const i = this.videoTrack, r = this.txtTrack;
    if (this.config.progressive) {
      this.remainderData && (s = Te(this.remainderData, e));
      const o = qa(s);
      this.remainderData = o.remainder, i.samples = o.valid || new Uint8Array();
    } else
      i.samples = s;
    const a = this.extractID3Track(i, t);
    return r.samples = fi(t, i), {
      videoTrack: i,
      audioTrack: this.audioTrack,
      id3Track: a,
      textTrack: this.txtTrack
    };
  }
  flush() {
    const e = this.timeOffset, t = this.videoTrack, s = this.txtTrack;
    t.samples = this.remainderData || new Uint8Array(), this.remainderData = null;
    const i = this.extractID3Track(t, this.timeOffset);
    return s.samples = fi(e, t), {
      videoTrack: t,
      audioTrack: Le(),
      id3Track: i,
      textTrack: Le()
    };
  }
  extractID3Track(e, t) {
    const s = this.id3Track;
    if (e.samples.length) {
      const i = H(e.samples, ["emsg"]);
      i && i.forEach((r) => {
        const a = Xa(r);
        if (vl.test(a.schemeIdUri)) {
          const o = M(a.presentationTime) ? a.presentationTime / a.timeScale : t + a.presentationTimeDelta / a.timeScale;
          let l = a.eventDuration === 4294967295 ? Number.POSITIVE_INFINITY : a.eventDuration / a.timeScale;
          l <= 1e-3 && (l = Number.POSITIVE_INFINITY);
          const c = a.payload;
          s.samples.push({
            data: c,
            len: c.byteLength,
            dts: o,
            pts: o,
            type: Se.emsg,
            duration: l
          });
        }
      });
    }
    return s;
  }
  demuxSampleAes(e, t, s) {
    return Promise.reject(new Error("The MP4 demuxer does not support SAMPLE-AES decryption"));
  }
  destroy() {
  }
}
const rn = (n, e) => {
  let t = 0, s = 5;
  e += s;
  const i = new Uint32Array(1), r = new Uint32Array(1), a = new Uint8Array(1);
  for (; s > 0; ) {
    a[0] = n[e];
    const o = Math.min(s, 8), l = 8 - o;
    r[0] = 4278190080 >>> 24 + l << l, i[0] = (a[0] & r[0]) >> l, t = t ? t << o | i[0] : i[0], e += 1, s -= o;
  }
  return t;
};
class Ll extends Ys {
  constructor(e) {
    super(), this.observer = void 0, this.observer = e;
  }
  resetInitSegment(e, t, s, i) {
    super.resetInitSegment(e, t, s, i), this._audioTrack = {
      container: "audio/ac-3",
      type: "audio",
      id: 2,
      pid: -1,
      sequenceNumber: 0,
      segmentCodec: "ac3",
      samples: [],
      manifestCodec: t,
      duration: i,
      inputTimeScale: 9e4,
      dropped: 0
    };
  }
  canParse(e, t) {
    return t + 64 < e.length;
  }
  appendFrame(e, t, s) {
    const i = nn(e, t, s, this.basePTS, this.frameIndex);
    if (i !== -1)
      return {
        sample: e.samples[e.samples.length - 1],
        length: i,
        missing: 0
      };
  }
  static probe(e) {
    if (!e)
      return !1;
    const t = ot(e, 0);
    if (!t)
      return !1;
    const s = t.length;
    return e[s] === 11 && e[s + 1] === 119 && Gs(t) !== void 0 && // check the bsid to confirm ac-3
    rn(e, s) < 16;
  }
}
function nn(n, e, t, s, i) {
  if (t + 8 > e.length || e[t] !== 11 || e[t + 1] !== 119)
    return -1;
  const r = e[t + 4] >> 6;
  if (r >= 3)
    return -1;
  const o = [48e3, 44100, 32e3][r], l = e[t + 4] & 63, h = [64, 69, 96, 64, 70, 96, 80, 87, 120, 80, 88, 120, 96, 104, 144, 96, 105, 144, 112, 121, 168, 112, 122, 168, 128, 139, 192, 128, 140, 192, 160, 174, 240, 160, 175, 240, 192, 208, 288, 192, 209, 288, 224, 243, 336, 224, 244, 336, 256, 278, 384, 256, 279, 384, 320, 348, 480, 320, 349, 480, 384, 417, 576, 384, 418, 576, 448, 487, 672, 448, 488, 672, 512, 557, 768, 512, 558, 768, 640, 696, 960, 640, 697, 960, 768, 835, 1152, 768, 836, 1152, 896, 975, 1344, 896, 976, 1344, 1024, 1114, 1536, 1024, 1115, 1536, 1152, 1253, 1728, 1152, 1254, 1728, 1280, 1393, 1920, 1280, 1394, 1920][l * 3 + r] * 2;
  if (t + h > e.length)
    return -1;
  const u = e[t + 6] >> 5;
  let d = 0;
  u === 2 ? d += 2 : (u & 1 && u !== 1 && (d += 2), u & 4 && (d += 2));
  const f = (e[t + 6] << 8 | e[t + 7]) >> 12 - d & 1, m = [2, 1, 2, 3, 3, 4, 4, 5][u] + f, E = e[t + 5] >> 3, T = e[t + 5] & 7, y = new Uint8Array([r << 6 | E << 1 | T >> 2, (T & 3) << 6 | u << 3 | f << 2 | l >> 4, l << 4 & 224]), x = 1536 / o * 9e4, b = s + i * x, S = e.subarray(t, t + h);
  return n.config = y, n.channelCount = m, n.samplerate = o, n.samples.push({
    unit: S,
    pts: b
  }), h;
}
class Rl {
  constructor() {
    this.VideoSample = null;
  }
  createVideoSample(e, t, s, i) {
    return {
      key: e,
      frame: !1,
      pts: t,
      dts: s,
      units: [],
      debug: i,
      length: 0
    };
  }
  getLastNalUnit(e) {
    var t;
    let s = this.VideoSample, i;
    if ((!s || s.units.length === 0) && (s = e[e.length - 1]), (t = s) != null && t.units) {
      const r = s.units;
      i = r[r.length - 1];
    }
    return i;
  }
  pushAccessUnit(e, t) {
    if (e.units.length && e.frame) {
      if (e.pts === void 0) {
        const s = t.samples, i = s.length;
        if (i) {
          const r = s[i - 1];
          e.pts = r.pts, e.dts = r.dts;
        } else {
          t.dropped++;
          return;
        }
      }
      t.samples.push(e);
    }
    e.debug.length && v.log(e.pts + "/" + e.dts + ":" + e.debug);
  }
}
class $i {
  constructor(e) {
    this.data = void 0, this.bytesAvailable = void 0, this.word = void 0, this.bitsAvailable = void 0, this.data = e, this.bytesAvailable = e.byteLength, this.word = 0, this.bitsAvailable = 0;
  }
  // ():void
  loadWord() {
    const e = this.data, t = this.bytesAvailable, s = e.byteLength - t, i = new Uint8Array(4), r = Math.min(4, t);
    if (r === 0)
      throw new Error("no bytes available");
    i.set(e.subarray(s, s + r)), this.word = new DataView(i.buffer).getUint32(0), this.bitsAvailable = r * 8, this.bytesAvailable -= r;
  }
  // (count:int):void
  skipBits(e) {
    let t;
    e = Math.min(e, this.bytesAvailable * 8 + this.bitsAvailable), this.bitsAvailable > e ? (this.word <<= e, this.bitsAvailable -= e) : (e -= this.bitsAvailable, t = e >> 3, e -= t << 3, this.bytesAvailable -= t, this.loadWord(), this.word <<= e, this.bitsAvailable -= e);
  }
  // (size:int):uint
  readBits(e) {
    let t = Math.min(this.bitsAvailable, e);
    const s = this.word >>> 32 - t;
    if (e > 32 && v.error("Cannot read more than 32 bits at a time"), this.bitsAvailable -= t, this.bitsAvailable > 0)
      this.word <<= t;
    else if (this.bytesAvailable > 0)
      this.loadWord();
    else
      throw new Error("no bits available");
    return t = e - t, t > 0 && this.bitsAvailable ? s << t | this.readBits(t) : s;
  }
  // ():uint
  skipLZ() {
    let e;
    for (e = 0; e < this.bitsAvailable; ++e)
      if (this.word & 2147483648 >>> e)
        return this.word <<= e, this.bitsAvailable -= e, e;
    return this.loadWord(), e + this.skipLZ();
  }
  // ():void
  skipUEG() {
    this.skipBits(1 + this.skipLZ());
  }
  // ():void
  skipEG() {
    this.skipBits(1 + this.skipLZ());
  }
  // ():uint
  readUEG() {
    const e = this.skipLZ();
    return this.readBits(e + 1) - 1;
  }
  // ():int
  readEG() {
    const e = this.readUEG();
    return 1 & e ? 1 + e >>> 1 : -1 * (e >>> 1);
  }
  // Some convenience functions
  // :Boolean
  readBoolean() {
    return this.readBits(1) === 1;
  }
  // ():int
  readUByte() {
    return this.readBits(8);
  }
  // ():int
  readUShort() {
    return this.readBits(16);
  }
  // ():int
  readUInt() {
    return this.readBits(32);
  }
  /**
   * Advance the ExpGolomb decoder past a scaling list. The scaling
   * list is optionally transmitted as part of a sequence parameter
   * set and is not relevant to transmuxing.
   * @param count the number of entries in this scaling list
   * @see Recommendation ITU-T H.264, Section 7.3.2.1.1.1
   */
  skipScalingList(e) {
    let t = 8, s = 8, i;
    for (let r = 0; r < e; r++)
      s !== 0 && (i = this.readEG(), s = (t + i + 256) % 256), t = s === 0 ? t : s;
  }
  /**
   * Read a sequence parameter set and return some interesting video
   * properties. A sequence parameter set is the H264 metadata that
   * describes the properties of upcoming video frames.
   * @returns an object with configuration parsed from the
   * sequence parameter set, including the dimensions of the
   * associated video frames.
   */
  readSPS() {
    let e = 0, t = 0, s = 0, i = 0, r, a, o;
    const l = this.readUByte.bind(this), c = this.readBits.bind(this), h = this.readUEG.bind(this), u = this.readBoolean.bind(this), d = this.skipBits.bind(this), f = this.skipEG.bind(this), g = this.skipUEG.bind(this), m = this.skipScalingList.bind(this);
    l();
    const E = l();
    if (c(5), d(3), l(), g(), E === 100 || E === 110 || E === 122 || E === 244 || E === 44 || E === 83 || E === 86 || E === 118 || E === 128) {
      const D = h();
      if (D === 3 && d(1), g(), g(), d(1), u())
        for (a = D !== 3 ? 8 : 12, o = 0; o < a; o++)
          u() && (o < 6 ? m(16) : m(64));
    }
    g();
    const T = h();
    if (T === 0)
      h();
    else if (T === 1)
      for (d(1), f(), f(), r = h(), o = 0; o < r; o++)
        f();
    g(), d(1);
    const y = h(), x = h(), b = c(1);
    b === 0 && d(1), d(1), u() && (e = h(), t = h(), s = h(), i = h());
    let S = [1, 1];
    if (u() && u())
      switch (l()) {
        case 1:
          S = [1, 1];
          break;
        case 2:
          S = [12, 11];
          break;
        case 3:
          S = [10, 11];
          break;
        case 4:
          S = [16, 11];
          break;
        case 5:
          S = [40, 33];
          break;
        case 6:
          S = [24, 11];
          break;
        case 7:
          S = [20, 11];
          break;
        case 8:
          S = [32, 11];
          break;
        case 9:
          S = [80, 33];
          break;
        case 10:
          S = [18, 11];
          break;
        case 11:
          S = [15, 11];
          break;
        case 12:
          S = [64, 33];
          break;
        case 13:
          S = [160, 99];
          break;
        case 14:
          S = [4, 3];
          break;
        case 15:
          S = [3, 2];
          break;
        case 16:
          S = [2, 1];
          break;
        case 255: {
          S = [l() << 8 | l(), l() << 8 | l()];
          break;
        }
      }
    return {
      width: Math.ceil((y + 1) * 16 - e * 2 - t * 2),
      height: (2 - b) * (x + 1) * 16 - (b ? 2 : 4) * (s + i),
      pixelRatio: S
    };
  }
  readSliceType() {
    return this.readUByte(), this.readUEG(), this.readUEG();
  }
}
class bl extends Rl {
  parseAVCPES(e, t, s, i, r) {
    const a = this.parseAVCNALu(e, s.data);
    let o = this.VideoSample, l, c = !1;
    s.data = null, o && a.length && !e.audFound && (this.pushAccessUnit(o, e), o = this.VideoSample = this.createVideoSample(!1, s.pts, s.dts, "")), a.forEach((h) => {
      var u;
      switch (h.type) {
        case 1: {
          let m = !1;
          l = !0;
          const E = h.data;
          if (c && E.length > 4) {
            const T = new $i(E).readSliceType();
            (T === 2 || T === 4 || T === 7 || T === 9) && (m = !0);
          }
          if (m) {
            var d;
            (d = o) != null && d.frame && !o.key && (this.pushAccessUnit(o, e), o = this.VideoSample = null);
          }
          o || (o = this.VideoSample = this.createVideoSample(!0, s.pts, s.dts, "")), o.frame = !0, o.key = m;
          break;
        }
        case 5:
          l = !0, (u = o) != null && u.frame && !o.key && (this.pushAccessUnit(o, e), o = this.VideoSample = null), o || (o = this.VideoSample = this.createVideoSample(!0, s.pts, s.dts, "")), o.key = !0, o.frame = !0;
          break;
        case 6: {
          l = !0, Fr(h.data, 1, s.pts, t.samples);
          break;
        }
        case 7: {
          var f, g;
          l = !0, c = !0;
          const m = h.data, T = new $i(m).readSPS();
          if (!e.sps || e.width !== T.width || e.height !== T.height || ((f = e.pixelRatio) == null ? void 0 : f[0]) !== T.pixelRatio[0] || ((g = e.pixelRatio) == null ? void 0 : g[1]) !== T.pixelRatio[1]) {
            e.width = T.width, e.height = T.height, e.pixelRatio = T.pixelRatio, e.sps = [m], e.duration = r;
            const y = m.subarray(1, 4);
            let x = "avc1.";
            for (let b = 0; b < 3; b++) {
              let S = y[b].toString(16);
              S.length < 2 && (S = "0" + S), x += S;
            }
            e.codec = x;
          }
          break;
        }
        case 8:
          l = !0, e.pps = [h.data];
          break;
        case 9:
          l = !0, e.audFound = !0, o && this.pushAccessUnit(o, e), o = this.VideoSample = this.createVideoSample(!1, s.pts, s.dts, "");
          break;
        case 12:
          l = !0;
          break;
        default:
          l = !1, o && (o.debug += "unknown NAL " + h.type + " ");
          break;
      }
      o && l && o.units.push(h);
    }), i && o && (this.pushAccessUnit(o, e), this.VideoSample = null);
  }
  parseAVCNALu(e, t) {
    const s = t.byteLength;
    let i = e.naluState || 0;
    const r = i, a = [];
    let o = 0, l, c, h, u = -1, d = 0;
    for (i === -1 && (u = 0, d = t[0] & 31, i = 0, o = 1); o < s; ) {
      if (l = t[o++], !i) {
        i = l ? 0 : 1;
        continue;
      }
      if (i === 1) {
        i = l ? 0 : 2;
        continue;
      }
      if (!l)
        i = 3;
      else if (l === 1) {
        if (c = o - i - 1, u >= 0) {
          const f = {
            data: t.subarray(u, c),
            type: d
          };
          a.push(f);
        } else {
          const f = this.getLastNalUnit(e.samples);
          f && (r && o <= 4 - r && f.state && (f.data = f.data.subarray(0, f.data.byteLength - r)), c > 0 && (f.data = Te(f.data, t.subarray(0, c)), f.state = 0));
        }
        o < s ? (h = t[o] & 31, u = o, d = h, i = 0) : i = -1;
      } else
        i = 0;
    }
    if (u >= 0 && i >= 0) {
      const f = {
        data: t.subarray(u, s),
        type: d,
        state: i
      };
      a.push(f);
    }
    if (a.length === 0) {
      const f = this.getLastNalUnit(e.samples);
      f && (f.data = Te(f.data, t));
    }
    return e.naluState = i, a;
  }
}
class Il {
  constructor(e, t, s) {
    this.keyData = void 0, this.decrypter = void 0, this.keyData = s, this.decrypter = new Hs(t, {
      removePKCS7Padding: !1
    });
  }
  decryptBuffer(e) {
    return this.decrypter.decrypt(e, this.keyData.key.buffer, this.keyData.iv.buffer);
  }
  // AAC - encrypt all full 16 bytes blocks starting from offset 16
  decryptAacSample(e, t, s) {
    const i = e[t].unit;
    if (i.length <= 16)
      return;
    const r = i.subarray(16, i.length - i.length % 16), a = r.buffer.slice(r.byteOffset, r.byteOffset + r.length);
    this.decryptBuffer(a).then((o) => {
      const l = new Uint8Array(o);
      i.set(l, 16), this.decrypter.isSync() || this.decryptAacSamples(e, t + 1, s);
    });
  }
  decryptAacSamples(e, t, s) {
    for (; ; t++) {
      if (t >= e.length) {
        s();
        return;
      }
      if (!(e[t].unit.length < 32) && (this.decryptAacSample(e, t, s), !this.decrypter.isSync()))
        return;
    }
  }
  // AVC - encrypt one 16 bytes block out of ten, starting from offset 32
  getAvcEncryptedData(e) {
    const t = Math.floor((e.length - 48) / 160) * 16 + 16, s = new Int8Array(t);
    let i = 0;
    for (let r = 32; r < e.length - 16; r += 160, i += 16)
      s.set(e.subarray(r, r + 16), i);
    return s;
  }
  getAvcDecryptedUnit(e, t) {
    const s = new Uint8Array(t);
    let i = 0;
    for (let r = 32; r < e.length - 16; r += 160, i += 16)
      e.set(s.subarray(i, i + 16), r);
    return e;
  }
  decryptAvcSample(e, t, s, i, r) {
    const a = Or(r.data), o = this.getAvcEncryptedData(a);
    this.decryptBuffer(o.buffer).then((l) => {
      r.data = this.getAvcDecryptedUnit(a, l), this.decrypter.isSync() || this.decryptAvcSamples(e, t, s + 1, i);
    });
  }
  decryptAvcSamples(e, t, s, i) {
    if (e instanceof Uint8Array)
      throw new Error("Cannot decrypt samples of type Uint8Array");
    for (; ; t++, s = 0) {
      if (t >= e.length) {
        i();
        return;
      }
      const r = e[t].units;
      for (; !(s >= r.length); s++) {
        const a = r[s];
        if (!(a.data.length <= 48 || a.type !== 1 && a.type !== 5) && (this.decryptAvcSample(e, t, s, i, a), !this.decrypter.isSync()))
          return;
      }
    }
  }
}
const ne = 188;
class Me {
  constructor(e, t, s) {
    this.observer = void 0, this.config = void 0, this.typeSupported = void 0, this.sampleAes = null, this.pmtParsed = !1, this.audioCodec = void 0, this.videoCodec = void 0, this._duration = 0, this._pmtId = -1, this._videoTrack = void 0, this._audioTrack = void 0, this._id3Track = void 0, this._txtTrack = void 0, this.aacOverFlow = null, this.remainderData = null, this.videoParser = void 0, this.observer = e, this.config = t, this.typeSupported = s, this.videoParser = new bl();
  }
  static probe(e) {
    const t = Me.syncOffset(e);
    return t > 0 && v.warn(`MPEG2-TS detected but first sync word found @ offset ${t}`), t !== -1;
  }
  static syncOffset(e) {
    const t = e.length;
    let s = Math.min(ne * 5, t - ne) + 1, i = 0;
    for (; i < s; ) {
      let r = !1, a = -1, o = 0;
      for (let l = i; l < t; l += ne)
        if (e[l] === 71 && (t - l === ne || e[l + ne] === 71)) {
          if (o++, a === -1 && (a = l, a !== 0 && (s = Math.min(a + ne * 99, e.length - ne) + 1)), r || (r = bs(e, l) === 0), r && o > 1 && (a === 0 && o > 2 || l + ne > s))
            return a;
        } else {
          if (o)
            return -1;
          break;
        }
      i++;
    }
    return -1;
  }
  /**
   * Creates a track model internal to demuxer used to drive remuxing input
   */
  static createTrack(e, t) {
    return {
      container: e === "video" || e === "audio" ? "video/mp2t" : void 0,
      type: e,
      id: Cr[e],
      pid: -1,
      inputTimeScale: 9e4,
      sequenceNumber: 0,
      samples: [],
      dropped: 0,
      duration: e === "audio" ? t : void 0
    };
  }
  /**
   * Initializes a new init segment on the demuxer/remuxer interface. Needed for discontinuities/track-switches (or at stream start)
   * Resets all internal track instances of the demuxer.
   */
  resetInitSegment(e, t, s, i) {
    this.pmtParsed = !1, this._pmtId = -1, this._videoTrack = Me.createTrack("video"), this._audioTrack = Me.createTrack("audio", i), this._id3Track = Me.createTrack("id3"), this._txtTrack = Me.createTrack("text"), this._audioTrack.segmentCodec = "aac", this.aacOverFlow = null, this.remainderData = null, this.audioCodec = t, this.videoCodec = s, this._duration = i;
  }
  resetTimeStamp() {
  }
  resetContiguity() {
    const {
      _audioTrack: e,
      _videoTrack: t,
      _id3Track: s
    } = this;
    e && (e.pesData = null), t && (t.pesData = null), s && (s.pesData = null), this.aacOverFlow = null, this.remainderData = null;
  }
  demux(e, t, s = !1, i = !1) {
    s || (this.sampleAes = null);
    let r;
    const a = this._videoTrack, o = this._audioTrack, l = this._id3Track, c = this._txtTrack;
    let h = a.pid, u = a.pesData, d = o.pid, f = l.pid, g = o.pesData, m = l.pesData, E = null, T = this.pmtParsed, y = this._pmtId, x = e.length;
    if (this.remainderData && (e = Te(this.remainderData, e), x = e.length, this.remainderData = null), x < ne && !i)
      return this.remainderData = e, {
        audioTrack: o,
        videoTrack: a,
        id3Track: l,
        textTrack: c
      };
    const b = Math.max(0, Me.syncOffset(e));
    x -= (x - b) % ne, x < e.byteLength && !i && (this.remainderData = new Uint8Array(e.buffer, x, e.buffer.byteLength - x));
    let S = 0;
    for (let R = b; R < x; R += ne)
      if (e[R] === 71) {
        const _ = !!(e[R + 1] & 64), P = bs(e, R), I = (e[R + 3] & 48) >> 4;
        let k;
        if (I > 1) {
          if (k = R + 5 + e[R + 4], k === R + ne)
            continue;
        } else
          k = R + 4;
        switch (P) {
          case h:
            _ && (u && (r = qe(u)) && this.videoParser.parseAVCPES(a, c, r, !1, this._duration), u = {
              data: [],
              size: 0
            }), u && (u.data.push(e.subarray(k, R + ne)), u.size += R + ne - k);
            break;
          case d:
            if (_) {
              if (g && (r = qe(g)))
                switch (o.segmentCodec) {
                  case "aac":
                    this.parseAACPES(o, r);
                    break;
                  case "mp3":
                    this.parseMPEGPES(o, r);
                    break;
                  case "ac3":
                    this.parseAC3PES(o, r);
                    break;
                }
              g = {
                data: [],
                size: 0
              };
            }
            g && (g.data.push(e.subarray(k, R + ne)), g.size += R + ne - k);
            break;
          case f:
            _ && (m && (r = qe(m)) && this.parseID3PES(l, r), m = {
              data: [],
              size: 0
            }), m && (m.data.push(e.subarray(k, R + ne)), m.size += R + ne - k);
            break;
          case 0:
            _ && (k += e[k] + 1), y = this._pmtId = Dl(e, k);
            break;
          case y: {
            _ && (k += e[k] + 1);
            const V = Cl(e, k, this.typeSupported, s, this.observer);
            h = V.videoPid, h > 0 && (a.pid = h, a.segmentCodec = V.segmentVideoCodec), d = V.audioPid, d > 0 && (o.pid = d, o.segmentCodec = V.segmentAudioCodec), f = V.id3Pid, f > 0 && (l.pid = f), E !== null && !T && (v.warn(`MPEG-TS PMT found at ${R} after unknown PID '${E}'. Backtracking to sync byte @${b} to parse all TS packets.`), E = null, R = b - 188), T = this.pmtParsed = !0;
            break;
          }
          case 17:
          case 8191:
            break;
          default:
            E = P;
            break;
        }
      } else
        S++;
    S > 0 && $t(this.observer, new Error(`Found ${S} TS packet/s that do not start with 0x47`)), a.pesData = u, o.pesData = g, l.pesData = m;
    const D = {
      audioTrack: o,
      videoTrack: a,
      id3Track: l,
      textTrack: c
    };
    return i && this.extractRemainingSamples(D), D;
  }
  flush() {
    const {
      remainderData: e
    } = this;
    this.remainderData = null;
    let t;
    return e ? t = this.demux(e, -1, !1, !0) : t = {
      videoTrack: this._videoTrack,
      audioTrack: this._audioTrack,
      id3Track: this._id3Track,
      textTrack: this._txtTrack
    }, this.extractRemainingSamples(t), this.sampleAes ? this.decrypt(t, this.sampleAes) : t;
  }
  extractRemainingSamples(e) {
    const {
      audioTrack: t,
      videoTrack: s,
      id3Track: i,
      textTrack: r
    } = e, a = s.pesData, o = t.pesData, l = i.pesData;
    let c;
    if (a && (c = qe(a)) ? (this.videoParser.parseAVCPES(s, r, c, !0, this._duration), s.pesData = null) : s.pesData = a, o && (c = qe(o))) {
      switch (t.segmentCodec) {
        case "aac":
          this.parseAACPES(t, c);
          break;
        case "mp3":
          this.parseMPEGPES(t, c);
          break;
        case "ac3":
          this.parseAC3PES(t, c);
          break;
      }
      t.pesData = null;
    } else
      o != null && o.size && v.log("last AAC PES packet truncated,might overlap between fragments"), t.pesData = o;
    l && (c = qe(l)) ? (this.parseID3PES(i, c), i.pesData = null) : i.pesData = l;
  }
  demuxSampleAes(e, t, s) {
    const i = this.demux(e, s, !0, !this.config.progressive), r = this.sampleAes = new Il(this.observer, this.config, t);
    return this.decrypt(i, r);
  }
  decrypt(e, t) {
    return new Promise((s) => {
      const {
        audioTrack: i,
        videoTrack: r
      } = e;
      i.samples && i.segmentCodec === "aac" ? t.decryptAacSamples(i.samples, 0, () => {
        r.samples ? t.decryptAvcSamples(r.samples, 0, 0, () => {
          s(e);
        }) : s(e);
      }) : r.samples && t.decryptAvcSamples(r.samples, 0, 0, () => {
        s(e);
      });
    });
  }
  destroy() {
    this._duration = 0;
  }
  parseAACPES(e, t) {
    let s = 0;
    const i = this.aacOverFlow;
    let r = t.data;
    if (i) {
      this.aacOverFlow = null;
      const u = i.missing, d = i.sample.unit.byteLength;
      if (u === -1)
        r = Te(i.sample.unit, r);
      else {
        const f = d - u;
        i.sample.unit.set(r.subarray(0, u), f), e.samples.push(i.sample), s = i.missing;
      }
    }
    let a, o;
    for (a = s, o = r.length; a < o - 1 && !Gt(r, a); a++)
      ;
    if (a !== s) {
      let u;
      const d = a < o - 1;
      if (d ? u = `AAC PES did not start with ADTS header,offset:${a}` : u = "No ADTS header found in AAC PES", $t(this.observer, new Error(u), d), !d)
        return;
    }
    Xr(e, this.observer, r, a, this.audioCodec);
    let l;
    if (t.pts !== void 0)
      l = t.pts;
    else if (i) {
      const u = Qr(e.samplerate);
      l = i.sample.pts + u;
    } else {
      v.warn("[tsdemuxer]: AAC PES unknown PTS");
      return;
    }
    let c = 0, h;
    for (; a < o; )
      if (h = Jr(e, r, a, l, c), a += h.length, h.missing) {
        this.aacOverFlow = h;
        break;
      } else
        for (c++; a < o - 1 && !Gt(r, a); a++)
          ;
  }
  parseMPEGPES(e, t) {
    const s = t.data, i = s.length;
    let r = 0, a = 0;
    const o = t.pts;
    if (o === void 0) {
      v.warn("[tsdemuxer]: MPEG PES unknown PTS");
      return;
    }
    for (; a < i; )
      if (tn(s, a)) {
        const l = Zr(e, s, a, o, r);
        if (l)
          a += l.length, r++;
        else
          break;
      } else
        a++;
  }
  parseAC3PES(e, t) {
    {
      const s = t.data, i = t.pts;
      if (i === void 0) {
        v.warn("[tsdemuxer]: AC3 PES unknown PTS");
        return;
      }
      const r = s.length;
      let a = 0, o = 0, l;
      for (; o < r && (l = nn(e, s, o, i, a++)) > 0; )
        o += l;
    }
  }
  parseID3PES(e, t) {
    if (t.pts === void 0) {
      v.warn("[tsdemuxer]: ID3 PES unknown PTS");
      return;
    }
    const s = se({}, t, {
      type: this._videoTrack ? Se.emsg : Se.audioId3,
      duration: Number.POSITIVE_INFINITY
    });
    e.samples.push(s);
  }
}
function bs(n, e) {
  return ((n[e + 1] & 31) << 8) + n[e + 2];
}
function Dl(n, e) {
  return (n[e + 10] & 31) << 8 | n[e + 11];
}
function Cl(n, e, t, s, i) {
  const r = {
    audioPid: -1,
    videoPid: -1,
    id3Pid: -1,
    segmentVideoCodec: "avc",
    segmentAudioCodec: "aac"
  }, a = (n[e + 1] & 15) << 8 | n[e + 2], o = e + 3 + a - 4, l = (n[e + 10] & 15) << 8 | n[e + 11];
  for (e += 12 + l; e < o; ) {
    const c = bs(n, e), h = (n[e + 3] & 15) << 8 | n[e + 4];
    switch (n[e]) {
      case 207:
        if (!s) {
          is("ADTS AAC");
          break;
        }
      case 15:
        r.audioPid === -1 && (r.audioPid = c);
        break;
      case 21:
        r.id3Pid === -1 && (r.id3Pid = c);
        break;
      case 219:
        if (!s) {
          is("H.264");
          break;
        }
      case 27:
        r.videoPid === -1 && (r.videoPid = c, r.segmentVideoCodec = "avc");
        break;
      case 3:
      case 4:
        !t.mpeg && !t.mp3 ? v.log("MPEG audio found, not supported in this browser") : r.audioPid === -1 && (r.audioPid = c, r.segmentAudioCodec = "mp3");
        break;
      case 193:
        if (!s) {
          is("AC-3");
          break;
        }
      case 129:
        t.ac3 ? r.audioPid === -1 && (r.audioPid = c, r.segmentAudioCodec = "ac3") : v.log("AC-3 audio found, not supported in this browser");
        break;
      case 6:
        if (r.audioPid === -1 && h > 0) {
          let u = e + 5, d = h;
          for (; d > 2; ) {
            switch (n[u]) {
              case 106:
                t.ac3 !== !0 ? v.log("AC-3 audio found, not supported in this browser for now") : (r.audioPid = c, r.segmentAudioCodec = "ac3");
                break;
            }
            const g = n[u + 1] + 2;
            u += g, d -= g;
          }
        }
        break;
      case 194:
      case 135:
        return $t(i, new Error("Unsupported EC-3 in M2TS found")), r;
      case 36:
        return $t(i, new Error("Unsupported HEVC in M2TS found")), r;
    }
    e += h + 5;
  }
  return r;
}
function $t(n, e, t) {
  v.warn(`parsing error: ${e.message}`), n.emit(p.ERROR, p.ERROR, {
    type: K.MEDIA_ERROR,
    details: L.FRAG_PARSING_ERROR,
    fatal: !1,
    levelRetry: t,
    error: e,
    reason: e.message
  });
}
function is(n) {
  v.log(`${n} with AES-128-CBC encryption found in unencrypted stream`);
}
function qe(n) {
  let e = 0, t, s, i, r, a;
  const o = n.data;
  if (!n || n.size === 0)
    return null;
  for (; o[0].length < 19 && o.length > 1; )
    o[0] = Te(o[0], o[1]), o.splice(1, 1);
  if (t = o[0], (t[0] << 16) + (t[1] << 8) + t[2] === 1) {
    if (s = (t[4] << 8) + t[5], s && s > n.size - 6)
      return null;
    const c = t[7];
    c & 192 && (r = (t[9] & 14) * 536870912 + // 1 << 29
    (t[10] & 255) * 4194304 + // 1 << 22
    (t[11] & 254) * 16384 + // 1 << 14
    (t[12] & 255) * 128 + // 1 << 7
    (t[13] & 254) / 2, c & 64 ? (a = (t[14] & 14) * 536870912 + // 1 << 29
    (t[15] & 255) * 4194304 + // 1 << 22
    (t[16] & 254) * 16384 + // 1 << 14
    (t[17] & 255) * 128 + // 1 << 7
    (t[18] & 254) / 2, r - a > 60 * 9e4 && (v.warn(`${Math.round((r - a) / 9e4)}s delta between PTS and DTS, align them`), r = a)) : a = r), i = t[8];
    let h = i + 9;
    if (n.size <= h)
      return null;
    n.size -= h;
    const u = new Uint8Array(n.size);
    for (let d = 0, f = o.length; d < f; d++) {
      t = o[d];
      let g = t.byteLength;
      if (h)
        if (h > g) {
          h -= g;
          continue;
        } else
          t = t.subarray(h), g -= h, h = 0;
      u.set(t, e), e += g;
    }
    return s && (s -= i + 3), {
      data: u,
      pts: r,
      dts: a,
      len: s
    };
  }
  return null;
}
class _l extends Ys {
  resetInitSegment(e, t, s, i) {
    super.resetInitSegment(e, t, s, i), this._audioTrack = {
      container: "audio/mpeg",
      type: "audio",
      id: 2,
      pid: -1,
      sequenceNumber: 0,
      segmentCodec: "mp3",
      samples: [],
      manifestCodec: t,
      duration: i,
      inputTimeScale: 9e4,
      dropped: 0
    };
  }
  static probe(e) {
    if (!e)
      return !1;
    const t = ot(e, 0);
    let s = (t == null ? void 0 : t.length) || 0;
    if (t && e[s] === 11 && e[s + 1] === 119 && Gs(t) !== void 0 && // check the bsid to confirm ac-3 or ec-3 (not mp3)
    rn(e, s) <= 16)
      return !1;
    for (let i = e.length; s < i; s++)
      if (sn(e, s))
        return v.log("MPEG Audio sync word found !"), !0;
    return !1;
  }
  canParse(e, t) {
    return xl(e, t);
  }
  appendFrame(e, t, s) {
    if (this.basePTS !== null)
      return Zr(e, t, s, this.basePTS, this.frameIndex);
  }
}
class Ki {
  static getSilentFrame(e, t) {
    switch (e) {
      case "mp4a.40.2":
        if (t === 1)
          return new Uint8Array([0, 200, 0, 128, 35, 128]);
        if (t === 2)
          return new Uint8Array([33, 0, 73, 144, 2, 25, 0, 35, 128]);
        if (t === 3)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 142]);
        if (t === 4)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 128, 44, 128, 8, 2, 56]);
        if (t === 5)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 56]);
        if (t === 6)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 0, 178, 0, 32, 8, 224]);
        break;
      default:
        if (t === 1)
          return new Uint8Array([1, 64, 34, 128, 163, 78, 230, 128, 186, 8, 0, 0, 0, 28, 6, 241, 193, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
        if (t === 2)
          return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
        if (t === 3)
          return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
        break;
    }
  }
}
const Pe = Math.pow(2, 32) - 1;
class A {
  static init() {
    A.types = {
      avc1: [],
      // codingname
      avcC: [],
      btrt: [],
      dinf: [],
      dref: [],
      esds: [],
      ftyp: [],
      hdlr: [],
      mdat: [],
      mdhd: [],
      mdia: [],
      mfhd: [],
      minf: [],
      moof: [],
      moov: [],
      mp4a: [],
      ".mp3": [],
      dac3: [],
      "ac-3": [],
      mvex: [],
      mvhd: [],
      pasp: [],
      sdtp: [],
      stbl: [],
      stco: [],
      stsc: [],
      stsd: [],
      stsz: [],
      stts: [],
      tfdt: [],
      tfhd: [],
      traf: [],
      trak: [],
      trun: [],
      trex: [],
      tkhd: [],
      vmhd: [],
      smhd: []
    };
    let e;
    for (e in A.types)
      A.types.hasOwnProperty(e) && (A.types[e] = [e.charCodeAt(0), e.charCodeAt(1), e.charCodeAt(2), e.charCodeAt(3)]);
    const t = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      // pre_defined
      118,
      105,
      100,
      101,
      // handler_type: 'vide'
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      86,
      105,
      100,
      101,
      111,
      72,
      97,
      110,
      100,
      108,
      101,
      114,
      0
      // name: 'VideoHandler'
    ]), s = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      // pre_defined
      115,
      111,
      117,
      110,
      // handler_type: 'soun'
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      83,
      111,
      117,
      110,
      100,
      72,
      97,
      110,
      100,
      108,
      101,
      114,
      0
      // name: 'SoundHandler'
    ]);
    A.HDLR_TYPES = {
      video: t,
      audio: s
    };
    const i = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      1,
      // entry_count
      0,
      0,
      0,
      12,
      // entry_size
      117,
      114,
      108,
      32,
      // 'url' type
      0,
      // version 0
      0,
      0,
      1
      // entry_flags
    ]), r = new Uint8Array([
      0,
      // version
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0
      // entry_count
    ]);
    A.STTS = A.STSC = A.STCO = r, A.STSZ = new Uint8Array([
      0,
      // version
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      // sample_size
      0,
      0,
      0,
      0
      // sample_count
    ]), A.VMHD = new Uint8Array([
      0,
      // version
      0,
      0,
      1,
      // flags
      0,
      0,
      // graphicsmode
      0,
      0,
      0,
      0,
      0,
      0
      // opcolor
    ]), A.SMHD = new Uint8Array([
      0,
      // version
      0,
      0,
      0,
      // flags
      0,
      0,
      // balance
      0,
      0
      // reserved
    ]), A.STSD = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      1
    ]);
    const a = new Uint8Array([105, 115, 111, 109]), o = new Uint8Array([97, 118, 99, 49]), l = new Uint8Array([0, 0, 0, 1]);
    A.FTYP = A.box(A.types.ftyp, a, l, a, o), A.DINF = A.box(A.types.dinf, A.box(A.types.dref, i));
  }
  static box(e, ...t) {
    let s = 8, i = t.length;
    const r = i;
    for (; i--; )
      s += t[i].byteLength;
    const a = new Uint8Array(s);
    for (a[0] = s >> 24 & 255, a[1] = s >> 16 & 255, a[2] = s >> 8 & 255, a[3] = s & 255, a.set(e, 4), i = 0, s = 8; i < r; i++)
      a.set(t[i], s), s += t[i].byteLength;
    return a;
  }
  static hdlr(e) {
    return A.box(A.types.hdlr, A.HDLR_TYPES[e]);
  }
  static mdat(e) {
    return A.box(A.types.mdat, e);
  }
  static mdhd(e, t) {
    t *= e;
    const s = Math.floor(t / (Pe + 1)), i = Math.floor(t % (Pe + 1));
    return A.box(A.types.mdhd, new Uint8Array([
      1,
      // version 1
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      // creation_time
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      // modification_time
      e >> 24 & 255,
      e >> 16 & 255,
      e >> 8 & 255,
      e & 255,
      // timescale
      s >> 24,
      s >> 16 & 255,
      s >> 8 & 255,
      s & 255,
      i >> 24,
      i >> 16 & 255,
      i >> 8 & 255,
      i & 255,
      85,
      196,
      // 'und' language (undetermined)
      0,
      0
    ]));
  }
  static mdia(e) {
    return A.box(A.types.mdia, A.mdhd(e.timescale, e.duration), A.hdlr(e.type), A.minf(e));
  }
  static mfhd(e) {
    return A.box(A.types.mfhd, new Uint8Array([
      0,
      0,
      0,
      0,
      // flags
      e >> 24,
      e >> 16 & 255,
      e >> 8 & 255,
      e & 255
      // sequence_number
    ]));
  }
  static minf(e) {
    return e.type === "audio" ? A.box(A.types.minf, A.box(A.types.smhd, A.SMHD), A.DINF, A.stbl(e)) : A.box(A.types.minf, A.box(A.types.vmhd, A.VMHD), A.DINF, A.stbl(e));
  }
  static moof(e, t, s) {
    return A.box(A.types.moof, A.mfhd(e), A.traf(s, t));
  }
  static moov(e) {
    let t = e.length;
    const s = [];
    for (; t--; )
      s[t] = A.trak(e[t]);
    return A.box.apply(null, [A.types.moov, A.mvhd(e[0].timescale, e[0].duration)].concat(s).concat(A.mvex(e)));
  }
  static mvex(e) {
    let t = e.length;
    const s = [];
    for (; t--; )
      s[t] = A.trex(e[t]);
    return A.box.apply(null, [A.types.mvex, ...s]);
  }
  static mvhd(e, t) {
    t *= e;
    const s = Math.floor(t / (Pe + 1)), i = Math.floor(t % (Pe + 1)), r = new Uint8Array([
      1,
      // version 1
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      // creation_time
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      // modification_time
      e >> 24 & 255,
      e >> 16 & 255,
      e >> 8 & 255,
      e & 255,
      // timescale
      s >> 24,
      s >> 16 & 255,
      s >> 8 & 255,
      s & 255,
      i >> 24,
      i >> 16 & 255,
      i >> 8 & 255,
      i & 255,
      0,
      1,
      0,
      0,
      // 1.0 rate
      1,
      0,
      // 1.0 volume
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      64,
      0,
      0,
      0,
      // transformation: unity matrix
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // pre_defined
      255,
      255,
      255,
      255
      // next_track_ID
    ]);
    return A.box(A.types.mvhd, r);
  }
  static sdtp(e) {
    const t = e.samples || [], s = new Uint8Array(4 + t.length);
    let i, r;
    for (i = 0; i < t.length; i++)
      r = t[i].flags, s[i + 4] = r.dependsOn << 4 | r.isDependedOn << 2 | r.hasRedundancy;
    return A.box(A.types.sdtp, s);
  }
  static stbl(e) {
    return A.box(A.types.stbl, A.stsd(e), A.box(A.types.stts, A.STTS), A.box(A.types.stsc, A.STSC), A.box(A.types.stsz, A.STSZ), A.box(A.types.stco, A.STCO));
  }
  static avc1(e) {
    let t = [], s = [], i, r, a;
    for (i = 0; i < e.sps.length; i++)
      r = e.sps[i], a = r.byteLength, t.push(a >>> 8 & 255), t.push(a & 255), t = t.concat(Array.prototype.slice.call(r));
    for (i = 0; i < e.pps.length; i++)
      r = e.pps[i], a = r.byteLength, s.push(a >>> 8 & 255), s.push(a & 255), s = s.concat(Array.prototype.slice.call(r));
    const o = A.box(A.types.avcC, new Uint8Array([
      1,
      // version
      t[3],
      // profile
      t[4],
      // profile compat
      t[5],
      // level
      255,
      // lengthSizeMinusOne, hard-coded to 4 bytes
      224 | e.sps.length
      // 3bit reserved (111) + numOfSequenceParameterSets
    ].concat(t).concat([
      e.pps.length
      // numOfPictureParameterSets
    ]).concat(s))), l = e.width, c = e.height, h = e.pixelRatio[0], u = e.pixelRatio[1];
    return A.box(
      A.types.avc1,
      new Uint8Array([
        0,
        0,
        0,
        // reserved
        0,
        0,
        0,
        // reserved
        0,
        1,
        // data_reference_index
        0,
        0,
        // pre_defined
        0,
        0,
        // reserved
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        // pre_defined
        l >> 8 & 255,
        l & 255,
        // width
        c >> 8 & 255,
        c & 255,
        // height
        0,
        72,
        0,
        0,
        // horizresolution
        0,
        72,
        0,
        0,
        // vertresolution
        0,
        0,
        0,
        0,
        // reserved
        0,
        1,
        // frame_count
        18,
        100,
        97,
        105,
        108,
        // dailymotion/hls.js
        121,
        109,
        111,
        116,
        105,
        111,
        110,
        47,
        104,
        108,
        115,
        46,
        106,
        115,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        // compressorname
        0,
        24,
        // depth = 24
        17,
        17
      ]),
      // pre_defined = -1
      o,
      A.box(A.types.btrt, new Uint8Array([
        0,
        28,
        156,
        128,
        // bufferSizeDB
        0,
        45,
        198,
        192,
        // maxBitrate
        0,
        45,
        198,
        192
      ])),
      // avgBitrate
      A.box(A.types.pasp, new Uint8Array([
        h >> 24,
        // hSpacing
        h >> 16 & 255,
        h >> 8 & 255,
        h & 255,
        u >> 24,
        // vSpacing
        u >> 16 & 255,
        u >> 8 & 255,
        u & 255
      ]))
    );
  }
  static esds(e) {
    const t = e.config.length;
    return new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      3,
      // descriptor_type
      23 + t,
      // length
      0,
      1,
      // es_id
      0,
      // stream_priority
      4,
      // descriptor_type
      15 + t,
      // length
      64,
      // codec : mpeg4_audio
      21,
      // stream_type
      0,
      0,
      0,
      // buffer_size
      0,
      0,
      0,
      0,
      // maxBitrate
      0,
      0,
      0,
      0,
      // avgBitrate
      5
      // descriptor_type
    ].concat([t]).concat(e.config).concat([6, 1, 2]));
  }
  static audioStsd(e) {
    const t = e.samplerate;
    return new Uint8Array([
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      // reserved
      0,
      1,
      // data_reference_index
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // reserved
      0,
      e.channelCount,
      // channelcount
      0,
      16,
      // sampleSize:16bits
      0,
      0,
      0,
      0,
      // reserved2
      t >> 8 & 255,
      t & 255,
      //
      0,
      0
    ]);
  }
  static mp4a(e) {
    return A.box(A.types.mp4a, A.audioStsd(e), A.box(A.types.esds, A.esds(e)));
  }
  static mp3(e) {
    return A.box(A.types[".mp3"], A.audioStsd(e));
  }
  static ac3(e) {
    return A.box(A.types["ac-3"], A.audioStsd(e), A.box(A.types.dac3, e.config));
  }
  static stsd(e) {
    return e.type === "audio" ? e.segmentCodec === "mp3" && e.codec === "mp3" ? A.box(A.types.stsd, A.STSD, A.mp3(e)) : e.segmentCodec === "ac3" ? A.box(A.types.stsd, A.STSD, A.ac3(e)) : A.box(A.types.stsd, A.STSD, A.mp4a(e)) : A.box(A.types.stsd, A.STSD, A.avc1(e));
  }
  static tkhd(e) {
    const t = e.id, s = e.duration * e.timescale, i = e.width, r = e.height, a = Math.floor(s / (Pe + 1)), o = Math.floor(s % (Pe + 1));
    return A.box(A.types.tkhd, new Uint8Array([
      1,
      // version 1
      0,
      0,
      7,
      // flags
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      // creation_time
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      // modification_time
      t >> 24 & 255,
      t >> 16 & 255,
      t >> 8 & 255,
      t & 255,
      // track_ID
      0,
      0,
      0,
      0,
      // reserved
      a >> 24,
      a >> 16 & 255,
      a >> 8 & 255,
      a & 255,
      o >> 24,
      o >> 16 & 255,
      o >> 8 & 255,
      o & 255,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      // layer
      0,
      0,
      // alternate_group
      0,
      0,
      // non-audio track volume
      0,
      0,
      // reserved
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      64,
      0,
      0,
      0,
      // transformation: unity matrix
      i >> 8 & 255,
      i & 255,
      0,
      0,
      // width
      r >> 8 & 255,
      r & 255,
      0,
      0
      // height
    ]));
  }
  static traf(e, t) {
    const s = A.sdtp(e), i = e.id, r = Math.floor(t / (Pe + 1)), a = Math.floor(t % (Pe + 1));
    return A.box(
      A.types.traf,
      A.box(A.types.tfhd, new Uint8Array([
        0,
        // version 0
        0,
        0,
        0,
        // flags
        i >> 24,
        i >> 16 & 255,
        i >> 8 & 255,
        i & 255
        // track_ID
      ])),
      A.box(A.types.tfdt, new Uint8Array([
        1,
        // version 1
        0,
        0,
        0,
        // flags
        r >> 24,
        r >> 16 & 255,
        r >> 8 & 255,
        r & 255,
        a >> 24,
        a >> 16 & 255,
        a >> 8 & 255,
        a & 255
      ])),
      A.trun(e, s.length + 16 + // tfhd
      20 + // tfdt
      8 + // traf header
      16 + // mfhd
      8 + // moof header
      8),
      // mdat header
      s
    );
  }
  /**
   * Generate a track box.
   * @param track a track definition
   */
  static trak(e) {
    return e.duration = e.duration || 4294967295, A.box(A.types.trak, A.tkhd(e), A.mdia(e));
  }
  static trex(e) {
    const t = e.id;
    return A.box(A.types.trex, new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      t >> 24,
      t >> 16 & 255,
      t >> 8 & 255,
      t & 255,
      // track_ID
      0,
      0,
      0,
      1,
      // default_sample_description_index
      0,
      0,
      0,
      0,
      // default_sample_duration
      0,
      0,
      0,
      0,
      // default_sample_size
      0,
      1,
      0,
      1
      // default_sample_flags
    ]));
  }
  static trun(e, t) {
    const s = e.samples || [], i = s.length, r = 12 + 16 * i, a = new Uint8Array(r);
    let o, l, c, h, u, d;
    for (t += 8 + r, a.set([
      e.type === "video" ? 1 : 0,
      // version 1 for video with signed-int sample_composition_time_offset
      0,
      15,
      1,
      // flags
      i >>> 24 & 255,
      i >>> 16 & 255,
      i >>> 8 & 255,
      i & 255,
      // sample_count
      t >>> 24 & 255,
      t >>> 16 & 255,
      t >>> 8 & 255,
      t & 255
      // data_offset
    ], 0), o = 0; o < i; o++)
      l = s[o], c = l.duration, h = l.size, u = l.flags, d = l.cts, a.set([
        c >>> 24 & 255,
        c >>> 16 & 255,
        c >>> 8 & 255,
        c & 255,
        // sample_duration
        h >>> 24 & 255,
        h >>> 16 & 255,
        h >>> 8 & 255,
        h & 255,
        // sample_size
        u.isLeading << 2 | u.dependsOn,
        u.isDependedOn << 6 | u.hasRedundancy << 4 | u.paddingValue << 1 | u.isNonSync,
        u.degradPrio & 61440,
        u.degradPrio & 15,
        // sample_flags
        d >>> 24 & 255,
        d >>> 16 & 255,
        d >>> 8 & 255,
        d & 255
        // sample_composition_time_offset
      ], 12 + 16 * o);
    return A.box(A.types.trun, a);
  }
  static initSegment(e) {
    A.types || A.init();
    const t = A.moov(e);
    return Te(A.FTYP, t);
  }
}
A.types = void 0;
A.HDLR_TYPES = void 0;
A.STTS = void 0;
A.STSC = void 0;
A.STCO = void 0;
A.STSZ = void 0;
A.VMHD = void 0;
A.SMHD = void 0;
A.STSD = void 0;
A.FTYP = void 0;
A.DINF = void 0;
const an = 9e4;
function zs(n, e, t = 1, s = !1) {
  const i = n * e * t;
  return s ? Math.round(i) : i;
}
function kl(n, e, t = 1, s = !1) {
  return zs(n, e, 1 / t, s);
}
function rt(n, e = !1) {
  return zs(n, 1e3, 1 / an, e);
}
function wl(n, e = 1) {
  return zs(n, an, 1 / e);
}
const Pl = 10 * 1e3, Vi = 1024, Fl = 1152, Ol = 1536;
let je = null, rs = null;
class bt {
  constructor(e, t, s, i = "") {
    if (this.observer = void 0, this.config = void 0, this.typeSupported = void 0, this.ISGenerated = !1, this._initPTS = null, this._initDTS = null, this.nextAvcDts = null, this.nextAudioPts = null, this.videoSampleDuration = null, this.isAudioContiguous = !1, this.isVideoContiguous = !1, this.videoTrackConfig = void 0, this.observer = e, this.config = t, this.typeSupported = s, this.ISGenerated = !1, je === null) {
      const a = (navigator.userAgent || "").match(/Chrome\/(\d+)/i);
      je = a ? parseInt(a[1]) : 0;
    }
    if (rs === null) {
      const r = navigator.userAgent.match(/Safari\/(\d+)/i);
      rs = r ? parseInt(r[1]) : 0;
    }
  }
  destroy() {
    this.config = this.videoTrackConfig = this._initPTS = this._initDTS = null;
  }
  resetTimeStamp(e) {
    v.log("[mp4-remuxer]: initPTS & initDTS reset"), this._initPTS = this._initDTS = e;
  }
  resetNextTimestamp() {
    v.log("[mp4-remuxer]: reset next timestamp"), this.isVideoContiguous = !1, this.isAudioContiguous = !1;
  }
  resetInitSegment() {
    v.log("[mp4-remuxer]: ISGenerated flag reset"), this.ISGenerated = !1, this.videoTrackConfig = void 0;
  }
  getVideoStartPts(e) {
    let t = !1;
    const s = e.reduce((i, r) => {
      const a = r.pts - i;
      return a < -4294967296 ? (t = !0, pe(i, r.pts)) : a > 0 ? i : r.pts;
    }, e[0].pts);
    return t && v.debug("PTS rollover detected"), s;
  }
  remux(e, t, s, i, r, a, o, l) {
    let c, h, u, d, f, g, m = r, E = r;
    const T = e.pid > -1, y = t.pid > -1, x = t.samples.length, b = e.samples.length > 0, S = o && x > 0 || x > 1;
    if ((!T || b) && (!y || S) || this.ISGenerated || o) {
      if (this.ISGenerated) {
        var R, _, P, I;
        const w = this.videoTrackConfig;
        w && (t.width !== w.width || t.height !== w.height || ((R = t.pixelRatio) == null ? void 0 : R[0]) !== ((_ = w.pixelRatio) == null ? void 0 : _[0]) || ((P = t.pixelRatio) == null ? void 0 : P[1]) !== ((I = w.pixelRatio) == null ? void 0 : I[1])) && this.resetInitSegment();
      } else
        u = this.generateIS(e, t, r, a);
      const k = this.isVideoContiguous;
      let V = -1, F;
      if (S && (V = Ml(t.samples), !k && this.config.forceKeyFrameOnDiscontinuity))
        if (g = !0, V > 0) {
          v.warn(`[mp4-remuxer]: Dropped ${V} out of ${x} video samples due to a missing keyframe`);
          const w = this.getVideoStartPts(t.samples);
          t.samples = t.samples.slice(V), t.dropped += V, E += (t.samples[0].pts - w) / t.inputTimeScale, F = E;
        } else V === -1 && (v.warn(`[mp4-remuxer]: No keyframe found out of ${x} video samples`), g = !1);
      if (this.ISGenerated) {
        if (b && S) {
          const w = this.getVideoStartPts(t.samples), U = (pe(e.samples[0].pts, w) - w) / t.inputTimeScale;
          m += Math.max(0, U), E += Math.max(0, -U);
        }
        if (b) {
          if (e.samplerate || (v.warn("[mp4-remuxer]: regenerate InitSegment as audio detected"), u = this.generateIS(e, t, r, a)), h = this.remuxAudio(e, m, this.isAudioContiguous, a, y || S || l === G.AUDIO ? E : void 0), S) {
            const w = h ? h.endPTS - h.startPTS : 0;
            t.inputTimeScale || (v.warn("[mp4-remuxer]: regenerate InitSegment as video detected"), u = this.generateIS(e, t, r, a)), c = this.remuxVideo(t, E, k, w);
          }
        } else S && (c = this.remuxVideo(t, E, k, 0));
        c && (c.firstKeyFrame = V, c.independent = V !== -1, c.firstKeyFramePTS = F);
      }
    }
    return this.ISGenerated && this._initPTS && this._initDTS && (s.samples.length && (f = on(s, r, this._initPTS, this._initDTS)), i.samples.length && (d = ln(i, r, this._initPTS))), {
      audio: h,
      video: c,
      initSegment: u,
      independent: g,
      text: d,
      id3: f
    };
  }
  generateIS(e, t, s, i) {
    const r = e.samples, a = t.samples, o = this.typeSupported, l = {}, c = this._initPTS;
    let h = !c || i, u = "audio/mp4", d, f, g;
    if (h && (d = f = 1 / 0), e.config && r.length) {
      switch (e.timescale = e.samplerate, e.segmentCodec) {
        case "mp3":
          o.mpeg ? (u = "audio/mpeg", e.codec = "") : o.mp3 && (e.codec = "mp3");
          break;
        case "ac3":
          e.codec = "ac-3";
          break;
      }
      l.audio = {
        id: "audio",
        container: u,
        codec: e.codec,
        initSegment: e.segmentCodec === "mp3" && o.mpeg ? new Uint8Array(0) : A.initSegment([e]),
        metadata: {
          channelCount: e.channelCount
        }
      }, h && (g = e.inputTimeScale, !c || g !== c.timescale ? d = f = r[0].pts - Math.round(g * s) : h = !1);
    }
    if (t.sps && t.pps && a.length) {
      if (t.timescale = t.inputTimeScale, l.video = {
        id: "main",
        container: "video/mp4",
        codec: t.codec,
        initSegment: A.initSegment([t]),
        metadata: {
          width: t.width,
          height: t.height
        }
      }, h)
        if (g = t.inputTimeScale, !c || g !== c.timescale) {
          const m = this.getVideoStartPts(a), E = Math.round(g * s);
          f = Math.min(f, pe(a[0].dts, m) - E), d = Math.min(d, m - E);
        } else
          h = !1;
      this.videoTrackConfig = {
        width: t.width,
        height: t.height,
        pixelRatio: t.pixelRatio
      };
    }
    if (Object.keys(l).length)
      return this.ISGenerated = !0, h ? (this._initPTS = {
        baseTime: d,
        timescale: g
      }, this._initDTS = {
        baseTime: f,
        timescale: g
      }) : d = g = void 0, {
        tracks: l,
        initPTS: d,
        timescale: g
      };
  }
  remuxVideo(e, t, s, i) {
    const r = e.inputTimeScale, a = e.samples, o = [], l = a.length, c = this._initPTS;
    let h = this.nextAvcDts, u = 8, d = this.videoSampleDuration, f, g, m = Number.POSITIVE_INFINITY, E = Number.NEGATIVE_INFINITY, T = !1;
    if (!s || h === null) {
      const N = t * r, O = a[0].pts - pe(a[0].dts, a[0].pts);
      je && h !== null && Math.abs(N - O - h) < 15e3 ? s = !0 : h = N - O;
    }
    const y = c.baseTime * r / c.timescale;
    for (let N = 0; N < l; N++) {
      const O = a[N];
      O.pts = pe(O.pts - y, h), O.dts = pe(O.dts - y, h), O.dts < a[N > 0 ? N - 1 : N].dts && (T = !0);
    }
    T && a.sort(function(N, O) {
      const j = N.dts - O.dts, Y = N.pts - O.pts;
      return j || Y;
    }), f = a[0].dts, g = a[a.length - 1].dts;
    const x = g - f, b = x ? Math.round(x / (l - 1)) : d || e.inputTimeScale / 30;
    if (s) {
      const N = f - h, O = N > b, j = N < -1;
      if ((O || j) && (O ? v.warn(`AVC: ${rt(N, !0)} ms (${N}dts) hole between fragments detected at ${t.toFixed(3)}`) : v.warn(`AVC: ${rt(-N, !0)} ms (${N}dts) overlapping between fragments detected at ${t.toFixed(3)}`), !j || h >= a[0].pts || je)) {
        f = h;
        const Y = a[0].pts - N;
        if (O)
          a[0].dts = f, a[0].pts = Y;
        else
          for (let X = 0; X < a.length && !(a[X].dts > Y); X++)
            a[X].dts -= N, a[X].pts -= N;
        v.log(`Video: Initial PTS/DTS adjusted: ${rt(Y, !0)}/${rt(f, !0)}, delta: ${rt(N, !0)} ms`);
      }
    }
    f = Math.max(0, f);
    let S = 0, D = 0, R = f;
    for (let N = 0; N < l; N++) {
      const O = a[N], j = O.units, Y = j.length;
      let X = 0;
      for (let te = 0; te < Y; te++)
        X += j[te].data.length;
      D += X, S += Y, O.length = X, O.dts < R ? (O.dts = R, R += b / 4 | 0 || 1) : R = O.dts, m = Math.min(O.pts, m), E = Math.max(O.pts, E);
    }
    g = a[l - 1].dts;
    const _ = D + 4 * S + 8;
    let P;
    try {
      P = new Uint8Array(_);
    } catch (N) {
      this.observer.emit(p.ERROR, p.ERROR, {
        type: K.MUX_ERROR,
        details: L.REMUX_ALLOC_ERROR,
        fatal: !1,
        error: N,
        bytes: _,
        reason: `fail allocating video mdat ${_}`
      });
      return;
    }
    const I = new DataView(P.buffer);
    I.setUint32(0, _), P.set(A.types.mdat, 4);
    let k = !1, V = Number.POSITIVE_INFINITY, F = Number.POSITIVE_INFINITY, w = Number.NEGATIVE_INFINITY, $ = Number.NEGATIVE_INFINITY;
    for (let N = 0; N < l; N++) {
      const O = a[N], j = O.units;
      let Y = 0;
      for (let re = 0, le = j.length; re < le; re++) {
        const ge = j[re], it = ge.data, Yt = ge.data.byteLength;
        I.setUint32(u, Yt), u += 4, P.set(it, u), u += Yt, Y += 4 + Yt;
      }
      let X;
      if (N < l - 1)
        d = a[N + 1].dts - O.dts, X = a[N + 1].pts - O.pts;
      else {
        const re = this.config, le = N > 0 ? O.dts - a[N - 1].dts : b;
        if (X = N > 0 ? O.pts - a[N - 1].pts : b, re.stretchShortVideoTrack && this.nextAudioPts !== null) {
          const ge = Math.floor(re.maxBufferHole * r), it = (i ? m + i * r : this.nextAudioPts) - O.pts;
          it > ge ? (d = it - le, d < 0 ? d = le : k = !0, v.log(`[mp4-remuxer]: It is approximately ${it / 90} ms to the next segment; using duration ${d / 90} ms for the last video frame.`)) : d = le;
        } else
          d = le;
      }
      const te = Math.round(O.pts - O.dts);
      V = Math.min(V, d), w = Math.max(w, d), F = Math.min(F, X), $ = Math.max($, X), o.push(new Hi(O.key, d, Y, te));
    }
    if (o.length) {
      if (je) {
        if (je < 70) {
          const N = o[0].flags;
          N.dependsOn = 2, N.isNonSync = 0;
        }
      } else if (rs && $ - F < w - V && b / w < 0.025 && o[0].cts === 0) {
        v.warn("Found irregular gaps in sample duration. Using PTS instead of DTS to determine MP4 sample duration.");
        let N = f;
        for (let O = 0, j = o.length; O < j; O++) {
          const Y = N + o[O].duration, X = N + o[O].cts;
          if (O < j - 1) {
            const te = Y + o[O + 1].cts;
            o[O].duration = te - X;
          } else
            o[O].duration = O ? o[O - 1].duration : b;
          o[O].cts = 0, N = Y;
        }
      }
    }
    d = k || !d ? b : d, this.nextAvcDts = h = g + d, this.videoSampleDuration = d, this.isVideoContiguous = !0;
    const z = {
      data1: A.moof(e.sequenceNumber++, f, se({}, e, {
        samples: o
      })),
      data2: P,
      startPTS: m / r,
      endPTS: (E + d) / r,
      startDTS: f / r,
      endDTS: h / r,
      type: "video",
      hasAudio: !1,
      hasVideo: !0,
      nb: o.length,
      dropped: e.dropped
    };
    return e.samples = [], e.dropped = 0, z;
  }
  getSamplesPerFrame(e) {
    switch (e.segmentCodec) {
      case "mp3":
        return Fl;
      case "ac3":
        return Ol;
      default:
        return Vi;
    }
  }
  remuxAudio(e, t, s, i, r) {
    const a = e.inputTimeScale, o = e.samplerate ? e.samplerate : a, l = a / o, c = this.getSamplesPerFrame(e), h = c * l, u = this._initPTS, d = e.segmentCodec === "mp3" && this.typeSupported.mpeg, f = [], g = r !== void 0;
    let m = e.samples, E = d ? 0 : 8, T = this.nextAudioPts || -1;
    const y = t * a, x = u.baseTime * a / u.timescale;
    if (this.isAudioContiguous = s = s || m.length && T > 0 && (i && Math.abs(y - T) < 9e3 || Math.abs(pe(m[0].pts - x, y) - T) < 20 * h), m.forEach(function(U) {
      U.pts = pe(U.pts - x, y);
    }), !s || T < 0) {
      if (m = m.filter((U) => U.pts >= 0), !m.length)
        return;
      r === 0 ? T = 0 : i && !g ? T = Math.max(0, y) : T = m[0].pts;
    }
    if (e.segmentCodec === "aac") {
      const U = this.config.maxAudioFramesDrift;
      for (let W = 0, z = T; W < m.length; W++) {
        const N = m[W], O = N.pts, j = O - z, Y = Math.abs(1e3 * j / a);
        if (j <= -U * h && g)
          W === 0 && (v.warn(`Audio frame @ ${(O / a).toFixed(3)}s overlaps nextAudioPts by ${Math.round(1e3 * j / a)} ms.`), this.nextAudioPts = T = z = O);
        else if (j >= U * h && Y < Pl && g) {
          let X = Math.round(j / h);
          z = O - X * h, z < 0 && (X--, z += h), W === 0 && (this.nextAudioPts = T = z), v.warn(`[mp4-remuxer]: Injecting ${X} audio frame @ ${(z / a).toFixed(3)}s due to ${Math.round(1e3 * j / a)} ms gap.`);
          for (let te = 0; te < X; te++) {
            const re = Math.max(z, 0);
            let le = Ki.getSilentFrame(e.manifestCodec || e.codec, e.channelCount);
            le || (v.log("[mp4-remuxer]: Unable to get silent frame for given audio codec; duplicating last frame instead."), le = N.unit.subarray()), m.splice(W, 0, {
              unit: le,
              pts: re
            }), z += h, W++;
          }
        }
        N.pts = z, z += h;
      }
    }
    let b = null, S = null, D, R = 0, _ = m.length;
    for (; _--; )
      R += m[_].unit.byteLength;
    for (let U = 0, W = m.length; U < W; U++) {
      const z = m[U], N = z.unit;
      let O = z.pts;
      if (S !== null) {
        const Y = f[U - 1];
        Y.duration = Math.round((O - S) / l);
      } else if (s && e.segmentCodec === "aac" && (O = T), b = O, R > 0) {
        R += E;
        try {
          D = new Uint8Array(R);
        } catch (Y) {
          this.observer.emit(p.ERROR, p.ERROR, {
            type: K.MUX_ERROR,
            details: L.REMUX_ALLOC_ERROR,
            fatal: !1,
            error: Y,
            bytes: R,
            reason: `fail allocating audio mdat ${R}`
          });
          return;
        }
        d || (new DataView(D.buffer).setUint32(0, R), D.set(A.types.mdat, 4));
      } else
        return;
      D.set(N, E);
      const j = N.byteLength;
      E += j, f.push(new Hi(!0, c, j, 0)), S = O;
    }
    const P = f.length;
    if (!P)
      return;
    const I = f[f.length - 1];
    this.nextAudioPts = T = S + l * I.duration;
    const k = d ? new Uint8Array(0) : A.moof(e.sequenceNumber++, b / l, se({}, e, {
      samples: f
    }));
    e.samples = [];
    const V = b / a, F = T / a, $ = {
      data1: k,
      data2: D,
      startPTS: V,
      endPTS: F,
      startDTS: V,
      endDTS: F,
      type: "audio",
      hasAudio: !0,
      hasVideo: !1,
      nb: P
    };
    return this.isAudioContiguous = !0, $;
  }
  remuxEmptyAudio(e, t, s, i) {
    const r = e.inputTimeScale, a = e.samplerate ? e.samplerate : r, o = r / a, l = this.nextAudioPts, c = this._initDTS, h = c.baseTime * 9e4 / c.timescale, u = (l !== null ? l : i.startDTS * r) + h, d = i.endDTS * r + h, f = o * Vi, g = Math.ceil((d - u) / f), m = Ki.getSilentFrame(e.manifestCodec || e.codec, e.channelCount);
    if (v.warn("[mp4-remuxer]: remux empty Audio"), !m) {
      v.trace("[mp4-remuxer]: Unable to remuxEmptyAudio since we were unable to get a silent frame for given audio codec");
      return;
    }
    const E = [];
    for (let T = 0; T < g; T++) {
      const y = u + T * f;
      E.push({
        unit: m,
        pts: y,
        dts: y
      });
    }
    return e.samples = E, this.remuxAudio(e, t, s, !1);
  }
}
function pe(n, e) {
  let t;
  if (e === null)
    return n;
  for (e < n ? t = -8589934592 : t = 8589934592; Math.abs(n - e) > 4294967296; )
    n += t;
  return n;
}
function Ml(n) {
  for (let e = 0; e < n.length; e++)
    if (n[e].key)
      return e;
  return -1;
}
function on(n, e, t, s) {
  const i = n.samples.length;
  if (!i)
    return;
  const r = n.inputTimeScale;
  for (let o = 0; o < i; o++) {
    const l = n.samples[o];
    l.pts = pe(l.pts - t.baseTime * r / t.timescale, e * r) / r, l.dts = pe(l.dts - s.baseTime * r / s.timescale, e * r) / r;
  }
  const a = n.samples;
  return n.samples = [], {
    samples: a
  };
}
function ln(n, e, t) {
  const s = n.samples.length;
  if (!s)
    return;
  const i = n.inputTimeScale;
  for (let a = 0; a < s; a++) {
    const o = n.samples[a];
    o.pts = pe(o.pts - t.baseTime * i / t.timescale, e * i) / i;
  }
  n.samples.sort((a, o) => a.pts - o.pts);
  const r = n.samples;
  return n.samples = [], {
    samples: r
  };
}
class Hi {
  constructor(e, t, s, i) {
    this.size = void 0, this.duration = void 0, this.cts = void 0, this.flags = void 0, this.duration = t, this.size = s, this.cts = i, this.flags = {
      isLeading: 0,
      isDependedOn: 0,
      hasRedundancy: 0,
      degradPrio: 0,
      dependsOn: e ? 2 : 1,
      isNonSync: e ? 0 : 1
    };
  }
}
class Nl {
  constructor() {
    this.emitInitSegment = !1, this.audioCodec = void 0, this.videoCodec = void 0, this.initData = void 0, this.initPTS = null, this.initTracks = void 0, this.lastEndTime = null;
  }
  destroy() {
  }
  resetTimeStamp(e) {
    this.initPTS = e, this.lastEndTime = null;
  }
  resetNextTimestamp() {
    this.lastEndTime = null;
  }
  resetInitSegment(e, t, s, i) {
    this.audioCodec = t, this.videoCodec = s, this.generateInitSegment(Ka(e, i)), this.emitInitSegment = !0;
  }
  generateInitSegment(e) {
    let {
      audioCodec: t,
      videoCodec: s
    } = this;
    if (!(e != null && e.byteLength)) {
      this.initTracks = void 0, this.initData = void 0;
      return;
    }
    const i = this.initData = wr(e);
    i.audio && (t = Wi(i.audio, Q.AUDIO)), i.video && (s = Wi(i.video, Q.VIDEO));
    const r = {};
    i.audio && i.video ? r.audiovideo = {
      container: "video/mp4",
      codec: t + "," + s,
      initSegment: e,
      id: "main"
    } : i.audio ? r.audio = {
      container: "audio/mp4",
      codec: t,
      initSegment: e,
      id: "audio"
    } : i.video ? r.video = {
      container: "video/mp4",
      codec: s,
      initSegment: e,
      id: "main"
    } : v.warn("[passthrough-remuxer.ts]: initSegment does not contain moov or trak boxes."), this.initTracks = r;
  }
  remux(e, t, s, i, r, a) {
    var o, l;
    let {
      initPTS: c,
      lastEndTime: h
    } = this;
    const u = {
      audio: void 0,
      video: void 0,
      text: i,
      id3: s,
      initSegment: void 0
    };
    M(h) || (h = this.lastEndTime = r || 0);
    const d = t.samples;
    if (!(d != null && d.length))
      return u;
    const f = {
      initPTS: void 0,
      timescale: 1
    };
    let g = this.initData;
    if ((o = g) != null && o.length || (this.generateInitSegment(d), g = this.initData), !((l = g) != null && l.length))
      return v.warn("[passthrough-remuxer.ts]: Failed to generate initSegment."), u;
    this.emitInitSegment && (f.tracks = this.initTracks, this.emitInitSegment = !1);
    const m = Ha(d, g), E = Va(g, d), T = E === null ? r : E;
    (Ul(c, T, r, m) || f.timescale !== c.timescale && a) && (f.initPTS = T - r, c && c.timescale === 1 && v.warn(`Adjusting initPTS by ${f.initPTS - c.baseTime}`), this.initPTS = c = {
      baseTime: f.initPTS,
      timescale: 1
    });
    const y = e ? T - c.baseTime / c.timescale : h, x = y + m;
    Ya(g, d, c.baseTime / c.timescale), m > 0 ? this.lastEndTime = x : (v.warn("Duration parsed from mp4 should be greater than zero"), this.resetNextTimestamp());
    const b = !!g.audio, S = !!g.video;
    let D = "";
    b && (D += "audio"), S && (D += "video");
    const R = {
      data1: d,
      startPTS: y,
      startDTS: y,
      endPTS: x,
      endDTS: x,
      type: D,
      hasAudio: b,
      hasVideo: S,
      nb: 1,
      dropped: 0
    };
    return u.audio = R.type === "audio" ? R : void 0, u.video = R.type !== "audio" ? R : void 0, u.initSegment = f, u.id3 = on(s, r, c, c), i.samples.length && (u.text = ln(i, r, c)), u;
  }
}
function Ul(n, e, t, s) {
  if (n === null)
    return !0;
  const i = Math.max(s, 1), r = e - n.baseTime / n.timescale;
  return Math.abs(r - t) > i;
}
function Wi(n, e) {
  const t = n == null ? void 0 : n.codec;
  if (t && t.length > 4)
    return t;
  if (e === Q.AUDIO) {
    if (t === "ec-3" || t === "ac-3" || t === "alac")
      return t;
    if (t === "fLaC" || t === "Opus")
      return Ft(t, !1);
    const s = "mp4a.40.5";
    return v.info(`Parsed audio codec "${t}" or audio object type not handled. Using "${s}"`), s;
  }
  return v.warn(`Unhandled video codec "${t}"`), t === "hvc1" || t === "hev1" ? "hvc1.1.6.L120.90" : t === "av01" ? "av01.0.04M.08" : "avc1.42e01e";
}
let we;
try {
  we = self.performance.now.bind(self.performance);
} catch {
  v.debug("Unable to use Performance API on this environment"), we = Je == null ? void 0 : Je.Date.now;
}
const It = [{
  demux: Al,
  remux: Nl
}, {
  demux: Me,
  remux: bt
}, {
  demux: Sl,
  remux: bt
}, {
  demux: _l,
  remux: bt
}];
It.splice(2, 0, {
  demux: Ll,
  remux: bt
});
class Yi {
  constructor(e, t, s, i, r) {
    this.async = !1, this.observer = void 0, this.typeSupported = void 0, this.config = void 0, this.vendor = void 0, this.id = void 0, this.demuxer = void 0, this.remuxer = void 0, this.decrypter = void 0, this.probe = void 0, this.decryptionPromise = null, this.transmuxConfig = void 0, this.currentTransmuxState = void 0, this.observer = e, this.typeSupported = t, this.config = s, this.vendor = i, this.id = r;
  }
  configure(e) {
    this.transmuxConfig = e, this.decrypter && this.decrypter.reset();
  }
  push(e, t, s, i) {
    const r = s.transmuxing;
    r.executeStart = we();
    let a = new Uint8Array(e);
    const {
      currentTransmuxState: o,
      transmuxConfig: l
    } = this;
    i && (this.currentTransmuxState = i);
    const {
      contiguous: c,
      discontinuity: h,
      trackSwitch: u,
      accurateTimeOffset: d,
      timeOffset: f,
      initSegmentChange: g
    } = i || o, {
      audioCodec: m,
      videoCodec: E,
      defaultInitPts: T,
      duration: y,
      initSegmentData: x
    } = l, b = Bl(a, t);
    if (b && b.method === "AES-128") {
      const _ = this.getDecrypter();
      if (_.isSync()) {
        let P = _.softwareDecrypt(a, b.key.buffer, b.iv.buffer);
        if (s.part > -1 && (P = _.flush()), !P)
          return r.executeEnd = we(), ns(s);
        a = new Uint8Array(P);
      } else
        return this.decryptionPromise = _.webCryptoDecrypt(a, b.key.buffer, b.iv.buffer).then((P) => {
          const I = this.push(P, null, s);
          return this.decryptionPromise = null, I;
        }), this.decryptionPromise;
    }
    const S = this.needsProbing(h, u);
    if (S) {
      const _ = this.configureTransmuxer(a);
      if (_)
        return v.warn(`[transmuxer] ${_.message}`), this.observer.emit(p.ERROR, p.ERROR, {
          type: K.MEDIA_ERROR,
          details: L.FRAG_PARSING_ERROR,
          fatal: !1,
          error: _,
          reason: _.message
        }), r.executeEnd = we(), ns(s);
    }
    (h || u || g || S) && this.resetInitSegment(x, m, E, y, t), (h || g || S) && this.resetInitialTimestamp(T), c || this.resetContiguity();
    const D = this.transmux(a, b, f, d, s), R = this.currentTransmuxState;
    return R.contiguous = !0, R.discontinuity = !1, R.trackSwitch = !1, r.executeEnd = we(), D;
  }
  // Due to data caching, flush calls can produce more than one TransmuxerResult (hence the Array type)
  flush(e) {
    const t = e.transmuxing;
    t.executeStart = we();
    const {
      decrypter: s,
      currentTransmuxState: i,
      decryptionPromise: r
    } = this;
    if (r)
      return r.then(() => this.flush(e));
    const a = [], {
      timeOffset: o
    } = i;
    if (s) {
      const u = s.flush();
      u && a.push(this.push(u, null, e));
    }
    const {
      demuxer: l,
      remuxer: c
    } = this;
    if (!l || !c)
      return t.executeEnd = we(), [ns(e)];
    const h = l.flush(o);
    return Dt(h) ? h.then((u) => (this.flushRemux(a, u, e), a)) : (this.flushRemux(a, h, e), a);
  }
  flushRemux(e, t, s) {
    const {
      audioTrack: i,
      videoTrack: r,
      id3Track: a,
      textTrack: o
    } = t, {
      accurateTimeOffset: l,
      timeOffset: c
    } = this.currentTransmuxState;
    v.log(`[transmuxer.ts]: Flushed fragment ${s.sn}${s.part > -1 ? " p: " + s.part : ""} of level ${s.level}`);
    const h = this.remuxer.remux(i, r, a, o, c, l, !0, this.id);
    e.push({
      remuxResult: h,
      chunkMeta: s
    }), s.transmuxing.executeEnd = we();
  }
  resetInitialTimestamp(e) {
    const {
      demuxer: t,
      remuxer: s
    } = this;
    !t || !s || (t.resetTimeStamp(e), s.resetTimeStamp(e));
  }
  resetContiguity() {
    const {
      demuxer: e,
      remuxer: t
    } = this;
    !e || !t || (e.resetContiguity(), t.resetNextTimestamp());
  }
  resetInitSegment(e, t, s, i, r) {
    const {
      demuxer: a,
      remuxer: o
    } = this;
    !a || !o || (a.resetInitSegment(e, t, s, i), o.resetInitSegment(e, t, s, r));
  }
  destroy() {
    this.demuxer && (this.demuxer.destroy(), this.demuxer = void 0), this.remuxer && (this.remuxer.destroy(), this.remuxer = void 0);
  }
  transmux(e, t, s, i, r) {
    let a;
    return t && t.method === "SAMPLE-AES" ? a = this.transmuxSampleAes(e, t, s, i, r) : a = this.transmuxUnencrypted(e, s, i, r), a;
  }
  transmuxUnencrypted(e, t, s, i) {
    const {
      audioTrack: r,
      videoTrack: a,
      id3Track: o,
      textTrack: l
    } = this.demuxer.demux(e, t, !1, !this.config.progressive);
    return {
      remuxResult: this.remuxer.remux(r, a, o, l, t, s, !1, this.id),
      chunkMeta: i
    };
  }
  transmuxSampleAes(e, t, s, i, r) {
    return this.demuxer.demuxSampleAes(e, t, s).then((a) => ({
      remuxResult: this.remuxer.remux(a.audioTrack, a.videoTrack, a.id3Track, a.textTrack, s, i, !1, this.id),
      chunkMeta: r
    }));
  }
  configureTransmuxer(e) {
    const {
      config: t,
      observer: s,
      typeSupported: i,
      vendor: r
    } = this;
    let a;
    for (let d = 0, f = It.length; d < f; d++) {
      var o;
      if ((o = It[d].demux) != null && o.probe(e)) {
        a = It[d];
        break;
      }
    }
    if (!a)
      return new Error("Failed to find demuxer by probing fragment data");
    const l = this.demuxer, c = this.remuxer, h = a.remux, u = a.demux;
    (!c || !(c instanceof h)) && (this.remuxer = new h(s, t, i, r)), (!l || !(l instanceof u)) && (this.demuxer = new u(s, t, i), this.probe = u.probe);
  }
  needsProbing(e, t) {
    return !this.demuxer || !this.remuxer || e || t;
  }
  getDecrypter() {
    let e = this.decrypter;
    return e || (e = this.decrypter = new Hs(this.config)), e;
  }
}
function Bl(n, e) {
  let t = null;
  return n.byteLength > 0 && (e == null ? void 0 : e.key) != null && e.iv !== null && e.method != null && (t = e), t;
}
const ns = (n) => ({
  remuxResult: {},
  chunkMeta: n
});
function Dt(n) {
  return "then" in n && n.then instanceof Function;
}
class Gl {
  constructor(e, t, s, i, r) {
    this.audioCodec = void 0, this.videoCodec = void 0, this.initSegmentData = void 0, this.duration = void 0, this.defaultInitPts = void 0, this.audioCodec = e, this.videoCodec = t, this.initSegmentData = s, this.duration = i, this.defaultInitPts = r || null;
  }
}
class $l {
  constructor(e, t, s, i, r, a) {
    this.discontinuity = void 0, this.contiguous = void 0, this.accurateTimeOffset = void 0, this.trackSwitch = void 0, this.timeOffset = void 0, this.initSegmentChange = void 0, this.discontinuity = e, this.contiguous = t, this.accurateTimeOffset = s, this.trackSwitch = i, this.timeOffset = r, this.initSegmentChange = a;
  }
}
var cn = { exports: {} };
(function(n) {
  var e = Object.prototype.hasOwnProperty, t = "~";
  function s() {
  }
  Object.create && (s.prototype = /* @__PURE__ */ Object.create(null), new s().__proto__ || (t = !1));
  function i(l, c, h) {
    this.fn = l, this.context = c, this.once = h || !1;
  }
  function r(l, c, h, u, d) {
    if (typeof h != "function")
      throw new TypeError("The listener must be a function");
    var f = new i(h, u || l, d), g = t ? t + c : c;
    return l._events[g] ? l._events[g].fn ? l._events[g] = [l._events[g], f] : l._events[g].push(f) : (l._events[g] = f, l._eventsCount++), l;
  }
  function a(l, c) {
    --l._eventsCount === 0 ? l._events = new s() : delete l._events[c];
  }
  function o() {
    this._events = new s(), this._eventsCount = 0;
  }
  o.prototype.eventNames = function() {
    var c = [], h, u;
    if (this._eventsCount === 0) return c;
    for (u in h = this._events)
      e.call(h, u) && c.push(t ? u.slice(1) : u);
    return Object.getOwnPropertySymbols ? c.concat(Object.getOwnPropertySymbols(h)) : c;
  }, o.prototype.listeners = function(c) {
    var h = t ? t + c : c, u = this._events[h];
    if (!u) return [];
    if (u.fn) return [u.fn];
    for (var d = 0, f = u.length, g = new Array(f); d < f; d++)
      g[d] = u[d].fn;
    return g;
  }, o.prototype.listenerCount = function(c) {
    var h = t ? t + c : c, u = this._events[h];
    return u ? u.fn ? 1 : u.length : 0;
  }, o.prototype.emit = function(c, h, u, d, f, g) {
    var m = t ? t + c : c;
    if (!this._events[m]) return !1;
    var E = this._events[m], T = arguments.length, y, x;
    if (E.fn) {
      switch (E.once && this.removeListener(c, E.fn, void 0, !0), T) {
        case 1:
          return E.fn.call(E.context), !0;
        case 2:
          return E.fn.call(E.context, h), !0;
        case 3:
          return E.fn.call(E.context, h, u), !0;
        case 4:
          return E.fn.call(E.context, h, u, d), !0;
        case 5:
          return E.fn.call(E.context, h, u, d, f), !0;
        case 6:
          return E.fn.call(E.context, h, u, d, f, g), !0;
      }
      for (x = 1, y = new Array(T - 1); x < T; x++)
        y[x - 1] = arguments[x];
      E.fn.apply(E.context, y);
    } else {
      var b = E.length, S;
      for (x = 0; x < b; x++)
        switch (E[x].once && this.removeListener(c, E[x].fn, void 0, !0), T) {
          case 1:
            E[x].fn.call(E[x].context);
            break;
          case 2:
            E[x].fn.call(E[x].context, h);
            break;
          case 3:
            E[x].fn.call(E[x].context, h, u);
            break;
          case 4:
            E[x].fn.call(E[x].context, h, u, d);
            break;
          default:
            if (!y) for (S = 1, y = new Array(T - 1); S < T; S++)
              y[S - 1] = arguments[S];
            E[x].fn.apply(E[x].context, y);
        }
    }
    return !0;
  }, o.prototype.on = function(c, h, u) {
    return r(this, c, h, u, !1);
  }, o.prototype.once = function(c, h, u) {
    return r(this, c, h, u, !0);
  }, o.prototype.removeListener = function(c, h, u, d) {
    var f = t ? t + c : c;
    if (!this._events[f]) return this;
    if (!h)
      return a(this, f), this;
    var g = this._events[f];
    if (g.fn)
      g.fn === h && (!d || g.once) && (!u || g.context === u) && a(this, f);
    else {
      for (var m = 0, E = [], T = g.length; m < T; m++)
        (g[m].fn !== h || d && !g[m].once || u && g[m].context !== u) && E.push(g[m]);
      E.length ? this._events[f] = E.length === 1 ? E[0] : E : a(this, f);
    }
    return this;
  }, o.prototype.removeAllListeners = function(c) {
    var h;
    return c ? (h = t ? t + c : c, this._events[h] && a(this, h)) : (this._events = new s(), this._eventsCount = 0), this;
  }, o.prototype.off = o.prototype.removeListener, o.prototype.addListener = o.prototype.on, o.prefixed = t, o.EventEmitter = o, n.exports = o;
})(cn);
var Kl = cn.exports, Xs = /* @__PURE__ */ ha(Kl);
class hn {
  constructor(e, t, s, i) {
    this.error = null, this.hls = void 0, this.id = void 0, this.observer = void 0, this.frag = null, this.part = null, this.useWorker = void 0, this.workerContext = null, this.onwmsg = void 0, this.transmuxer = null, this.onTransmuxComplete = void 0, this.onFlush = void 0;
    const r = e.config;
    this.hls = e, this.id = t, this.useWorker = !!r.enableWorker, this.onTransmuxComplete = s, this.onFlush = i;
    const a = (c, h) => {
      h = h || {}, h.frag = this.frag, h.id = this.id, c === p.ERROR && (this.error = h.error), this.hls.trigger(c, h);
    };
    this.observer = new Xs(), this.observer.on(p.FRAG_DECRYPTED, a), this.observer.on(p.ERROR, a);
    const o = Ve(r.preferManagedMediaSource) || {
      isTypeSupported: () => !1
    }, l = {
      mpeg: o.isTypeSupported("audio/mpeg"),
      mp3: o.isTypeSupported('audio/mp4; codecs="mp3"'),
      ac3: o.isTypeSupported('audio/mp4; codecs="ac-3"')
    };
    if (this.useWorker && typeof Worker < "u" && (r.workerPath || ol())) {
      try {
        r.workerPath ? (v.log(`loading Web Worker ${r.workerPath} for "${t}"`), this.workerContext = cl(r.workerPath)) : (v.log(`injecting Web Worker for "${t}"`), this.workerContext = ll()), this.onwmsg = (u) => this.onWorkerMessage(u);
        const {
          worker: h
        } = this.workerContext;
        h.addEventListener("message", this.onwmsg), h.onerror = (u) => {
          const d = new Error(`${u.message}  (${u.filename}:${u.lineno})`);
          r.enableWorker = !1, v.warn(`Error in "${t}" Web Worker, fallback to inline`), this.hls.trigger(p.ERROR, {
            type: K.OTHER_ERROR,
            details: L.INTERNAL_EXCEPTION,
            fatal: !1,
            event: "demuxerWorker",
            error: d
          });
        }, h.postMessage({
          cmd: "init",
          typeSupported: l,
          vendor: "",
          id: t,
          config: JSON.stringify(r)
        });
      } catch (h) {
        v.warn(`Error setting up "${t}" Web Worker, fallback to inline`, h), this.resetWorker(), this.error = null, this.transmuxer = new Yi(this.observer, l, r, "", t);
      }
      return;
    }
    this.transmuxer = new Yi(this.observer, l, r, "", t);
  }
  resetWorker() {
    if (this.workerContext) {
      const {
        worker: e,
        objectURL: t
      } = this.workerContext;
      t && self.URL.revokeObjectURL(t), e.removeEventListener("message", this.onwmsg), e.onerror = null, e.terminate(), this.workerContext = null;
    }
  }
  destroy() {
    if (this.workerContext)
      this.resetWorker(), this.onwmsg = void 0;
    else {
      const t = this.transmuxer;
      t && (t.destroy(), this.transmuxer = null);
    }
    const e = this.observer;
    e && e.removeAllListeners(), this.frag = null, this.observer = null, this.hls = null;
  }
  push(e, t, s, i, r, a, o, l, c, h) {
    var u, d;
    c.transmuxing.start = self.performance.now();
    const {
      transmuxer: f
    } = this, g = a ? a.start : r.start, m = r.decryptdata, E = this.frag, T = !(E && r.cc === E.cc), y = !(E && c.level === E.level), x = E ? c.sn - E.sn : -1, b = this.part ? c.part - this.part.index : -1, S = x === 0 && c.id > 1 && c.id === (E == null ? void 0 : E.stats.chunkCount), D = !y && (x === 1 || x === 0 && (b === 1 || S && b <= 0)), R = self.performance.now();
    (y || x || r.stats.parsing.start === 0) && (r.stats.parsing.start = R), a && (b || !D) && (a.stats.parsing.start = R);
    const _ = !(E && ((u = r.initSegment) == null ? void 0 : u.url) === ((d = E.initSegment) == null ? void 0 : d.url)), P = new $l(T, D, l, y, g, _);
    if (!D || T || _) {
      v.log(`[transmuxer-interface, ${r.type}]: Starting new transmux session for sn: ${c.sn} p: ${c.part} level: ${c.level} id: ${c.id}
        discontinuity: ${T}
        trackSwitch: ${y}
        contiguous: ${D}
        accurateTimeOffset: ${l}
        timeOffset: ${g}
        initSegmentChange: ${_}`);
      const I = new Gl(s, i, t, o, h);
      this.configureTransmuxer(I);
    }
    if (this.frag = r, this.part = a, this.workerContext)
      this.workerContext.worker.postMessage({
        cmd: "demux",
        data: e,
        decryptdata: m,
        chunkMeta: c,
        state: P
      }, e instanceof ArrayBuffer ? [e] : []);
    else if (f) {
      const I = f.push(e, m, c, P);
      Dt(I) ? (f.async = !0, I.then((k) => {
        this.handleTransmuxComplete(k);
      }).catch((k) => {
        this.transmuxerError(k, c, "transmuxer-interface push error");
      })) : (f.async = !1, this.handleTransmuxComplete(I));
    }
  }
  flush(e) {
    e.transmuxing.start = self.performance.now();
    const {
      transmuxer: t
    } = this;
    if (this.workerContext)
      this.workerContext.worker.postMessage({
        cmd: "flush",
        chunkMeta: e
      });
    else if (t) {
      let s = t.flush(e);
      Dt(s) || t.async ? (Dt(s) || (s = Promise.resolve(s)), s.then((r) => {
        this.handleFlushResult(r, e);
      }).catch((r) => {
        this.transmuxerError(r, e, "transmuxer-interface flush error");
      })) : this.handleFlushResult(s, e);
    }
  }
  transmuxerError(e, t, s) {
    this.hls && (this.error = e, this.hls.trigger(p.ERROR, {
      type: K.MEDIA_ERROR,
      details: L.FRAG_PARSING_ERROR,
      chunkMeta: t,
      frag: this.frag || void 0,
      fatal: !1,
      error: e,
      err: e,
      reason: s
    }));
  }
  handleFlushResult(e, t) {
    e.forEach((s) => {
      this.handleTransmuxComplete(s);
    }), this.onFlush(t);
  }
  onWorkerMessage(e) {
    const t = e.data;
    if (!(t != null && t.event)) {
      v.warn(`worker message received with no ${t ? "event name" : "data"}`);
      return;
    }
    const s = this.hls;
    if (this.hls)
      switch (t.event) {
        case "init": {
          var i;
          const r = (i = this.workerContext) == null ? void 0 : i.objectURL;
          r && self.URL.revokeObjectURL(r);
          break;
        }
        case "transmuxComplete": {
          this.handleTransmuxComplete(t.data);
          break;
        }
        case "flush": {
          this.onFlush(t.data);
          break;
        }
        case "workerLog":
          v[t.data.logType] && v[t.data.logType](t.data.message);
          break;
        default: {
          t.data = t.data || {}, t.data.frag = this.frag, t.data.id = this.id, s.trigger(t.event, t.data);
          break;
        }
      }
  }
  configureTransmuxer(e) {
    const {
      transmuxer: t
    } = this;
    this.workerContext ? this.workerContext.worker.postMessage({
      cmd: "configure",
      config: e
    }) : t && t.configure(e);
  }
  handleTransmuxComplete(e) {
    e.chunkMeta.transmuxing.end = self.performance.now(), this.onTransmuxComplete(e);
  }
}
function un(n, e) {
  if (n.length !== e.length)
    return !1;
  for (let t = 0; t < n.length; t++)
    if (!et(n[t].attrs, e[t].attrs))
      return !1;
  return !0;
}
function et(n, e, t) {
  const s = n["STABLE-RENDITION-ID"];
  return s && !t ? s === e["STABLE-RENDITION-ID"] : !(t || ["LANGUAGE", "NAME", "CHARACTERISTICS", "AUTOSELECT", "DEFAULT", "FORCED", "ASSOC-LANGUAGE"]).some((i) => n[i] !== e[i]);
}
function Is(n, e) {
  return e.label.toLowerCase() === n.name.toLowerCase() && (!e.language || e.language.toLowerCase() === (n.lang || "").toLowerCase());
}
const qi = 100;
class Vl extends Ws {
  constructor(e, t, s) {
    super(e, t, s, "[audio-stream-controller]", G.AUDIO), this.videoBuffer = null, this.videoTrackCC = -1, this.waitingVideoCC = -1, this.bufferedTrack = null, this.switchingTrack = null, this.trackId = -1, this.waitingData = null, this.mainDetails = null, this.flushing = !1, this.bufferFlushed = !1, this.cachedTrackLoadedData = null, this._registerListeners();
  }
  onHandlerDestroying() {
    this._unregisterListeners(), super.onHandlerDestroying(), this.mainDetails = null, this.bufferedTrack = null, this.switchingTrack = null;
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.LEVEL_LOADED, this.onLevelLoaded, this), e.on(p.AUDIO_TRACKS_UPDATED, this.onAudioTracksUpdated, this), e.on(p.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.on(p.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.on(p.ERROR, this.onError, this), e.on(p.BUFFER_RESET, this.onBufferReset, this), e.on(p.BUFFER_CREATED, this.onBufferCreated, this), e.on(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.on(p.BUFFER_FLUSHED, this.onBufferFlushed, this), e.on(p.INIT_PTS_FOUND, this.onInitPtsFound, this), e.on(p.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.LEVEL_LOADED, this.onLevelLoaded, this), e.off(p.AUDIO_TRACKS_UPDATED, this.onAudioTracksUpdated, this), e.off(p.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.off(p.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.off(p.ERROR, this.onError, this), e.off(p.BUFFER_RESET, this.onBufferReset, this), e.off(p.BUFFER_CREATED, this.onBufferCreated, this), e.off(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.off(p.BUFFER_FLUSHED, this.onBufferFlushed, this), e.off(p.INIT_PTS_FOUND, this.onInitPtsFound, this), e.off(p.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  // INIT_PTS_FOUND is triggered when the video track parsed in the stream-controller has a new PTS value
  onInitPtsFound(e, {
    frag: t,
    id: s,
    initPTS: i,
    timescale: r
  }) {
    if (s === "main") {
      const a = t.cc;
      this.initPTS[t.cc] = {
        baseTime: i,
        timescale: r
      }, this.log(`InitPTS for cc: ${a} found from main: ${i}`), this.videoTrackCC = a, this.state === C.WAITING_INIT_PTS && this.tick();
    }
  }
  startLoad(e) {
    if (!this.levels) {
      this.startPosition = e, this.state = C.STOPPED;
      return;
    }
    const t = this.lastCurrentTime;
    this.stopLoad(), this.setInterval(qi), t > 0 && e === -1 ? (this.log(`Override startPosition with lastCurrentTime @${t.toFixed(3)}`), e = t, this.state = C.IDLE) : (this.loadedmetadata = !1, this.state = C.WAITING_TRACK), this.nextLoadPosition = this.startPosition = this.lastCurrentTime = e, this.tick();
  }
  doTick() {
    switch (this.state) {
      case C.IDLE:
        this.doTickIdle();
        break;
      case C.WAITING_TRACK: {
        var e;
        const {
          levels: s,
          trackId: i
        } = this, r = s == null || (e = s[i]) == null ? void 0 : e.details;
        if (r) {
          if (this.waitForCdnTuneIn(r))
            break;
          this.state = C.WAITING_INIT_PTS;
        }
        break;
      }
      case C.FRAG_LOADING_WAITING_RETRY: {
        var t;
        const s = performance.now(), i = this.retryDate;
        if (!i || s >= i || (t = this.media) != null && t.seeking) {
          const {
            levels: r,
            trackId: a
          } = this;
          this.log("RetryDate reached, switch back to IDLE state"), this.resetStartWhenNotLoaded((r == null ? void 0 : r[a]) || null), this.state = C.IDLE;
        }
        break;
      }
      case C.WAITING_INIT_PTS: {
        const s = this.waitingData;
        if (s) {
          const {
            frag: i,
            part: r,
            cache: a,
            complete: o
          } = s;
          if (this.initPTS[i.cc] !== void 0) {
            this.waitingData = null, this.waitingVideoCC = -1, this.state = C.FRAG_LOADING;
            const l = a.flush(), c = {
              frag: i,
              part: r,
              payload: l,
              networkDetails: null
            };
            this._handleFragmentLoadProgress(c), o && super._handleFragmentLoadComplete(c);
          } else if (this.videoTrackCC !== this.waitingVideoCC)
            this.log(`Waiting fragment cc (${i.cc}) cancelled because video is at cc ${this.videoTrackCC}`), this.clearWaitingFragment();
          else {
            const l = this.getLoadPosition(), c = J.bufferInfo(this.mediaBuffer, l, this.config.maxBufferHole);
            Rs(c.end, this.config.maxFragLookUpTolerance, i) < 0 && (this.log(`Waiting fragment cc (${i.cc}) @ ${i.start} cancelled because another fragment at ${c.end} is needed`), this.clearWaitingFragment());
          }
        } else
          this.state = C.IDLE;
      }
    }
    this.onTickEnd();
  }
  clearWaitingFragment() {
    const e = this.waitingData;
    e && (this.fragmentTracker.removeFragment(e.frag), this.waitingData = null, this.waitingVideoCC = -1, this.state = C.IDLE);
  }
  resetLoadingState() {
    this.clearWaitingFragment(), super.resetLoadingState();
  }
  onTickEnd() {
    const {
      media: e
    } = this;
    e != null && e.readyState && (this.lastCurrentTime = e.currentTime);
  }
  doTickIdle() {
    const {
      hls: e,
      levels: t,
      media: s,
      trackId: i
    } = this, r = e.config;
    if (!s && (this.startFragRequested || !r.startFragPrefetch) || !(t != null && t[i]))
      return;
    const a = t[i], o = a.details;
    if (!o || o.live && this.levelLastLoaded !== a || this.waitForCdnTuneIn(o)) {
      this.state = C.WAITING_TRACK;
      return;
    }
    const l = this.mediaBuffer ? this.mediaBuffer : this.media;
    this.bufferFlushed && l && (this.bufferFlushed = !1, this.afterBufferFlushed(l, Q.AUDIO, G.AUDIO));
    const c = this.getFwdBufferInfo(l, G.AUDIO);
    if (c === null)
      return;
    const {
      bufferedTrack: h,
      switchingTrack: u
    } = this;
    if (!u && this._streamEnded(c, o)) {
      e.trigger(p.BUFFER_EOS, {
        type: "audio"
      }), this.state = C.ENDED;
      return;
    }
    const d = this.getFwdBufferInfo(this.videoBuffer ? this.videoBuffer : this.media, G.MAIN), f = c.len, g = this.getMaxBufferLength(d == null ? void 0 : d.len), m = o.fragments, E = m[0].start;
    let T = this.flushing ? this.getLoadPosition() : c.end;
    if (u && s) {
      const S = this.getLoadPosition();
      h && !et(u.attrs, h.attrs) && (T = S), o.PTSKnown && S < E && (c.end > E || c.nextStart) && (this.log("Alt audio track ahead of main track, seek to start of alt audio track"), s.currentTime = E + 0.05);
    }
    if (f >= g && !u && T < m[m.length - 1].start)
      return;
    let y = this.getNextFragment(T, o), x = !1;
    if (y && this.isLoopLoading(y, T) && (x = !!y.gap, y = this.getNextFragmentLoopLoading(y, o, c, G.MAIN, g)), !y) {
      this.bufferFlushed = !0;
      return;
    }
    const b = d && y.start > d.end + o.targetduration;
    if (b || // Or wait for main buffer after buffing some audio
    !(d != null && d.len) && c.len) {
      const S = this.getAppendedFrag(y.start, G.MAIN);
      if (S === null || (x || (x = !!S.gap || !!b && d.len === 0), b && !x || x && c.nextStart && c.nextStart < S.end))
        return;
    }
    this.loadFragment(y, a, T);
  }
  getMaxBufferLength(e) {
    const t = super.getMaxBufferLength();
    return e ? Math.min(Math.max(t, e), this.config.maxMaxBufferLength) : t;
  }
  onMediaDetaching() {
    this.videoBuffer = null, this.bufferFlushed = this.flushing = !1, super.onMediaDetaching();
  }
  onAudioTracksUpdated(e, {
    audioTracks: t
  }) {
    this.resetTransmuxer(), this.levels = t.map((s) => new Ze(s));
  }
  onAudioTrackSwitching(e, t) {
    const s = !!t.url;
    this.trackId = t.id;
    const {
      fragCurrent: i
    } = this;
    i && (i.abortRequests(), this.removeUnbufferedFrags(i.start)), this.resetLoadingState(), s ? this.setInterval(qi) : this.resetTransmuxer(), s ? (this.switchingTrack = t, this.state = C.IDLE, this.flushAudioIfNeeded(t)) : (this.switchingTrack = null, this.bufferedTrack = t, this.state = C.STOPPED), this.tick();
  }
  onManifestLoading() {
    this.fragmentTracker.removeAllFragments(), this.startPosition = this.lastCurrentTime = 0, this.bufferFlushed = this.flushing = !1, this.levels = this.mainDetails = this.waitingData = this.bufferedTrack = this.cachedTrackLoadedData = this.switchingTrack = null, this.startFragRequested = !1, this.trackId = this.videoTrackCC = this.waitingVideoCC = -1;
  }
  onLevelLoaded(e, t) {
    this.mainDetails = t.details, this.cachedTrackLoadedData !== null && (this.hls.trigger(p.AUDIO_TRACK_LOADED, this.cachedTrackLoadedData), this.cachedTrackLoadedData = null);
  }
  onAudioTrackLoaded(e, t) {
    var s;
    if (this.mainDetails == null) {
      this.cachedTrackLoadedData = t;
      return;
    }
    const {
      levels: i
    } = this, {
      details: r,
      id: a
    } = t;
    if (!i) {
      this.warn(`Audio tracks were reset while loading level ${a}`);
      return;
    }
    this.log(`Audio track ${a} loaded [${r.startSN},${r.endSN}]${r.lastPartSn ? `[part-${r.lastPartSn}-${r.lastPartIndex}]` : ""},duration:${r.totalduration}`);
    const o = i[a];
    let l = 0;
    if (r.live || (s = o.details) != null && s.live) {
      this.checkLiveUpdate(r);
      const h = this.mainDetails;
      if (r.deltaUpdateFailed || !h)
        return;
      if (!o.details && r.hasProgramDateTime && h.hasProgramDateTime)
        Bt(r, h), l = r.fragments[0].start;
      else {
        var c;
        l = this.alignPlaylists(r, o.details, (c = this.levelLastLoaded) == null ? void 0 : c.details);
      }
    }
    o.details = r, this.levelLastLoaded = o, !this.startFragRequested && (this.mainDetails || !r.live) && this.setStartPosition(this.mainDetails || r, l), this.state === C.WAITING_TRACK && !this.waitForCdnTuneIn(r) && (this.state = C.IDLE), this.tick();
  }
  _handleFragmentLoadProgress(e) {
    var t;
    const {
      frag: s,
      part: i,
      payload: r
    } = e, {
      config: a,
      trackId: o,
      levels: l
    } = this;
    if (!l) {
      this.warn(`Audio tracks were reset while fragment load was in progress. Fragment ${s.sn} of level ${s.level} will not be buffered`);
      return;
    }
    const c = l[o];
    if (!c) {
      this.warn("Audio track is undefined on fragment load progress");
      return;
    }
    const h = c.details;
    if (!h) {
      this.warn("Audio track details undefined on fragment load progress"), this.removeUnbufferedFrags(s.start);
      return;
    }
    const u = a.defaultAudioCodec || c.audioCodec || "mp4a.40.2";
    let d = this.transmuxer;
    d || (d = this.transmuxer = new hn(this.hls, G.AUDIO, this._handleTransmuxComplete.bind(this), this._handleTransmuxerFlush.bind(this)));
    const f = this.initPTS[s.cc], g = (t = s.initSegment) == null ? void 0 : t.data;
    if (f !== void 0) {
      const E = i ? i.index : -1, T = E !== -1, y = new Vs(s.level, s.sn, s.stats.chunkCount, r.byteLength, E, T);
      d.push(r, g, u, "", s, i, h.totalduration, !1, y, f);
    } else {
      this.log(`Unknown video PTS for cc ${s.cc}, waiting for video PTS before demuxing audio frag ${s.sn} of [${h.startSN} ,${h.endSN}],track ${o}`);
      const {
        cache: m
      } = this.waitingData = this.waitingData || {
        frag: s,
        part: i,
        cache: new qr(),
        complete: !1
      };
      m.push(new Uint8Array(r)), this.waitingVideoCC = this.videoTrackCC, this.state = C.WAITING_INIT_PTS;
    }
  }
  _handleFragmentLoadComplete(e) {
    if (this.waitingData) {
      this.waitingData.complete = !0;
      return;
    }
    super._handleFragmentLoadComplete(e);
  }
  onBufferReset() {
    this.mediaBuffer = this.videoBuffer = null, this.loadedmetadata = !1;
  }
  onBufferCreated(e, t) {
    const s = t.tracks.audio;
    s && (this.mediaBuffer = s.buffer || null), t.tracks.video && (this.videoBuffer = t.tracks.video.buffer || null);
  }
  onFragBuffered(e, t) {
    const {
      frag: s,
      part: i
    } = t;
    if (s.type !== G.AUDIO) {
      if (!this.loadedmetadata && s.type === G.MAIN) {
        const r = this.videoBuffer || this.media;
        r && J.getBuffered(r).length && (this.loadedmetadata = !0);
      }
      return;
    }
    if (this.fragContextChanged(s)) {
      this.warn(`Fragment ${s.sn}${i ? " p: " + i.index : ""} of level ${s.level} finished buffering, but was aborted. state: ${this.state}, audioSwitch: ${this.switchingTrack ? this.switchingTrack.name : "false"}`);
      return;
    }
    if (s.sn !== "initSegment") {
      this.fragPrevious = s;
      const r = this.switchingTrack;
      r && (this.bufferedTrack = r, this.switchingTrack = null, this.hls.trigger(p.AUDIO_TRACK_SWITCHED, oe({}, r)));
    }
    this.fragBufferedComplete(s, i);
  }
  onError(e, t) {
    var s;
    if (t.fatal) {
      this.state = C.ERROR;
      return;
    }
    switch (t.details) {
      case L.FRAG_GAP:
      case L.FRAG_PARSING_ERROR:
      case L.FRAG_DECRYPT_ERROR:
      case L.FRAG_LOAD_ERROR:
      case L.FRAG_LOAD_TIMEOUT:
      case L.KEY_LOAD_ERROR:
      case L.KEY_LOAD_TIMEOUT:
        this.onFragmentOrKeyLoadError(G.AUDIO, t);
        break;
      case L.AUDIO_TRACK_LOAD_ERROR:
      case L.AUDIO_TRACK_LOAD_TIMEOUT:
      case L.LEVEL_PARSING_ERROR:
        !t.levelRetry && this.state === C.WAITING_TRACK && ((s = t.context) == null ? void 0 : s.type) === q.AUDIO_TRACK && (this.state = C.IDLE);
        break;
      case L.BUFFER_APPEND_ERROR:
      case L.BUFFER_FULL_ERROR:
        if (!t.parent || t.parent !== "audio")
          return;
        if (t.details === L.BUFFER_APPEND_ERROR) {
          this.resetLoadingState();
          return;
        }
        this.reduceLengthAndFlushBuffer(t) && (this.bufferedTrack = null, super.flushMainBuffer(0, Number.POSITIVE_INFINITY, "audio"));
        break;
      case L.INTERNAL_EXCEPTION:
        this.recoverWorkerError(t);
        break;
    }
  }
  onBufferFlushing(e, {
    type: t
  }) {
    t !== Q.VIDEO && (this.flushing = !0);
  }
  onBufferFlushed(e, {
    type: t
  }) {
    if (t !== Q.VIDEO) {
      this.flushing = !1, this.bufferFlushed = !0, this.state === C.ENDED && (this.state = C.IDLE);
      const s = this.mediaBuffer || this.media;
      s && (this.afterBufferFlushed(s, t, G.AUDIO), this.tick());
    }
  }
  _handleTransmuxComplete(e) {
    var t;
    const s = "audio", {
      hls: i
    } = this, {
      remuxResult: r,
      chunkMeta: a
    } = e, o = this.getCurrentContext(a);
    if (!o) {
      this.resetWhenMissingContext(a);
      return;
    }
    const {
      frag: l,
      part: c,
      level: h
    } = o, {
      details: u
    } = h, {
      audio: d,
      text: f,
      id3: g,
      initSegment: m
    } = r;
    if (this.fragContextChanged(l) || !u) {
      this.fragmentTracker.removeFragment(l);
      return;
    }
    if (this.state = C.PARSING, this.switchingTrack && d && this.completeAudioSwitch(this.switchingTrack), m != null && m.tracks) {
      const E = l.initSegment || l;
      this._bufferInitSegment(h, m.tracks, E, a), i.trigger(p.FRAG_PARSING_INIT_SEGMENT, {
        frag: E,
        id: s,
        tracks: m.tracks
      });
    }
    if (d) {
      const {
        startPTS: E,
        endPTS: T,
        startDTS: y,
        endDTS: x
      } = d;
      c && (c.elementaryStreams[Q.AUDIO] = {
        startPTS: E,
        endPTS: T,
        startDTS: y,
        endDTS: x
      }), l.setElementaryStreamInfo(Q.AUDIO, E, T, y, x), this.bufferFragmentData(d, l, c, a);
    }
    if (g != null && (t = g.samples) != null && t.length) {
      const E = se({
        id: s,
        frag: l,
        details: u
      }, g);
      i.trigger(p.FRAG_PARSING_METADATA, E);
    }
    if (f) {
      const E = se({
        id: s,
        frag: l,
        details: u
      }, f);
      i.trigger(p.FRAG_PARSING_USERDATA, E);
    }
  }
  _bufferInitSegment(e, t, s, i) {
    if (this.state !== C.PARSING)
      return;
    t.video && delete t.video;
    const r = t.audio;
    if (!r)
      return;
    r.id = "audio";
    const a = e.audioCodec;
    this.log(`Init audio buffer, container:${r.container}, codecs[level/parsed]=[${a}/${r.codec}]`), a && a.split(",").length === 1 && (r.levelCodec = a), this.hls.trigger(p.BUFFER_CODECS, t);
    const o = r.initSegment;
    if (o != null && o.byteLength) {
      const l = {
        type: "audio",
        frag: s,
        part: null,
        chunkMeta: i,
        parent: s.type,
        data: o
      };
      this.hls.trigger(p.BUFFER_APPENDING, l);
    }
    this.tickImmediate();
  }
  loadFragment(e, t, s) {
    const i = this.fragmentTracker.getState(e);
    if (this.fragCurrent = e, this.switchingTrack || i === ae.NOT_LOADED || i === ae.PARTIAL) {
      var r;
      if (e.sn === "initSegment")
        this._loadInitSegment(e, t);
      else if ((r = t.details) != null && r.live && !this.initPTS[e.cc]) {
        this.log(`Waiting for video PTS in continuity counter ${e.cc} of live stream before loading audio fragment ${e.sn} of level ${this.trackId}`), this.state = C.WAITING_INIT_PTS;
        const a = this.mainDetails;
        a && a.fragments[0].start !== t.details.fragments[0].start && Bt(t.details, a);
      } else
        this.startFragRequested = !0, super.loadFragment(e, t, s);
    } else
      this.clearTrackerIfNeeded(e);
  }
  flushAudioIfNeeded(e) {
    const {
      media: t,
      bufferedTrack: s
    } = this, i = s == null ? void 0 : s.attrs, r = e.attrs;
    t && i && (i.CHANNELS !== r.CHANNELS || s.name !== e.name || s.lang !== e.lang) && (this.log("Switching audio track : flushing all audio"), super.flushMainBuffer(0, Number.POSITIVE_INFINITY, "audio"), this.bufferedTrack = null);
  }
  completeAudioSwitch(e) {
    const {
      hls: t
    } = this;
    this.flushAudioIfNeeded(e), this.bufferedTrack = e, this.switchingTrack = null, t.trigger(p.AUDIO_TRACK_SWITCHED, oe({}, e));
  }
}
class Hl extends Ks {
  constructor(e) {
    super(e, "[audio-track-controller]"), this.tracks = [], this.groupIds = null, this.tracksInGroup = [], this.trackId = -1, this.currentTrack = null, this.selectDefaultTrack = !0, this.registerListeners();
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.MANIFEST_PARSED, this.onManifestParsed, this), e.on(p.LEVEL_LOADING, this.onLevelLoading, this), e.on(p.LEVEL_SWITCHING, this.onLevelSwitching, this), e.on(p.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.on(p.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.MANIFEST_PARSED, this.onManifestParsed, this), e.off(p.LEVEL_LOADING, this.onLevelLoading, this), e.off(p.LEVEL_SWITCHING, this.onLevelSwitching, this), e.off(p.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.off(p.ERROR, this.onError, this);
  }
  destroy() {
    this.unregisterListeners(), this.tracks.length = 0, this.tracksInGroup.length = 0, this.currentTrack = null, super.destroy();
  }
  onManifestLoading() {
    this.tracks = [], this.tracksInGroup = [], this.groupIds = null, this.currentTrack = null, this.trackId = -1, this.selectDefaultTrack = !0;
  }
  onManifestParsed(e, t) {
    this.tracks = t.audioTracks || [];
  }
  onAudioTrackLoaded(e, t) {
    const {
      id: s,
      groupId: i,
      details: r
    } = t, a = this.tracksInGroup[s];
    if (!a || a.groupId !== i) {
      this.warn(`Audio track with id:${s} and group:${i} not found in active group ${a == null ? void 0 : a.groupId}`);
      return;
    }
    const o = a.details;
    a.details = t.details, this.log(`Audio track ${s} "${a.name}" lang:${a.lang} group:${i} loaded [${r.startSN}-${r.endSN}]`), s === this.trackId && this.playlistLoaded(s, t, o);
  }
  onLevelLoading(e, t) {
    this.switchLevel(t.level);
  }
  onLevelSwitching(e, t) {
    this.switchLevel(t.level);
  }
  switchLevel(e) {
    const t = this.hls.levels[e];
    if (!t)
      return;
    const s = t.audioGroups || null, i = this.groupIds;
    let r = this.currentTrack;
    if (!s || (i == null ? void 0 : i.length) !== (s == null ? void 0 : s.length) || s != null && s.some((o) => (i == null ? void 0 : i.indexOf(o)) === -1)) {
      this.groupIds = s, this.trackId = -1, this.currentTrack = null;
      const o = this.tracks.filter((d) => !s || s.indexOf(d.groupId) !== -1);
      if (o.length)
        this.selectDefaultTrack && !o.some((d) => d.default) && (this.selectDefaultTrack = !1), o.forEach((d, f) => {
          d.id = f;
        });
      else if (!r && !this.tracksInGroup.length)
        return;
      this.tracksInGroup = o;
      const l = this.hls.config.audioPreference;
      if (!r && l) {
        const d = be(l, o, We);
        if (d > -1)
          r = o[d];
        else {
          const f = be(l, this.tracks);
          r = this.tracks[f];
        }
      }
      let c = this.findTrackId(r);
      c === -1 && r && (c = this.findTrackId(null));
      const h = {
        audioTracks: o
      };
      this.log(`Updating audio tracks, ${o.length} track(s) found in group(s): ${s == null ? void 0 : s.join(",")}`), this.hls.trigger(p.AUDIO_TRACKS_UPDATED, h);
      const u = this.trackId;
      if (c !== -1 && u === -1)
        this.setAudioTrack(c);
      else if (o.length && u === -1) {
        var a;
        const d = new Error(`No audio track selected for current audio group-ID(s): ${(a = this.groupIds) == null ? void 0 : a.join(",")} track count: ${o.length}`);
        this.warn(d.message), this.hls.trigger(p.ERROR, {
          type: K.MEDIA_ERROR,
          details: L.AUDIO_TRACK_LOAD_ERROR,
          fatal: !0,
          error: d
        });
      }
    } else this.shouldReloadPlaylist(r) && this.setAudioTrack(this.trackId);
  }
  onError(e, t) {
    t.fatal || !t.context || t.context.type === q.AUDIO_TRACK && t.context.id === this.trackId && (!this.groupIds || this.groupIds.indexOf(t.context.groupId) !== -1) && (this.requestScheduled = -1, this.checkRetry(t));
  }
  get allAudioTracks() {
    return this.tracks;
  }
  get audioTracks() {
    return this.tracksInGroup;
  }
  get audioTrack() {
    return this.trackId;
  }
  set audioTrack(e) {
    this.selectDefaultTrack = !1, this.setAudioTrack(e);
  }
  setAudioOption(e) {
    const t = this.hls;
    if (t.config.audioPreference = e, e) {
      const s = this.allAudioTracks;
      if (this.selectDefaultTrack = !1, s.length) {
        const i = this.currentTrack;
        if (i && Xe(e, i, We))
          return i;
        const r = be(e, this.tracksInGroup, We);
        if (r > -1) {
          const a = this.tracksInGroup[r];
          return this.setAudioTrack(r), a;
        } else if (i) {
          let a = t.loadLevel;
          a === -1 && (a = t.firstAutoLevel);
          const o = Ho(e, t.levels, s, a, We);
          if (o === -1)
            return null;
          t.nextLoadLevel = o;
        }
        if (e.channels || e.audioCodec) {
          const a = be(e, s);
          if (a > -1)
            return s[a];
        }
      }
    }
    return null;
  }
  setAudioTrack(e) {
    const t = this.tracksInGroup;
    if (e < 0 || e >= t.length) {
      this.warn(`Invalid audio track id: ${e}`);
      return;
    }
    this.clearTimer(), this.selectDefaultTrack = !1;
    const s = this.currentTrack, i = t[e], r = i.details && !i.details.live;
    if (e === this.trackId && i === s && r || (this.log(`Switching to audio-track ${e} "${i.name}" lang:${i.lang} group:${i.groupId} channels:${i.channels}`), this.trackId = e, this.currentTrack = i, this.hls.trigger(p.AUDIO_TRACK_SWITCHING, oe({}, i)), r))
      return;
    const a = this.switchParams(i.url, s == null ? void 0 : s.details, i.details);
    this.loadPlaylist(a);
  }
  findTrackId(e) {
    const t = this.tracksInGroup;
    for (let s = 0; s < t.length; s++) {
      const i = t[s];
      if (!(this.selectDefaultTrack && !i.default) && (!e || Xe(e, i, We)))
        return s;
    }
    if (e) {
      const {
        name: s,
        lang: i,
        assocLang: r,
        characteristics: a,
        audioCodec: o,
        channels: l
      } = e;
      for (let c = 0; c < t.length; c++) {
        const h = t[c];
        if (Xe({
          name: s,
          lang: i,
          assocLang: r,
          characteristics: a,
          audioCodec: o,
          channels: l
        }, h, We))
          return c;
      }
      for (let c = 0; c < t.length; c++) {
        const h = t[c];
        if (et(e.attrs, h.attrs, ["LANGUAGE", "ASSOC-LANGUAGE", "CHARACTERISTICS"]))
          return c;
      }
      for (let c = 0; c < t.length; c++) {
        const h = t[c];
        if (et(e.attrs, h.attrs, ["LANGUAGE"]))
          return c;
      }
    }
    return -1;
  }
  loadPlaylist(e) {
    const t = this.currentTrack;
    if (this.shouldLoadPlaylist(t) && t) {
      super.loadPlaylist();
      const s = t.id, i = t.groupId;
      let r = t.url;
      if (e)
        try {
          r = e.addDirectives(r);
        } catch (a) {
          this.warn(`Could not construct new URL with HLS Delivery Directives: ${a}`);
        }
      this.log(`loading audio-track playlist ${s} "${t.name}" lang:${t.lang} group:${i}`), this.clearTimer(), this.hls.trigger(p.AUDIO_TRACK_LOADING, {
        url: r,
        id: s,
        groupId: i,
        deliveryDirectives: e || null
      });
    }
  }
}
const ji = 500;
class Wl extends Ws {
  constructor(e, t, s) {
    super(e, t, s, "[subtitle-stream-controller]", G.SUBTITLE), this.currentTrackId = -1, this.tracksBuffered = [], this.mainDetails = null, this._registerListeners();
  }
  onHandlerDestroying() {
    this._unregisterListeners(), super.onHandlerDestroying(), this.mainDetails = null;
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.LEVEL_LOADED, this.onLevelLoaded, this), e.on(p.ERROR, this.onError, this), e.on(p.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.on(p.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), e.on(p.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.on(p.SUBTITLE_FRAG_PROCESSED, this.onSubtitleFragProcessed, this), e.on(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.on(p.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.LEVEL_LOADED, this.onLevelLoaded, this), e.off(p.ERROR, this.onError, this), e.off(p.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.off(p.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), e.off(p.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.off(p.SUBTITLE_FRAG_PROCESSED, this.onSubtitleFragProcessed, this), e.off(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.off(p.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  startLoad(e) {
    this.stopLoad(), this.state = C.IDLE, this.setInterval(ji), this.nextLoadPosition = this.startPosition = this.lastCurrentTime = e, this.tick();
  }
  onManifestLoading() {
    this.mainDetails = null, this.fragmentTracker.removeAllFragments();
  }
  onMediaDetaching() {
    this.tracksBuffered = [], super.onMediaDetaching();
  }
  onLevelLoaded(e, t) {
    this.mainDetails = t.details;
  }
  onSubtitleFragProcessed(e, t) {
    const {
      frag: s,
      success: i
    } = t;
    if (this.fragPrevious = s, this.state = C.IDLE, !i)
      return;
    const r = this.tracksBuffered[this.currentTrackId];
    if (!r)
      return;
    let a;
    const o = s.start;
    for (let c = 0; c < r.length; c++)
      if (o >= r[c].start && o <= r[c].end) {
        a = r[c];
        break;
      }
    const l = s.start + s.duration;
    a ? a.end = l : (a = {
      start: o,
      end: l
    }, r.push(a)), this.fragmentTracker.fragBuffered(s), this.fragBufferedComplete(s, null);
  }
  onBufferFlushing(e, t) {
    const {
      startOffset: s,
      endOffset: i
    } = t;
    if (s === 0 && i !== Number.POSITIVE_INFINITY) {
      const r = i - 1;
      if (r <= 0)
        return;
      t.endOffsetSubtitles = Math.max(0, r), this.tracksBuffered.forEach((a) => {
        for (let o = 0; o < a.length; ) {
          if (a[o].end <= r) {
            a.shift();
            continue;
          } else if (a[o].start < r)
            a[o].start = r;
          else
            break;
          o++;
        }
      }), this.fragmentTracker.removeFragmentsInRange(s, r, G.SUBTITLE);
    }
  }
  onFragBuffered(e, t) {
    if (!this.loadedmetadata && t.frag.type === G.MAIN) {
      var s;
      (s = this.media) != null && s.buffered.length && (this.loadedmetadata = !0);
    }
  }
  // If something goes wrong, proceed to next frag, if we were processing one.
  onError(e, t) {
    const s = t.frag;
    (s == null ? void 0 : s.type) === G.SUBTITLE && (t.details === L.FRAG_GAP && this.fragmentTracker.fragBuffered(s, !0), this.fragCurrent && this.fragCurrent.abortRequests(), this.state !== C.STOPPED && (this.state = C.IDLE));
  }
  // Got all new subtitle levels.
  onSubtitleTracksUpdated(e, {
    subtitleTracks: t
  }) {
    if (this.levels && un(this.levels, t)) {
      this.levels = t.map((s) => new Ze(s));
      return;
    }
    this.tracksBuffered = [], this.levels = t.map((s) => {
      const i = new Ze(s);
      return this.tracksBuffered[i.id] = [], i;
    }), this.fragmentTracker.removeFragmentsInRange(0, Number.POSITIVE_INFINITY, G.SUBTITLE), this.fragPrevious = null, this.mediaBuffer = null;
  }
  onSubtitleTrackSwitch(e, t) {
    var s;
    if (this.currentTrackId = t.id, !((s = this.levels) != null && s.length) || this.currentTrackId === -1) {
      this.clearInterval();
      return;
    }
    const i = this.levels[this.currentTrackId];
    i != null && i.details ? this.mediaBuffer = this.mediaBufferTimeRanges : this.mediaBuffer = null, i && this.setInterval(ji);
  }
  // Got a new set of subtitle fragments.
  onSubtitleTrackLoaded(e, t) {
    var s;
    const {
      currentTrackId: i,
      levels: r
    } = this, {
      details: a,
      id: o
    } = t;
    if (!r) {
      this.warn(`Subtitle tracks were reset while loading level ${o}`);
      return;
    }
    const l = r[o];
    if (o >= r.length || !l)
      return;
    this.log(`Subtitle track ${o} loaded [${a.startSN},${a.endSN}]${a.lastPartSn ? `[part-${a.lastPartSn}-${a.lastPartIndex}]` : ""},duration:${a.totalduration}`), this.mediaBuffer = this.mediaBufferTimeRanges;
    let c = 0;
    if (a.live || (s = l.details) != null && s.live) {
      const u = this.mainDetails;
      if (a.deltaUpdateFailed || !u)
        return;
      const d = u.fragments[0];
      if (!l.details)
        a.hasProgramDateTime && u.hasProgramDateTime ? (Bt(a, u), c = a.fragments[0].start) : d && (c = d.start, Ls(a, c));
      else {
        var h;
        c = this.alignPlaylists(a, l.details, (h = this.levelLastLoaded) == null ? void 0 : h.details), c === 0 && d && (c = d.start, Ls(a, c));
      }
    }
    l.details = a, this.levelLastLoaded = l, o === i && (!this.startFragRequested && (this.mainDetails || !a.live) && this.setStartPosition(this.mainDetails || a, c), this.tick(), a.live && !this.fragCurrent && this.media && this.state === C.IDLE && (Ut(null, a.fragments, this.media.currentTime, 0) || (this.warn("Subtitle playlist not aligned with playback"), l.details = void 0)));
  }
  _handleFragmentLoadComplete(e) {
    const {
      frag: t,
      payload: s
    } = e, i = t.decryptdata, r = this.hls;
    if (!this.fragContextChanged(t) && s && s.byteLength > 0 && i != null && i.key && i.iv && i.method === "AES-128") {
      const a = performance.now();
      this.decrypter.decrypt(new Uint8Array(s), i.key.buffer, i.iv.buffer).catch((o) => {
        throw r.trigger(p.ERROR, {
          type: K.MEDIA_ERROR,
          details: L.FRAG_DECRYPT_ERROR,
          fatal: !1,
          error: o,
          reason: o.message,
          frag: t
        }), o;
      }).then((o) => {
        const l = performance.now();
        r.trigger(p.FRAG_DECRYPTED, {
          frag: t,
          payload: o,
          stats: {
            tstart: a,
            tdecrypt: l
          }
        });
      }).catch((o) => {
        this.warn(`${o.name}: ${o.message}`), this.state = C.IDLE;
      });
    }
  }
  doTick() {
    if (!this.media) {
      this.state = C.IDLE;
      return;
    }
    if (this.state === C.IDLE) {
      const {
        currentTrackId: e,
        levels: t
      } = this, s = t == null ? void 0 : t[e];
      if (!s || !t.length || !s.details)
        return;
      const {
        config: i
      } = this, r = this.getLoadPosition(), a = J.bufferedInfo(this.tracksBuffered[this.currentTrackId] || [], r, i.maxBufferHole), {
        end: o,
        len: l
      } = a, c = this.getFwdBufferInfo(this.media, G.MAIN), h = s.details, u = this.getMaxBufferLength(c == null ? void 0 : c.len) + h.levelTargetDuration;
      if (l > u)
        return;
      const d = h.fragments, f = d.length, g = h.edge;
      let m = null;
      const E = this.fragPrevious;
      if (o < g) {
        const T = i.maxFragLookUpTolerance, y = o > g - T ? 0 : T;
        m = Ut(E, d, Math.max(d[0].start, o), y), !m && E && E.start < d[0].start && (m = d[0]);
      } else
        m = d[f - 1];
      if (!m)
        return;
      if (m = this.mapToInitFragWhenRequired(m), m.sn !== "initSegment") {
        const T = m.sn - h.startSN, y = d[T - 1];
        y && y.cc === m.cc && this.fragmentTracker.getState(y) === ae.NOT_LOADED && (m = y);
      }
      this.fragmentTracker.getState(m) === ae.NOT_LOADED && this.loadFragment(m, s, o);
    }
  }
  getMaxBufferLength(e) {
    const t = super.getMaxBufferLength();
    return e ? Math.max(t, e) : t;
  }
  loadFragment(e, t, s) {
    this.fragCurrent = e, e.sn === "initSegment" ? this._loadInitSegment(e, t) : (this.startFragRequested = !0, super.loadFragment(e, t, s));
  }
  get mediaBufferTimeRanges() {
    return new Yl(this.tracksBuffered[this.currentTrackId] || []);
  }
}
class Yl {
  constructor(e) {
    this.buffered = void 0;
    const t = (s, i, r) => {
      if (i = i >>> 0, i > r - 1)
        throw new DOMException(`Failed to execute '${s}' on 'TimeRanges': The index provided (${i}) is greater than the maximum bound (${r})`);
      return e[i][s];
    };
    this.buffered = {
      get length() {
        return e.length;
      },
      end(s) {
        return t("end", s, e.length);
      },
      start(s) {
        return t("start", s, e.length);
      }
    };
  }
}
class ql extends Ks {
  constructor(e) {
    super(e, "[subtitle-track-controller]"), this.media = null, this.tracks = [], this.groupIds = null, this.tracksInGroup = [], this.trackId = -1, this.currentTrack = null, this.selectDefaultTrack = !0, this.queuedDefaultTrack = -1, this.asyncPollTrackChange = () => this.pollTrackChange(0), this.useTextTrackPolling = !1, this.subtitlePollingInterval = -1, this._subtitleDisplay = !0, this.onTextTracksChanged = () => {
      if (this.useTextTrackPolling || self.clearInterval(this.subtitlePollingInterval), !this.media || !this.hls.config.renderTextTracksNatively)
        return;
      let t = null;
      const s = At(this.media.textTracks);
      for (let r = 0; r < s.length; r++)
        if (s[r].mode === "hidden")
          t = s[r];
        else if (s[r].mode === "showing") {
          t = s[r];
          break;
        }
      const i = this.findTrackForTextTrack(t);
      this.subtitleTrack !== i && this.setSubtitleTrack(i);
    }, this.registerListeners();
  }
  destroy() {
    this.unregisterListeners(), this.tracks.length = 0, this.tracksInGroup.length = 0, this.currentTrack = null, this.onTextTracksChanged = this.asyncPollTrackChange = null, super.destroy();
  }
  get subtitleDisplay() {
    return this._subtitleDisplay;
  }
  set subtitleDisplay(e) {
    this._subtitleDisplay = e, this.trackId > -1 && this.toggleTrackModes();
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.MANIFEST_PARSED, this.onManifestParsed, this), e.on(p.LEVEL_LOADING, this.onLevelLoading, this), e.on(p.LEVEL_SWITCHING, this.onLevelSwitching, this), e.on(p.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.on(p.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.MANIFEST_PARSED, this.onManifestParsed, this), e.off(p.LEVEL_LOADING, this.onLevelLoading, this), e.off(p.LEVEL_SWITCHING, this.onLevelSwitching, this), e.off(p.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.off(p.ERROR, this.onError, this);
  }
  // Listen for subtitle track change, then extract the current track ID.
  onMediaAttached(e, t) {
    this.media = t.media, this.media && (this.queuedDefaultTrack > -1 && (this.subtitleTrack = this.queuedDefaultTrack, this.queuedDefaultTrack = -1), this.useTextTrackPolling = !(this.media.textTracks && "onchange" in this.media.textTracks), this.useTextTrackPolling ? this.pollTrackChange(500) : this.media.textTracks.addEventListener("change", this.asyncPollTrackChange));
  }
  pollTrackChange(e) {
    self.clearInterval(this.subtitlePollingInterval), this.subtitlePollingInterval = self.setInterval(this.onTextTracksChanged, e);
  }
  onMediaDetaching() {
    if (!this.media)
      return;
    self.clearInterval(this.subtitlePollingInterval), this.useTextTrackPolling || this.media.textTracks.removeEventListener("change", this.asyncPollTrackChange), this.trackId > -1 && (this.queuedDefaultTrack = this.trackId), At(this.media.textTracks).forEach((t) => {
      ze(t);
    }), this.subtitleTrack = -1, this.media = null;
  }
  onManifestLoading() {
    this.tracks = [], this.groupIds = null, this.tracksInGroup = [], this.trackId = -1, this.currentTrack = null, this.selectDefaultTrack = !0;
  }
  // Fired whenever a new manifest is loaded.
  onManifestParsed(e, t) {
    this.tracks = t.subtitleTracks;
  }
  onSubtitleTrackLoaded(e, t) {
    const {
      id: s,
      groupId: i,
      details: r
    } = t, a = this.tracksInGroup[s];
    if (!a || a.groupId !== i) {
      this.warn(`Subtitle track with id:${s} and group:${i} not found in active group ${a == null ? void 0 : a.groupId}`);
      return;
    }
    const o = a.details;
    a.details = t.details, this.log(`Subtitle track ${s} "${a.name}" lang:${a.lang} group:${i} loaded [${r.startSN}-${r.endSN}]`), s === this.trackId && this.playlistLoaded(s, t, o);
  }
  onLevelLoading(e, t) {
    this.switchLevel(t.level);
  }
  onLevelSwitching(e, t) {
    this.switchLevel(t.level);
  }
  switchLevel(e) {
    const t = this.hls.levels[e];
    if (!t)
      return;
    const s = t.subtitleGroups || null, i = this.groupIds;
    let r = this.currentTrack;
    if (!s || (i == null ? void 0 : i.length) !== (s == null ? void 0 : s.length) || s != null && s.some((a) => (i == null ? void 0 : i.indexOf(a)) === -1)) {
      this.groupIds = s, this.trackId = -1, this.currentTrack = null;
      const a = this.tracks.filter((h) => !s || s.indexOf(h.groupId) !== -1);
      if (a.length)
        this.selectDefaultTrack && !a.some((h) => h.default) && (this.selectDefaultTrack = !1), a.forEach((h, u) => {
          h.id = u;
        });
      else if (!r && !this.tracksInGroup.length)
        return;
      this.tracksInGroup = a;
      const o = this.hls.config.subtitlePreference;
      if (!r && o) {
        this.selectDefaultTrack = !1;
        const h = be(o, a);
        if (h > -1)
          r = a[h];
        else {
          const u = be(o, this.tracks);
          r = this.tracks[u];
        }
      }
      let l = this.findTrackId(r);
      l === -1 && r && (l = this.findTrackId(null));
      const c = {
        subtitleTracks: a
      };
      this.log(`Updating subtitle tracks, ${a.length} track(s) found in "${s == null ? void 0 : s.join(",")}" group-id`), this.hls.trigger(p.SUBTITLE_TRACKS_UPDATED, c), l !== -1 && this.trackId === -1 && this.setSubtitleTrack(l);
    } else this.shouldReloadPlaylist(r) && this.setSubtitleTrack(this.trackId);
  }
  findTrackId(e) {
    const t = this.tracksInGroup, s = this.selectDefaultTrack;
    for (let i = 0; i < t.length; i++) {
      const r = t[i];
      if (!(s && !r.default || !s && !e) && (!e || Xe(r, e)))
        return i;
    }
    if (e) {
      for (let i = 0; i < t.length; i++) {
        const r = t[i];
        if (et(e.attrs, r.attrs, ["LANGUAGE", "ASSOC-LANGUAGE", "CHARACTERISTICS"]))
          return i;
      }
      for (let i = 0; i < t.length; i++) {
        const r = t[i];
        if (et(e.attrs, r.attrs, ["LANGUAGE"]))
          return i;
      }
    }
    return -1;
  }
  findTrackForTextTrack(e) {
    if (e) {
      const t = this.tracksInGroup;
      for (let s = 0; s < t.length; s++) {
        const i = t[s];
        if (Is(i, e))
          return s;
      }
    }
    return -1;
  }
  onError(e, t) {
    t.fatal || !t.context || t.context.type === q.SUBTITLE_TRACK && t.context.id === this.trackId && (!this.groupIds || this.groupIds.indexOf(t.context.groupId) !== -1) && this.checkRetry(t);
  }
  get allSubtitleTracks() {
    return this.tracks;
  }
  /** get alternate subtitle tracks list from playlist **/
  get subtitleTracks() {
    return this.tracksInGroup;
  }
  /** get/set index of the selected subtitle track (based on index in subtitle track lists) **/
  get subtitleTrack() {
    return this.trackId;
  }
  set subtitleTrack(e) {
    this.selectDefaultTrack = !1, this.setSubtitleTrack(e);
  }
  setSubtitleOption(e) {
    if (this.hls.config.subtitlePreference = e, e) {
      const t = this.allSubtitleTracks;
      if (this.selectDefaultTrack = !1, t.length) {
        const s = this.currentTrack;
        if (s && Xe(e, s))
          return s;
        const i = be(e, this.tracksInGroup);
        if (i > -1) {
          const r = this.tracksInGroup[i];
          return this.setSubtitleTrack(i), r;
        } else {
          if (s)
            return null;
          {
            const r = be(e, t);
            if (r > -1)
              return t[r];
          }
        }
      }
    }
    return null;
  }
  loadPlaylist(e) {
    super.loadPlaylist();
    const t = this.currentTrack;
    if (this.shouldLoadPlaylist(t) && t) {
      const s = t.id, i = t.groupId;
      let r = t.url;
      if (e)
        try {
          r = e.addDirectives(r);
        } catch (a) {
          this.warn(`Could not construct new URL with HLS Delivery Directives: ${a}`);
        }
      this.log(`Loading subtitle playlist for id ${s}`), this.hls.trigger(p.SUBTITLE_TRACK_LOADING, {
        url: r,
        id: s,
        groupId: i,
        deliveryDirectives: e || null
      });
    }
  }
  /**
   * Disables the old subtitleTrack and sets current mode on the next subtitleTrack.
   * This operates on the DOM textTracks.
   * A value of -1 will disable all subtitle tracks.
   */
  toggleTrackModes() {
    const {
      media: e
    } = this;
    if (!e)
      return;
    const t = At(e.textTracks), s = this.currentTrack;
    let i;
    if (s && (i = t.filter((r) => Is(s, r))[0], i || this.warn(`Unable to find subtitle TextTrack with name "${s.name}" and language "${s.lang}"`)), [].slice.call(t).forEach((r) => {
      r.mode !== "disabled" && r !== i && (r.mode = "disabled");
    }), i) {
      const r = this.subtitleDisplay ? "showing" : "hidden";
      i.mode !== r && (i.mode = r);
    }
  }
  /**
   * This method is responsible for validating the subtitle index and periodically reloading if live.
   * Dispatches the SUBTITLE_TRACK_SWITCH event, which instructs the subtitle-stream-controller to load the selected track.
   */
  setSubtitleTrack(e) {
    const t = this.tracksInGroup;
    if (!this.media) {
      this.queuedDefaultTrack = e;
      return;
    }
    if (e < -1 || e >= t.length || !M(e)) {
      this.warn(`Invalid subtitle track id: ${e}`);
      return;
    }
    this.clearTimer(), this.selectDefaultTrack = !1;
    const s = this.currentTrack, i = t[e] || null;
    if (this.trackId = e, this.currentTrack = i, this.toggleTrackModes(), !i) {
      this.hls.trigger(p.SUBTITLE_TRACK_SWITCH, {
        id: e
      });
      return;
    }
    const r = !!i.details && !i.details.live;
    if (e === this.trackId && i === s && r)
      return;
    this.log(`Switching to subtitle-track ${e}` + (i ? ` "${i.name}" lang:${i.lang} group:${i.groupId}` : ""));
    const {
      id: a,
      groupId: o = "",
      name: l,
      type: c,
      url: h
    } = i;
    this.hls.trigger(p.SUBTITLE_TRACK_SWITCH, {
      id: a,
      groupId: o,
      name: l,
      type: c,
      url: h
    });
    const u = this.switchParams(i.url, s == null ? void 0 : s.details, i.details);
    this.loadPlaylist(u);
  }
}
class jl {
  constructor(e) {
    this.buffers = void 0, this.queues = {
      video: [],
      audio: [],
      audiovideo: []
    }, this.buffers = e;
  }
  append(e, t, s) {
    const i = this.queues[t];
    i.push(e), i.length === 1 && !s && this.executeNext(t);
  }
  insertAbort(e, t) {
    this.queues[t].unshift(e), this.executeNext(t);
  }
  appendBlocker(e) {
    let t;
    const s = new Promise((r) => {
      t = r;
    }), i = {
      execute: t,
      onStart: () => {
      },
      onComplete: () => {
      },
      onError: () => {
      }
    };
    return this.append(i, e), s;
  }
  executeNext(e) {
    const t = this.queues[e];
    if (t.length) {
      const s = t[0];
      try {
        s.execute();
      } catch (i) {
        v.warn(`[buffer-operation-queue]: Exception executing "${e}" SourceBuffer operation: ${i}`), s.onError(i);
        const r = this.buffers[e];
        r != null && r.updating || this.shiftAndExecuteNext(e);
      }
    }
  }
  shiftAndExecuteNext(e) {
    this.queues[e].shift(), this.executeNext(e);
  }
  current(e) {
    return this.queues[e][0];
  }
}
const zi = /(avc[1234]|hvc1|hev1|dvh[1e]|vp09|av01)(?:\.[^.,]+)+/;
class zl {
  constructor(e) {
    this.details = null, this._objectUrl = null, this.operationQueue = void 0, this.listeners = void 0, this.hls = void 0, this.bufferCodecEventsExpected = 0, this._bufferCodecEventsTotal = 0, this.media = null, this.mediaSource = null, this.lastMpegAudioChunk = null, this.appendSource = void 0, this.appendErrors = {
      audio: 0,
      video: 0,
      audiovideo: 0
    }, this.tracks = {}, this.pendingTracks = {}, this.sourceBuffer = void 0, this.log = void 0, this.warn = void 0, this.error = void 0, this._onEndStreaming = (s) => {
      this.hls && this.hls.pauseBuffering();
    }, this._onStartStreaming = (s) => {
      this.hls && this.hls.resumeBuffering();
    }, this._onMediaSourceOpen = () => {
      const {
        media: s,
        mediaSource: i
      } = this;
      this.log("Media source opened"), s && (s.removeEventListener("emptied", this._onMediaEmptied), this.updateMediaElementDuration(), this.hls.trigger(p.MEDIA_ATTACHED, {
        media: s,
        mediaSource: i
      })), i && i.removeEventListener("sourceopen", this._onMediaSourceOpen), this.checkPendingTracks();
    }, this._onMediaSourceClose = () => {
      this.log("Media source closed");
    }, this._onMediaSourceEnded = () => {
      this.log("Media source ended");
    }, this._onMediaEmptied = () => {
      const {
        mediaSrc: s,
        _objectUrl: i
      } = this;
      s !== i && v.error(`Media element src was set while attaching MediaSource (${i} > ${s})`);
    }, this.hls = e;
    const t = "[buffer-controller]";
    this.appendSource = io(Ve(e.config.preferManagedMediaSource)), this.log = v.log.bind(v, t), this.warn = v.warn.bind(v, t), this.error = v.error.bind(v, t), this._initSourceBuffer(), this.registerListeners();
  }
  hasSourceTypes() {
    return this.getSourceBufferTypes().length > 0 || Object.keys(this.pendingTracks).length > 0;
  }
  destroy() {
    this.unregisterListeners(), this.details = null, this.lastMpegAudioChunk = null, this.hls = null;
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.MANIFEST_PARSED, this.onManifestParsed, this), e.on(p.BUFFER_RESET, this.onBufferReset, this), e.on(p.BUFFER_APPENDING, this.onBufferAppending, this), e.on(p.BUFFER_CODECS, this.onBufferCodecs, this), e.on(p.BUFFER_EOS, this.onBufferEos, this), e.on(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.on(p.LEVEL_UPDATED, this.onLevelUpdated, this), e.on(p.FRAG_PARSED, this.onFragParsed, this), e.on(p.FRAG_CHANGED, this.onFragChanged, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.MANIFEST_PARSED, this.onManifestParsed, this), e.off(p.BUFFER_RESET, this.onBufferReset, this), e.off(p.BUFFER_APPENDING, this.onBufferAppending, this), e.off(p.BUFFER_CODECS, this.onBufferCodecs, this), e.off(p.BUFFER_EOS, this.onBufferEos, this), e.off(p.BUFFER_FLUSHING, this.onBufferFlushing, this), e.off(p.LEVEL_UPDATED, this.onLevelUpdated, this), e.off(p.FRAG_PARSED, this.onFragParsed, this), e.off(p.FRAG_CHANGED, this.onFragChanged, this);
  }
  _initSourceBuffer() {
    this.sourceBuffer = {}, this.operationQueue = new jl(this.sourceBuffer), this.listeners = {
      audio: [],
      video: [],
      audiovideo: []
    }, this.appendErrors = {
      audio: 0,
      video: 0,
      audiovideo: 0
    }, this.lastMpegAudioChunk = null;
  }
  onManifestLoading() {
    this.bufferCodecEventsExpected = this._bufferCodecEventsTotal = 0, this.details = null;
  }
  onManifestParsed(e, t) {
    let s = 2;
    (t.audio && !t.video || !t.altAudio) && (s = 1), this.bufferCodecEventsExpected = this._bufferCodecEventsTotal = s, this.log(`${this.bufferCodecEventsExpected} bufferCodec event(s) expected`);
  }
  onMediaAttaching(e, t) {
    const s = this.media = t.media, i = Ve(this.appendSource);
    if (s && i) {
      var r;
      const a = this.mediaSource = new i();
      this.log(`created media source: ${(r = a.constructor) == null ? void 0 : r.name}`), a.addEventListener("sourceopen", this._onMediaSourceOpen), a.addEventListener("sourceended", this._onMediaSourceEnded), a.addEventListener("sourceclose", this._onMediaSourceClose), this.appendSource && (a.addEventListener("startstreaming", this._onStartStreaming), a.addEventListener("endstreaming", this._onEndStreaming));
      const o = this._objectUrl = self.URL.createObjectURL(a);
      if (this.appendSource)
        try {
          s.removeAttribute("src");
          const l = self.ManagedMediaSource;
          s.disableRemotePlayback = s.disableRemotePlayback || l && a instanceof l, Xi(s), Xl(s, o), s.load();
        } catch {
          s.src = o;
        }
      else
        s.src = o;
      s.addEventListener("emptied", this._onMediaEmptied);
    }
  }
  onMediaDetaching() {
    const {
      media: e,
      mediaSource: t,
      _objectUrl: s
    } = this;
    if (t) {
      if (this.log("media source detaching"), t.readyState === "open")
        try {
          t.endOfStream();
        } catch (i) {
          this.warn(`onMediaDetaching: ${i.message} while calling endOfStream`);
        }
      this.onBufferReset(), t.removeEventListener("sourceopen", this._onMediaSourceOpen), t.removeEventListener("sourceended", this._onMediaSourceEnded), t.removeEventListener("sourceclose", this._onMediaSourceClose), this.appendSource && (t.removeEventListener("startstreaming", this._onStartStreaming), t.removeEventListener("endstreaming", this._onEndStreaming)), e && (e.removeEventListener("emptied", this._onMediaEmptied), s && self.URL.revokeObjectURL(s), this.mediaSrc === s ? (e.removeAttribute("src"), this.appendSource && Xi(e), e.load()) : this.warn("media|source.src was changed by a third party - skip cleanup")), this.mediaSource = null, this.media = null, this._objectUrl = null, this.bufferCodecEventsExpected = this._bufferCodecEventsTotal, this.pendingTracks = {}, this.tracks = {};
    }
    this.hls.trigger(p.MEDIA_DETACHED, void 0);
  }
  onBufferReset() {
    this.getSourceBufferTypes().forEach((e) => {
      this.resetBuffer(e);
    }), this._initSourceBuffer();
  }
  resetBuffer(e) {
    const t = this.sourceBuffer[e];
    try {
      if (t) {
        var s;
        this.removeBufferListeners(e), this.sourceBuffer[e] = void 0, (s = this.mediaSource) != null && s.sourceBuffers.length && this.mediaSource.removeSourceBuffer(t);
      }
    } catch (i) {
      this.warn(`onBufferReset ${e}`, i);
    }
  }
  onBufferCodecs(e, t) {
    const s = this.getSourceBufferTypes().length, i = Object.keys(t);
    if (i.forEach((a) => {
      if (s) {
        const l = this.tracks[a];
        if (l && typeof l.buffer.changeType == "function") {
          var o;
          const {
            id: c,
            codec: h,
            levelCodec: u,
            container: d,
            metadata: f
          } = t[a], g = Ei(l.codec, l.levelCodec), m = g == null ? void 0 : g.replace(zi, "$1");
          let E = Ei(h, u);
          const T = (o = E) == null ? void 0 : o.replace(zi, "$1");
          if (E && m !== T) {
            a.slice(0, 5) === "audio" && (E = Ft(E, this.appendSource));
            const y = `${d};codecs=${E}`;
            this.appendChangeType(a, y), this.log(`switching codec ${g} to ${E}`), this.tracks[a] = {
              buffer: l.buffer,
              codec: h,
              container: d,
              levelCodec: u,
              metadata: f,
              id: c
            };
          }
        }
      } else
        this.pendingTracks[a] = t[a];
    }), s)
      return;
    const r = Math.max(this.bufferCodecEventsExpected - 1, 0);
    this.bufferCodecEventsExpected !== r && (this.log(`${r} bufferCodec event(s) expected ${i.join(",")}`), this.bufferCodecEventsExpected = r), this.mediaSource && this.mediaSource.readyState === "open" && this.checkPendingTracks();
  }
  appendChangeType(e, t) {
    const {
      operationQueue: s
    } = this, i = {
      execute: () => {
        const r = this.sourceBuffer[e];
        r && (this.log(`changing ${e} sourceBuffer type to ${t}`), r.changeType(t)), s.shiftAndExecuteNext(e);
      },
      onStart: () => {
      },
      onComplete: () => {
      },
      onError: (r) => {
        this.warn(`Failed to change ${e} SourceBuffer type`, r);
      }
    };
    s.append(i, e, !!this.pendingTracks[e]);
  }
  onBufferAppending(e, t) {
    const {
      hls: s,
      operationQueue: i,
      tracks: r
    } = this, {
      data: a,
      type: o,
      frag: l,
      part: c,
      chunkMeta: h
    } = t, u = h.buffering[o], d = self.performance.now();
    u.start = d;
    const f = l.stats.buffering, g = c ? c.stats.buffering : null;
    f.start === 0 && (f.start = d), g && g.start === 0 && (g.start = d);
    const m = r.audio;
    let E = !1;
    o === "audio" && (m == null ? void 0 : m.container) === "audio/mpeg" && (E = !this.lastMpegAudioChunk || h.id === 1 || this.lastMpegAudioChunk.sn !== h.sn, this.lastMpegAudioChunk = h);
    const T = l.start, y = {
      execute: () => {
        if (u.executeStart = self.performance.now(), E) {
          const x = this.sourceBuffer[o];
          if (x) {
            const b = T - x.timestampOffset;
            Math.abs(b) >= 0.1 && (this.log(`Updating audio SourceBuffer timestampOffset to ${T} (delta: ${b}) sn: ${l.sn})`), x.timestampOffset = T);
          }
        }
        this.appendExecutor(a, o);
      },
      onStart: () => {
      },
      onComplete: () => {
        const x = self.performance.now();
        u.executeEnd = u.end = x, f.first === 0 && (f.first = x), g && g.first === 0 && (g.first = x);
        const {
          sourceBuffer: b
        } = this, S = {};
        for (const D in b)
          S[D] = J.getBuffered(b[D]);
        this.appendErrors[o] = 0, o === "audio" || o === "video" ? this.appendErrors.audiovideo = 0 : (this.appendErrors.audio = 0, this.appendErrors.video = 0), this.hls.trigger(p.BUFFER_APPENDED, {
          type: o,
          frag: l,
          part: c,
          chunkMeta: h,
          parent: l.type,
          timeRanges: S
        });
      },
      onError: (x) => {
        const b = {
          type: K.MEDIA_ERROR,
          parent: l.type,
          details: L.BUFFER_APPEND_ERROR,
          sourceBufferName: o,
          frag: l,
          part: c,
          chunkMeta: h,
          error: x,
          err: x,
          fatal: !1
        };
        if (x.code === DOMException.QUOTA_EXCEEDED_ERR)
          b.details = L.BUFFER_FULL_ERROR;
        else {
          const S = ++this.appendErrors[o];
          b.details = L.BUFFER_APPEND_ERROR, this.warn(`Failed ${S}/${s.config.appendErrorMaxRetry} times to append segment in "${o}" sourceBuffer`), S >= s.config.appendErrorMaxRetry && (b.fatal = !0);
        }
        s.trigger(p.ERROR, b);
      }
    };
    i.append(y, o, !!this.pendingTracks[o]);
  }
  onBufferFlushing(e, t) {
    const {
      operationQueue: s
    } = this, i = (r) => ({
      execute: this.removeExecutor.bind(this, r, t.startOffset, t.endOffset),
      onStart: () => {
      },
      onComplete: () => {
        this.hls.trigger(p.BUFFER_FLUSHED, {
          type: r
        });
      },
      onError: (a) => {
        this.warn(`Failed to remove from ${r} SourceBuffer`, a);
      }
    });
    t.type ? s.append(i(t.type), t.type) : this.getSourceBufferTypes().forEach((r) => {
      s.append(i(r), r);
    });
  }
  onFragParsed(e, t) {
    const {
      frag: s,
      part: i
    } = t, r = [], a = i ? i.elementaryStreams : s.elementaryStreams;
    a[Q.AUDIOVIDEO] ? r.push("audiovideo") : (a[Q.AUDIO] && r.push("audio"), a[Q.VIDEO] && r.push("video"));
    const o = () => {
      const l = self.performance.now();
      s.stats.buffering.end = l, i && (i.stats.buffering.end = l);
      const c = i ? i.stats : s.stats;
      this.hls.trigger(p.FRAG_BUFFERED, {
        frag: s,
        part: i,
        stats: c,
        id: s.type
      });
    };
    r.length === 0 && this.warn(`Fragments must have at least one ElementaryStreamType set. type: ${s.type} level: ${s.level} sn: ${s.sn}`), this.blockBuffers(o, r);
  }
  onFragChanged(e, t) {
    this.trimBuffers();
  }
  // on BUFFER_EOS mark matching sourcebuffer(s) as ended and trigger checkEos()
  // an undefined data.type will mark all buffers as EOS.
  onBufferEos(e, t) {
    this.getSourceBufferTypes().reduce((i, r) => {
      const a = this.sourceBuffer[r];
      return a && (!t.type || t.type === r) && (a.ending = !0, a.ended || (a.ended = !0, this.log(`${r} sourceBuffer now EOS`))), i && !!(!a || a.ended);
    }, !0) && (this.log("Queueing mediaSource.endOfStream()"), this.blockBuffers(() => {
      this.getSourceBufferTypes().forEach((r) => {
        const a = this.sourceBuffer[r];
        a && (a.ending = !1);
      });
      const {
        mediaSource: i
      } = this;
      if (!i || i.readyState !== "open") {
        i && this.log(`Could not call mediaSource.endOfStream(). mediaSource.readyState: ${i.readyState}`);
        return;
      }
      this.log("Calling mediaSource.endOfStream()"), i.endOfStream();
    }));
  }
  onLevelUpdated(e, {
    details: t
  }) {
    t.fragments.length && (this.details = t, this.getSourceBufferTypes().length ? this.blockBuffers(this.updateMediaElementDuration.bind(this)) : this.updateMediaElementDuration());
  }
  trimBuffers() {
    const {
      hls: e,
      details: t,
      media: s
    } = this;
    if (!s || t === null || !this.getSourceBufferTypes().length)
      return;
    const r = e.config, a = s.currentTime, o = t.levelTargetDuration, l = t.live && r.liveBackBufferLength !== null ? r.liveBackBufferLength : r.backBufferLength;
    if (M(l) && l > 0) {
      const c = Math.max(l, o), h = Math.floor(a / o) * o - c;
      this.flushBackBuffer(a, o, h);
    }
    if (M(r.frontBufferFlushThreshold) && r.frontBufferFlushThreshold > 0) {
      const c = Math.max(r.maxBufferLength, r.frontBufferFlushThreshold), h = Math.max(c, o), u = Math.floor(a / o) * o + h;
      this.flushFrontBuffer(a, o, u);
    }
  }
  flushBackBuffer(e, t, s) {
    const {
      details: i,
      sourceBuffer: r
    } = this;
    this.getSourceBufferTypes().forEach((o) => {
      const l = r[o];
      if (l) {
        const c = J.getBuffered(l);
        if (c.length > 0 && s > c.start(0)) {
          if (this.hls.trigger(p.BACK_BUFFER_REACHED, {
            bufferEnd: s
          }), i != null && i.live)
            this.hls.trigger(p.LIVE_BACK_BUFFER_REACHED, {
              bufferEnd: s
            });
          else if (l.ended && c.end(c.length - 1) - e < t * 2) {
            this.log(`Cannot flush ${o} back buffer while SourceBuffer is in ended state`);
            return;
          }
          this.hls.trigger(p.BUFFER_FLUSHING, {
            startOffset: 0,
            endOffset: s,
            type: o
          });
        }
      }
    });
  }
  flushFrontBuffer(e, t, s) {
    const {
      sourceBuffer: i
    } = this;
    this.getSourceBufferTypes().forEach((a) => {
      const o = i[a];
      if (o) {
        const l = J.getBuffered(o), c = l.length;
        if (c < 2)
          return;
        const h = l.start(c - 1), u = l.end(c - 1);
        if (s > h || e >= h && e <= u)
          return;
        if (o.ended && e - u < 2 * t) {
          this.log(`Cannot flush ${a} front buffer while SourceBuffer is in ended state`);
          return;
        }
        this.hls.trigger(p.BUFFER_FLUSHING, {
          startOffset: h,
          endOffset: 1 / 0,
          type: a
        });
      }
    });
  }
  /**
   * Update Media Source duration to current level duration or override to Infinity if configuration parameter
   * 'liveDurationInfinity` is set to `true`
   * More details: https://github.com/video-dev/hls.js/issues/355
   */
  updateMediaElementDuration() {
    if (!this.details || !this.media || !this.mediaSource || this.mediaSource.readyState !== "open")
      return;
    const {
      details: e,
      hls: t,
      media: s,
      mediaSource: i
    } = this, r = e.fragments[0].start + e.totalduration, a = s.duration, o = M(i.duration) ? i.duration : 0;
    e.live && t.config.liveDurationInfinity ? (i.duration = 1 / 0, this.updateSeekableRange(e)) : (r > o && r > a || !M(a)) && (this.log(`Updating Media Source duration to ${r.toFixed(3)}`), i.duration = r);
  }
  updateSeekableRange(e) {
    const t = this.mediaSource, s = e.fragments;
    if (s.length && e.live && t != null && t.setLiveSeekableRange) {
      const r = Math.max(0, s[0].start), a = Math.max(r, r + e.totalduration);
      this.log(`Media Source duration is set to ${t.duration}. Setting seekable range to ${r}-${a}.`), t.setLiveSeekableRange(r, a);
    }
  }
  checkPendingTracks() {
    const {
      bufferCodecEventsExpected: e,
      operationQueue: t,
      pendingTracks: s
    } = this, i = Object.keys(s).length;
    if (i && (!e || i === 2 || "audiovideo" in s)) {
      this.createSourceBuffers(s), this.pendingTracks = {};
      const r = this.getSourceBufferTypes();
      if (r.length)
        this.hls.trigger(p.BUFFER_CREATED, {
          tracks: this.tracks
        }), r.forEach((a) => {
          t.executeNext(a);
        });
      else {
        const a = new Error("could not create source buffer for media codec(s)");
        this.hls.trigger(p.ERROR, {
          type: K.MEDIA_ERROR,
          details: L.BUFFER_INCOMPATIBLE_CODECS_ERROR,
          fatal: !0,
          error: a,
          reason: a.message
        });
      }
    }
  }
  createSourceBuffers(e) {
    const {
      sourceBuffer: t,
      mediaSource: s
    } = this;
    if (!s)
      throw Error("createSourceBuffers called when mediaSource was null");
    for (const r in e)
      if (!t[r]) {
        var i;
        const a = e[r];
        if (!a)
          throw Error(`source buffer exists for track ${r}, however track does not`);
        let o = ((i = a.levelCodec) == null ? void 0 : i.indexOf(",")) === -1 ? a.levelCodec : a.codec;
        o && r.slice(0, 5) === "audio" && (o = Ft(o, this.appendSource));
        const l = `${a.container};codecs=${o}`;
        this.log(`creating sourceBuffer(${l})`);
        try {
          const c = t[r] = s.addSourceBuffer(l), h = r;
          this.addBufferListener(h, "updatestart", this._onSBUpdateStart), this.addBufferListener(h, "updateend", this._onSBUpdateEnd), this.addBufferListener(h, "error", this._onSBUpdateError), this.appendSource && this.addBufferListener(h, "bufferedchange", (u, d) => {
            const f = d.removedRanges;
            f != null && f.length && this.hls.trigger(p.BUFFER_FLUSHED, {
              type: r
            });
          }), this.tracks[r] = {
            buffer: c,
            codec: o,
            container: a.container,
            levelCodec: a.levelCodec,
            metadata: a.metadata,
            id: a.id
          };
        } catch (c) {
          this.error(`error while trying to add sourceBuffer: ${c.message}`), this.hls.trigger(p.ERROR, {
            type: K.MEDIA_ERROR,
            details: L.BUFFER_ADD_CODEC_ERROR,
            fatal: !1,
            error: c,
            sourceBufferName: r,
            mimeType: l
          });
        }
      }
  }
  get mediaSrc() {
    var e, t;
    const s = ((e = this.media) == null || (t = e.querySelector) == null ? void 0 : t.call(e, "source")) || this.media;
    return s == null ? void 0 : s.src;
  }
  _onSBUpdateStart(e) {
    const {
      operationQueue: t
    } = this;
    t.current(e).onStart();
  }
  _onSBUpdateEnd(e) {
    var t;
    if (((t = this.mediaSource) == null ? void 0 : t.readyState) === "closed") {
      this.resetBuffer(e);
      return;
    }
    const {
      operationQueue: s
    } = this;
    s.current(e).onComplete(), s.shiftAndExecuteNext(e);
  }
  _onSBUpdateError(e, t) {
    var s;
    const i = new Error(`${e} SourceBuffer error. MediaSource readyState: ${(s = this.mediaSource) == null ? void 0 : s.readyState}`);
    this.error(`${i}`, t), this.hls.trigger(p.ERROR, {
      type: K.MEDIA_ERROR,
      details: L.BUFFER_APPENDING_ERROR,
      sourceBufferName: e,
      error: i,
      fatal: !1
    });
    const r = this.operationQueue.current(e);
    r && r.onError(i);
  }
  // This method must result in an updateend event; if remove is not called, _onSBUpdateEnd must be called manually
  removeExecutor(e, t, s) {
    const {
      media: i,
      mediaSource: r,
      operationQueue: a,
      sourceBuffer: o
    } = this, l = o[e];
    if (!i || !r || !l) {
      this.warn(`Attempting to remove from the ${e} SourceBuffer, but it does not exist`), a.shiftAndExecuteNext(e);
      return;
    }
    const c = M(i.duration) ? i.duration : 1 / 0, h = M(r.duration) ? r.duration : 1 / 0, u = Math.max(0, t), d = Math.min(s, c, h);
    d > u && (!l.ending || l.ended) ? (l.ended = !1, this.log(`Removing [${u},${d}] from the ${e} SourceBuffer`), l.remove(u, d)) : a.shiftAndExecuteNext(e);
  }
  // This method must result in an updateend event; if append is not called, _onSBUpdateEnd must be called manually
  appendExecutor(e, t) {
    const s = this.sourceBuffer[t];
    if (!s) {
      if (!this.pendingTracks[t])
        throw new Error(`Attempting to append to the ${t} SourceBuffer, but it does not exist`);
      return;
    }
    s.ended = !1, s.appendBuffer(e);
  }
  // Enqueues an operation to each SourceBuffer queue which, upon execution, resolves a promise. When all promises
  // resolve, the onUnblocked function is executed. Functions calling this method do not need to unblock the queue
  // upon completion, since we already do it here
  blockBuffers(e, t = this.getSourceBufferTypes()) {
    if (!t.length) {
      this.log("Blocking operation requested, but no SourceBuffers exist"), Promise.resolve().then(e);
      return;
    }
    const {
      operationQueue: s
    } = this, i = t.map((r) => s.appendBlocker(r));
    Promise.all(i).then(() => {
      e(), t.forEach((r) => {
        const a = this.sourceBuffer[r];
        a != null && a.updating || s.shiftAndExecuteNext(r);
      });
    });
  }
  getSourceBufferTypes() {
    return Object.keys(this.sourceBuffer);
  }
  addBufferListener(e, t, s) {
    const i = this.sourceBuffer[e];
    if (!i)
      return;
    const r = s.bind(this, e);
    this.listeners[e].push({
      event: t,
      listener: r
    }), i.addEventListener(t, r);
  }
  removeBufferListeners(e) {
    const t = this.sourceBuffer[e];
    t && this.listeners[e].forEach((s) => {
      t.removeEventListener(s.event, s.listener);
    });
  }
}
function Xi(n) {
  const e = n.querySelectorAll("source");
  [].slice.call(e).forEach((t) => {
    n.removeChild(t);
  });
}
function Xl(n, e) {
  const t = self.document.createElement("source");
  t.type = "video/mp4", t.src = e, n.appendChild(t);
}
const Ql = {
  42: 225,
  // lowercase a, acute accent
  92: 233,
  // lowercase e, acute accent
  94: 237,
  // lowercase i, acute accent
  95: 243,
  // lowercase o, acute accent
  96: 250,
  // lowercase u, acute accent
  123: 231,
  // lowercase c with cedilla
  124: 247,
  // division symbol
  125: 209,
  // uppercase N tilde
  126: 241,
  // lowercase n tilde
  127: 9608,
  // Full block
  // THIS BLOCK INCLUDES THE 16 EXTENDED (TWO-BYTE) LINE 21 CHARACTERS
  // THAT COME FROM HI BYTE=0x11 AND LOW BETWEEN 0x30 AND 0x3F
  // THIS MEANS THAT \x50 MUST BE ADDED TO THE VALUES
  128: 174,
  // Registered symbol (R)
  129: 176,
  // degree sign
  130: 189,
  // 1/2 symbol
  131: 191,
  // Inverted (open) question mark
  132: 8482,
  // Trademark symbol (TM)
  133: 162,
  // Cents symbol
  134: 163,
  // Pounds sterling
  135: 9834,
  // Music 8'th note
  136: 224,
  // lowercase a, grave accent
  137: 32,
  // transparent space (regular)
  138: 232,
  // lowercase e, grave accent
  139: 226,
  // lowercase a, circumflex accent
  140: 234,
  // lowercase e, circumflex accent
  141: 238,
  // lowercase i, circumflex accent
  142: 244,
  // lowercase o, circumflex accent
  143: 251,
  // lowercase u, circumflex accent
  // THIS BLOCK INCLUDES THE 32 EXTENDED (TWO-BYTE) LINE 21 CHARACTERS
  // THAT COME FROM HI BYTE=0x12 AND LOW BETWEEN 0x20 AND 0x3F
  144: 193,
  // capital letter A with acute
  145: 201,
  // capital letter E with acute
  146: 211,
  // capital letter O with acute
  147: 218,
  // capital letter U with acute
  148: 220,
  // capital letter U with diaresis
  149: 252,
  // lowercase letter U with diaeresis
  150: 8216,
  // opening single quote
  151: 161,
  // inverted exclamation mark
  152: 42,
  // asterisk
  153: 8217,
  // closing single quote
  154: 9473,
  // box drawings heavy horizontal
  155: 169,
  // copyright sign
  156: 8480,
  // Service mark
  157: 8226,
  // (round) bullet
  158: 8220,
  // Left double quotation mark
  159: 8221,
  // Right double quotation mark
  160: 192,
  // uppercase A, grave accent
  161: 194,
  // uppercase A, circumflex
  162: 199,
  // uppercase C with cedilla
  163: 200,
  // uppercase E, grave accent
  164: 202,
  // uppercase E, circumflex
  165: 203,
  // capital letter E with diaresis
  166: 235,
  // lowercase letter e with diaresis
  167: 206,
  // uppercase I, circumflex
  168: 207,
  // uppercase I, with diaresis
  169: 239,
  // lowercase i, with diaresis
  170: 212,
  // uppercase O, circumflex
  171: 217,
  // uppercase U, grave accent
  172: 249,
  // lowercase u, grave accent
  173: 219,
  // uppercase U, circumflex
  174: 171,
  // left-pointing double angle quotation mark
  175: 187,
  // right-pointing double angle quotation mark
  // THIS BLOCK INCLUDES THE 32 EXTENDED (TWO-BYTE) LINE 21 CHARACTERS
  // THAT COME FROM HI BYTE=0x13 AND LOW BETWEEN 0x20 AND 0x3F
  176: 195,
  // Uppercase A, tilde
  177: 227,
  // Lowercase a, tilde
  178: 205,
  // Uppercase I, acute accent
  179: 204,
  // Uppercase I, grave accent
  180: 236,
  // Lowercase i, grave accent
  181: 210,
  // Uppercase O, grave accent
  182: 242,
  // Lowercase o, grave accent
  183: 213,
  // Uppercase O, tilde
  184: 245,
  // Lowercase o, tilde
  185: 123,
  // Open curly brace
  186: 125,
  // Closing curly brace
  187: 92,
  // Backslash
  188: 94,
  // Caret
  189: 95,
  // Underscore
  190: 124,
  // Pipe (vertical line)
  191: 8764,
  // Tilde operator
  192: 196,
  // Uppercase A, umlaut
  193: 228,
  // Lowercase A, umlaut
  194: 214,
  // Uppercase O, umlaut
  195: 246,
  // Lowercase o, umlaut
  196: 223,
  // Esszett (sharp S)
  197: 165,
  // Yen symbol
  198: 164,
  // Generic currency sign
  199: 9475,
  // Box drawings heavy vertical
  200: 197,
  // Uppercase A, ring
  201: 229,
  // Lowercase A, ring
  202: 216,
  // Uppercase O, stroke
  203: 248,
  // Lowercase o, strok
  204: 9487,
  // Box drawings heavy down and right
  205: 9491,
  // Box drawings heavy down and left
  206: 9495,
  // Box drawings heavy up and right
  207: 9499
  // Box drawings heavy up and left
}, dn = (n) => String.fromCharCode(Ql[n] || n), xe = 15, _e = 100, Jl = {
  17: 1,
  18: 3,
  21: 5,
  22: 7,
  23: 9,
  16: 11,
  19: 12,
  20: 14
}, Zl = {
  17: 2,
  18: 4,
  21: 6,
  22: 8,
  23: 10,
  19: 13,
  20: 15
}, ec = {
  25: 1,
  26: 3,
  29: 5,
  30: 7,
  31: 9,
  24: 11,
  27: 12,
  28: 14
}, tc = {
  25: 2,
  26: 4,
  29: 6,
  30: 8,
  31: 10,
  27: 13,
  28: 15
}, sc = ["white", "green", "blue", "cyan", "red", "yellow", "magenta", "black", "transparent"];
class ic {
  constructor() {
    this.time = null, this.verboseLevel = 0;
  }
  log(e, t) {
    if (this.verboseLevel >= e) {
      const s = typeof t == "function" ? t() : t;
      v.log(`${this.time} [${e}] ${s}`);
    }
  }
}
const Ne = function(e) {
  const t = [];
  for (let s = 0; s < e.length; s++)
    t.push(e[s].toString(16));
  return t;
};
class fn {
  constructor() {
    this.foreground = "white", this.underline = !1, this.italics = !1, this.background = "black", this.flash = !1;
  }
  reset() {
    this.foreground = "white", this.underline = !1, this.italics = !1, this.background = "black", this.flash = !1;
  }
  setStyles(e) {
    const t = ["foreground", "underline", "italics", "background", "flash"];
    for (let s = 0; s < t.length; s++) {
      const i = t[s];
      e.hasOwnProperty(i) && (this[i] = e[i]);
    }
  }
  isDefault() {
    return this.foreground === "white" && !this.underline && !this.italics && this.background === "black" && !this.flash;
  }
  equals(e) {
    return this.foreground === e.foreground && this.underline === e.underline && this.italics === e.italics && this.background === e.background && this.flash === e.flash;
  }
  copy(e) {
    this.foreground = e.foreground, this.underline = e.underline, this.italics = e.italics, this.background = e.background, this.flash = e.flash;
  }
  toString() {
    return "color=" + this.foreground + ", underline=" + this.underline + ", italics=" + this.italics + ", background=" + this.background + ", flash=" + this.flash;
  }
}
class rc {
  constructor() {
    this.uchar = " ", this.penState = new fn();
  }
  reset() {
    this.uchar = " ", this.penState.reset();
  }
  setChar(e, t) {
    this.uchar = e, this.penState.copy(t);
  }
  setPenState(e) {
    this.penState.copy(e);
  }
  equals(e) {
    return this.uchar === e.uchar && this.penState.equals(e.penState);
  }
  copy(e) {
    this.uchar = e.uchar, this.penState.copy(e.penState);
  }
  isEmpty() {
    return this.uchar === " " && this.penState.isDefault();
  }
}
class nc {
  constructor(e) {
    this.chars = [], this.pos = 0, this.currPenState = new fn(), this.cueStartTime = null, this.logger = void 0;
    for (let t = 0; t < _e; t++)
      this.chars.push(new rc());
    this.logger = e;
  }
  equals(e) {
    for (let t = 0; t < _e; t++)
      if (!this.chars[t].equals(e.chars[t]))
        return !1;
    return !0;
  }
  copy(e) {
    for (let t = 0; t < _e; t++)
      this.chars[t].copy(e.chars[t]);
  }
  isEmpty() {
    let e = !0;
    for (let t = 0; t < _e; t++)
      if (!this.chars[t].isEmpty()) {
        e = !1;
        break;
      }
    return e;
  }
  /**
   *  Set the cursor to a valid column.
   */
  setCursor(e) {
    this.pos !== e && (this.pos = e), this.pos < 0 ? (this.logger.log(3, "Negative cursor position " + this.pos), this.pos = 0) : this.pos > _e && (this.logger.log(3, "Too large cursor position " + this.pos), this.pos = _e);
  }
  /**
   * Move the cursor relative to current position.
   */
  moveCursor(e) {
    const t = this.pos + e;
    if (e > 1)
      for (let s = this.pos + 1; s < t + 1; s++)
        this.chars[s].setPenState(this.currPenState);
    this.setCursor(t);
  }
  /**
   * Backspace, move one step back and clear character.
   */
  backSpace() {
    this.moveCursor(-1), this.chars[this.pos].setChar(" ", this.currPenState);
  }
  insertChar(e) {
    e >= 144 && this.backSpace();
    const t = dn(e);
    if (this.pos >= _e) {
      this.logger.log(0, () => "Cannot insert " + e.toString(16) + " (" + t + ") at position " + this.pos + ". Skipping it!");
      return;
    }
    this.chars[this.pos].setChar(t, this.currPenState), this.moveCursor(1);
  }
  clearFromPos(e) {
    let t;
    for (t = e; t < _e; t++)
      this.chars[t].reset();
  }
  clear() {
    this.clearFromPos(0), this.pos = 0, this.currPenState.reset();
  }
  clearToEndOfRow() {
    this.clearFromPos(this.pos);
  }
  getTextString() {
    const e = [];
    let t = !0;
    for (let s = 0; s < _e; s++) {
      const i = this.chars[s].uchar;
      i !== " " && (t = !1), e.push(i);
    }
    return t ? "" : e.join("");
  }
  setPenStyles(e) {
    this.currPenState.setStyles(e), this.chars[this.pos].setPenState(this.currPenState);
  }
}
class as {
  constructor(e) {
    this.rows = [], this.currRow = xe - 1, this.nrRollUpRows = null, this.lastOutputScreen = null, this.logger = void 0;
    for (let t = 0; t < xe; t++)
      this.rows.push(new nc(e));
    this.logger = e;
  }
  reset() {
    for (let e = 0; e < xe; e++)
      this.rows[e].clear();
    this.currRow = xe - 1;
  }
  equals(e) {
    let t = !0;
    for (let s = 0; s < xe; s++)
      if (!this.rows[s].equals(e.rows[s])) {
        t = !1;
        break;
      }
    return t;
  }
  copy(e) {
    for (let t = 0; t < xe; t++)
      this.rows[t].copy(e.rows[t]);
  }
  isEmpty() {
    let e = !0;
    for (let t = 0; t < xe; t++)
      if (!this.rows[t].isEmpty()) {
        e = !1;
        break;
      }
    return e;
  }
  backSpace() {
    this.rows[this.currRow].backSpace();
  }
  clearToEndOfRow() {
    this.rows[this.currRow].clearToEndOfRow();
  }
  /**
   * Insert a character (without styling) in the current row.
   */
  insertChar(e) {
    this.rows[this.currRow].insertChar(e);
  }
  setPen(e) {
    this.rows[this.currRow].setPenStyles(e);
  }
  moveCursor(e) {
    this.rows[this.currRow].moveCursor(e);
  }
  setCursor(e) {
    this.logger.log(2, "setCursor: " + e), this.rows[this.currRow].setCursor(e);
  }
  setPAC(e) {
    this.logger.log(2, () => "pacData = " + JSON.stringify(e));
    let t = e.row - 1;
    if (this.nrRollUpRows && t < this.nrRollUpRows - 1 && (t = this.nrRollUpRows - 1), this.nrRollUpRows && this.currRow !== t) {
      for (let o = 0; o < xe; o++)
        this.rows[o].clear();
      const r = this.currRow + 1 - this.nrRollUpRows, a = this.lastOutputScreen;
      if (a) {
        const o = a.rows[r].cueStartTime, l = this.logger.time;
        if (o !== null && l !== null && o < l)
          for (let c = 0; c < this.nrRollUpRows; c++)
            this.rows[t - this.nrRollUpRows + c + 1].copy(a.rows[r + c]);
      }
    }
    this.currRow = t;
    const s = this.rows[this.currRow];
    if (e.indent !== null) {
      const r = e.indent, a = Math.max(r - 1, 0);
      s.setCursor(e.indent), e.color = s.chars[a].penState.foreground;
    }
    const i = {
      foreground: e.color,
      underline: e.underline,
      italics: e.italics,
      background: "black",
      flash: !1
    };
    this.setPen(i);
  }
  /**
   * Set background/extra foreground, but first do back_space, and then insert space (backwards compatibility).
   */
  setBkgData(e) {
    this.logger.log(2, () => "bkgData = " + JSON.stringify(e)), this.backSpace(), this.setPen(e), this.insertChar(32);
  }
  setRollUpRows(e) {
    this.nrRollUpRows = e;
  }
  rollUp() {
    if (this.nrRollUpRows === null) {
      this.logger.log(3, "roll_up but nrRollUpRows not set yet");
      return;
    }
    this.logger.log(1, () => this.getDisplayText());
    const e = this.currRow + 1 - this.nrRollUpRows, t = this.rows.splice(e, 1)[0];
    t.clear(), this.rows.splice(this.currRow, 0, t), this.logger.log(2, "Rolling up");
  }
  /**
   * Get all non-empty rows with as unicode text.
   */
  getDisplayText(e) {
    e = e || !1;
    const t = [];
    let s = "", i = -1;
    for (let r = 0; r < xe; r++) {
      const a = this.rows[r].getTextString();
      a && (i = r + 1, e ? t.push("Row " + i + ": '" + a + "'") : t.push(a.trim()));
    }
    return t.length > 0 && (e ? s = "[" + t.join(" | ") + "]" : s = t.join(`
`)), s;
  }
  getTextAndFormat() {
    return this.rows;
  }
}
class Qi {
  constructor(e, t, s) {
    this.chNr = void 0, this.outputFilter = void 0, this.mode = void 0, this.verbose = void 0, this.displayedMemory = void 0, this.nonDisplayedMemory = void 0, this.lastOutputScreen = void 0, this.currRollUpRow = void 0, this.writeScreen = void 0, this.cueStartTime = void 0, this.logger = void 0, this.chNr = e, this.outputFilter = t, this.mode = null, this.verbose = 0, this.displayedMemory = new as(s), this.nonDisplayedMemory = new as(s), this.lastOutputScreen = new as(s), this.currRollUpRow = this.displayedMemory.rows[xe - 1], this.writeScreen = this.displayedMemory, this.mode = null, this.cueStartTime = null, this.logger = s;
  }
  reset() {
    this.mode = null, this.displayedMemory.reset(), this.nonDisplayedMemory.reset(), this.lastOutputScreen.reset(), this.outputFilter.reset(), this.currRollUpRow = this.displayedMemory.rows[xe - 1], this.writeScreen = this.displayedMemory, this.mode = null, this.cueStartTime = null;
  }
  getHandler() {
    return this.outputFilter;
  }
  setHandler(e) {
    this.outputFilter = e;
  }
  setPAC(e) {
    this.writeScreen.setPAC(e);
  }
  setBkgData(e) {
    this.writeScreen.setBkgData(e);
  }
  setMode(e) {
    e !== this.mode && (this.mode = e, this.logger.log(2, () => "MODE=" + e), this.mode === "MODE_POP-ON" ? this.writeScreen = this.nonDisplayedMemory : (this.writeScreen = this.displayedMemory, this.writeScreen.reset()), this.mode !== "MODE_ROLL-UP" && (this.displayedMemory.nrRollUpRows = null, this.nonDisplayedMemory.nrRollUpRows = null), this.mode = e);
  }
  insertChars(e) {
    for (let s = 0; s < e.length; s++)
      this.writeScreen.insertChar(e[s]);
    const t = this.writeScreen === this.displayedMemory ? "DISP" : "NON_DISP";
    this.logger.log(2, () => t + ": " + this.writeScreen.getDisplayText(!0)), (this.mode === "MODE_PAINT-ON" || this.mode === "MODE_ROLL-UP") && (this.logger.log(1, () => "DISPLAYED: " + this.displayedMemory.getDisplayText(!0)), this.outputDataUpdate());
  }
  ccRCL() {
    this.logger.log(2, "RCL - Resume Caption Loading"), this.setMode("MODE_POP-ON");
  }
  ccBS() {
    this.logger.log(2, "BS - BackSpace"), this.mode !== "MODE_TEXT" && (this.writeScreen.backSpace(), this.writeScreen === this.displayedMemory && this.outputDataUpdate());
  }
  ccAOF() {
  }
  ccAON() {
  }
  ccDER() {
    this.logger.log(2, "DER- Delete to End of Row"), this.writeScreen.clearToEndOfRow(), this.outputDataUpdate();
  }
  ccRU(e) {
    this.logger.log(2, "RU(" + e + ") - Roll Up"), this.writeScreen = this.displayedMemory, this.setMode("MODE_ROLL-UP"), this.writeScreen.setRollUpRows(e);
  }
  ccFON() {
    this.logger.log(2, "FON - Flash On"), this.writeScreen.setPen({
      flash: !0
    });
  }
  ccRDC() {
    this.logger.log(2, "RDC - Resume Direct Captioning"), this.setMode("MODE_PAINT-ON");
  }
  ccTR() {
    this.logger.log(2, "TR"), this.setMode("MODE_TEXT");
  }
  ccRTD() {
    this.logger.log(2, "RTD"), this.setMode("MODE_TEXT");
  }
  ccEDM() {
    this.logger.log(2, "EDM - Erase Displayed Memory"), this.displayedMemory.reset(), this.outputDataUpdate(!0);
  }
  ccCR() {
    this.logger.log(2, "CR - Carriage Return"), this.writeScreen.rollUp(), this.outputDataUpdate(!0);
  }
  ccENM() {
    this.logger.log(2, "ENM - Erase Non-displayed Memory"), this.nonDisplayedMemory.reset();
  }
  ccEOC() {
    if (this.logger.log(2, "EOC - End Of Caption"), this.mode === "MODE_POP-ON") {
      const e = this.displayedMemory;
      this.displayedMemory = this.nonDisplayedMemory, this.nonDisplayedMemory = e, this.writeScreen = this.nonDisplayedMemory, this.logger.log(1, () => "DISP: " + this.displayedMemory.getDisplayText());
    }
    this.outputDataUpdate(!0);
  }
  ccTO(e) {
    this.logger.log(2, "TO(" + e + ") - Tab Offset"), this.writeScreen.moveCursor(e);
  }
  ccMIDROW(e) {
    const t = {
      flash: !1
    };
    if (t.underline = e % 2 === 1, t.italics = e >= 46, t.italics)
      t.foreground = "white";
    else {
      const s = Math.floor(e / 2) - 16, i = ["white", "green", "blue", "cyan", "red", "yellow", "magenta"];
      t.foreground = i[s];
    }
    this.logger.log(2, "MIDROW: " + JSON.stringify(t)), this.writeScreen.setPen(t);
  }
  outputDataUpdate(e = !1) {
    const t = this.logger.time;
    t !== null && this.outputFilter && (this.cueStartTime === null && !this.displayedMemory.isEmpty() ? this.cueStartTime = t : this.displayedMemory.equals(this.lastOutputScreen) || (this.outputFilter.newCue(this.cueStartTime, t, this.lastOutputScreen), e && this.outputFilter.dispatchCue && this.outputFilter.dispatchCue(), this.cueStartTime = this.displayedMemory.isEmpty() ? null : t), this.lastOutputScreen.copy(this.displayedMemory));
  }
  cueSplitAtTime(e) {
    this.outputFilter && (this.displayedMemory.isEmpty() || (this.outputFilter.newCue && this.outputFilter.newCue(this.cueStartTime, e, this.displayedMemory), this.cueStartTime = e));
  }
}
class Ji {
  constructor(e, t, s) {
    this.channels = void 0, this.currentChannel = 0, this.cmdHistory = oc(), this.logger = void 0;
    const i = this.logger = new ic();
    this.channels = [null, new Qi(e, t, i), new Qi(e + 1, s, i)];
  }
  getHandler(e) {
    return this.channels[e].getHandler();
  }
  setHandler(e, t) {
    this.channels[e].setHandler(t);
  }
  /**
   * Add data for time t in forms of list of bytes (unsigned ints). The bytes are treated as pairs.
   */
  addData(e, t) {
    this.logger.time = e;
    for (let s = 0; s < t.length; s += 2) {
      const i = t[s] & 127, r = t[s + 1] & 127;
      let a = !1, o = null;
      if (i === 0 && r === 0)
        continue;
      this.logger.log(3, () => "[" + Ne([t[s], t[s + 1]]) + "] -> (" + Ne([i, r]) + ")");
      const l = this.cmdHistory;
      if (i >= 16 && i <= 31) {
        if (ac(i, r, l)) {
          Et(null, null, l), this.logger.log(3, () => "Repeated command (" + Ne([i, r]) + ") is dropped");
          continue;
        }
        Et(i, r, this.cmdHistory), a = this.parseCmd(i, r), a || (a = this.parseMidrow(i, r)), a || (a = this.parsePAC(i, r)), a || (a = this.parseBackgroundAttributes(i, r));
      } else
        Et(null, null, l);
      if (!a && (o = this.parseChars(i, r), o)) {
        const h = this.currentChannel;
        h && h > 0 ? this.channels[h].insertChars(o) : this.logger.log(2, "No channel found yet. TEXT-MODE?");
      }
      !a && !o && this.logger.log(2, () => "Couldn't parse cleaned data " + Ne([i, r]) + " orig: " + Ne([t[s], t[s + 1]]));
    }
  }
  /**
   * Parse Command.
   * @returns True if a command was found
   */
  parseCmd(e, t) {
    const s = (e === 20 || e === 28 || e === 21 || e === 29) && t >= 32 && t <= 47, i = (e === 23 || e === 31) && t >= 33 && t <= 35;
    if (!(s || i))
      return !1;
    const r = e === 20 || e === 21 || e === 23 ? 1 : 2, a = this.channels[r];
    return e === 20 || e === 21 || e === 28 || e === 29 ? t === 32 ? a.ccRCL() : t === 33 ? a.ccBS() : t === 34 ? a.ccAOF() : t === 35 ? a.ccAON() : t === 36 ? a.ccDER() : t === 37 ? a.ccRU(2) : t === 38 ? a.ccRU(3) : t === 39 ? a.ccRU(4) : t === 40 ? a.ccFON() : t === 41 ? a.ccRDC() : t === 42 ? a.ccTR() : t === 43 ? a.ccRTD() : t === 44 ? a.ccEDM() : t === 45 ? a.ccCR() : t === 46 ? a.ccENM() : t === 47 && a.ccEOC() : a.ccTO(t - 32), this.currentChannel = r, !0;
  }
  /**
   * Parse midrow styling command
   */
  parseMidrow(e, t) {
    let s = 0;
    if ((e === 17 || e === 25) && t >= 32 && t <= 47) {
      if (e === 17 ? s = 1 : s = 2, s !== this.currentChannel)
        return this.logger.log(0, "Mismatch channel in midrow parsing"), !1;
      const i = this.channels[s];
      return i ? (i.ccMIDROW(t), this.logger.log(3, () => "MIDROW (" + Ne([e, t]) + ")"), !0) : !1;
    }
    return !1;
  }
  /**
   * Parse Preable Access Codes (Table 53).
   * @returns {Boolean} Tells if PAC found
   */
  parsePAC(e, t) {
    let s;
    const i = (e >= 17 && e <= 23 || e >= 25 && e <= 31) && t >= 64 && t <= 127, r = (e === 16 || e === 24) && t >= 64 && t <= 95;
    if (!(i || r))
      return !1;
    const a = e <= 23 ? 1 : 2;
    t >= 64 && t <= 95 ? s = a === 1 ? Jl[e] : ec[e] : s = a === 1 ? Zl[e] : tc[e];
    const o = this.channels[a];
    return o ? (o.setPAC(this.interpretPAC(s, t)), this.currentChannel = a, !0) : !1;
  }
  /**
   * Interpret the second byte of the pac, and return the information.
   * @returns pacData with style parameters
   */
  interpretPAC(e, t) {
    let s;
    const i = {
      color: null,
      italics: !1,
      indent: null,
      underline: !1,
      row: e
    };
    return t > 95 ? s = t - 96 : s = t - 64, i.underline = (s & 1) === 1, s <= 13 ? i.color = ["white", "green", "blue", "cyan", "red", "yellow", "magenta", "white"][Math.floor(s / 2)] : s <= 15 ? (i.italics = !0, i.color = "white") : i.indent = Math.floor((s - 16) / 2) * 4, i;
  }
  /**
   * Parse characters.
   * @returns An array with 1 to 2 codes corresponding to chars, if found. null otherwise.
   */
  parseChars(e, t) {
    let s, i = null, r = null;
    if (e >= 25 ? (s = 2, r = e - 8) : (s = 1, r = e), r >= 17 && r <= 19) {
      let a;
      r === 17 ? a = t + 80 : r === 18 ? a = t + 112 : a = t + 144, this.logger.log(2, () => "Special char '" + dn(a) + "' in channel " + s), i = [a];
    } else e >= 32 && e <= 127 && (i = t === 0 ? [e] : [e, t]);
    return i && this.logger.log(3, () => "Char codes =  " + Ne(i).join(",")), i;
  }
  /**
   * Parse extended background attributes as well as new foreground color black.
   * @returns True if background attributes are found
   */
  parseBackgroundAttributes(e, t) {
    const s = (e === 16 || e === 24) && t >= 32 && t <= 47, i = (e === 23 || e === 31) && t >= 45 && t <= 47;
    if (!(s || i))
      return !1;
    let r;
    const a = {};
    e === 16 || e === 24 ? (r = Math.floor((t - 32) / 2), a.background = sc[r], t % 2 === 1 && (a.background = a.background + "_semi")) : t === 45 ? a.background = "transparent" : (a.foreground = "black", t === 47 && (a.underline = !0));
    const o = e <= 23 ? 1 : 2;
    return this.channels[o].setBkgData(a), !0;
  }
  /**
   * Reset state of parser and its channels.
   */
  reset() {
    for (let e = 0; e < Object.keys(this.channels).length; e++) {
      const t = this.channels[e];
      t && t.reset();
    }
    Et(null, null, this.cmdHistory);
  }
  /**
   * Trigger the generation of a cue, and the start of a new one if displayScreens are not empty.
   */
  cueSplitAtTime(e) {
    for (let t = 0; t < this.channels.length; t++) {
      const s = this.channels[t];
      s && s.cueSplitAtTime(e);
    }
  }
}
function Et(n, e, t) {
  t.a = n, t.b = e;
}
function ac(n, e, t) {
  return t.a === n && t.b === e;
}
function oc() {
  return {
    a: null,
    b: null
  };
}
class Tt {
  constructor(e, t) {
    this.timelineController = void 0, this.cueRanges = [], this.trackName = void 0, this.startTime = null, this.endTime = null, this.screen = null, this.timelineController = e, this.trackName = t;
  }
  dispatchCue() {
    this.startTime !== null && (this.timelineController.addCues(this.trackName, this.startTime, this.endTime, this.screen, this.cueRanges), this.startTime = null);
  }
  newCue(e, t, s) {
    (this.startTime === null || this.startTime > e) && (this.startTime = e), this.endTime = t, this.screen = s, this.timelineController.createCaptionsTrack(this.trackName);
  }
  reset() {
    this.cueRanges = [], this.startTime = null;
  }
}
var Qs = function() {
  if (Je != null && Je.VTTCue)
    return self.VTTCue;
  const n = ["", "lr", "rl"], e = ["start", "middle", "end", "left", "right"];
  function t(o, l) {
    if (typeof l != "string" || !Array.isArray(o))
      return !1;
    const c = l.toLowerCase();
    return ~o.indexOf(c) ? c : !1;
  }
  function s(o) {
    return t(n, o);
  }
  function i(o) {
    return t(e, o);
  }
  function r(o, ...l) {
    let c = 1;
    for (; c < arguments.length; c++) {
      const h = arguments[c];
      for (const u in h)
        o[u] = h[u];
    }
    return o;
  }
  function a(o, l, c) {
    const h = this, u = {
      enumerable: !0
    };
    h.hasBeenReset = !1;
    let d = "", f = !1, g = o, m = l, E = c, T = null, y = "", x = !0, b = "auto", S = "start", D = 50, R = "middle", _ = 50, P = "middle";
    Object.defineProperty(h, "id", r({}, u, {
      get: function() {
        return d;
      },
      set: function(I) {
        d = "" + I;
      }
    })), Object.defineProperty(h, "pauseOnExit", r({}, u, {
      get: function() {
        return f;
      },
      set: function(I) {
        f = !!I;
      }
    })), Object.defineProperty(h, "startTime", r({}, u, {
      get: function() {
        return g;
      },
      set: function(I) {
        if (typeof I != "number")
          throw new TypeError("Start time must be set to a number.");
        g = I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "endTime", r({}, u, {
      get: function() {
        return m;
      },
      set: function(I) {
        if (typeof I != "number")
          throw new TypeError("End time must be set to a number.");
        m = I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "text", r({}, u, {
      get: function() {
        return E;
      },
      set: function(I) {
        E = "" + I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "region", r({}, u, {
      get: function() {
        return T;
      },
      set: function(I) {
        T = I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "vertical", r({}, u, {
      get: function() {
        return y;
      },
      set: function(I) {
        const k = s(I);
        if (k === !1)
          throw new SyntaxError("An invalid or illegal string was specified.");
        y = k, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "snapToLines", r({}, u, {
      get: function() {
        return x;
      },
      set: function(I) {
        x = !!I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "line", r({}, u, {
      get: function() {
        return b;
      },
      set: function(I) {
        if (typeof I != "number" && I !== "auto")
          throw new SyntaxError("An invalid number or illegal string was specified.");
        b = I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "lineAlign", r({}, u, {
      get: function() {
        return S;
      },
      set: function(I) {
        const k = i(I);
        if (!k)
          throw new SyntaxError("An invalid or illegal string was specified.");
        S = k, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "position", r({}, u, {
      get: function() {
        return D;
      },
      set: function(I) {
        if (I < 0 || I > 100)
          throw new Error("Position must be between 0 and 100.");
        D = I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "positionAlign", r({}, u, {
      get: function() {
        return R;
      },
      set: function(I) {
        const k = i(I);
        if (!k)
          throw new SyntaxError("An invalid or illegal string was specified.");
        R = k, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "size", r({}, u, {
      get: function() {
        return _;
      },
      set: function(I) {
        if (I < 0 || I > 100)
          throw new Error("Size must be between 0 and 100.");
        _ = I, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "align", r({}, u, {
      get: function() {
        return P;
      },
      set: function(I) {
        const k = i(I);
        if (!k)
          throw new SyntaxError("An invalid or illegal string was specified.");
        P = k, this.hasBeenReset = !0;
      }
    })), h.displayState = void 0;
  }
  return a.prototype.getCueAsHTML = function() {
    return self.WebVTT.convertCueToDOMTree(self, this.text);
  }, a;
}();
class lc {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  decode(e, t) {
    if (!e)
      return "";
    if (typeof e != "string")
      throw new Error("Error - expected string data.");
    return decodeURIComponent(encodeURIComponent(e));
  }
}
function gn(n) {
  function e(s, i, r, a) {
    return (s | 0) * 3600 + (i | 0) * 60 + (r | 0) + parseFloat(a || 0);
  }
  const t = n.match(/^(?:(\d+):)?(\d{2}):(\d{2})(\.\d+)?/);
  return t ? parseFloat(t[2]) > 59 ? e(t[2], t[3], 0, t[4]) : e(t[1], t[2], t[3], t[4]) : null;
}
class cc {
  constructor() {
    this.values = /* @__PURE__ */ Object.create(null);
  }
  // Only accept the first assignment to any key.
  set(e, t) {
    !this.get(e) && t !== "" && (this.values[e] = t);
  }
  // Return the value for a key, or a default value.
  // If 'defaultKey' is passed then 'dflt' is assumed to be an object with
  // a number of possible default values as properties where 'defaultKey' is
  // the key of the property that will be chosen; otherwise it's assumed to be
  // a single value.
  get(e, t, s) {
    return s ? this.has(e) ? this.values[e] : t[s] : this.has(e) ? this.values[e] : t;
  }
  // Check whether we have a value for a key.
  has(e) {
    return e in this.values;
  }
  // Accept a setting if its one of the given alternatives.
  alt(e, t, s) {
    for (let i = 0; i < s.length; ++i)
      if (t === s[i]) {
        this.set(e, t);
        break;
      }
  }
  // Accept a setting if its a valid (signed) integer.
  integer(e, t) {
    /^-?\d+$/.test(t) && this.set(e, parseInt(t, 10));
  }
  // Accept a setting if its a valid percentage.
  percent(e, t) {
    if (/^([\d]{1,3})(\.[\d]*)?%$/.test(t)) {
      const s = parseFloat(t);
      if (s >= 0 && s <= 100)
        return this.set(e, s), !0;
    }
    return !1;
  }
}
function mn(n, e, t, s) {
  const i = s ? n.split(s) : [n];
  for (const r in i) {
    if (typeof i[r] != "string")
      continue;
    const a = i[r].split(t);
    if (a.length !== 2)
      continue;
    const o = a[0], l = a[1];
    e(o, l);
  }
}
const Ds = new Qs(0, 0, ""), yt = Ds.align === "middle" ? "middle" : "center";
function hc(n, e, t) {
  const s = n;
  function i() {
    const o = gn(n);
    if (o === null)
      throw new Error("Malformed timestamp: " + s);
    return n = n.replace(/^[^\sa-zA-Z-]+/, ""), o;
  }
  function r(o, l) {
    const c = new cc();
    mn(o, function(d, f) {
      let g;
      switch (d) {
        case "region":
          for (let m = t.length - 1; m >= 0; m--)
            if (t[m].id === f) {
              c.set(d, t[m].region);
              break;
            }
          break;
        case "vertical":
          c.alt(d, f, ["rl", "lr"]);
          break;
        case "line":
          g = f.split(","), c.integer(d, g[0]), c.percent(d, g[0]) && c.set("snapToLines", !1), c.alt(d, g[0], ["auto"]), g.length === 2 && c.alt("lineAlign", g[1], ["start", yt, "end"]);
          break;
        case "position":
          g = f.split(","), c.percent(d, g[0]), g.length === 2 && c.alt("positionAlign", g[1], ["start", yt, "end", "line-left", "line-right", "auto"]);
          break;
        case "size":
          c.percent(d, f);
          break;
        case "align":
          c.alt(d, f, ["start", yt, "end", "left", "right"]);
          break;
      }
    }, /:/, /\s/), l.region = c.get("region", null), l.vertical = c.get("vertical", "");
    let h = c.get("line", "auto");
    h === "auto" && Ds.line === -1 && (h = -1), l.line = h, l.lineAlign = c.get("lineAlign", "start"), l.snapToLines = c.get("snapToLines", !0), l.size = c.get("size", 100), l.align = c.get("align", yt);
    let u = c.get("position", "auto");
    u === "auto" && Ds.position === 50 && (u = l.align === "start" || l.align === "left" ? 0 : l.align === "end" || l.align === "right" ? 100 : 50), l.position = u;
  }
  function a() {
    n = n.replace(/^\s+/, "");
  }
  if (a(), e.startTime = i(), a(), n.slice(0, 3) !== "-->")
    throw new Error("Malformed time stamp (time stamps must be separated by '-->'): " + s);
  n = n.slice(3), a(), e.endTime = i(), a(), r(n, e);
}
function pn(n) {
  return n.replace(/<br(?: \/)?>/gi, `
`);
}
class uc {
  constructor() {
    this.state = "INITIAL", this.buffer = "", this.decoder = new lc(), this.regionList = [], this.cue = null, this.oncue = void 0, this.onparsingerror = void 0, this.onflush = void 0;
  }
  parse(e) {
    const t = this;
    e && (t.buffer += t.decoder.decode(e, {
      stream: !0
    }));
    function s() {
      let r = t.buffer, a = 0;
      for (r = pn(r); a < r.length && r[a] !== "\r" && r[a] !== `
`; )
        ++a;
      const o = r.slice(0, a);
      return r[a] === "\r" && ++a, r[a] === `
` && ++a, t.buffer = r.slice(a), o;
    }
    function i(r) {
      mn(r, function(a, o) {
      }, /:/);
    }
    try {
      let r = "";
      if (t.state === "INITIAL") {
        if (!/\r\n|\n/.test(t.buffer))
          return this;
        r = s();
        const o = r.match(/^(ï»¿)?WEBVTT([ \t].*)?$/);
        if (!(o != null && o[0]))
          throw new Error("Malformed WebVTT signature.");
        t.state = "HEADER";
      }
      let a = !1;
      for (; t.buffer; ) {
        if (!/\r\n|\n/.test(t.buffer))
          return this;
        switch (a ? a = !1 : r = s(), t.state) {
          case "HEADER":
            /:/.test(r) ? i(r) : r || (t.state = "ID");
            continue;
          case "NOTE":
            r || (t.state = "ID");
            continue;
          case "ID":
            if (/^NOTE($|[ \t])/.test(r)) {
              t.state = "NOTE";
              break;
            }
            if (!r)
              continue;
            if (t.cue = new Qs(0, 0, ""), t.state = "CUE", r.indexOf("-->") === -1) {
              t.cue.id = r;
              continue;
            }
          case "CUE":
            if (!t.cue) {
              t.state = "BADCUE";
              continue;
            }
            try {
              hc(r, t.cue, t.regionList);
            } catch {
              t.cue = null, t.state = "BADCUE";
              continue;
            }
            t.state = "CUETEXT";
            continue;
          case "CUETEXT":
            {
              const o = r.indexOf("-->") !== -1;
              if (!r || o && (a = !0)) {
                t.oncue && t.cue && t.oncue(t.cue), t.cue = null, t.state = "ID";
                continue;
              }
              if (t.cue === null)
                continue;
              t.cue.text && (t.cue.text += `
`), t.cue.text += r;
            }
            continue;
          case "BADCUE":
            r || (t.state = "ID");
        }
      }
    } catch {
      t.state === "CUETEXT" && t.cue && t.oncue && t.oncue(t.cue), t.cue = null, t.state = t.state === "INITIAL" ? "BADWEBVTT" : "BADCUE";
    }
    return this;
  }
  flush() {
    const e = this;
    try {
      if ((e.cue || e.state === "HEADER") && (e.buffer += `

`, e.parse()), e.state === "INITIAL" || e.state === "BADWEBVTT")
        throw new Error("Malformed WebVTT signature.");
    } catch (t) {
      e.onparsingerror && e.onparsingerror(t);
    }
    return e.onflush && e.onflush(), this;
  }
}
const dc = /\r\n|\n\r|\n|\r/g, os = function(e, t, s = 0) {
  return e.slice(s, s + t.length) === t;
}, fc = function(e) {
  let t = parseInt(e.slice(-3));
  const s = parseInt(e.slice(-6, -4)), i = parseInt(e.slice(-9, -7)), r = e.length > 9 ? parseInt(e.substring(0, e.indexOf(":"))) : 0;
  if (!M(t) || !M(s) || !M(i) || !M(r))
    throw Error(`Malformed X-TIMESTAMP-MAP: Local:${e}`);
  return t += 1e3 * s, t += 60 * 1e3 * i, t += 60 * 60 * 1e3 * r, t;
}, ls = function(e) {
  let t = 5381, s = e.length;
  for (; s; )
    t = t * 33 ^ e.charCodeAt(--s);
  return (t >>> 0).toString();
};
function Js(n, e, t) {
  return ls(n.toString()) + ls(e.toString()) + ls(t);
}
const gc = function(e, t, s) {
  let i = e[t], r = e[i.prevCC];
  if (!r || !r.new && i.new) {
    e.ccOffset = e.presentationOffset = i.start, i.new = !1;
    return;
  }
  for (; (a = r) != null && a.new; ) {
    var a;
    e.ccOffset += i.start - r.start, i.new = !1, i = r, r = e[i.prevCC];
  }
  e.presentationOffset = s;
};
function mc(n, e, t, s, i, r, a) {
  const o = new uc(), l = Ie(new Uint8Array(n)).trim().replace(dc, `
`).split(`
`), c = [], h = e ? wl(e.baseTime, e.timescale) : 0;
  let u = "00:00.000", d = 0, f = 0, g, m = !0;
  o.oncue = function(E) {
    const T = t[s];
    let y = t.ccOffset;
    const x = (d - h) / 9e4;
    if (T != null && T.new && (f !== void 0 ? y = t.ccOffset = T.start : gc(t, s, x)), x) {
      if (!e) {
        g = new Error("Missing initPTS for VTT MPEGTS");
        return;
      }
      y = x - t.presentationOffset;
    }
    const b = E.endTime - E.startTime, S = pe((E.startTime + y - f) * 9e4, i * 9e4) / 9e4;
    E.startTime = Math.max(S, 0), E.endTime = Math.max(S + b, 0);
    const D = E.text.trim();
    E.text = decodeURIComponent(encodeURIComponent(D)), E.id || (E.id = Js(E.startTime, E.endTime, D)), E.endTime > 0 && c.push(E);
  }, o.onparsingerror = function(E) {
    g = E;
  }, o.onflush = function() {
    if (g) {
      a(g);
      return;
    }
    r(c);
  }, l.forEach((E) => {
    if (m)
      if (os(E, "X-TIMESTAMP-MAP=")) {
        m = !1, E.slice(16).split(",").forEach((T) => {
          os(T, "LOCAL:") ? u = T.slice(6) : os(T, "MPEGTS:") && (d = parseInt(T.slice(7)));
        });
        try {
          f = fc(u) / 1e3;
        } catch (T) {
          g = T;
        }
        return;
      } else E === "" && (m = !1);
    o.parse(E + `
`);
  }), o.flush();
}
const cs = "stpp.ttml.im1t", En = /^(\d{2,}):(\d{2}):(\d{2}):(\d{2})\.?(\d+)?$/, Tn = /^(\d*(?:\.\d*)?)(h|m|s|ms|f|t)$/, pc = {
  left: "start",
  center: "center",
  right: "end",
  start: "start",
  end: "end"
};
function Zi(n, e, t, s) {
  const i = H(new Uint8Array(n), ["mdat"]);
  if (i.length === 0) {
    s(new Error("Could not parse IMSC1 mdat"));
    return;
  }
  const r = i.map((o) => Ie(o)), a = kl(e.baseTime, 1, e.timescale);
  try {
    r.forEach((o) => t(Ec(o, a)));
  } catch (o) {
    s(o);
  }
}
function Ec(n, e) {
  const i = new DOMParser().parseFromString(n, "text/xml").getElementsByTagName("tt")[0];
  if (!i)
    throw new Error("Invalid ttml");
  const r = {
    frameRate: 30,
    subFrameRate: 1,
    frameRateMultiplier: 0,
    tickRate: 0
  }, a = Object.keys(r).reduce((u, d) => (u[d] = i.getAttribute(`ttp:${d}`) || r[d], u), {}), o = i.getAttribute("xml:space") !== "preserve", l = er(hs(i, "styling", "style")), c = er(hs(i, "layout", "region")), h = hs(i, "body", "[begin]");
  return [].map.call(h, (u) => {
    const d = yn(u, o);
    if (!d || !u.hasAttribute("begin"))
      return null;
    const f = ds(u.getAttribute("begin"), a), g = ds(u.getAttribute("dur"), a);
    let m = ds(u.getAttribute("end"), a);
    if (f === null)
      throw tr(u);
    if (m === null) {
      if (g === null)
        throw tr(u);
      m = f + g;
    }
    const E = new Qs(f - e, m - e, d);
    E.id = Js(E.startTime, E.endTime, E.text);
    const T = c[u.getAttribute("region")], y = l[u.getAttribute("style")], x = Tc(T, y, l), {
      textAlign: b
    } = x;
    if (b) {
      const S = pc[b];
      S && (E.lineAlign = S), E.align = b;
    }
    return se(E, x), E;
  }).filter((u) => u !== null);
}
function hs(n, e, t) {
  const s = n.getElementsByTagName(e)[0];
  return s ? [].slice.call(s.querySelectorAll(t)) : [];
}
function er(n) {
  return n.reduce((e, t) => {
    const s = t.getAttribute("xml:id");
    return s && (e[s] = t), e;
  }, {});
}
function yn(n, e) {
  return [].slice.call(n.childNodes).reduce((t, s, i) => {
    var r;
    return s.nodeName === "br" && i ? t + `
` : (r = s.childNodes) != null && r.length ? yn(s, e) : e ? t + s.textContent.trim().replace(/\s+/g, " ") : t + s.textContent;
  }, "");
}
function Tc(n, e, t) {
  const s = "http://www.w3.org/ns/ttml#styling";
  let i = null;
  const r = [
    "displayAlign",
    "textAlign",
    "color",
    "backgroundColor",
    "fontSize",
    "fontFamily"
    // 'fontWeight',
    // 'lineHeight',
    // 'wrapOption',
    // 'fontStyle',
    // 'direction',
    // 'writingMode'
  ], a = n != null && n.hasAttribute("style") ? n.getAttribute("style") : null;
  return a && t.hasOwnProperty(a) && (i = t[a]), r.reduce((o, l) => {
    const c = us(e, s, l) || us(n, s, l) || us(i, s, l);
    return c && (o[l] = c), o;
  }, {});
}
function us(n, e, t) {
  return n && n.hasAttributeNS(e, t) ? n.getAttributeNS(e, t) : null;
}
function tr(n) {
  return new Error(`Could not parse ttml timestamp ${n}`);
}
function ds(n, e) {
  if (!n)
    return null;
  let t = gn(n);
  return t === null && (En.test(n) ? t = yc(n, e) : Tn.test(n) && (t = xc(n, e))), t;
}
function yc(n, e) {
  const t = En.exec(n), s = (t[4] | 0) + (t[5] | 0) / e.subFrameRate;
  return (t[1] | 0) * 3600 + (t[2] | 0) * 60 + (t[3] | 0) + s / e.frameRate;
}
function xc(n, e) {
  const t = Tn.exec(n), s = Number(t[1]);
  switch (t[2]) {
    case "h":
      return s * 3600;
    case "m":
      return s * 60;
    case "ms":
      return s * 1e3;
    case "f":
      return s / e.frameRate;
    case "t":
      return s / e.tickRate;
  }
  return s;
}
class Sc {
  constructor(e) {
    this.hls = void 0, this.media = null, this.config = void 0, this.enabled = !0, this.Cues = void 0, this.textTracks = [], this.tracks = [], this.initPTS = [], this.unparsedVttFrags = [], this.captionsTracks = {}, this.nonNativeCaptionsTracks = {}, this.cea608Parser1 = void 0, this.cea608Parser2 = void 0, this.lastCc = -1, this.lastSn = -1, this.lastPartIndex = -1, this.prevCC = -1, this.vttCCs = ir(), this.captionsProperties = void 0, this.hls = e, this.config = e.config, this.Cues = e.config.cueHandler, this.captionsProperties = {
      textTrack1: {
        label: this.config.captionsTextTrack1Label,
        languageCode: this.config.captionsTextTrack1LanguageCode
      },
      textTrack2: {
        label: this.config.captionsTextTrack2Label,
        languageCode: this.config.captionsTextTrack2LanguageCode
      },
      textTrack3: {
        label: this.config.captionsTextTrack3Label,
        languageCode: this.config.captionsTextTrack3LanguageCode
      },
      textTrack4: {
        label: this.config.captionsTextTrack4Label,
        languageCode: this.config.captionsTextTrack4LanguageCode
      }
    }, e.on(p.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.MANIFEST_LOADED, this.onManifestLoaded, this), e.on(p.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.on(p.FRAG_LOADING, this.onFragLoading, this), e.on(p.FRAG_LOADED, this.onFragLoaded, this), e.on(p.FRAG_PARSING_USERDATA, this.onFragParsingUserdata, this), e.on(p.FRAG_DECRYPTED, this.onFragDecrypted, this), e.on(p.INIT_PTS_FOUND, this.onInitPtsFound, this), e.on(p.SUBTITLE_TRACKS_CLEARED, this.onSubtitleTracksCleared, this), e.on(p.BUFFER_FLUSHING, this.onBufferFlushing, this);
  }
  destroy() {
    const {
      hls: e
    } = this;
    e.off(p.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.MANIFEST_LOADED, this.onManifestLoaded, this), e.off(p.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.off(p.FRAG_LOADING, this.onFragLoading, this), e.off(p.FRAG_LOADED, this.onFragLoaded, this), e.off(p.FRAG_PARSING_USERDATA, this.onFragParsingUserdata, this), e.off(p.FRAG_DECRYPTED, this.onFragDecrypted, this), e.off(p.INIT_PTS_FOUND, this.onInitPtsFound, this), e.off(p.SUBTITLE_TRACKS_CLEARED, this.onSubtitleTracksCleared, this), e.off(p.BUFFER_FLUSHING, this.onBufferFlushing, this), this.hls = this.config = null, this.cea608Parser1 = this.cea608Parser2 = void 0;
  }
  initCea608Parsers() {
    if (this.config.enableCEA708Captions && (!this.cea608Parser1 || !this.cea608Parser2)) {
      const e = new Tt(this, "textTrack1"), t = new Tt(this, "textTrack2"), s = new Tt(this, "textTrack3"), i = new Tt(this, "textTrack4");
      this.cea608Parser1 = new Ji(1, e, t), this.cea608Parser2 = new Ji(3, s, i);
    }
  }
  addCues(e, t, s, i, r) {
    let a = !1;
    for (let o = r.length; o--; ) {
      const l = r[o], c = vc(l[0], l[1], t, s);
      if (c >= 0 && (l[0] = Math.min(l[0], t), l[1] = Math.max(l[1], s), a = !0, c / (s - t) > 0.5))
        return;
    }
    if (a || r.push([t, s]), this.config.renderTextTracksNatively) {
      const o = this.captionsTracks[e];
      this.Cues.newCue(o, t, s, i);
    } else {
      const o = this.Cues.newCue(null, t, s, i);
      this.hls.trigger(p.CUES_PARSED, {
        type: "captions",
        cues: o,
        track: e
      });
    }
  }
  // Triggered when an initial PTS is found; used for synchronisation of WebVTT.
  onInitPtsFound(e, {
    frag: t,
    id: s,
    initPTS: i,
    timescale: r
  }) {
    const {
      unparsedVttFrags: a
    } = this;
    s === "main" && (this.initPTS[t.cc] = {
      baseTime: i,
      timescale: r
    }), a.length && (this.unparsedVttFrags = [], a.forEach((o) => {
      this.onFragLoaded(p.FRAG_LOADED, o);
    }));
  }
  getExistingTrack(e, t) {
    const {
      media: s
    } = this;
    if (s)
      for (let i = 0; i < s.textTracks.length; i++) {
        const r = s.textTracks[i];
        if (sr(r, {
          name: e,
          lang: t,
          attrs: {}
        }))
          return r;
      }
    return null;
  }
  createCaptionsTrack(e) {
    this.config.renderTextTracksNatively ? this.createNativeTrack(e) : this.createNonNativeTrack(e);
  }
  createNativeTrack(e) {
    if (this.captionsTracks[e])
      return;
    const {
      captionsProperties: t,
      captionsTracks: s,
      media: i
    } = this, {
      label: r,
      languageCode: a
    } = t[e], o = this.getExistingTrack(r, a);
    if (o)
      s[e] = o, ze(s[e]), Ur(s[e], i);
    else {
      const l = this.createTextTrack("captions", r, a);
      l && (l[e] = !0, s[e] = l);
    }
  }
  createNonNativeTrack(e) {
    if (this.nonNativeCaptionsTracks[e])
      return;
    const t = this.captionsProperties[e];
    if (!t)
      return;
    const s = t.label, i = {
      _id: e,
      label: s,
      kind: "captions",
      default: t.media ? !!t.media.default : !1,
      closedCaptions: t.media
    };
    this.nonNativeCaptionsTracks[e] = i, this.hls.trigger(p.NON_NATIVE_TEXT_TRACKS_FOUND, {
      tracks: [i]
    });
  }
  createTextTrack(e, t, s) {
    const i = this.media;
    if (i)
      return i.addTextTrack(e, t, s);
  }
  onMediaAttaching(e, t) {
    this.media = t.media, this._cleanTracks();
  }
  onMediaDetaching() {
    const {
      captionsTracks: e
    } = this;
    Object.keys(e).forEach((t) => {
      ze(e[t]), delete e[t];
    }), this.nonNativeCaptionsTracks = {};
  }
  onManifestLoading() {
    this.lastCc = -1, this.lastSn = -1, this.lastPartIndex = -1, this.prevCC = -1, this.vttCCs = ir(), this._cleanTracks(), this.tracks = [], this.captionsTracks = {}, this.nonNativeCaptionsTracks = {}, this.textTracks = [], this.unparsedVttFrags = [], this.initPTS = [], this.cea608Parser1 && this.cea608Parser2 && (this.cea608Parser1.reset(), this.cea608Parser2.reset());
  }
  _cleanTracks() {
    const {
      media: e
    } = this;
    if (!e)
      return;
    const t = e.textTracks;
    if (t)
      for (let s = 0; s < t.length; s++)
        ze(t[s]);
  }
  onSubtitleTracksUpdated(e, t) {
    const s = t.subtitleTracks || [], i = s.some((r) => r.textCodec === cs);
    if (this.config.enableWebVTT || i && this.config.enableIMSC1) {
      if (un(this.tracks, s)) {
        this.tracks = s;
        return;
      }
      if (this.textTracks = [], this.tracks = s, this.config.renderTextTracksNatively) {
        const a = this.media, o = a ? At(a.textTracks) : null;
        if (this.tracks.forEach((l, c) => {
          let h;
          if (o) {
            let u = null;
            for (let d = 0; d < o.length; d++)
              if (o[d] && sr(o[d], l)) {
                u = o[d], o[d] = null;
                break;
              }
            u && (h = u);
          }
          if (h)
            ze(h);
          else {
            const u = xn(l);
            h = this.createTextTrack(u, l.name, l.lang), h && (h.mode = "disabled");
          }
          h && this.textTracks.push(h);
        }), o != null && o.length) {
          const l = o.filter((c) => c !== null).map((c) => c.label);
          l.length && v.warn(`Media element contains unused subtitle tracks: ${l.join(", ")}. Replace media element for each source to clear TextTracks and captions menu.`);
        }
      } else if (this.tracks.length) {
        const a = this.tracks.map((o) => ({
          label: o.name,
          kind: o.type.toLowerCase(),
          default: o.default,
          subtitleTrack: o
        }));
        this.hls.trigger(p.NON_NATIVE_TEXT_TRACKS_FOUND, {
          tracks: a
        });
      }
    }
  }
  onManifestLoaded(e, t) {
    this.config.enableCEA708Captions && t.captions && t.captions.forEach((s) => {
      const i = /(?:CC|SERVICE)([1-4])/.exec(s.instreamId);
      if (!i)
        return;
      const r = `textTrack${i[1]}`, a = this.captionsProperties[r];
      a && (a.label = s.name, s.lang && (a.languageCode = s.lang), a.media = s);
    });
  }
  closedCaptionsForLevel(e) {
    const t = this.hls.levels[e.level];
    return t == null ? void 0 : t.attrs["CLOSED-CAPTIONS"];
  }
  onFragLoading(e, t) {
    if (this.enabled && t.frag.type === G.MAIN) {
      var s, i;
      const {
        cea608Parser1: r,
        cea608Parser2: a,
        lastSn: o
      } = this, {
        cc: l,
        sn: c
      } = t.frag, h = (s = (i = t.part) == null ? void 0 : i.index) != null ? s : -1;
      r && a && (c !== o + 1 || c === o && h !== this.lastPartIndex + 1 || l !== this.lastCc) && (r.reset(), a.reset()), this.lastCc = l, this.lastSn = c, this.lastPartIndex = h;
    }
  }
  onFragLoaded(e, t) {
    const {
      frag: s,
      payload: i
    } = t;
    if (s.type === G.SUBTITLE)
      if (i.byteLength) {
        const r = s.decryptdata, a = "stats" in t;
        if (r == null || !r.encrypted || a) {
          const o = this.tracks[s.level], l = this.vttCCs;
          l[s.cc] || (l[s.cc] = {
            start: s.start,
            prevCC: this.prevCC,
            new: !0
          }, this.prevCC = s.cc), o && o.textCodec === cs ? this._parseIMSC1(s, i) : this._parseVTTs(t);
        }
      } else
        this.hls.trigger(p.SUBTITLE_FRAG_PROCESSED, {
          success: !1,
          frag: s,
          error: new Error("Empty subtitle payload")
        });
  }
  _parseIMSC1(e, t) {
    const s = this.hls;
    Zi(t, this.initPTS[e.cc], (i) => {
      this._appendCues(i, e.level), s.trigger(p.SUBTITLE_FRAG_PROCESSED, {
        success: !0,
        frag: e
      });
    }, (i) => {
      v.log(`Failed to parse IMSC1: ${i}`), s.trigger(p.SUBTITLE_FRAG_PROCESSED, {
        success: !1,
        frag: e,
        error: i
      });
    });
  }
  _parseVTTs(e) {
    var t;
    const {
      frag: s,
      payload: i
    } = e, {
      initPTS: r,
      unparsedVttFrags: a
    } = this, o = r.length - 1;
    if (!r[s.cc] && o === -1) {
      a.push(e);
      return;
    }
    const l = this.hls, c = (t = s.initSegment) != null && t.data ? Te(s.initSegment.data, new Uint8Array(i)) : i;
    mc(c, this.initPTS[s.cc], this.vttCCs, s.cc, s.start, (h) => {
      this._appendCues(h, s.level), l.trigger(p.SUBTITLE_FRAG_PROCESSED, {
        success: !0,
        frag: s
      });
    }, (h) => {
      const u = h.message === "Missing initPTS for VTT MPEGTS";
      u ? a.push(e) : this._fallbackToIMSC1(s, i), v.log(`Failed to parse VTT cue: ${h}`), !(u && o > s.cc) && l.trigger(p.SUBTITLE_FRAG_PROCESSED, {
        success: !1,
        frag: s,
        error: h
      });
    });
  }
  _fallbackToIMSC1(e, t) {
    const s = this.tracks[e.level];
    s.textCodec || Zi(t, this.initPTS[e.cc], () => {
      s.textCodec = cs, this._parseIMSC1(e, t);
    }, () => {
      s.textCodec = "wvtt";
    });
  }
  _appendCues(e, t) {
    const s = this.hls;
    if (this.config.renderTextTracksNatively) {
      const i = this.textTracks[t];
      if (!i || i.mode === "disabled")
        return;
      e.forEach((r) => Br(i, r));
    } else {
      const i = this.tracks[t];
      if (!i)
        return;
      const r = i.default ? "default" : "subtitles" + t;
      s.trigger(p.CUES_PARSED, {
        type: "subtitles",
        cues: e,
        track: r
      });
    }
  }
  onFragDecrypted(e, t) {
    const {
      frag: s
    } = t;
    s.type === G.SUBTITLE && this.onFragLoaded(p.FRAG_LOADED, t);
  }
  onSubtitleTracksCleared() {
    this.tracks = [], this.captionsTracks = {};
  }
  onFragParsingUserdata(e, t) {
    this.initCea608Parsers();
    const {
      cea608Parser1: s,
      cea608Parser2: i
    } = this;
    if (!this.enabled || !s || !i)
      return;
    const {
      frag: r,
      samples: a
    } = t;
    if (!(r.type === G.MAIN && this.closedCaptionsForLevel(r) === "NONE"))
      for (let o = 0; o < a.length; o++) {
        const l = a[o].bytes;
        if (l) {
          const c = this.extractCea608Data(l);
          s.addData(a[o].pts, c[0]), i.addData(a[o].pts, c[1]);
        }
      }
  }
  onBufferFlushing(e, {
    startOffset: t,
    endOffset: s,
    endOffsetSubtitles: i,
    type: r
  }) {
    const {
      media: a
    } = this;
    if (!(!a || a.currentTime < s)) {
      if (!r || r === "video") {
        const {
          captionsTracks: o
        } = this;
        Object.keys(o).forEach((l) => Ss(o[l], t, s));
      }
      if (this.config.renderTextTracksNatively && t === 0 && i !== void 0) {
        const {
          textTracks: o
        } = this;
        Object.keys(o).forEach((l) => Ss(o[l], t, i));
      }
    }
  }
  extractCea608Data(e) {
    const t = [[], []], s = e[0] & 31;
    let i = 2;
    for (let r = 0; r < s; r++) {
      const a = e[i++], o = 127 & e[i++], l = 127 & e[i++];
      if (o === 0 && l === 0)
        continue;
      if ((4 & a) !== 0) {
        const h = 3 & a;
        (h === 0 || h === 1) && (t[h].push(o), t[h].push(l));
      }
    }
    return t;
  }
}
function xn(n) {
  return n.characteristics && /transcribes-spoken-dialog/gi.test(n.characteristics) && /describes-music-and-sound/gi.test(n.characteristics) ? "captions" : "subtitles";
}
function sr(n, e) {
  return !!n && n.kind === xn(e) && Is(e, n);
}
function vc(n, e, t, s) {
  return Math.min(e, s) - Math.max(n, t);
}
function ir() {
  return {
    ccOffset: 0,
    presentationOffset: 0,
    0: {
      start: 0,
      prevCC: -1,
      new: !0
    }
  };
}
class Zs {
  constructor(e) {
    this.hls = void 0, this.autoLevelCapping = void 0, this.firstLevel = void 0, this.media = void 0, this.restrictedLevels = void 0, this.timer = void 0, this.clientRect = void 0, this.streamController = void 0, this.hls = e, this.autoLevelCapping = Number.POSITIVE_INFINITY, this.firstLevel = -1, this.media = null, this.restrictedLevels = [], this.timer = void 0, this.clientRect = null, this.registerListeners();
  }
  setStreamController(e) {
    this.streamController = e;
  }
  destroy() {
    this.hls && this.unregisterListener(), this.timer && this.stopCapping(), this.media = null, this.clientRect = null, this.hls = this.streamController = null;
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.FPS_DROP_LEVEL_CAPPING, this.onFpsDropLevelCapping, this), e.on(p.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(p.MANIFEST_PARSED, this.onManifestParsed, this), e.on(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(p.BUFFER_CODECS, this.onBufferCodecs, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this);
  }
  unregisterListener() {
    const {
      hls: e
    } = this;
    e.off(p.FPS_DROP_LEVEL_CAPPING, this.onFpsDropLevelCapping, this), e.off(p.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(p.MANIFEST_PARSED, this.onManifestParsed, this), e.off(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(p.BUFFER_CODECS, this.onBufferCodecs, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this);
  }
  onFpsDropLevelCapping(e, t) {
    const s = this.hls.levels[t.droppedLevel];
    this.isLevelAllowed(s) && this.restrictedLevels.push({
      bitrate: s.bitrate,
      height: s.height,
      width: s.width
    });
  }
  onMediaAttaching(e, t) {
    this.media = t.media instanceof HTMLVideoElement ? t.media : null, this.clientRect = null, this.timer && this.hls.levels.length && this.detectPlayerSize();
  }
  onManifestParsed(e, t) {
    const s = this.hls;
    this.restrictedLevels = [], this.firstLevel = t.firstLevel, s.config.capLevelToPlayerSize && t.video && this.startCapping();
  }
  onLevelsUpdated(e, t) {
    this.timer && M(this.autoLevelCapping) && this.detectPlayerSize();
  }
  // Only activate capping when playing a video stream; otherwise, multi-bitrate audio-only streams will be restricted
  // to the first level
  onBufferCodecs(e, t) {
    this.hls.config.capLevelToPlayerSize && t.video && this.startCapping();
  }
  onMediaDetaching() {
    this.stopCapping();
  }
  detectPlayerSize() {
    if (this.media) {
      if (this.mediaHeight <= 0 || this.mediaWidth <= 0) {
        this.clientRect = null;
        return;
      }
      const e = this.hls.levels;
      if (e.length) {
        const t = this.hls, s = this.getMaxLevel(e.length - 1);
        s !== this.autoLevelCapping && v.log(`Setting autoLevelCapping to ${s}: ${e[s].height}p@${e[s].bitrate} for media ${this.mediaWidth}x${this.mediaHeight}`), t.autoLevelCapping = s, t.autoLevelCapping > this.autoLevelCapping && this.streamController && this.streamController.nextLevelSwitch(), this.autoLevelCapping = t.autoLevelCapping;
      }
    }
  }
  /*
   * returns level should be the one with the dimensions equal or greater than the media (player) dimensions (so the video will be downscaled)
   */
  getMaxLevel(e) {
    const t = this.hls.levels;
    if (!t.length)
      return -1;
    const s = t.filter((i, r) => this.isLevelAllowed(i) && r <= e);
    return this.clientRect = null, Zs.getMaxLevelByMediaSize(s, this.mediaWidth, this.mediaHeight);
  }
  startCapping() {
    this.timer || (this.autoLevelCapping = Number.POSITIVE_INFINITY, self.clearInterval(this.timer), this.timer = self.setInterval(this.detectPlayerSize.bind(this), 1e3), this.detectPlayerSize());
  }
  stopCapping() {
    this.restrictedLevels = [], this.firstLevel = -1, this.autoLevelCapping = Number.POSITIVE_INFINITY, this.timer && (self.clearInterval(this.timer), this.timer = void 0);
  }
  getDimensions() {
    if (this.clientRect)
      return this.clientRect;
    const e = this.media, t = {
      width: 0,
      height: 0
    };
    if (e) {
      const s = e.getBoundingClientRect();
      t.width = s.width, t.height = s.height, !t.width && !t.height && (t.width = s.right - s.left || e.width || 0, t.height = s.bottom - s.top || e.height || 0);
    }
    return this.clientRect = t, t;
  }
  get mediaWidth() {
    return this.getDimensions().width * this.contentScaleFactor;
  }
  get mediaHeight() {
    return this.getDimensions().height * this.contentScaleFactor;
  }
  get contentScaleFactor() {
    let e = 1;
    if (!this.hls.config.ignoreDevicePixelRatio)
      try {
        e = self.devicePixelRatio;
      } catch {
      }
    return e;
  }
  isLevelAllowed(e) {
    return !this.restrictedLevels.some((s) => e.bitrate === s.bitrate && e.width === s.width && e.height === s.height);
  }
  static getMaxLevelByMediaSize(e, t, s) {
    if (!(e != null && e.length))
      return -1;
    const i = (o, l) => l ? o.width !== l.width || o.height !== l.height : !0;
    let r = e.length - 1;
    const a = Math.max(t, s);
    for (let o = 0; o < e.length; o += 1) {
      const l = e[o];
      if ((l.width >= a || l.height >= a) && i(l, e[o + 1])) {
        r = o;
        break;
      }
    }
    return r;
  }
}
class Ac {
  constructor(e) {
    this.hls = void 0, this.isVideoPlaybackQualityAvailable = !1, this.timer = void 0, this.media = null, this.lastTime = void 0, this.lastDroppedFrames = 0, this.lastDecodedFrames = 0, this.streamController = void 0, this.hls = e, this.registerListeners();
  }
  setStreamController(e) {
    this.streamController = e;
  }
  registerListeners() {
    this.hls.on(p.MEDIA_ATTACHING, this.onMediaAttaching, this);
  }
  unregisterListeners() {
    this.hls.off(p.MEDIA_ATTACHING, this.onMediaAttaching, this);
  }
  destroy() {
    this.timer && clearInterval(this.timer), this.unregisterListeners(), this.isVideoPlaybackQualityAvailable = !1, this.media = null;
  }
  onMediaAttaching(e, t) {
    const s = this.hls.config;
    if (s.capLevelOnFPSDrop) {
      const i = t.media instanceof self.HTMLVideoElement ? t.media : null;
      this.media = i, i && typeof i.getVideoPlaybackQuality == "function" && (this.isVideoPlaybackQualityAvailable = !0), self.clearInterval(this.timer), this.timer = self.setInterval(this.checkFPSInterval.bind(this), s.fpsDroppedMonitoringPeriod);
    }
  }
  checkFPS(e, t, s) {
    const i = performance.now();
    if (t) {
      if (this.lastTime) {
        const r = i - this.lastTime, a = s - this.lastDroppedFrames, o = t - this.lastDecodedFrames, l = 1e3 * a / r, c = this.hls;
        if (c.trigger(p.FPS_DROP, {
          currentDropped: a,
          currentDecoded: o,
          totalDroppedFrames: s
        }), l > 0 && a > c.config.fpsDroppedMonitoringThreshold * o) {
          let h = c.currentLevel;
          v.warn("drop FPS ratio greater than max allowed value for currentLevel: " + h), h > 0 && (c.autoLevelCapping === -1 || c.autoLevelCapping >= h) && (h = h - 1, c.trigger(p.FPS_DROP_LEVEL_CAPPING, {
            level: h,
            droppedLevel: c.currentLevel
          }), c.autoLevelCapping = h, this.streamController.nextLevelSwitch());
        }
      }
      this.lastTime = i, this.lastDroppedFrames = s, this.lastDecodedFrames = t;
    }
  }
  checkFPSInterval() {
    const e = this.media;
    if (e)
      if (this.isVideoPlaybackQualityAvailable) {
        const t = e.getVideoPlaybackQuality();
        this.checkFPS(e, t.totalVideoFrames, t.droppedVideoFrames);
      } else
        this.checkFPS(e, e.webkitDecodedFrameCount, e.webkitDroppedFrameCount);
  }
}
const xt = "[eme]";
class Qe {
  constructor(e) {
    this.hls = void 0, this.config = void 0, this.media = null, this.keyFormatPromise = null, this.keySystemAccessPromises = {}, this._requestLicenseFailureCount = 0, this.mediaKeySessions = [], this.keyIdToKeySessionPromise = {}, this.setMediaKeysQueue = Qe.CDMCleanupPromise ? [Qe.CDMCleanupPromise] : [], this.onMediaEncrypted = this._onMediaEncrypted.bind(this), this.onWaitingForKey = this._onWaitingForKey.bind(this), this.debug = v.debug.bind(v, xt), this.log = v.log.bind(v, xt), this.warn = v.warn.bind(v, xt), this.error = v.error.bind(v, xt), this.hls = e, this.config = e.config, this.registerListeners();
  }
  destroy() {
    this.unregisterListeners(), this.onMediaDetached();
    const e = this.config;
    e.requestMediaKeySystemAccessFunc = null, e.licenseXhrSetup = e.licenseResponseCallback = void 0, e.drmSystems = e.drmSystemOptions = {}, this.hls = this.onMediaEncrypted = this.onWaitingForKey = this.keyIdToKeySessionPromise = null, this.config = null;
  }
  registerListeners() {
    this.hls.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.on(p.MEDIA_DETACHED, this.onMediaDetached, this), this.hls.on(p.MANIFEST_LOADING, this.onManifestLoading, this), this.hls.on(p.MANIFEST_LOADED, this.onManifestLoaded, this);
  }
  unregisterListeners() {
    this.hls.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.off(p.MEDIA_DETACHED, this.onMediaDetached, this), this.hls.off(p.MANIFEST_LOADING, this.onManifestLoading, this), this.hls.off(p.MANIFEST_LOADED, this.onManifestLoaded, this);
  }
  getLicenseServerUrl(e) {
    const {
      drmSystems: t,
      widevineLicenseUrl: s
    } = this.config, i = t[e];
    if (i)
      return i.licenseUrl;
    if (e === Z.WIDEVINE && s)
      return s;
    throw new Error(`no license server URL configured for key-system "${e}"`);
  }
  getServerCertificateUrl(e) {
    const {
      drmSystems: t
    } = this.config, s = t[e];
    if (s)
      return s.serverCertificateUrl;
    this.log(`No Server Certificate in config.drmSystems["${e}"]`);
  }
  attemptKeySystemAccess(e) {
    const t = this.hls.levels, s = (a, o, l) => !!a && l.indexOf(a) === o, i = t.map((a) => a.audioCodec).filter(s), r = t.map((a) => a.videoCodec).filter(s);
    return i.length + r.length === 0 && r.push("avc1.42e01e"), new Promise((a, o) => {
      const l = (c) => {
        const h = c.shift();
        this.getMediaKeysPromise(h, i, r).then((u) => a({
          keySystem: h,
          mediaKeys: u
        })).catch((u) => {
          c.length ? l(c) : u instanceof me ? o(u) : o(new me({
            type: K.KEY_SYSTEM_ERROR,
            details: L.KEY_SYSTEM_NO_ACCESS,
            error: u,
            fatal: !0
          }, u.message));
        });
      };
      l(e);
    });
  }
  requestMediaKeySystemAccess(e, t) {
    const {
      requestMediaKeySystemAccessFunc: s
    } = this.config;
    if (typeof s != "function") {
      let i = `Configured requestMediaKeySystemAccess is not a function ${s}`;
      return Rr === null && self.location.protocol === "http:" && (i = `navigator.requestMediaKeySystemAccess is not available over insecure protocol ${location.protocol}`), Promise.reject(new Error(i));
    }
    return s(e, t);
  }
  getMediaKeysPromise(e, t, s) {
    const i = Da(e, t, s, this.config.drmSystemOptions), r = this.keySystemAccessPromises[e];
    let a = r == null ? void 0 : r.keySystemAccess;
    if (!a) {
      this.log(`Requesting encrypted media "${e}" key-system access with config: ${JSON.stringify(i)}`), a = this.requestMediaKeySystemAccess(e, i);
      const o = this.keySystemAccessPromises[e] = {
        keySystemAccess: a
      };
      return a.catch((l) => {
        this.log(`Failed to obtain access to key-system "${e}": ${l}`);
      }), a.then((l) => {
        this.log(`Access for key-system "${l.keySystem}" obtained`);
        const c = this.fetchServerCertificate(e);
        return this.log(`Create media-keys for "${e}"`), o.mediaKeys = l.createMediaKeys().then((h) => (this.log(`Media-keys created for "${e}"`), c.then((u) => u ? this.setMediaKeysServerCertificate(h, e, u) : h))), o.mediaKeys.catch((h) => {
          this.error(`Failed to create media-keys for "${e}"}: ${h}`);
        }), o.mediaKeys;
      });
    }
    return a.then(() => r.mediaKeys);
  }
  createMediaKeySessionContext({
    decryptdata: e,
    keySystem: t,
    mediaKeys: s
  }) {
    this.log(`Creating key-system session "${t}" keyId: ${Ae.hexDump(e.keyId || [])}`);
    const i = s.createSession(), r = {
      decryptdata: e,
      keySystem: t,
      mediaKeys: s,
      mediaKeysSession: i,
      keyStatus: "status-pending"
    };
    return this.mediaKeySessions.push(r), r;
  }
  renewKeySession(e) {
    const t = e.decryptdata;
    if (t.pssh) {
      const s = this.createMediaKeySessionContext(e), i = this.getKeyIdString(t), r = "cenc";
      this.keyIdToKeySessionPromise[i] = this.generateRequestWithPreferredKeySession(s, r, t.pssh, "expired");
    } else
      this.warn("Could not renew expired session. Missing pssh initData.");
    this.removeSession(e);
  }
  getKeyIdString(e) {
    if (!e)
      throw new Error("Could not read keyId of undefined decryptdata");
    if (e.keyId === null)
      throw new Error("keyId is null");
    return Ae.hexDump(e.keyId);
  }
  updateKeySession(e, t) {
    var s;
    const i = e.mediaKeysSession;
    return this.log(`Updating key-session "${i.sessionId}" for keyID ${Ae.hexDump(((s = e.decryptdata) == null ? void 0 : s.keyId) || [])}
      } (data length: ${t && t.byteLength})`), i.update(t);
  }
  selectKeySystemFormat(e) {
    const t = Object.keys(e.levelkeys || {});
    return this.keyFormatPromise || (this.log(`Selecting key-system from fragment (sn: ${e.sn} ${e.type}: ${e.level}) key formats ${t.join(", ")}`), this.keyFormatPromise = this.getKeyFormatPromise(t)), this.keyFormatPromise;
  }
  getKeyFormatPromise(e) {
    return new Promise((t, s) => {
      const i = jt(this.config), r = e.map(ci).filter((a) => !!a && i.indexOf(a) !== -1);
      return this.getKeySystemSelectionPromise(r).then(({
        keySystem: a
      }) => {
        const o = ui(a);
        o ? t(o) : s(new Error(`Unable to find format for key-system "${a}"`));
      }).catch(s);
    });
  }
  loadKey(e) {
    const t = e.keyInfo.decryptdata, s = this.getKeyIdString(t), i = `(keyId: ${s} format: "${t.keyFormat}" method: ${t.method} uri: ${t.uri})`;
    this.log(`Starting session for key ${i}`);
    let r = this.keyIdToKeySessionPromise[s];
    return r || (r = this.keyIdToKeySessionPromise[s] = this.getKeySystemForKeyPromise(t).then(({
      keySystem: a,
      mediaKeys: o
    }) => (this.throwIfDestroyed(), this.log(`Handle encrypted media sn: ${e.frag.sn} ${e.frag.type}: ${e.frag.level} using key ${i}`), this.attemptSetMediaKeys(a, o).then(() => {
      this.throwIfDestroyed();
      const l = this.createMediaKeySessionContext({
        keySystem: a,
        mediaKeys: o,
        decryptdata: t
      });
      return this.generateRequestWithPreferredKeySession(l, "cenc", t.pssh, "playlist-key");
    }))), r.catch((a) => this.handleError(a))), r;
  }
  throwIfDestroyed(e = "Invalid state") {
    if (!this.hls)
      throw new Error("invalid state");
  }
  handleError(e) {
    this.hls && (this.error(e.message), e instanceof me ? this.hls.trigger(p.ERROR, e.data) : this.hls.trigger(p.ERROR, {
      type: K.KEY_SYSTEM_ERROR,
      details: L.KEY_SYSTEM_NO_KEYS,
      error: e,
      fatal: !0
    }));
  }
  getKeySystemForKeyPromise(e) {
    const t = this.getKeyIdString(e), s = this.keyIdToKeySessionPromise[t];
    if (!s) {
      const i = ci(e.keyFormat), r = i ? [i] : jt(this.config);
      return this.attemptKeySystemAccess(r);
    }
    return s;
  }
  getKeySystemSelectionPromise(e) {
    if (e.length || (e = jt(this.config)), e.length === 0)
      throw new me({
        type: K.KEY_SYSTEM_ERROR,
        details: L.KEY_SYSTEM_NO_CONFIGURED_LICENSE,
        fatal: !0
      }, `Missing key-system license configuration options ${JSON.stringify({
        drmSystems: this.config.drmSystems
      })}`);
    return this.attemptKeySystemAccess(e);
  }
  _onMediaEncrypted(e) {
    const {
      initDataType: t,
      initData: s
    } = e, i = `"${e.type}" event: init data type: "${t}"`;
    if (this.debug(i), s === null)
      return;
    let r, a;
    if (t === "sinf" && this.config.drmSystems[Z.FAIRPLAY]) {
      const u = ie(new Uint8Array(s));
      try {
        const d = Us(JSON.parse(u).sinf), f = Pr(new Uint8Array(d));
        if (!f)
          throw new Error("'schm' box missing or not cbcs/cenc with schi > tenc");
        r = f.subarray(8, 24), a = Z.FAIRPLAY;
      } catch (d) {
        this.warn(`${i} Failed to parse sinf: ${d}`);
        return;
      }
    } else {
      const u = Za(s), d = u.filter((f) => f.systemId === nt.WIDEVINE)[0];
      if (!d) {
        u.length === 0 || u.some((f) => !f.systemId) ? this.warn(`${i} contains incomplete or invalid pssh data`) : this.log(`ignoring ${i} for ${u.map((f) => hi(f.systemId)).join(",")} pssh data in favor of playlist keys`);
        return;
      }
      if (a = hi(d.systemId), d.version === 0 && d.data) {
        const f = d.data.length - 22;
        r = d.data.subarray(f, f + 16);
      }
    }
    if (!a || !r)
      return;
    const o = Ae.hexDump(r), {
      keyIdToKeySessionPromise: l,
      mediaKeySessions: c
    } = this;
    let h = l[o];
    for (let u = 0; u < c.length; u++) {
      const d = c[u], f = d.decryptdata;
      if (!f.keyId)
        continue;
      const g = Ae.hexDump(f.keyId);
      if (o === g || f.uri.replace(/-/g, "").indexOf(o) !== -1) {
        if (h = l[g], f.pssh)
          break;
        delete l[g], f.pssh = new Uint8Array(s), f.keyId = r, h = l[o] = h.then(() => this.generateRequestWithPreferredKeySession(d, t, s, "encrypted-event-key-match"));
        break;
      }
    }
    h || (h = l[o] = this.getKeySystemSelectionPromise([a]).then(({
      keySystem: u,
      mediaKeys: d
    }) => {
      var f;
      this.throwIfDestroyed();
      const g = new lt("ISO-23001-7", o, (f = ui(u)) != null ? f : "");
      return g.pssh = new Uint8Array(s), g.keyId = r, this.attemptSetMediaKeys(u, d).then(() => {
        this.throwIfDestroyed();
        const m = this.createMediaKeySessionContext({
          decryptdata: g,
          keySystem: u,
          mediaKeys: d
        });
        return this.generateRequestWithPreferredKeySession(m, t, s, "encrypted-event-no-match");
      });
    })), h.catch((u) => this.handleError(u));
  }
  _onWaitingForKey(e) {
    this.log(`"${e.type}" event`);
  }
  attemptSetMediaKeys(e, t) {
    const s = this.setMediaKeysQueue.slice();
    this.log(`Setting media-keys for "${e}"`);
    const i = Promise.all(s).then(() => {
      if (!this.media)
        throw new Error("Attempted to set mediaKeys without media element attached");
      return this.media.setMediaKeys(t);
    });
    return this.setMediaKeysQueue.push(i), i.then(() => {
      this.log(`Media-keys set for "${e}"`), s.push(i), this.setMediaKeysQueue = this.setMediaKeysQueue.filter((r) => s.indexOf(r) === -1);
    });
  }
  generateRequestWithPreferredKeySession(e, t, s, i) {
    var r, a;
    const o = (r = this.config.drmSystems) == null || (a = r[e.keySystem]) == null ? void 0 : a.generateRequest;
    if (o)
      try {
        const g = o.call(this.hls, t, s, e);
        if (!g)
          throw new Error("Invalid response from configured generateRequest filter");
        t = g.initDataType, s = e.decryptdata.pssh = g.initData ? new Uint8Array(g.initData) : null;
      } catch (g) {
        var l;
        if (this.warn(g.message), (l = this.hls) != null && l.config.debug)
          throw g;
      }
    if (s === null)
      return this.log(`Skipping key-session request for "${i}" (no initData)`), Promise.resolve(e);
    const c = this.getKeyIdString(e.decryptdata);
    this.log(`Generating key-session request for "${i}": ${c} (init data type: ${t} length: ${s ? s.byteLength : null})`);
    const h = new Xs(), u = e._onmessage = (g) => {
      const m = e.mediaKeysSession;
      if (!m) {
        h.emit("error", new Error("invalid state"));
        return;
      }
      const {
        messageType: E,
        message: T
      } = g;
      this.log(`"${E}" message event for session "${m.sessionId}" message size: ${T.byteLength}`), E === "license-request" || E === "license-renewal" ? this.renewLicense(e, T).catch((y) => {
        this.handleError(y), h.emit("error", y);
      }) : E === "license-release" ? e.keySystem === Z.FAIRPLAY && (this.updateKeySession(e, ys("acknowledged")), this.removeSession(e)) : this.warn(`unhandled media key message type "${E}"`);
    }, d = e._onkeystatuseschange = (g) => {
      if (!e.mediaKeysSession) {
        h.emit("error", new Error("invalid state"));
        return;
      }
      this.onKeyStatusChange(e);
      const E = e.keyStatus;
      h.emit("keyStatus", E), E === "expired" && (this.warn(`${e.keySystem} expired for key ${c}`), this.renewKeySession(e));
    };
    e.mediaKeysSession.addEventListener("message", u), e.mediaKeysSession.addEventListener("keystatuseschange", d);
    const f = new Promise((g, m) => {
      h.on("error", m), h.on("keyStatus", (E) => {
        E.startsWith("usable") ? g() : E === "output-restricted" ? m(new me({
          type: K.KEY_SYSTEM_ERROR,
          details: L.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED,
          fatal: !1
        }, "HDCP level output restricted")) : E === "internal-error" ? m(new me({
          type: K.KEY_SYSTEM_ERROR,
          details: L.KEY_SYSTEM_STATUS_INTERNAL_ERROR,
          fatal: !0
        }, `key status changed to "${E}"`)) : E === "expired" ? m(new Error("key expired while generating request")) : this.warn(`unhandled key status change "${E}"`);
      });
    });
    return e.mediaKeysSession.generateRequest(t, s).then(() => {
      var g;
      this.log(`Request generated for key-session "${(g = e.mediaKeysSession) == null ? void 0 : g.sessionId}" keyId: ${c}`);
    }).catch((g) => {
      throw new me({
        type: K.KEY_SYSTEM_ERROR,
        details: L.KEY_SYSTEM_NO_SESSION,
        error: g,
        fatal: !1
      }, `Error generating key-session request: ${g}`);
    }).then(() => f).catch((g) => {
      throw h.removeAllListeners(), this.removeSession(e), g;
    }).then(() => (h.removeAllListeners(), e));
  }
  onKeyStatusChange(e) {
    e.mediaKeysSession.keyStatuses.forEach((t, s) => {
      this.log(`key status change "${t}" for keyStatuses keyId: ${Ae.hexDump("buffer" in s ? new Uint8Array(s.buffer, s.byteOffset, s.byteLength) : new Uint8Array(s))} session keyId: ${Ae.hexDump(new Uint8Array(e.decryptdata.keyId || []))} uri: ${e.decryptdata.uri}`), e.keyStatus = t;
    });
  }
  fetchServerCertificate(e) {
    const t = this.config, s = t.loader, i = new s(t), r = this.getServerCertificateUrl(e);
    return r ? (this.log(`Fetching server certificate for "${e}"`), new Promise((a, o) => {
      const l = {
        responseType: "arraybuffer",
        url: r
      }, c = t.certLoadPolicy.default, h = {
        loadPolicy: c,
        timeout: c.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0
      }, u = {
        onSuccess: (d, f, g, m) => {
          a(d.data);
        },
        onError: (d, f, g, m) => {
          o(new me({
            type: K.KEY_SYSTEM_ERROR,
            details: L.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED,
            fatal: !0,
            networkDetails: g,
            response: oe({
              url: l.url,
              data: void 0
            }, d)
          }, `"${e}" certificate request failed (${r}). Status: ${d.code} (${d.text})`));
        },
        onTimeout: (d, f, g) => {
          o(new me({
            type: K.KEY_SYSTEM_ERROR,
            details: L.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED,
            fatal: !0,
            networkDetails: g,
            response: {
              url: l.url,
              data: void 0
            }
          }, `"${e}" certificate request timed out (${r})`));
        },
        onAbort: (d, f, g) => {
          o(new Error("aborted"));
        }
      };
      i.load(l, h, u);
    })) : Promise.resolve();
  }
  setMediaKeysServerCertificate(e, t, s) {
    return new Promise((i, r) => {
      e.setServerCertificate(s).then((a) => {
        this.log(`setServerCertificate ${a ? "success" : "not supported by CDM"} (${s == null ? void 0 : s.byteLength}) on "${t}"`), i(e);
      }).catch((a) => {
        r(new me({
          type: K.KEY_SYSTEM_ERROR,
          details: L.KEY_SYSTEM_SERVER_CERTIFICATE_UPDATE_FAILED,
          error: a,
          fatal: !0
        }, a.message));
      });
    });
  }
  renewLicense(e, t) {
    return this.requestLicense(e, new Uint8Array(t)).then((s) => this.updateKeySession(e, new Uint8Array(s)).catch((i) => {
      throw new me({
        type: K.KEY_SYSTEM_ERROR,
        details: L.KEY_SYSTEM_SESSION_UPDATE_FAILED,
        error: i,
        fatal: !0
      }, i.message);
    }));
  }
  unpackPlayReadyKeyMessage(e, t) {
    const s = String.fromCharCode.apply(null, new Uint16Array(t.buffer));
    if (!s.includes("PlayReadyKeyMessage"))
      return e.setRequestHeader("Content-Type", "text/xml; charset=utf-8"), t;
    const i = new DOMParser().parseFromString(s, "application/xml"), r = i.querySelectorAll("HttpHeader");
    if (r.length > 0) {
      let h;
      for (let u = 0, d = r.length; u < d; u++) {
        var a, o;
        h = r[u];
        const f = (a = h.querySelector("name")) == null ? void 0 : a.textContent, g = (o = h.querySelector("value")) == null ? void 0 : o.textContent;
        f && g && e.setRequestHeader(f, g);
      }
    }
    const l = i.querySelector("Challenge"), c = l == null ? void 0 : l.textContent;
    if (!c)
      throw new Error("Cannot find <Challenge> in key message");
    return ys(atob(c));
  }
  setupLicenseXHR(e, t, s, i) {
    const r = this.config.licenseXhrSetup;
    return r ? Promise.resolve().then(() => {
      if (!s.decryptdata)
        throw new Error("Key removed");
      return r.call(this.hls, e, t, s, i);
    }).catch((a) => {
      if (!s.decryptdata)
        throw a;
      return e.open("POST", t, !0), r.call(this.hls, e, t, s, i);
    }).then((a) => (e.readyState || e.open("POST", t, !0), {
      xhr: e,
      licenseChallenge: a || i
    })) : (e.open("POST", t, !0), Promise.resolve({
      xhr: e,
      licenseChallenge: i
    }));
  }
  requestLicense(e, t) {
    const s = this.config.keyLoadPolicy.default;
    return new Promise((i, r) => {
      const a = this.getLicenseServerUrl(e.keySystem);
      this.log(`Sending license request to URL: ${a}`);
      const o = new XMLHttpRequest();
      o.responseType = "arraybuffer", o.onreadystatechange = () => {
        if (!this.hls || !e.mediaKeysSession)
          return r(new Error("invalid state"));
        if (o.readyState === 4)
          if (o.status === 200) {
            this._requestLicenseFailureCount = 0;
            let l = o.response;
            this.log(`License received ${l instanceof ArrayBuffer ? l.byteLength : l}`);
            const c = this.config.licenseResponseCallback;
            if (c)
              try {
                l = c.call(this.hls, o, a, e);
              } catch (h) {
                this.error(h);
              }
            i(l);
          } else {
            const l = s.errorRetry, c = l ? l.maxNumRetry : 0;
            if (this._requestLicenseFailureCount++, this._requestLicenseFailureCount > c || o.status >= 400 && o.status < 500)
              r(new me({
                type: K.KEY_SYSTEM_ERROR,
                details: L.KEY_SYSTEM_LICENSE_REQUEST_FAILED,
                fatal: !0,
                networkDetails: o,
                response: {
                  url: a,
                  data: void 0,
                  code: o.status,
                  text: o.statusText
                }
              }, `License Request XHR failed (${a}). Status: ${o.status} (${o.statusText})`));
            else {
              const h = c - this._requestLicenseFailureCount + 1;
              this.warn(`Retrying license request, ${h} attempts left`), this.requestLicense(e, t).then(i, r);
            }
          }
      }, e.licenseXhr && e.licenseXhr.readyState !== XMLHttpRequest.DONE && e.licenseXhr.abort(), e.licenseXhr = o, this.setupLicenseXHR(o, a, e, t).then(({
        xhr: l,
        licenseChallenge: c
      }) => {
        e.keySystem == Z.PLAYREADY && (c = this.unpackPlayReadyKeyMessage(l, c)), l.send(c);
      });
    });
  }
  onMediaAttached(e, t) {
    if (!this.config.emeEnabled)
      return;
    const s = t.media;
    this.media = s, s.addEventListener("encrypted", this.onMediaEncrypted), s.addEventListener("waitingforkey", this.onWaitingForKey);
  }
  onMediaDetached() {
    const e = this.media, t = this.mediaKeySessions;
    e && (e.removeEventListener("encrypted", this.onMediaEncrypted), e.removeEventListener("waitingforkey", this.onWaitingForKey), this.media = null), this._requestLicenseFailureCount = 0, this.setMediaKeysQueue = [], this.mediaKeySessions = [], this.keyIdToKeySessionPromise = {}, lt.clearKeyUriToKeyIdMap();
    const s = t.length;
    Qe.CDMCleanupPromise = Promise.all(t.map((i) => this.removeSession(i)).concat(e == null ? void 0 : e.setMediaKeys(null).catch((i) => {
      this.log(`Could not clear media keys: ${i}`);
    }))).then(() => {
      s && (this.log("finished closing key sessions and clearing media keys"), t.length = 0);
    }).catch((i) => {
      this.log(`Could not close sessions and clear media keys: ${i}`);
    });
  }
  onManifestLoading() {
    this.keyFormatPromise = null;
  }
  onManifestLoaded(e, {
    sessionKeys: t
  }) {
    if (!(!t || !this.config.emeEnabled) && !this.keyFormatPromise) {
      const s = t.reduce((i, r) => (i.indexOf(r.keyFormat) === -1 && i.push(r.keyFormat), i), []);
      this.log(`Selecting key-system from session-keys ${s.join(", ")}`), this.keyFormatPromise = this.getKeyFormatPromise(s);
    }
  }
  removeSession(e) {
    const {
      mediaKeysSession: t,
      licenseXhr: s
    } = e;
    if (t) {
      this.log(`Remove licenses and keys and close session ${t.sessionId}`), e._onmessage && (t.removeEventListener("message", e._onmessage), e._onmessage = void 0), e._onkeystatuseschange && (t.removeEventListener("keystatuseschange", e._onkeystatuseschange), e._onkeystatuseschange = void 0), s && s.readyState !== XMLHttpRequest.DONE && s.abort(), e.mediaKeysSession = e.decryptdata = e.licenseXhr = void 0;
      const i = this.mediaKeySessions.indexOf(e);
      return i > -1 && this.mediaKeySessions.splice(i, 1), t.remove().catch((r) => {
        this.log(`Could not remove session: ${r}`);
      }).then(() => t.close()).catch((r) => {
        this.log(`Could not close session: ${r}`);
      });
    }
  }
}
Qe.CDMCleanupPromise = void 0;
class me extends Error {
  constructor(e, t) {
    super(t), this.data = void 0, e.error || (e.error = new Error(t)), this.data = e, e.err = e.error;
  }
}
var ue;
(function(n) {
  n.MANIFEST = "m", n.AUDIO = "a", n.VIDEO = "v", n.MUXED = "av", n.INIT = "i", n.CAPTION = "c", n.TIMED_TEXT = "tt", n.KEY = "k", n.OTHER = "o";
})(ue || (ue = {}));
var Cs;
(function(n) {
  n.DASH = "d", n.HLS = "h", n.SMOOTH = "s", n.OTHER = "o";
})(Cs || (Cs = {}));
var Be;
(function(n) {
  n.OBJECT = "CMCD-Object", n.REQUEST = "CMCD-Request", n.SESSION = "CMCD-Session", n.STATUS = "CMCD-Status";
})(Be || (Be = {}));
const Lc = {
  [Be.OBJECT]: ["br", "d", "ot", "tb"],
  [Be.REQUEST]: ["bl", "dl", "mtp", "nor", "nrr", "su"],
  [Be.SESSION]: ["cid", "pr", "sf", "sid", "st", "v"],
  [Be.STATUS]: ["bs", "rtp"]
};
class tt {
  constructor(e, t) {
    this.value = void 0, this.params = void 0, Array.isArray(e) && (e = e.map((s) => s instanceof tt ? s : new tt(s))), this.value = e, this.params = t;
  }
}
class Sn {
  constructor(e) {
    this.description = void 0, this.description = e;
  }
}
const Rc = "Dict";
function bc(n) {
  return Array.isArray(n) ? JSON.stringify(n) : n instanceof Map ? "Map{}" : n instanceof Set ? "Set{}" : typeof n == "object" ? JSON.stringify(n) : String(n);
}
function Ic(n, e, t, s) {
  return new Error(`failed to ${n} "${bc(e)}" as ${t}`, {
    cause: s
  });
}
const rr = "Bare Item", Dc = "Boolean", Cc = "Byte Sequence", _c = "Decimal", kc = "Integer";
function wc(n) {
  return n < -999999999999999 || 999999999999999 < n;
}
const Pc = /[\x00-\x1f\x7f]+/, Fc = "Token", Oc = "Key";
function De(n, e, t) {
  return Ic("serialize", n, e, t);
}
function Mc(n) {
  if (typeof n != "boolean")
    throw De(n, Dc);
  return n ? "?1" : "?0";
}
function Nc(n) {
  return btoa(String.fromCharCode(...n));
}
function Uc(n) {
  if (ArrayBuffer.isView(n) === !1)
    throw De(n, Cc);
  return `:${Nc(n)}:`;
}
function vn(n) {
  if (wc(n))
    throw De(n, kc);
  return n.toString();
}
function Bc(n) {
  return `@${vn(n.getTime() / 1e3)}`;
}
function An(n, e) {
  if (n < 0)
    return -An(-n, e);
  const t = Math.pow(10, e);
  if (Math.abs(n * t % 1 - 0.5) < Number.EPSILON) {
    const i = Math.floor(n * t);
    return (i % 2 === 0 ? i : i + 1) / t;
  } else
    return Math.round(n * t) / t;
}
function Gc(n) {
  const e = An(n, 3);
  if (Math.floor(Math.abs(e)).toString().length > 12)
    throw De(n, _c);
  const t = e.toString();
  return t.includes(".") ? t : `${t}.0`;
}
const $c = "String";
function Kc(n) {
  if (Pc.test(n))
    throw De(n, $c);
  return `"${n.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}
function Vc(n) {
  return n.description || n.toString().slice(7, -1);
}
function nr(n) {
  const e = Vc(n);
  if (/^([a-zA-Z*])([!#$%&'*+\-.^_`|~\w:/]*)$/.test(e) === !1)
    throw De(e, Fc);
  return e;
}
function _s(n) {
  switch (typeof n) {
    case "number":
      if (!M(n))
        throw De(n, rr);
      return Number.isInteger(n) ? vn(n) : Gc(n);
    case "string":
      return Kc(n);
    case "symbol":
      return nr(n);
    case "boolean":
      return Mc(n);
    case "object":
      if (n instanceof Date)
        return Bc(n);
      if (n instanceof Uint8Array)
        return Uc(n);
      if (n instanceof Sn)
        return nr(n);
    default:
      throw De(n, rr);
  }
}
function ks(n) {
  if (/^[a-z*][a-z0-9\-_.*]*$/.test(n) === !1)
    throw De(n, Oc);
  return n;
}
function ei(n) {
  return n == null ? "" : Object.entries(n).map(([e, t]) => t === !0 ? `;${ks(e)}` : `;${ks(e)}=${_s(t)}`).join("");
}
function Ln(n) {
  return n instanceof tt ? `${_s(n.value)}${ei(n.params)}` : _s(n);
}
function Hc(n) {
  return `(${n.value.map(Ln).join(" ")})${ei(n.params)}`;
}
function Wc(n, e = {
  whitespace: !0
}) {
  if (typeof n != "object")
    throw De(n, Rc);
  const t = n instanceof Map ? n.entries() : Object.entries(n), s = e != null && e.whitespace ? " " : "";
  return Array.from(t).map(([i, r]) => {
    r instanceof tt || (r = new tt(r));
    let a = ks(i);
    return r.value === !0 ? a += ei(r.params) : (a += "=", Array.isArray(r.value) ? a += Hc(r) : a += Ln(r)), a;
  }).join(`,${s}`);
}
function Yc(n, e) {
  return Wc(n, e);
}
const qc = (n) => n === "ot" || n === "sf" || n === "st", jc = (n) => typeof n == "number" ? M(n) : n != null && n !== "" && n !== !1;
function zc(n, e) {
  const t = new URL(n), s = new URL(e);
  if (t.origin !== s.origin)
    return n;
  const i = t.pathname.split("/").slice(1), r = s.pathname.split("/").slice(1, -1);
  for (; i[0] === r[0]; )
    i.shift(), r.shift();
  for (; r.length; )
    r.shift(), i.unshift("..");
  return i.join("/");
}
function Xc() {
  try {
    return crypto.randomUUID();
  } catch {
    try {
      const e = URL.createObjectURL(new Blob()), t = e.toString();
      return URL.revokeObjectURL(e), t.slice(t.lastIndexOf("/") + 1);
    } catch {
      let t = (/* @__PURE__ */ new Date()).getTime();
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (i) => {
        const r = (t + Math.random() * 16) % 16 | 0;
        return t = Math.floor(t / 16), (i == "x" ? r : r & 3 | 8).toString(16);
      });
    }
  }
}
const Ct = (n) => Math.round(n), Qc = (n, e) => (e != null && e.baseUrl && (n = zc(n, e.baseUrl)), encodeURIComponent(n)), St = (n) => Ct(n / 100) * 100, Jc = {
  /**
   * Bitrate (kbps) rounded integer
   */
  br: Ct,
  /**
   * Duration (milliseconds) rounded integer
   */
  d: Ct,
  /**
   * Buffer Length (milliseconds) rounded nearest 100ms
   */
  bl: St,
  /**
   * Deadline (milliseconds) rounded nearest 100ms
   */
  dl: St,
  /**
   * Measured Throughput (kbps) rounded nearest 100kbps
   */
  mtp: St,
  /**
   * Next Object Request URL encoded
   */
  nor: Qc,
  /**
   * Requested maximum throughput (kbps) rounded nearest 100kbps
   */
  rtp: St,
  /**
   * Top Bitrate (kbps) rounded integer
   */
  tb: Ct
};
function Zc(n, e) {
  const t = {};
  if (n == null || typeof n != "object")
    return t;
  const s = Object.keys(n).sort(), i = se({}, Jc, e == null ? void 0 : e.formatters), r = e == null ? void 0 : e.filter;
  return s.forEach((a) => {
    if (r != null && r(a))
      return;
    let o = n[a];
    const l = i[a];
    l && (o = l(o, e)), !(a === "v" && o === 1) && (a == "pr" && o === 1 || jc(o) && (qc(a) && typeof o == "string" && (o = new Sn(o)), t[a] = o));
  }), t;
}
function Rn(n, e = {}) {
  return n ? Yc(Zc(n, e), se({
    whitespace: !1
  }, e)) : "";
}
function eh(n, e = {}) {
  if (!n)
    return {};
  const t = Object.entries(n), s = Object.entries(Lc).concat(Object.entries((e == null ? void 0 : e.customHeaderMap) || {})), i = t.reduce((r, a) => {
    var o, l;
    const [c, h] = a, u = ((o = s.find((d) => d[1].includes(c))) == null ? void 0 : o[0]) || Be.REQUEST;
    return (l = r[u]) != null || (r[u] = {}), r[u][c] = h, r;
  }, {});
  return Object.entries(i).reduce((r, [a, o]) => (r[a] = Rn(o, e), r), {});
}
function th(n, e, t) {
  return se(n, eh(e, t));
}
const sh = "CMCD";
function ih(n, e = {}) {
  if (!n)
    return "";
  const t = Rn(n, e);
  return `${sh}=${encodeURIComponent(t)}`;
}
const ar = /CMCD=[^&#]+/;
function rh(n, e, t) {
  const s = ih(e, t);
  if (!s)
    return n;
  if (ar.test(n))
    return n.replace(ar, s);
  const i = n.includes("?") ? "&" : "?";
  return `${n}${i}${s}`;
}
class nh {
  // eslint-disable-line no-restricted-globals
  constructor(e) {
    this.hls = void 0, this.config = void 0, this.media = void 0, this.sid = void 0, this.cid = void 0, this.useHeaders = !1, this.includeKeys = void 0, this.initialized = !1, this.starved = !1, this.buffering = !0, this.audioBuffer = void 0, this.videoBuffer = void 0, this.onWaiting = () => {
      this.initialized && (this.starved = !0), this.buffering = !0;
    }, this.onPlaying = () => {
      this.initialized || (this.initialized = !0), this.buffering = !1;
    }, this.applyPlaylistData = (i) => {
      try {
        this.apply(i, {
          ot: ue.MANIFEST,
          su: !this.initialized
        });
      } catch (r) {
        v.warn("Could not generate manifest CMCD data.", r);
      }
    }, this.applyFragmentData = (i) => {
      try {
        const r = i.frag, a = this.hls.levels[r.level], o = this.getObjectType(r), l = {
          d: r.duration * 1e3,
          ot: o
        };
        (o === ue.VIDEO || o === ue.AUDIO || o == ue.MUXED) && (l.br = a.bitrate / 1e3, l.tb = this.getTopBandwidth(o) / 1e3, l.bl = this.getBufferLength(o)), this.apply(i, l);
      } catch (r) {
        v.warn("Could not generate segment CMCD data.", r);
      }
    }, this.hls = e;
    const t = this.config = e.config, {
      cmcd: s
    } = t;
    s != null && (t.pLoader = this.createPlaylistLoader(), t.fLoader = this.createFragmentLoader(), this.sid = s.sessionId || Xc(), this.cid = s.contentId, this.useHeaders = s.useHeaders === !0, this.includeKeys = s.includeKeys, this.registerListeners());
  }
  registerListeners() {
    const e = this.hls;
    e.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(p.MEDIA_DETACHED, this.onMediaDetached, this), e.on(p.BUFFER_CREATED, this.onBufferCreated, this);
  }
  unregisterListeners() {
    const e = this.hls;
    e.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(p.MEDIA_DETACHED, this.onMediaDetached, this), e.off(p.BUFFER_CREATED, this.onBufferCreated, this);
  }
  destroy() {
    this.unregisterListeners(), this.onMediaDetached(), this.hls = this.config = this.audioBuffer = this.videoBuffer = null, this.onWaiting = this.onPlaying = null;
  }
  onMediaAttached(e, t) {
    this.media = t.media, this.media.addEventListener("waiting", this.onWaiting), this.media.addEventListener("playing", this.onPlaying);
  }
  onMediaDetached() {
    this.media && (this.media.removeEventListener("waiting", this.onWaiting), this.media.removeEventListener("playing", this.onPlaying), this.media = null);
  }
  onBufferCreated(e, t) {
    var s, i;
    this.audioBuffer = (s = t.tracks.audio) == null ? void 0 : s.buffer, this.videoBuffer = (i = t.tracks.video) == null ? void 0 : i.buffer;
  }
  /**
   * Create baseline CMCD data
   */
  createData() {
    var e;
    return {
      v: 1,
      sf: Cs.HLS,
      sid: this.sid,
      cid: this.cid,
      pr: (e = this.media) == null ? void 0 : e.playbackRate,
      mtp: this.hls.bandwidthEstimate / 1e3
    };
  }
  /**
   * Apply CMCD data to a request.
   */
  apply(e, t = {}) {
    se(t, this.createData());
    const s = t.ot === ue.INIT || t.ot === ue.VIDEO || t.ot === ue.MUXED;
    this.starved && s && (t.bs = !0, t.su = !0, this.starved = !1), t.su == null && (t.su = this.buffering);
    const {
      includeKeys: i
    } = this;
    i && (t = Object.keys(t).reduce((r, a) => (i.includes(a) && (r[a] = t[a]), r), {})), this.useHeaders ? (e.headers || (e.headers = {}), th(e.headers, t)) : e.url = rh(e.url, t);
  }
  /**
   * The CMCD object type.
   */
  getObjectType(e) {
    const {
      type: t
    } = e;
    if (t === "subtitle")
      return ue.TIMED_TEXT;
    if (e.sn === "initSegment")
      return ue.INIT;
    if (t === "audio")
      return ue.AUDIO;
    if (t === "main")
      return this.hls.audioTracks.length ? ue.VIDEO : ue.MUXED;
  }
  /**
   * Get the highest bitrate.
   */
  getTopBandwidth(e) {
    let t = 0, s;
    const i = this.hls;
    if (e === ue.AUDIO)
      s = i.audioTracks;
    else {
      const r = i.maxAutoLevel, a = r > -1 ? r + 1 : i.levels.length;
      s = i.levels.slice(0, a);
    }
    for (const r of s)
      r.bitrate > t && (t = r.bitrate);
    return t > 0 ? t : NaN;
  }
  /**
   * Get the buffer length for a media type in milliseconds
   */
  getBufferLength(e) {
    const t = this.hls.media, s = e === ue.AUDIO ? this.audioBuffer : this.videoBuffer;
    return !s || !t ? NaN : J.bufferInfo(s, t.currentTime, this.config.maxBufferHole).len * 1e3;
  }
  /**
   * Create a playlist loader
   */
  createPlaylistLoader() {
    const {
      pLoader: e
    } = this.config, t = this.applyPlaylistData, s = e || this.config.loader;
    return class {
      constructor(r) {
        this.loader = void 0, this.loader = new s(r);
      }
      get stats() {
        return this.loader.stats;
      }
      get context() {
        return this.loader.context;
      }
      destroy() {
        this.loader.destroy();
      }
      abort() {
        this.loader.abort();
      }
      load(r, a, o) {
        t(r), this.loader.load(r, a, o);
      }
    };
  }
  /**
   * Create a playlist loader
   */
  createFragmentLoader() {
    const {
      fLoader: e
    } = this.config, t = this.applyFragmentData, s = e || this.config.loader;
    return class {
      constructor(r) {
        this.loader = void 0, this.loader = new s(r);
      }
      get stats() {
        return this.loader.stats;
      }
      get context() {
        return this.loader.context;
      }
      destroy() {
        this.loader.destroy();
      }
      abort() {
        this.loader.abort();
      }
      load(r, a, o) {
        t(r), this.loader.load(r, a, o);
      }
    };
  }
}
const ah = 3e5;
class oh {
  constructor(e) {
    this.hls = void 0, this.log = void 0, this.loader = null, this.uri = null, this.pathwayId = ".", this.pathwayPriority = null, this.timeToLoad = 300, this.reloadTimer = -1, this.updated = 0, this.started = !1, this.enabled = !0, this.levels = null, this.audioTracks = null, this.subtitleTracks = null, this.penalizedPathways = {}, this.hls = e, this.log = v.log.bind(v, "[content-steering]:"), this.registerListeners();
  }
  registerListeners() {
    const e = this.hls;
    e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.MANIFEST_LOADED, this.onManifestLoaded, this), e.on(p.MANIFEST_PARSED, this.onManifestParsed, this), e.on(p.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const e = this.hls;
    e && (e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.MANIFEST_LOADED, this.onManifestLoaded, this), e.off(p.MANIFEST_PARSED, this.onManifestParsed, this), e.off(p.ERROR, this.onError, this));
  }
  startLoad() {
    if (this.started = !0, this.clearTimeout(), this.enabled && this.uri) {
      if (this.updated) {
        const e = this.timeToLoad * 1e3 - (performance.now() - this.updated);
        if (e > 0) {
          this.scheduleRefresh(this.uri, e);
          return;
        }
      }
      this.loadSteeringManifest(this.uri);
    }
  }
  stopLoad() {
    this.started = !1, this.loader && (this.loader.destroy(), this.loader = null), this.clearTimeout();
  }
  clearTimeout() {
    this.reloadTimer !== -1 && (self.clearTimeout(this.reloadTimer), this.reloadTimer = -1);
  }
  destroy() {
    this.unregisterListeners(), this.stopLoad(), this.hls = null, this.levels = this.audioTracks = this.subtitleTracks = null;
  }
  removeLevel(e) {
    const t = this.levels;
    t && (this.levels = t.filter((s) => s !== e));
  }
  onManifestLoading() {
    this.stopLoad(), this.enabled = !0, this.timeToLoad = 300, this.updated = 0, this.uri = null, this.pathwayId = ".", this.levels = this.audioTracks = this.subtitleTracks = null;
  }
  onManifestLoaded(e, t) {
    const {
      contentSteering: s
    } = t;
    s !== null && (this.pathwayId = s.pathwayId, this.uri = s.uri, this.started && this.startLoad());
  }
  onManifestParsed(e, t) {
    this.audioTracks = t.audioTracks, this.subtitleTracks = t.subtitleTracks;
  }
  onError(e, t) {
    const {
      errorAction: s
    } = t;
    if ((s == null ? void 0 : s.action) === ce.SendAlternateToPenaltyBox && s.flags === ye.MoveAllAlternatesMatchingHost) {
      const i = this.levels;
      let r = this.pathwayPriority, a = this.pathwayId;
      if (t.context) {
        const {
          groupId: o,
          pathwayId: l,
          type: c
        } = t.context;
        o && i ? a = this.getPathwayForGroupId(o, c, a) : l && (a = l);
      }
      a in this.penalizedPathways || (this.penalizedPathways[a] = performance.now()), !r && i && (r = i.reduce((o, l) => (o.indexOf(l.pathwayId) === -1 && o.push(l.pathwayId), o), [])), r && r.length > 1 && (this.updatePathwayPriority(r), s.resolved = this.pathwayId !== a), s.resolved || v.warn(`Could not resolve ${t.details} ("${t.error.message}") with content-steering for Pathway: ${a} levels: ${i && i.length} priorities: ${JSON.stringify(r)} penalized: ${JSON.stringify(this.penalizedPathways)}`);
    }
  }
  filterParsedLevels(e) {
    this.levels = e;
    let t = this.getLevelsForPathway(this.pathwayId);
    if (t.length === 0) {
      const s = e[0].pathwayId;
      this.log(`No levels found in Pathway ${this.pathwayId}. Setting initial Pathway to "${s}"`), t = this.getLevelsForPathway(s), this.pathwayId = s;
    }
    return t.length !== e.length && this.log(`Found ${t.length}/${e.length} levels in Pathway "${this.pathwayId}"`), t;
  }
  getLevelsForPathway(e) {
    return this.levels === null ? [] : this.levels.filter((t) => e === t.pathwayId);
  }
  updatePathwayPriority(e) {
    this.pathwayPriority = e;
    let t;
    const s = this.penalizedPathways, i = performance.now();
    Object.keys(s).forEach((r) => {
      i - s[r] > ah && delete s[r];
    });
    for (let r = 0; r < e.length; r++) {
      const a = e[r];
      if (a in s)
        continue;
      if (a === this.pathwayId)
        return;
      const o = this.hls.nextLoadLevel, l = this.hls.levels[o];
      if (t = this.getLevelsForPathway(a), t.length > 0) {
        this.log(`Setting Pathway to "${a}"`), this.pathwayId = a, Vr(t), this.hls.trigger(p.LEVELS_UPDATED, {
          levels: t
        });
        const c = this.hls.levels[o];
        l && c && this.levels && (c.attrs["STABLE-VARIANT-ID"] !== l.attrs["STABLE-VARIANT-ID"] && c.bitrate !== l.bitrate && this.log(`Unstable Pathways change from bitrate ${l.bitrate} to ${c.bitrate}`), this.hls.nextLoadLevel = o);
        break;
      }
    }
  }
  getPathwayForGroupId(e, t, s) {
    const i = this.getLevelsForPathway(s).concat(this.levels || []);
    for (let r = 0; r < i.length; r++)
      if (t === q.AUDIO_TRACK && i[r].hasAudioGroup(e) || t === q.SUBTITLE_TRACK && i[r].hasSubtitleGroup(e))
        return i[r].pathwayId;
    return s;
  }
  clonePathways(e) {
    const t = this.levels;
    if (!t)
      return;
    const s = {}, i = {};
    e.forEach((r) => {
      const {
        ID: a,
        "BASE-ID": o,
        "URI-REPLACEMENT": l
      } = r;
      if (t.some((h) => h.pathwayId === a))
        return;
      const c = this.getLevelsForPathway(o).map((h) => {
        const u = new ee(h.attrs);
        u["PATHWAY-ID"] = a;
        const d = u.AUDIO && `${u.AUDIO}_clone_${a}`, f = u.SUBTITLES && `${u.SUBTITLES}_clone_${a}`;
        d && (s[u.AUDIO] = d, u.AUDIO = d), f && (i[u.SUBTITLES] = f, u.SUBTITLES = f);
        const g = bn(h.uri, u["STABLE-VARIANT-ID"], "PER-VARIANT-URIS", l), m = new Ze({
          attrs: u,
          audioCodec: h.audioCodec,
          bitrate: h.bitrate,
          height: h.height,
          name: h.name,
          url: g,
          videoCodec: h.videoCodec,
          width: h.width
        });
        if (h.audioGroups)
          for (let E = 1; E < h.audioGroups.length; E++)
            m.addGroupId("audio", `${h.audioGroups[E]}_clone_${a}`);
        if (h.subtitleGroups)
          for (let E = 1; E < h.subtitleGroups.length; E++)
            m.addGroupId("text", `${h.subtitleGroups[E]}_clone_${a}`);
        return m;
      });
      t.push(...c), or(this.audioTracks, s, l, a), or(this.subtitleTracks, i, l, a);
    });
  }
  loadSteeringManifest(e) {
    const t = this.hls.config, s = t.loader;
    this.loader && this.loader.destroy(), this.loader = new s(t);
    let i;
    try {
      i = new self.URL(e);
    } catch {
      this.enabled = !1, this.log(`Failed to parse Steering Manifest URI: ${e}`);
      return;
    }
    if (i.protocol !== "data:") {
      const h = (this.hls.bandwidthEstimate || t.abrEwmaDefaultEstimate) | 0;
      i.searchParams.set("_HLS_pathway", this.pathwayId), i.searchParams.set("_HLS_throughput", "" + h);
    }
    const r = {
      responseType: "json",
      url: i.href
    }, a = t.steeringManifestLoadPolicy.default, o = a.errorRetry || a.timeoutRetry || {}, l = {
      loadPolicy: a,
      timeout: a.maxLoadTimeMs,
      maxRetry: o.maxNumRetry || 0,
      retryDelay: o.retryDelayMs || 0,
      maxRetryDelay: o.maxRetryDelayMs || 0
    }, c = {
      onSuccess: (h, u, d, f) => {
        this.log(`Loaded steering manifest: "${i}"`);
        const g = h.data;
        if (g.VERSION !== 1) {
          this.log(`Steering VERSION ${g.VERSION} not supported!`);
          return;
        }
        this.updated = performance.now(), this.timeToLoad = g.TTL;
        const {
          "RELOAD-URI": m,
          "PATHWAY-CLONES": E,
          "PATHWAY-PRIORITY": T
        } = g;
        if (m)
          try {
            this.uri = new self.URL(m, i).href;
          } catch {
            this.enabled = !1, this.log(`Failed to parse Steering Manifest RELOAD-URI: ${m}`);
            return;
          }
        this.scheduleRefresh(this.uri || d.url), E && this.clonePathways(E);
        const y = {
          steeringManifest: g,
          url: i.toString()
        };
        this.hls.trigger(p.STEERING_MANIFEST_LOADED, y), T && this.updatePathwayPriority(T);
      },
      onError: (h, u, d, f) => {
        if (this.log(`Error loading steering manifest: ${h.code} ${h.text} (${u.url})`), this.stopLoad(), h.code === 410) {
          this.enabled = !1, this.log(`Steering manifest ${u.url} no longer available`);
          return;
        }
        let g = this.timeToLoad * 1e3;
        if (h.code === 429) {
          const m = this.loader;
          if (typeof (m == null ? void 0 : m.getResponseHeader) == "function") {
            const E = m.getResponseHeader("Retry-After");
            E && (g = parseFloat(E) * 1e3);
          }
          this.log(`Steering manifest ${u.url} rate limited`);
          return;
        }
        this.scheduleRefresh(this.uri || u.url, g);
      },
      onTimeout: (h, u, d) => {
        this.log(`Timeout loading steering manifest (${u.url})`), this.scheduleRefresh(this.uri || u.url);
      }
    };
    this.log(`Requesting steering manifest: ${i}`), this.loader.load(r, l, c);
  }
  scheduleRefresh(e, t = this.timeToLoad * 1e3) {
    this.clearTimeout(), this.reloadTimer = self.setTimeout(() => {
      var s;
      const i = (s = this.hls) == null ? void 0 : s.media;
      if (i && !i.ended) {
        this.loadSteeringManifest(e);
        return;
      }
      this.scheduleRefresh(e, this.timeToLoad * 1e3);
    }, t);
  }
}
function or(n, e, t, s) {
  n && Object.keys(e).forEach((i) => {
    const r = n.filter((a) => a.groupId === i).map((a) => {
      const o = se({}, a);
      return o.details = void 0, o.attrs = new ee(o.attrs), o.url = o.attrs.URI = bn(a.url, a.attrs["STABLE-RENDITION-ID"], "PER-RENDITION-URIS", t), o.groupId = o.attrs["GROUP-ID"] = e[i], o.attrs["PATHWAY-ID"] = s, o;
    });
    n.push(...r);
  });
}
function bn(n, e, t, s) {
  const {
    HOST: i,
    PARAMS: r,
    [t]: a
  } = s;
  let o;
  e && (o = a == null ? void 0 : a[e], o && (n = o));
  const l = new self.URL(n);
  return i && !o && (l.host = i), r && Object.keys(r).sort().forEach((c) => {
    c && l.searchParams.set(c, r[c]);
  }), l.href;
}
const lh = /^age:\s*[\d.]+\s*$/im;
class In {
  constructor(e) {
    this.xhrSetup = void 0, this.requestTimeout = void 0, this.retryTimeout = void 0, this.retryDelay = void 0, this.config = null, this.callbacks = null, this.context = null, this.loader = null, this.stats = void 0, this.xhrSetup = e && e.xhrSetup || null, this.stats = new Vt(), this.retryDelay = 0;
  }
  destroy() {
    this.callbacks = null, this.abortInternal(), this.loader = null, this.config = null, this.context = null, this.xhrSetup = null;
  }
  abortInternal() {
    const e = this.loader;
    self.clearTimeout(this.requestTimeout), self.clearTimeout(this.retryTimeout), e && (e.onreadystatechange = null, e.onprogress = null, e.readyState !== 4 && (this.stats.aborted = !0, e.abort()));
  }
  abort() {
    var e;
    this.abortInternal(), (e = this.callbacks) != null && e.onAbort && this.callbacks.onAbort(this.stats, this.context, this.loader);
  }
  load(e, t, s) {
    if (this.stats.loading.start)
      throw new Error("Loader can only be used once.");
    this.stats.loading.start = self.performance.now(), this.context = e, this.config = t, this.callbacks = s, this.loadInternal();
  }
  loadInternal() {
    const {
      config: e,
      context: t
    } = this;
    if (!e || !t)
      return;
    const s = this.loader = new self.XMLHttpRequest(), i = this.stats;
    i.loading.first = 0, i.loaded = 0, i.aborted = !1;
    const r = this.xhrSetup;
    r ? Promise.resolve().then(() => {
      if (!(this.loader !== s || this.stats.aborted))
        return r(s, t.url);
    }).catch((a) => {
      if (!(this.loader !== s || this.stats.aborted))
        return s.open("GET", t.url, !0), r(s, t.url);
    }).then(() => {
      this.loader !== s || this.stats.aborted || this.openAndSendXhr(s, t, e);
    }).catch((a) => {
      this.callbacks.onError({
        code: s.status,
        text: a.message
      }, t, s, i);
    }) : this.openAndSendXhr(s, t, e);
  }
  openAndSendXhr(e, t, s) {
    e.readyState || e.open("GET", t.url, !0);
    const i = t.headers, {
      maxTimeToFirstByteMs: r,
      maxLoadTimeMs: a
    } = s.loadPolicy;
    if (i)
      for (const o in i)
        e.setRequestHeader(o, i[o]);
    t.rangeEnd && e.setRequestHeader("Range", "bytes=" + t.rangeStart + "-" + (t.rangeEnd - 1)), e.onreadystatechange = this.readystatechange.bind(this), e.onprogress = this.loadprogress.bind(this), e.responseType = t.responseType, self.clearTimeout(this.requestTimeout), s.timeout = r && M(r) ? r : a, this.requestTimeout = self.setTimeout(this.loadtimeout.bind(this), s.timeout), e.send();
  }
  readystatechange() {
    const {
      context: e,
      loader: t,
      stats: s
    } = this;
    if (!e || !t)
      return;
    const i = t.readyState, r = this.config;
    if (!s.aborted && i >= 2 && (s.loading.first === 0 && (s.loading.first = Math.max(self.performance.now(), s.loading.start), r.timeout !== r.loadPolicy.maxLoadTimeMs && (self.clearTimeout(this.requestTimeout), r.timeout = r.loadPolicy.maxLoadTimeMs, this.requestTimeout = self.setTimeout(this.loadtimeout.bind(this), r.loadPolicy.maxLoadTimeMs - (s.loading.first - s.loading.start)))), i === 4)) {
      self.clearTimeout(this.requestTimeout), t.onreadystatechange = null, t.onprogress = null;
      const a = t.status, o = t.responseType !== "text";
      if (a >= 200 && a < 300 && (o && t.response || t.responseText !== null)) {
        s.loading.end = Math.max(self.performance.now(), s.loading.first);
        const l = o ? t.response : t.responseText, c = t.responseType === "arraybuffer" ? l.byteLength : l.length;
        if (s.loaded = s.total = c, s.bwEstimate = s.total * 8e3 / (s.loading.end - s.loading.first), !this.callbacks)
          return;
        const h = this.callbacks.onProgress;
        if (h && h(s, e, l, t), !this.callbacks)
          return;
        const u = {
          url: t.responseURL,
          data: l,
          code: a
        };
        this.callbacks.onSuccess(u, s, e, t);
      } else {
        const l = r.loadPolicy.errorRetry, c = s.retry, h = {
          url: e.url,
          data: void 0,
          code: a
        };
        Nt(l, c, !1, h) ? this.retry(l) : (v.error(`${a} while loading ${e.url}`), this.callbacks.onError({
          code: a,
          text: t.statusText
        }, e, t, s));
      }
    }
  }
  loadtimeout() {
    if (!this.config) return;
    const e = this.config.loadPolicy.timeoutRetry, t = this.stats.retry;
    if (Nt(e, t, !0))
      this.retry(e);
    else {
      var s;
      v.warn(`timeout while loading ${(s = this.context) == null ? void 0 : s.url}`);
      const i = this.callbacks;
      i && (this.abortInternal(), i.onTimeout(this.stats, this.context, this.loader));
    }
  }
  retry(e) {
    const {
      context: t,
      stats: s
    } = this;
    this.retryDelay = $s(e, s.retry), s.retry++, v.warn(`${status ? "HTTP Status " + status : "Timeout"} while loading ${t == null ? void 0 : t.url}, retrying ${s.retry}/${e.maxNumRetry} in ${this.retryDelay}ms`), this.abortInternal(), this.loader = null, self.clearTimeout(this.retryTimeout), this.retryTimeout = self.setTimeout(this.loadInternal.bind(this), this.retryDelay);
  }
  loadprogress(e) {
    const t = this.stats;
    t.loaded = e.loaded, e.lengthComputable && (t.total = e.total);
  }
  getCacheAge() {
    let e = null;
    if (this.loader && lh.test(this.loader.getAllResponseHeaders())) {
      const t = this.loader.getResponseHeader("age");
      e = t ? parseFloat(t) : null;
    }
    return e;
  }
  getResponseHeader(e) {
    return this.loader && new RegExp(`^${e}:\\s*[\\d.]+\\s*$`, "im").test(this.loader.getAllResponseHeaders()) ? this.loader.getResponseHeader(e) : null;
  }
}
function ch() {
  if (
    // @ts-ignore
    self.fetch && self.AbortController && self.ReadableStream && self.Request
  )
    try {
      return new self.ReadableStream({}), !0;
    } catch {
    }
  return !1;
}
const hh = /(\d+)-(\d+)\/(\d+)/;
class lr {
  constructor(e) {
    this.fetchSetup = void 0, this.requestTimeout = void 0, this.request = null, this.response = null, this.controller = void 0, this.context = null, this.config = null, this.callbacks = null, this.stats = void 0, this.loader = null, this.fetchSetup = e.fetchSetup || gh, this.controller = new self.AbortController(), this.stats = new Vt();
  }
  destroy() {
    this.loader = this.callbacks = this.context = this.config = this.request = null, this.abortInternal(), this.response = null, this.fetchSetup = this.controller = this.stats = null;
  }
  abortInternal() {
    this.controller && !this.stats.loading.end && (this.stats.aborted = !0, this.controller.abort());
  }
  abort() {
    var e;
    this.abortInternal(), (e = this.callbacks) != null && e.onAbort && this.callbacks.onAbort(this.stats, this.context, this.response);
  }
  load(e, t, s) {
    const i = this.stats;
    if (i.loading.start)
      throw new Error("Loader can only be used once.");
    i.loading.start = self.performance.now();
    const r = uh(e, this.controller.signal), a = s.onProgress, o = e.responseType === "arraybuffer", l = o ? "byteLength" : "length", {
      maxTimeToFirstByteMs: c,
      maxLoadTimeMs: h
    } = t.loadPolicy;
    this.context = e, this.config = t, this.callbacks = s, this.request = this.fetchSetup(e, r), self.clearTimeout(this.requestTimeout), t.timeout = c && M(c) ? c : h, this.requestTimeout = self.setTimeout(() => {
      this.abortInternal(), s.onTimeout(i, e, this.response);
    }, t.timeout), self.fetch(this.request).then((u) => {
      this.response = this.loader = u;
      const d = Math.max(self.performance.now(), i.loading.start);
      if (self.clearTimeout(this.requestTimeout), t.timeout = h, this.requestTimeout = self.setTimeout(() => {
        this.abortInternal(), s.onTimeout(i, e, this.response);
      }, h - (d - i.loading.start)), !u.ok) {
        const {
          status: f,
          statusText: g
        } = u;
        throw new mh(g || "fetch, bad network response", f, u);
      }
      return i.loading.first = d, i.total = fh(u.headers) || i.total, a && M(t.highWaterMark) ? this.loadProgressively(u, i, e, t.highWaterMark, a) : o ? u.arrayBuffer() : e.responseType === "json" ? u.json() : u.text();
    }).then((u) => {
      const d = this.response;
      if (!d)
        throw new Error("loader destroyed");
      self.clearTimeout(this.requestTimeout), i.loading.end = Math.max(self.performance.now(), i.loading.first);
      const f = u[l];
      f && (i.loaded = i.total = f);
      const g = {
        url: d.url,
        data: u,
        code: d.status
      };
      a && !M(t.highWaterMark) && a(i, e, u, d), s.onSuccess(g, i, e, d);
    }).catch((u) => {
      if (self.clearTimeout(this.requestTimeout), i.aborted)
        return;
      const d = u && u.code || 0, f = u ? u.message : null;
      s.onError({
        code: d,
        text: f
      }, e, u ? u.details : null, i);
    });
  }
  getCacheAge() {
    let e = null;
    if (this.response) {
      const t = this.response.headers.get("age");
      e = t ? parseFloat(t) : null;
    }
    return e;
  }
  getResponseHeader(e) {
    return this.response ? this.response.headers.get(e) : null;
  }
  loadProgressively(e, t, s, i = 0, r) {
    const a = new qr(), o = e.body.getReader(), l = () => o.read().then((c) => {
      if (c.done)
        return a.dataLength && r(t, s, a.flush(), e), Promise.resolve(new ArrayBuffer(0));
      const h = c.value, u = h.length;
      return t.loaded += u, u < i || a.dataLength ? (a.push(h), a.dataLength >= i && r(t, s, a.flush(), e)) : r(t, s, h, e), l();
    }).catch(() => Promise.reject());
    return l();
  }
}
function uh(n, e) {
  const t = {
    method: "GET",
    mode: "cors",
    credentials: "same-origin",
    signal: e,
    headers: new self.Headers(se({}, n.headers))
  };
  return n.rangeEnd && t.headers.set("Range", "bytes=" + n.rangeStart + "-" + String(n.rangeEnd - 1)), t;
}
function dh(n) {
  const e = hh.exec(n);
  if (e)
    return parseInt(e[2]) - parseInt(e[1]) + 1;
}
function fh(n) {
  const e = n.get("Content-Range");
  if (e) {
    const s = dh(e);
    if (M(s))
      return s;
  }
  const t = n.get("Content-Length");
  if (t)
    return parseInt(t);
}
function gh(n, e) {
  return new self.Request(n.url, e);
}
class mh extends Error {
  constructor(e, t, s) {
    super(e), this.code = void 0, this.details = void 0, this.code = t, this.details = s;
  }
}
const ph = /\s/, Eh = {
  newCue(n, e, t, s) {
    const i = [];
    let r, a, o, l, c;
    const h = self.VTTCue || self.TextTrackCue;
    for (let d = 0; d < s.rows.length; d++)
      if (r = s.rows[d], o = !0, l = 0, c = "", !r.isEmpty()) {
        var u;
        for (let m = 0; m < r.chars.length; m++)
          ph.test(r.chars[m].uchar) && o ? l++ : (c += r.chars[m].uchar, o = !1);
        r.cueStartTime = e, e === t && (t += 1e-4), l >= 16 ? l-- : l++;
        const f = pn(c.trim()), g = Js(e, t, f);
        n != null && (u = n.cues) != null && u.getCueById(g) || (a = new h(e, t, f), a.id = g, a.line = d + 1, a.align = "left", a.position = 10 + Math.min(80, Math.floor(l * 8 / 32) * 10), i.push(a));
      }
    return n && i.length && (i.sort((d, f) => d.line === "auto" || f.line === "auto" ? 0 : d.line > 8 && f.line > 8 ? f.line - d.line : d.line - f.line), i.forEach((d) => Br(n, d))), i;
  }
}, Th = {
  maxTimeToFirstByteMs: 8e3,
  maxLoadTimeMs: 2e4,
  timeoutRetry: null,
  errorRetry: null
}, Dn = oe(oe({
  autoStartLoad: !0,
  // used by stream-controller
  startPosition: -1,
  // used by stream-controller
  defaultAudioCodec: void 0,
  // used by stream-controller
  debug: !1,
  // used by logger
  capLevelOnFPSDrop: !1,
  // used by fps-controller
  capLevelToPlayerSize: !1,
  // used by cap-level-controller
  ignoreDevicePixelRatio: !1,
  // used by cap-level-controller
  preferManagedMediaSource: !0,
  initialLiveManifestSize: 1,
  // used by stream-controller
  maxBufferLength: 30,
  // used by stream-controller
  backBufferLength: 1 / 0,
  // used by buffer-controller
  frontBufferFlushThreshold: 1 / 0,
  maxBufferSize: 60 * 1e3 * 1e3,
  // used by stream-controller
  maxBufferHole: 0.1,
  // used by stream-controller
  highBufferWatchdogPeriod: 2,
  // used by stream-controller
  nudgeOffset: 0.1,
  // used by stream-controller
  nudgeMaxRetry: 3,
  // used by stream-controller
  maxFragLookUpTolerance: 0.25,
  // used by stream-controller
  liveSyncDurationCount: 3,
  // used by latency-controller
  liveMaxLatencyDurationCount: 1 / 0,
  // used by latency-controller
  liveSyncDuration: void 0,
  // used by latency-controller
  liveMaxLatencyDuration: void 0,
  // used by latency-controller
  maxLiveSyncPlaybackRate: 1,
  // used by latency-controller
  liveDurationInfinity: !1,
  // used by buffer-controller
  /**
   * @deprecated use backBufferLength
   */
  liveBackBufferLength: null,
  // used by buffer-controller
  maxMaxBufferLength: 600,
  // used by stream-controller
  enableWorker: !0,
  // used by transmuxer
  workerPath: null,
  // used by transmuxer
  enableSoftwareAES: !0,
  // used by decrypter
  startLevel: void 0,
  // used by level-controller
  startFragPrefetch: !1,
  // used by stream-controller
  fpsDroppedMonitoringPeriod: 5e3,
  // used by fps-controller
  fpsDroppedMonitoringThreshold: 0.2,
  // used by fps-controller
  appendErrorMaxRetry: 3,
  // used by buffer-controller
  loader: In,
  // loader: FetchLoader,
  fLoader: void 0,
  // used by fragment-loader
  pLoader: void 0,
  // used by playlist-loader
  xhrSetup: void 0,
  // used by xhr-loader
  licenseXhrSetup: void 0,
  // used by eme-controller
  licenseResponseCallback: void 0,
  // used by eme-controller
  abrController: Wo,
  bufferController: zl,
  capLevelController: Zs,
  errorController: Po,
  fpsController: Ac,
  stretchShortVideoTrack: !1,
  // used by mp4-remuxer
  maxAudioFramesDrift: 1,
  // used by mp4-remuxer
  forceKeyFrameOnDiscontinuity: !0,
  // used by ts-demuxer
  abrEwmaFastLive: 3,
  // used by abr-controller
  abrEwmaSlowLive: 9,
  // used by abr-controller
  abrEwmaFastVoD: 3,
  // used by abr-controller
  abrEwmaSlowVoD: 9,
  // used by abr-controller
  abrEwmaDefaultEstimate: 5e5,
  // 500 kbps  // used by abr-controller
  abrEwmaDefaultEstimateMax: 5e6,
  // 5 mbps
  abrBandWidthFactor: 0.95,
  // used by abr-controller
  abrBandWidthUpFactor: 0.7,
  // used by abr-controller
  abrMaxWithRealBitrate: !1,
  // used by abr-controller
  maxStarvationDelay: 4,
  // used by abr-controller
  maxLoadingDelay: 4,
  // used by abr-controller
  minAutoBitrate: 0,
  // used by hls
  emeEnabled: !1,
  // used by eme-controller
  widevineLicenseUrl: void 0,
  // used by eme-controller
  drmSystems: {},
  // used by eme-controller
  drmSystemOptions: {},
  // used by eme-controller
  requestMediaKeySystemAccessFunc: Rr,
  // used by eme-controller
  testBandwidth: !0,
  progressive: !1,
  lowLatencyMode: !0,
  cmcd: void 0,
  enableDateRangeMetadataCues: !0,
  enableEmsgMetadataCues: !0,
  enableID3MetadataCues: !0,
  useMediaCapabilities: !0,
  certLoadPolicy: {
    default: Th
  },
  keyLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 8e3,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 1,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 2e4,
        backoff: "linear"
      },
      errorRetry: {
        maxNumRetry: 8,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 2e4,
        backoff: "linear"
      }
    }
  },
  manifestLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1 / 0,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 2,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 1,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  playlistLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1e4,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 2,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 2,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  fragLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1e4,
      maxLoadTimeMs: 12e4,
      timeoutRetry: {
        maxNumRetry: 4,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 6,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  steeringManifestLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1e4,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 2,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 1,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  // These default settings are deprecated in favor of the above policies
  // and are maintained for backwards compatibility
  manifestLoadingTimeOut: 1e4,
  manifestLoadingMaxRetry: 1,
  manifestLoadingRetryDelay: 1e3,
  manifestLoadingMaxRetryTimeout: 64e3,
  levelLoadingTimeOut: 1e4,
  levelLoadingMaxRetry: 4,
  levelLoadingRetryDelay: 1e3,
  levelLoadingMaxRetryTimeout: 64e3,
  fragLoadingTimeOut: 2e4,
  fragLoadingMaxRetry: 6,
  fragLoadingRetryDelay: 1e3,
  fragLoadingMaxRetryTimeout: 64e3
}, yh()), {}, {
  subtitleStreamController: Wl,
  subtitleTrackController: ql,
  timelineController: Sc,
  audioStreamController: Vl,
  audioTrackController: Hl,
  emeController: Qe,
  cmcdController: nh,
  contentSteeringController: oh
});
function yh() {
  return {
    cueHandler: Eh,
    // used by timeline-controller
    enableWebVTT: !0,
    // used by timeline-controller
    enableIMSC1: !0,
    // used by timeline-controller
    enableCEA708Captions: !0,
    // used by timeline-controller
    captionsTextTrack1Label: "English",
    // used by timeline-controller
    captionsTextTrack1LanguageCode: "en",
    // used by timeline-controller
    captionsTextTrack2Label: "Spanish",
    // used by timeline-controller
    captionsTextTrack2LanguageCode: "es",
    // used by timeline-controller
    captionsTextTrack3Label: "Unknown CC",
    // used by timeline-controller
    captionsTextTrack3LanguageCode: "",
    // used by timeline-controller
    captionsTextTrack4Label: "Unknown CC",
    // used by timeline-controller
    captionsTextTrack4LanguageCode: "",
    // used by timeline-controller
    renderTextTracksNatively: !0
  };
}
function xh(n, e) {
  if ((e.liveSyncDurationCount || e.liveMaxLatencyDurationCount) && (e.liveSyncDuration || e.liveMaxLatencyDuration))
    throw new Error("Illegal hls.js config: don't mix up liveSyncDurationCount/liveMaxLatencyDurationCount and liveSyncDuration/liveMaxLatencyDuration");
  if (e.liveMaxLatencyDurationCount !== void 0 && (e.liveSyncDurationCount === void 0 || e.liveMaxLatencyDurationCount <= e.liveSyncDurationCount))
    throw new Error('Illegal hls.js config: "liveMaxLatencyDurationCount" must be greater than "liveSyncDurationCount"');
  if (e.liveMaxLatencyDuration !== void 0 && (e.liveSyncDuration === void 0 || e.liveMaxLatencyDuration <= e.liveSyncDuration))
    throw new Error('Illegal hls.js config: "liveMaxLatencyDuration" must be greater than "liveSyncDuration"');
  const t = ws(n), s = ["manifest", "level", "frag"], i = ["TimeOut", "MaxRetry", "RetryDelay", "MaxRetryTimeout"];
  return s.forEach((r) => {
    const a = `${r === "level" ? "playlist" : r}LoadPolicy`, o = e[a] === void 0, l = [];
    i.forEach((c) => {
      const h = `${r}Loading${c}`, u = e[h];
      if (u !== void 0 && o) {
        l.push(h);
        const d = t[a].default;
        switch (e[a] = {
          default: d
        }, c) {
          case "TimeOut":
            d.maxLoadTimeMs = u, d.maxTimeToFirstByteMs = u;
            break;
          case "MaxRetry":
            d.errorRetry.maxNumRetry = u, d.timeoutRetry.maxNumRetry = u;
            break;
          case "RetryDelay":
            d.errorRetry.retryDelayMs = u, d.timeoutRetry.retryDelayMs = u;
            break;
          case "MaxRetryTimeout":
            d.errorRetry.maxRetryDelayMs = u, d.timeoutRetry.maxRetryDelayMs = u;
            break;
        }
      }
    }), l.length && v.warn(`hls.js config: "${l.join('", "')}" setting(s) are deprecated, use "${a}": ${JSON.stringify(e[a])}`);
  }), oe(oe({}, t), e);
}
function ws(n) {
  return n && typeof n == "object" ? Array.isArray(n) ? n.map(ws) : Object.keys(n).reduce((e, t) => (e[t] = ws(n[t]), e), {}) : n;
}
function Sh(n) {
  const e = n.loader;
  e !== lr && e !== In ? (v.log("[config]: Custom loader detected, cannot enable progressive streaming"), n.progressive = !1) : ch() && (n.loader = lr, n.progressive = !0, n.enableSoftwareAES = !0, v.log("[config]: Progressive streaming enabled, using FetchLoader"));
}
let fs;
class vh extends Ks {
  constructor(e, t) {
    super(e, "[level-controller]"), this._levels = [], this._firstLevel = -1, this._maxAutoLevel = -1, this._startLevel = void 0, this.currentLevel = null, this.currentLevelIndex = -1, this.manualLevelIndex = -1, this.steering = void 0, this.onParsedComplete = void 0, this.steering = t, this._registerListeners();
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.MANIFEST_LOADED, this.onManifestLoaded, this), e.on(p.LEVEL_LOADED, this.onLevelLoaded, this), e.on(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(p.FRAG_BUFFERED, this.onFragBuffered, this), e.on(p.ERROR, this.onError, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.MANIFEST_LOADED, this.onManifestLoaded, this), e.off(p.LEVEL_LOADED, this.onLevelLoaded, this), e.off(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(p.FRAG_BUFFERED, this.onFragBuffered, this), e.off(p.ERROR, this.onError, this);
  }
  destroy() {
    this._unregisterListeners(), this.steering = null, this.resetLevels(), super.destroy();
  }
  stopLoad() {
    this._levels.forEach((t) => {
      t.loadError = 0, t.fragmentError = 0;
    }), super.stopLoad();
  }
  resetLevels() {
    this._startLevel = void 0, this.manualLevelIndex = -1, this.currentLevelIndex = -1, this.currentLevel = null, this._levels = [], this._maxAutoLevel = -1;
  }
  onManifestLoading(e, t) {
    this.resetLevels();
  }
  onManifestLoaded(e, t) {
    const s = this.hls.config.preferManagedMediaSource, i = [], r = {}, a = {};
    let o = !1, l = !1, c = !1;
    t.levels.forEach((h) => {
      var u, d;
      const f = h.attrs;
      let {
        audioCodec: g,
        videoCodec: m
      } = h;
      ((u = g) == null ? void 0 : u.indexOf("mp4a.40.34")) !== -1 && (fs || (fs = /chrome|firefox/i.test(navigator.userAgent)), fs && (h.audioCodec = g = void 0)), g && (h.audioCodec = g = Ft(g, s)), ((d = m) == null ? void 0 : d.indexOf("avc1")) === 0 && (m = h.videoCodec = oo(m));
      const {
        width: E,
        height: T,
        unknownCodecs: y
      } = h;
      if (o || (o = !!(E && T)), l || (l = !!m), c || (c = !!g), y != null && y.length || g && !Jt(g, "audio", s) || m && !Jt(m, "video", s))
        return;
      const {
        CODECS: x,
        "FRAME-RATE": b,
        "HDCP-LEVEL": S,
        "PATHWAY-ID": D,
        RESOLUTION: R,
        "VIDEO-RANGE": _
      } = f, I = `${`${D || "."}-`}${h.bitrate}-${R}-${b}-${x}-${_}-${S}`;
      if (r[I])
        if (r[I].uri !== h.url && !h.attrs["PATHWAY-ID"]) {
          const k = a[I] += 1;
          h.attrs["PATHWAY-ID"] = new Array(k + 1).join(".");
          const V = new Ze(h);
          r[I] = V, i.push(V);
        } else
          r[I].addGroupId("audio", f.AUDIO), r[I].addGroupId("text", f.SUBTITLES);
      else {
        const k = new Ze(h);
        r[I] = k, a[I] = 1, i.push(k);
      }
    }), this.filterAndSortMediaOptions(i, t, o, l, c);
  }
  filterAndSortMediaOptions(e, t, s, i, r) {
    let a = [], o = [], l = e;
    if ((s || i) && r && (l = l.filter(({
      videoCodec: g,
      videoRange: m,
      width: E,
      height: T
    }) => (!!g || !!(E && T)) && So(m))), l.length === 0) {
      Promise.resolve().then(() => {
        if (this.hls) {
          t.levels.length && this.warn(`One or more CODECS in variant not supported: ${JSON.stringify(t.levels[0].attrs)}`);
          const g = new Error("no level with compatible codecs found in manifest");
          this.hls.trigger(p.ERROR, {
            type: K.MEDIA_ERROR,
            details: L.MANIFEST_INCOMPATIBLE_CODECS_ERROR,
            fatal: !0,
            url: t.url,
            error: g,
            reason: g.message
          });
        }
      });
      return;
    }
    if (t.audioTracks) {
      const {
        preferManagedMediaSource: g
      } = this.hls.config;
      a = t.audioTracks.filter((m) => !m.audioCodec || Jt(m.audioCodec, "audio", g)), cr(a);
    }
    t.subtitles && (o = t.subtitles, cr(o));
    const c = l.slice(0);
    l.sort((g, m) => {
      if (g.attrs["HDCP-LEVEL"] !== m.attrs["HDCP-LEVEL"])
        return (g.attrs["HDCP-LEVEL"] || "") > (m.attrs["HDCP-LEVEL"] || "") ? 1 : -1;
      if (s && g.height !== m.height)
        return g.height - m.height;
      if (g.frameRate !== m.frameRate)
        return g.frameRate - m.frameRate;
      if (g.videoRange !== m.videoRange)
        return Ot.indexOf(g.videoRange) - Ot.indexOf(m.videoRange);
      if (g.videoCodec !== m.videoCodec) {
        const E = pi(g.videoCodec), T = pi(m.videoCodec);
        if (E !== T)
          return T - E;
      }
      if (g.uri === m.uri && g.codecSet !== m.codecSet) {
        const E = Pt(g.codecSet), T = Pt(m.codecSet);
        if (E !== T)
          return T - E;
      }
      return g.averageBitrate !== m.averageBitrate ? g.averageBitrate - m.averageBitrate : 0;
    });
    let h = c[0];
    if (this.steering && (l = this.steering.filterParsedLevels(l), l.length !== c.length)) {
      for (let g = 0; g < c.length; g++)
        if (c[g].pathwayId === l[0].pathwayId) {
          h = c[g];
          break;
        }
    }
    this._levels = l;
    for (let g = 0; g < l.length; g++)
      if (l[g] === h) {
        var u;
        this._firstLevel = g;
        const m = h.bitrate, E = this.hls.bandwidthEstimate;
        if (this.log(`manifest loaded, ${l.length} level(s) found, first bitrate: ${m}`), ((u = this.hls.userConfig) == null ? void 0 : u.abrEwmaDefaultEstimate) === void 0) {
          const T = Math.min(m, this.hls.config.abrEwmaDefaultEstimateMax);
          T > E && E === Dn.abrEwmaDefaultEstimate && (this.hls.bandwidthEstimate = T);
        }
        break;
      }
    const d = r && !i, f = {
      levels: l,
      audioTracks: a,
      subtitleTracks: o,
      sessionData: t.sessionData,
      sessionKeys: t.sessionKeys,
      firstLevel: this._firstLevel,
      stats: t.stats,
      audio: r,
      video: i,
      altAudio: !d && a.some((g) => !!g.url)
    };
    this.hls.trigger(p.MANIFEST_PARSED, f), (this.hls.config.autoStartLoad || this.hls.forceStartLoad) && this.hls.startLoad(this.hls.config.startPosition);
  }
  get levels() {
    return this._levels.length === 0 ? null : this._levels;
  }
  get level() {
    return this.currentLevelIndex;
  }
  set level(e) {
    const t = this._levels;
    if (t.length === 0)
      return;
    if (e < 0 || e >= t.length) {
      const h = new Error("invalid level idx"), u = e < 0;
      if (this.hls.trigger(p.ERROR, {
        type: K.OTHER_ERROR,
        details: L.LEVEL_SWITCH_ERROR,
        level: e,
        fatal: u,
        error: h,
        reason: h.message
      }), u)
        return;
      e = Math.min(e, t.length - 1);
    }
    const s = this.currentLevelIndex, i = this.currentLevel, r = i ? i.attrs["PATHWAY-ID"] : void 0, a = t[e], o = a.attrs["PATHWAY-ID"];
    if (this.currentLevelIndex = e, this.currentLevel = a, s === e && a.details && i && r === o)
      return;
    this.log(`Switching to level ${e} (${a.height ? a.height + "p " : ""}${a.videoRange ? a.videoRange + " " : ""}${a.codecSet ? a.codecSet + " " : ""}@${a.bitrate})${o ? " with Pathway " + o : ""} from level ${s}${r ? " with Pathway " + r : ""}`);
    const l = {
      level: e,
      attrs: a.attrs,
      details: a.details,
      bitrate: a.bitrate,
      averageBitrate: a.averageBitrate,
      maxBitrate: a.maxBitrate,
      realBitrate: a.realBitrate,
      width: a.width,
      height: a.height,
      codecSet: a.codecSet,
      audioCodec: a.audioCodec,
      videoCodec: a.videoCodec,
      audioGroups: a.audioGroups,
      subtitleGroups: a.subtitleGroups,
      loaded: a.loaded,
      loadError: a.loadError,
      fragmentError: a.fragmentError,
      name: a.name,
      id: a.id,
      uri: a.uri,
      url: a.url,
      urlId: 0,
      audioGroupIds: a.audioGroupIds,
      textGroupIds: a.textGroupIds
    };
    this.hls.trigger(p.LEVEL_SWITCHING, l);
    const c = a.details;
    if (!c || c.live) {
      const h = this.switchParams(a.uri, i == null ? void 0 : i.details, c);
      this.loadPlaylist(h);
    }
  }
  get manualLevel() {
    return this.manualLevelIndex;
  }
  set manualLevel(e) {
    this.manualLevelIndex = e, this._startLevel === void 0 && (this._startLevel = e), e !== -1 && (this.level = e);
  }
  get firstLevel() {
    return this._firstLevel;
  }
  set firstLevel(e) {
    this._firstLevel = e;
  }
  get startLevel() {
    if (this._startLevel === void 0) {
      const e = this.hls.config.startLevel;
      return e !== void 0 ? e : this.hls.firstAutoLevel;
    }
    return this._startLevel;
  }
  set startLevel(e) {
    this._startLevel = e;
  }
  onError(e, t) {
    t.fatal || !t.context || t.context.type === q.LEVEL && t.context.level === this.level && this.checkRetry(t);
  }
  // reset errors on the successful load of a fragment
  onFragBuffered(e, {
    frag: t
  }) {
    if (t !== void 0 && t.type === G.MAIN) {
      const s = t.elementaryStreams;
      if (!Object.keys(s).some((r) => !!s[r]))
        return;
      const i = this._levels[t.level];
      i != null && i.loadError && (this.log(`Resetting level error count of ${i.loadError} on frag buffered`), i.loadError = 0);
    }
  }
  onLevelLoaded(e, t) {
    var s;
    const {
      level: i,
      details: r
    } = t, a = this._levels[i];
    if (!a) {
      var o;
      this.warn(`Invalid level index ${i}`), (o = t.deliveryDirectives) != null && o.skip && (r.deltaUpdateFailed = !0);
      return;
    }
    i === this.currentLevelIndex ? (a.fragmentError === 0 && (a.loadError = 0), this.playlistLoaded(i, t, a.details)) : (s = t.deliveryDirectives) != null && s.skip && (r.deltaUpdateFailed = !0);
  }
  loadPlaylist(e) {
    super.loadPlaylist();
    const t = this.currentLevelIndex, s = this.currentLevel;
    if (s && this.shouldLoadPlaylist(s)) {
      let i = s.uri;
      if (e)
        try {
          i = e.addDirectives(i);
        } catch (a) {
          this.warn(`Could not construct new URL with HLS Delivery Directives: ${a}`);
        }
      const r = s.attrs["PATHWAY-ID"];
      this.log(`Loading level index ${t}${(e == null ? void 0 : e.msn) !== void 0 ? " at sn " + e.msn + " part " + e.part : ""} with${r ? " Pathway " + r : ""} ${i}`), this.clearTimer(), this.hls.trigger(p.LEVEL_LOADING, {
        url: i,
        level: t,
        pathwayId: s.attrs["PATHWAY-ID"],
        id: 0,
        // Deprecated Level urlId
        deliveryDirectives: e || null
      });
    }
  }
  get nextLoadLevel() {
    return this.manualLevelIndex !== -1 ? this.manualLevelIndex : this.hls.nextAutoLevel;
  }
  set nextLoadLevel(e) {
    this.level = e, this.manualLevelIndex === -1 && (this.hls.nextAutoLevel = e);
  }
  removeLevel(e) {
    var t;
    const s = this._levels.filter((i, r) => r !== e ? !0 : (this.steering && this.steering.removeLevel(i), i === this.currentLevel && (this.currentLevel = null, this.currentLevelIndex = -1, i.details && i.details.fragments.forEach((a) => a.level = -1)), !1));
    Vr(s), this._levels = s, this.currentLevelIndex > -1 && (t = this.currentLevel) != null && t.details && (this.currentLevelIndex = this.currentLevel.details.fragments[0].level), this.hls.trigger(p.LEVELS_UPDATED, {
      levels: s
    });
  }
  onLevelsUpdated(e, {
    levels: t
  }) {
    this._levels = t;
  }
  checkMaxAutoUpdated() {
    const {
      autoLevelCapping: e,
      maxAutoLevel: t,
      maxHdcpLevel: s
    } = this.hls;
    this._maxAutoLevel !== t && (this._maxAutoLevel = t, this.hls.trigger(p.MAX_AUTO_LEVEL_UPDATED, {
      autoLevelCapping: e,
      levels: this.levels,
      maxAutoLevel: t,
      minAutoLevel: this.hls.minAutoLevel,
      maxHdcpLevel: s
    }));
  }
}
function cr(n) {
  const e = {};
  n.forEach((t) => {
    const s = t.groupId || "";
    t.id = e[s] = e[s] || 0, e[s]++;
  });
}
class Ah {
  constructor(e) {
    this.config = void 0, this.keyUriToKeyInfo = {}, this.emeController = null, this.config = e;
  }
  abort(e) {
    for (const s in this.keyUriToKeyInfo) {
      const i = this.keyUriToKeyInfo[s].loader;
      if (i) {
        var t;
        if (e && e !== ((t = i.context) == null ? void 0 : t.frag.type))
          return;
        i.abort();
      }
    }
  }
  detach() {
    for (const e in this.keyUriToKeyInfo) {
      const t = this.keyUriToKeyInfo[e];
      (t.mediaKeySessionContext || t.decryptdata.isCommonEncryption) && delete this.keyUriToKeyInfo[e];
    }
  }
  destroy() {
    this.detach();
    for (const e in this.keyUriToKeyInfo) {
      const t = this.keyUriToKeyInfo[e].loader;
      t && t.destroy();
    }
    this.keyUriToKeyInfo = {};
  }
  createKeyLoadError(e, t = L.KEY_LOAD_ERROR, s, i, r) {
    return new ke({
      type: K.NETWORK_ERROR,
      details: t,
      fatal: !1,
      frag: e,
      response: r,
      error: s,
      networkDetails: i
    });
  }
  loadClear(e, t) {
    if (this.emeController && this.config.emeEnabled) {
      const {
        sn: s,
        cc: i
      } = e;
      for (let r = 0; r < t.length; r++) {
        const a = t[r];
        if (i <= a.cc && (s === "initSegment" || a.sn === "initSegment" || s < a.sn)) {
          this.emeController.selectKeySystemFormat(a).then((o) => {
            a.setKeyFormat(o);
          });
          break;
        }
      }
    }
  }
  load(e) {
    return !e.decryptdata && e.encrypted && this.emeController ? this.emeController.selectKeySystemFormat(e).then((t) => this.loadInternal(e, t)) : this.loadInternal(e);
  }
  loadInternal(e, t) {
    var s, i;
    t && e.setKeyFormat(t);
    const r = e.decryptdata;
    if (!r) {
      const c = new Error(t ? `Expected frag.decryptdata to be defined after setting format ${t}` : "Missing decryption data on fragment in onKeyLoading");
      return Promise.reject(this.createKeyLoadError(e, L.KEY_LOAD_ERROR, c));
    }
    const a = r.uri;
    if (!a)
      return Promise.reject(this.createKeyLoadError(e, L.KEY_LOAD_ERROR, new Error(`Invalid key URI: "${a}"`)));
    let o = this.keyUriToKeyInfo[a];
    if ((s = o) != null && s.decryptdata.key)
      return r.key = o.decryptdata.key, Promise.resolve({
        frag: e,
        keyInfo: o
      });
    if ((i = o) != null && i.keyLoadPromise) {
      var l;
      switch ((l = o.mediaKeySessionContext) == null ? void 0 : l.keyStatus) {
        case void 0:
        case "status-pending":
        case "usable":
        case "usable-in-future":
          return o.keyLoadPromise.then((c) => (r.key = c.keyInfo.decryptdata.key, {
            frag: e,
            keyInfo: o
          }));
      }
    }
    switch (o = this.keyUriToKeyInfo[a] = {
      decryptdata: r,
      keyLoadPromise: null,
      loader: null,
      mediaKeySessionContext: null
    }, r.method) {
      case "ISO-23001-7":
      case "SAMPLE-AES":
      case "SAMPLE-AES-CENC":
      case "SAMPLE-AES-CTR":
        return r.keyFormat === "identity" ? this.loadKeyHTTP(o, e) : this.loadKeyEME(o, e);
      case "AES-128":
        return this.loadKeyHTTP(o, e);
      default:
        return Promise.reject(this.createKeyLoadError(e, L.KEY_LOAD_ERROR, new Error(`Key supplied with unsupported METHOD: "${r.method}"`)));
    }
  }
  loadKeyEME(e, t) {
    const s = {
      frag: t,
      keyInfo: e
    };
    if (this.emeController && this.config.emeEnabled) {
      const i = this.emeController.loadKey(s);
      if (i)
        return (e.keyLoadPromise = i.then((r) => (e.mediaKeySessionContext = r, s))).catch((r) => {
          throw e.keyLoadPromise = null, r;
        });
    }
    return Promise.resolve(s);
  }
  loadKeyHTTP(e, t) {
    const s = this.config, i = s.loader, r = new i(s);
    return t.keyLoader = e.loader = r, e.keyLoadPromise = new Promise((a, o) => {
      const l = {
        keyInfo: e,
        frag: t,
        responseType: "arraybuffer",
        url: e.decryptdata.uri
      }, c = s.keyLoadPolicy.default, h = {
        loadPolicy: c,
        timeout: c.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0
      }, u = {
        onSuccess: (d, f, g, m) => {
          const {
            frag: E,
            keyInfo: T,
            url: y
          } = g;
          if (!E.decryptdata || T !== this.keyUriToKeyInfo[y])
            return o(this.createKeyLoadError(E, L.KEY_LOAD_ERROR, new Error("after key load, decryptdata unset or changed"), m));
          T.decryptdata.key = E.decryptdata.key = new Uint8Array(d.data), E.keyLoader = null, T.loader = null, a({
            frag: E,
            keyInfo: T
          });
        },
        onError: (d, f, g, m) => {
          this.resetLoader(f), o(this.createKeyLoadError(t, L.KEY_LOAD_ERROR, new Error(`HTTP Error ${d.code} loading key ${d.text}`), g, oe({
            url: l.url,
            data: void 0
          }, d)));
        },
        onTimeout: (d, f, g) => {
          this.resetLoader(f), o(this.createKeyLoadError(t, L.KEY_LOAD_TIMEOUT, new Error("key loading timed out"), g));
        },
        onAbort: (d, f, g) => {
          this.resetLoader(f), o(this.createKeyLoadError(t, L.INTERNAL_ABORTED, new Error("key loading aborted"), g));
        }
      };
      r.load(l, h, u);
    });
  }
  resetLoader(e) {
    const {
      frag: t,
      keyInfo: s,
      url: i
    } = e, r = s.loader;
    t.keyLoader === r && (t.keyLoader = null, s.loader = null), delete this.keyUriToKeyInfo[i], r && r.destroy();
  }
}
function Cn() {
  return self.SourceBuffer || self.WebKitSourceBuffer;
}
function _n() {
  if (!Ve())
    return !1;
  const e = Cn();
  return !e || e.prototype && typeof e.prototype.appendBuffer == "function" && typeof e.prototype.remove == "function";
}
function Lh() {
  if (!_n())
    return !1;
  const n = Ve();
  return typeof (n == null ? void 0 : n.isTypeSupported) == "function" && (["avc1.42E01E,mp4a.40.2", "av01.0.01M.08", "vp09.00.50.08"].some((e) => n.isTypeSupported(ct(e, "video"))) || ["mp4a.40.2", "fLaC"].some((e) => n.isTypeSupported(ct(e, "audio"))));
}
function Rh() {
  var n;
  const e = Cn();
  return typeof (e == null || (n = e.prototype) == null ? void 0 : n.changeType) == "function";
}
const bh = 250, _t = 2, Ih = 0.1, Dh = 0.05;
class Ch {
  constructor(e, t, s, i) {
    this.config = void 0, this.media = null, this.fragmentTracker = void 0, this.hls = void 0, this.nudgeRetry = 0, this.stallReported = !1, this.stalled = null, this.moved = !1, this.seeking = !1, this.config = e, this.media = t, this.fragmentTracker = s, this.hls = i;
  }
  destroy() {
    this.media = null, this.hls = this.fragmentTracker = null;
  }
  /**
   * Checks if the playhead is stuck within a gap, and if so, attempts to free it.
   * A gap is an unbuffered range between two buffered ranges (or the start and the first buffered range).
   *
   * @param lastCurrentTime - Previously read playhead position
   */
  poll(e, t) {
    const {
      config: s,
      media: i,
      stalled: r
    } = this;
    if (i === null)
      return;
    const {
      currentTime: a,
      seeking: o
    } = i, l = this.seeking && !o, c = !this.seeking && o;
    if (this.seeking = o, a !== e) {
      if (this.moved = !0, o || (this.nudgeRetry = 0), r !== null) {
        if (this.stallReported) {
          const E = self.performance.now() - r;
          v.warn(`playback not stuck anymore @${a}, after ${Math.round(E)}ms`), this.stallReported = !1;
        }
        this.stalled = null;
      }
      return;
    }
    if (c || l) {
      this.stalled = null;
      return;
    }
    if (i.paused && !o || i.ended || i.playbackRate === 0 || !J.getBuffered(i).length) {
      this.nudgeRetry = 0;
      return;
    }
    const h = J.bufferInfo(i, a, 0), u = h.nextStart || 0;
    if (o) {
      const E = h.len > _t, T = !u || t && t.start <= a || u - a > _t && !this.fragmentTracker.getPartialFragment(a);
      if (E || T)
        return;
      this.moved = !1;
    }
    if (!this.moved && this.stalled !== null) {
      var d;
      if (!(h.len > 0) && !u)
        return;
      const T = Math.max(u, h.start || 0) - a, y = this.hls.levels ? this.hls.levels[this.hls.currentLevel] : null, b = (y == null || (d = y.details) == null ? void 0 : d.live) ? y.details.targetduration * 2 : _t, S = this.fragmentTracker.getPartialFragment(a);
      if (T > 0 && (T <= b || S)) {
        i.paused || this._trySkipBufferHole(S);
        return;
      }
    }
    const f = self.performance.now();
    if (r === null) {
      this.stalled = f;
      return;
    }
    const g = f - r;
    if (!o && g >= bh && (this._reportStall(h), !this.media))
      return;
    const m = J.bufferInfo(i, a, s.maxBufferHole);
    this._tryFixBufferStall(m, g);
  }
  /**
   * Detects and attempts to fix known buffer stalling issues.
   * @param bufferInfo - The properties of the current buffer.
   * @param stalledDurationMs - The amount of time Hls.js has been stalling for.
   * @private
   */
  _tryFixBufferStall(e, t) {
    const {
      config: s,
      fragmentTracker: i,
      media: r
    } = this;
    if (r === null)
      return;
    const a = r.currentTime, o = i.getPartialFragment(a);
    o && (this._trySkipBufferHole(o) || !this.media) || (e.len > s.maxBufferHole || e.nextStart && e.nextStart - a < s.maxBufferHole) && t > s.highBufferWatchdogPeriod * 1e3 && (v.warn("Trying to nudge playhead over buffer-hole"), this.stalled = null, this._tryNudgeBuffer());
  }
  /**
   * Triggers a BUFFER_STALLED_ERROR event, but only once per stall period.
   * @param bufferLen - The playhead distance from the end of the current buffer segment.
   * @private
   */
  _reportStall(e) {
    const {
      hls: t,
      media: s,
      stallReported: i
    } = this;
    if (!i && s) {
      this.stallReported = !0;
      const r = new Error(`Playback stalling at @${s.currentTime} due to low buffer (${JSON.stringify(e)})`);
      v.warn(r.message), t.trigger(p.ERROR, {
        type: K.MEDIA_ERROR,
        details: L.BUFFER_STALLED_ERROR,
        fatal: !1,
        error: r,
        buffer: e.len
      });
    }
  }
  /**
   * Attempts to fix buffer stalls by jumping over known gaps caused by partial fragments
   * @param partial - The partial fragment found at the current time (where playback is stalling).
   * @private
   */
  _trySkipBufferHole(e) {
    const {
      config: t,
      hls: s,
      media: i
    } = this;
    if (i === null)
      return 0;
    const r = i.currentTime, a = J.bufferInfo(i, r, 0), o = r < a.start ? a.start : a.nextStart;
    if (o) {
      const l = a.len <= t.maxBufferHole, c = a.len > 0 && a.len < 1 && i.readyState < 3, h = o - r;
      if (h > 0 && (l || c)) {
        if (h > t.maxBufferHole) {
          const {
            fragmentTracker: d
          } = this;
          let f = !1;
          if (r === 0) {
            const g = d.getAppendedFrag(0, G.MAIN);
            g && o < g.end && (f = !0);
          }
          if (!f) {
            const g = e || d.getAppendedFrag(r, G.MAIN);
            if (g) {
              let m = !1, E = g.end;
              for (; E < o; ) {
                const T = d.getPartialFragment(E);
                if (T)
                  E += T.duration;
                else {
                  m = !0;
                  break;
                }
              }
              if (m)
                return 0;
            }
          }
        }
        const u = Math.max(o + Dh, r + Ih);
        if (v.warn(`skipping hole, adjusting currentTime from ${r} to ${u}`), this.moved = !0, this.stalled = null, i.currentTime = u, e && !e.gap) {
          const d = new Error(`fragment loaded with buffer holes, seeking from ${r} to ${u}`);
          s.trigger(p.ERROR, {
            type: K.MEDIA_ERROR,
            details: L.BUFFER_SEEK_OVER_HOLE,
            fatal: !1,
            error: d,
            reason: d.message,
            frag: e
          });
        }
        return u;
      }
    }
    return 0;
  }
  /**
   * Attempts to fix buffer stalls by advancing the mediaElement's current time by a small amount.
   * @private
   */
  _tryNudgeBuffer() {
    const {
      config: e,
      hls: t,
      media: s,
      nudgeRetry: i
    } = this;
    if (s === null)
      return;
    const r = s.currentTime;
    if (this.nudgeRetry++, i < e.nudgeMaxRetry) {
      const a = r + (i + 1) * e.nudgeOffset, o = new Error(`Nudging 'currentTime' from ${r} to ${a}`);
      v.warn(o.message), s.currentTime = a, t.trigger(p.ERROR, {
        type: K.MEDIA_ERROR,
        details: L.BUFFER_NUDGE_ON_STALL,
        error: o,
        fatal: !1
      });
    } else {
      const a = new Error(`Playhead still not moving while enough data buffered @${r} after ${e.nudgeMaxRetry} nudges`);
      v.error(a.message), t.trigger(p.ERROR, {
        type: K.MEDIA_ERROR,
        details: L.BUFFER_STALLED_ERROR,
        error: a,
        fatal: !0
      });
    }
  }
}
const _h = 100;
class kh extends Ws {
  constructor(e, t, s) {
    super(e, t, s, "[stream-controller]", G.MAIN), this.audioCodecSwap = !1, this.gapController = null, this.level = -1, this._forceStartLoad = !1, this.altAudio = !1, this.audioOnly = !1, this.fragPlaying = null, this.onvplaying = null, this.onvseeked = null, this.fragLastKbps = 0, this.couldBacktrack = !1, this.backtrackFragment = null, this.audioCodecSwitch = !1, this.videoBuffer = null, this._registerListeners();
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(p.MANIFEST_LOADING, this.onManifestLoading, this), e.on(p.MANIFEST_PARSED, this.onManifestParsed, this), e.on(p.LEVEL_LOADING, this.onLevelLoading, this), e.on(p.LEVEL_LOADED, this.onLevelLoaded, this), e.on(p.FRAG_LOAD_EMERGENCY_ABORTED, this.onFragLoadEmergencyAborted, this), e.on(p.ERROR, this.onError, this), e.on(p.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.on(p.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), e.on(p.BUFFER_CREATED, this.onBufferCreated, this), e.on(p.BUFFER_FLUSHED, this.onBufferFlushed, this), e.on(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(p.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(p.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(p.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(p.MANIFEST_LOADING, this.onManifestLoading, this), e.off(p.MANIFEST_PARSED, this.onManifestParsed, this), e.off(p.LEVEL_LOADED, this.onLevelLoaded, this), e.off(p.FRAG_LOAD_EMERGENCY_ABORTED, this.onFragLoadEmergencyAborted, this), e.off(p.ERROR, this.onError, this), e.off(p.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.off(p.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), e.off(p.BUFFER_CREATED, this.onBufferCreated, this), e.off(p.BUFFER_FLUSHED, this.onBufferFlushed, this), e.off(p.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(p.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  onHandlerDestroying() {
    this._unregisterListeners(), super.onHandlerDestroying();
  }
  startLoad(e) {
    if (this.levels) {
      const {
        lastCurrentTime: t,
        hls: s
      } = this;
      if (this.stopLoad(), this.setInterval(_h), this.level = -1, !this.startFragRequested) {
        let i = s.startLevel;
        i === -1 && (s.config.testBandwidth && this.levels.length > 1 ? (i = 0, this.bitrateTest = !0) : i = s.firstAutoLevel), s.nextLoadLevel = i, this.level = s.loadLevel, this.loadedmetadata = !1;
      }
      t > 0 && e === -1 && (this.log(`Override startPosition with lastCurrentTime @${t.toFixed(3)}`), e = t), this.state = C.IDLE, this.nextLoadPosition = this.startPosition = this.lastCurrentTime = e, this.tick();
    } else
      this._forceStartLoad = !0, this.state = C.STOPPED;
  }
  stopLoad() {
    this._forceStartLoad = !1, super.stopLoad();
  }
  doTick() {
    switch (this.state) {
      case C.WAITING_LEVEL: {
        const {
          levels: t,
          level: s
        } = this, i = t == null ? void 0 : t[s], r = i == null ? void 0 : i.details;
        if (r && (!r.live || this.levelLastLoaded === i)) {
          if (this.waitForCdnTuneIn(r))
            break;
          this.state = C.IDLE;
          break;
        } else if (this.hls.nextLoadLevel !== this.level) {
          this.state = C.IDLE;
          break;
        }
        break;
      }
      case C.FRAG_LOADING_WAITING_RETRY:
        {
          var e;
          const t = self.performance.now(), s = this.retryDate;
          if (!s || t >= s || (e = this.media) != null && e.seeking) {
            const {
              levels: i,
              level: r
            } = this, a = i == null ? void 0 : i[r];
            this.resetStartWhenNotLoaded(a || null), this.state = C.IDLE;
          }
        }
        break;
    }
    this.state === C.IDLE && this.doTickIdle(), this.onTickEnd();
  }
  onTickEnd() {
    super.onTickEnd(), this.checkBuffer(), this.checkFragmentChanged();
  }
  doTickIdle() {
    const {
      hls: e,
      levelLastLoaded: t,
      levels: s,
      media: i
    } = this;
    if (t === null || !i && (this.startFragRequested || !e.config.startFragPrefetch) || this.altAudio && this.audioOnly)
      return;
    const r = e.nextLoadLevel;
    if (!(s != null && s[r]))
      return;
    const a = s[r], o = this.getMainFwdBufferInfo();
    if (o === null)
      return;
    const l = this.getLevelDetails();
    if (l && this._streamEnded(o, l)) {
      const m = {};
      this.altAudio && (m.type = "video"), this.hls.trigger(p.BUFFER_EOS, m), this.state = C.ENDED;
      return;
    }
    e.loadLevel !== r && e.manualLevel === -1 && this.log(`Adapting to level ${r} from level ${this.level}`), this.level = e.nextLoadLevel = r;
    const c = a.details;
    if (!c || this.state === C.WAITING_LEVEL || c.live && this.levelLastLoaded !== a) {
      this.level = r, this.state = C.WAITING_LEVEL;
      return;
    }
    const h = o.len, u = this.getMaxBufferLength(a.maxBitrate);
    if (h >= u)
      return;
    this.backtrackFragment && this.backtrackFragment.start > o.end && (this.backtrackFragment = null);
    const d = this.backtrackFragment ? this.backtrackFragment.start : o.end;
    let f = this.getNextFragment(d, c);
    if (this.couldBacktrack && !this.fragPrevious && f && f.sn !== "initSegment" && this.fragmentTracker.getState(f) !== ae.OK) {
      var g;
      const E = ((g = this.backtrackFragment) != null ? g : f).sn - c.startSN, T = c.fragments[E - 1];
      T && f.cc === T.cc && (f = T, this.fragmentTracker.removeFragment(T));
    } else this.backtrackFragment && o.len && (this.backtrackFragment = null);
    if (f && this.isLoopLoading(f, d)) {
      if (!f.gap) {
        const E = this.audioOnly && !this.altAudio ? Q.AUDIO : Q.VIDEO, T = (E === Q.VIDEO ? this.videoBuffer : this.mediaBuffer) || this.media;
        T && this.afterBufferFlushed(T, E, G.MAIN);
      }
      f = this.getNextFragmentLoopLoading(f, c, o, G.MAIN, u);
    }
    f && (f.initSegment && !f.initSegment.data && !this.bitrateTest && (f = f.initSegment), this.loadFragment(f, a, d));
  }
  loadFragment(e, t, s) {
    const i = this.fragmentTracker.getState(e);
    this.fragCurrent = e, i === ae.NOT_LOADED || i === ae.PARTIAL ? e.sn === "initSegment" ? this._loadInitSegment(e, t) : this.bitrateTest ? (this.log(`Fragment ${e.sn} of level ${e.level} is being downloaded to test bitrate and will not be buffered`), this._loadBitrateTestFrag(e, t)) : (this.startFragRequested = !0, super.loadFragment(e, t, s)) : this.clearTrackerIfNeeded(e);
  }
  getBufferedFrag(e) {
    return this.fragmentTracker.getBufferedFrag(e, G.MAIN);
  }
  followingBufferedFrag(e) {
    return e ? this.getBufferedFrag(e.end + 0.5) : null;
  }
  /*
    on immediate level switch :
     - pause playback if playing
     - cancel any pending load request
     - and trigger a buffer flush
  */
  immediateLevelSwitch() {
    this.abortCurrentFrag(), this.flushMainBuffer(0, Number.POSITIVE_INFINITY);
  }
  /**
   * try to switch ASAP without breaking video playback:
   * in order to ensure smooth but quick level switching,
   * we need to find the next flushable buffer range
   * we should take into account new segment fetch time
   */
  nextLevelSwitch() {
    const {
      levels: e,
      media: t
    } = this;
    if (t != null && t.readyState) {
      let s;
      const i = this.getAppendedFrag(t.currentTime);
      i && i.start > 1 && this.flushMainBuffer(0, i.start - 1);
      const r = this.getLevelDetails();
      if (r != null && r.live) {
        const o = this.getMainFwdBufferInfo();
        if (!o || o.len < r.targetduration * 2)
          return;
      }
      if (!t.paused && e) {
        const o = this.hls.nextLoadLevel, l = e[o], c = this.fragLastKbps;
        c && this.fragCurrent ? s = this.fragCurrent.duration * l.maxBitrate / (1e3 * c) + 1 : s = 0;
      } else
        s = 0;
      const a = this.getBufferedFrag(t.currentTime + s);
      if (a) {
        const o = this.followingBufferedFrag(a);
        if (o) {
          this.abortCurrentFrag();
          const l = o.maxStartPTS ? o.maxStartPTS : o.start, c = o.duration, h = Math.max(a.end, l + Math.min(Math.max(c - this.config.maxFragLookUpTolerance, c * (this.couldBacktrack ? 0.5 : 0.125)), c * (this.couldBacktrack ? 0.75 : 0.25)));
          this.flushMainBuffer(h, Number.POSITIVE_INFINITY);
        }
      }
    }
  }
  abortCurrentFrag() {
    const e = this.fragCurrent;
    switch (this.fragCurrent = null, this.backtrackFragment = null, e && (e.abortRequests(), this.fragmentTracker.removeFragment(e)), this.state) {
      case C.KEY_LOADING:
      case C.FRAG_LOADING:
      case C.FRAG_LOADING_WAITING_RETRY:
      case C.PARSING:
      case C.PARSED:
        this.state = C.IDLE;
        break;
    }
    this.nextLoadPosition = this.getLoadPosition();
  }
  flushMainBuffer(e, t) {
    super.flushMainBuffer(e, t, this.altAudio ? "video" : null);
  }
  onMediaAttached(e, t) {
    super.onMediaAttached(e, t);
    const s = t.media;
    this.onvplaying = this.onMediaPlaying.bind(this), this.onvseeked = this.onMediaSeeked.bind(this), s.addEventListener("playing", this.onvplaying), s.addEventListener("seeked", this.onvseeked), this.gapController = new Ch(this.config, s, this.fragmentTracker, this.hls);
  }
  onMediaDetaching() {
    const {
      media: e
    } = this;
    e && this.onvplaying && this.onvseeked && (e.removeEventListener("playing", this.onvplaying), e.removeEventListener("seeked", this.onvseeked), this.onvplaying = this.onvseeked = null, this.videoBuffer = null), this.fragPlaying = null, this.gapController && (this.gapController.destroy(), this.gapController = null), super.onMediaDetaching();
  }
  onMediaPlaying() {
    this.tick();
  }
  onMediaSeeked() {
    const e = this.media, t = e ? e.currentTime : null;
    M(t) && this.log(`Media seeked to ${t.toFixed(3)}`);
    const s = this.getMainFwdBufferInfo();
    if (s === null || s.len === 0) {
      this.warn(`Main forward buffer length on "seeked" event ${s ? s.len : "empty"})`);
      return;
    }
    this.tick();
  }
  onManifestLoading() {
    this.log("Trigger BUFFER_RESET"), this.hls.trigger(p.BUFFER_RESET, void 0), this.fragmentTracker.removeAllFragments(), this.couldBacktrack = !1, this.startPosition = this.lastCurrentTime = this.fragLastKbps = 0, this.levels = this.fragPlaying = this.backtrackFragment = this.levelLastLoaded = null, this.altAudio = this.audioOnly = this.startFragRequested = !1;
  }
  onManifestParsed(e, t) {
    let s = !1, i = !1;
    t.levels.forEach((r) => {
      const a = r.audioCodec;
      a && (s = s || a.indexOf("mp4a.40.2") !== -1, i = i || a.indexOf("mp4a.40.5") !== -1);
    }), this.audioCodecSwitch = s && i && !Rh(), this.audioCodecSwitch && this.log("Both AAC/HE-AAC audio found in levels; declaring level codec as HE-AAC"), this.levels = t.levels, this.startFragRequested = !1;
  }
  onLevelLoading(e, t) {
    const {
      levels: s
    } = this;
    if (!s || this.state !== C.IDLE)
      return;
    const i = s[t.level];
    (!i.details || i.details.live && this.levelLastLoaded !== i || this.waitForCdnTuneIn(i.details)) && (this.state = C.WAITING_LEVEL);
  }
  onLevelLoaded(e, t) {
    var s;
    const {
      levels: i
    } = this, r = t.level, a = t.details, o = a.totalduration;
    if (!i) {
      this.warn(`Levels were reset while loading level ${r}`);
      return;
    }
    this.log(`Level ${r} loaded [${a.startSN},${a.endSN}]${a.lastPartSn ? `[part-${a.lastPartSn}-${a.lastPartIndex}]` : ""}, cc [${a.startCC}, ${a.endCC}] duration:${o}`);
    const l = i[r], c = this.fragCurrent;
    c && (this.state === C.FRAG_LOADING || this.state === C.FRAG_LOADING_WAITING_RETRY) && c.level !== t.level && c.loader && this.abortCurrentFrag();
    let h = 0;
    if (a.live || (s = l.details) != null && s.live) {
      var u;
      if (this.checkLiveUpdate(a), a.deltaUpdateFailed)
        return;
      h = this.alignPlaylists(a, l.details, (u = this.levelLastLoaded) == null ? void 0 : u.details);
    }
    if (l.details = a, this.levelLastLoaded = l, this.hls.trigger(p.LEVEL_UPDATED, {
      details: a,
      level: r
    }), this.state === C.WAITING_LEVEL) {
      if (this.waitForCdnTuneIn(a))
        return;
      this.state = C.IDLE;
    }
    this.startFragRequested ? a.live && this.synchronizeToLiveEdge(a) : this.setStartPosition(a, h), this.tick();
  }
  _handleFragmentLoadProgress(e) {
    var t;
    const {
      frag: s,
      part: i,
      payload: r
    } = e, {
      levels: a
    } = this;
    if (!a) {
      this.warn(`Levels were reset while fragment load was in progress. Fragment ${s.sn} of level ${s.level} will not be buffered`);
      return;
    }
    const o = a[s.level], l = o.details;
    if (!l) {
      this.warn(`Dropping fragment ${s.sn} of level ${s.level} after level details were reset`), this.fragmentTracker.removeFragment(s);
      return;
    }
    const c = o.videoCodec, h = l.PTSKnown || !l.live, u = (t = s.initSegment) == null ? void 0 : t.data, d = this._getAudioCodec(o), f = this.transmuxer = this.transmuxer || new hn(this.hls, G.MAIN, this._handleTransmuxComplete.bind(this), this._handleTransmuxerFlush.bind(this)), g = i ? i.index : -1, m = g !== -1, E = new Vs(s.level, s.sn, s.stats.chunkCount, r.byteLength, g, m), T = this.initPTS[s.cc];
    f.push(r, u, d, c, s, i, l.totalduration, h, E, T);
  }
  onAudioTrackSwitching(e, t) {
    const s = this.altAudio;
    if (!!!t.url) {
      if (this.mediaBuffer !== this.media) {
        this.log("Switching on main audio, use media.buffered to schedule main fragment loading"), this.mediaBuffer = this.media;
        const a = this.fragCurrent;
        a && (this.log("Switching to main audio track, cancel main fragment load"), a.abortRequests(), this.fragmentTracker.removeFragment(a)), this.resetTransmuxer(), this.resetLoadingState();
      } else this.audioOnly && this.resetTransmuxer();
      const r = this.hls;
      s && (r.trigger(p.BUFFER_FLUSHING, {
        startOffset: 0,
        endOffset: Number.POSITIVE_INFINITY,
        type: null
      }), this.fragmentTracker.removeAllFragments()), r.trigger(p.AUDIO_TRACK_SWITCHED, t);
    }
  }
  onAudioTrackSwitched(e, t) {
    const s = t.id, i = !!this.hls.audioTracks[s].url;
    if (i) {
      const r = this.videoBuffer;
      r && this.mediaBuffer !== r && (this.log("Switching on alternate audio, use video.buffered to schedule main fragment loading"), this.mediaBuffer = r);
    }
    this.altAudio = i, this.tick();
  }
  onBufferCreated(e, t) {
    const s = t.tracks;
    let i, r, a = !1;
    for (const o in s) {
      const l = s[o];
      if (l.id === "main") {
        if (r = o, i = l, o === "video") {
          const c = s[o];
          c && (this.videoBuffer = c.buffer);
        }
      } else
        a = !0;
    }
    a && i ? (this.log(`Alternate track found, use ${r}.buffered to schedule main fragment loading`), this.mediaBuffer = i.buffer) : this.mediaBuffer = this.media;
  }
  onFragBuffered(e, t) {
    const {
      frag: s,
      part: i
    } = t;
    if (s && s.type !== G.MAIN)
      return;
    if (this.fragContextChanged(s)) {
      this.warn(`Fragment ${s.sn}${i ? " p: " + i.index : ""} of level ${s.level} finished buffering, but was aborted. state: ${this.state}`), this.state === C.PARSED && (this.state = C.IDLE);
      return;
    }
    const r = i ? i.stats : s.stats;
    this.fragLastKbps = Math.round(8 * r.total / (r.buffering.end - r.loading.first)), s.sn !== "initSegment" && (this.fragPrevious = s), this.fragBufferedComplete(s, i);
  }
  onError(e, t) {
    var s;
    if (t.fatal) {
      this.state = C.ERROR;
      return;
    }
    switch (t.details) {
      case L.FRAG_GAP:
      case L.FRAG_PARSING_ERROR:
      case L.FRAG_DECRYPT_ERROR:
      case L.FRAG_LOAD_ERROR:
      case L.FRAG_LOAD_TIMEOUT:
      case L.KEY_LOAD_ERROR:
      case L.KEY_LOAD_TIMEOUT:
        this.onFragmentOrKeyLoadError(G.MAIN, t);
        break;
      case L.LEVEL_LOAD_ERROR:
      case L.LEVEL_LOAD_TIMEOUT:
      case L.LEVEL_PARSING_ERROR:
        !t.levelRetry && this.state === C.WAITING_LEVEL && ((s = t.context) == null ? void 0 : s.type) === q.LEVEL && (this.state = C.IDLE);
        break;
      case L.BUFFER_APPEND_ERROR:
      case L.BUFFER_FULL_ERROR:
        if (!t.parent || t.parent !== "main")
          return;
        if (t.details === L.BUFFER_APPEND_ERROR) {
          this.resetLoadingState();
          return;
        }
        this.reduceLengthAndFlushBuffer(t) && this.flushMainBuffer(0, Number.POSITIVE_INFINITY);
        break;
      case L.INTERNAL_EXCEPTION:
        this.recoverWorkerError(t);
        break;
    }
  }
  // Checks the health of the buffer and attempts to resolve playback stalls.
  checkBuffer() {
    const {
      media: e,
      gapController: t
    } = this;
    if (!(!e || !t || !e.readyState)) {
      if (this.loadedmetadata || !J.getBuffered(e).length) {
        const s = this.state !== C.IDLE ? this.fragCurrent : null;
        t.poll(this.lastCurrentTime, s);
      }
      this.lastCurrentTime = e.currentTime;
    }
  }
  onFragLoadEmergencyAborted() {
    this.state = C.IDLE, this.loadedmetadata || (this.startFragRequested = !1, this.nextLoadPosition = this.startPosition), this.tickImmediate();
  }
  onBufferFlushed(e, {
    type: t
  }) {
    if (t !== Q.AUDIO || this.audioOnly && !this.altAudio) {
      const s = (t === Q.VIDEO ? this.videoBuffer : this.mediaBuffer) || this.media;
      this.afterBufferFlushed(s, t, G.MAIN), this.tick();
    }
  }
  onLevelsUpdated(e, t) {
    this.level > -1 && this.fragCurrent && (this.level = this.fragCurrent.level), this.levels = t.levels;
  }
  swapAudioCodec() {
    this.audioCodecSwap = !this.audioCodecSwap;
  }
  /**
   * Seeks to the set startPosition if not equal to the mediaElement's current time.
   */
  seekToStartPos() {
    const {
      media: e
    } = this;
    if (!e)
      return;
    const t = e.currentTime;
    let s = this.startPosition;
    if (s >= 0 && t < s) {
      if (e.seeking) {
        this.log(`could not seek to ${s}, already seeking at ${t}`);
        return;
      }
      const i = J.getBuffered(e), a = (i.length ? i.start(0) : 0) - s;
      a > 0 && (a < this.config.maxBufferHole || a < this.config.maxFragLookUpTolerance) && (this.log(`adjusting start position by ${a} to match buffer start`), s += a, this.startPosition = s), this.log(`seek to target start position ${s} from current time ${t}`), e.currentTime = s;
    }
  }
  _getAudioCodec(e) {
    let t = this.config.defaultAudioCodec || e.audioCodec;
    return this.audioCodecSwap && t && (this.log("Swapping audio codec"), t.indexOf("mp4a.40.5") !== -1 ? t = "mp4a.40.2" : t = "mp4a.40.5"), t;
  }
  _loadBitrateTestFrag(e, t) {
    e.bitrateTest = !0, this._doFragLoad(e, t).then((s) => {
      const {
        hls: i
      } = this;
      if (!s || this.fragContextChanged(e))
        return;
      t.fragmentError = 0, this.state = C.IDLE, this.startFragRequested = !1, this.bitrateTest = !1;
      const r = e.stats;
      r.parsing.start = r.parsing.end = r.buffering.start = r.buffering.end = self.performance.now(), i.trigger(p.FRAG_LOADED, s), e.bitrateTest = !1;
    });
  }
  _handleTransmuxComplete(e) {
    var t;
    const s = "main", {
      hls: i
    } = this, {
      remuxResult: r,
      chunkMeta: a
    } = e, o = this.getCurrentContext(a);
    if (!o) {
      this.resetWhenMissingContext(a);
      return;
    }
    const {
      frag: l,
      part: c,
      level: h
    } = o, {
      video: u,
      text: d,
      id3: f,
      initSegment: g
    } = r, {
      details: m
    } = h, E = this.altAudio ? void 0 : r.audio;
    if (this.fragContextChanged(l)) {
      this.fragmentTracker.removeFragment(l);
      return;
    }
    if (this.state = C.PARSING, g) {
      if (g != null && g.tracks) {
        const x = l.initSegment || l;
        this._bufferInitSegment(h, g.tracks, x, a), i.trigger(p.FRAG_PARSING_INIT_SEGMENT, {
          frag: x,
          id: s,
          tracks: g.tracks
        });
      }
      const T = g.initPTS, y = g.timescale;
      M(T) && (this.initPTS[l.cc] = {
        baseTime: T,
        timescale: y
      }, i.trigger(p.INIT_PTS_FOUND, {
        frag: l,
        id: s,
        initPTS: T,
        timescale: y
      }));
    }
    if (u && m && l.sn !== "initSegment") {
      const T = m.fragments[l.sn - 1 - m.startSN], y = l.sn === m.startSN, x = !T || l.cc > T.cc;
      if (r.independent !== !1) {
        const {
          startPTS: b,
          endPTS: S,
          startDTS: D,
          endDTS: R
        } = u;
        if (c)
          c.elementaryStreams[u.type] = {
            startPTS: b,
            endPTS: S,
            startDTS: D,
            endDTS: R
          };
        else if (u.firstKeyFrame && u.independent && a.id === 1 && !x && (this.couldBacktrack = !0), u.dropped && u.independent) {
          const _ = this.getMainFwdBufferInfo(), P = (_ ? _.end : this.getLoadPosition()) + this.config.maxBufferHole, I = u.firstKeyFramePTS ? u.firstKeyFramePTS : b;
          if (!y && P < I - this.config.maxBufferHole && !x) {
            this.backtrack(l);
            return;
          } else x && (l.gap = !0);
          l.setElementaryStreamInfo(u.type, l.start, S, l.start, R, !0);
        } else y && b > _t && (l.gap = !0);
        l.setElementaryStreamInfo(u.type, b, S, D, R), this.backtrackFragment && (this.backtrackFragment = l), this.bufferFragmentData(u, l, c, a, y || x);
      } else if (y || x)
        l.gap = !0;
      else {
        this.backtrack(l);
        return;
      }
    }
    if (E) {
      const {
        startPTS: T,
        endPTS: y,
        startDTS: x,
        endDTS: b
      } = E;
      c && (c.elementaryStreams[Q.AUDIO] = {
        startPTS: T,
        endPTS: y,
        startDTS: x,
        endDTS: b
      }), l.setElementaryStreamInfo(Q.AUDIO, T, y, x, b), this.bufferFragmentData(E, l, c, a);
    }
    if (m && f != null && (t = f.samples) != null && t.length) {
      const T = {
        id: s,
        frag: l,
        details: m,
        samples: f.samples
      };
      i.trigger(p.FRAG_PARSING_METADATA, T);
    }
    if (m && d) {
      const T = {
        id: s,
        frag: l,
        details: m,
        samples: d.samples
      };
      i.trigger(p.FRAG_PARSING_USERDATA, T);
    }
  }
  _bufferInitSegment(e, t, s, i) {
    if (this.state !== C.PARSING)
      return;
    this.audioOnly = !!t.audio && !t.video, this.altAudio && !this.audioOnly && delete t.audio;
    const {
      audio: r,
      video: a,
      audiovideo: o
    } = t;
    if (r) {
      let l = e.audioCodec;
      const c = navigator.userAgent.toLowerCase();
      if (this.audioCodecSwitch) {
        l && (l.indexOf("mp4a.40.5") !== -1 ? l = "mp4a.40.2" : l = "mp4a.40.5");
        const h = r.metadata;
        h && "channelCount" in h && (h.channelCount || 1) !== 1 && c.indexOf("firefox") === -1 && (l = "mp4a.40.5");
      }
      l && l.indexOf("mp4a.40.5") !== -1 && c.indexOf("android") !== -1 && r.container !== "audio/mpeg" && (l = "mp4a.40.2", this.log(`Android: force audio codec to ${l}`)), e.audioCodec && e.audioCodec !== l && this.log(`Swapping manifest audio codec "${e.audioCodec}" for "${l}"`), r.levelCodec = l, r.id = "main", this.log(`Init audio buffer, container:${r.container}, codecs[selected/level/parsed]=[${l || ""}/${e.audioCodec || ""}/${r.codec}]`);
    }
    a && (a.levelCodec = e.videoCodec, a.id = "main", this.log(`Init video buffer, container:${a.container}, codecs[level/parsed]=[${e.videoCodec || ""}/${a.codec}]`)), o && this.log(`Init audiovideo buffer, container:${o.container}, codecs[level/parsed]=[${e.codecs}/${o.codec}]`), this.hls.trigger(p.BUFFER_CODECS, t), Object.keys(t).forEach((l) => {
      const h = t[l].initSegment;
      h != null && h.byteLength && this.hls.trigger(p.BUFFER_APPENDING, {
        type: l,
        data: h,
        frag: s,
        part: null,
        chunkMeta: i,
        parent: s.type
      });
    }), this.tickImmediate();
  }
  getMainFwdBufferInfo() {
    return this.getFwdBufferInfo(this.mediaBuffer ? this.mediaBuffer : this.media, G.MAIN);
  }
  backtrack(e) {
    this.couldBacktrack = !0, this.backtrackFragment = e, this.resetTransmuxer(), this.flushBufferGap(e), this.fragmentTracker.removeFragment(e), this.fragPrevious = null, this.nextLoadPosition = e.start, this.state = C.IDLE;
  }
  checkFragmentChanged() {
    const e = this.media;
    let t = null;
    if (e && e.readyState > 1 && e.seeking === !1) {
      const s = e.currentTime;
      if (J.isBuffered(e, s) ? t = this.getAppendedFrag(s) : J.isBuffered(e, s + 0.1) && (t = this.getAppendedFrag(s + 0.1)), t) {
        this.backtrackFragment = null;
        const i = this.fragPlaying, r = t.level;
        (!i || t.sn !== i.sn || i.level !== r) && (this.fragPlaying = t, this.hls.trigger(p.FRAG_CHANGED, {
          frag: t
        }), (!i || i.level !== r) && this.hls.trigger(p.LEVEL_SWITCHED, {
          level: r
        }));
      }
    }
  }
  get nextLevel() {
    const e = this.nextBufferedFrag;
    return e ? e.level : -1;
  }
  get currentFrag() {
    const e = this.media;
    return e ? this.fragPlaying || this.getAppendedFrag(e.currentTime) : null;
  }
  get currentProgramDateTime() {
    const e = this.media;
    if (e) {
      const t = e.currentTime, s = this.currentFrag;
      if (s && M(t) && M(s.programDateTime)) {
        const i = s.programDateTime + (t - s.start) * 1e3;
        return new Date(i);
      }
    }
    return null;
  }
  get currentLevel() {
    const e = this.currentFrag;
    return e ? e.level : -1;
  }
  get nextBufferedFrag() {
    const e = this.currentFrag;
    return e ? this.followingBufferedFrag(e) : null;
  }
  get forceStartLoad() {
    return this._forceStartLoad;
  }
}
class Ee {
  /**
   * Get the video-dev/hls.js package version.
   */
  static get version() {
    return "1.5.17";
  }
  /**
   * Check if the required MediaSource Extensions are available.
   */
  static isMSESupported() {
    return _n();
  }
  /**
   * Check if MediaSource Extensions are available and isTypeSupported checks pass for any baseline codecs.
   */
  static isSupported() {
    return Lh();
  }
  /**
   * Get the MediaSource global used for MSE playback (ManagedMediaSource, MediaSource, or WebKitMediaSource).
   */
  static getMediaSource() {
    return Ve();
  }
  static get Events() {
    return p;
  }
  static get ErrorTypes() {
    return K;
  }
  static get ErrorDetails() {
    return L;
  }
  /**
   * Get the default configuration applied to new instances.
   */
  static get DefaultConfig() {
    return Ee.defaultConfig ? Ee.defaultConfig : Dn;
  }
  /**
   * Replace the default configuration applied to new instances.
   */
  static set DefaultConfig(e) {
    Ee.defaultConfig = e;
  }
  /**
   * Creates an instance of an HLS client that can attach to exactly one `HTMLMediaElement`.
   * @param userConfig - Configuration options applied over `Hls.DefaultConfig`
   */
  constructor(e = {}) {
    this.config = void 0, this.userConfig = void 0, this.coreComponents = void 0, this.networkControllers = void 0, this.started = !1, this._emitter = new Xs(), this._autoLevelCapping = -1, this._maxHdcpLevel = null, this.abrController = void 0, this.bufferController = void 0, this.capLevelController = void 0, this.latencyController = void 0, this.levelController = void 0, this.streamController = void 0, this.audioTrackController = void 0, this.subtitleTrackController = void 0, this.emeController = void 0, this.cmcdController = void 0, this._media = null, this.url = null, this.triggeringException = void 0, Ta(e.debug || !1, "Hls instance");
    const t = this.config = xh(Ee.DefaultConfig, e);
    this.userConfig = e, t.progressive && Sh(t);
    const {
      abrController: s,
      bufferController: i,
      capLevelController: r,
      errorController: a,
      fpsController: o
    } = t, l = new a(this), c = this.abrController = new s(this), h = this.bufferController = new i(this), u = this.capLevelController = new r(this), d = new o(this), f = new fo(this), g = new To(this), m = t.contentSteeringController, E = m ? new m(this) : null, T = this.levelController = new vh(this, E), y = new qo(this), x = new Ah(this.config), b = this.streamController = new kh(this, y, x);
    u.setStreamController(b), d.setStreamController(b);
    const S = [f, T, b];
    E && S.splice(1, 0, E), this.networkControllers = S;
    const D = [c, h, u, d, g, y];
    this.audioTrackController = this.createController(t.audioTrackController, S);
    const R = t.audioStreamController;
    R && S.push(new R(this, y, x)), this.subtitleTrackController = this.createController(t.subtitleTrackController, S);
    const _ = t.subtitleStreamController;
    _ && S.push(new _(this, y, x)), this.createController(t.timelineController, D), x.emeController = this.emeController = this.createController(t.emeController, D), this.cmcdController = this.createController(t.cmcdController, D), this.latencyController = this.createController(yo, D), this.coreComponents = D, S.push(l);
    const P = l.onErrorOut;
    typeof P == "function" && this.on(p.ERROR, P, l);
  }
  createController(e, t) {
    if (e) {
      const s = new e(this);
      return t && t.push(s), s;
    }
    return null;
  }
  // Delegate the EventEmitter through the public API of Hls.js
  on(e, t, s = this) {
    this._emitter.on(e, t, s);
  }
  once(e, t, s = this) {
    this._emitter.once(e, t, s);
  }
  removeAllListeners(e) {
    this._emitter.removeAllListeners(e);
  }
  off(e, t, s = this, i) {
    this._emitter.off(e, t, s, i);
  }
  listeners(e) {
    return this._emitter.listeners(e);
  }
  emit(e, t, s) {
    return this._emitter.emit(e, t, s);
  }
  trigger(e, t) {
    if (this.config.debug)
      return this.emit(e, e, t);
    try {
      return this.emit(e, e, t);
    } catch (s) {
      if (v.error("An internal error happened while handling event " + e + '. Error message: "' + s.message + '". Here is a stacktrace:', s), !this.triggeringException) {
        this.triggeringException = !0;
        const i = e === p.ERROR;
        this.trigger(p.ERROR, {
          type: K.OTHER_ERROR,
          details: L.INTERNAL_EXCEPTION,
          fatal: i,
          event: e,
          error: s
        }), this.triggeringException = !1;
      }
    }
    return !1;
  }
  listenerCount(e) {
    return this._emitter.listenerCount(e);
  }
  /**
   * Dispose of the instance
   */
  destroy() {
    v.log("destroy"), this.trigger(p.DESTROYING, void 0), this.detachMedia(), this.removeAllListeners(), this._autoLevelCapping = -1, this.url = null, this.networkControllers.forEach((t) => t.destroy()), this.networkControllers.length = 0, this.coreComponents.forEach((t) => t.destroy()), this.coreComponents.length = 0;
    const e = this.config;
    e.xhrSetup = e.fetchSetup = void 0, this.userConfig = null;
  }
  /**
   * Attaches Hls.js to a media element
   */
  attachMedia(e) {
    v.log("attachMedia"), this._media = e, this.trigger(p.MEDIA_ATTACHING, {
      media: e
    });
  }
  /**
   * Detach Hls.js from the media
   */
  detachMedia() {
    v.log("detachMedia"), this.trigger(p.MEDIA_DETACHING, void 0), this._media = null;
  }
  /**
   * Set the source URL. Can be relative or absolute.
   */
  loadSource(e) {
    this.stopLoad();
    const t = this.media, s = this.url, i = this.url = Ns.buildAbsoluteURL(self.location.href, e, {
      alwaysNormalize: !0
    });
    this._autoLevelCapping = -1, this._maxHdcpLevel = null, v.log(`loadSource:${i}`), t && s && (s !== i || this.bufferController.hasSourceTypes()) && (this.detachMedia(), this.attachMedia(t)), this.trigger(p.MANIFEST_LOADING, {
      url: e
    });
  }
  /**
   * Start loading data from the stream source.
   * Depending on default config, client starts loading automatically when a source is set.
   *
   * @param startPosition - Set the start position to stream from.
   * Defaults to -1 (None: starts from earliest point)
   */
  startLoad(e = -1) {
    v.log(`startLoad(${e})`), this.started = !0, this.networkControllers.forEach((t) => {
      t.startLoad(e);
    });
  }
  /**
   * Stop loading of any stream data.
   */
  stopLoad() {
    v.log("stopLoad"), this.started = !1, this.networkControllers.forEach((e) => {
      e.stopLoad();
    });
  }
  /**
   * Resumes stream controller segment loading if previously started.
   */
  resumeBuffering() {
    this.started && this.networkControllers.forEach((e) => {
      "fragmentLoader" in e && e.startLoad(-1);
    });
  }
  /**
   * Stops stream controller segment loading without changing 'started' state like stopLoad().
   * This allows for media buffering to be paused without interupting playlist loading.
   */
  pauseBuffering() {
    this.networkControllers.forEach((e) => {
      "fragmentLoader" in e && e.stopLoad();
    });
  }
  /**
   * Swap through possible audio codecs in the stream (for example to switch from stereo to 5.1)
   */
  swapAudioCodec() {
    v.log("swapAudioCodec"), this.streamController.swapAudioCodec();
  }
  /**
   * When the media-element fails, this allows to detach and then re-attach it
   * as one call (convenience method).
   *
   * Automatic recovery of media-errors by this process is configurable.
   */
  recoverMediaError() {
    v.log("recoverMediaError");
    const e = this._media;
    this.detachMedia(), e && this.attachMedia(e);
  }
  removeLevel(e) {
    this.levelController.removeLevel(e);
  }
  /**
   * @returns an array of levels (variants) sorted by HDCP-LEVEL, RESOLUTION (height), FRAME-RATE, CODECS, VIDEO-RANGE, and BANDWIDTH
   */
  get levels() {
    const e = this.levelController.levels;
    return e || [];
  }
  /**
   * Index of quality level (variant) currently played
   */
  get currentLevel() {
    return this.streamController.currentLevel;
  }
  /**
   * Set quality level index immediately. This will flush the current buffer to replace the quality asap. That means playback will interrupt at least shortly to re-buffer and re-sync eventually. Set to -1 for automatic level selection.
   */
  set currentLevel(e) {
    v.log(`set currentLevel:${e}`), this.levelController.manualLevel = e, this.streamController.immediateLevelSwitch();
  }
  /**
   * Index of next quality level loaded as scheduled by stream controller.
   */
  get nextLevel() {
    return this.streamController.nextLevel;
  }
  /**
   * Set quality level index for next loaded data.
   * This will switch the video quality asap, without interrupting playback.
   * May abort current loading of data, and flush parts of buffer (outside currently played fragment region).
   * @param newLevel - Pass -1 for automatic level selection
   */
  set nextLevel(e) {
    v.log(`set nextLevel:${e}`), this.levelController.manualLevel = e, this.streamController.nextLevelSwitch();
  }
  /**
   * Return the quality level of the currently or last (of none is loaded currently) segment
   */
  get loadLevel() {
    return this.levelController.level;
  }
  /**
   * Set quality level index for next loaded data in a conservative way.
   * This will switch the quality without flushing, but interrupt current loading.
   * Thus the moment when the quality switch will appear in effect will only be after the already existing buffer.
   * @param newLevel - Pass -1 for automatic level selection
   */
  set loadLevel(e) {
    v.log(`set loadLevel:${e}`), this.levelController.manualLevel = e;
  }
  /**
   * get next quality level loaded
   */
  get nextLoadLevel() {
    return this.levelController.nextLoadLevel;
  }
  /**
   * Set quality level of next loaded segment in a fully "non-destructive" way.
   * Same as `loadLevel` but will wait for next switch (until current loading is done).
   */
  set nextLoadLevel(e) {
    this.levelController.nextLoadLevel = e;
  }
  /**
   * Return "first level": like a default level, if not set,
   * falls back to index of first level referenced in manifest
   */
  get firstLevel() {
    return Math.max(this.levelController.firstLevel, this.minAutoLevel);
  }
  /**
   * Sets "first-level", see getter.
   */
  set firstLevel(e) {
    v.log(`set firstLevel:${e}`), this.levelController.firstLevel = e;
  }
  /**
   * Return the desired start level for the first fragment that will be loaded.
   * The default value of -1 indicates automatic start level selection.
   * Setting hls.nextAutoLevel without setting a startLevel will result in
   * the nextAutoLevel value being used for one fragment load.
   */
  get startLevel() {
    const e = this.levelController.startLevel;
    return e === -1 && this.abrController.forcedAutoLevel > -1 ? this.abrController.forcedAutoLevel : e;
  }
  /**
   * set  start level (level of first fragment that will be played back)
   * if not overrided by user, first level appearing in manifest will be used as start level
   * if -1 : automatic start level selection, playback will start from level matching download bandwidth
   * (determined from download of first segment)
   */
  set startLevel(e) {
    v.log(`set startLevel:${e}`), e !== -1 && (e = Math.max(e, this.minAutoLevel)), this.levelController.startLevel = e;
  }
  /**
   * Whether level capping is enabled.
   * Default value is set via `config.capLevelToPlayerSize`.
   */
  get capLevelToPlayerSize() {
    return this.config.capLevelToPlayerSize;
  }
  /**
   * Enables or disables level capping. If disabled after previously enabled, `nextLevelSwitch` will be immediately called.
   */
  set capLevelToPlayerSize(e) {
    const t = !!e;
    t !== this.config.capLevelToPlayerSize && (t ? this.capLevelController.startCapping() : (this.capLevelController.stopCapping(), this.autoLevelCapping = -1, this.streamController.nextLevelSwitch()), this.config.capLevelToPlayerSize = t);
  }
  /**
   * Capping/max level value that should be used by automatic level selection algorithm (`ABRController`)
   */
  get autoLevelCapping() {
    return this._autoLevelCapping;
  }
  /**
   * Returns the current bandwidth estimate in bits per second, when available. Otherwise, `NaN` is returned.
   */
  get bandwidthEstimate() {
    const {
      bwEstimator: e
    } = this.abrController;
    return e ? e.getEstimate() : NaN;
  }
  set bandwidthEstimate(e) {
    this.abrController.resetEstimator(e);
  }
  /**
   * get time to first byte estimate
   * @type {number}
   */
  get ttfbEstimate() {
    const {
      bwEstimator: e
    } = this.abrController;
    return e ? e.getEstimateTTFB() : NaN;
  }
  /**
   * Capping/max level value that should be used by automatic level selection algorithm (`ABRController`)
   */
  set autoLevelCapping(e) {
    this._autoLevelCapping !== e && (v.log(`set autoLevelCapping:${e}`), this._autoLevelCapping = e, this.levelController.checkMaxAutoUpdated());
  }
  get maxHdcpLevel() {
    return this._maxHdcpLevel;
  }
  set maxHdcpLevel(e) {
    xo(e) && this._maxHdcpLevel !== e && (this._maxHdcpLevel = e, this.levelController.checkMaxAutoUpdated());
  }
  /**
   * True when automatic level selection enabled
   */
  get autoLevelEnabled() {
    return this.levelController.manualLevel === -1;
  }
  /**
   * Level set manually (if any)
   */
  get manualLevel() {
    return this.levelController.manualLevel;
  }
  /**
   * min level selectable in auto mode according to config.minAutoBitrate
   */
  get minAutoLevel() {
    const {
      levels: e,
      config: {
        minAutoBitrate: t
      }
    } = this;
    if (!e) return 0;
    const s = e.length;
    for (let i = 0; i < s; i++)
      if (e[i].maxBitrate >= t)
        return i;
    return 0;
  }
  /**
   * max level selectable in auto mode according to autoLevelCapping
   */
  get maxAutoLevel() {
    const {
      levels: e,
      autoLevelCapping: t,
      maxHdcpLevel: s
    } = this;
    let i;
    if (t === -1 && e != null && e.length ? i = e.length - 1 : i = t, s)
      for (let r = i; r--; ) {
        const a = e[r].attrs["HDCP-LEVEL"];
        if (a && a <= s)
          return r;
      }
    return i;
  }
  get firstAutoLevel() {
    return this.abrController.firstAutoLevel;
  }
  /**
   * next automatically selected quality level
   */
  get nextAutoLevel() {
    return this.abrController.nextAutoLevel;
  }
  /**
   * this setter is used to force next auto level.
   * this is useful to force a switch down in auto mode:
   * in case of load error on level N, hls.js can set nextAutoLevel to N-1 for example)
   * forced value is valid for one fragment. upon successful frag loading at forced level,
   * this value will be resetted to -1 by ABR controller.
   */
  set nextAutoLevel(e) {
    this.abrController.nextAutoLevel = e;
  }
  /**
   * get the datetime value relative to media.currentTime for the active level Program Date Time if present
   */
  get playingDate() {
    return this.streamController.currentProgramDateTime;
  }
  get mainForwardBufferInfo() {
    return this.streamController.getMainFwdBufferInfo();
  }
  /**
   * Find and select the best matching audio track, making a level switch when a Group change is necessary.
   * Updates `hls.config.audioPreference`. Returns the selected track, or null when no matching track is found.
   */
  setAudioOption(e) {
    var t;
    return (t = this.audioTrackController) == null ? void 0 : t.setAudioOption(e);
  }
  /**
   * Find and select the best matching subtitle track, making a level switch when a Group change is necessary.
   * Updates `hls.config.subtitlePreference`. Returns the selected track, or null when no matching track is found.
   */
  setSubtitleOption(e) {
    var t;
    return (t = this.subtitleTrackController) == null || t.setSubtitleOption(e), null;
  }
  /**
   * Get the complete list of audio tracks across all media groups
   */
  get allAudioTracks() {
    const e = this.audioTrackController;
    return e ? e.allAudioTracks : [];
  }
  /**
   * Get the list of selectable audio tracks
   */
  get audioTracks() {
    const e = this.audioTrackController;
    return e ? e.audioTracks : [];
  }
  /**
   * index of the selected audio track (index in audio track lists)
   */
  get audioTrack() {
    const e = this.audioTrackController;
    return e ? e.audioTrack : -1;
  }
  /**
   * selects an audio track, based on its index in audio track lists
   */
  set audioTrack(e) {
    const t = this.audioTrackController;
    t && (t.audioTrack = e);
  }
  /**
   * get the complete list of subtitle tracks across all media groups
   */
  get allSubtitleTracks() {
    const e = this.subtitleTrackController;
    return e ? e.allSubtitleTracks : [];
  }
  /**
   * get alternate subtitle tracks list from playlist
   */
  get subtitleTracks() {
    const e = this.subtitleTrackController;
    return e ? e.subtitleTracks : [];
  }
  /**
   * index of the selected subtitle track (index in subtitle track lists)
   */
  get subtitleTrack() {
    const e = this.subtitleTrackController;
    return e ? e.subtitleTrack : -1;
  }
  get media() {
    return this._media;
  }
  /**
   * select an subtitle track, based on its index in subtitle track lists
   */
  set subtitleTrack(e) {
    const t = this.subtitleTrackController;
    t && (t.subtitleTrack = e);
  }
  /**
   * Whether subtitle display is enabled or not
   */
  get subtitleDisplay() {
    const e = this.subtitleTrackController;
    return e ? e.subtitleDisplay : !1;
  }
  /**
   * Enable/disable subtitle display rendering
   */
  set subtitleDisplay(e) {
    const t = this.subtitleTrackController;
    t && (t.subtitleDisplay = e);
  }
  /**
   * get mode for Low-Latency HLS loading
   */
  get lowLatencyMode() {
    return this.config.lowLatencyMode;
  }
  /**
   * Enable/disable Low-Latency HLS part playlist and segment loading, and start live streams at playlist PART-HOLD-BACK rather than HOLD-BACK.
   */
  set lowLatencyMode(e) {
    this.config.lowLatencyMode = e;
  }
  /**
   * Position (in seconds) of live sync point (ie edge of live position minus safety delay defined by ```hls.config.liveSyncDuration```)
   * @returns null prior to loading live Playlist
   */
  get liveSyncPosition() {
    return this.latencyController.liveSyncPosition;
  }
  /**
   * Estimated position (in seconds) of live edge (ie edge of live playlist plus time sync playlist advanced)
   * @returns 0 before first playlist is loaded
   */
  get latency() {
    return this.latencyController.latency;
  }
  /**
   * maximum distance from the edge before the player seeks forward to ```hls.liveSyncPosition```
   * configured using ```liveMaxLatencyDurationCount``` (multiple of target duration) or ```liveMaxLatencyDuration```
   * @returns 0 before first playlist is loaded
   */
  get maxLatency() {
    return this.latencyController.maxLatency;
  }
  /**
   * target distance from the edge as calculated by the latency controller
   */
  get targetLatency() {
    return this.latencyController.targetLatency;
  }
  /**
   * the rate at which the edge of the current live playlist is advancing or 1 if there is none
   */
  get drift() {
    return this.latencyController.drift;
  }
  /**
   * set to true when startLoad is called before MANIFEST_PARSED event
   */
  get forceStartLoad() {
    return this.streamController.forceStartLoad;
  }
}
Ee.defaultConfig = void 0;
const {
  SvelteComponent: wh,
  action_destroyer: Ph,
  add_render_callback: Fh,
  assign: hr,
  attr: Fe,
  binding_callbacks: Oh,
  bubble: gs,
  children: Mh,
  claim_element: ur,
  claim_space: Nh,
  create_slot: Uh,
  detach: vt,
  element: dr,
  exclude_internal_props: fr,
  get_all_dirty_from_scope: Bh,
  get_slot_changes: Gh,
  get_svelte_dataset: $h,
  init: Kh,
  insert_hydration: ms,
  is_function: Vh,
  listen: he,
  raf: Hh,
  run_all: Wh,
  safe_not_equal: Yh,
  space: qh,
  src_url_equal: gr,
  toggle_class: mr,
  transition_in: jh,
  transition_out: zh,
  update_slot_base: Xh
} = window.__gradio__svelte__internal, { createEventDispatcher: Qh } = window.__gradio__svelte__internal;
function Jh(n) {
  let e, t = '<span class="load-wrap svelte-1pwzuub"><span class="loader svelte-1pwzuub"></span></span>', s, i, r, a, o = !1, l, c = !0, h, u, d, f;
  const g = (
    /*#slots*/
    n[18].default
  ), m = Uh(
    g,
    n,
    /*$$scope*/
    n[17],
    null
  );
  function E() {
    cancelAnimationFrame(l), i.paused || (l = Hh(E), o = !0), n[22].call(i);
  }
  return {
    c() {
      e = dr("div"), e.innerHTML = t, s = qh(), i = dr("video"), m && m.c(), this.h();
    },
    l(T) {
      e = ur(T, "DIV", { class: !0, "data-svelte-h": !0 }), $h(e) !== "svelte-mez4j5" && (e.innerHTML = t), s = Nh(T), i = ur(T, "VIDEO", {
        src: !0,
        preload: !0,
        "data-testid": !0,
        crossorigin: !0
      });
      var y = Mh(i);
      m && m.l(y), y.forEach(vt), this.h();
    },
    h() {
      Fe(e, "class", "overlay svelte-1pwzuub"), mr(e, "hidden", !/*processingVideo*/
      n[10]), gr(i.src, r = /*resolved_src*/
      n[11]) || Fe(i, "src", r), i.muted = /*muted*/
      n[4], i.playsInline = /*playsinline*/
      n[5], Fe(
        i,
        "preload",
        /*preload*/
        n[6]
      ), i.autoplay = /*autoplay*/
      n[7], i.controls = /*controls*/
      n[8], i.loop = /*loop*/
      n[9], Fe(i, "data-testid", a = /*$$props*/
      n[13]["data-testid"]), Fe(i, "crossorigin", "anonymous"), /*duration*/
      n[2] === void 0 && Fh(() => (
        /*video_durationchange_handler*/
        n[23].call(i)
      ));
    },
    m(T, y) {
      ms(T, e, y), ms(T, s, y), ms(T, i, y), m && m.m(i, null), n[25](i), u = !0, d || (f = [
        he(
          i,
          "loadeddata",
          /*dispatch*/
          n[12].bind(null, "loadeddata")
        ),
        he(
          i,
          "click",
          /*dispatch*/
          n[12].bind(null, "click")
        ),
        he(
          i,
          "play",
          /*dispatch*/
          n[12].bind(null, "play")
        ),
        he(
          i,
          "pause",
          /*dispatch*/
          n[12].bind(null, "pause")
        ),
        he(
          i,
          "ended",
          /*dispatch*/
          n[12].bind(null, "ended")
        ),
        he(
          i,
          "mouseover",
          /*dispatch*/
          n[12].bind(null, "mouseover")
        ),
        he(
          i,
          "mouseout",
          /*dispatch*/
          n[12].bind(null, "mouseout")
        ),
        he(
          i,
          "focus",
          /*dispatch*/
          n[12].bind(null, "focus")
        ),
        he(
          i,
          "blur",
          /*dispatch*/
          n[12].bind(null, "blur")
        ),
        he(
          i,
          "loadstart",
          /*loadstart_handler*/
          n[19]
        ),
        he(
          i,
          "loadeddata",
          /*loadeddata_handler*/
          n[20]
        ),
        he(
          i,
          "loadedmetadata",
          /*loadedmetadata_handler*/
          n[21]
        ),
        he(i, "timeupdate", E),
        he(
          i,
          "durationchange",
          /*video_durationchange_handler*/
          n[23]
        ),
        he(
          i,
          "play",
          /*video_play_pause_handler*/
          n[24]
        ),
        he(
          i,
          "pause",
          /*video_play_pause_handler*/
          n[24]
        ),
        Ph(h = ca.call(null, i, { autoplay: (
          /*autoplay*/
          n[7] ?? !1
        ) }))
      ], d = !0);
    },
    p(T, [y]) {
      (!u || y & /*processingVideo*/
      1024) && mr(e, "hidden", !/*processingVideo*/
      T[10]), m && m.p && (!u || y & /*$$scope*/
      131072) && Xh(
        m,
        g,
        T,
        /*$$scope*/
        T[17],
        u ? Gh(
          g,
          /*$$scope*/
          T[17],
          y,
          null
        ) : Bh(
          /*$$scope*/
          T[17]
        ),
        null
      ), (!u || y & /*resolved_src*/
      2048 && !gr(i.src, r = /*resolved_src*/
      T[11])) && Fe(i, "src", r), (!u || y & /*muted*/
      16) && (i.muted = /*muted*/
      T[4]), (!u || y & /*playsinline*/
      32) && (i.playsInline = /*playsinline*/
      T[5]), (!u || y & /*preload*/
      64) && Fe(
        i,
        "preload",
        /*preload*/
        T[6]
      ), (!u || y & /*autoplay*/
      128) && (i.autoplay = /*autoplay*/
      T[7]), (!u || y & /*controls*/
      256) && (i.controls = /*controls*/
      T[8]), (!u || y & /*loop*/
      512) && (i.loop = /*loop*/
      T[9]), (!u || y & /*$$props*/
      8192 && a !== (a = /*$$props*/
      T[13]["data-testid"])) && Fe(i, "data-testid", a), !o && y & /*currentTime*/
      2 && !isNaN(
        /*currentTime*/
        T[1]
      ) && (i.currentTime = /*currentTime*/
      T[1]), o = !1, y & /*paused*/
      8 && c !== (c = /*paused*/
      T[3]) && i[c ? "pause" : "play"](), h && Vh(h.update) && y & /*autoplay*/
      128 && h.update.call(null, { autoplay: (
        /*autoplay*/
        T[7] ?? !1
      ) });
    },
    i(T) {
      u || (jh(m, T), u = !0);
    },
    o(T) {
      zh(m, T), u = !1;
    },
    d(T) {
      T && (vt(e), vt(s), vt(i)), m && m.d(T), n[25](null), d = !1, Wh(f);
    }
  };
}
function Zh(n, e, t) {
  let { $$slots: s = {}, $$scope: i } = e, { src: r = void 0 } = e, { muted: a = void 0 } = e, { playsinline: o = void 0 } = e, { preload: l = void 0 } = e, { autoplay: c = void 0 } = e, { controls: h = void 0 } = e, { currentTime: u = void 0 } = e, { duration: d = void 0 } = e, { paused: f = void 0 } = e, { node: g = void 0 } = e, { loop: m } = e, { is_stream: E } = e, { processingVideo: T = !1 } = e, y, x = !1, b;
  const S = Qh();
  function D(w, $, U) {
    if (!(!w || !$) && U && Ee.isSupported() && !x) {
      const W = new Ee({
        maxBufferLength: 1,
        // 0.5 seconds (500 ms)
        maxMaxBufferLength: 1,
        // Maximum max buffer length in seconds
        lowLatencyMode: !0
        // Enable low latency mode
      });
      W.loadSource(w), W.attachMedia(U), W.on(Ee.Events.MANIFEST_PARSED, function() {
        U.play();
      }), W.on(Ee.Events.ERROR, function(z, N) {
        if (console.error("HLS error:", z, N), N.fatal)
          switch (N.type) {
            case Ee.ErrorTypes.NETWORK_ERROR:
              console.error("Fatal network error encountered, trying to recover"), W.startLoad();
              break;
            case Ee.ErrorTypes.MEDIA_ERROR:
              console.error("Fatal media error encountered, trying to recover"), W.recoverMediaError();
              break;
            default:
              console.error("Fatal error, cannot recover"), W.destroy();
              break;
          }
      }), x = !0;
    }
  }
  function R(w) {
    gs.call(this, n, w);
  }
  function _(w) {
    gs.call(this, n, w);
  }
  function P(w) {
    gs.call(this, n, w);
  }
  function I() {
    u = this.currentTime, t(1, u);
  }
  function k() {
    d = this.duration, t(2, d);
  }
  function V() {
    f = this.paused, t(3, f);
  }
  function F(w) {
    Oh[w ? "unshift" : "push"](() => {
      g = w, t(0, g);
    });
  }
  return n.$$set = (w) => {
    t(13, e = hr(hr({}, e), fr(w))), "src" in w && t(14, r = w.src), "muted" in w && t(4, a = w.muted), "playsinline" in w && t(5, o = w.playsinline), "preload" in w && t(6, l = w.preload), "autoplay" in w && t(7, c = w.autoplay), "controls" in w && t(8, h = w.controls), "currentTime" in w && t(1, u = w.currentTime), "duration" in w && t(2, d = w.duration), "paused" in w && t(3, f = w.paused), "node" in w && t(0, g = w.node), "loop" in w && t(9, m = w.loop), "is_stream" in w && t(15, E = w.is_stream), "processingVideo" in w && t(10, T = w.processingVideo), "$$scope" in w && t(17, i = w.$$scope);
  }, n.$$.update = () => {
    if (n.$$.dirty & /*src, latest_src*/
    81920) {
      t(11, y = r), t(16, b = r);
      const w = r;
      Sr(w).then(($) => {
        b === w && t(11, y = $);
      });
    }
    n.$$.dirty & /*src*/
    16384 && (x = !1), n.$$.dirty & /*src, is_stream, node*/
    49153 && D(r, E, g);
  }, e = fr(e), [
    g,
    u,
    d,
    f,
    a,
    o,
    l,
    c,
    h,
    m,
    T,
    y,
    S,
    e,
    r,
    E,
    b,
    i,
    s,
    R,
    _,
    P,
    I,
    k,
    V,
    F
  ];
}
class eu extends wh {
  constructor(e) {
    super(), Kh(this, e, Zh, Jh, Yh, {
      src: 14,
      muted: 4,
      playsinline: 5,
      preload: 6,
      autoplay: 7,
      controls: 8,
      currentTime: 1,
      duration: 2,
      paused: 3,
      node: 0,
      loop: 9,
      is_stream: 15,
      processingVideo: 10
    });
  }
}
const {
  SvelteComponent: tu,
  add_iframe_resize_listener: su,
  add_render_callback: iu,
  append_hydration: ps,
  attr: Ps,
  binding_callbacks: ru,
  check_outros: kn,
  children: Fs,
  claim_component: wn,
  claim_element: Os,
  claim_space: nu,
  claim_text: Pn,
  create_component: Fn,
  destroy_component: On,
  destroy_each: au,
  detach: $e,
  element: Ms,
  empty: pr,
  ensure_array_like: Er,
  group_outros: Mn,
  init: ou,
  insert_hydration: Wt,
  mount_component: Nn,
  noop: Kt,
  safe_not_equal: lu,
  set_data: Un,
  space: cu,
  src_url_equal: Tr,
  text: Bn,
  toggle_class: Oe,
  transition_in: Ke,
  transition_out: st
} = window.__gradio__svelte__internal, { onMount: hu } = window.__gradio__svelte__internal;
function yr(n, e, t) {
  const s = n.slice();
  return s[8] = e[t], s;
}
function uu(n) {
  let e = (
    /*file*/
    n[8].orig_name + ""
  ), t;
  return {
    c() {
      t = Bn(e);
    },
    l(s) {
      t = Pn(s, e);
    },
    m(s, i) {
      Wt(s, t, i);
    },
    p(s, i) {
      i & /*value*/
      1 && e !== (e = /*file*/
      s[8].orig_name + "") && Un(t, e);
    },
    i: Kt,
    o: Kt,
    d(s) {
      s && $e(t);
    }
  };
}
function du(n) {
  let e, t;
  return {
    c() {
      e = Ms("audio"), this.h();
    },
    l(s) {
      e = Os(s, "AUDIO", { src: !0 }), Fs(e).forEach($e), this.h();
    },
    h() {
      Tr(e.src, t = /*file*/
      n[8].url) || Ps(e, "src", t), e.controls = !0;
    },
    m(s, i) {
      Wt(s, e, i);
    },
    p(s, i) {
      i & /*value*/
      1 && !Tr(e.src, t = /*file*/
      s[8].url) && Ps(e, "src", t);
    },
    i: Kt,
    o: Kt,
    d(s) {
      s && $e(e);
    }
  };
}
function fu(n) {
  let e, t;
  return e = new eu({
    props: {
      src: (
        /*file*/
        n[8].url
      ),
      alt: "",
      loop: !0,
      is_stream: !1
    }
  }), {
    c() {
      Fn(e.$$.fragment);
    },
    l(s) {
      wn(e.$$.fragment, s);
    },
    m(s, i) {
      Nn(e, s, i), t = !0;
    },
    p(s, i) {
      const r = {};
      i & /*value*/
      1 && (r.src = /*file*/
      s[8].url), e.$set(r);
    },
    i(s) {
      t || (Ke(e.$$.fragment, s), t = !0);
    },
    o(s) {
      st(e.$$.fragment, s), t = !1;
    },
    d(s) {
      On(e, s);
    }
  };
}
function gu(n) {
  let e, t;
  return e = new oa({
    props: { src: (
      /*file*/
      n[8].url
    ), alt: "" }
  }), {
    c() {
      Fn(e.$$.fragment);
    },
    l(s) {
      wn(e.$$.fragment, s);
    },
    m(s, i) {
      Nn(e, s, i), t = !0;
    },
    p(s, i) {
      const r = {};
      i & /*value*/
      1 && (r.src = /*file*/
      s[8].url), e.$set(r);
    },
    i(s) {
      t || (Ke(e.$$.fragment, s), t = !0);
    },
    o(s) {
      st(e.$$.fragment, s), t = !1;
    },
    d(s) {
      On(e, s);
    }
  };
}
function xr(n) {
  let e, t, s, i, r, a, o;
  const l = [gu, fu, du, uu], c = [];
  function h(u, d) {
    return d & /*value*/
    1 && (e = null), d & /*value*/
    1 && (t = null), d & /*value*/
    1 && (s = null), e == null && (e = !!/*file*/
    (u[8].mime_type && /*file*/
    u[8].mime_type.includes("image"))), e ? 0 : (t == null && (t = !!/*file*/
    (u[8].mime_type && /*file*/
    u[8].mime_type.includes("video"))), t ? 1 : (s == null && (s = !!/*file*/
    (u[8].mime_type && /*file*/
    u[8].mime_type.includes("audio"))), s ? 2 : 3));
  }
  return i = h(n, -1), r = c[i] = l[i](n), {
    c() {
      r.c(), a = pr();
    },
    l(u) {
      r.l(u), a = pr();
    },
    m(u, d) {
      c[i].m(u, d), Wt(u, a, d), o = !0;
    },
    p(u, d) {
      let f = i;
      i = h(u, d), i === f ? c[i].p(u, d) : (Mn(), st(c[f], 1, 1, () => {
        c[f] = null;
      }), kn(), r = c[i], r ? r.p(u, d) : (r = c[i] = l[i](u), r.c()), Ke(r, 1), r.m(a.parentNode, a));
    },
    i(u) {
      o || (Ke(r), o = !0);
    },
    o(u) {
      st(r), o = !1;
    },
    d(u) {
      u && $e(a), c[i].d(u);
    }
  };
}
function mu(n) {
  let e, t, s = (
    /*value*/
    (n[0].text ? (
      /*value*/
      n[0].text
    ) : "") + ""
  ), i, r, a, o, l = Er(
    /*value*/
    n[0].files
  ), c = [];
  for (let u = 0; u < l.length; u += 1)
    c[u] = xr(yr(n, l, u));
  const h = (u) => st(c[u], 1, 1, () => {
    c[u] = null;
  });
  return {
    c() {
      e = Ms("div"), t = Ms("p"), i = Bn(s), r = cu();
      for (let u = 0; u < c.length; u += 1)
        c[u].c();
      this.h();
    },
    l(u) {
      e = Os(u, "DIV", { class: !0 });
      var d = Fs(e);
      t = Os(d, "P", {});
      var f = Fs(t);
      i = Pn(f, s), f.forEach($e), r = nu(d);
      for (let g = 0; g < c.length; g += 1)
        c[g].l(d);
      d.forEach($e), this.h();
    },
    h() {
      Ps(e, "class", "container svelte-glyrxt"), iu(() => (
        /*div_elementresize_handler*/
        n[5].call(e)
      )), Oe(
        e,
        "table",
        /*type*/
        n[1] === "table"
      ), Oe(
        e,
        "gallery",
        /*type*/
        n[1] === "gallery"
      ), Oe(
        e,
        "selected",
        /*selected*/
        n[2]
      ), Oe(
        e,
        "border",
        /*value*/
        n[0]
      );
    },
    m(u, d) {
      Wt(u, e, d), ps(e, t), ps(t, i), ps(e, r);
      for (let f = 0; f < c.length; f += 1)
        c[f] && c[f].m(e, null);
      a = su(
        e,
        /*div_elementresize_handler*/
        n[5].bind(e)
      ), n[6](e), o = !0;
    },
    p(u, [d]) {
      if ((!o || d & /*value*/
      1) && s !== (s = /*value*/
      (u[0].text ? (
        /*value*/
        u[0].text
      ) : "") + "") && Un(i, s), d & /*value*/
      1) {
        l = Er(
          /*value*/
          u[0].files
        );
        let f;
        for (f = 0; f < l.length; f += 1) {
          const g = yr(u, l, f);
          c[f] ? (c[f].p(g, d), Ke(c[f], 1)) : (c[f] = xr(g), c[f].c(), Ke(c[f], 1), c[f].m(e, null));
        }
        for (Mn(), f = l.length; f < c.length; f += 1)
          h(f);
        kn();
      }
      (!o || d & /*type*/
      2) && Oe(
        e,
        "table",
        /*type*/
        u[1] === "table"
      ), (!o || d & /*type*/
      2) && Oe(
        e,
        "gallery",
        /*type*/
        u[1] === "gallery"
      ), (!o || d & /*selected*/
      4) && Oe(
        e,
        "selected",
        /*selected*/
        u[2]
      ), (!o || d & /*value*/
      1) && Oe(
        e,
        "border",
        /*value*/
        u[0]
      );
    },
    i(u) {
      if (!o) {
        for (let d = 0; d < l.length; d += 1)
          Ke(c[d]);
        o = !0;
      }
    },
    o(u) {
      c = c.filter(Boolean);
      for (let d = 0; d < c.length; d += 1)
        st(c[d]);
      o = !1;
    },
    d(u) {
      u && $e(e), au(c, u), a(), n[6](null);
    }
  };
}
function pu(n, e, t) {
  let { value: s = { text: "", files: [] } } = e, { type: i } = e, { selected: r = !1 } = e, a, o;
  function l(u, d) {
    !u || !d || (o.style.setProperty("--local-text-width", `${d < 150 ? d : 200}px`), t(4, o.style.whiteSpace = "unset", o));
  }
  hu(() => {
    l(o, a);
  });
  function c() {
    a = this.clientWidth, t(3, a);
  }
  function h(u) {
    ru[u ? "unshift" : "push"](() => {
      o = u, t(4, o);
    });
  }
  return n.$$set = (u) => {
    "value" in u && t(0, s = u.value), "type" in u && t(1, i = u.type), "selected" in u && t(2, r = u.selected);
  }, [s, i, r, a, o, c, h];
}
class xu extends tu {
  constructor(e) {
    super(), ou(this, e, pu, mu, lu, { value: 0, type: 1, selected: 2 });
  }
}
export {
  xu as default
};
