__version__ = '3.6.1' 
VERSION = __version__
