"""Module to clean and process GECI data"""

__version__ = "0.14.0"
from .cli import *  # noqa
