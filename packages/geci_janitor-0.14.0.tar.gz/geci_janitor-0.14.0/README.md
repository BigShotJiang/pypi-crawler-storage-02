# Janitor <a href="https://www.islas.org.mx/"><img src="https://www.islas.org.mx/img/logo.svg" align="right" width="256" /></a>

[![codecov](https://codecov.io/gh/IslasGECI/janitor/branch/develop/graph/badge.svg?token=zXmBXOWRbG)](https://codecov.io/gh/IslasGECI/janitor)
![PyPI - Version](https://img.shields.io/pypi/v/geci-janitor)


## Overview

CLI with tools to process cat data.

## 🏗️ Installation

```shell
pip install geci-janitor
```
