from yardstick.cli.cli import cli

cli()
