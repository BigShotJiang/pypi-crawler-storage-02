from pydantic import BaseModel


class AbstractItemSource(BaseModel):
    pass
