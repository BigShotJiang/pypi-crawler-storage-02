# todo: this needs refactoring with the Flow_Run__Event events stored in the Schema__Flow__Data. object

# from typing                             import Dict, Optional, Any
# from osbot_utils.type_safe.Type_Safe    import Type_Safe
#
#
# class Schema__Flow__Event__Data(Type_Safe):         # Represents the data associated with a flow event
#     data         : Dict[str, Any]
#     event_source : str
#     flow_name    : Optional[str]
#     flow_run_id  : Optional[str]
#     log_level    : int
#     task_name    : Optional[str]
#     task_run_id  : Optional[str]