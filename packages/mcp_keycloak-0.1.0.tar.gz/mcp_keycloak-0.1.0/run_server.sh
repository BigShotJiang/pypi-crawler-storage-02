#!/bin/bash

# Run the Keycloak MCP server
echo "Starting Keycloak MCP Server..."

# Run with uv
uv run python src/main.py