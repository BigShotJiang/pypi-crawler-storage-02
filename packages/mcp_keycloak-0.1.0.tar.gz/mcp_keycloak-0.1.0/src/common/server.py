from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("Keycloak MCP Server", dependencies=["dotenv"])
