# Dean utils

This is a collection of funcs I use often and don't want to copy paste everywhere. They aren't necessarily functionally related and have hard coded env names that might probably don't make sense for others. It's public so that I can import it from various Azure Functions. 