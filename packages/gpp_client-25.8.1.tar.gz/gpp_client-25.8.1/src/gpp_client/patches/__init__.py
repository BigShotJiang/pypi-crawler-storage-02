from .patches import (
    patch_base_operations_graphql_field__format_variable_name,
    patch_base_operations_graphql_field_get_formatted_variables,
)

__all__ = [
    "patch_base_operations_graphql_field__format_variable_name",
    "patch_base_operations_graphql_field_get_formatted_variables",
]
