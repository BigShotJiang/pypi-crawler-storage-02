# Code of Conduct

We are committed to fostering an open and welcoming community.

- Be respectful and inclusive.
- Assume positive intent and seek to understand.
- Avoid harassment, discrimination, or personal attacks.

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the maintainers at project.jintoag@gmail.com.

This project adheres to the [Contributor Covenant](https://www.contributor-covenant.org/).
