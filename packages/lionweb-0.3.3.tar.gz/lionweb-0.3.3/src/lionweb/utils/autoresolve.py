from typing import Final

LIONCORE_AUTORESOLVE_PREFIX: Final = "LionWeb.LionCore_M3."
LIONCOREBUILTINS_AUTORESOLVE_PREFIX: Final = "LionWeb.LionCore_builtins."
