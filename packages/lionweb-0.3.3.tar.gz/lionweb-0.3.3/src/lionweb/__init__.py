__version__ = "0.3.3"
from .lionweb_version import LionWebVersion

__all__ = ["LionWebVersion"]
