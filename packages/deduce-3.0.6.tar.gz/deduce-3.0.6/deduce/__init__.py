from deduce.deduce import Deduce, __version__

__all__ = [
    "Deduce",
    "__version__",
]
