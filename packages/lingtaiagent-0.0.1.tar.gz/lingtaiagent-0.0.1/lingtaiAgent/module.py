
def hello():
    print("hello lingtai")
    return "hello lingtai"