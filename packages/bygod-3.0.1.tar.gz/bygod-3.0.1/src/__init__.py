"""ByGoD source package."""
