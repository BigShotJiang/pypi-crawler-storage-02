"""Tests package for ByGoD."""
