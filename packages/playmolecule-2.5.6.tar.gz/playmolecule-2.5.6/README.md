# Server-less PlayMolecule

Look up the docs

pip install playmolecule questionary google-cloud-storage==1.35.0 tqdm
