"""Tests for pltr."""
