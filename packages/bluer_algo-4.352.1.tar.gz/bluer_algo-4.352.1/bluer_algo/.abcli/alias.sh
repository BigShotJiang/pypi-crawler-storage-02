#! /usr/bin/env bash

alias @algo=bluer_algo

alias @image_classifier=bluer_algo_image_classifier

alias @tracker=bluer_algo_tracker

alias @yolo=bluer_algo_yolo
