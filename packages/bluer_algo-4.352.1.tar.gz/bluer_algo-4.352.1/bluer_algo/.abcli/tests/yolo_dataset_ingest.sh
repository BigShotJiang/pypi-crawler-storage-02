#! /usr/bin/env bash

function test_bluer_algo_yolo_dataset_ingest() {
    local options=$1

    local object_name=test_bluer_algo_yolo_dataset_ingest-$(bluer_ai_string_timestamp)

    bluer_ai_eval ,$options \
        bluer_algo_yolo_dataset_ingest \
        ,$options \
        $object_name \
        --verbose 1
}
