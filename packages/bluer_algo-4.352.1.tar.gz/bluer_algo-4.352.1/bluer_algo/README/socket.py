docs = [
    {"path": "../docs/socket.md"},
]
