docs = [
    {"path": "../docs/aliases"},
    {"path": "../docs/aliases/image_classifier.md"},
    {"path": "../docs/aliases/socket.md"},
    {"path": "../docs/aliases/tracker.md"},
    {"path": "../docs/aliases/yolo.md"},
]
