# Jupyterlab Armenian (Armenia) Language Pack

Armenian (Armenia) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-hy-AM
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-hy-AM
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
