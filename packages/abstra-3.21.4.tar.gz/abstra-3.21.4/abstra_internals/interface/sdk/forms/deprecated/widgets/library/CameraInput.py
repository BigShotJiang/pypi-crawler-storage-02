from .FileInput import FileInput


class CameraInput(FileInput):
    type = "camera-input"
