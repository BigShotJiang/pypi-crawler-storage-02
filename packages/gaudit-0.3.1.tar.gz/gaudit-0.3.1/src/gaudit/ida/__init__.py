from .plugin import GauditPlugin

__all__ = ["GauditPlugin"]
