"""Binary distribution testing package."""
