import logging

from custom_python_logger import get_logger

logger = get_logger(project_name='pytest-plugins', log_level=logging.DEBUG)
