"""Package metadata."""

__version__ = "0.0.61"
