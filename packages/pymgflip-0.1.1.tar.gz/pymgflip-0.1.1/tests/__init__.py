"""Tests for pymgflip."""
