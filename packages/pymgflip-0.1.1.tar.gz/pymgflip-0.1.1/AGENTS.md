# imgflip

This is a python library that wraps the imgflip API in a type-safe way.

The imgflip API is described at:

https://imgflip.com/api

We use httpx to make API calls and provide a type-safe interface for all the API features.
