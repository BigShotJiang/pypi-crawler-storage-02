def main():
    print("Hello from imgflip!")


if __name__ == "__main__":
    main()
