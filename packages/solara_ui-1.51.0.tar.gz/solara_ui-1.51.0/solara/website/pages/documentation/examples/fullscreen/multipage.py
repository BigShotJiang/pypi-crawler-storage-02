redirect = "/apps/multipage"

Page = True
