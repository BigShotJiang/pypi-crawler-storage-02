# for backwards compatibility
from solara.components.cross_filter import (  # noqa: F401
    CrossFilterDataFrame,
    CrossFilterReport,
    CrossFilterSelect,
    CrossFilterSlider,
)
