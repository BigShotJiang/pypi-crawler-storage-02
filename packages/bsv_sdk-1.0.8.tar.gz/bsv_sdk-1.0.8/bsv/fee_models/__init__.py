from .satoshis_per_kilobyte import SatoshisPerKilobyte

# Alias for the default fee model
DefaultFeeModel = SatoshisPerKilobyte
