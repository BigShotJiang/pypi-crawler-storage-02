import example.plugin.hardware.bridge.providers.bridgeA
import example.plugin.hardware.factory.providers.creatorA
import example.plugin.hardware.observer.providers.publisherA