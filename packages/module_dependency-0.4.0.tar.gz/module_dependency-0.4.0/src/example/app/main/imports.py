import example.plugin.base.imports
import example.plugin.hardware.imports
import example.plugin.reporter.imports