"""SciLink CLI interface."""

from .workflows import main as experimental_novelty_main

__all__ = ['experimental_novelty_main']