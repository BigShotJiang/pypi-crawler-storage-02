TIMEDELTA_FORMAT = "{D}d {H}h {M}m {S}s"
