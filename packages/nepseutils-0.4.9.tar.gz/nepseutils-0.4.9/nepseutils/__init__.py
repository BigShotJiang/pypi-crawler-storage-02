from nepseutils.core.meroshare import MeroShare

from .version import __version__
