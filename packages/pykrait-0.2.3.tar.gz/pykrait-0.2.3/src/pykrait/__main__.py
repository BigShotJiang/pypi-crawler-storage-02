"""
Copyright © 2025 Pentabyteman
"""
# src/pykrait/__main__.py
from pykrait.gui.app import AppController

if __name__ == "__main__":
    controller = AppController()
    controller.run()
