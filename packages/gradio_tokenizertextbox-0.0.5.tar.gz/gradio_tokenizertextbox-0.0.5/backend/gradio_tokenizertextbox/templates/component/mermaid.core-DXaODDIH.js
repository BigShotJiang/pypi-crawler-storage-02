var Xd = Object.defineProperty;
var Vd = (e, t, r) => t in e ? Xd(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var ot = (e, t, r) => Vd(e, typeof t != "symbol" ? t + "" : t, r);
import { g as Zd, c as Kd, p as pr } from "./Index-DcB-GfxT.js";
var Rl = { exports: {} };
(function(e, t) {
  (function(r, i) {
    e.exports = i();
  })(Kd, function() {
    var r = 1e3, i = 6e4, n = 36e5, a = "millisecond", o = "second", s = "minute", l = "hour", c = "day", h = "week", u = "month", f = "quarter", p = "year", g = "date", m = "Invalid Date", y = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, x = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, b = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(B) {
      var M = ["th", "st", "nd", "rd"], T = B % 100;
      return "[" + B + (M[(T - 20) % 10] || M[T] || M[0]) + "]";
    } }, _ = function(B, M, T) {
      var $ = String(B);
      return !$ || $.length >= M ? B : "" + Array(M + 1 - $.length).join(T) + B;
    }, S = { s: _, z: function(B) {
      var M = -B.utcOffset(), T = Math.abs(M), $ = Math.floor(T / 60), L = T % 60;
      return (M <= 0 ? "+" : "-") + _($, 2, "0") + ":" + _(L, 2, "0");
    }, m: function B(M, T) {
      if (M.date() < T.date()) return -B(T, M);
      var $ = 12 * (T.year() - M.year()) + (T.month() - M.month()), L = M.clone().add($, u), N = T - L < 0, U = M.clone().add($ + (N ? -1 : 1), u);
      return +(-($ + (T - L) / (N ? L - U : U - L)) || 0);
    }, a: function(B) {
      return B < 0 ? Math.ceil(B) || 0 : Math.floor(B);
    }, p: function(B) {
      return { M: u, y: p, w: h, d: c, D: g, h: l, m: s, s: o, ms: a, Q: f }[B] || String(B || "").toLowerCase().replace(/s$/, "");
    }, u: function(B) {
      return B === void 0;
    } }, w = "en", C = {};
    C[w] = b;
    var v = "$isDayjsObject", D = function(B) {
      return B instanceof P || !(!B || !B[v]);
    }, R = function B(M, T, $) {
      var L;
      if (!M) return w;
      if (typeof M == "string") {
        var N = M.toLowerCase();
        C[N] && (L = N), T && (C[N] = T, L = N);
        var U = M.split("-");
        if (!L && U.length > 1) return B(U[0]);
      } else {
        var J = M.name;
        C[J] = M, L = J;
      }
      return !$ && L && (w = L), L || !$ && w;
    }, E = function(B, M) {
      if (D(B)) return B.clone();
      var T = typeof M == "object" ? M : {};
      return T.date = B, T.args = arguments, new P(T);
    }, A = S;
    A.l = R, A.i = D, A.w = function(B, M) {
      return E(B, { locale: M.$L, utc: M.$u, x: M.$x, $offset: M.$offset });
    };
    var P = function() {
      function B(T) {
        this.$L = R(T.locale, null, !0), this.parse(T), this.$x = this.$x || T.x || {}, this[v] = !0;
      }
      var M = B.prototype;
      return M.parse = function(T) {
        this.$d = function($) {
          var L = $.date, N = $.utc;
          if (L === null) return /* @__PURE__ */ new Date(NaN);
          if (A.u(L)) return /* @__PURE__ */ new Date();
          if (L instanceof Date) return new Date(L);
          if (typeof L == "string" && !/Z$/i.test(L)) {
            var U = L.match(y);
            if (U) {
              var J = U[2] - 1 || 0, lt = (U[7] || "0").substring(0, 3);
              return N ? new Date(Date.UTC(U[1], J, U[3] || 1, U[4] || 0, U[5] || 0, U[6] || 0, lt)) : new Date(U[1], J, U[3] || 1, U[4] || 0, U[5] || 0, U[6] || 0, lt);
            }
          }
          return new Date(L);
        }(T), this.init();
      }, M.init = function() {
        var T = this.$d;
        this.$y = T.getFullYear(), this.$M = T.getMonth(), this.$D = T.getDate(), this.$W = T.getDay(), this.$H = T.getHours(), this.$m = T.getMinutes(), this.$s = T.getSeconds(), this.$ms = T.getMilliseconds();
      }, M.$utils = function() {
        return A;
      }, M.isValid = function() {
        return this.$d.toString() !== m;
      }, M.isSame = function(T, $) {
        var L = E(T);
        return this.startOf($) <= L && L <= this.endOf($);
      }, M.isAfter = function(T, $) {
        return E(T) < this.startOf($);
      }, M.isBefore = function(T, $) {
        return this.endOf($) < E(T);
      }, M.$g = function(T, $, L) {
        return A.u(T) ? this[$] : this.set(L, T);
      }, M.unix = function() {
        return Math.floor(this.valueOf() / 1e3);
      }, M.valueOf = function() {
        return this.$d.getTime();
      }, M.startOf = function(T, $) {
        var L = this, N = !!A.u($) || $, U = A.p(T), J = function(pt, ut) {
          var _t = A.w(L.$u ? Date.UTC(L.$y, ut, pt) : new Date(L.$y, ut, pt), L);
          return N ? _t : _t.endOf(c);
        }, lt = function(pt, ut) {
          return A.w(L.toDate()[pt].apply(L.toDate("s"), (N ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(ut)), L);
        }, ft = this.$W, yt = this.$M, Mt = this.$D, tt = "set" + (this.$u ? "UTC" : "");
        switch (U) {
          case p:
            return N ? J(1, 0) : J(31, 11);
          case u:
            return N ? J(1, yt) : J(0, yt + 1);
          case h:
            var it = this.$locale().weekStart || 0, gt = (ft < it ? ft + 7 : ft) - it;
            return J(N ? Mt - gt : Mt + (6 - gt), yt);
          case c:
          case g:
            return lt(tt + "Hours", 0);
          case l:
            return lt(tt + "Minutes", 1);
          case s:
            return lt(tt + "Seconds", 2);
          case o:
            return lt(tt + "Milliseconds", 3);
          default:
            return this.clone();
        }
      }, M.endOf = function(T) {
        return this.startOf(T, !1);
      }, M.$set = function(T, $) {
        var L, N = A.p(T), U = "set" + (this.$u ? "UTC" : ""), J = (L = {}, L[c] = U + "Date", L[g] = U + "Date", L[u] = U + "Month", L[p] = U + "FullYear", L[l] = U + "Hours", L[s] = U + "Minutes", L[o] = U + "Seconds", L[a] = U + "Milliseconds", L)[N], lt = N === c ? this.$D + ($ - this.$W) : $;
        if (N === u || N === p) {
          var ft = this.clone().set(g, 1);
          ft.$d[J](lt), ft.init(), this.$d = ft.set(g, Math.min(this.$D, ft.daysInMonth())).$d;
        } else J && this.$d[J](lt);
        return this.init(), this;
      }, M.set = function(T, $) {
        return this.clone().$set(T, $);
      }, M.get = function(T) {
        return this[A.p(T)]();
      }, M.add = function(T, $) {
        var L, N = this;
        T = Number(T);
        var U = A.p($), J = function(yt) {
          var Mt = E(N);
          return A.w(Mt.date(Mt.date() + Math.round(yt * T)), N);
        };
        if (U === u) return this.set(u, this.$M + T);
        if (U === p) return this.set(p, this.$y + T);
        if (U === c) return J(1);
        if (U === h) return J(7);
        var lt = (L = {}, L[s] = i, L[l] = n, L[o] = r, L)[U] || 1, ft = this.$d.getTime() + T * lt;
        return A.w(ft, this);
      }, M.subtract = function(T, $) {
        return this.add(-1 * T, $);
      }, M.format = function(T) {
        var $ = this, L = this.$locale();
        if (!this.isValid()) return L.invalidDate || m;
        var N = T || "YYYY-MM-DDTHH:mm:ssZ", U = A.z(this), J = this.$H, lt = this.$m, ft = this.$M, yt = L.weekdays, Mt = L.months, tt = L.meridiem, it = function(ut, _t, xe, Ar) {
          return ut && (ut[_t] || ut($, N)) || xe[_t].slice(0, Ar);
        }, gt = function(ut) {
          return A.s(J % 12 || 12, ut, "0");
        }, pt = tt || function(ut, _t, xe) {
          var Ar = ut < 12 ? "AM" : "PM";
          return xe ? Ar.toLowerCase() : Ar;
        };
        return N.replace(x, function(ut, _t) {
          return _t || function(xe) {
            switch (xe) {
              case "YY":
                return String($.$y).slice(-2);
              case "YYYY":
                return A.s($.$y, 4, "0");
              case "M":
                return ft + 1;
              case "MM":
                return A.s(ft + 1, 2, "0");
              case "MMM":
                return it(L.monthsShort, ft, Mt, 3);
              case "MMMM":
                return it(Mt, ft);
              case "D":
                return $.$D;
              case "DD":
                return A.s($.$D, 2, "0");
              case "d":
                return String($.$W);
              case "dd":
                return it(L.weekdaysMin, $.$W, yt, 2);
              case "ddd":
                return it(L.weekdaysShort, $.$W, yt, 3);
              case "dddd":
                return yt[$.$W];
              case "H":
                return String(J);
              case "HH":
                return A.s(J, 2, "0");
              case "h":
                return gt(1);
              case "hh":
                return gt(2);
              case "a":
                return pt(J, lt, !0);
              case "A":
                return pt(J, lt, !1);
              case "m":
                return String(lt);
              case "mm":
                return A.s(lt, 2, "0");
              case "s":
                return String($.$s);
              case "ss":
                return A.s($.$s, 2, "0");
              case "SSS":
                return A.s($.$ms, 3, "0");
              case "Z":
                return U;
            }
            return null;
          }(ut) || U.replace(":", "");
        });
      }, M.utcOffset = function() {
        return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
      }, M.diff = function(T, $, L) {
        var N, U = this, J = A.p($), lt = E(T), ft = (lt.utcOffset() - this.utcOffset()) * i, yt = this - lt, Mt = function() {
          return A.m(U, lt);
        };
        switch (J) {
          case p:
            N = Mt() / 12;
            break;
          case u:
            N = Mt();
            break;
          case f:
            N = Mt() / 3;
            break;
          case h:
            N = (yt - ft) / 6048e5;
            break;
          case c:
            N = (yt - ft) / 864e5;
            break;
          case l:
            N = yt / n;
            break;
          case s:
            N = yt / i;
            break;
          case o:
            N = yt / r;
            break;
          default:
            N = yt;
        }
        return L ? N : A.a(N);
      }, M.daysInMonth = function() {
        return this.endOf(u).$D;
      }, M.$locale = function() {
        return C[this.$L];
      }, M.locale = function(T, $) {
        if (!T) return this.$L;
        var L = this.clone(), N = R(T, $, !0);
        return N && (L.$L = N), L;
      }, M.clone = function() {
        return A.w(this.$d, this);
      }, M.toDate = function() {
        return new Date(this.valueOf());
      }, M.toJSON = function() {
        return this.isValid() ? this.toISOString() : null;
      }, M.toISOString = function() {
        return this.$d.toISOString();
      }, M.toString = function() {
        return this.$d.toUTCString();
      }, B;
    }(), O = P.prototype;
    return E.prototype = O, [["$ms", a], ["$s", o], ["$m", s], ["$H", l], ["$W", c], ["$M", u], ["$y", p], ["$D", g]].forEach(function(B) {
      O[B[1]] = function(M) {
        return this.$g(M, B[0], B[1]);
      };
    }), E.extend = function(B, M) {
      return B.$i || (B(M, P, E), B.$i = !0), E;
    }, E.locale = R, E.isDayjs = D, E.unix = function(B) {
      return E(1e3 * B);
    }, E.en = C[w], E.Ls = C, E.p = {}, E;
  });
})(Rl);
var Qd = Rl.exports;
const Jd = /* @__PURE__ */ Zd(Qd), Mi = {
  /* CLAMP */
  min: {
    r: 0,
    g: 0,
    b: 0,
    s: 0,
    l: 0,
    a: 0
  },
  max: {
    r: 255,
    g: 255,
    b: 255,
    h: 360,
    s: 100,
    l: 100,
    a: 1
  },
  clamp: {
    r: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    g: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    b: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    h: (e) => e % 360,
    s: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    l: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    a: (e) => e >= 1 ? 1 : e < 0 ? 0 : e
  },
  /* CONVERSION */
  //SOURCE: https://planetcalc.com/7779
  toLinear: (e) => {
    const t = e / 255;
    return e > 0.03928 ? Math.pow((t + 0.055) / 1.055, 2.4) : t / 12.92;
  },
  //SOURCE: https://gist.github.com/mjackson/5311256
  hue2rgb: (e, t, r) => (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (t - e) * 6 * r : r < 1 / 2 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e),
  hsl2rgb: ({ h: e, s: t, l: r }, i) => {
    if (!t)
      return r * 2.55;
    e /= 360, t /= 100, r /= 100;
    const n = r < 0.5 ? r * (1 + t) : r + t - r * t, a = 2 * r - n;
    switch (i) {
      case "r":
        return Mi.hue2rgb(a, n, e + 1 / 3) * 255;
      case "g":
        return Mi.hue2rgb(a, n, e) * 255;
      case "b":
        return Mi.hue2rgb(a, n, e - 1 / 3) * 255;
    }
  },
  rgb2hsl: ({ r: e, g: t, b: r }, i) => {
    e /= 255, t /= 255, r /= 255;
    const n = Math.max(e, t, r), a = Math.min(e, t, r), o = (n + a) / 2;
    if (i === "l")
      return o * 100;
    if (n === a)
      return 0;
    const s = n - a, l = o > 0.5 ? s / (2 - n - a) : s / (n + a);
    if (i === "s")
      return l * 100;
    switch (n) {
      case e:
        return ((t - r) / s + (t < r ? 6 : 0)) * 60;
      case t:
        return ((r - e) / s + 2) * 60;
      case r:
        return ((e - t) / s + 4) * 60;
      default:
        return -1;
    }
  }
}, tg = {
  /* API */
  clamp: (e, t, r) => t > r ? Math.min(t, Math.max(r, e)) : Math.min(r, Math.max(t, e)),
  round: (e) => Math.round(e * 1e10) / 1e10
}, eg = {
  /* API */
  dec2hex: (e) => {
    const t = Math.round(e).toString(16);
    return t.length > 1 ? t : `0${t}`;
  }
}, K = {
  channel: Mi,
  lang: tg,
  unit: eg
}, be = {};
for (let e = 0; e <= 255; e++)
  be[e] = K.unit.dec2hex(e);
const St = {
  ALL: 0,
  RGB: 1,
  HSL: 2
};
class rg {
  constructor() {
    this.type = St.ALL;
  }
  /* API */
  get() {
    return this.type;
  }
  set(t) {
    if (this.type && this.type !== t)
      throw new Error("Cannot change both RGB and HSL channels at the same time");
    this.type = t;
  }
  reset() {
    this.type = St.ALL;
  }
  is(t) {
    return this.type === t;
  }
}
class ig {
  /* CONSTRUCTOR */
  constructor(t, r) {
    this.color = r, this.changed = !1, this.data = t, this.type = new rg();
  }
  /* API */
  set(t, r) {
    return this.color = r, this.changed = !1, this.data = t, this.type.type = St.ALL, this;
  }
  /* HELPERS */
  _ensureHSL() {
    const t = this.data, { h: r, s: i, l: n } = t;
    r === void 0 && (t.h = K.channel.rgb2hsl(t, "h")), i === void 0 && (t.s = K.channel.rgb2hsl(t, "s")), n === void 0 && (t.l = K.channel.rgb2hsl(t, "l"));
  }
  _ensureRGB() {
    const t = this.data, { r, g: i, b: n } = t;
    r === void 0 && (t.r = K.channel.hsl2rgb(t, "r")), i === void 0 && (t.g = K.channel.hsl2rgb(t, "g")), n === void 0 && (t.b = K.channel.hsl2rgb(t, "b"));
  }
  /* GETTERS */
  get r() {
    const t = this.data, r = t.r;
    return !this.type.is(St.HSL) && r !== void 0 ? r : (this._ensureHSL(), K.channel.hsl2rgb(t, "r"));
  }
  get g() {
    const t = this.data, r = t.g;
    return !this.type.is(St.HSL) && r !== void 0 ? r : (this._ensureHSL(), K.channel.hsl2rgb(t, "g"));
  }
  get b() {
    const t = this.data, r = t.b;
    return !this.type.is(St.HSL) && r !== void 0 ? r : (this._ensureHSL(), K.channel.hsl2rgb(t, "b"));
  }
  get h() {
    const t = this.data, r = t.h;
    return !this.type.is(St.RGB) && r !== void 0 ? r : (this._ensureRGB(), K.channel.rgb2hsl(t, "h"));
  }
  get s() {
    const t = this.data, r = t.s;
    return !this.type.is(St.RGB) && r !== void 0 ? r : (this._ensureRGB(), K.channel.rgb2hsl(t, "s"));
  }
  get l() {
    const t = this.data, r = t.l;
    return !this.type.is(St.RGB) && r !== void 0 ? r : (this._ensureRGB(), K.channel.rgb2hsl(t, "l"));
  }
  get a() {
    return this.data.a;
  }
  /* SETTERS */
  set r(t) {
    this.type.set(St.RGB), this.changed = !0, this.data.r = t;
  }
  set g(t) {
    this.type.set(St.RGB), this.changed = !0, this.data.g = t;
  }
  set b(t) {
    this.type.set(St.RGB), this.changed = !0, this.data.b = t;
  }
  set h(t) {
    this.type.set(St.HSL), this.changed = !0, this.data.h = t;
  }
  set s(t) {
    this.type.set(St.HSL), this.changed = !0, this.data.s = t;
  }
  set l(t) {
    this.type.set(St.HSL), this.changed = !0, this.data.l = t;
  }
  set a(t) {
    this.changed = !0, this.data.a = t;
  }
}
const Sn = new ig({ r: 0, g: 0, b: 0, a: 0 }, "transparent"), rr = {
  /* VARIABLES */
  re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
  /* API */
  parse: (e) => {
    if (e.charCodeAt(0) !== 35)
      return;
    const t = e.match(rr.re);
    if (!t)
      return;
    const r = t[1], i = parseInt(r, 16), n = r.length, a = n % 4 === 0, o = n > 4, s = o ? 1 : 17, l = o ? 8 : 4, c = a ? 0 : -1, h = o ? 255 : 15;
    return Sn.set({
      r: (i >> l * (c + 3) & h) * s,
      g: (i >> l * (c + 2) & h) * s,
      b: (i >> l * (c + 1) & h) * s,
      a: a ? (i & h) * s / 255 : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `#${be[Math.round(t)]}${be[Math.round(r)]}${be[Math.round(i)]}${be[Math.round(n * 255)]}` : `#${be[Math.round(t)]}${be[Math.round(r)]}${be[Math.round(i)]}`;
  }
}, Ee = {
  /* VARIABLES */
  re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
  hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
  /* HELPERS */
  _hue2deg: (e) => {
    const t = e.match(Ee.hueRe);
    if (t) {
      const [, r, i] = t;
      switch (i) {
        case "grad":
          return K.channel.clamp.h(parseFloat(r) * 0.9);
        case "rad":
          return K.channel.clamp.h(parseFloat(r) * 180 / Math.PI);
        case "turn":
          return K.channel.clamp.h(parseFloat(r) * 360);
      }
    }
    return K.channel.clamp.h(parseFloat(e));
  },
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 104 && t !== 72)
      return;
    const r = e.match(Ee.re);
    if (!r)
      return;
    const [, i, n, a, o, s] = r;
    return Sn.set({
      h: Ee._hue2deg(i),
      s: K.channel.clamp.s(parseFloat(n)),
      l: K.channel.clamp.l(parseFloat(a)),
      a: o ? K.channel.clamp.a(s ? parseFloat(o) / 100 : parseFloat(o)) : 1
    }, e);
  },
  stringify: (e) => {
    const { h: t, s: r, l: i, a: n } = e;
    return n < 1 ? `hsla(${K.lang.round(t)}, ${K.lang.round(r)}%, ${K.lang.round(i)}%, ${n})` : `hsl(${K.lang.round(t)}, ${K.lang.round(r)}%, ${K.lang.round(i)}%)`;
  }
}, Yr = {
  /* VARIABLES */
  colors: {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyanaqua: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    transparent: "#00000000",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
  /* API */
  parse: (e) => {
    e = e.toLowerCase();
    const t = Yr.colors[e];
    if (t)
      return rr.parse(t);
  },
  stringify: (e) => {
    const t = rr.stringify(e);
    for (const r in Yr.colors)
      if (Yr.colors[r] === t)
        return r;
  }
}, Pr = {
  /* VARIABLES */
  re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 114 && t !== 82)
      return;
    const r = e.match(Pr.re);
    if (!r)
      return;
    const [, i, n, a, o, s, l, c, h] = r;
    return Sn.set({
      r: K.channel.clamp.r(n ? parseFloat(i) * 2.55 : parseFloat(i)),
      g: K.channel.clamp.g(o ? parseFloat(a) * 2.55 : parseFloat(a)),
      b: K.channel.clamp.b(l ? parseFloat(s) * 2.55 : parseFloat(s)),
      a: c ? K.channel.clamp.a(h ? parseFloat(c) / 100 : parseFloat(c)) : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `rgba(${K.lang.round(t)}, ${K.lang.round(r)}, ${K.lang.round(i)}, ${K.lang.round(n)})` : `rgb(${K.lang.round(t)}, ${K.lang.round(r)}, ${K.lang.round(i)})`;
  }
}, ee = {
  /* VARIABLES */
  format: {
    keyword: Yr,
    hex: rr,
    rgb: Pr,
    rgba: Pr,
    hsl: Ee,
    hsla: Ee
  },
  /* API */
  parse: (e) => {
    if (typeof e != "string")
      return e;
    const t = rr.parse(e) || Pr.parse(e) || Ee.parse(e) || Yr.parse(e);
    if (t)
      return t;
    throw new Error(`Unsupported color format: "${e}"`);
  },
  stringify: (e) => !e.changed && e.color ? e.color : e.type.is(St.HSL) || e.data.r === void 0 ? Ee.stringify(e) : e.a < 1 || !Number.isInteger(e.r) || !Number.isInteger(e.g) || !Number.isInteger(e.b) ? Pr.stringify(e) : rr.stringify(e)
}, Il = (e, t) => {
  const r = ee.parse(e);
  for (const i in t)
    r[i] = K.channel.clamp[i](t[i]);
  return ee.stringify(r);
}, Gr = (e, t, r = 0, i = 1) => {
  if (typeof e != "number")
    return Il(e, { a: t });
  const n = Sn.set({
    r: K.channel.clamp.r(e),
    g: K.channel.clamp.g(t),
    b: K.channel.clamp.b(r),
    a: K.channel.clamp.a(i)
  });
  return ee.stringify(n);
}, ng = (e) => {
  const { r: t, g: r, b: i } = ee.parse(e), n = 0.2126 * K.channel.toLinear(t) + 0.7152 * K.channel.toLinear(r) + 0.0722 * K.channel.toLinear(i);
  return K.lang.round(n);
}, ag = (e) => ng(e) >= 0.5, ci = (e) => !ag(e), Pl = (e, t, r) => {
  const i = ee.parse(e), n = i[t], a = K.channel.clamp[t](n + r);
  return n !== a && (i[t] = a), ee.stringify(i);
}, z = (e, t) => Pl(e, "l", t), X = (e, t) => Pl(e, "l", -t), k = (e, t) => {
  const r = ee.parse(e), i = {};
  for (const n in t)
    t[n] && (i[n] = r[n] + t[n]);
  return Il(e, i);
}, sg = (e, t, r = 50) => {
  const { r: i, g: n, b: a, a: o } = ee.parse(e), { r: s, g: l, b: c, a: h } = ee.parse(t), u = r / 100, f = u * 2 - 1, p = o - h, m = ((f * p === -1 ? f : (f + p) / (1 + f * p)) + 1) / 2, y = 1 - m, x = i * m + s * y, b = n * m + l * y, _ = a * m + c * y, S = o * u + h * (1 - u);
  return Gr(x, b, _, S);
}, I = (e, t = 100) => {
  const r = ee.parse(e);
  return r.r = 255 - r.r, r.g = 255 - r.g, r.b = 255 - r.b, sg(r, e, t);
};
var Nl = Object.defineProperty, d = (e, t) => Nl(e, "name", { value: t, configurable: !0 }), og = (e, t) => {
  for (var r in t)
    Nl(e, r, { get: t[r], enumerable: !0 });
}, ae = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  fatal: 5
}, F = {
  trace: /* @__PURE__ */ d((...e) => {
  }, "trace"),
  debug: /* @__PURE__ */ d((...e) => {
  }, "debug"),
  info: /* @__PURE__ */ d((...e) => {
  }, "info"),
  warn: /* @__PURE__ */ d((...e) => {
  }, "warn"),
  error: /* @__PURE__ */ d((...e) => {
  }, "error"),
  fatal: /* @__PURE__ */ d((...e) => {
  }, "fatal")
}, hs = /* @__PURE__ */ d(function(e = "fatal") {
  let t = ae.fatal;
  typeof e == "string" ? e.toLowerCase() in ae && (t = ae[e]) : typeof e == "number" && (t = e), F.trace = () => {
  }, F.debug = () => {
  }, F.info = () => {
  }, F.warn = () => {
  }, F.error = () => {
  }, F.fatal = () => {
  }, t <= ae.fatal && (F.fatal = console.error ? console.error.bind(console, Wt("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", Wt("FATAL"))), t <= ae.error && (F.error = console.error ? console.error.bind(console, Wt("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", Wt("ERROR"))), t <= ae.warn && (F.warn = console.warn ? console.warn.bind(console, Wt("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", Wt("WARN"))), t <= ae.info && (F.info = console.info ? console.info.bind(console, Wt("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", Wt("INFO"))), t <= ae.debug && (F.debug = console.debug ? console.debug.bind(console, Wt("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Wt("DEBUG"))), t <= ae.trace && (F.trace = console.debug ? console.debug.bind(console, Wt("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Wt("TRACE")));
}, "setLogLevel"), Wt = /* @__PURE__ */ d((e) => `%c${Jd().format("ss.SSS")} : ${e} : `, "format"), zl = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s, Ur = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, lg = /\s*%%.*\n/gm, ar, ql = (ar = class extends Error {
  constructor(t) {
    super(t), this.name = "UnknownDiagramError";
  }
}, d(ar, "UnknownDiagramError"), ar), dr = {}, us = /* @__PURE__ */ d(function(e, t) {
  e = e.replace(zl, "").replace(Ur, "").replace(lg, `
`);
  for (const [r, { detector: i }] of Object.entries(dr))
    if (i(e, t))
      return r;
  throw new ql(
    `No diagram type detected matching given configuration for text: ${e}`
  );
}, "detectType"), ga = /* @__PURE__ */ d((...e) => {
  for (const { id: t, detector: r, loader: i } of e)
    Wl(t, r, i);
}, "registerLazyLoadedDiagrams"), Wl = /* @__PURE__ */ d((e, t, r) => {
  dr[e] && F.warn(`Detector with key ${e} already exists. Overwriting.`), dr[e] = { detector: t, loader: r }, F.debug(`Detector with key ${e} added${r ? " with loader" : ""}`);
}, "addDetector"), cg = /* @__PURE__ */ d((e) => dr[e].loader, "getDiagramLoader"), ma = /* @__PURE__ */ d((e, t, { depth: r = 2, clobber: i = !1 } = {}) => {
  const n = { depth: r, clobber: i };
  return Array.isArray(t) && !Array.isArray(e) ? (t.forEach((a) => ma(e, a, n)), e) : Array.isArray(t) && Array.isArray(e) ? (t.forEach((a) => {
    e.includes(a) || e.push(a);
  }), e) : e === void 0 || r <= 0 ? e != null && typeof e == "object" && typeof t == "object" ? Object.assign(e, t) : t : (t !== void 0 && typeof e == "object" && typeof t == "object" && Object.keys(t).forEach((a) => {
    typeof t[a] == "object" && (e[a] === void 0 || typeof e[a] == "object") ? (e[a] === void 0 && (e[a] = Array.isArray(t[a]) ? [] : {}), e[a] = ma(e[a], t[a], { depth: r - 1, clobber: i })) : (i || typeof e[a] != "object" && typeof t[a] != "object") && (e[a] = t[a]);
  }), e);
}, "assignWithDepth"), kt = ma, Tn = "#ffffff", Bn = "#f2f2f2", At = /* @__PURE__ */ d((e, t) => t ? k(e, { s: -40, l: 10 }) : k(e, { s: -40, l: -10 }), "mkBorder"), sr, hg = (sr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#fff4dd", this.noteBkgColor = "#fff5ad", this.noteTextColor = "#333", this.THEME_COLOR_LIMIT = 12, this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px";
  }
  updateColors() {
    var r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, S, w, C;
    if (this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333"), this.secondaryColor = this.secondaryColor || k(this.primaryColor, { h: -120 }), this.tertiaryColor = this.tertiaryColor || k(this.primaryColor, { h: 180, l: 5 }), this.primaryBorderColor = this.primaryBorderColor || At(this.primaryColor, this.darkMode), this.secondaryBorderColor = this.secondaryBorderColor || At(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = this.tertiaryBorderColor || At(this.tertiaryColor, this.darkMode), this.noteBorderColor = this.noteBorderColor || At(this.noteBkgColor, this.darkMode), this.noteBkgColor = this.noteBkgColor || "#fff5ad", this.noteTextColor = this.noteTextColor || "#333", this.secondaryTextColor = this.secondaryTextColor || I(this.secondaryColor), this.tertiaryTextColor = this.tertiaryTextColor || I(this.tertiaryColor), this.lineColor = this.lineColor || I(this.background), this.arrowheadColor = this.arrowheadColor || I(this.background), this.textColor = this.textColor || this.primaryTextColor, this.border2 = this.border2 || this.tertiaryBorderColor, this.nodeBkg = this.nodeBkg || this.primaryColor, this.mainBkg = this.mainBkg || this.primaryColor, this.nodeBorder = this.nodeBorder || this.primaryBorderColor, this.clusterBkg = this.clusterBkg || this.tertiaryColor, this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor, this.defaultLinkColor = this.defaultLinkColor || this.lineColor, this.titleColor = this.titleColor || this.tertiaryTextColor, this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? X(this.secondaryColor, 30) : this.secondaryColor), this.nodeTextColor = this.nodeTextColor || this.primaryTextColor, this.actorBorder = this.actorBorder || this.primaryBorderColor, this.actorBkg = this.actorBkg || this.mainBkg, this.actorTextColor = this.actorTextColor || this.primaryTextColor, this.actorLineColor = this.actorLineColor || this.actorBorder, this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg, this.signalColor = this.signalColor || this.textColor, this.signalTextColor = this.signalTextColor || this.textColor, this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder, this.labelTextColor = this.labelTextColor || this.actorTextColor, this.loopTextColor = this.loopTextColor || this.actorTextColor, this.activationBorderColor = this.activationBorderColor || X(this.secondaryColor, 10), this.activationBkgColor = this.activationBkgColor || this.secondaryColor, this.sequenceNumberColor = this.sequenceNumberColor || I(this.lineColor), this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor, this.altSectionBkgColor = this.altSectionBkgColor || "white", this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor, this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor, this.excludeBkgColor = this.excludeBkgColor || "#eeeeee", this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor, this.taskBkgColor = this.taskBkgColor || this.primaryColor, this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor, this.activeTaskBkgColor = this.activeTaskBkgColor || z(this.primaryColor, 23), this.gridColor = this.gridColor || "lightgrey", this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey", this.doneTaskBorderColor = this.doneTaskBorderColor || "grey", this.critBorderColor = this.critBorderColor || "#ff8888", this.critBkgColor = this.critBkgColor || "red", this.todayLineColor = this.todayLineColor || "red", this.vertLineColor = this.vertLineColor || "navy", this.taskTextColor = this.taskTextColor || this.textColor, this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor, this.taskTextLightColor = this.taskTextLightColor || this.textColor, this.taskTextColor = this.taskTextColor || this.primaryTextColor, this.taskTextDarkColor = this.taskTextDarkColor || this.textColor, this.taskTextClickableColor = this.taskTextClickableColor || "#003163", this.personBorder = this.personBorder || this.primaryBorderColor, this.personBkg = this.personBkg || this.mainBkg, this.darkMode ? (this.rowOdd = this.rowOdd || X(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || X(this.mainBkg, 10)) : (this.rowOdd = this.rowOdd || z(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || z(this.mainBkg, 5)), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || this.tertiaryColor, this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.specialStateColor = this.lineColor, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || k(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || k(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || k(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || k(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || k(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || k(this.primaryColor, { h: 210, l: 150 }), this.cScale9 = this.cScale9 || k(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || k(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || k(this.primaryColor, { h: 330 }), this.darkMode)
      for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
        this["cScale" + v] = X(this["cScale" + v], 75);
    else
      for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
        this["cScale" + v] = X(this["cScale" + v], 25);
    for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
      this["cScaleInv" + v] = this["cScaleInv" + v] || I(this["cScale" + v]);
    for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
      this.darkMode ? this["cScalePeer" + v] = this["cScalePeer" + v] || z(this["cScale" + v], 10) : this["cScalePeer" + v] = this["cScalePeer" + v] || X(this["cScale" + v], 10);
    this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
    for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
      this["cScaleLabel" + v] = this["cScaleLabel" + v] || this.scaleLabelColor;
    const t = this.darkMode ? -4 : -1;
    for (let v = 0; v < 5; v++)
      this["surface" + v] = this["surface" + v] || k(this.mainBkg, { h: 180, s: -15, l: t * (5 + v * 3) }), this["surfacePeer" + v] = this["surfacePeer" + v] || k(this.mainBkg, { h: 180, s: -15, l: t * (8 + v * 3) });
    this.classText = this.classText || this.textColor, this.fillType0 = this.fillType0 || this.primaryColor, this.fillType1 = this.fillType1 || this.secondaryColor, this.fillType2 = this.fillType2 || k(this.primaryColor, { h: 64 }), this.fillType3 = this.fillType3 || k(this.secondaryColor, { h: 64 }), this.fillType4 = this.fillType4 || k(this.primaryColor, { h: -64 }), this.fillType5 = this.fillType5 || k(this.secondaryColor, { h: -64 }), this.fillType6 = this.fillType6 || k(this.primaryColor, { h: 128 }), this.fillType7 = this.fillType7 || k(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || k(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || k(this.secondaryColor, { l: -10 }), this.pie6 = this.pie6 || k(this.tertiaryColor, { l: -10 }), this.pie7 = this.pie7 || k(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || k(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || k(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || k(this.primaryColor, { h: 60, l: -20 }), this.pie11 = this.pie11 || k(this.primaryColor, { h: -60, l: -20 }), this.pie12 = this.pie12 || k(this.primaryColor, { h: 120, l: -10 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.radar = {
      axisColor: ((r = this.radar) == null ? void 0 : r.axisColor) || this.lineColor,
      axisStrokeWidth: ((i = this.radar) == null ? void 0 : i.axisStrokeWidth) || 2,
      axisLabelFontSize: ((n = this.radar) == null ? void 0 : n.axisLabelFontSize) || 12,
      curveOpacity: ((a = this.radar) == null ? void 0 : a.curveOpacity) || 0.5,
      curveStrokeWidth: ((o = this.radar) == null ? void 0 : o.curveStrokeWidth) || 2,
      graticuleColor: ((s = this.radar) == null ? void 0 : s.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((l = this.radar) == null ? void 0 : l.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((c = this.radar) == null ? void 0 : c.graticuleOpacity) || 0.3,
      legendBoxSize: ((h = this.radar) == null ? void 0 : h.legendBoxSize) || 12,
      legendFontSize: ((u = this.radar) == null ? void 0 : u.legendFontSize) || 12
    }, this.archEdgeColor = this.archEdgeColor || "#777", this.archEdgeArrowColor = this.archEdgeArrowColor || "#777", this.archEdgeWidth = this.archEdgeWidth || "3", this.archGroupBorderColor = this.archGroupBorderColor || "#000", this.archGroupBorderWidth = this.archGroupBorderWidth || "2px", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || k(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || k(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || k(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || k(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || k(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || k(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ci(this.quadrant1Fill) ? z(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((f = this.xyChart) == null ? void 0 : f.backgroundColor) || this.background,
      titleColor: ((p = this.xyChart) == null ? void 0 : p.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((g = this.xyChart) == null ? void 0 : g.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((m = this.xyChart) == null ? void 0 : m.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((y = this.xyChart) == null ? void 0 : y.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((x = this.xyChart) == null ? void 0 : x.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((b = this.xyChart) == null ? void 0 : b.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((S = this.xyChart) == null ? void 0 : S.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((w = this.xyChart) == null ? void 0 : w.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((C = this.xyChart) == null ? void 0 : C.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? X(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || k(this.primaryColor, { h: -30 }), this.git4 = this.git4 || k(this.primaryColor, { h: -60 }), this.git5 = this.git5 || k(this.primaryColor, { h: -90 }), this.git6 = this.git6 || k(this.primaryColor, { h: 60 }), this.git7 = this.git7 || k(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = z(this.git0, 25), this.git1 = z(this.git1, 25), this.git2 = z(this.git2, 25), this.git3 = z(this.git3, 25), this.git4 = z(this.git4, 25), this.git5 = z(this.git5, 25), this.git6 = z(this.git6, 25), this.git7 = z(this.git7, 25)) : (this.git0 = X(this.git0, 25), this.git1 = X(this.git1, 25), this.git2 = X(this.git2, 25), this.git3 = X(this.git3, 25), this.git4 = X(this.git4, 25), this.git5 = X(this.git5, 25), this.git6 = X(this.git6, 25), this.git7 = X(this.git7, 25)), this.gitInv0 = this.gitInv0 || I(this.git0), this.gitInv1 = this.gitInv1 || I(this.git1), this.gitInv2 = this.gitInv2 || I(this.git2), this.gitInv3 = this.gitInv3 || I(this.git3), this.gitInv4 = this.gitInv4 || I(this.git4), this.gitInv5 = this.gitInv5 || I(this.git5), this.gitInv6 = this.gitInv6 || I(this.git6), this.gitInv7 = this.gitInv7 || I(this.git7), this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor, this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor, this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor, this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Tn, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Bn;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(sr, "Theme"), sr), ug = /* @__PURE__ */ d((e) => {
  const t = new hg();
  return t.calculate(e), t;
}, "getThemeVariables"), or, fg = (or = class {
  constructor() {
    this.background = "#333", this.primaryColor = "#1f2020", this.secondaryColor = z(this.primaryColor, 16), this.tertiaryColor = k(this.primaryColor, { h: -160 }), this.primaryBorderColor = I(this.background), this.secondaryBorderColor = At(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = At(this.tertiaryColor, this.darkMode), this.primaryTextColor = I(this.primaryColor), this.secondaryTextColor = I(this.secondaryColor), this.tertiaryTextColor = I(this.tertiaryColor), this.lineColor = I(this.background), this.textColor = I(this.background), this.mainBkg = "#1f2020", this.secondBkg = "calculated", this.mainContrastColor = "lightgrey", this.darkTextColor = z(I("#323D47"), 10), this.lineColor = "calculated", this.border1 = "#ccc", this.border2 = Gr(255, 255, 255, 0.25), this.arrowheadColor = "calculated", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "#181818", this.textColor = "#ccc", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#F9FFFE", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "calculated", this.activationBkgColor = "calculated", this.sequenceNumberColor = "black", this.sectionBkgColor = X("#EAE8D9", 30), this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "#EAE8D9", this.excludeBkgColor = X(this.sectionBkgColor, 10), this.taskBorderColor = Gr(255, 255, 255, 70), this.taskBkgColor = "calculated", this.taskTextColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = Gr(255, 255, 255, 50), this.activeTaskBkgColor = "#81B1DB", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "grey", this.critBorderColor = "#E83737", this.critBkgColor = "#E83737", this.taskTextDarkColor = "calculated", this.todayLineColor = "#DB5757", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || z(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || X(this.mainBkg, 10), this.labelColor = "calculated", this.errorBkgColor = "#a44141", this.errorTextColor = "#ddd";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, S, w;
    this.secondBkg = z(this.mainBkg, 16), this.lineColor = this.mainContrastColor, this.arrowheadColor = this.mainContrastColor, this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.edgeLabelBackground = z(this.labelBackground, 25), this.actorBorder = this.border1, this.actorBkg = this.mainBkg, this.actorTextColor = this.mainContrastColor, this.actorLineColor = this.actorBorder, this.signalColor = this.mainContrastColor, this.signalTextColor = this.mainContrastColor, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.mainContrastColor, this.loopTextColor = this.mainContrastColor, this.noteBorderColor = this.secondaryBorderColor, this.noteBkgColor = this.secondBkg, this.noteTextColor = this.secondaryTextColor, this.activationBorderColor = this.border1, this.activationBkgColor = this.secondBkg, this.altSectionBkgColor = this.background, this.taskBkgColor = z(this.mainBkg, 23), this.taskTextColor = this.darkTextColor, this.taskTextLightColor = this.mainContrastColor, this.taskTextOutsideColor = this.taskTextLightColor, this.gridColor = this.mainContrastColor, this.doneTaskBkgColor = this.mainContrastColor, this.taskTextDarkColor = this.darkTextColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#555", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#f4f4f4", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = k(this.primaryColor, { h: 64 }), this.fillType3 = k(this.secondaryColor, { h: 64 }), this.fillType4 = k(this.primaryColor, { h: -64 }), this.fillType5 = k(this.secondaryColor, { h: -64 }), this.fillType6 = k(this.primaryColor, { h: 128 }), this.fillType7 = k(this.secondaryColor, { h: 128 }), this.cScale1 = this.cScale1 || "#0b0000", this.cScale2 = this.cScale2 || "#4d1037", this.cScale3 = this.cScale3 || "#3f5258", this.cScale4 = this.cScale4 || "#4f2f1b", this.cScale5 = this.cScale5 || "#6e0a0a", this.cScale6 = this.cScale6 || "#3b0048", this.cScale7 = this.cScale7 || "#995a01", this.cScale8 = this.cScale8 || "#154706", this.cScale9 = this.cScale9 || "#161722", this.cScale10 = this.cScale10 || "#00296f", this.cScale11 = this.cScale11 || "#01629c", this.cScale12 = this.cScale12 || "#010029", this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || k(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || k(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || k(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || k(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || k(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || k(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || k(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || k(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || k(this.primaryColor, { h: 330 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || I(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScalePeer" + C] = this["cScalePeer" + C] || z(this["cScale" + C], 10);
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || k(this.mainBkg, { h: 30, s: -30, l: -(-10 + C * 4) }), this["surfacePeer" + C] = this["surfacePeer" + C] || k(this.mainBkg, { h: 30, s: -30, l: -(-7 + C * 4) });
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || k(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || k(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || k(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || k(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || k(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || k(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ci(this.quadrant1Fill) ? z(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
    }, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.background
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((y = this.radar) == null ? void 0 : y.curveStrokeWidth) || 2,
      graticuleColor: ((x = this.radar) == null ? void 0 : x.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((S = this.radar) == null ? void 0 : S.legendBoxSize) || 12,
      legendFontSize: ((w = this.radar) == null ? void 0 : w.legendFontSize) || 12
    }, this.classText = this.primaryTextColor, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? X(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = z(this.secondaryColor, 20), this.git1 = z(this.pie2 || this.secondaryColor, 20), this.git2 = z(this.pie3 || this.tertiaryColor, 20), this.git3 = z(this.pie4 || k(this.primaryColor, { h: -30 }), 20), this.git4 = z(this.pie5 || k(this.primaryColor, { h: -60 }), 20), this.git5 = z(this.pie6 || k(this.primaryColor, { h: -90 }), 10), this.git6 = z(this.pie7 || k(this.primaryColor, { h: 60 }), 10), this.git7 = z(this.pie8 || k(this.primaryColor, { h: 120 }), 20), this.gitInv0 = this.gitInv0 || I(this.git0), this.gitInv1 = this.gitInv1 || I(this.git1), this.gitInv2 = this.gitInv2 || I(this.git2), this.gitInv3 = this.gitInv3 || I(this.git3), this.gitInv4 = this.gitInv4 || I(this.git4), this.gitInv5 = this.gitInv5 || I(this.git5), this.gitInv6 = this.gitInv6 || I(this.git6), this.gitInv7 = this.gitInv7 || I(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || I(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || I(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || z(this.background, 12), this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || z(this.background, 2), this.nodeBorder = this.nodeBorder || "#999";
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(or, "Theme"), or), pg = /* @__PURE__ */ d((e) => {
  const t = new fg();
  return t.calculate(e), t;
}, "getThemeVariables"), lr, dg = (lr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#ECECFF", this.secondaryColor = k(this.primaryColor, { h: 120 }), this.secondaryColor = "#ffffde", this.tertiaryColor = k(this.primaryColor, { h: -160 }), this.primaryBorderColor = At(this.primaryColor, this.darkMode), this.secondaryBorderColor = At(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = At(this.tertiaryColor, this.darkMode), this.primaryTextColor = I(this.primaryColor), this.secondaryTextColor = I(this.secondaryColor), this.tertiaryTextColor = I(this.tertiaryColor), this.lineColor = I(this.background), this.textColor = I(this.background), this.background = "white", this.mainBkg = "#ECECFF", this.secondBkg = "#ffffde", this.lineColor = "#333333", this.border1 = "#9370DB", this.border2 = "#aaaa33", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "rgba(232,232,232, 0.8)", this.textColor = "#333", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = this.taskTextDarkColor, this.taskTextClickableColor = "calculated", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBorderColor = "calculated", this.critBkgColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.sectionBkgColor = Gr(102, 102, 255, 0.49), this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#fff400", this.taskBorderColor = "#534fbc", this.taskBkgColor = "#8a90dd", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "#534fbc", this.activeTaskBkgColor = "#bfc7ff", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "navy", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = "calculated", this.rowEven = "calculated", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222", this.updateColors();
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, S, w;
    this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || k(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || k(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || k(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || k(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || k(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || k(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || k(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || k(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || k(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || X(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || X(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = X(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || X(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || k(this["cScale" + C], { h: 180 });
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || k(this.mainBkg, { h: 30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || k(this.mainBkg, { h: 30, l: -(7 + C * 5) });
    if (this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor, this.labelTextColor !== "calculated") {
      this.cScaleLabel0 = this.cScaleLabel0 || I(this.labelTextColor), this.cScaleLabel3 = this.cScaleLabel3 || I(this.labelTextColor);
      for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
        this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.labelTextColor;
    }
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.textColor, this.edgeLabelBackground = this.labelBackground, this.actorBorder = z(this.border1, 23), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.signalColor = this.textColor, this.signalTextColor = this.textColor, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || z(this.primaryColor, 75) || "#ffffff", this.rowEven = this.rowEven || z(this.primaryColor, 1), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = k(this.primaryColor, { h: 64 }), this.fillType3 = k(this.secondaryColor, { h: 64 }), this.fillType4 = k(this.primaryColor, { h: -64 }), this.fillType5 = k(this.secondaryColor, { h: -64 }), this.fillType6 = k(this.primaryColor, { h: 128 }), this.fillType7 = k(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || k(this.tertiaryColor, { l: -40 }), this.pie4 = this.pie4 || k(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || k(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || k(this.tertiaryColor, { l: -20 }), this.pie7 = this.pie7 || k(this.primaryColor, { h: 60, l: -20 }), this.pie8 = this.pie8 || k(this.primaryColor, { h: -60, l: -40 }), this.pie9 = this.pie9 || k(this.primaryColor, { h: 120, l: -40 }), this.pie10 = this.pie10 || k(this.primaryColor, { h: 60, l: -40 }), this.pie11 = this.pie11 || k(this.primaryColor, { h: -90, l: -40 }), this.pie12 = this.pie12 || k(this.primaryColor, { h: 120, l: -30 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || k(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || k(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || k(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || k(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || k(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || k(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ci(this.quadrant1Fill) ? z(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((x = this.xyChart) == null ? void 0 : x.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((S = this.xyChart) == null ? void 0 : S.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((w = this.xyChart) == null ? void 0 : w.plotColorPalette) || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.labelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || k(this.primaryColor, { h: -30 }), this.git4 = this.git4 || k(this.primaryColor, { h: -60 }), this.git5 = this.git5 || k(this.primaryColor, { h: -90 }), this.git6 = this.git6 || k(this.primaryColor, { h: 60 }), this.git7 = this.git7 || k(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = z(this.git0, 25), this.git1 = z(this.git1, 25), this.git2 = z(this.git2, 25), this.git3 = z(this.git3, 25), this.git4 = z(this.git4, 25), this.git5 = z(this.git5, 25), this.git6 = z(this.git6, 25), this.git7 = z(this.git7, 25)) : (this.git0 = X(this.git0, 25), this.git1 = X(this.git1, 25), this.git2 = X(this.git2, 25), this.git3 = X(this.git3, 25), this.git4 = X(this.git4, 25), this.git5 = X(this.git5, 25), this.git6 = X(this.git6, 25), this.git7 = X(this.git7, 25)), this.gitInv0 = this.gitInv0 || X(I(this.git0), 25), this.gitInv1 = this.gitInv1 || I(this.git1), this.gitInv2 = this.gitInv2 || I(this.git2), this.gitInv3 = this.gitInv3 || I(this.git3), this.gitInv4 = this.gitInv4 || I(this.git4), this.gitInv5 = this.gitInv5 || I(this.git5), this.gitInv6 = this.gitInv6 || I(this.git6), this.gitInv7 = this.gitInv7 || I(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || I(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || I(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Tn, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Bn;
  }
  calculate(t) {
    if (Object.keys(this).forEach((i) => {
      this[i] === "calculated" && (this[i] = void 0);
    }), typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(lr, "Theme"), lr), gg = /* @__PURE__ */ d((e) => {
  const t = new dg();
  return t.calculate(e), t;
}, "getThemeVariables"), cr, mg = (cr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#cde498", this.secondaryColor = "#cdffb2", this.background = "white", this.mainBkg = "#cde498", this.secondBkg = "#cdffb2", this.lineColor = "green", this.border1 = "#13540c", this.border2 = "#6eaa49", this.arrowheadColor = "green", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.tertiaryColor = z("#cde498", 10), this.primaryBorderColor = At(this.primaryColor, this.darkMode), this.secondaryBorderColor = At(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = At(this.tertiaryColor, this.darkMode), this.primaryTextColor = I(this.primaryColor), this.secondaryTextColor = I(this.secondaryColor), this.tertiaryTextColor = I(this.primaryColor), this.lineColor = I(this.background), this.textColor = I(this.background), this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#333", this.edgeLabelBackground = "#e8e8e8", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "#333", this.signalTextColor = "#333", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "#326932", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "#6eaa49", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#6eaa49", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "#487e3a", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, S, w;
    this.actorBorder = X(this.mainBkg, 20), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || k(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || k(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || k(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || k(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || k(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || k(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || k(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || k(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || k(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || X(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || X(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = X(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || X(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || k(this["cScale" + C], { h: 180 });
    this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || k(this.mainBkg, { h: 30, s: -30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || k(this.mainBkg, { h: 30, s: -30, l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.taskBorderColor = this.border1, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || z(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || z(this.mainBkg, 20), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = k(this.primaryColor, { h: 64 }), this.fillType3 = k(this.secondaryColor, { h: 64 }), this.fillType4 = k(this.primaryColor, { h: -64 }), this.fillType5 = k(this.secondaryColor, { h: -64 }), this.fillType6 = k(this.primaryColor, { h: 128 }), this.fillType7 = k(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || k(this.primaryColor, { l: -30 }), this.pie5 = this.pie5 || k(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || k(this.tertiaryColor, { h: 40, l: -40 }), this.pie7 = this.pie7 || k(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || k(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || k(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || k(this.primaryColor, { h: 60, l: -50 }), this.pie11 = this.pie11 || k(this.primaryColor, { h: -60, l: -50 }), this.pie12 = this.pie12 || k(this.primaryColor, { h: 120, l: -50 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || k(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || k(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || k(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || k(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || k(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || k(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ci(this.quadrant1Fill) ? z(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.mainBkg
    }, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((x = this.xyChart) == null ? void 0 : x.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((S = this.xyChart) == null ? void 0 : S.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((w = this.xyChart) == null ? void 0 : w.plotColorPalette) || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || k(this.primaryColor, { h: -30 }), this.git4 = this.git4 || k(this.primaryColor, { h: -60 }), this.git5 = this.git5 || k(this.primaryColor, { h: -90 }), this.git6 = this.git6 || k(this.primaryColor, { h: 60 }), this.git7 = this.git7 || k(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = z(this.git0, 25), this.git1 = z(this.git1, 25), this.git2 = z(this.git2, 25), this.git3 = z(this.git3, 25), this.git4 = z(this.git4, 25), this.git5 = z(this.git5, 25), this.git6 = z(this.git6, 25), this.git7 = z(this.git7, 25)) : (this.git0 = X(this.git0, 25), this.git1 = X(this.git1, 25), this.git2 = X(this.git2, 25), this.git3 = X(this.git3, 25), this.git4 = X(this.git4, 25), this.git5 = X(this.git5, 25), this.git6 = X(this.git6, 25), this.git7 = X(this.git7, 25)), this.gitInv0 = this.gitInv0 || I(this.git0), this.gitInv1 = this.gitInv1 || I(this.git1), this.gitInv2 = this.gitInv2 || I(this.git2), this.gitInv3 = this.gitInv3 || I(this.git3), this.gitInv4 = this.gitInv4 || I(this.git4), this.gitInv5 = this.gitInv5 || I(this.git5), this.gitInv6 = this.gitInv6 || I(this.git6), this.gitInv7 = this.gitInv7 || I(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || I(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || I(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Tn, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Bn;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(cr, "Theme"), cr), yg = /* @__PURE__ */ d((e) => {
  const t = new mg();
  return t.calculate(e), t;
}, "getThemeVariables"), hr, xg = (hr = class {
  constructor() {
    this.primaryColor = "#eee", this.contrast = "#707070", this.secondaryColor = z(this.contrast, 55), this.background = "#ffffff", this.tertiaryColor = k(this.primaryColor, { h: -160 }), this.primaryBorderColor = At(this.primaryColor, this.darkMode), this.secondaryBorderColor = At(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = At(this.tertiaryColor, this.darkMode), this.primaryTextColor = I(this.primaryColor), this.secondaryTextColor = I(this.secondaryColor), this.tertiaryTextColor = I(this.tertiaryColor), this.lineColor = I(this.background), this.textColor = I(this.background), this.mainBkg = "#eee", this.secondBkg = "calculated", this.lineColor = "#666", this.border1 = "#999", this.border2 = "calculated", this.note = "#ffa", this.text = "#333", this.critical = "#d42", this.done = "#bbb", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "white", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = this.actorBorder, this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "calculated", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBkgColor = "calculated", this.critBorderColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || z(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || "#f4f4f4", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, y, x, b, _, S, w;
    this.secondBkg = z(this.contrast, 55), this.border2 = this.contrast, this.actorBorder = z(this.border1, 23), this.actorBkg = this.mainBkg, this.actorTextColor = this.text, this.actorLineColor = this.actorBorder, this.signalColor = this.text, this.signalTextColor = this.text, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.text, this.loopTextColor = this.text, this.noteBorderColor = "#999", this.noteBkgColor = "#666", this.noteTextColor = "#fff", this.cScale0 = this.cScale0 || "#555", this.cScale1 = this.cScale1 || "#F4F4F4", this.cScale2 = this.cScale2 || "#555", this.cScale3 = this.cScale3 || "#BBB", this.cScale4 = this.cScale4 || "#777", this.cScale5 = this.cScale5 || "#999", this.cScale6 = this.cScale6 || "#DDD", this.cScale7 = this.cScale7 || "#FFF", this.cScale8 = this.cScale8 || "#DDD", this.cScale9 = this.cScale9 || "#BBB", this.cScale10 = this.cScale10 || "#999", this.cScale11 = this.cScale11 || "#777";
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || I(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this.darkMode ? this["cScalePeer" + C] = this["cScalePeer" + C] || z(this["cScale" + C], 10) : this["cScalePeer" + C] = this["cScalePeer" + C] || X(this["cScale" + C], 10);
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1, this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || k(this.mainBkg, { l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || k(this.mainBkg, { l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.text, this.sectionBkgColor = z(this.contrast, 30), this.sectionBkgColor2 = z(this.contrast, 30), this.taskBorderColor = X(this.contrast, 10), this.taskBkgColor = this.contrast, this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = this.text, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.gridColor = z(this.border1, 30), this.doneTaskBkgColor = this.done, this.doneTaskBorderColor = this.lineColor, this.critBkgColor = this.critical, this.critBorderColor = X(this.critBkgColor, 10), this.todayLineColor = this.critBkgColor, this.vertLineColor = this.critBkgColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || "#000", this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f4f4f4", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.stateBorder = this.stateBorder || "#000", this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#222", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = k(this.primaryColor, { h: 64 }), this.fillType3 = k(this.secondaryColor, { h: 64 }), this.fillType4 = k(this.primaryColor, { h: -64 }), this.fillType5 = k(this.secondaryColor, { h: -64 }), this.fillType6 = k(this.primaryColor, { h: 128 }), this.fillType7 = k(this.secondaryColor, { h: 128 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pie12 = this.pie0, this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || k(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || k(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || k(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || k(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || k(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || k(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ci(this.quadrant1Fill) ? z(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((y = this.radar) == null ? void 0 : y.curveStrokeWidth) || 2,
      graticuleColor: ((x = this.radar) == null ? void 0 : x.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((S = this.radar) == null ? void 0 : S.legendBoxSize) || 12,
      legendFontSize: ((w = this.radar) == null ? void 0 : w.legendFontSize) || 12
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = X(this.pie1, 25) || this.primaryColor, this.git1 = this.pie2 || this.secondaryColor, this.git2 = this.pie3 || this.tertiaryColor, this.git3 = this.pie4 || k(this.primaryColor, { h: -30 }), this.git4 = this.pie5 || k(this.primaryColor, { h: -60 }), this.git5 = this.pie6 || k(this.primaryColor, { h: -90 }), this.git6 = this.pie7 || k(this.primaryColor, { h: 60 }), this.git7 = this.pie8 || k(this.primaryColor, { h: 120 }), this.gitInv0 = this.gitInv0 || I(this.git0), this.gitInv1 = this.gitInv1 || I(this.git1), this.gitInv2 = this.gitInv2 || I(this.git2), this.gitInv3 = this.gitInv3 || I(this.git3), this.gitInv4 = this.gitInv4 || I(this.git4), this.gitInv5 = this.gitInv5 || I(this.git5), this.gitInv6 = this.gitInv6 || I(this.git6), this.gitInv7 = this.gitInv7 || I(this.git7), this.branchLabelColor = this.branchLabelColor || this.labelTextColor, this.gitBranchLabel0 = this.branchLabelColor, this.gitBranchLabel1 = "white", this.gitBranchLabel2 = this.branchLabelColor, this.gitBranchLabel3 = "white", this.gitBranchLabel4 = this.branchLabelColor, this.gitBranchLabel5 = this.branchLabelColor, this.gitBranchLabel6 = this.branchLabelColor, this.gitBranchLabel7 = this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Tn, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Bn;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(hr, "Theme"), hr), bg = /* @__PURE__ */ d((e) => {
  const t = new xg();
  return t.calculate(e), t;
}, "getThemeVariables"), ue = {
  base: {
    getThemeVariables: ug
  },
  dark: {
    getThemeVariables: pg
  },
  default: {
    getThemeVariables: gg
  },
  forest: {
    getThemeVariables: yg
  },
  neutral: {
    getThemeVariables: bg
  }
}, Vt = {
  flowchart: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    subGraphTitleMargin: {
      top: 0,
      bottom: 0
    },
    diagramPadding: 8,
    htmlLabels: !0,
    nodeSpacing: 50,
    rankSpacing: 50,
    curve: "basis",
    padding: 15,
    defaultRenderer: "dagre-wrapper",
    wrappingWidth: 200,
    inheritDir: !1
  },
  sequence: {
    useMaxWidth: !0,
    hideUnusedParticipants: !1,
    activationWidth: 10,
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    mirrorActors: !0,
    forceMenus: !1,
    bottomMarginAdj: 1,
    rightAngles: !1,
    showSequenceNumbers: !1,
    actorFontSize: 14,
    actorFontFamily: '"Open Sans", sans-serif',
    actorFontWeight: 400,
    noteFontSize: 14,
    noteFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    noteFontWeight: 400,
    noteAlign: "center",
    messageFontSize: 16,
    messageFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    messageFontWeight: 400,
    wrap: !1,
    wrapPadding: 10,
    labelBoxWidth: 50,
    labelBoxHeight: 20
  },
  gantt: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    barHeight: 20,
    barGap: 4,
    topPadding: 50,
    rightPadding: 75,
    leftPadding: 75,
    gridLineStartPadding: 35,
    fontSize: 11,
    sectionFontSize: 11,
    numberSectionStyles: 4,
    axisFormat: "%Y-%m-%d",
    topAxis: !1,
    displayMode: "",
    weekday: "sunday"
  },
  journey: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    maxLabelWidth: 360,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    titleColor: "",
    titleFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    titleFontSize: "4ex"
  },
  class: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    arrowMarkerAbsolute: !1,
    dividerMargin: 10,
    padding: 5,
    textHeight: 10,
    defaultRenderer: "dagre-wrapper",
    htmlLabels: !1,
    hideEmptyMembersBox: !1
  },
  state: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    dividerMargin: 10,
    sizeUnit: 5,
    padding: 8,
    textHeight: 10,
    titleShift: -15,
    noteMargin: 10,
    forkWidth: 70,
    forkHeight: 7,
    miniPadding: 2,
    fontSizeFactor: 5.02,
    fontSize: 24,
    labelHeight: 16,
    edgeLengthFactor: "20",
    compositTitleSize: 35,
    radius: 5,
    defaultRenderer: "dagre-wrapper"
  },
  er: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 20,
    layoutDirection: "TB",
    minEntityWidth: 100,
    minEntityHeight: 75,
    entityPadding: 15,
    nodeSpacing: 140,
    rankSpacing: 80,
    stroke: "gray",
    fill: "honeydew",
    fontSize: 12
  },
  pie: {
    useMaxWidth: !0,
    textPosition: 0.75
  },
  quadrantChart: {
    useMaxWidth: !0,
    chartWidth: 500,
    chartHeight: 500,
    titleFontSize: 20,
    titlePadding: 10,
    quadrantPadding: 5,
    xAxisLabelPadding: 5,
    yAxisLabelPadding: 5,
    xAxisLabelFontSize: 16,
    yAxisLabelFontSize: 16,
    quadrantLabelFontSize: 16,
    quadrantTextTopPadding: 5,
    pointTextPadding: 5,
    pointLabelFontSize: 12,
    pointRadius: 5,
    xAxisPosition: "top",
    yAxisPosition: "left",
    quadrantInternalBorderStrokeWidth: 1,
    quadrantExternalBorderStrokeWidth: 2
  },
  xyChart: {
    useMaxWidth: !0,
    width: 700,
    height: 500,
    titleFontSize: 20,
    titlePadding: 10,
    showDataLabel: !1,
    showTitle: !0,
    xAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    yAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    chartOrientation: "vertical",
    plotReservedSpacePercent: 50
  },
  requirement: {
    useMaxWidth: !0,
    rect_fill: "#f9f9f9",
    text_color: "#333",
    rect_border_size: "0.5px",
    rect_border_color: "#bbb",
    rect_min_width: 200,
    rect_min_height: 200,
    fontSize: 14,
    rect_padding: 10,
    line_height: 20
  },
  mindmap: {
    useMaxWidth: !0,
    padding: 10,
    maxNodeWidth: 200
  },
  kanban: {
    useMaxWidth: !0,
    padding: 8,
    sectionWidth: 200,
    ticketBaseUrl: ""
  },
  timeline: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    disableMulticolor: !1
  },
  gitGraph: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 8,
    nodeLabel: {
      width: 75,
      height: 100,
      x: -25,
      y: 0
    },
    mainBranchName: "main",
    mainBranchOrder: 0,
    showCommitLabel: !0,
    showBranches: !0,
    rotateCommitLabel: !0,
    parallelCommits: !1,
    arrowMarkerAbsolute: !1
  },
  c4: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    c4ShapeMargin: 50,
    c4ShapePadding: 20,
    width: 216,
    height: 60,
    boxMargin: 10,
    c4ShapeInRow: 4,
    nextLinePaddingX: 0,
    c4BoundaryInRow: 2,
    personFontSize: 14,
    personFontFamily: '"Open Sans", sans-serif',
    personFontWeight: "normal",
    external_personFontSize: 14,
    external_personFontFamily: '"Open Sans", sans-serif',
    external_personFontWeight: "normal",
    systemFontSize: 14,
    systemFontFamily: '"Open Sans", sans-serif',
    systemFontWeight: "normal",
    external_systemFontSize: 14,
    external_systemFontFamily: '"Open Sans", sans-serif',
    external_systemFontWeight: "normal",
    system_dbFontSize: 14,
    system_dbFontFamily: '"Open Sans", sans-serif',
    system_dbFontWeight: "normal",
    external_system_dbFontSize: 14,
    external_system_dbFontFamily: '"Open Sans", sans-serif',
    external_system_dbFontWeight: "normal",
    system_queueFontSize: 14,
    system_queueFontFamily: '"Open Sans", sans-serif',
    system_queueFontWeight: "normal",
    external_system_queueFontSize: 14,
    external_system_queueFontFamily: '"Open Sans", sans-serif',
    external_system_queueFontWeight: "normal",
    boundaryFontSize: 14,
    boundaryFontFamily: '"Open Sans", sans-serif',
    boundaryFontWeight: "normal",
    messageFontSize: 12,
    messageFontFamily: '"Open Sans", sans-serif',
    messageFontWeight: "normal",
    containerFontSize: 14,
    containerFontFamily: '"Open Sans", sans-serif',
    containerFontWeight: "normal",
    external_containerFontSize: 14,
    external_containerFontFamily: '"Open Sans", sans-serif',
    external_containerFontWeight: "normal",
    container_dbFontSize: 14,
    container_dbFontFamily: '"Open Sans", sans-serif',
    container_dbFontWeight: "normal",
    external_container_dbFontSize: 14,
    external_container_dbFontFamily: '"Open Sans", sans-serif',
    external_container_dbFontWeight: "normal",
    container_queueFontSize: 14,
    container_queueFontFamily: '"Open Sans", sans-serif',
    container_queueFontWeight: "normal",
    external_container_queueFontSize: 14,
    external_container_queueFontFamily: '"Open Sans", sans-serif',
    external_container_queueFontWeight: "normal",
    componentFontSize: 14,
    componentFontFamily: '"Open Sans", sans-serif',
    componentFontWeight: "normal",
    external_componentFontSize: 14,
    external_componentFontFamily: '"Open Sans", sans-serif',
    external_componentFontWeight: "normal",
    component_dbFontSize: 14,
    component_dbFontFamily: '"Open Sans", sans-serif',
    component_dbFontWeight: "normal",
    external_component_dbFontSize: 14,
    external_component_dbFontFamily: '"Open Sans", sans-serif',
    external_component_dbFontWeight: "normal",
    component_queueFontSize: 14,
    component_queueFontFamily: '"Open Sans", sans-serif',
    component_queueFontWeight: "normal",
    external_component_queueFontSize: 14,
    external_component_queueFontFamily: '"Open Sans", sans-serif',
    external_component_queueFontWeight: "normal",
    wrap: !0,
    wrapPadding: 10,
    person_bg_color: "#08427B",
    person_border_color: "#073B6F",
    external_person_bg_color: "#686868",
    external_person_border_color: "#8A8A8A",
    system_bg_color: "#1168BD",
    system_border_color: "#3C7FC0",
    system_db_bg_color: "#1168BD",
    system_db_border_color: "#3C7FC0",
    system_queue_bg_color: "#1168BD",
    system_queue_border_color: "#3C7FC0",
    external_system_bg_color: "#999999",
    external_system_border_color: "#8A8A8A",
    external_system_db_bg_color: "#999999",
    external_system_db_border_color: "#8A8A8A",
    external_system_queue_bg_color: "#999999",
    external_system_queue_border_color: "#8A8A8A",
    container_bg_color: "#438DD5",
    container_border_color: "#3C7FC0",
    container_db_bg_color: "#438DD5",
    container_db_border_color: "#3C7FC0",
    container_queue_bg_color: "#438DD5",
    container_queue_border_color: "#3C7FC0",
    external_container_bg_color: "#B3B3B3",
    external_container_border_color: "#A6A6A6",
    external_container_db_bg_color: "#B3B3B3",
    external_container_db_border_color: "#A6A6A6",
    external_container_queue_bg_color: "#B3B3B3",
    external_container_queue_border_color: "#A6A6A6",
    component_bg_color: "#85BBF0",
    component_border_color: "#78A8D8",
    component_db_bg_color: "#85BBF0",
    component_db_border_color: "#78A8D8",
    component_queue_bg_color: "#85BBF0",
    component_queue_border_color: "#78A8D8",
    external_component_bg_color: "#CCCCCC",
    external_component_border_color: "#BFBFBF",
    external_component_db_bg_color: "#CCCCCC",
    external_component_db_border_color: "#BFBFBF",
    external_component_queue_bg_color: "#CCCCCC",
    external_component_queue_border_color: "#BFBFBF"
  },
  sankey: {
    useMaxWidth: !0,
    width: 600,
    height: 400,
    linkColor: "gradient",
    nodeAlignment: "justify",
    showValues: !0,
    prefix: "",
    suffix: ""
  },
  block: {
    useMaxWidth: !0,
    padding: 8
  },
  packet: {
    useMaxWidth: !0,
    rowHeight: 32,
    bitWidth: 32,
    bitsPerRow: 32,
    showBits: !0,
    paddingX: 5,
    paddingY: 5
  },
  architecture: {
    useMaxWidth: !0,
    padding: 40,
    iconSize: 80,
    fontSize: 16
  },
  radar: {
    useMaxWidth: !0,
    width: 600,
    height: 600,
    marginTop: 50,
    marginRight: 50,
    marginBottom: 50,
    marginLeft: 50,
    axisScaleFactor: 1,
    axisLabelFactor: 1.05,
    curveTension: 0.17
  },
  theme: "default",
  look: "classic",
  handDrawnSeed: 0,
  layout: "dagre",
  maxTextSize: 5e4,
  maxEdges: 500,
  darkMode: !1,
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif;',
  logLevel: 5,
  securityLevel: "strict",
  startOnLoad: !0,
  arrowMarkerAbsolute: !1,
  secure: [
    "secure",
    "securityLevel",
    "startOnLoad",
    "maxTextSize",
    "suppressErrorRendering",
    "maxEdges"
  ],
  legacyMathML: !1,
  forceLegacyMathML: !1,
  deterministicIds: !1,
  fontSize: 16,
  markdownAutoWrap: !0,
  suppressErrorRendering: !1
}, Hl = {
  ...Vt,
  // Set, even though they're `undefined` so that `configKeys` finds these keys
  // TODO: Should we replace these with `null` so that they can go in the JSON Schema?
  deterministicIDSeed: void 0,
  elk: {
    // mergeEdges is needed here to be considered
    mergeEdges: !1,
    nodePlacementStrategy: "BRANDES_KOEPF"
  },
  themeCSS: void 0,
  // add non-JSON default config values
  themeVariables: ue.default.getThemeVariables(),
  sequence: {
    ...Vt.sequence,
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont"),
    noteFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.noteFontFamily,
        fontSize: this.noteFontSize,
        fontWeight: this.noteFontWeight
      };
    }, "noteFont"),
    actorFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.actorFontFamily,
        fontSize: this.actorFontSize,
        fontWeight: this.actorFontWeight
      };
    }, "actorFont")
  },
  class: {
    hideEmptyMembersBox: !1
  },
  gantt: {
    ...Vt.gantt,
    tickInterval: void 0,
    useWidth: void 0
    // can probably be removed since `configKeys` already includes this
  },
  c4: {
    ...Vt.c4,
    useWidth: void 0,
    personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.personFontFamily,
        fontSize: this.personFontSize,
        fontWeight: this.personFontWeight
      };
    }, "personFont"),
    flowchart: {
      ...Vt.flowchart,
      inheritDir: !1
      // default to legacy behavior
    },
    external_personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_personFontFamily,
        fontSize: this.external_personFontSize,
        fontWeight: this.external_personFontWeight
      };
    }, "external_personFont"),
    systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.systemFontFamily,
        fontSize: this.systemFontSize,
        fontWeight: this.systemFontWeight
      };
    }, "systemFont"),
    external_systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_systemFontFamily,
        fontSize: this.external_systemFontSize,
        fontWeight: this.external_systemFontWeight
      };
    }, "external_systemFont"),
    system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_dbFontFamily,
        fontSize: this.system_dbFontSize,
        fontWeight: this.system_dbFontWeight
      };
    }, "system_dbFont"),
    external_system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_dbFontFamily,
        fontSize: this.external_system_dbFontSize,
        fontWeight: this.external_system_dbFontWeight
      };
    }, "external_system_dbFont"),
    system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_queueFontFamily,
        fontSize: this.system_queueFontSize,
        fontWeight: this.system_queueFontWeight
      };
    }, "system_queueFont"),
    external_system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_queueFontFamily,
        fontSize: this.external_system_queueFontSize,
        fontWeight: this.external_system_queueFontWeight
      };
    }, "external_system_queueFont"),
    containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.containerFontFamily,
        fontSize: this.containerFontSize,
        fontWeight: this.containerFontWeight
      };
    }, "containerFont"),
    external_containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_containerFontFamily,
        fontSize: this.external_containerFontSize,
        fontWeight: this.external_containerFontWeight
      };
    }, "external_containerFont"),
    container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_dbFontFamily,
        fontSize: this.container_dbFontSize,
        fontWeight: this.container_dbFontWeight
      };
    }, "container_dbFont"),
    external_container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_dbFontFamily,
        fontSize: this.external_container_dbFontSize,
        fontWeight: this.external_container_dbFontWeight
      };
    }, "external_container_dbFont"),
    container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_queueFontFamily,
        fontSize: this.container_queueFontSize,
        fontWeight: this.container_queueFontWeight
      };
    }, "container_queueFont"),
    external_container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_queueFontFamily,
        fontSize: this.external_container_queueFontSize,
        fontWeight: this.external_container_queueFontWeight
      };
    }, "external_container_queueFont"),
    componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.componentFontFamily,
        fontSize: this.componentFontSize,
        fontWeight: this.componentFontWeight
      };
    }, "componentFont"),
    external_componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_componentFontFamily,
        fontSize: this.external_componentFontSize,
        fontWeight: this.external_componentFontWeight
      };
    }, "external_componentFont"),
    component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_dbFontFamily,
        fontSize: this.component_dbFontSize,
        fontWeight: this.component_dbFontWeight
      };
    }, "component_dbFont"),
    external_component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_dbFontFamily,
        fontSize: this.external_component_dbFontSize,
        fontWeight: this.external_component_dbFontWeight
      };
    }, "external_component_dbFont"),
    component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_queueFontFamily,
        fontSize: this.component_queueFontSize,
        fontWeight: this.component_queueFontWeight
      };
    }, "component_queueFont"),
    external_component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_queueFontFamily,
        fontSize: this.external_component_queueFontSize,
        fontWeight: this.external_component_queueFontWeight
      };
    }, "external_component_queueFont"),
    boundaryFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.boundaryFontFamily,
        fontSize: this.boundaryFontSize,
        fontWeight: this.boundaryFontWeight
      };
    }, "boundaryFont"),
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont")
  },
  pie: {
    ...Vt.pie,
    useWidth: 984
  },
  xyChart: {
    ...Vt.xyChart,
    useWidth: void 0
  },
  requirement: {
    ...Vt.requirement,
    useWidth: void 0
  },
  packet: {
    ...Vt.packet
  },
  radar: {
    ...Vt.radar
  }
}, jl = /* @__PURE__ */ d((e, t = "") => Object.keys(e).reduce((r, i) => Array.isArray(e[i]) ? r : typeof e[i] == "object" && e[i] !== null ? [...r, t + i, ...jl(e[i], "")] : [...r, t + i], []), "keyify"), Cg = new Set(jl(Hl, "")), Yl = Hl, Hi = /* @__PURE__ */ d((e) => {
  if (F.debug("sanitizeDirective called with", e), !(typeof e != "object" || e == null)) {
    if (Array.isArray(e)) {
      e.forEach((t) => Hi(t));
      return;
    }
    for (const t of Object.keys(e)) {
      if (F.debug("Checking key", t), t.startsWith("__") || t.includes("proto") || t.includes("constr") || !Cg.has(t) || e[t] == null) {
        F.debug("sanitize deleting key: ", t), delete e[t];
        continue;
      }
      if (typeof e[t] == "object") {
        F.debug("sanitizing object", t), Hi(e[t]);
        continue;
      }
      const r = ["themeCSS", "fontFamily", "altFontFamily"];
      for (const i of r)
        t.includes(i) && (F.debug("sanitizing css option", t), e[t] = _g(e[t]));
    }
    if (e.themeVariables)
      for (const t of Object.keys(e.themeVariables)) {
        const r = e.themeVariables[t];
        r != null && r.match && !r.match(/^[\d "#%(),.;A-Za-z]+$/) && (e.themeVariables[t] = "");
      }
    F.debug("After sanitization", e);
  }
}, "sanitizeDirective"), _g = /* @__PURE__ */ d((e) => {
  let t = 0, r = 0;
  for (const i of e) {
    if (t < r)
      return "{ /* ERROR: Unbalanced CSS */ }";
    i === "{" ? t++ : i === "}" && r++;
  }
  return t !== r ? "{ /* ERROR: Unbalanced CSS */ }" : e;
}, "sanitizeCss"), gr = Object.freeze(Yl), Dt = kt({}, gr), Gl, mr = [], Xr = kt({}, gr), Ln = /* @__PURE__ */ d((e, t) => {
  let r = kt({}, e), i = {};
  for (const n of t)
    Vl(n), i = kt(i, n);
  if (r = kt(r, i), i.theme && i.theme in ue) {
    const n = kt({}, Gl), a = kt(
      n.themeVariables || {},
      i.themeVariables
    );
    r.theme && r.theme in ue && (r.themeVariables = ue[r.theme].getThemeVariables(a));
  }
  return Xr = r, Zl(Xr), Xr;
}, "updateCurrentConfig"), wg = /* @__PURE__ */ d((e) => (Dt = kt({}, gr), Dt = kt(Dt, e), e.theme && ue[e.theme] && (Dt.themeVariables = ue[e.theme].getThemeVariables(e.themeVariables)), Ln(Dt, mr), Dt), "setSiteConfig"), vg = /* @__PURE__ */ d((e) => {
  Gl = kt({}, e);
}, "saveConfigFromInitialize"), kg = /* @__PURE__ */ d((e) => (Dt = kt(Dt, e), Ln(Dt, mr), Dt), "updateSiteConfig"), Ul = /* @__PURE__ */ d(() => kt({}, Dt), "getSiteConfig"), Xl = /* @__PURE__ */ d((e) => (Zl(e), kt(Xr, e), Pt()), "setConfig"), Pt = /* @__PURE__ */ d(() => kt({}, Xr), "getConfig"), Vl = /* @__PURE__ */ d((e) => {
  e && (["secure", ...Dt.secure ?? []].forEach((t) => {
    Object.hasOwn(e, t) && (F.debug(`Denied attempt to modify a secure key ${t}`, e[t]), delete e[t]);
  }), Object.keys(e).forEach((t) => {
    t.startsWith("__") && delete e[t];
  }), Object.keys(e).forEach((t) => {
    typeof e[t] == "string" && (e[t].includes("<") || e[t].includes(">") || e[t].includes("url(data:")) && delete e[t], typeof e[t] == "object" && Vl(e[t]);
  }));
}, "sanitize"), Sg = /* @__PURE__ */ d((e) => {
  var t;
  Hi(e), e.fontFamily && !((t = e.themeVariables) != null && t.fontFamily) && (e.themeVariables = {
    ...e.themeVariables,
    fontFamily: e.fontFamily
  }), mr.push(e), Ln(Dt, mr);
}, "addDirective"), ji = /* @__PURE__ */ d((e = Dt) => {
  mr = [], Ln(e, mr);
}, "reset"), Tg = {
  LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead."
}, fo = {}, Bg = /* @__PURE__ */ d((e) => {
  fo[e] || (F.warn(Tg[e]), fo[e] = !0);
}, "issueWarning"), Zl = /* @__PURE__ */ d((e) => {
  e && (e.lazyLoadedDiagrams || e.loadExternalDiagramsAtStartup) && Bg("LAZY_LOAD_DEPRECATED");
}, "checkConfig"), hi = /<br\s*\/?>/gi, Lg = /* @__PURE__ */ d((e) => e ? Jl(e).replace(/\\n/g, "#br#").split("#br#") : [""], "getRows"), Mg = /* @__PURE__ */ (() => {
  let e = !1;
  return () => {
    e || (Kl(), e = !0);
  };
})();
function Kl() {
  const e = "data-temp-href-target";
  pr.addHook("beforeSanitizeAttributes", (t) => {
    t instanceof Element && t.tagName === "A" && t.hasAttribute("target") && t.setAttribute(e, t.getAttribute("target") ?? "");
  }), pr.addHook("afterSanitizeAttributes", (t) => {
    t instanceof Element && t.tagName === "A" && t.hasAttribute(e) && (t.setAttribute("target", t.getAttribute(e) ?? ""), t.removeAttribute(e), t.getAttribute("target") === "_blank" && t.setAttribute("rel", "noopener"));
  });
}
d(Kl, "setupDompurifyHooks");
var Ql = /* @__PURE__ */ d((e) => (Mg(), pr.sanitize(e)), "removeScript"), po = /* @__PURE__ */ d((e, t) => {
  var r;
  if (((r = t.flowchart) == null ? void 0 : r.htmlLabels) !== !1) {
    const i = t.securityLevel;
    i === "antiscript" || i === "strict" ? e = Ql(e) : i !== "loose" && (e = Jl(e), e = e.replace(/</g, "&lt;").replace(/>/g, "&gt;"), e = e.replace(/=/g, "&equals;"), e = Eg(e));
  }
  return e;
}, "sanitizeMore"), ze = /* @__PURE__ */ d((e, t) => e && (t.dompurifyConfig ? e = pr.sanitize(po(e, t), t.dompurifyConfig).toString() : e = pr.sanitize(po(e, t), {
  FORBID_TAGS: ["style"]
}).toString(), e), "sanitizeText"), Ag = /* @__PURE__ */ d((e, t) => typeof e == "string" ? ze(e, t) : e.flat().map((r) => ze(r, t)), "sanitizeTextOrArray"), $g = /* @__PURE__ */ d((e) => hi.test(e), "hasBreaks"), Fg = /* @__PURE__ */ d((e) => e.split(hi), "splitBreaks"), Eg = /* @__PURE__ */ d((e) => e.replace(/#br#/g, "<br/>"), "placeholderToBreak"), Jl = /* @__PURE__ */ d((e) => e.replace(hi, "#br#"), "breakToPlaceholder"), tc = /* @__PURE__ */ d((e) => {
  let t = "";
  return e && (t = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, t = CSS.escape(t)), t;
}, "getUrl"), bt = /* @__PURE__ */ d((e) => !(e === !1 || ["false", "null", "0"].includes(String(e).trim().toLowerCase())), "evaluate"), Og = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.max(...t);
}, "getMax"), Dg = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.min(...t);
}, "getMin"), go = /* @__PURE__ */ d(function(e) {
  const t = e.split(/(,)/), r = [];
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    if (n === "," && i > 0 && i + 1 < t.length) {
      const a = t[i - 1], o = t[i + 1];
      Rg(a, o) && (n = a + "," + o, i++, r.pop());
    }
    r.push(Ig(n));
  }
  return r.join("");
}, "parseGenericTypes"), ya = /* @__PURE__ */ d((e, t) => Math.max(0, e.split(t).length - 1), "countOccurrence"), Rg = /* @__PURE__ */ d((e, t) => {
  const r = ya(e, "~"), i = ya(t, "~");
  return r === 1 && i === 1;
}, "shouldCombineSets"), Ig = /* @__PURE__ */ d((e) => {
  const t = ya(e, "~");
  let r = !1;
  if (t <= 1)
    return e;
  t % 2 !== 0 && e.startsWith("~") && (e = e.substring(1), r = !0);
  const i = [...e];
  let n = i.indexOf("~"), a = i.lastIndexOf("~");
  for (; n !== -1 && a !== -1 && n !== a; )
    i[n] = "<", i[a] = ">", n = i.indexOf("~"), a = i.lastIndexOf("~");
  return r && i.unshift("~"), i.join("");
}, "processSet"), mo = /* @__PURE__ */ d(() => window.MathMLElement !== void 0, "isMathMLSupported"), xa = /\$\$(.*)\$\$/g, yr = /* @__PURE__ */ d((e) => {
  var t;
  return (((t = e.match(xa)) == null ? void 0 : t.length) ?? 0) > 0;
}, "hasKatex"), xT = /* @__PURE__ */ d(async (e, t) => {
  e = await fs(e, t);
  const r = document.createElement("div");
  r.innerHTML = e, r.id = "katex-temp", r.style.visibility = "hidden", r.style.position = "absolute", r.style.top = "0";
  const i = document.querySelector("body");
  i == null || i.insertAdjacentElement("beforeend", r);
  const n = { width: r.clientWidth, height: r.clientHeight };
  return r.remove(), n;
}, "calculateMathMLDimensions"), fs = /* @__PURE__ */ d(async (e, t) => {
  if (!yr(e))
    return e;
  if (!(mo() || t.legacyMathML || t.forceLegacyMathML))
    return e.replace(xa, "MathML is unsupported in this environment.");
  {
    const { default: r } = await import("./Index-DcB-GfxT.js").then((n) => n.k), i = t.forceLegacyMathML || !mo() && t.legacyMathML ? "htmlAndMathml" : "mathml";
    return e.split(hi).map(
      (n) => yr(n) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${n}</div>` : `<div>${n}</div>`
    ).join("").replace(
      xa,
      (n, a) => r.renderToString(a, {
        throwOnError: !0,
        displayMode: !0,
        output: i
      }).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, "")
    );
  }
}, "renderKatex"), kr = {
  getRows: Lg,
  sanitizeText: ze,
  sanitizeTextOrArray: Ag,
  hasBreaks: $g,
  splitBreaks: Fg,
  lineBreakRegex: hi,
  removeScript: Ql,
  getUrl: tc,
  evaluate: bt,
  getMax: Og,
  getMin: Dg
}, Pg = /* @__PURE__ */ d(function(e, t) {
  for (let r of t)
    e.attr(r[0], r[1]);
}, "d3Attrs"), Ng = /* @__PURE__ */ d(function(e, t, r) {
  let i = /* @__PURE__ */ new Map();
  return r ? (i.set("width", "100%"), i.set("style", `max-width: ${t}px;`)) : (i.set("height", e), i.set("width", t)), i;
}, "calculateSvgSizeAttrs"), ec = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = Ng(t, r, i);
  Pg(e, n);
}, "configureSvgSize"), zg = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = t.node().getBBox(), a = n.width, o = n.height;
  F.info(`SVG bounds: ${a}x${o}`, n);
  let s = 0, l = 0;
  F.info(`Graph bounds: ${s}x${l}`, e), s = a + r * 2, l = o + r * 2, F.info(`Calculated bounds: ${s}x${l}`), ec(t, l, s, i);
  const c = `${n.x - r} ${n.y - r} ${n.width + 2 * r} ${n.height + 2 * r}`;
  t.attr("viewBox", c);
}, "setupGraphViewbox"), Ai = {}, qg = /* @__PURE__ */ d((e, t, r) => {
  let i = "";
  return e in Ai && Ai[e] ? i = Ai[e](r) : F.warn(`No theme found for ${e}`), ` & {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
    fill: ${r.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${r.errorBkgColor};
  }
  & .error-text {
    fill: ${r.errorTextColor};
    stroke: ${r.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: 1px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${r.lineColor};
    stroke: ${r.lineColor};
  }
  & .marker.cross {
    stroke: ${r.lineColor};
  }

  & svg {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
  }
   & p {
    margin: 0
   }

  ${i}

  ${t}
`;
}, "getStyles"), Wg = /* @__PURE__ */ d((e, t) => {
  t !== void 0 && (Ai[e] = t);
}, "addStylesForDiagram"), Hg = qg, rc = {};
og(rc, {
  clear: () => jg,
  getAccDescription: () => Xg,
  getAccTitle: () => Gg,
  getDiagramTitle: () => Zg,
  setAccDescription: () => Ug,
  setAccTitle: () => Yg,
  setDiagramTitle: () => Vg
});
var ps = "", ds = "", gs = "", ms = /* @__PURE__ */ d((e) => ze(e, Pt()), "sanitizeText"), jg = /* @__PURE__ */ d(() => {
  ps = "", gs = "", ds = "";
}, "clear"), Yg = /* @__PURE__ */ d((e) => {
  ps = ms(e).replace(/^\s+/g, "");
}, "setAccTitle"), Gg = /* @__PURE__ */ d(() => ps, "getAccTitle"), Ug = /* @__PURE__ */ d((e) => {
  gs = ms(e).replace(/\n\s+/g, `
`);
}, "setAccDescription"), Xg = /* @__PURE__ */ d(() => gs, "getAccDescription"), Vg = /* @__PURE__ */ d((e) => {
  ds = ms(e);
}, "setDiagramTitle"), Zg = /* @__PURE__ */ d(() => ds, "getDiagramTitle"), yo = F, Kg = hs, nt = Pt, bT = Xl, CT = gr, Mn = /* @__PURE__ */ d((e) => ze(e, nt()), "sanitizeText"), Qg = zg, Jg = /* @__PURE__ */ d(() => rc, "getCommonDb"), Yi = {}, Gi = /* @__PURE__ */ d((e, t, r) => {
  var i;
  Yi[e] && yo.warn(`Diagram with id ${e} already registered. Overwriting.`), Yi[e] = t, r && Wl(e, r), Wg(e, t.styles), (i = t.injectUtils) == null || i.call(
    t,
    yo,
    Kg,
    nt,
    Mn,
    Qg,
    Jg(),
    () => {
    }
  );
}, "registerDiagram"), ba = /* @__PURE__ */ d((e) => {
  if (e in Yi)
    return Yi[e];
  throw new t0(e);
}, "getDiagram"), ur, t0 = (ur = class extends Error {
  constructor(t) {
    super(`Diagram ${t} not found.`);
  }
}, d(ur, "DiagramNotFoundError"), ur);
function ys(e) {
  return typeof e > "u" || e === null;
}
d(ys, "isNothing");
function ic(e) {
  return typeof e == "object" && e !== null;
}
d(ic, "isObject");
function nc(e) {
  return Array.isArray(e) ? e : ys(e) ? [] : [e];
}
d(nc, "toArray");
function ac(e, t) {
  var r, i, n, a;
  if (t)
    for (a = Object.keys(t), r = 0, i = a.length; r < i; r += 1)
      n = a[r], e[n] = t[n];
  return e;
}
d(ac, "extend");
function sc(e, t) {
  var r = "", i;
  for (i = 0; i < t; i += 1)
    r += e;
  return r;
}
d(sc, "repeat");
function oc(e) {
  return e === 0 && Number.NEGATIVE_INFINITY === 1 / e;
}
d(oc, "isNegativeZero");
var e0 = ys, r0 = ic, i0 = nc, n0 = sc, a0 = oc, s0 = ac, xt = {
  isNothing: e0,
  isObject: r0,
  toArray: i0,
  repeat: n0,
  isNegativeZero: a0,
  extend: s0
};
function xs(e, t) {
  var r = "", i = e.reason || "(unknown reason)";
  return e.mark ? (e.mark.name && (r += 'in "' + e.mark.name + '" '), r += "(" + (e.mark.line + 1) + ":" + (e.mark.column + 1) + ")", !t && e.mark.snippet && (r += `

` + e.mark.snippet), i + " " + r) : i;
}
d(xs, "formatError");
function xr(e, t) {
  Error.call(this), this.name = "YAMLException", this.reason = e, this.mark = t, this.message = xs(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "";
}
d(xr, "YAMLException$1");
xr.prototype = Object.create(Error.prototype);
xr.prototype.constructor = xr;
xr.prototype.toString = /* @__PURE__ */ d(function(t) {
  return this.name + ": " + xs(this, t);
}, "toString");
var Rt = xr;
function $i(e, t, r, i, n) {
  var a = "", o = "", s = Math.floor(n / 2) - 1;
  return i - t > s && (a = " ... ", t = i - s + a.length), r - i > s && (o = " ...", r = i + s - o.length), {
    str: a + e.slice(t, r).replace(/\t/g, "→") + o,
    pos: i - t + a.length
    // relative position
  };
}
d($i, "getLine");
function Fi(e, t) {
  return xt.repeat(" ", t - e.length) + e;
}
d(Fi, "padStart");
function lc(e, t) {
  if (t = Object.create(t || null), !e.buffer) return null;
  t.maxLength || (t.maxLength = 79), typeof t.indent != "number" && (t.indent = 1), typeof t.linesBefore != "number" && (t.linesBefore = 3), typeof t.linesAfter != "number" && (t.linesAfter = 2);
  for (var r = /\r?\n|\r|\0/g, i = [0], n = [], a, o = -1; a = r.exec(e.buffer); )
    n.push(a.index), i.push(a.index + a[0].length), e.position <= a.index && o < 0 && (o = i.length - 2);
  o < 0 && (o = i.length - 1);
  var s = "", l, c, h = Math.min(e.line + t.linesAfter, n.length).toString().length, u = t.maxLength - (t.indent + h + 3);
  for (l = 1; l <= t.linesBefore && !(o - l < 0); l++)
    c = $i(
      e.buffer,
      i[o - l],
      n[o - l],
      e.position - (i[o] - i[o - l]),
      u
    ), s = xt.repeat(" ", t.indent) + Fi((e.line - l + 1).toString(), h) + " | " + c.str + `
` + s;
  for (c = $i(e.buffer, i[o], n[o], e.position, u), s += xt.repeat(" ", t.indent) + Fi((e.line + 1).toString(), h) + " | " + c.str + `
`, s += xt.repeat("-", t.indent + h + 3 + c.pos) + `^
`, l = 1; l <= t.linesAfter && !(o + l >= n.length); l++)
    c = $i(
      e.buffer,
      i[o + l],
      n[o + l],
      e.position - (i[o] - i[o + l]),
      u
    ), s += xt.repeat(" ", t.indent) + Fi((e.line + l + 1).toString(), h) + " | " + c.str + `
`;
  return s.replace(/\n$/, "");
}
d(lc, "makeSnippet");
var o0 = lc, l0 = [
  "kind",
  "multi",
  "resolve",
  "construct",
  "instanceOf",
  "predicate",
  "represent",
  "representName",
  "defaultStyle",
  "styleAliases"
], c0 = [
  "scalar",
  "sequence",
  "mapping"
];
function cc(e) {
  var t = {};
  return e !== null && Object.keys(e).forEach(function(r) {
    e[r].forEach(function(i) {
      t[String(i)] = r;
    });
  }), t;
}
d(cc, "compileStyleAliases");
function hc(e, t) {
  if (t = t || {}, Object.keys(t).forEach(function(r) {
    if (l0.indexOf(r) === -1)
      throw new Rt('Unknown option "' + r + '" is met in definition of "' + e + '" YAML type.');
  }), this.options = t, this.tag = e, this.kind = t.kind || null, this.resolve = t.resolve || function() {
    return !0;
  }, this.construct = t.construct || function(r) {
    return r;
  }, this.instanceOf = t.instanceOf || null, this.predicate = t.predicate || null, this.represent = t.represent || null, this.representName = t.representName || null, this.defaultStyle = t.defaultStyle || null, this.multi = t.multi || !1, this.styleAliases = cc(t.styleAliases || null), c0.indexOf(this.kind) === -1)
    throw new Rt('Unknown kind "' + this.kind + '" is specified for "' + e + '" YAML type.');
}
d(hc, "Type$1");
var Bt = hc;
function Ca(e, t) {
  var r = [];
  return e[t].forEach(function(i) {
    var n = r.length;
    r.forEach(function(a, o) {
      a.tag === i.tag && a.kind === i.kind && a.multi === i.multi && (n = o);
    }), r[n] = i;
  }), r;
}
d(Ca, "compileList");
function uc() {
  var e = {
    scalar: {},
    sequence: {},
    mapping: {},
    fallback: {},
    multi: {
      scalar: [],
      sequence: [],
      mapping: [],
      fallback: []
    }
  }, t, r;
  function i(n) {
    n.multi ? (e.multi[n.kind].push(n), e.multi.fallback.push(n)) : e[n.kind][n.tag] = e.fallback[n.tag] = n;
  }
  for (d(i, "collectType"), t = 0, r = arguments.length; t < r; t += 1)
    arguments[t].forEach(i);
  return e;
}
d(uc, "compileMap");
function Ui(e) {
  return this.extend(e);
}
d(Ui, "Schema$1");
Ui.prototype.extend = /* @__PURE__ */ d(function(t) {
  var r = [], i = [];
  if (t instanceof Bt)
    i.push(t);
  else if (Array.isArray(t))
    i = i.concat(t);
  else if (t && (Array.isArray(t.implicit) || Array.isArray(t.explicit)))
    t.implicit && (r = r.concat(t.implicit)), t.explicit && (i = i.concat(t.explicit));
  else
    throw new Rt("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");
  r.forEach(function(a) {
    if (!(a instanceof Bt))
      throw new Rt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
    if (a.loadKind && a.loadKind !== "scalar")
      throw new Rt("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
    if (a.multi)
      throw new Rt("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.");
  }), i.forEach(function(a) {
    if (!(a instanceof Bt))
      throw new Rt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
  });
  var n = Object.create(Ui.prototype);
  return n.implicit = (this.implicit || []).concat(r), n.explicit = (this.explicit || []).concat(i), n.compiledImplicit = Ca(n, "implicit"), n.compiledExplicit = Ca(n, "explicit"), n.compiledTypeMap = uc(n.compiledImplicit, n.compiledExplicit), n;
}, "extend");
var h0 = Ui, u0 = new Bt("tag:yaml.org,2002:str", {
  kind: "scalar",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : "";
  }, "construct")
}), f0 = new Bt("tag:yaml.org,2002:seq", {
  kind: "sequence",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : [];
  }, "construct")
}), p0 = new Bt("tag:yaml.org,2002:map", {
  kind: "mapping",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : {};
  }, "construct")
}), d0 = new h0({
  explicit: [
    u0,
    f0,
    p0
  ]
});
function fc(e) {
  if (e === null) return !0;
  var t = e.length;
  return t === 1 && e === "~" || t === 4 && (e === "null" || e === "Null" || e === "NULL");
}
d(fc, "resolveYamlNull");
function pc() {
  return null;
}
d(pc, "constructYamlNull");
function dc(e) {
  return e === null;
}
d(dc, "isNull");
var g0 = new Bt("tag:yaml.org,2002:null", {
  kind: "scalar",
  resolve: fc,
  construct: pc,
  predicate: dc,
  represent: {
    canonical: /* @__PURE__ */ d(function() {
      return "~";
    }, "canonical"),
    lowercase: /* @__PURE__ */ d(function() {
      return "null";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function() {
      return "NULL";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function() {
      return "Null";
    }, "camelcase"),
    empty: /* @__PURE__ */ d(function() {
      return "";
    }, "empty")
  },
  defaultStyle: "lowercase"
});
function gc(e) {
  if (e === null) return !1;
  var t = e.length;
  return t === 4 && (e === "true" || e === "True" || e === "TRUE") || t === 5 && (e === "false" || e === "False" || e === "FALSE");
}
d(gc, "resolveYamlBoolean");
function mc(e) {
  return e === "true" || e === "True" || e === "TRUE";
}
d(mc, "constructYamlBoolean");
function yc(e) {
  return Object.prototype.toString.call(e) === "[object Boolean]";
}
d(yc, "isBoolean");
var m0 = new Bt("tag:yaml.org,2002:bool", {
  kind: "scalar",
  resolve: gc,
  construct: mc,
  predicate: yc,
  represent: {
    lowercase: /* @__PURE__ */ d(function(e) {
      return e ? "true" : "false";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function(e) {
      return e ? "TRUE" : "FALSE";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function(e) {
      return e ? "True" : "False";
    }, "camelcase")
  },
  defaultStyle: "lowercase"
});
function xc(e) {
  return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
}
d(xc, "isHexCode");
function bc(e) {
  return 48 <= e && e <= 55;
}
d(bc, "isOctCode");
function Cc(e) {
  return 48 <= e && e <= 57;
}
d(Cc, "isDecCode");
function _c(e) {
  if (e === null) return !1;
  var t = e.length, r = 0, i = !1, n;
  if (!t) return !1;
  if (n = e[r], (n === "-" || n === "+") && (n = e[++r]), n === "0") {
    if (r + 1 === t) return !0;
    if (n = e[++r], n === "b") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (n !== "0" && n !== "1") return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "x") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!xc(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "o") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!bc(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
  }
  if (n === "_") return !1;
  for (; r < t; r++)
    if (n = e[r], n !== "_") {
      if (!Cc(e.charCodeAt(r)))
        return !1;
      i = !0;
    }
  return !(!i || n === "_");
}
d(_c, "resolveYamlInteger");
function wc(e) {
  var t = e, r = 1, i;
  if (t.indexOf("_") !== -1 && (t = t.replace(/_/g, "")), i = t[0], (i === "-" || i === "+") && (i === "-" && (r = -1), t = t.slice(1), i = t[0]), t === "0") return 0;
  if (i === "0") {
    if (t[1] === "b") return r * parseInt(t.slice(2), 2);
    if (t[1] === "x") return r * parseInt(t.slice(2), 16);
    if (t[1] === "o") return r * parseInt(t.slice(2), 8);
  }
  return r * parseInt(t, 10);
}
d(wc, "constructYamlInteger");
function vc(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && e % 1 === 0 && !xt.isNegativeZero(e);
}
d(vc, "isInteger");
var y0 = new Bt("tag:yaml.org,2002:int", {
  kind: "scalar",
  resolve: _c,
  construct: wc,
  predicate: vc,
  represent: {
    binary: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0b" + e.toString(2) : "-0b" + e.toString(2).slice(1);
    }, "binary"),
    octal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0o" + e.toString(8) : "-0o" + e.toString(8).slice(1);
    }, "octal"),
    decimal: /* @__PURE__ */ d(function(e) {
      return e.toString(10);
    }, "decimal"),
    /* eslint-disable max-len */
    hexadecimal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0x" + e.toString(16).toUpperCase() : "-0x" + e.toString(16).toUpperCase().slice(1);
    }, "hexadecimal")
  },
  defaultStyle: "decimal",
  styleAliases: {
    binary: [2, "bin"],
    octal: [8, "oct"],
    decimal: [10, "dec"],
    hexadecimal: [16, "hex"]
  }
}), x0 = new RegExp(
  // 2.5e4, 2.5 and integers
  "^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"
);
function kc(e) {
  return !(e === null || !x0.test(e) || // Quick hack to not allow integers end with `_`
  // Probably should update regexp & check speed
  e[e.length - 1] === "_");
}
d(kc, "resolveYamlFloat");
function Sc(e) {
  var t, r;
  return t = e.replace(/_/g, "").toLowerCase(), r = t[0] === "-" ? -1 : 1, "+-".indexOf(t[0]) >= 0 && (t = t.slice(1)), t === ".inf" ? r === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t === ".nan" ? NaN : r * parseFloat(t, 10);
}
d(Sc, "constructYamlFloat");
var b0 = /^[-+]?[0-9]+e/;
function Tc(e, t) {
  var r;
  if (isNaN(e))
    switch (t) {
      case "lowercase":
        return ".nan";
      case "uppercase":
        return ".NAN";
      case "camelcase":
        return ".NaN";
    }
  else if (Number.POSITIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return ".inf";
      case "uppercase":
        return ".INF";
      case "camelcase":
        return ".Inf";
    }
  else if (Number.NEGATIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return "-.inf";
      case "uppercase":
        return "-.INF";
      case "camelcase":
        return "-.Inf";
    }
  else if (xt.isNegativeZero(e))
    return "-0.0";
  return r = e.toString(10), b0.test(r) ? r.replace("e", ".e") : r;
}
d(Tc, "representYamlFloat");
function Bc(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && (e % 1 !== 0 || xt.isNegativeZero(e));
}
d(Bc, "isFloat");
var C0 = new Bt("tag:yaml.org,2002:float", {
  kind: "scalar",
  resolve: kc,
  construct: Sc,
  predicate: Bc,
  represent: Tc,
  defaultStyle: "lowercase"
}), Lc = d0.extend({
  implicit: [
    g0,
    m0,
    y0,
    C0
  ]
}), _0 = Lc, Mc = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"
), Ac = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"
);
function $c(e) {
  return e === null ? !1 : Mc.exec(e) !== null || Ac.exec(e) !== null;
}
d($c, "resolveYamlTimestamp");
function Fc(e) {
  var t, r, i, n, a, o, s, l = 0, c = null, h, u, f;
  if (t = Mc.exec(e), t === null && (t = Ac.exec(e)), t === null) throw new Error("Date resolve error");
  if (r = +t[1], i = +t[2] - 1, n = +t[3], !t[4])
    return new Date(Date.UTC(r, i, n));
  if (a = +t[4], o = +t[5], s = +t[6], t[7]) {
    for (l = t[7].slice(0, 3); l.length < 3; )
      l += "0";
    l = +l;
  }
  return t[9] && (h = +t[10], u = +(t[11] || 0), c = (h * 60 + u) * 6e4, t[9] === "-" && (c = -c)), f = new Date(Date.UTC(r, i, n, a, o, s, l)), c && f.setTime(f.getTime() - c), f;
}
d(Fc, "constructYamlTimestamp");
function Ec(e) {
  return e.toISOString();
}
d(Ec, "representYamlTimestamp");
var w0 = new Bt("tag:yaml.org,2002:timestamp", {
  kind: "scalar",
  resolve: $c,
  construct: Fc,
  instanceOf: Date,
  represent: Ec
});
function Oc(e) {
  return e === "<<" || e === null;
}
d(Oc, "resolveYamlMerge");
var v0 = new Bt("tag:yaml.org,2002:merge", {
  kind: "scalar",
  resolve: Oc
}), bs = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
function Dc(e) {
  if (e === null) return !1;
  var t, r, i = 0, n = e.length, a = bs;
  for (r = 0; r < n; r++)
    if (t = a.indexOf(e.charAt(r)), !(t > 64)) {
      if (t < 0) return !1;
      i += 6;
    }
  return i % 8 === 0;
}
d(Dc, "resolveYamlBinary");
function Rc(e) {
  var t, r, i = e.replace(/[\r\n=]/g, ""), n = i.length, a = bs, o = 0, s = [];
  for (t = 0; t < n; t++)
    t % 4 === 0 && t && (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)), o = o << 6 | a.indexOf(i.charAt(t));
  return r = n % 4 * 6, r === 0 ? (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)) : r === 18 ? (s.push(o >> 10 & 255), s.push(o >> 2 & 255)) : r === 12 && s.push(o >> 4 & 255), new Uint8Array(s);
}
d(Rc, "constructYamlBinary");
function Ic(e) {
  var t = "", r = 0, i, n, a = e.length, o = bs;
  for (i = 0; i < a; i++)
    i % 3 === 0 && i && (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]), r = (r << 8) + e[i];
  return n = a % 3, n === 0 ? (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]) : n === 2 ? (t += o[r >> 10 & 63], t += o[r >> 4 & 63], t += o[r << 2 & 63], t += o[64]) : n === 1 && (t += o[r >> 2 & 63], t += o[r << 4 & 63], t += o[64], t += o[64]), t;
}
d(Ic, "representYamlBinary");
function Pc(e) {
  return Object.prototype.toString.call(e) === "[object Uint8Array]";
}
d(Pc, "isBinary");
var k0 = new Bt("tag:yaml.org,2002:binary", {
  kind: "scalar",
  resolve: Dc,
  construct: Rc,
  predicate: Pc,
  represent: Ic
}), S0 = Object.prototype.hasOwnProperty, T0 = Object.prototype.toString;
function Nc(e) {
  if (e === null) return !0;
  var t = [], r, i, n, a, o, s = e;
  for (r = 0, i = s.length; r < i; r += 1) {
    if (n = s[r], o = !1, T0.call(n) !== "[object Object]") return !1;
    for (a in n)
      if (S0.call(n, a))
        if (!o) o = !0;
        else return !1;
    if (!o) return !1;
    if (t.indexOf(a) === -1) t.push(a);
    else return !1;
  }
  return !0;
}
d(Nc, "resolveYamlOmap");
function zc(e) {
  return e !== null ? e : [];
}
d(zc, "constructYamlOmap");
var B0 = new Bt("tag:yaml.org,2002:omap", {
  kind: "sequence",
  resolve: Nc,
  construct: zc
}), L0 = Object.prototype.toString;
function qc(e) {
  if (e === null) return !0;
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1) {
    if (i = o[t], L0.call(i) !== "[object Object]" || (n = Object.keys(i), n.length !== 1)) return !1;
    a[t] = [n[0], i[n[0]]];
  }
  return !0;
}
d(qc, "resolveYamlPairs");
function Wc(e) {
  if (e === null) return [];
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1)
    i = o[t], n = Object.keys(i), a[t] = [n[0], i[n[0]]];
  return a;
}
d(Wc, "constructYamlPairs");
var M0 = new Bt("tag:yaml.org,2002:pairs", {
  kind: "sequence",
  resolve: qc,
  construct: Wc
}), A0 = Object.prototype.hasOwnProperty;
function Hc(e) {
  if (e === null) return !0;
  var t, r = e;
  for (t in r)
    if (A0.call(r, t) && r[t] !== null)
      return !1;
  return !0;
}
d(Hc, "resolveYamlSet");
function jc(e) {
  return e !== null ? e : {};
}
d(jc, "constructYamlSet");
var $0 = new Bt("tag:yaml.org,2002:set", {
  kind: "mapping",
  resolve: Hc,
  construct: jc
}), Yc = _0.extend({
  implicit: [
    w0,
    v0
  ],
  explicit: [
    k0,
    B0,
    M0,
    $0
  ]
}), ve = Object.prototype.hasOwnProperty, Xi = 1, Gc = 2, Uc = 3, Vi = 4, Jn = 1, F0 = 2, xo = 3, E0 = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, O0 = /[\x85\u2028\u2029]/, D0 = /[,\[\]\{\}]/, Xc = /^(?:!|!!|![a-z\-]+!)$/i, Vc = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
function _a(e) {
  return Object.prototype.toString.call(e);
}
d(_a, "_class");
function Gt(e) {
  return e === 10 || e === 13;
}
d(Gt, "is_EOL");
function we(e) {
  return e === 9 || e === 32;
}
d(we, "is_WHITE_SPACE");
function $t(e) {
  return e === 9 || e === 32 || e === 10 || e === 13;
}
d($t, "is_WS_OR_EOL");
function Oe(e) {
  return e === 44 || e === 91 || e === 93 || e === 123 || e === 125;
}
d(Oe, "is_FLOW_INDICATOR");
function Zc(e) {
  var t;
  return 48 <= e && e <= 57 ? e - 48 : (t = e | 32, 97 <= t && t <= 102 ? t - 97 + 10 : -1);
}
d(Zc, "fromHexCode");
function Kc(e) {
  return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0;
}
d(Kc, "escapedHexLen");
function Qc(e) {
  return 48 <= e && e <= 57 ? e - 48 : -1;
}
d(Qc, "fromDecimalCode");
function wa(e) {
  return e === 48 ? "\0" : e === 97 ? "\x07" : e === 98 ? "\b" : e === 116 || e === 9 ? "	" : e === 110 ? `
` : e === 118 ? "\v" : e === 102 ? "\f" : e === 114 ? "\r" : e === 101 ? "\x1B" : e === 32 ? " " : e === 34 ? '"' : e === 47 ? "/" : e === 92 ? "\\" : e === 78 ? "" : e === 95 ? " " : e === 76 ? "\u2028" : e === 80 ? "\u2029" : "";
}
d(wa, "simpleEscapeSequence");
function Jc(e) {
  return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(
    (e - 65536 >> 10) + 55296,
    (e - 65536 & 1023) + 56320
  );
}
d(Jc, "charFromCodepoint");
var th = new Array(256), eh = new Array(256);
for (Me = 0; Me < 256; Me++)
  th[Me] = wa(Me) ? 1 : 0, eh[Me] = wa(Me);
var Me;
function rh(e, t) {
  this.input = e, this.filename = t.filename || null, this.schema = t.schema || Yc, this.onWarning = t.onWarning || null, this.legacy = t.legacy || !1, this.json = t.json || !1, this.listener = t.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.firstTabInLine = -1, this.documents = [];
}
d(rh, "State$1");
function Cs(e, t) {
  var r = {
    name: e.filename,
    buffer: e.input.slice(0, -1),
    // omit trailing \0
    position: e.position,
    line: e.line,
    column: e.position - e.lineStart
  };
  return r.snippet = o0(r), new Rt(t, r);
}
d(Cs, "generateError");
function G(e, t) {
  throw Cs(e, t);
}
d(G, "throwError");
function Kr(e, t) {
  e.onWarning && e.onWarning.call(null, Cs(e, t));
}
d(Kr, "throwWarning");
var bo = {
  YAML: /* @__PURE__ */ d(function(t, r, i) {
    var n, a, o;
    t.version !== null && G(t, "duplication of %YAML directive"), i.length !== 1 && G(t, "YAML directive accepts exactly one argument"), n = /^([0-9]+)\.([0-9]+)$/.exec(i[0]), n === null && G(t, "ill-formed argument of the YAML directive"), a = parseInt(n[1], 10), o = parseInt(n[2], 10), a !== 1 && G(t, "unacceptable YAML version of the document"), t.version = i[0], t.checkLineBreaks = o < 2, o !== 1 && o !== 2 && Kr(t, "unsupported YAML version of the document");
  }, "handleYamlDirective"),
  TAG: /* @__PURE__ */ d(function(t, r, i) {
    var n, a;
    i.length !== 2 && G(t, "TAG directive accepts exactly two arguments"), n = i[0], a = i[1], Xc.test(n) || G(t, "ill-formed tag handle (first argument) of the TAG directive"), ve.call(t.tagMap, n) && G(t, 'there is a previously declared suffix for "' + n + '" tag handle'), Vc.test(a) || G(t, "ill-formed tag prefix (second argument) of the TAG directive");
    try {
      a = decodeURIComponent(a);
    } catch {
      G(t, "tag prefix is malformed: " + a);
    }
    t.tagMap[n] = a;
  }, "handleTagDirective")
};
function fe(e, t, r, i) {
  var n, a, o, s;
  if (t < r) {
    if (s = e.input.slice(t, r), i)
      for (n = 0, a = s.length; n < a; n += 1)
        o = s.charCodeAt(n), o === 9 || 32 <= o && o <= 1114111 || G(e, "expected valid JSON character");
    else E0.test(s) && G(e, "the stream contains non-printable characters");
    e.result += s;
  }
}
d(fe, "captureSegment");
function va(e, t, r, i) {
  var n, a, o, s;
  for (xt.isObject(r) || G(e, "cannot merge mappings; the provided source object is unacceptable"), n = Object.keys(r), o = 0, s = n.length; o < s; o += 1)
    a = n[o], ve.call(t, a) || (t[a] = r[a], i[a] = !0);
}
d(va, "mergeMappings");
function De(e, t, r, i, n, a, o, s, l) {
  var c, h;
  if (Array.isArray(n))
    for (n = Array.prototype.slice.call(n), c = 0, h = n.length; c < h; c += 1)
      Array.isArray(n[c]) && G(e, "nested arrays are not supported inside keys"), typeof n == "object" && _a(n[c]) === "[object Object]" && (n[c] = "[object Object]");
  if (typeof n == "object" && _a(n) === "[object Object]" && (n = "[object Object]"), n = String(n), t === null && (t = {}), i === "tag:yaml.org,2002:merge")
    if (Array.isArray(a))
      for (c = 0, h = a.length; c < h; c += 1)
        va(e, t, a[c], r);
    else
      va(e, t, a, r);
  else
    !e.json && !ve.call(r, n) && ve.call(t, n) && (e.line = o || e.line, e.lineStart = s || e.lineStart, e.position = l || e.position, G(e, "duplicated mapping key")), n === "__proto__" ? Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      value: a
    }) : t[n] = a, delete r[n];
  return t;
}
d(De, "storeMappingPair");
function An(e) {
  var t;
  t = e.input.charCodeAt(e.position), t === 10 ? e.position++ : t === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : G(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1;
}
d(An, "readLineBreak");
function dt(e, t, r) {
  for (var i = 0, n = e.input.charCodeAt(e.position); n !== 0; ) {
    for (; we(n); )
      n === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), n = e.input.charCodeAt(++e.position);
    if (t && n === 35)
      do
        n = e.input.charCodeAt(++e.position);
      while (n !== 10 && n !== 13 && n !== 0);
    if (Gt(n))
      for (An(e), n = e.input.charCodeAt(e.position), i++, e.lineIndent = 0; n === 32; )
        e.lineIndent++, n = e.input.charCodeAt(++e.position);
    else
      break;
  }
  return r !== -1 && i !== 0 && e.lineIndent < r && Kr(e, "deficient indentation"), i;
}
d(dt, "skipSeparationSpace");
function ui(e) {
  var t = e.position, r;
  return r = e.input.charCodeAt(t), !!((r === 45 || r === 46) && r === e.input.charCodeAt(t + 1) && r === e.input.charCodeAt(t + 2) && (t += 3, r = e.input.charCodeAt(t), r === 0 || $t(r)));
}
d(ui, "testDocumentSeparator");
function $n(e, t) {
  t === 1 ? e.result += " " : t > 1 && (e.result += xt.repeat(`
`, t - 1));
}
d($n, "writeFoldedLines");
function ih(e, t, r) {
  var i, n, a, o, s, l, c, h, u = e.kind, f = e.result, p;
  if (p = e.input.charCodeAt(e.position), $t(p) || Oe(p) || p === 35 || p === 38 || p === 42 || p === 33 || p === 124 || p === 62 || p === 39 || p === 34 || p === 37 || p === 64 || p === 96 || (p === 63 || p === 45) && (n = e.input.charCodeAt(e.position + 1), $t(n) || r && Oe(n)))
    return !1;
  for (e.kind = "scalar", e.result = "", a = o = e.position, s = !1; p !== 0; ) {
    if (p === 58) {
      if (n = e.input.charCodeAt(e.position + 1), $t(n) || r && Oe(n))
        break;
    } else if (p === 35) {
      if (i = e.input.charCodeAt(e.position - 1), $t(i))
        break;
    } else {
      if (e.position === e.lineStart && ui(e) || r && Oe(p))
        break;
      if (Gt(p))
        if (l = e.line, c = e.lineStart, h = e.lineIndent, dt(e, !1, -1), e.lineIndent >= t) {
          s = !0, p = e.input.charCodeAt(e.position);
          continue;
        } else {
          e.position = o, e.line = l, e.lineStart = c, e.lineIndent = h;
          break;
        }
    }
    s && (fe(e, a, o, !1), $n(e, e.line - l), a = o = e.position, s = !1), we(p) || (o = e.position + 1), p = e.input.charCodeAt(++e.position);
  }
  return fe(e, a, o, !1), e.result ? !0 : (e.kind = u, e.result = f, !1);
}
d(ih, "readPlainScalar");
function nh(e, t) {
  var r, i, n;
  if (r = e.input.charCodeAt(e.position), r !== 39)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, i = n = e.position; (r = e.input.charCodeAt(e.position)) !== 0; )
    if (r === 39)
      if (fe(e, i, e.position, !0), r = e.input.charCodeAt(++e.position), r === 39)
        i = e.position, e.position++, n = e.position;
      else
        return !0;
    else Gt(r) ? (fe(e, i, n, !0), $n(e, dt(e, !1, t)), i = n = e.position) : e.position === e.lineStart && ui(e) ? G(e, "unexpected end of the document within a single quoted scalar") : (e.position++, n = e.position);
  G(e, "unexpected end of the stream within a single quoted scalar");
}
d(nh, "readSingleQuotedScalar");
function ah(e, t) {
  var r, i, n, a, o, s;
  if (s = e.input.charCodeAt(e.position), s !== 34)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, r = i = e.position; (s = e.input.charCodeAt(e.position)) !== 0; ) {
    if (s === 34)
      return fe(e, r, e.position, !0), e.position++, !0;
    if (s === 92) {
      if (fe(e, r, e.position, !0), s = e.input.charCodeAt(++e.position), Gt(s))
        dt(e, !1, t);
      else if (s < 256 && th[s])
        e.result += eh[s], e.position++;
      else if ((o = Kc(s)) > 0) {
        for (n = o, a = 0; n > 0; n--)
          s = e.input.charCodeAt(++e.position), (o = Zc(s)) >= 0 ? a = (a << 4) + o : G(e, "expected hexadecimal character");
        e.result += Jc(a), e.position++;
      } else
        G(e, "unknown escape sequence");
      r = i = e.position;
    } else Gt(s) ? (fe(e, r, i, !0), $n(e, dt(e, !1, t)), r = i = e.position) : e.position === e.lineStart && ui(e) ? G(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i = e.position);
  }
  G(e, "unexpected end of the stream within a double quoted scalar");
}
d(ah, "readDoubleQuotedScalar");
function sh(e, t) {
  var r = !0, i, n, a, o = e.tag, s, l = e.anchor, c, h, u, f, p, g = /* @__PURE__ */ Object.create(null), m, y, x, b;
  if (b = e.input.charCodeAt(e.position), b === 91)
    h = 93, p = !1, s = [];
  else if (b === 123)
    h = 125, p = !0, s = {};
  else
    return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = s), b = e.input.charCodeAt(++e.position); b !== 0; ) {
    if (dt(e, !0, t), b = e.input.charCodeAt(e.position), b === h)
      return e.position++, e.tag = o, e.anchor = l, e.kind = p ? "mapping" : "sequence", e.result = s, !0;
    r ? b === 44 && G(e, "expected the node content, but found ','") : G(e, "missed comma between flow collection entries"), y = m = x = null, u = f = !1, b === 63 && (c = e.input.charCodeAt(e.position + 1), $t(c) && (u = f = !0, e.position++, dt(e, !0, t))), i = e.line, n = e.lineStart, a = e.position, qe(e, t, Xi, !1, !0), y = e.tag, m = e.result, dt(e, !0, t), b = e.input.charCodeAt(e.position), (f || e.line === i) && b === 58 && (u = !0, b = e.input.charCodeAt(++e.position), dt(e, !0, t), qe(e, t, Xi, !1, !0), x = e.result), p ? De(e, s, g, y, m, x, i, n, a) : u ? s.push(De(e, null, g, y, m, x, i, n, a)) : s.push(m), dt(e, !0, t), b = e.input.charCodeAt(e.position), b === 44 ? (r = !0, b = e.input.charCodeAt(++e.position)) : r = !1;
  }
  G(e, "unexpected end of the stream within a flow collection");
}
d(sh, "readFlowCollection");
function oh(e, t) {
  var r, i, n = Jn, a = !1, o = !1, s = t, l = 0, c = !1, h, u;
  if (u = e.input.charCodeAt(e.position), u === 124)
    i = !1;
  else if (u === 62)
    i = !0;
  else
    return !1;
  for (e.kind = "scalar", e.result = ""; u !== 0; )
    if (u = e.input.charCodeAt(++e.position), u === 43 || u === 45)
      Jn === n ? n = u === 43 ? xo : F0 : G(e, "repeat of a chomping mode identifier");
    else if ((h = Qc(u)) >= 0)
      h === 0 ? G(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : o ? G(e, "repeat of an indentation width identifier") : (s = t + h - 1, o = !0);
    else
      break;
  if (we(u)) {
    do
      u = e.input.charCodeAt(++e.position);
    while (we(u));
    if (u === 35)
      do
        u = e.input.charCodeAt(++e.position);
      while (!Gt(u) && u !== 0);
  }
  for (; u !== 0; ) {
    for (An(e), e.lineIndent = 0, u = e.input.charCodeAt(e.position); (!o || e.lineIndent < s) && u === 32; )
      e.lineIndent++, u = e.input.charCodeAt(++e.position);
    if (!o && e.lineIndent > s && (s = e.lineIndent), Gt(u)) {
      l++;
      continue;
    }
    if (e.lineIndent < s) {
      n === xo ? e.result += xt.repeat(`
`, a ? 1 + l : l) : n === Jn && a && (e.result += `
`);
      break;
    }
    for (i ? we(u) ? (c = !0, e.result += xt.repeat(`
`, a ? 1 + l : l)) : c ? (c = !1, e.result += xt.repeat(`
`, l + 1)) : l === 0 ? a && (e.result += " ") : e.result += xt.repeat(`
`, l) : e.result += xt.repeat(`
`, a ? 1 + l : l), a = !0, o = !0, l = 0, r = e.position; !Gt(u) && u !== 0; )
      u = e.input.charCodeAt(++e.position);
    fe(e, r, e.position, !1);
  }
  return !0;
}
d(oh, "readBlockScalar");
function ka(e, t) {
  var r, i = e.tag, n = e.anchor, a = [], o, s = !1, l;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = a), l = e.input.charCodeAt(e.position); l !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, G(e, "tab characters must not be used in indentation")), !(l !== 45 || (o = e.input.charCodeAt(e.position + 1), !$t(o)))); ) {
    if (s = !0, e.position++, dt(e, !0, -1) && e.lineIndent <= t) {
      a.push(null), l = e.input.charCodeAt(e.position);
      continue;
    }
    if (r = e.line, qe(e, t, Uc, !1, !0), a.push(e.result), dt(e, !0, -1), l = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t) && l !== 0)
      G(e, "bad indentation of a sequence entry");
    else if (e.lineIndent < t)
      break;
  }
  return s ? (e.tag = i, e.anchor = n, e.kind = "sequence", e.result = a, !0) : !1;
}
d(ka, "readBlockSequence");
function lh(e, t, r) {
  var i, n, a, o, s, l, c = e.tag, h = e.anchor, u = {}, f = /* @__PURE__ */ Object.create(null), p = null, g = null, m = null, y = !1, x = !1, b;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = u), b = e.input.charCodeAt(e.position); b !== 0; ) {
    if (!y && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, G(e, "tab characters must not be used in indentation")), i = e.input.charCodeAt(e.position + 1), a = e.line, (b === 63 || b === 58) && $t(i))
      b === 63 ? (y && (De(e, u, f, p, g, null, o, s, l), p = g = m = null), x = !0, y = !0, n = !0) : y ? (y = !1, n = !0) : G(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, b = i;
    else {
      if (o = e.line, s = e.lineStart, l = e.position, !qe(e, r, Gc, !1, !0))
        break;
      if (e.line === a) {
        for (b = e.input.charCodeAt(e.position); we(b); )
          b = e.input.charCodeAt(++e.position);
        if (b === 58)
          b = e.input.charCodeAt(++e.position), $t(b) || G(e, "a whitespace character is expected after the key-value separator within a block mapping"), y && (De(e, u, f, p, g, null, o, s, l), p = g = m = null), x = !0, y = !1, n = !1, p = e.tag, g = e.result;
        else if (x)
          G(e, "can not read an implicit mapping pair; a colon is missed");
        else
          return e.tag = c, e.anchor = h, !0;
      } else if (x)
        G(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else
        return e.tag = c, e.anchor = h, !0;
    }
    if ((e.line === a || e.lineIndent > t) && (y && (o = e.line, s = e.lineStart, l = e.position), qe(e, t, Vi, !0, n) && (y ? g = e.result : m = e.result), y || (De(e, u, f, p, g, m, o, s, l), p = g = m = null), dt(e, !0, -1), b = e.input.charCodeAt(e.position)), (e.line === a || e.lineIndent > t) && b !== 0)
      G(e, "bad indentation of a mapping entry");
    else if (e.lineIndent < t)
      break;
  }
  return y && De(e, u, f, p, g, null, o, s, l), x && (e.tag = c, e.anchor = h, e.kind = "mapping", e.result = u), x;
}
d(lh, "readBlockMapping");
function ch(e) {
  var t, r = !1, i = !1, n, a, o;
  if (o = e.input.charCodeAt(e.position), o !== 33) return !1;
  if (e.tag !== null && G(e, "duplication of a tag property"), o = e.input.charCodeAt(++e.position), o === 60 ? (r = !0, o = e.input.charCodeAt(++e.position)) : o === 33 ? (i = !0, n = "!!", o = e.input.charCodeAt(++e.position)) : n = "!", t = e.position, r) {
    do
      o = e.input.charCodeAt(++e.position);
    while (o !== 0 && o !== 62);
    e.position < e.length ? (a = e.input.slice(t, e.position), o = e.input.charCodeAt(++e.position)) : G(e, "unexpected end of the stream within a verbatim tag");
  } else {
    for (; o !== 0 && !$t(o); )
      o === 33 && (i ? G(e, "tag suffix cannot contain exclamation marks") : (n = e.input.slice(t - 1, e.position + 1), Xc.test(n) || G(e, "named tag handle cannot contain such characters"), i = !0, t = e.position + 1)), o = e.input.charCodeAt(++e.position);
    a = e.input.slice(t, e.position), D0.test(a) && G(e, "tag suffix cannot contain flow indicator characters");
  }
  a && !Vc.test(a) && G(e, "tag name cannot contain such characters: " + a);
  try {
    a = decodeURIComponent(a);
  } catch {
    G(e, "tag name is malformed: " + a);
  }
  return r ? e.tag = a : ve.call(e.tagMap, n) ? e.tag = e.tagMap[n] + a : n === "!" ? e.tag = "!" + a : n === "!!" ? e.tag = "tag:yaml.org,2002:" + a : G(e, 'undeclared tag handle "' + n + '"'), !0;
}
d(ch, "readTagProperty");
function hh(e) {
  var t, r;
  if (r = e.input.charCodeAt(e.position), r !== 38) return !1;
  for (e.anchor !== null && G(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t = e.position; r !== 0 && !$t(r) && !Oe(r); )
    r = e.input.charCodeAt(++e.position);
  return e.position === t && G(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t, e.position), !0;
}
d(hh, "readAnchorProperty");
function uh(e) {
  var t, r, i;
  if (i = e.input.charCodeAt(e.position), i !== 42) return !1;
  for (i = e.input.charCodeAt(++e.position), t = e.position; i !== 0 && !$t(i) && !Oe(i); )
    i = e.input.charCodeAt(++e.position);
  return e.position === t && G(e, "name of an alias node must contain at least one character"), r = e.input.slice(t, e.position), ve.call(e.anchorMap, r) || G(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], dt(e, !0, -1), !0;
}
d(uh, "readAlias");
function qe(e, t, r, i, n) {
  var a, o, s, l = 1, c = !1, h = !1, u, f, p, g, m, y;
  if (e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, a = o = s = Vi === r || Uc === r, i && dt(e, !0, -1) && (c = !0, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)), l === 1)
    for (; ch(e) || hh(e); )
      dt(e, !0, -1) ? (c = !0, s = a, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)) : s = !1;
  if (s && (s = c || n), (l === 1 || Vi === r) && (Xi === r || Gc === r ? m = t : m = t + 1, y = e.position - e.lineStart, l === 1 ? s && (ka(e, y) || lh(e, y, m)) || sh(e, m) ? h = !0 : (o && oh(e, m) || nh(e, m) || ah(e, m) ? h = !0 : uh(e) ? (h = !0, (e.tag !== null || e.anchor !== null) && G(e, "alias node should not have any properties")) : ih(e, m, Xi === r) && (h = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : l === 0 && (h = s && ka(e, y))), e.tag === null)
    e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
  else if (e.tag === "?") {
    for (e.result !== null && e.kind !== "scalar" && G(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"'), u = 0, f = e.implicitTypes.length; u < f; u += 1)
      if (g = e.implicitTypes[u], g.resolve(e.result)) {
        e.result = g.construct(e.result), e.tag = g.tag, e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
        break;
      }
  } else if (e.tag !== "!") {
    if (ve.call(e.typeMap[e.kind || "fallback"], e.tag))
      g = e.typeMap[e.kind || "fallback"][e.tag];
    else
      for (g = null, p = e.typeMap.multi[e.kind || "fallback"], u = 0, f = p.length; u < f; u += 1)
        if (e.tag.slice(0, p[u].tag.length) === p[u].tag) {
          g = p[u];
          break;
        }
    g || G(e, "unknown tag !<" + e.tag + ">"), e.result !== null && g.kind !== e.kind && G(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + g.kind + '", not "' + e.kind + '"'), g.resolve(e.result, e.tag) ? (e.result = g.construct(e.result, e.tag), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : G(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
  }
  return e.listener !== null && e.listener("close", e), e.tag !== null || e.anchor !== null || h;
}
d(qe, "composeNode");
function fh(e) {
  var t = e.position, r, i, n, a = !1, o;
  for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = /* @__PURE__ */ Object.create(null), e.anchorMap = /* @__PURE__ */ Object.create(null); (o = e.input.charCodeAt(e.position)) !== 0 && (dt(e, !0, -1), o = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || o !== 37)); ) {
    for (a = !0, o = e.input.charCodeAt(++e.position), r = e.position; o !== 0 && !$t(o); )
      o = e.input.charCodeAt(++e.position);
    for (i = e.input.slice(r, e.position), n = [], i.length < 1 && G(e, "directive name must not be less than one character in length"); o !== 0; ) {
      for (; we(o); )
        o = e.input.charCodeAt(++e.position);
      if (o === 35) {
        do
          o = e.input.charCodeAt(++e.position);
        while (o !== 0 && !Gt(o));
        break;
      }
      if (Gt(o)) break;
      for (r = e.position; o !== 0 && !$t(o); )
        o = e.input.charCodeAt(++e.position);
      n.push(e.input.slice(r, e.position));
    }
    o !== 0 && An(e), ve.call(bo, i) ? bo[i](e, i, n) : Kr(e, 'unknown document directive "' + i + '"');
  }
  if (dt(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, dt(e, !0, -1)) : a && G(e, "directives end mark is expected"), qe(e, e.lineIndent - 1, Vi, !1, !0), dt(e, !0, -1), e.checkLineBreaks && O0.test(e.input.slice(t, e.position)) && Kr(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && ui(e)) {
    e.input.charCodeAt(e.position) === 46 && (e.position += 3, dt(e, !0, -1));
    return;
  }
  if (e.position < e.length - 1)
    G(e, "end of the stream or a document separator is expected");
  else
    return;
}
d(fh, "readDocument");
function _s(e, t) {
  e = String(e), t = t || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
  var r = new rh(e, t), i = e.indexOf("\0");
  for (i !== -1 && (r.position = i, G(r, "null byte is not allowed in input")), r.input += "\0"; r.input.charCodeAt(r.position) === 32; )
    r.lineIndent += 1, r.position += 1;
  for (; r.position < r.length - 1; )
    fh(r);
  return r.documents;
}
d(_s, "loadDocuments");
function R0(e, t, r) {
  t !== null && typeof t == "object" && typeof r > "u" && (r = t, t = null);
  var i = _s(e, r);
  if (typeof t != "function")
    return i;
  for (var n = 0, a = i.length; n < a; n += 1)
    t(i[n]);
}
d(R0, "loadAll$1");
function ph(e, t) {
  var r = _s(e, t);
  if (r.length !== 0) {
    if (r.length === 1)
      return r[0];
    throw new Rt("expected a single document in the stream, but found more");
  }
}
d(ph, "load$1");
var I0 = ph, P0 = {
  load: I0
}, dh = Object.prototype.toString, gh = Object.prototype.hasOwnProperty, ws = 65279, N0 = 9, Qr = 10, z0 = 13, q0 = 32, W0 = 33, H0 = 34, Sa = 35, j0 = 37, Y0 = 38, G0 = 39, U0 = 42, mh = 44, X0 = 45, Zi = 58, V0 = 61, Z0 = 62, K0 = 63, Q0 = 64, yh = 91, xh = 93, J0 = 96, bh = 123, tm = 124, Ch = 125, Lt = {};
Lt[0] = "\\0";
Lt[7] = "\\a";
Lt[8] = "\\b";
Lt[9] = "\\t";
Lt[10] = "\\n";
Lt[11] = "\\v";
Lt[12] = "\\f";
Lt[13] = "\\r";
Lt[27] = "\\e";
Lt[34] = '\\"';
Lt[92] = "\\\\";
Lt[133] = "\\N";
Lt[160] = "\\_";
Lt[8232] = "\\L";
Lt[8233] = "\\P";
var em = [
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
], rm = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
function _h(e, t) {
  var r, i, n, a, o, s, l;
  if (t === null) return {};
  for (r = {}, i = Object.keys(t), n = 0, a = i.length; n < a; n += 1)
    o = i[n], s = String(t[o]), o.slice(0, 2) === "!!" && (o = "tag:yaml.org,2002:" + o.slice(2)), l = e.compiledTypeMap.fallback[o], l && gh.call(l.styleAliases, s) && (s = l.styleAliases[s]), r[o] = s;
  return r;
}
d(_h, "compileStyleMap");
function wh(e) {
  var t, r, i;
  if (t = e.toString(16).toUpperCase(), e <= 255)
    r = "x", i = 2;
  else if (e <= 65535)
    r = "u", i = 4;
  else if (e <= 4294967295)
    r = "U", i = 8;
  else
    throw new Rt("code point within a string may not be greater than 0xFFFFFFFF");
  return "\\" + r + xt.repeat("0", i - t.length) + t;
}
d(wh, "encodeHex");
var im = 1, Jr = 2;
function vh(e) {
  this.schema = e.schema || Yc, this.indent = Math.max(1, e.indent || 2), this.noArrayIndent = e.noArrayIndent || !1, this.skipInvalid = e.skipInvalid || !1, this.flowLevel = xt.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = _h(this.schema, e.styles || null), this.sortKeys = e.sortKeys || !1, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || !1, this.noCompatMode = e.noCompatMode || !1, this.condenseFlow = e.condenseFlow || !1, this.quotingType = e.quotingType === '"' ? Jr : im, this.forceQuotes = e.forceQuotes || !1, this.replacer = typeof e.replacer == "function" ? e.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
}
d(vh, "State");
function Ta(e, t) {
  for (var r = xt.repeat(" ", t), i = 0, n = -1, a = "", o, s = e.length; i < s; )
    n = e.indexOf(`
`, i), n === -1 ? (o = e.slice(i), i = s) : (o = e.slice(i, n + 1), i = n + 1), o.length && o !== `
` && (a += r), a += o;
  return a;
}
d(Ta, "indentString");
function Ki(e, t) {
  return `
` + xt.repeat(" ", e.indent * t);
}
d(Ki, "generateNextLine");
function kh(e, t) {
  var r, i, n;
  for (r = 0, i = e.implicitTypes.length; r < i; r += 1)
    if (n = e.implicitTypes[r], n.resolve(t))
      return !0;
  return !1;
}
d(kh, "testImplicitResolving");
function ti(e) {
  return e === q0 || e === N0;
}
d(ti, "isWhitespace");
function br(e) {
  return 32 <= e && e <= 126 || 161 <= e && e <= 55295 && e !== 8232 && e !== 8233 || 57344 <= e && e <= 65533 && e !== ws || 65536 <= e && e <= 1114111;
}
d(br, "isPrintable");
function Ba(e) {
  return br(e) && e !== ws && e !== z0 && e !== Qr;
}
d(Ba, "isNsCharOrWhitespace");
function La(e, t, r) {
  var i = Ba(e), n = i && !ti(e);
  return (
    // ns-plain-safe
    (r ? (
      // c = flow-in
      i
    ) : i && e !== mh && e !== yh && e !== xh && e !== bh && e !== Ch) && e !== Sa && !(t === Zi && !n) || Ba(t) && !ti(t) && e === Sa || t === Zi && n
  );
}
d(La, "isPlainSafe");
function Sh(e) {
  return br(e) && e !== ws && !ti(e) && e !== X0 && e !== K0 && e !== Zi && e !== mh && e !== yh && e !== xh && e !== bh && e !== Ch && e !== Sa && e !== Y0 && e !== U0 && e !== W0 && e !== tm && e !== V0 && e !== Z0 && e !== G0 && e !== H0 && e !== j0 && e !== Q0 && e !== J0;
}
d(Sh, "isPlainSafeFirst");
function Th(e) {
  return !ti(e) && e !== Zi;
}
d(Th, "isPlainSafeLast");
function er(e, t) {
  var r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && t + 1 < e.length && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
d(er, "codePointAt");
function vs(e) {
  var t = /^\n* /;
  return t.test(e);
}
d(vs, "needIndentIndicator");
var Bh = 1, Ma = 2, Lh = 3, Mh = 4, Je = 5;
function Ah(e, t, r, i, n, a, o, s) {
  var l, c = 0, h = null, u = !1, f = !1, p = i !== -1, g = -1, m = Sh(er(e, 0)) && Th(er(e, e.length - 1));
  if (t || o)
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = er(e, l), !br(c))
        return Je;
      m = m && La(c, h, s), h = c;
    }
  else {
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = er(e, l), c === Qr)
        u = !0, p && (f = f || // Foldable line = too long, and not more-indented.
        l - g - 1 > i && e[g + 1] !== " ", g = l);
      else if (!br(c))
        return Je;
      m = m && La(c, h, s), h = c;
    }
    f = f || p && l - g - 1 > i && e[g + 1] !== " ";
  }
  return !u && !f ? m && !o && !n(e) ? Bh : a === Jr ? Je : Ma : r > 9 && vs(e) ? Je : o ? a === Jr ? Je : Ma : f ? Mh : Lh;
}
d(Ah, "chooseScalarStyle");
function $h(e, t, r, i, n) {
  e.dump = function() {
    if (t.length === 0)
      return e.quotingType === Jr ? '""' : "''";
    if (!e.noCompatMode && (em.indexOf(t) !== -1 || rm.test(t)))
      return e.quotingType === Jr ? '"' + t + '"' : "'" + t + "'";
    var a = e.indent * Math.max(1, r), o = e.lineWidth === -1 ? -1 : Math.max(Math.min(e.lineWidth, 40), e.lineWidth - a), s = i || e.flowLevel > -1 && r >= e.flowLevel;
    function l(c) {
      return kh(e, c);
    }
    switch (d(l, "testAmbiguity"), Ah(
      t,
      s,
      e.indent,
      o,
      l,
      e.quotingType,
      e.forceQuotes && !i,
      n
    )) {
      case Bh:
        return t;
      case Ma:
        return "'" + t.replace(/'/g, "''") + "'";
      case Lh:
        return "|" + Aa(t, e.indent) + $a(Ta(t, a));
      case Mh:
        return ">" + Aa(t, e.indent) + $a(Ta(Fh(t, o), a));
      case Je:
        return '"' + Eh(t) + '"';
      default:
        throw new Rt("impossible error: invalid scalar style");
    }
  }();
}
d($h, "writeScalar");
function Aa(e, t) {
  var r = vs(e) ? String(t) : "", i = e[e.length - 1] === `
`, n = i && (e[e.length - 2] === `
` || e === `
`), a = n ? "+" : i ? "" : "-";
  return r + a + `
`;
}
d(Aa, "blockHeader");
function $a(e) {
  return e[e.length - 1] === `
` ? e.slice(0, -1) : e;
}
d($a, "dropEndingNewline");
function Fh(e, t) {
  for (var r = /(\n+)([^\n]*)/g, i = function() {
    var c = e.indexOf(`
`);
    return c = c !== -1 ? c : e.length, r.lastIndex = c, Fa(e.slice(0, c), t);
  }(), n = e[0] === `
` || e[0] === " ", a, o; o = r.exec(e); ) {
    var s = o[1], l = o[2];
    a = l[0] === " ", i += s + (!n && !a && l !== "" ? `
` : "") + Fa(l, t), n = a;
  }
  return i;
}
d(Fh, "foldString");
function Fa(e, t) {
  if (e === "" || e[0] === " ") return e;
  for (var r = / [^ ]/g, i, n = 0, a, o = 0, s = 0, l = ""; i = r.exec(e); )
    s = i.index, s - n > t && (a = o > n ? o : s, l += `
` + e.slice(n, a), n = a + 1), o = s;
  return l += `
`, e.length - n > t && o > n ? l += e.slice(n, o) + `
` + e.slice(o + 1) : l += e.slice(n), l.slice(1);
}
d(Fa, "foldLine");
function Eh(e) {
  for (var t = "", r = 0, i, n = 0; n < e.length; r >= 65536 ? n += 2 : n++)
    r = er(e, n), i = Lt[r], !i && br(r) ? (t += e[n], r >= 65536 && (t += e[n + 1])) : t += i || wh(r);
  return t;
}
d(Eh, "escapeString");
function Oh(e, t, r) {
  var i = "", n = e.tag, a, o, s;
  for (a = 0, o = r.length; a < o; a += 1)
    s = r[a], e.replacer && (s = e.replacer.call(r, String(a), s)), (re(e, t, s, !1, !1) || typeof s > "u" && re(e, t, null, !1, !1)) && (i !== "" && (i += "," + (e.condenseFlow ? "" : " ")), i += e.dump);
  e.tag = n, e.dump = "[" + i + "]";
}
d(Oh, "writeFlowSequence");
function Ea(e, t, r, i) {
  var n = "", a = e.tag, o, s, l;
  for (o = 0, s = r.length; o < s; o += 1)
    l = r[o], e.replacer && (l = e.replacer.call(r, String(o), l)), (re(e, t + 1, l, !0, !0, !1, !0) || typeof l > "u" && re(e, t + 1, null, !0, !0, !1, !0)) && ((!i || n !== "") && (n += Ki(e, t)), e.dump && Qr === e.dump.charCodeAt(0) ? n += "-" : n += "- ", n += e.dump);
  e.tag = a, e.dump = n || "[]";
}
d(Ea, "writeBlockSequence");
function Dh(e, t, r) {
  var i = "", n = e.tag, a = Object.keys(r), o, s, l, c, h;
  for (o = 0, s = a.length; o < s; o += 1)
    h = "", i !== "" && (h += ", "), e.condenseFlow && (h += '"'), l = a[o], c = r[l], e.replacer && (c = e.replacer.call(r, l, c)), re(e, t, l, !1, !1) && (e.dump.length > 1024 && (h += "? "), h += e.dump + (e.condenseFlow ? '"' : "") + ":" + (e.condenseFlow ? "" : " "), re(e, t, c, !1, !1) && (h += e.dump, i += h));
  e.tag = n, e.dump = "{" + i + "}";
}
d(Dh, "writeFlowMapping");
function Rh(e, t, r, i) {
  var n = "", a = e.tag, o = Object.keys(r), s, l, c, h, u, f;
  if (e.sortKeys === !0)
    o.sort();
  else if (typeof e.sortKeys == "function")
    o.sort(e.sortKeys);
  else if (e.sortKeys)
    throw new Rt("sortKeys must be a boolean or a function");
  for (s = 0, l = o.length; s < l; s += 1)
    f = "", (!i || n !== "") && (f += Ki(e, t)), c = o[s], h = r[c], e.replacer && (h = e.replacer.call(r, c, h)), re(e, t + 1, c, !0, !0, !0) && (u = e.tag !== null && e.tag !== "?" || e.dump && e.dump.length > 1024, u && (e.dump && Qr === e.dump.charCodeAt(0) ? f += "?" : f += "? "), f += e.dump, u && (f += Ki(e, t)), re(e, t + 1, h, !0, u) && (e.dump && Qr === e.dump.charCodeAt(0) ? f += ":" : f += ": ", f += e.dump, n += f));
  e.tag = a, e.dump = n || "{}";
}
d(Rh, "writeBlockMapping");
function Oa(e, t, r) {
  var i, n, a, o, s, l;
  for (n = r ? e.explicitTypes : e.implicitTypes, a = 0, o = n.length; a < o; a += 1)
    if (s = n[a], (s.instanceOf || s.predicate) && (!s.instanceOf || typeof t == "object" && t instanceof s.instanceOf) && (!s.predicate || s.predicate(t))) {
      if (r ? s.multi && s.representName ? e.tag = s.representName(t) : e.tag = s.tag : e.tag = "?", s.represent) {
        if (l = e.styleMap[s.tag] || s.defaultStyle, dh.call(s.represent) === "[object Function]")
          i = s.represent(t, l);
        else if (gh.call(s.represent, l))
          i = s.represent[l](t, l);
        else
          throw new Rt("!<" + s.tag + '> tag resolver accepts not "' + l + '" style');
        e.dump = i;
      }
      return !0;
    }
  return !1;
}
d(Oa, "detectType");
function re(e, t, r, i, n, a, o) {
  e.tag = null, e.dump = r, Oa(e, r, !1) || Oa(e, r, !0);
  var s = dh.call(e.dump), l = i, c;
  i && (i = e.flowLevel < 0 || e.flowLevel > t);
  var h = s === "[object Object]" || s === "[object Array]", u, f;
  if (h && (u = e.duplicates.indexOf(r), f = u !== -1), (e.tag !== null && e.tag !== "?" || f || e.indent !== 2 && t > 0) && (n = !1), f && e.usedDuplicates[u])
    e.dump = "*ref_" + u;
  else {
    if (h && f && !e.usedDuplicates[u] && (e.usedDuplicates[u] = !0), s === "[object Object]")
      i && Object.keys(e.dump).length !== 0 ? (Rh(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (Dh(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object Array]")
      i && e.dump.length !== 0 ? (e.noArrayIndent && !o && t > 0 ? Ea(e, t - 1, e.dump, n) : Ea(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (Oh(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object String]")
      e.tag !== "?" && $h(e, e.dump, t, a, l);
    else {
      if (s === "[object Undefined]")
        return !1;
      if (e.skipInvalid) return !1;
      throw new Rt("unacceptable kind of an object to dump " + s);
    }
    e.tag !== null && e.tag !== "?" && (c = encodeURI(
      e.tag[0] === "!" ? e.tag.slice(1) : e.tag
    ).replace(/!/g, "%21"), e.tag[0] === "!" ? c = "!" + c : c.slice(0, 18) === "tag:yaml.org,2002:" ? c = "!!" + c.slice(18) : c = "!<" + c + ">", e.dump = c + " " + e.dump);
  }
  return !0;
}
d(re, "writeNode");
function Ih(e, t) {
  var r = [], i = [], n, a;
  for (Qi(e, r, i), n = 0, a = i.length; n < a; n += 1)
    t.duplicates.push(r[i[n]]);
  t.usedDuplicates = new Array(a);
}
d(Ih, "getDuplicateReferences");
function Qi(e, t, r) {
  var i, n, a;
  if (e !== null && typeof e == "object")
    if (n = t.indexOf(e), n !== -1)
      r.indexOf(n) === -1 && r.push(n);
    else if (t.push(e), Array.isArray(e))
      for (n = 0, a = e.length; n < a; n += 1)
        Qi(e[n], t, r);
    else
      for (i = Object.keys(e), n = 0, a = i.length; n < a; n += 1)
        Qi(e[i[n]], t, r);
}
d(Qi, "inspectNode");
function nm(e, t) {
  t = t || {};
  var r = new vh(t);
  r.noRefs || Ih(e, r);
  var i = e;
  return r.replacer && (i = r.replacer.call({ "": i }, "", i)), re(r, 0, i, !0, !0) ? r.dump + `
` : "";
}
d(nm, "dump$1");
function am(e, t) {
  return function() {
    throw new Error("Function yaml." + e + " is removed in js-yaml 4. Use yaml." + t + " instead, which is now safe by default.");
  };
}
d(am, "renamed");
var sm = Lc, om = P0.load;
/*! Bundled license information:

js-yaml/dist/js-yaml.mjs:
  (*! js-yaml 4.1.0 https://github.com/nodeca/js-yaml @license MIT *)
*/
var Ht = {
  aggregation: 18,
  extension: 18,
  composition: 18,
  dependency: 6,
  lollipop: 13.5,
  arrow_point: 4
};
function Nr(e, t) {
  if (e === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  e = ht(e), t = ht(t);
  const [r, i] = [e.x, e.y], [n, a] = [t.x, t.y], o = n - r, s = a - i;
  return { angle: Math.atan(s / o), deltaX: o, deltaY: s };
}
d(Nr, "calculateDeltaAndAngle");
var ht = /* @__PURE__ */ d((e) => Array.isArray(e) ? { x: e[0], y: e[1] } : e, "pointTransformer"), lm = /* @__PURE__ */ d((e) => ({
  x: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = ht(i[0]).x < ht(i[i.length - 1]).x ? "left" : "right";
    if (r === 0 && Object.hasOwn(Ht, e.arrowTypeStart)) {
      const { angle: p, deltaX: g } = Nr(i[0], i[1]);
      n = Ht[e.arrowTypeStart] * Math.cos(p) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ht, e.arrowTypeEnd)) {
      const { angle: p, deltaX: g } = Nr(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ht[e.arrowTypeEnd] * Math.cos(p) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      ht(t).x - ht(i[i.length - 1]).x
    ), s = Math.abs(
      ht(t).y - ht(i[i.length - 1]).y
    ), l = Math.abs(ht(t).x - ht(i[0]).x), c = Math.abs(ht(t).y - ht(i[0]).y), h = Ht[e.arrowTypeStart], u = Ht[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "right" ? -1 : 1, n -= p;
    }
    if (l < h && l > 0 && c < h) {
      let p = h + f - l;
      p *= a === "right" ? -1 : 1, n += p;
    }
    return ht(t).x + n;
  }, "x"),
  y: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = ht(i[0]).y < ht(i[i.length - 1]).y ? "down" : "up";
    if (r === 0 && Object.hasOwn(Ht, e.arrowTypeStart)) {
      const { angle: p, deltaY: g } = Nr(i[0], i[1]);
      n = Ht[e.arrowTypeStart] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ht, e.arrowTypeEnd)) {
      const { angle: p, deltaY: g } = Nr(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ht[e.arrowTypeEnd] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      ht(t).y - ht(i[i.length - 1]).y
    ), s = Math.abs(
      ht(t).x - ht(i[i.length - 1]).x
    ), l = Math.abs(ht(t).y - ht(i[0]).y), c = Math.abs(ht(t).x - ht(i[0]).x), h = Ht[e.arrowTypeStart], u = Ht[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "up" ? -1 : 1, n -= p;
    }
    if (l < h && l > 0 && c < h) {
      let p = h + f - l;
      p *= a === "up" ? -1 : 1, n += p;
    }
    return ht(t).y + n;
  }, "y")
}), "getLineFunctionsWithOffset"), ks = /* @__PURE__ */ d(({
  flowchart: e
}) => {
  var n, a;
  const t = ((n = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : n.top) ?? 0, r = ((a = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : a.bottom) ?? 0, i = t + r;
  return {
    subGraphTitleTopMargin: t,
    subGraphTitleBottomMargin: r,
    subGraphTitleTotalMargin: i
  };
}, "getSubGraphTitleMargins"), Ss = {}, Ct = {};
Object.defineProperty(Ct, "__esModule", { value: !0 });
Ct.BLANK_URL = Ct.relativeFirstCharacters = Ct.whitespaceEscapeCharsRegex = Ct.urlSchemeRegex = Ct.ctrlCharactersRegex = Ct.htmlCtrlEntityRegex = Ct.htmlEntitiesRegex = Ct.invalidProtocolRegex = void 0;
Ct.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im;
Ct.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g;
Ct.htmlCtrlEntityRegex = /&(newline|tab);/gi;
Ct.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim;
Ct.urlSchemeRegex = /^.+(:|&colon;)/gim;
Ct.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g;
Ct.relativeFirstCharacters = [".", "/"];
Ct.BLANK_URL = "about:blank";
Object.defineProperty(Ss, "__esModule", { value: !0 });
var Ph = Ss.sanitizeUrl = void 0, Tt = Ct;
function cm(e) {
  return Tt.relativeFirstCharacters.indexOf(e[0]) > -1;
}
function hm(e) {
  var t = e.replace(Tt.ctrlCharactersRegex, "");
  return t.replace(Tt.htmlEntitiesRegex, function(r, i) {
    return String.fromCharCode(i);
  });
}
function um(e) {
  return URL.canParse(e);
}
function Co(e) {
  try {
    return decodeURIComponent(e);
  } catch {
    return e;
  }
}
function fm(e) {
  if (!e)
    return Tt.BLANK_URL;
  var t, r = Co(e.trim());
  do
    r = hm(r).replace(Tt.htmlCtrlEntityRegex, "").replace(Tt.ctrlCharactersRegex, "").replace(Tt.whitespaceEscapeCharsRegex, "").trim(), r = Co(r), t = r.match(Tt.ctrlCharactersRegex) || r.match(Tt.htmlEntitiesRegex) || r.match(Tt.htmlCtrlEntityRegex) || r.match(Tt.whitespaceEscapeCharsRegex);
  while (t && t.length > 0);
  var i = r;
  if (!i)
    return Tt.BLANK_URL;
  if (cm(i))
    return i;
  var n = i.trimStart(), a = n.match(Tt.urlSchemeRegex);
  if (!a)
    return i;
  var o = a[0].toLowerCase().trim();
  if (Tt.invalidProtocolRegex.test(o))
    return Tt.BLANK_URL;
  var s = n.replace(/\\/g, "/");
  if (o === "mailto:" || o.includes("://"))
    return s;
  if (o === "http:" || o === "https:") {
    if (!um(s))
      return Tt.BLANK_URL;
    var l = new URL(s);
    return l.protocol = l.protocol.toLowerCase(), l.hostname = l.hostname.toLowerCase(), l.toString();
  }
  return s;
}
Ph = Ss.sanitizeUrl = fm;
var pm = { value: () => {
} };
function Nh() {
  for (var e = 0, t = arguments.length, r = {}, i; e < t; ++e) {
    if (!(i = arguments[e] + "") || i in r || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    r[i] = [];
  }
  return new Ei(r);
}
function Ei(e) {
  this._ = e;
}
function dm(e, t) {
  return e.trim().split(/^|\s+/).map(function(r) {
    var i = "", n = r.indexOf(".");
    if (n >= 0 && (i = r.slice(n + 1), r = r.slice(0, n)), r && !t.hasOwnProperty(r)) throw new Error("unknown type: " + r);
    return { type: r, name: i };
  });
}
Ei.prototype = Nh.prototype = {
  constructor: Ei,
  on: function(e, t) {
    var r = this._, i = dm(e + "", r), n, a = -1, o = i.length;
    if (arguments.length < 2) {
      for (; ++a < o; ) if ((n = (e = i[a]).type) && (n = gm(r[n], e.name))) return n;
      return;
    }
    if (t != null && typeof t != "function") throw new Error("invalid callback: " + t);
    for (; ++a < o; )
      if (n = (e = i[a]).type) r[n] = _o(r[n], e.name, t);
      else if (t == null) for (n in r) r[n] = _o(r[n], e.name, null);
    return this;
  },
  copy: function() {
    var e = {}, t = this._;
    for (var r in t) e[r] = t[r].slice();
    return new Ei(e);
  },
  call: function(e, t) {
    if ((n = arguments.length - 2) > 0) for (var r = new Array(n), i = 0, n, a; i < n; ++i) r[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (a = this._[e], i = 0, n = a.length; i < n; ++i) a[i].value.apply(t, r);
  },
  apply: function(e, t, r) {
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (var i = this._[e], n = 0, a = i.length; n < a; ++n) i[n].value.apply(t, r);
  }
};
function gm(e, t) {
  for (var r = 0, i = e.length, n; r < i; ++r)
    if ((n = e[r]).name === t)
      return n.value;
}
function _o(e, t, r) {
  for (var i = 0, n = e.length; i < n; ++i)
    if (e[i].name === t) {
      e[i] = pm, e = e.slice(0, i).concat(e.slice(i + 1));
      break;
    }
  return r != null && e.push({ name: t, value: r }), e;
}
var Da = "http://www.w3.org/1999/xhtml";
const wo = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: Da,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function Fn(e) {
  var t = e += "", r = t.indexOf(":");
  return r >= 0 && (t = e.slice(0, r)) !== "xmlns" && (e = e.slice(r + 1)), wo.hasOwnProperty(t) ? { space: wo[t], local: e } : e;
}
function mm(e) {
  return function() {
    var t = this.ownerDocument, r = this.namespaceURI;
    return r === Da && t.documentElement.namespaceURI === Da ? t.createElement(e) : t.createElementNS(r, e);
  };
}
function ym(e) {
  return function() {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function zh(e) {
  var t = Fn(e);
  return (t.local ? ym : mm)(t);
}
function xm() {
}
function Ts(e) {
  return e == null ? xm : function() {
    return this.querySelector(e);
  };
}
function bm(e) {
  typeof e != "function" && (e = Ts(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = new Array(o), l, c, h = 0; h < o; ++h)
      (l = a[h]) && (c = e.call(l, l.__data__, h, a)) && ("__data__" in l && (c.__data__ = l.__data__), s[h] = c);
  return new qt(i, this._parents);
}
function Cm(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function _m() {
  return [];
}
function qh(e) {
  return e == null ? _m : function() {
    return this.querySelectorAll(e);
  };
}
function wm(e) {
  return function() {
    return Cm(e.apply(this, arguments));
  };
}
function vm(e) {
  typeof e == "function" ? e = wm(e) : e = qh(e);
  for (var t = this._groups, r = t.length, i = [], n = [], a = 0; a < r; ++a)
    for (var o = t[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && (i.push(e.call(l, l.__data__, c, o)), n.push(l));
  return new qt(i, n);
}
function Wh(e) {
  return function() {
    return this.matches(e);
  };
}
function Hh(e) {
  return function(t) {
    return t.matches(e);
  };
}
var km = Array.prototype.find;
function Sm(e) {
  return function() {
    return km.call(this.children, e);
  };
}
function Tm() {
  return this.firstElementChild;
}
function Bm(e) {
  return this.select(e == null ? Tm : Sm(typeof e == "function" ? e : Hh(e)));
}
var Lm = Array.prototype.filter;
function Mm() {
  return Array.from(this.children);
}
function Am(e) {
  return function() {
    return Lm.call(this.children, e);
  };
}
function $m(e) {
  return this.selectAll(e == null ? Mm : Am(typeof e == "function" ? e : Hh(e)));
}
function Fm(e) {
  typeof e != "function" && (e = Wh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new qt(i, this._parents);
}
function jh(e) {
  return new Array(e.length);
}
function Em() {
  return new qt(this._enter || this._groups.map(jh), this._parents);
}
function Ji(e, t) {
  this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t;
}
Ji.prototype = {
  constructor: Ji,
  appendChild: function(e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function(e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function(e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function(e) {
    return this._parent.querySelectorAll(e);
  }
};
function Om(e) {
  return function() {
    return e;
  };
}
function Dm(e, t, r, i, n, a) {
  for (var o = 0, s, l = t.length, c = a.length; o < c; ++o)
    (s = t[o]) ? (s.__data__ = a[o], i[o] = s) : r[o] = new Ji(e, a[o]);
  for (; o < l; ++o)
    (s = t[o]) && (n[o] = s);
}
function Rm(e, t, r, i, n, a, o) {
  var s, l, c = /* @__PURE__ */ new Map(), h = t.length, u = a.length, f = new Array(h), p;
  for (s = 0; s < h; ++s)
    (l = t[s]) && (f[s] = p = o.call(l, l.__data__, s, t) + "", c.has(p) ? n[s] = l : c.set(p, l));
  for (s = 0; s < u; ++s)
    p = o.call(e, a[s], s, a) + "", (l = c.get(p)) ? (i[s] = l, l.__data__ = a[s], c.delete(p)) : r[s] = new Ji(e, a[s]);
  for (s = 0; s < h; ++s)
    (l = t[s]) && c.get(f[s]) === l && (n[s] = l);
}
function Im(e) {
  return e.__data__;
}
function Pm(e, t) {
  if (!arguments.length) return Array.from(this, Im);
  var r = t ? Rm : Dm, i = this._parents, n = this._groups;
  typeof e != "function" && (e = Om(e));
  for (var a = n.length, o = new Array(a), s = new Array(a), l = new Array(a), c = 0; c < a; ++c) {
    var h = i[c], u = n[c], f = u.length, p = Nm(e.call(h, h && h.__data__, c, i)), g = p.length, m = s[c] = new Array(g), y = o[c] = new Array(g), x = l[c] = new Array(f);
    r(h, u, m, y, x, p, t);
    for (var b = 0, _ = 0, S, w; b < g; ++b)
      if (S = m[b]) {
        for (b >= _ && (_ = b + 1); !(w = y[_]) && ++_ < g; ) ;
        S._next = w || null;
      }
  }
  return o = new qt(o, i), o._enter = s, o._exit = l, o;
}
function Nm(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function zm() {
  return new qt(this._exit || this._groups.map(jh), this._parents);
}
function qm(e, t, r) {
  var i = this.enter(), n = this, a = this.exit();
  return typeof e == "function" ? (i = e(i), i && (i = i.selection())) : i = i.append(e + ""), t != null && (n = t(n), n && (n = n.selection())), r == null ? a.remove() : r(a), i && n ? i.merge(n).order() : n;
}
function Wm(e) {
  for (var t = e.selection ? e.selection() : e, r = this._groups, i = t._groups, n = r.length, a = i.length, o = Math.min(n, a), s = new Array(n), l = 0; l < o; ++l)
    for (var c = r[l], h = i[l], u = c.length, f = s[l] = new Array(u), p, g = 0; g < u; ++g)
      (p = c[g] || h[g]) && (f[g] = p);
  for (; l < n; ++l)
    s[l] = r[l];
  return new qt(s, this._parents);
}
function Hm() {
  for (var e = this._groups, t = -1, r = e.length; ++t < r; )
    for (var i = e[t], n = i.length - 1, a = i[n], o; --n >= 0; )
      (o = i[n]) && (a && o.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(o, a), a = o);
  return this;
}
function jm(e) {
  e || (e = Ym);
  function t(u, f) {
    return u && f ? e(u.__data__, f.__data__) : !u - !f;
  }
  for (var r = this._groups, i = r.length, n = new Array(i), a = 0; a < i; ++a) {
    for (var o = r[a], s = o.length, l = n[a] = new Array(s), c, h = 0; h < s; ++h)
      (c = o[h]) && (l[h] = c);
    l.sort(t);
  }
  return new qt(n, this._parents).order();
}
function Ym(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function Gm() {
  var e = arguments[0];
  return arguments[0] = this, e.apply(null, arguments), this;
}
function Um() {
  return Array.from(this);
}
function Xm() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length; n < a; ++n) {
      var o = i[n];
      if (o) return o;
    }
  return null;
}
function Vm() {
  let e = 0;
  for (const t of this) ++e;
  return e;
}
function Zm() {
  return !this.node();
}
function Km(e) {
  for (var t = this._groups, r = 0, i = t.length; r < i; ++r)
    for (var n = t[r], a = 0, o = n.length, s; a < o; ++a)
      (s = n[a]) && e.call(s, s.__data__, a, n);
  return this;
}
function Qm(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function Jm(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function ty(e, t) {
  return function() {
    this.setAttribute(e, t);
  };
}
function ey(e, t) {
  return function() {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function ry(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r);
  };
}
function iy(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r);
  };
}
function ny(e, t) {
  var r = Fn(e);
  if (arguments.length < 2) {
    var i = this.node();
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r);
  }
  return this.each((t == null ? r.local ? Jm : Qm : typeof t == "function" ? r.local ? iy : ry : r.local ? ey : ty)(r, t));
}
function Yh(e) {
  return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView;
}
function ay(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function sy(e, t, r) {
  return function() {
    this.style.setProperty(e, t, r);
  };
}
function oy(e, t, r) {
  return function() {
    var i = t.apply(this, arguments);
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r);
  };
}
function ly(e, t, r) {
  return arguments.length > 1 ? this.each((t == null ? ay : typeof t == "function" ? oy : sy)(e, t, r ?? "")) : Cr(this.node(), e);
}
function Cr(e, t) {
  return e.style.getPropertyValue(t) || Yh(e).getComputedStyle(e, null).getPropertyValue(t);
}
function cy(e) {
  return function() {
    delete this[e];
  };
}
function hy(e, t) {
  return function() {
    this[e] = t;
  };
}
function uy(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? delete this[e] : this[e] = r;
  };
}
function fy(e, t) {
  return arguments.length > 1 ? this.each((t == null ? cy : typeof t == "function" ? uy : hy)(e, t)) : this.node()[e];
}
function Gh(e) {
  return e.trim().split(/^|\s+/);
}
function Bs(e) {
  return e.classList || new Uh(e);
}
function Uh(e) {
  this._node = e, this._names = Gh(e.getAttribute("class") || "");
}
Uh.prototype = {
  add: function(e) {
    var t = this._names.indexOf(e);
    t < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(e) {
    var t = this._names.indexOf(e);
    t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(e) {
    return this._names.indexOf(e) >= 0;
  }
};
function Xh(e, t) {
  for (var r = Bs(e), i = -1, n = t.length; ++i < n; ) r.add(t[i]);
}
function Vh(e, t) {
  for (var r = Bs(e), i = -1, n = t.length; ++i < n; ) r.remove(t[i]);
}
function py(e) {
  return function() {
    Xh(this, e);
  };
}
function dy(e) {
  return function() {
    Vh(this, e);
  };
}
function gy(e, t) {
  return function() {
    (t.apply(this, arguments) ? Xh : Vh)(this, e);
  };
}
function my(e, t) {
  var r = Gh(e + "");
  if (arguments.length < 2) {
    for (var i = Bs(this.node()), n = -1, a = r.length; ++n < a; ) if (!i.contains(r[n])) return !1;
    return !0;
  }
  return this.each((typeof t == "function" ? gy : t ? py : dy)(r, t));
}
function yy() {
  this.textContent = "";
}
function xy(e) {
  return function() {
    this.textContent = e;
  };
}
function by(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.textContent = t ?? "";
  };
}
function Cy(e) {
  return arguments.length ? this.each(e == null ? yy : (typeof e == "function" ? by : xy)(e)) : this.node().textContent;
}
function _y() {
  this.innerHTML = "";
}
function wy(e) {
  return function() {
    this.innerHTML = e;
  };
}
function vy(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.innerHTML = t ?? "";
  };
}
function ky(e) {
  return arguments.length ? this.each(e == null ? _y : (typeof e == "function" ? vy : wy)(e)) : this.node().innerHTML;
}
function Sy() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function Ty() {
  return this.each(Sy);
}
function By() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Ly() {
  return this.each(By);
}
function My(e) {
  var t = typeof e == "function" ? e : zh(e);
  return this.select(function() {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Ay() {
  return null;
}
function $y(e, t) {
  var r = typeof e == "function" ? e : zh(e), i = t == null ? Ay : typeof t == "function" ? t : Ts(t);
  return this.select(function() {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Fy() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function Ey() {
  return this.each(Fy);
}
function Oy() {
  var e = this.cloneNode(!1), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Dy() {
  var e = this.cloneNode(!0), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Ry(e) {
  return this.select(e ? Dy : Oy);
}
function Iy(e) {
  return arguments.length ? this.property("__data__", e) : this.node().__data__;
}
function Py(e) {
  return function(t) {
    e.call(this, t, this.__data__);
  };
}
function Ny(e) {
  return e.trim().split(/^|\s+/).map(function(t) {
    var r = "", i = t.indexOf(".");
    return i >= 0 && (r = t.slice(i + 1), t = t.slice(0, i)), { type: t, name: r };
  });
}
function zy(e) {
  return function() {
    var t = this.__on;
    if (t) {
      for (var r = 0, i = -1, n = t.length, a; r < n; ++r)
        a = t[r], (!e.type || a.type === e.type) && a.name === e.name ? this.removeEventListener(a.type, a.listener, a.options) : t[++i] = a;
      ++i ? t.length = i : delete this.__on;
    }
  };
}
function qy(e, t, r) {
  return function() {
    var i = this.__on, n, a = Py(t);
    if (i) {
      for (var o = 0, s = i.length; o < s; ++o)
        if ((n = i[o]).type === e.type && n.name === e.name) {
          this.removeEventListener(n.type, n.listener, n.options), this.addEventListener(n.type, n.listener = a, n.options = r), n.value = t;
          return;
        }
    }
    this.addEventListener(e.type, a, r), n = { type: e.type, name: e.name, value: t, listener: a, options: r }, i ? i.push(n) : this.__on = [n];
  };
}
function Wy(e, t, r) {
  var i = Ny(e + ""), n, a = i.length, o;
  if (arguments.length < 2) {
    var s = this.node().__on;
    if (s) {
      for (var l = 0, c = s.length, h; l < c; ++l)
        for (n = 0, h = s[l]; n < a; ++n)
          if ((o = i[n]).type === h.type && o.name === h.name)
            return h.value;
    }
    return;
  }
  for (s = t ? qy : zy, n = 0; n < a; ++n) this.each(s(i[n], t, r));
  return this;
}
function Zh(e, t, r) {
  var i = Yh(e), n = i.CustomEvent;
  typeof n == "function" ? n = new n(t, r) : (n = i.document.createEvent("Event"), r ? (n.initEvent(t, r.bubbles, r.cancelable), n.detail = r.detail) : n.initEvent(t, !1, !1)), e.dispatchEvent(n);
}
function Hy(e, t) {
  return function() {
    return Zh(this, e, t);
  };
}
function jy(e, t) {
  return function() {
    return Zh(this, e, t.apply(this, arguments));
  };
}
function Yy(e, t) {
  return this.each((typeof t == "function" ? jy : Hy)(e, t));
}
function* Gy() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length, o; n < a; ++n)
      (o = i[n]) && (yield o);
}
var Kh = [null];
function qt(e, t) {
  this._groups = e, this._parents = t;
}
function fi() {
  return new qt([[document.documentElement]], Kh);
}
function Uy() {
  return this;
}
qt.prototype = fi.prototype = {
  constructor: qt,
  select: bm,
  selectAll: vm,
  selectChild: Bm,
  selectChildren: $m,
  filter: Fm,
  data: Pm,
  enter: Em,
  exit: zm,
  join: qm,
  merge: Wm,
  selection: Uy,
  order: Hm,
  sort: jm,
  call: Gm,
  nodes: Um,
  node: Xm,
  size: Vm,
  empty: Zm,
  each: Km,
  attr: ny,
  style: ly,
  property: fy,
  classed: my,
  text: Cy,
  html: ky,
  raise: Ty,
  lower: Ly,
  append: My,
  insert: $y,
  remove: Ey,
  clone: Ry,
  datum: Iy,
  on: Wy,
  dispatch: Yy,
  [Symbol.iterator]: Gy
};
function et(e) {
  return typeof e == "string" ? new qt([[document.querySelector(e)]], [document.documentElement]) : new qt([[e]], Kh);
}
function Ls(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function Qh(e, t) {
  var r = Object.create(e.prototype);
  for (var i in t) r[i] = t[i];
  return r;
}
function pi() {
}
var ei = 0.7, tn = 1 / ei, ir = "\\s*([+-]?\\d+)\\s*", ri = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", te = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", Xy = /^#([0-9a-f]{3,8})$/, Vy = new RegExp(`^rgb\\(${ir},${ir},${ir}\\)$`), Zy = new RegExp(`^rgb\\(${te},${te},${te}\\)$`), Ky = new RegExp(`^rgba\\(${ir},${ir},${ir},${ri}\\)$`), Qy = new RegExp(`^rgba\\(${te},${te},${te},${ri}\\)$`), Jy = new RegExp(`^hsl\\(${ri},${te},${te}\\)$`), tx = new RegExp(`^hsla\\(${ri},${te},${te},${ri}\\)$`), vo = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
Ls(pi, ii, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: ko,
  // Deprecated! Use color.formatHex.
  formatHex: ko,
  formatHex8: ex,
  formatHsl: rx,
  formatRgb: So,
  toString: So
});
function ko() {
  return this.rgb().formatHex();
}
function ex() {
  return this.rgb().formatHex8();
}
function rx() {
  return Jh(this).formatHsl();
}
function So() {
  return this.rgb().formatRgb();
}
function ii(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = Xy.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? To(t) : r === 3 ? new It(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? Ci(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? Ci(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = Vy.exec(e)) ? new It(t[1], t[2], t[3], 1) : (t = Zy.exec(e)) ? new It(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = Ky.exec(e)) ? Ci(t[1], t[2], t[3], t[4]) : (t = Qy.exec(e)) ? Ci(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = Jy.exec(e)) ? Mo(t[1], t[2] / 100, t[3] / 100, 1) : (t = tx.exec(e)) ? Mo(t[1], t[2] / 100, t[3] / 100, t[4]) : vo.hasOwnProperty(e) ? To(vo[e]) : e === "transparent" ? new It(NaN, NaN, NaN, 0) : null;
}
function To(e) {
  return new It(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function Ci(e, t, r, i) {
  return i <= 0 && (e = t = r = NaN), new It(e, t, r, i);
}
function ix(e) {
  return e instanceof pi || (e = ii(e)), e ? (e = e.rgb(), new It(e.r, e.g, e.b, e.opacity)) : new It();
}
function Ra(e, t, r, i) {
  return arguments.length === 1 ? ix(e) : new It(e, t, r, i ?? 1);
}
function It(e, t, r, i) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +i;
}
Ls(It, Ra, Qh(pi, {
  brighter(e) {
    return e = e == null ? tn : Math.pow(tn, e), new It(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? ei : Math.pow(ei, e), new It(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new It(Pe(this.r), Pe(this.g), Pe(this.b), en(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: Bo,
  // Deprecated! Use color.formatHex.
  formatHex: Bo,
  formatHex8: nx,
  formatRgb: Lo,
  toString: Lo
}));
function Bo() {
  return `#${Re(this.r)}${Re(this.g)}${Re(this.b)}`;
}
function nx() {
  return `#${Re(this.r)}${Re(this.g)}${Re(this.b)}${Re((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function Lo() {
  const e = en(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${Pe(this.r)}, ${Pe(this.g)}, ${Pe(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function en(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function Pe(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function Re(e) {
  return e = Pe(e), (e < 16 ? "0" : "") + e.toString(16);
}
function Mo(e, t, r, i) {
  return i <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new Yt(e, t, r, i);
}
function Jh(e) {
  if (e instanceof Yt) return new Yt(e.h, e.s, e.l, e.opacity);
  if (e instanceof pi || (e = ii(e)), !e) return new Yt();
  if (e instanceof Yt) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, i = e.b / 255, n = Math.min(t, r, i), a = Math.max(t, r, i), o = NaN, s = a - n, l = (a + n) / 2;
  return s ? (t === a ? o = (r - i) / s + (r < i) * 6 : r === a ? o = (i - t) / s + 2 : o = (t - r) / s + 4, s /= l < 0.5 ? a + n : 2 - a - n, o *= 60) : s = l > 0 && l < 1 ? 0 : o, new Yt(o, s, l, e.opacity);
}
function ax(e, t, r, i) {
  return arguments.length === 1 ? Jh(e) : new Yt(e, t, r, i ?? 1);
}
function Yt(e, t, r, i) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +i;
}
Ls(Yt, ax, Qh(pi, {
  brighter(e) {
    return e = e == null ? tn : Math.pow(tn, e), new Yt(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? ei : Math.pow(ei, e), new Yt(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, i = r + (r < 0.5 ? r : 1 - r) * t, n = 2 * r - i;
    return new It(
      ta(e >= 240 ? e - 240 : e + 120, n, i),
      ta(e, n, i),
      ta(e < 120 ? e + 240 : e - 120, n, i),
      this.opacity
    );
  },
  clamp() {
    return new Yt(Ao(this.h), _i(this.s), _i(this.l), en(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = en(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${Ao(this.h)}, ${_i(this.s) * 100}%, ${_i(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function Ao(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function _i(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function ta(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const Ms = (e) => () => e;
function tu(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function sx(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(i) {
    return Math.pow(e + i * t, r);
  };
}
function _T(e, t) {
  var r = t - e;
  return r ? tu(e, r > 180 || r < -180 ? r - 360 * Math.round(r / 360) : r) : Ms(isNaN(e) ? t : e);
}
function ox(e) {
  return (e = +e) == 1 ? eu : function(t, r) {
    return r - t ? sx(t, r, e) : Ms(isNaN(t) ? r : t);
  };
}
function eu(e, t) {
  var r = t - e;
  return r ? tu(e, r) : Ms(isNaN(e) ? t : e);
}
const $o = function e(t) {
  var r = ox(t);
  function i(n, a) {
    var o = r((n = Ra(n)).r, (a = Ra(a)).r), s = r(n.g, a.g), l = r(n.b, a.b), c = eu(n.opacity, a.opacity);
    return function(h) {
      return n.r = o(h), n.g = s(h), n.b = l(h), n.opacity = c(h), n + "";
    };
  }
  return i.gamma = e, i;
}(1);
function Ce(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
var Ia = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, ea = new RegExp(Ia.source, "g");
function lx(e) {
  return function() {
    return e;
  };
}
function cx(e) {
  return function(t) {
    return e(t) + "";
  };
}
function hx(e, t) {
  var r = Ia.lastIndex = ea.lastIndex = 0, i, n, a, o = -1, s = [], l = [];
  for (e = e + "", t = t + ""; (i = Ia.exec(e)) && (n = ea.exec(t)); )
    (a = n.index) > r && (a = t.slice(r, a), s[o] ? s[o] += a : s[++o] = a), (i = i[0]) === (n = n[0]) ? s[o] ? s[o] += n : s[++o] = n : (s[++o] = null, l.push({ i: o, x: Ce(i, n) })), r = ea.lastIndex;
  return r < t.length && (a = t.slice(r), s[o] ? s[o] += a : s[++o] = a), s.length < 2 ? l[0] ? cx(l[0].x) : lx(t) : (t = l.length, function(c) {
    for (var h = 0, u; h < t; ++h) s[(u = l[h]).i] = u.x(c);
    return s.join("");
  });
}
var Fo = 180 / Math.PI, Pa = {
  translateX: 0,
  translateY: 0,
  rotate: 0,
  skewX: 0,
  scaleX: 1,
  scaleY: 1
};
function ru(e, t, r, i, n, a) {
  var o, s, l;
  return (o = Math.sqrt(e * e + t * t)) && (e /= o, t /= o), (l = e * r + t * i) && (r -= e * l, i -= t * l), (s = Math.sqrt(r * r + i * i)) && (r /= s, i /= s, l /= s), e * i < t * r && (e = -e, t = -t, l = -l, o = -o), {
    translateX: n,
    translateY: a,
    rotate: Math.atan2(t, e) * Fo,
    skewX: Math.atan(l) * Fo,
    scaleX: o,
    scaleY: s
  };
}
var wi;
function ux(e) {
  const t = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(e + "");
  return t.isIdentity ? Pa : ru(t.a, t.b, t.c, t.d, t.e, t.f);
}
function fx(e) {
  return e == null || (wi || (wi = document.createElementNS("http://www.w3.org/2000/svg", "g")), wi.setAttribute("transform", e), !(e = wi.transform.baseVal.consolidate())) ? Pa : (e = e.matrix, ru(e.a, e.b, e.c, e.d, e.e, e.f));
}
function iu(e, t, r, i) {
  function n(c) {
    return c.length ? c.pop() + " " : "";
  }
  function a(c, h, u, f, p, g) {
    if (c !== u || h !== f) {
      var m = p.push("translate(", null, t, null, r);
      g.push({ i: m - 4, x: Ce(c, u) }, { i: m - 2, x: Ce(h, f) });
    } else (u || f) && p.push("translate(" + u + t + f + r);
  }
  function o(c, h, u, f) {
    c !== h ? (c - h > 180 ? h += 360 : h - c > 180 && (c += 360), f.push({ i: u.push(n(u) + "rotate(", null, i) - 2, x: Ce(c, h) })) : h && u.push(n(u) + "rotate(" + h + i);
  }
  function s(c, h, u, f) {
    c !== h ? f.push({ i: u.push(n(u) + "skewX(", null, i) - 2, x: Ce(c, h) }) : h && u.push(n(u) + "skewX(" + h + i);
  }
  function l(c, h, u, f, p, g) {
    if (c !== u || h !== f) {
      var m = p.push(n(p) + "scale(", null, ",", null, ")");
      g.push({ i: m - 4, x: Ce(c, u) }, { i: m - 2, x: Ce(h, f) });
    } else (u !== 1 || f !== 1) && p.push(n(p) + "scale(" + u + "," + f + ")");
  }
  return function(c, h) {
    var u = [], f = [];
    return c = e(c), h = e(h), a(c.translateX, c.translateY, h.translateX, h.translateY, u, f), o(c.rotate, h.rotate, u, f), s(c.skewX, h.skewX, u, f), l(c.scaleX, c.scaleY, h.scaleX, h.scaleY, u, f), c = h = null, function(p) {
      for (var g = -1, m = f.length, y; ++g < m; ) u[(y = f[g]).i] = y.x(p);
      return u.join("");
    };
  };
}
var px = iu(ux, "px, ", "px)", "deg)"), dx = iu(fx, ", ", ")", ")"), _r = 0, zr = 0, $r = 0, nu = 1e3, rn, qr, nn = 0, We = 0, En = 0, ni = typeof performance == "object" && performance.now ? performance : Date, au = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
  setTimeout(e, 17);
};
function As() {
  return We || (au(gx), We = ni.now() + En);
}
function gx() {
  We = 0;
}
function an() {
  this._call = this._time = this._next = null;
}
an.prototype = su.prototype = {
  constructor: an,
  restart: function(e, t, r) {
    if (typeof e != "function") throw new TypeError("callback is not a function");
    r = (r == null ? As() : +r) + (t == null ? 0 : +t), !this._next && qr !== this && (qr ? qr._next = this : rn = this, qr = this), this._call = e, this._time = r, Na();
  },
  stop: function() {
    this._call && (this._call = null, this._time = 1 / 0, Na());
  }
};
function su(e, t, r) {
  var i = new an();
  return i.restart(e, t, r), i;
}
function mx() {
  As(), ++_r;
  for (var e = rn, t; e; )
    (t = We - e._time) >= 0 && e._call.call(void 0, t), e = e._next;
  --_r;
}
function Eo() {
  We = (nn = ni.now()) + En, _r = zr = 0;
  try {
    mx();
  } finally {
    _r = 0, xx(), We = 0;
  }
}
function yx() {
  var e = ni.now(), t = e - nn;
  t > nu && (En -= t, nn = e);
}
function xx() {
  for (var e, t = rn, r, i = 1 / 0; t; )
    t._call ? (i > t._time && (i = t._time), e = t, t = t._next) : (r = t._next, t._next = null, t = e ? e._next = r : rn = r);
  qr = e, Na(i);
}
function Na(e) {
  if (!_r) {
    zr && (zr = clearTimeout(zr));
    var t = e - We;
    t > 24 ? (e < 1 / 0 && (zr = setTimeout(Eo, e - ni.now() - En)), $r && ($r = clearInterval($r))) : ($r || (nn = ni.now(), $r = setInterval(yx, nu)), _r = 1, au(Eo));
  }
}
function Oo(e, t, r) {
  var i = new an();
  return t = t == null ? 0 : +t, i.restart((n) => {
    i.stop(), e(n + t);
  }, t, r), i;
}
var bx = Nh("start", "end", "cancel", "interrupt"), Cx = [], ou = 0, Do = 1, za = 2, Oi = 3, Ro = 4, qa = 5, Di = 6;
function On(e, t, r, i, n, a) {
  var o = e.__transition;
  if (!o) e.__transition = {};
  else if (r in o) return;
  _x(e, r, {
    name: t,
    index: i,
    // For context during callback.
    group: n,
    // For context during callback.
    on: bx,
    tween: Cx,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: ou
  });
}
function $s(e, t) {
  var r = Xt(e, t);
  if (r.state > ou) throw new Error("too late; already scheduled");
  return r;
}
function ie(e, t) {
  var r = Xt(e, t);
  if (r.state > Oi) throw new Error("too late; already running");
  return r;
}
function Xt(e, t) {
  var r = e.__transition;
  if (!r || !(r = r[t])) throw new Error("transition not found");
  return r;
}
function _x(e, t, r) {
  var i = e.__transition, n;
  i[t] = r, r.timer = su(a, 0, r.time);
  function a(c) {
    r.state = Do, r.timer.restart(o, r.delay, r.time), r.delay <= c && o(c - r.delay);
  }
  function o(c) {
    var h, u, f, p;
    if (r.state !== Do) return l();
    for (h in i)
      if (p = i[h], p.name === r.name) {
        if (p.state === Oi) return Oo(o);
        p.state === Ro ? (p.state = Di, p.timer.stop(), p.on.call("interrupt", e, e.__data__, p.index, p.group), delete i[h]) : +h < t && (p.state = Di, p.timer.stop(), p.on.call("cancel", e, e.__data__, p.index, p.group), delete i[h]);
      }
    if (Oo(function() {
      r.state === Oi && (r.state = Ro, r.timer.restart(s, r.delay, r.time), s(c));
    }), r.state = za, r.on.call("start", e, e.__data__, r.index, r.group), r.state === za) {
      for (r.state = Oi, n = new Array(f = r.tween.length), h = 0, u = -1; h < f; ++h)
        (p = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (n[++u] = p);
      n.length = u + 1;
    }
  }
  function s(c) {
    for (var h = c < r.duration ? r.ease.call(null, c / r.duration) : (r.timer.restart(l), r.state = qa, 1), u = -1, f = n.length; ++u < f; )
      n[u].call(e, h);
    r.state === qa && (r.on.call("end", e, e.__data__, r.index, r.group), l());
  }
  function l() {
    r.state = Di, r.timer.stop(), delete i[t];
    for (var c in i) return;
    delete e.__transition;
  }
}
function wx(e, t) {
  var r = e.__transition, i, n, a = !0, o;
  if (r) {
    t = t == null ? null : t + "";
    for (o in r) {
      if ((i = r[o]).name !== t) {
        a = !1;
        continue;
      }
      n = i.state > za && i.state < qa, i.state = Di, i.timer.stop(), i.on.call(n ? "interrupt" : "cancel", e, e.__data__, i.index, i.group), delete r[o];
    }
    a && delete e.__transition;
  }
}
function vx(e) {
  return this.each(function() {
    wx(this, e);
  });
}
function kx(e, t) {
  var r, i;
  return function() {
    var n = ie(this, e), a = n.tween;
    if (a !== r) {
      i = r = a;
      for (var o = 0, s = i.length; o < s; ++o)
        if (i[o].name === t) {
          i = i.slice(), i.splice(o, 1);
          break;
        }
    }
    n.tween = i;
  };
}
function Sx(e, t, r) {
  var i, n;
  if (typeof r != "function") throw new Error();
  return function() {
    var a = ie(this, e), o = a.tween;
    if (o !== i) {
      n = (i = o).slice();
      for (var s = { name: t, value: r }, l = 0, c = n.length; l < c; ++l)
        if (n[l].name === t) {
          n[l] = s;
          break;
        }
      l === c && n.push(s);
    }
    a.tween = n;
  };
}
function Tx(e, t) {
  var r = this._id;
  if (e += "", arguments.length < 2) {
    for (var i = Xt(this.node(), r).tween, n = 0, a = i.length, o; n < a; ++n)
      if ((o = i[n]).name === e)
        return o.value;
    return null;
  }
  return this.each((t == null ? kx : Sx)(r, e, t));
}
function Fs(e, t, r) {
  var i = e._id;
  return e.each(function() {
    var n = ie(this, i);
    (n.value || (n.value = {}))[t] = r.apply(this, arguments);
  }), function(n) {
    return Xt(n, i).value[t];
  };
}
function lu(e, t) {
  var r;
  return (typeof t == "number" ? Ce : t instanceof ii ? $o : (r = ii(t)) ? (t = r, $o) : hx)(e, t);
}
function Bx(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function Lx(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function Mx(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttribute(e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function Ax(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttributeNS(e.space, e.local);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function $x(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttribute(e) : (o = this.getAttribute(e), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function Fx(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttributeNS(e.space, e.local) : (o = this.getAttributeNS(e.space, e.local), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function Ex(e, t) {
  var r = Fn(e), i = r === "transform" ? dx : lu;
  return this.attrTween(e, typeof t == "function" ? (r.local ? Fx : $x)(r, i, Fs(this, "attr." + e, t)) : t == null ? (r.local ? Lx : Bx)(r) : (r.local ? Ax : Mx)(r, i, t));
}
function Ox(e, t) {
  return function(r) {
    this.setAttribute(e, t.call(this, r));
  };
}
function Dx(e, t) {
  return function(r) {
    this.setAttributeNS(e.space, e.local, t.call(this, r));
  };
}
function Rx(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Dx(e, a)), r;
  }
  return n._value = t, n;
}
function Ix(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Ox(e, a)), r;
  }
  return n._value = t, n;
}
function Px(e, t) {
  var r = "attr." + e;
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != "function") throw new Error();
  var i = Fn(e);
  return this.tween(r, (i.local ? Rx : Ix)(i, t));
}
function Nx(e, t) {
  return function() {
    $s(this, e).delay = +t.apply(this, arguments);
  };
}
function zx(e, t) {
  return t = +t, function() {
    $s(this, e).delay = t;
  };
}
function qx(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Nx : zx)(t, e)) : Xt(this.node(), t).delay;
}
function Wx(e, t) {
  return function() {
    ie(this, e).duration = +t.apply(this, arguments);
  };
}
function Hx(e, t) {
  return t = +t, function() {
    ie(this, e).duration = t;
  };
}
function jx(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Wx : Hx)(t, e)) : Xt(this.node(), t).duration;
}
function Yx(e, t) {
  if (typeof t != "function") throw new Error();
  return function() {
    ie(this, e).ease = t;
  };
}
function Gx(e) {
  var t = this._id;
  return arguments.length ? this.each(Yx(t, e)) : Xt(this.node(), t).ease;
}
function Ux(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    if (typeof r != "function") throw new Error();
    ie(this, e).ease = r;
  };
}
function Xx(e) {
  if (typeof e != "function") throw new Error();
  return this.each(Ux(this._id, e));
}
function Vx(e) {
  typeof e != "function" && (e = Wh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new pe(i, this._parents, this._name, this._id);
}
function Zx(e) {
  if (e._id !== this._id) throw new Error();
  for (var t = this._groups, r = e._groups, i = t.length, n = r.length, a = Math.min(i, n), o = new Array(i), s = 0; s < a; ++s)
    for (var l = t[s], c = r[s], h = l.length, u = o[s] = new Array(h), f, p = 0; p < h; ++p)
      (f = l[p] || c[p]) && (u[p] = f);
  for (; s < i; ++s)
    o[s] = t[s];
  return new pe(o, this._parents, this._name, this._id);
}
function Kx(e) {
  return (e + "").trim().split(/^|\s+/).every(function(t) {
    var r = t.indexOf(".");
    return r >= 0 && (t = t.slice(0, r)), !t || t === "start";
  });
}
function Qx(e, t, r) {
  var i, n, a = Kx(t) ? $s : ie;
  return function() {
    var o = a(this, e), s = o.on;
    s !== i && (n = (i = s).copy()).on(t, r), o.on = n;
  };
}
function Jx(e, t) {
  var r = this._id;
  return arguments.length < 2 ? Xt(this.node(), r).on.on(e) : this.each(Qx(r, e, t));
}
function tb(e) {
  return function() {
    var t = this.parentNode;
    for (var r in this.__transition) if (+r !== e) return;
    t && t.removeChild(this);
  };
}
function eb() {
  return this.on("end.remove", tb(this._id));
}
function rb(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Ts(e));
  for (var i = this._groups, n = i.length, a = new Array(n), o = 0; o < n; ++o)
    for (var s = i[o], l = s.length, c = a[o] = new Array(l), h, u, f = 0; f < l; ++f)
      (h = s[f]) && (u = e.call(h, h.__data__, f, s)) && ("__data__" in h && (u.__data__ = h.__data__), c[f] = u, On(c[f], t, r, f, c, Xt(h, r)));
  return new pe(a, this._parents, t, r);
}
function ib(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = qh(e));
  for (var i = this._groups, n = i.length, a = [], o = [], s = 0; s < n; ++s)
    for (var l = i[s], c = l.length, h, u = 0; u < c; ++u)
      if (h = l[u]) {
        for (var f = e.call(h, h.__data__, u, l), p, g = Xt(h, r), m = 0, y = f.length; m < y; ++m)
          (p = f[m]) && On(p, t, r, m, f, g);
        a.push(f), o.push(h);
      }
  return new pe(a, o, t, r);
}
var nb = fi.prototype.constructor;
function ab() {
  return new nb(this._groups, this._parents);
}
function sb(e, t) {
  var r, i, n;
  return function() {
    var a = Cr(this, e), o = (this.style.removeProperty(e), Cr(this, e));
    return a === o ? null : a === r && o === i ? n : n = t(r = a, i = o);
  };
}
function cu(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function ob(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = Cr(this, e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function lb(e, t, r) {
  var i, n, a;
  return function() {
    var o = Cr(this, e), s = r(this), l = s + "";
    return s == null && (l = s = (this.style.removeProperty(e), Cr(this, e))), o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s));
  };
}
function cb(e, t) {
  var r, i, n, a = "style." + t, o = "end." + a, s;
  return function() {
    var l = ie(this, e), c = l.on, h = l.value[a] == null ? s || (s = cu(t)) : void 0;
    (c !== r || n !== h) && (i = (r = c).copy()).on(o, n = h), l.on = i;
  };
}
function hb(e, t, r) {
  var i = (e += "") == "transform" ? px : lu;
  return t == null ? this.styleTween(e, sb(e, i)).on("end.style." + e, cu(e)) : typeof t == "function" ? this.styleTween(e, lb(e, i, Fs(this, "style." + e, t))).each(cb(this._id, e)) : this.styleTween(e, ob(e, i, t), r).on("end.style." + e, null);
}
function ub(e, t, r) {
  return function(i) {
    this.style.setProperty(e, t.call(this, i), r);
  };
}
function fb(e, t, r) {
  var i, n;
  function a() {
    var o = t.apply(this, arguments);
    return o !== n && (i = (n = o) && ub(e, o, r)), i;
  }
  return a._value = t, a;
}
function pb(e, t, r) {
  var i = "style." + (e += "");
  if (arguments.length < 2) return (i = this.tween(i)) && i._value;
  if (t == null) return this.tween(i, null);
  if (typeof t != "function") throw new Error();
  return this.tween(i, fb(e, t, r ?? ""));
}
function db(e) {
  return function() {
    this.textContent = e;
  };
}
function gb(e) {
  return function() {
    var t = e(this);
    this.textContent = t ?? "";
  };
}
function mb(e) {
  return this.tween("text", typeof e == "function" ? gb(Fs(this, "text", e)) : db(e == null ? "" : e + ""));
}
function yb(e) {
  return function(t) {
    this.textContent = e.call(this, t);
  };
}
function xb(e) {
  var t, r;
  function i() {
    var n = e.apply(this, arguments);
    return n !== r && (t = (r = n) && yb(n)), t;
  }
  return i._value = e, i;
}
function bb(e) {
  var t = "text";
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != "function") throw new Error();
  return this.tween(t, xb(e));
}
function Cb() {
  for (var e = this._name, t = this._id, r = hu(), i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      if (l = o[c]) {
        var h = Xt(l, t);
        On(l, e, r, c, o, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease
        });
      }
  return new pe(i, this._parents, e, r);
}
function _b() {
  var e, t, r = this, i = r._id, n = r.size();
  return new Promise(function(a, o) {
    var s = { value: o }, l = { value: function() {
      --n === 0 && a();
    } };
    r.each(function() {
      var c = ie(this, i), h = c.on;
      h !== e && (t = (e = h).copy(), t._.cancel.push(s), t._.interrupt.push(s), t._.end.push(l)), c.on = t;
    }), n === 0 && a();
  });
}
var wb = 0;
function pe(e, t, r, i) {
  this._groups = e, this._parents = t, this._name = r, this._id = i;
}
function hu() {
  return ++wb;
}
var se = fi.prototype;
pe.prototype = {
  constructor: pe,
  select: rb,
  selectAll: ib,
  selectChild: se.selectChild,
  selectChildren: se.selectChildren,
  filter: Vx,
  merge: Zx,
  selection: ab,
  transition: Cb,
  call: se.call,
  nodes: se.nodes,
  node: se.node,
  size: se.size,
  empty: se.empty,
  each: se.each,
  on: Jx,
  attr: Ex,
  attrTween: Px,
  style: hb,
  styleTween: pb,
  text: mb,
  textTween: bb,
  remove: eb,
  tween: Tx,
  delay: qx,
  duration: jx,
  ease: Gx,
  easeVarying: Xx,
  end: _b,
  [Symbol.iterator]: se[Symbol.iterator]
};
function vb(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var kb = {
  time: null,
  // Set on use.
  delay: 0,
  duration: 250,
  ease: vb
};
function Sb(e, t) {
  for (var r; !(r = e.__transition) || !(r = r[t]); )
    if (!(e = e.parentNode))
      throw new Error(`transition ${t} not found`);
  return r;
}
function Tb(e) {
  var t, r;
  e instanceof pe ? (t = e._id, e = e._name) : (t = hu(), (r = kb).time = As(), e = e == null ? null : e + "");
  for (var i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && On(l, e, t, c, o, r || Sb(l, t));
  return new pe(i, this._parents, e, t);
}
fi.prototype.interrupt = vx;
fi.prototype.transition = Tb;
const Wa = Math.PI, Ha = 2 * Wa, Ae = 1e-6, Bb = Ha - Ae;
function uu(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function Lb(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return uu;
  const r = 10 ** t;
  return function(i) {
    this._ += i[0];
    for (let n = 1, a = i.length; n < a; ++n)
      this._ += Math.round(arguments[n] * r) / r + i[n];
  };
}
class Mb {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? uu : Lb(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, i, n) {
    this._append`Q${+t},${+r},${this._x1 = +i},${this._y1 = +n}`;
  }
  bezierCurveTo(t, r, i, n, a, o) {
    this._append`C${+t},${+r},${+i},${+n},${this._x1 = +a},${this._y1 = +o}`;
  }
  arcTo(t, r, i, n, a) {
    if (t = +t, r = +r, i = +i, n = +n, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let o = this._x1, s = this._y1, l = i - t, c = n - r, h = o - t, u = s - r, f = h * h + u * u;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (f > Ae) if (!(Math.abs(u * l - c * h) > Ae) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let p = i - o, g = n - s, m = l * l + c * c, y = p * p + g * g, x = Math.sqrt(m), b = Math.sqrt(f), _ = a * Math.tan((Wa - Math.acos((m + f - y) / (2 * x * b))) / 2), S = _ / b, w = _ / x;
      Math.abs(S - 1) > Ae && this._append`L${t + S * h},${r + S * u}`, this._append`A${a},${a},0,0,${+(u * p > h * g)},${this._x1 = t + w * l},${this._y1 = r + w * c}`;
    }
  }
  arc(t, r, i, n, a, o) {
    if (t = +t, r = +r, i = +i, o = !!o, i < 0) throw new Error(`negative radius: ${i}`);
    let s = i * Math.cos(n), l = i * Math.sin(n), c = t + s, h = r + l, u = 1 ^ o, f = o ? n - a : a - n;
    this._x1 === null ? this._append`M${c},${h}` : (Math.abs(this._x1 - c) > Ae || Math.abs(this._y1 - h) > Ae) && this._append`L${c},${h}`, i && (f < 0 && (f = f % Ha + Ha), f > Bb ? this._append`A${i},${i},0,1,${u},${t - s},${r - l}A${i},${i},0,1,${u},${this._x1 = c},${this._y1 = h}` : f > Ae && this._append`A${i},${i},0,${+(f >= Wa)},${u},${this._x1 = t + i * Math.cos(a)},${this._y1 = r + i * Math.sin(a)}`);
  }
  rect(t, r, i, n) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${i = +i}v${+n}h${-i}Z`;
  }
  toString() {
    return this._;
  }
}
function Ke(e) {
  return function() {
    return e;
  };
}
const wT = Math.abs, vT = Math.atan2, kT = Math.cos, ST = Math.max, TT = Math.min, BT = Math.sin, LT = Math.sqrt, Io = 1e-12, Es = Math.PI, Po = Es / 2, MT = 2 * Es;
function AT(e) {
  return e > 1 ? 0 : e < -1 ? Es : Math.acos(e);
}
function $T(e) {
  return e >= 1 ? Po : e <= -1 ? -Po : Math.asin(e);
}
function Ab(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const i = Math.floor(r);
      if (!(i >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = i;
    }
    return e;
  }, () => new Mb(t);
}
function $b(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function fu(e) {
  this._context = e;
}
fu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function sn(e) {
  return new fu(e);
}
function Fb(e) {
  return e[0];
}
function Eb(e) {
  return e[1];
}
function Ob(e, t) {
  var r = Ke(!0), i = null, n = sn, a = null, o = Ab(s);
  e = typeof e == "function" ? e : e === void 0 ? Fb : Ke(e), t = typeof t == "function" ? t : t === void 0 ? Eb : Ke(t);
  function s(l) {
    var c, h = (l = $b(l)).length, u, f = !1, p;
    for (i == null && (a = n(p = o())), c = 0; c <= h; ++c)
      !(c < h && r(u = l[c], c, l)) === f && ((f = !f) ? a.lineStart() : a.lineEnd()), f && a.point(+e(u, c, l), +t(u, c, l));
    if (p) return a = null, p + "" || null;
  }
  return s.x = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : Ke(+l), s) : e;
  }, s.y = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : Ke(+l), s) : t;
  }, s.defined = function(l) {
    return arguments.length ? (r = typeof l == "function" ? l : Ke(!!l), s) : r;
  }, s.curve = function(l) {
    return arguments.length ? (n = l, i != null && (a = n(i)), s) : n;
  }, s.context = function(l) {
    return arguments.length ? (l == null ? i = a = null : a = n(i = l), s) : i;
  }, s;
}
class pu {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function du(e) {
  return new pu(e, !0);
}
function gu(e) {
  return new pu(e, !1);
}
function ke() {
}
function on(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function Dn(e) {
  this._context = e;
}
Dn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        on(this, this._x1, this._y1);
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      default:
        on(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Ri(e) {
  return new Dn(e);
}
function mu(e) {
  this._context = e;
}
mu.prototype = {
  areaStart: ke,
  areaEnd: ke,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        on(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Db(e) {
  return new mu(e);
}
function yu(e) {
  this._context = e;
}
yu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, i = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, i) : this._context.moveTo(r, i);
        break;
      case 3:
        this._point = 4;
      default:
        on(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Rb(e) {
  return new yu(e);
}
function xu(e, t) {
  this._basis = new Dn(e), this._beta = t;
}
xu.prototype = {
  lineStart: function() {
    this._x = [], this._y = [], this._basis.lineStart();
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length - 1;
    if (r > 0)
      for (var i = e[0], n = t[0], a = e[r] - i, o = t[r] - n, s = -1, l; ++s <= r; )
        l = s / r, this._basis.point(
          this._beta * e[s] + (1 - this._beta) * (i + l * a),
          this._beta * t[s] + (1 - this._beta) * (n + l * o)
        );
    this._x = this._y = null, this._basis.lineEnd();
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
const Ib = function e(t) {
  function r(i) {
    return t === 1 ? new Dn(i) : new xu(i, t);
  }
  return r.beta = function(i) {
    return e(+i);
  }, r;
}(0.85);
function ln(e, t, r) {
  e._context.bezierCurveTo(
    e._x1 + e._k * (e._x2 - e._x0),
    e._y1 + e._k * (e._y2 - e._y0),
    e._x2 + e._k * (e._x1 - t),
    e._y2 + e._k * (e._y1 - r),
    e._x2,
    e._y2
  );
}
function Os(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Os.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        ln(this, this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2, this._x1 = e, this._y1 = t;
        break;
      case 2:
        this._point = 3;
      default:
        ln(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const bu = function e(t) {
  function r(i) {
    return new Os(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Ds(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Ds.prototype = {
  areaStart: ke,
  areaEnd: ke,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        ln(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Pb = function e(t) {
  function r(i) {
    return new Ds(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Rs(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Rs.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        ln(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Nb = function e(t) {
  function r(i) {
    return new Rs(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Is(e, t, r) {
  var i = e._x1, n = e._y1, a = e._x2, o = e._y2;
  if (e._l01_a > Io) {
    var s = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a, l = 3 * e._l01_a * (e._l01_a + e._l12_a);
    i = (i * s - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / l, n = (n * s - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / l;
  }
  if (e._l23_a > Io) {
    var c = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a, h = 3 * e._l23_a * (e._l23_a + e._l12_a);
    a = (a * c + e._x1 * e._l23_2a - t * e._l12_2a) / h, o = (o * c + e._y1 * e._l23_2a - r * e._l12_2a) / h;
  }
  e._context.bezierCurveTo(i, n, a, o, e._x2, e._y2);
}
function Cu(e, t) {
  this._context = e, this._alpha = t;
}
Cu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        this.point(this._x2, this._y2);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
      default:
        Is(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const _u = function e(t) {
  function r(i) {
    return t ? new Cu(i, t) : new Os(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function wu(e, t) {
  this._context = e, this._alpha = t;
}
wu.prototype = {
  areaStart: ke,
  areaEnd: ke,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        Is(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const zb = function e(t) {
  function r(i) {
    return t ? new wu(i, t) : new Ds(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function vu(e, t) {
  this._context = e, this._alpha = t;
}
vu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        Is(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const qb = function e(t) {
  function r(i) {
    return t ? new vu(i, t) : new Rs(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function ku(e) {
  this._context = e;
}
ku.prototype = {
  areaStart: ke,
  areaEnd: ke,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function Wb(e) {
  return new ku(e);
}
function No(e) {
  return e < 0 ? -1 : 1;
}
function zo(e, t, r) {
  var i = e._x1 - e._x0, n = t - e._x1, a = (e._y1 - e._y0) / (i || n < 0 && -0), o = (r - e._y1) / (n || i < 0 && -0), s = (a * n + o * i) / (i + n);
  return (No(a) + No(o)) * Math.min(Math.abs(a), Math.abs(o), 0.5 * Math.abs(s)) || 0;
}
function qo(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function ra(e, t, r) {
  var i = e._x0, n = e._y0, a = e._x1, o = e._y1, s = (a - i) / 3;
  e._context.bezierCurveTo(i + s, n + s * t, a - s, o - s * r, a, o);
}
function cn(e) {
  this._context = e;
}
cn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        ra(this, this._t0, qo(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, ra(this, qo(this, r = zo(this, e, t)), r);
          break;
        default:
          ra(this, this._t0, r = zo(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Su(e) {
  this._context = new Tu(e);
}
(Su.prototype = Object.create(cn.prototype)).point = function(e, t) {
  cn.prototype.point.call(this, t, e);
};
function Tu(e) {
  this._context = e;
}
Tu.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, i, n, a) {
    this._context.bezierCurveTo(t, e, i, r, a, n);
  }
};
function Bu(e) {
  return new cn(e);
}
function Lu(e) {
  return new Su(e);
}
function Mu(e) {
  this._context = e;
}
Mu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var i = Wo(e), n = Wo(t), a = 0, o = 1; o < r; ++a, ++o)
          this._context.bezierCurveTo(i[0][a], n[0][a], i[1][a], n[1][a], e[o], t[o]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function Wo(e) {
  var t, r = e.length - 1, i, n = new Array(r), a = new Array(r), o = new Array(r);
  for (n[0] = 0, a[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) n[t] = 1, a[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
  for (n[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) i = n[t] / a[t - 1], a[t] -= i, o[t] -= i * o[t - 1];
  for (n[r - 1] = o[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) n[t] = (o[t] - n[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + n[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - n[t + 1];
  return [n, a];
}
function Au(e) {
  return new Mu(e);
}
function Rn(e, t) {
  this._context = e, this._t = t;
}
Rn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function $u(e) {
  return new Rn(e, 0.5);
}
function Fu(e) {
  return new Rn(e, 0);
}
function Eu(e) {
  return new Rn(e, 1);
}
function Wr(e, t, r) {
  this.k = e, this.x = t, this.y = r;
}
Wr.prototype = {
  constructor: Wr,
  scale: function(e) {
    return e === 1 ? this : new Wr(this.k * e, this.x, this.y);
  },
  translate: function(e, t) {
    return e === 0 & t === 0 ? this : new Wr(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function(e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function(e) {
    return e * this.k + this.x;
  },
  applyY: function(e) {
    return e * this.k + this.y;
  },
  invert: function(e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function(e) {
    return (e - this.x) / this.k;
  },
  invertY: function(e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function(e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function(e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function() {
    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
  }
};
Wr.prototype;
var Ou = typeof global == "object" && global && global.Object === Object && global, Hb = typeof self == "object" && self && self.Object === Object && self, ne = Ou || Hb || Function("return this")(), hn = ne.Symbol, Du = Object.prototype, jb = Du.hasOwnProperty, Yb = Du.toString, Fr = hn ? hn.toStringTag : void 0;
function Gb(e) {
  var t = jb.call(e, Fr), r = e[Fr];
  try {
    e[Fr] = void 0;
    var i = !0;
  } catch {
  }
  var n = Yb.call(e);
  return i && (t ? e[Fr] = r : delete e[Fr]), n;
}
var Ub = Object.prototype, Xb = Ub.toString;
function Vb(e) {
  return Xb.call(e);
}
var Zb = "[object Null]", Kb = "[object Undefined]", Ho = hn ? hn.toStringTag : void 0;
function Sr(e) {
  return e == null ? e === void 0 ? Kb : Zb : Ho && Ho in Object(e) ? Gb(e) : Vb(e);
}
function Ge(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var Qb = "[object AsyncFunction]", Jb = "[object Function]", t1 = "[object GeneratorFunction]", e1 = "[object Proxy]";
function Ps(e) {
  if (!Ge(e))
    return !1;
  var t = Sr(e);
  return t == Jb || t == t1 || t == Qb || t == e1;
}
var ia = ne["__core-js_shared__"], jo = function() {
  var e = /[^.]+$/.exec(ia && ia.keys && ia.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
}();
function r1(e) {
  return !!jo && jo in e;
}
var i1 = Function.prototype, n1 = i1.toString;
function Ue(e) {
  if (e != null) {
    try {
      return n1.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var a1 = /[\\^$.*+?()[\]{}|]/g, s1 = /^\[object .+?Constructor\]$/, o1 = Function.prototype, l1 = Object.prototype, c1 = o1.toString, h1 = l1.hasOwnProperty, u1 = RegExp(
  "^" + c1.call(h1).replace(a1, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function f1(e) {
  if (!Ge(e) || r1(e))
    return !1;
  var t = Ps(e) ? u1 : s1;
  return t.test(Ue(e));
}
function p1(e, t) {
  return e == null ? void 0 : e[t];
}
function Xe(e, t) {
  var r = p1(e, t);
  return f1(r) ? r : void 0;
}
var ai = Xe(Object, "create");
function d1() {
  this.__data__ = ai ? ai(null) : {}, this.size = 0;
}
function g1(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var m1 = "__lodash_hash_undefined__", y1 = Object.prototype, x1 = y1.hasOwnProperty;
function b1(e) {
  var t = this.__data__;
  if (ai) {
    var r = t[e];
    return r === m1 ? void 0 : r;
  }
  return x1.call(t, e) ? t[e] : void 0;
}
var C1 = Object.prototype, _1 = C1.hasOwnProperty;
function w1(e) {
  var t = this.__data__;
  return ai ? t[e] !== void 0 : _1.call(t, e);
}
var v1 = "__lodash_hash_undefined__";
function k1(e, t) {
  var r = this.__data__;
  return this.size += this.has(e) ? 0 : 1, r[e] = ai && t === void 0 ? v1 : t, this;
}
function He(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
He.prototype.clear = d1;
He.prototype.delete = g1;
He.prototype.get = b1;
He.prototype.has = w1;
He.prototype.set = k1;
function S1() {
  this.__data__ = [], this.size = 0;
}
function In(e, t) {
  return e === t || e !== e && t !== t;
}
function Pn(e, t) {
  for (var r = e.length; r--; )
    if (In(e[r][0], t))
      return r;
  return -1;
}
var T1 = Array.prototype, B1 = T1.splice;
function L1(e) {
  var t = this.__data__, r = Pn(t, e);
  if (r < 0)
    return !1;
  var i = t.length - 1;
  return r == i ? t.pop() : B1.call(t, r, 1), --this.size, !0;
}
function M1(e) {
  var t = this.__data__, r = Pn(t, e);
  return r < 0 ? void 0 : t[r][1];
}
function A1(e) {
  return Pn(this.__data__, e) > -1;
}
function $1(e, t) {
  var r = this.__data__, i = Pn(r, e);
  return i < 0 ? (++this.size, r.push([e, t])) : r[i][1] = t, this;
}
function ge(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
ge.prototype.clear = S1;
ge.prototype.delete = L1;
ge.prototype.get = M1;
ge.prototype.has = A1;
ge.prototype.set = $1;
var si = Xe(ne, "Map");
function F1() {
  this.size = 0, this.__data__ = {
    hash: new He(),
    map: new (si || ge)(),
    string: new He()
  };
}
function E1(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function Nn(e, t) {
  var r = e.__data__;
  return E1(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map;
}
function O1(e) {
  var t = Nn(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function D1(e) {
  return Nn(this, e).get(e);
}
function R1(e) {
  return Nn(this, e).has(e);
}
function I1(e, t) {
  var r = Nn(this, e), i = r.size;
  return r.set(e, t), this.size += r.size == i ? 0 : 1, this;
}
function Be(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Be.prototype.clear = F1;
Be.prototype.delete = O1;
Be.prototype.get = D1;
Be.prototype.has = R1;
Be.prototype.set = I1;
var P1 = "Expected a function";
function di(e, t) {
  if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(P1);
  var r = function() {
    var i = arguments, n = t ? t.apply(this, i) : i[0], a = r.cache;
    if (a.has(n))
      return a.get(n);
    var o = e.apply(this, i);
    return r.cache = a.set(n, o) || a, o;
  };
  return r.cache = new (di.Cache || Be)(), r;
}
di.Cache = Be;
function N1() {
  this.__data__ = new ge(), this.size = 0;
}
function z1(e) {
  var t = this.__data__, r = t.delete(e);
  return this.size = t.size, r;
}
function q1(e) {
  return this.__data__.get(e);
}
function W1(e) {
  return this.__data__.has(e);
}
var H1 = 200;
function j1(e, t) {
  var r = this.__data__;
  if (r instanceof ge) {
    var i = r.__data__;
    if (!si || i.length < H1 - 1)
      return i.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new Be(i);
  }
  return r.set(e, t), this.size = r.size, this;
}
function Tr(e) {
  var t = this.__data__ = new ge(e);
  this.size = t.size;
}
Tr.prototype.clear = N1;
Tr.prototype.delete = z1;
Tr.prototype.get = q1;
Tr.prototype.has = W1;
Tr.prototype.set = j1;
var un = function() {
  try {
    var e = Xe(Object, "defineProperty");
    return e({}, "", {}), e;
  } catch {
  }
}();
function Ns(e, t, r) {
  t == "__proto__" && un ? un(e, t, {
    configurable: !0,
    enumerable: !0,
    value: r,
    writable: !0
  }) : e[t] = r;
}
function ja(e, t, r) {
  (r !== void 0 && !In(e[t], r) || r === void 0 && !(t in e)) && Ns(e, t, r);
}
function Y1(e) {
  return function(t, r, i) {
    for (var n = -1, a = Object(t), o = i(t), s = o.length; s--; ) {
      var l = o[++n];
      if (r(a[l], l, a) === !1)
        break;
    }
    return t;
  };
}
var G1 = Y1(), Ru = typeof exports == "object" && exports && !exports.nodeType && exports, Yo = Ru && typeof module == "object" && module && !module.nodeType && module, U1 = Yo && Yo.exports === Ru, Go = U1 ? ne.Buffer : void 0, Uo = Go ? Go.allocUnsafe : void 0;
function X1(e, t) {
  if (t)
    return e.slice();
  var r = e.length, i = Uo ? Uo(r) : new e.constructor(r);
  return e.copy(i), i;
}
var Xo = ne.Uint8Array;
function V1(e) {
  var t = new e.constructor(e.byteLength);
  return new Xo(t).set(new Xo(e)), t;
}
function Z1(e, t) {
  var r = t ? V1(e.buffer) : e.buffer;
  return new e.constructor(r, e.byteOffset, e.length);
}
function K1(e, t) {
  var r = -1, i = e.length;
  for (t || (t = Array(i)); ++r < i; )
    t[r] = e[r];
  return t;
}
var Vo = Object.create, Q1 = /* @__PURE__ */ function() {
  function e() {
  }
  return function(t) {
    if (!Ge(t))
      return {};
    if (Vo)
      return Vo(t);
    e.prototype = t;
    var r = new e();
    return e.prototype = void 0, r;
  };
}();
function Iu(e, t) {
  return function(r) {
    return e(t(r));
  };
}
var Pu = Iu(Object.getPrototypeOf, Object), J1 = Object.prototype;
function zn(e) {
  var t = e && e.constructor, r = typeof t == "function" && t.prototype || J1;
  return e === r;
}
function t2(e) {
  return typeof e.constructor == "function" && !zn(e) ? Q1(Pu(e)) : {};
}
function gi(e) {
  return e != null && typeof e == "object";
}
var e2 = "[object Arguments]";
function Zo(e) {
  return gi(e) && Sr(e) == e2;
}
var Nu = Object.prototype, r2 = Nu.hasOwnProperty, i2 = Nu.propertyIsEnumerable, fn = Zo(/* @__PURE__ */ function() {
  return arguments;
}()) ? Zo : function(e) {
  return gi(e) && r2.call(e, "callee") && !i2.call(e, "callee");
}, pn = Array.isArray, n2 = 9007199254740991;
function zu(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= n2;
}
function qn(e) {
  return e != null && zu(e.length) && !Ps(e);
}
function a2(e) {
  return gi(e) && qn(e);
}
function s2() {
  return !1;
}
var qu = typeof exports == "object" && exports && !exports.nodeType && exports, Ko = qu && typeof module == "object" && module && !module.nodeType && module, o2 = Ko && Ko.exports === qu, Qo = o2 ? ne.Buffer : void 0, l2 = Qo ? Qo.isBuffer : void 0, zs = l2 || s2, c2 = "[object Object]", h2 = Function.prototype, u2 = Object.prototype, Wu = h2.toString, f2 = u2.hasOwnProperty, p2 = Wu.call(Object);
function d2(e) {
  if (!gi(e) || Sr(e) != c2)
    return !1;
  var t = Pu(e);
  if (t === null)
    return !0;
  var r = f2.call(t, "constructor") && t.constructor;
  return typeof r == "function" && r instanceof r && Wu.call(r) == p2;
}
var g2 = "[object Arguments]", m2 = "[object Array]", y2 = "[object Boolean]", x2 = "[object Date]", b2 = "[object Error]", C2 = "[object Function]", _2 = "[object Map]", w2 = "[object Number]", v2 = "[object Object]", k2 = "[object RegExp]", S2 = "[object Set]", T2 = "[object String]", B2 = "[object WeakMap]", L2 = "[object ArrayBuffer]", M2 = "[object DataView]", A2 = "[object Float32Array]", $2 = "[object Float64Array]", F2 = "[object Int8Array]", E2 = "[object Int16Array]", O2 = "[object Int32Array]", D2 = "[object Uint8Array]", R2 = "[object Uint8ClampedArray]", I2 = "[object Uint16Array]", P2 = "[object Uint32Array]", ct = {};
ct[A2] = ct[$2] = ct[F2] = ct[E2] = ct[O2] = ct[D2] = ct[R2] = ct[I2] = ct[P2] = !0;
ct[g2] = ct[m2] = ct[L2] = ct[y2] = ct[M2] = ct[x2] = ct[b2] = ct[C2] = ct[_2] = ct[w2] = ct[v2] = ct[k2] = ct[S2] = ct[T2] = ct[B2] = !1;
function N2(e) {
  return gi(e) && zu(e.length) && !!ct[Sr(e)];
}
function z2(e) {
  return function(t) {
    return e(t);
  };
}
var Hu = typeof exports == "object" && exports && !exports.nodeType && exports, Vr = Hu && typeof module == "object" && module && !module.nodeType && module, q2 = Vr && Vr.exports === Hu, na = q2 && Ou.process, Jo = function() {
  try {
    var e = Vr && Vr.require && Vr.require("util").types;
    return e || na && na.binding && na.binding("util");
  } catch {
  }
}(), tl = Jo && Jo.isTypedArray, qs = tl ? z2(tl) : N2;
function Ya(e, t) {
  if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__")
    return e[t];
}
var W2 = Object.prototype, H2 = W2.hasOwnProperty;
function j2(e, t, r) {
  var i = e[t];
  (!(H2.call(e, t) && In(i, r)) || r === void 0 && !(t in e)) && Ns(e, t, r);
}
function Y2(e, t, r, i) {
  var n = !r;
  r || (r = {});
  for (var a = -1, o = t.length; ++a < o; ) {
    var s = t[a], l = void 0;
    l === void 0 && (l = e[s]), n ? Ns(r, s, l) : j2(r, s, l);
  }
  return r;
}
function G2(e, t) {
  for (var r = -1, i = Array(e); ++r < e; )
    i[r] = t(r);
  return i;
}
var U2 = 9007199254740991, X2 = /^(?:0|[1-9]\d*)$/;
function ju(e, t) {
  var r = typeof e;
  return t = t ?? U2, !!t && (r == "number" || r != "symbol" && X2.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var V2 = Object.prototype, Z2 = V2.hasOwnProperty;
function K2(e, t) {
  var r = pn(e), i = !r && fn(e), n = !r && !i && zs(e), a = !r && !i && !n && qs(e), o = r || i || n || a, s = o ? G2(e.length, String) : [], l = s.length;
  for (var c in e)
    (t || Z2.call(e, c)) && !(o && // Safari 9 has enumerable `arguments.length` in strict mode.
    (c == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    n && (c == "offset" || c == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    a && (c == "buffer" || c == "byteLength" || c == "byteOffset") || // Skip index properties.
    ju(c, l))) && s.push(c);
  return s;
}
function Q2(e) {
  var t = [];
  if (e != null)
    for (var r in Object(e))
      t.push(r);
  return t;
}
var J2 = Object.prototype, tC = J2.hasOwnProperty;
function eC(e) {
  if (!Ge(e))
    return Q2(e);
  var t = zn(e), r = [];
  for (var i in e)
    i == "constructor" && (t || !tC.call(e, i)) || r.push(i);
  return r;
}
function Yu(e) {
  return qn(e) ? K2(e, !0) : eC(e);
}
function rC(e) {
  return Y2(e, Yu(e));
}
function iC(e, t, r, i, n, a, o) {
  var s = Ya(e, r), l = Ya(t, r), c = o.get(l);
  if (c) {
    ja(e, r, c);
    return;
  }
  var h = a ? a(s, l, r + "", e, t, o) : void 0, u = h === void 0;
  if (u) {
    var f = pn(l), p = !f && zs(l), g = !f && !p && qs(l);
    h = l, f || p || g ? pn(s) ? h = s : a2(s) ? h = K1(s) : p ? (u = !1, h = X1(l, !0)) : g ? (u = !1, h = Z1(l, !0)) : h = [] : d2(l) || fn(l) ? (h = s, fn(s) ? h = rC(s) : (!Ge(s) || Ps(s)) && (h = t2(l))) : u = !1;
  }
  u && (o.set(l, h), n(h, l, i, a, o), o.delete(l)), ja(e, r, h);
}
function Gu(e, t, r, i, n) {
  e !== t && G1(t, function(a, o) {
    if (n || (n = new Tr()), Ge(a))
      iC(e, t, o, r, Gu, i, n);
    else {
      var s = i ? i(Ya(e, o), a, o + "", e, t, n) : void 0;
      s === void 0 && (s = a), ja(e, o, s);
    }
  }, Yu);
}
function Uu(e) {
  return e;
}
function nC(e, t, r) {
  switch (r.length) {
    case 0:
      return e.call(t);
    case 1:
      return e.call(t, r[0]);
    case 2:
      return e.call(t, r[0], r[1]);
    case 3:
      return e.call(t, r[0], r[1], r[2]);
  }
  return e.apply(t, r);
}
var el = Math.max;
function aC(e, t, r) {
  return t = el(t === void 0 ? e.length - 1 : t, 0), function() {
    for (var i = arguments, n = -1, a = el(i.length - t, 0), o = Array(a); ++n < a; )
      o[n] = i[t + n];
    n = -1;
    for (var s = Array(t + 1); ++n < t; )
      s[n] = i[n];
    return s[t] = r(o), nC(e, this, s);
  };
}
function sC(e) {
  return function() {
    return e;
  };
}
var oC = un ? function(e, t) {
  return un(e, "toString", {
    configurable: !0,
    enumerable: !1,
    value: sC(t),
    writable: !0
  });
} : Uu, lC = 800, cC = 16, hC = Date.now;
function uC(e) {
  var t = 0, r = 0;
  return function() {
    var i = hC(), n = cC - (i - r);
    if (r = i, n > 0) {
      if (++t >= lC)
        return arguments[0];
    } else
      t = 0;
    return e.apply(void 0, arguments);
  };
}
var fC = uC(oC);
function pC(e, t) {
  return fC(aC(e, t, Uu), e + "");
}
function dC(e, t, r) {
  if (!Ge(r))
    return !1;
  var i = typeof t;
  return (i == "number" ? qn(r) && ju(t, r.length) : i == "string" && t in r) ? In(r[t], e) : !1;
}
function gC(e) {
  return pC(function(t, r) {
    var i = -1, n = r.length, a = n > 1 ? r[n - 1] : void 0, o = n > 2 ? r[2] : void 0;
    for (a = e.length > 3 && typeof a == "function" ? (n--, a) : void 0, o && dC(r[0], r[1], o) && (a = n < 3 ? void 0 : a, n = 1), t = Object(t); ++i < n; ) {
      var s = r[i];
      s && e(t, s, i, a);
    }
    return t;
  });
}
var mC = gC(function(e, t, r) {
  Gu(e, t, r);
}), yC = "​", xC = {
  curveBasis: Ri,
  curveBasisClosed: Db,
  curveBasisOpen: Rb,
  curveBumpX: du,
  curveBumpY: gu,
  curveBundle: Ib,
  curveCardinalClosed: Pb,
  curveCardinalOpen: Nb,
  curveCardinal: bu,
  curveCatmullRomClosed: zb,
  curveCatmullRomOpen: qb,
  curveCatmullRom: _u,
  curveLinear: sn,
  curveLinearClosed: Wb,
  curveMonotoneX: Bu,
  curveMonotoneY: Lu,
  curveNatural: Au,
  curveStep: $u,
  curveStepAfter: Eu,
  curveStepBefore: Fu
}, bC = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, CC = /* @__PURE__ */ d(function(e, t) {
  const r = Xu(e, /(?:init\b)|(?:initialize\b)/);
  let i = {};
  if (Array.isArray(r)) {
    const o = r.map((s) => s.args);
    Hi(o), i = kt(i, [...o]);
  } else
    i = r.args;
  if (!i)
    return;
  let n = us(e, t);
  const a = "config";
  return i[a] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), i[n] = i[a], delete i[a]), i;
}, "detectInit"), Xu = /* @__PURE__ */ d(function(e, t = null) {
  var r, i;
  try {
    const n = new RegExp(
      `[%]{2}(?![{]${bC.source})(?=[}][%]{2}).*
`,
      "ig"
    );
    e = e.trim().replace(n, "").replace(/'/gm, '"'), F.debug(
      `Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${e}`
    );
    let a;
    const o = [];
    for (; (a = Ur.exec(e)) !== null; )
      if (a.index === Ur.lastIndex && Ur.lastIndex++, a && !t || t && ((r = a[1]) != null && r.match(t)) || t && ((i = a[2]) != null && i.match(t))) {
        const s = a[1] ? a[1] : a[2], l = a[3] ? a[3].trim() : a[4] ? JSON.parse(a[4].trim()) : null;
        o.push({ type: s, args: l });
      }
    return o.length === 0 ? { type: e, args: null } : o.length === 1 ? o[0] : o;
  } catch (n) {
    return F.error(
      `ERROR: ${n.message} - Unable to parse directive type: '${t}' based on the text: '${e}'`
    ), { type: void 0, args: null };
  }
}, "detectDirective"), _C = /* @__PURE__ */ d(function(e) {
  return e.replace(Ur, "");
}, "removeDirectives"), wC = /* @__PURE__ */ d(function(e, t) {
  for (const [r, i] of t.entries())
    if (i.match(e))
      return r;
  return -1;
}, "isSubstringInArray");
function Ws(e, t) {
  if (!e)
    return t;
  const r = `curve${e.charAt(0).toUpperCase() + e.slice(1)}`;
  return xC[r] ?? t;
}
d(Ws, "interpolateToCurve");
function Vu(e, t) {
  const r = e.trim();
  if (r)
    return t.securityLevel !== "loose" ? Ph(r) : r;
}
d(Vu, "formatUrl");
var vC = /* @__PURE__ */ d((e, ...t) => {
  const r = e.split("."), i = r.length - 1, n = r[i];
  let a = window;
  for (let o = 0; o < i; o++)
    if (a = a[r[o]], !a) {
      F.error(`Function name: ${e} not found in window`);
      return;
    }
  a[n](...t);
}, "runFunc");
function Hs(e, t) {
  return !e || !t ? 0 : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
d(Hs, "distance");
function Zu(e) {
  let t, r = 0;
  e.forEach((n) => {
    r += Hs(n, t), t = n;
  });
  const i = r / 2;
  return js(e, i);
}
d(Zu, "traverseEdge");
function Ku(e) {
  return e.length === 1 ? e[0] : Zu(e);
}
d(Ku, "calcLabelPosition");
var rl = /* @__PURE__ */ d((e, t = 2) => {
  const r = Math.pow(10, t);
  return Math.round(e * r) / r;
}, "roundNumber"), js = /* @__PURE__ */ d((e, t) => {
  let r, i = t;
  for (const n of e) {
    if (r) {
      const a = Hs(n, r);
      if (a === 0)
        return r;
      if (a < i)
        i -= a;
      else {
        const o = i / a;
        if (o <= 0)
          return r;
        if (o >= 1)
          return { x: n.x, y: n.y };
        if (o > 0 && o < 1)
          return {
            x: rl((1 - o) * r.x + o * n.x, 5),
            y: rl((1 - o) * r.y + o * n.y, 5)
          };
      }
    }
    r = n;
  }
  throw new Error("Could not find a suitable point for the given distance");
}, "calculatePoint"), kC = /* @__PURE__ */ d((e, t, r) => {
  F.info(`our points ${JSON.stringify(t)}`), t[0] !== r && (t = t.reverse());
  const n = js(t, 25), a = e ? 10 : 5, o = Math.atan2(t[0].y - n.y, t[0].x - n.x), s = { x: 0, y: 0 };
  return s.x = Math.sin(o) * a + (t[0].x + n.x) / 2, s.y = -Math.cos(o) * a + (t[0].y + n.y) / 2, s;
}, "calcCardinalityPosition");
function Qu(e, t, r) {
  const i = structuredClone(r);
  F.info("our points", i), t !== "start_left" && t !== "start_right" && i.reverse();
  const n = 25 + e, a = js(i, n), o = 10 + e * 0.5, s = Math.atan2(i[0].y - a.y, i[0].x - a.x), l = { x: 0, y: 0 };
  return t === "start_left" ? (l.x = Math.sin(s + Math.PI) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s + Math.PI) * o + (i[0].y + a.y) / 2) : t === "end_right" ? (l.x = Math.sin(s - Math.PI) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s - Math.PI) * o + (i[0].y + a.y) / 2 - 5) : t === "end_left" ? (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2 - 5) : (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2), l;
}
d(Qu, "calcTerminalLabelPosition");
function Ju(e) {
  let t = "", r = "";
  for (const i of e)
    i !== void 0 && (i.startsWith("color:") || i.startsWith("text-align:") ? r = r + i + ";" : t = t + i + ";");
  return { style: t, labelStyle: r };
}
d(Ju, "getStylesFromArray");
var il = 0, SC = /* @__PURE__ */ d(() => (il++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + il), "generateId");
function tf(e) {
  let t = "";
  const r = "0123456789abcdef", i = r.length;
  for (let n = 0; n < e; n++)
    t += r.charAt(Math.floor(Math.random() * i));
  return t;
}
d(tf, "makeRandomHex");
var TC = /* @__PURE__ */ d((e) => tf(e.length), "random"), BC = /* @__PURE__ */ d(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: "start",
    style: "#666",
    width: 100,
    height: 100,
    textMargin: 0,
    rx: 0,
    ry: 0,
    valign: void 0,
    text: ""
  };
}, "getTextObj"), LC = /* @__PURE__ */ d(function(e, t) {
  const r = t.text.replace(kr.lineBreakRegex, " "), [, i] = Wn(t.fontSize), n = e.append("text");
  n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", i), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class);
  const a = n.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.attr("fill", t.fill), a.text(r), n;
}, "drawSimpleText"), MC = di(
  (e, t, r) => {
    if (!e || (r = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" },
      r
    ), kr.lineBreakRegex.test(e)))
      return e;
    const i = e.split(" ").filter(Boolean), n = [];
    let a = "";
    return i.forEach((o, s) => {
      const l = de(`${o} `, r), c = de(a, r);
      if (l > t) {
        const { hyphenatedStrings: f, remainingWord: p } = AC(o, t, "-", r);
        n.push(a, ...f), a = p;
      } else c + l >= t ? (n.push(a), a = o) : a = [a, o].filter(Boolean).join(" ");
      s + 1 === i.length && n.push(a);
    }), n.filter((o) => o !== "").join(r.joinWith);
  },
  (e, t, r) => `${e}${t}${r.fontSize}${r.fontWeight}${r.fontFamily}${r.joinWith}`
), AC = di(
  (e, t, r = "-", i) => {
    i = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 },
      i
    );
    const n = [...e], a = [];
    let o = "";
    return n.forEach((s, l) => {
      const c = `${o}${s}`;
      if (de(c, i) >= t) {
        const u = l + 1, f = n.length === u, p = `${c}${r}`;
        a.push(f ? c : p), o = "";
      } else
        o = c;
    }), { hyphenatedStrings: a, remainingWord: o };
  },
  (e, t, r = "-", i) => `${e}${t}${r}${i.fontSize}${i.fontWeight}${i.fontFamily}`
);
function ef(e, t) {
  return Ys(e, t).height;
}
d(ef, "calculateTextHeight");
function de(e, t) {
  return Ys(e, t).width;
}
d(de, "calculateTextWidth");
var Ys = di(
  (e, t) => {
    const { fontSize: r = 12, fontFamily: i = "Arial", fontWeight: n = 400 } = t;
    if (!e)
      return { width: 0, height: 0 };
    const [, a] = Wn(r), o = ["sans-serif", i], s = e.split(kr.lineBreakRegex), l = [], c = et("body");
    if (!c.remove)
      return { width: 0, height: 0, lineHeight: 0 };
    const h = c.append("svg");
    for (const f of o) {
      let p = 0;
      const g = { width: 0, height: 0, lineHeight: 0 };
      for (const m of s) {
        const y = BC();
        y.text = m || yC;
        const x = LC(h, y).style("font-size", a).style("font-weight", n).style("font-family", f), b = (x._groups || x)[0][0].getBBox();
        if (b.width === 0 && b.height === 0)
          throw new Error("svg element not in render tree");
        g.width = Math.round(Math.max(g.width, b.width)), p = Math.round(b.height), g.height += p, g.lineHeight = Math.round(Math.max(g.lineHeight, p));
      }
      l.push(g);
    }
    h.remove();
    const u = isNaN(l[1].height) || isNaN(l[1].width) || isNaN(l[1].lineHeight) || l[0].height > l[1].height && l[0].width > l[1].width && l[0].lineHeight > l[1].lineHeight ? 0 : 1;
    return l[u];
  },
  (e, t) => `${e}${t.fontSize}${t.fontWeight}${t.fontFamily}`
), fr, $C = (fr = class {
  constructor(t = !1, r) {
    this.count = 0, this.count = r ? r.length : 0, this.next = t ? () => this.count++ : () => Date.now();
  }
}, d(fr, "InitIDGenerator"), fr), vi, FC = /* @__PURE__ */ d(function(e) {
  return vi = vi || document.createElement("div"), e = escape(e).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), vi.innerHTML = e, unescape(vi.textContent);
}, "entityDecode");
function Gs(e) {
  return "str" in e;
}
d(Gs, "isDetailedError");
var EC = /* @__PURE__ */ d((e, t, r, i) => {
  var a;
  if (!i)
    return;
  const n = (a = e.node()) == null ? void 0 : a.getBBox();
  n && e.append("text").text(i).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -r).attr("class", t);
}, "insertTitle"), Wn = /* @__PURE__ */ d((e) => {
  if (typeof e == "number")
    return [e, e + "px"];
  const t = parseInt(e ?? "", 10);
  return Number.isNaN(t) ? [void 0, void 0] : e === String(t) ? [t, e + "px"] : [t, e];
}, "parseFontSize");
function Us(e, t) {
  return mC({}, e, t);
}
d(Us, "cleanAndMerge");
var Jt = {
  assignWithDepth: kt,
  wrapLabel: MC,
  calculateTextHeight: ef,
  calculateTextWidth: de,
  calculateTextDimensions: Ys,
  cleanAndMerge: Us,
  detectInit: CC,
  detectDirective: Xu,
  isSubstringInArray: wC,
  interpolateToCurve: Ws,
  calcLabelPosition: Ku,
  calcCardinalityPosition: kC,
  calcTerminalLabelPosition: Qu,
  formatUrl: Vu,
  getStylesFromArray: Ju,
  generateId: SC,
  random: TC,
  runFunc: vC,
  entityDecode: FC,
  insertTitle: EC,
  parseFontSize: Wn,
  InitIDGenerator: $C
}, OC = /* @__PURE__ */ d(function(e) {
  let t = e;
  return t = t.replace(/style.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/classDef.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/#\w+;/g, function(r) {
    const i = r.substring(1, r.length - 1);
    return /^\+?\d+$/.test(i) ? "ﬂ°°" + i + "¶ß" : "ﬂ°" + i + "¶ß";
  }), t;
}, "encodeEntities"), Ve = /* @__PURE__ */ d(function(e) {
  return e.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";");
}, "decodeEntities"), FT = /* @__PURE__ */ d((e, t, {
  counter: r = 0,
  prefix: i,
  suffix: n
}, a) => a || `${i ? `${i}_` : ""}${e}_${t}_${r}${n ? `_${n}` : ""}`, "getEdgeId");
function Et(e) {
  return e ?? null;
}
d(Et, "handleUndefinedAttr");
const DC = Object.freeze(
  {
    left: 0,
    top: 0,
    width: 16,
    height: 16
  }
), dn = Object.freeze({
  rotate: 0,
  vFlip: !1,
  hFlip: !1
}), rf = Object.freeze({
  ...DC,
  ...dn
}), RC = Object.freeze({
  ...rf,
  body: "",
  hidden: !1
}), IC = Object.freeze({
  width: null,
  height: null
}), PC = Object.freeze({
  // Dimensions
  ...IC,
  // Transformations
  ...dn
}), NC = (e, t, r, i = "") => {
  const n = e.split(":");
  if (e.slice(0, 1) === "@") {
    if (n.length < 2 || n.length > 3)
      return null;
    i = n.shift().slice(1);
  }
  if (n.length > 3 || !n.length)
    return null;
  if (n.length > 1) {
    const s = n.pop(), l = n.pop(), c = {
      // Allow provider without '@': "provider:prefix:name"
      provider: n.length > 0 ? n[0] : i,
      prefix: l,
      name: s
    };
    return aa(c) ? c : null;
  }
  const a = n[0], o = a.split("-");
  if (o.length > 1) {
    const s = {
      provider: i,
      prefix: o.shift(),
      name: o.join("-")
    };
    return aa(s) ? s : null;
  }
  if (r && i === "") {
    const s = {
      provider: i,
      prefix: "",
      name: a
    };
    return aa(s, r) ? s : null;
  }
  return null;
}, aa = (e, t) => e ? !!// Check prefix: cannot be empty, unless allowSimpleName is enabled
// Check name: cannot be empty
((t && e.prefix === "" || e.prefix) && e.name) : !1;
function zC(e, t) {
  const r = {};
  !e.hFlip != !t.hFlip && (r.hFlip = !0), !e.vFlip != !t.vFlip && (r.vFlip = !0);
  const i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
  return i && (r.rotate = i), r;
}
function nl(e, t) {
  const r = zC(e, t);
  for (const i in RC)
    i in dn ? i in e && !(i in r) && (r[i] = dn[i]) : i in t ? r[i] = t[i] : i in e && (r[i] = e[i]);
  return r;
}
function qC(e, t) {
  const r = e.icons, i = e.aliases || /* @__PURE__ */ Object.create(null), n = /* @__PURE__ */ Object.create(null);
  function a(o) {
    if (r[o])
      return n[o] = [];
    if (!(o in n)) {
      n[o] = null;
      const s = i[o] && i[o].parent, l = s && a(s);
      l && (n[o] = [s].concat(l));
    }
    return n[o];
  }
  return (t || Object.keys(r).concat(Object.keys(i))).forEach(a), n;
}
function al(e, t, r) {
  const i = e.icons, n = e.aliases || /* @__PURE__ */ Object.create(null);
  let a = {};
  function o(s) {
    a = nl(
      i[s] || n[s],
      a
    );
  }
  return o(t), r.forEach(o), nl(e, a);
}
function WC(e, t) {
  if (e.icons[t])
    return al(e, t, []);
  const r = qC(e, [t])[t];
  return r ? al(e, t, r) : null;
}
const HC = /(-?[0-9.]*[0-9]+[0-9.]*)/g, jC = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function sl(e, t, r) {
  if (t === 1)
    return e;
  if (r = r || 100, typeof e == "number")
    return Math.ceil(e * t * r) / r;
  if (typeof e != "string")
    return e;
  const i = e.split(HC);
  if (i === null || !i.length)
    return e;
  const n = [];
  let a = i.shift(), o = jC.test(a);
  for (; ; ) {
    if (o) {
      const s = parseFloat(a);
      isNaN(s) ? n.push(a) : n.push(Math.ceil(s * t * r) / r);
    } else
      n.push(a);
    if (a = i.shift(), a === void 0)
      return n.join("");
    o = !o;
  }
}
function YC(e, t = "defs") {
  let r = "";
  const i = e.indexOf("<" + t);
  for (; i >= 0; ) {
    const n = e.indexOf(">", i), a = e.indexOf("</" + t);
    if (n === -1 || a === -1)
      break;
    const o = e.indexOf(">", a);
    if (o === -1)
      break;
    r += e.slice(n + 1, a).trim(), e = e.slice(0, i).trim() + e.slice(o + 1);
  }
  return {
    defs: r,
    content: e
  };
}
function GC(e, t) {
  return e ? "<defs>" + e + "</defs>" + t : t;
}
function UC(e, t, r) {
  const i = YC(e);
  return GC(i.defs, t + i.content + r);
}
const XC = (e) => e === "unset" || e === "undefined" || e === "none";
function VC(e, t) {
  const r = {
    ...rf,
    ...e
  }, i = {
    ...PC,
    ...t
  }, n = {
    left: r.left,
    top: r.top,
    width: r.width,
    height: r.height
  };
  let a = r.body;
  [r, i].forEach((m) => {
    const y = [], x = m.hFlip, b = m.vFlip;
    let _ = m.rotate;
    x ? b ? _ += 2 : (y.push(
      "translate(" + (n.width + n.left).toString() + " " + (0 - n.top).toString() + ")"
    ), y.push("scale(-1 1)"), n.top = n.left = 0) : b && (y.push(
      "translate(" + (0 - n.left).toString() + " " + (n.height + n.top).toString() + ")"
    ), y.push("scale(1 -1)"), n.top = n.left = 0);
    let S;
    switch (_ < 0 && (_ -= Math.floor(_ / 4) * 4), _ = _ % 4, _) {
      case 1:
        S = n.height / 2 + n.top, y.unshift(
          "rotate(90 " + S.toString() + " " + S.toString() + ")"
        );
        break;
      case 2:
        y.unshift(
          "rotate(180 " + (n.width / 2 + n.left).toString() + " " + (n.height / 2 + n.top).toString() + ")"
        );
        break;
      case 3:
        S = n.width / 2 + n.left, y.unshift(
          "rotate(-90 " + S.toString() + " " + S.toString() + ")"
        );
        break;
    }
    _ % 2 === 1 && (n.left !== n.top && (S = n.left, n.left = n.top, n.top = S), n.width !== n.height && (S = n.width, n.width = n.height, n.height = S)), y.length && (a = UC(
      a,
      '<g transform="' + y.join(" ") + '">',
      "</g>"
    ));
  });
  const o = i.width, s = i.height, l = n.width, c = n.height;
  let h, u;
  o === null ? (u = s === null ? "1em" : s === "auto" ? c : s, h = sl(u, l / c)) : (h = o === "auto" ? l : o, u = s === null ? sl(h, c / l) : s === "auto" ? c : s);
  const f = {}, p = (m, y) => {
    XC(y) || (f[m] = y.toString());
  };
  p("width", h), p("height", u);
  const g = [n.left, n.top, l, c];
  return f.viewBox = g.join(" "), {
    attributes: f,
    viewBox: g,
    body: a
  };
}
const ZC = /\sid="(\S+)"/g, KC = "IconifyId" + Date.now().toString(16) + (Math.random() * 16777216 | 0).toString(16);
let QC = 0;
function JC(e, t = KC) {
  const r = [];
  let i;
  for (; i = ZC.exec(e); )
    r.push(i[1]);
  if (!r.length)
    return e;
  const n = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
  return r.forEach((a) => {
    const o = typeof t == "function" ? t(a) : t + (QC++).toString(), s = a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    e = e.replace(
      // Allowed characters before id: [#;"]
      // Allowed characters after id: [)"], .[a-z]
      new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"),
      "$1" + o + n + "$3"
    );
  }), e = e.replace(new RegExp(n, "g"), ""), e;
}
function t_(e, t) {
  let r = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const i in t)
    r += " " + i + '="' + t[i] + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + r + ">" + e + "</svg>";
}
function Xs() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
var Ze = Xs();
function nf(e) {
  Ze = e;
}
var Zr = { exec: () => null };
function st(e, t = "") {
  let r = typeof e == "string" ? e : e.source;
  const i = {
    replace: (n, a) => {
      let o = typeof a == "string" ? a : a.source;
      return o = o.replace(Ft.caret, "$1"), r = r.replace(n, o), i;
    },
    getRegex: () => new RegExp(r, t)
  };
  return i;
}
var Ft = {
  codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
  outputLinkReplace: /\\([\[\]])/g,
  indentCodeCompensation: /^(\s+)(?:```)/,
  beginningSpace: /^\s+/,
  endingHash: /#$/,
  startingSpaceChar: /^ /,
  endingSpaceChar: / $/,
  nonSpaceChar: /[^ ]/,
  newLineCharGlobal: /\n/g,
  tabCharGlobal: /\t/g,
  multipleSpaceGlobal: /\s+/g,
  blankLine: /^[ \t]*$/,
  doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
  blockquoteStart: /^ {0,3}>/,
  blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
  blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
  listReplaceTabs: /^\t+/,
  listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
  listIsTask: /^\[[ xX]\] /,
  listReplaceTask: /^\[[ xX]\] +/,
  anyLine: /\n.*\n/,
  hrefBrackets: /^<(.*)>$/,
  tableDelimiter: /[:|]/,
  tableAlignChars: /^\||\| *$/g,
  tableRowBlankLine: /\n[ \t]*$/,
  tableAlignRight: /^ *-+: *$/,
  tableAlignCenter: /^ *:-+: *$/,
  tableAlignLeft: /^ *:-+ *$/,
  startATag: /^<a /i,
  endATag: /^<\/a>/i,
  startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
  endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
  startAngleBracket: /^</,
  endAngleBracket: />$/,
  pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
  unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
  escapeTest: /[&<>"']/,
  escapeReplace: /[&<>"']/g,
  escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
  escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
  caret: /(^|[^\[])\^/g,
  percentDecode: /%25/g,
  findPipe: /\|/g,
  splitPipe: / \|/,
  slashPipe: /\\\|/g,
  carriageReturn: /\r\n|\r/g,
  spaceLine: /^ +$/gm,
  notSpaceStart: /^\S*/,
  endingNewline: /\n$/,
  listItemRegex: (e) => new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`),
  nextBulletRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
  hrRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
  fencesBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:\`\`\`|~~~)`),
  headingBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}#`),
  htmlBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}<(?:[a-z].*>|!--)`, "i")
}, e_ = /^(?:[ \t]*(?:\n|$))+/, r_ = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, i_ = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, mi = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, n_ = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Vs = /(?:[*+-]|\d{1,9}[.)])/, af = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, sf = st(af).replace(/bull/g, Vs).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), a_ = st(af).replace(/bull/g, Vs).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), Zs = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, s_ = /^[^\n]+/, Ks = /(?!\s*\])(?:\\.|[^\[\]\\])+/, o_ = st(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", Ks).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), l_ = st(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Vs).getRegex(), Hn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Qs = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, c_ = st(
  "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))",
  "i"
).replace("comment", Qs).replace("tag", Hn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), of = st(Zs).replace("hr", mi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Hn).getRegex(), h_ = st(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", of).getRegex(), Js = {
  blockquote: h_,
  code: r_,
  def: o_,
  fences: i_,
  heading: n_,
  hr: mi,
  html: c_,
  lheading: sf,
  list: l_,
  newline: e_,
  paragraph: of,
  table: Zr,
  text: s_
}, ol = st(
  "^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
).replace("hr", mi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Hn).getRegex(), u_ = {
  ...Js,
  lheading: a_,
  table: ol,
  paragraph: st(Zs).replace("hr", mi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", ol).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Hn).getRegex()
}, f_ = {
  ...Js,
  html: st(
    `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`
  ).replace("comment", Qs).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Zr,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: st(Zs).replace("hr", mi).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", sf).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, p_ = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, d_ = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, lf = /^( {2,}|\\)\n(?!\s*$)/, g_ = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, jn = /[\p{P}\p{S}]/u, to = /[\s\p{P}\p{S}]/u, cf = /[^\s\p{P}\p{S}]/u, m_ = st(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, to).getRegex(), hf = /(?!~)[\p{P}\p{S}]/u, y_ = /(?!~)[\s\p{P}\p{S}]/u, x_ = /(?:[^\s\p{P}\p{S}]|~)/u, b_ = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g, uf = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, C_ = st(uf, "u").replace(/punct/g, jn).getRegex(), __ = st(uf, "u").replace(/punct/g, hf).getRegex(), ff = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", w_ = st(ff, "gu").replace(/notPunctSpace/g, cf).replace(/punctSpace/g, to).replace(/punct/g, jn).getRegex(), v_ = st(ff, "gu").replace(/notPunctSpace/g, x_).replace(/punctSpace/g, y_).replace(/punct/g, hf).getRegex(), k_ = st(
  "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)",
  "gu"
).replace(/notPunctSpace/g, cf).replace(/punctSpace/g, to).replace(/punct/g, jn).getRegex(), S_ = st(/\\(punct)/, "gu").replace(/punct/g, jn).getRegex(), T_ = st(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), B_ = st(Qs).replace("(?:-->|$)", "-->").getRegex(), L_ = st(
  "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>"
).replace("comment", B_).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), gn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, M_ = st(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", gn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), pf = st(/^!?\[(label)\]\[(ref)\]/).replace("label", gn).replace("ref", Ks).getRegex(), df = st(/^!?\[(ref)\](?:\[\])?/).replace("ref", Ks).getRegex(), A_ = st("reflink|nolink(?!\\()", "g").replace("reflink", pf).replace("nolink", df).getRegex(), eo = {
  _backpedal: Zr,
  // only used for GFM url
  anyPunctuation: S_,
  autolink: T_,
  blockSkip: b_,
  br: lf,
  code: d_,
  del: Zr,
  emStrongLDelim: C_,
  emStrongRDelimAst: w_,
  emStrongRDelimUnd: k_,
  escape: p_,
  link: M_,
  nolink: df,
  punctuation: m_,
  reflink: pf,
  reflinkSearch: A_,
  tag: L_,
  text: g_,
  url: Zr
}, $_ = {
  ...eo,
  link: st(/^!?\[(label)\]\((.*?)\)/).replace("label", gn).getRegex(),
  reflink: st(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", gn).getRegex()
}, Ga = {
  ...eo,
  emStrongRDelimAst: v_,
  emStrongLDelim: __,
  url: st(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, F_ = {
  ...Ga,
  br: st(lf).replace("{2,}", "*").getRegex(),
  text: st(Ga.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, ki = {
  normal: Js,
  gfm: u_,
  pedantic: f_
}, Er = {
  normal: eo,
  gfm: Ga,
  breaks: F_,
  pedantic: $_
}, E_ = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ll = (e) => E_[e];
function Zt(e, t) {
  if (t) {
    if (Ft.escapeTest.test(e))
      return e.replace(Ft.escapeReplace, ll);
  } else if (Ft.escapeTestNoEncode.test(e))
    return e.replace(Ft.escapeReplaceNoEncode, ll);
  return e;
}
function cl(e) {
  try {
    e = encodeURI(e).replace(Ft.percentDecode, "%");
  } catch {
    return null;
  }
  return e;
}
function hl(e, t) {
  var a;
  const r = e.replace(Ft.findPipe, (o, s, l) => {
    let c = !1, h = s;
    for (; --h >= 0 && l[h] === "\\"; ) c = !c;
    return c ? "|" : " |";
  }), i = r.split(Ft.splitPipe);
  let n = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !((a = i.at(-1)) != null && a.trim()) && i.pop(), t)
    if (i.length > t)
      i.splice(t);
    else
      for (; i.length < t; ) i.push("");
  for (; n < i.length; n++)
    i[n] = i[n].trim().replace(Ft.slashPipe, "|");
  return i;
}
function Or(e, t, r) {
  const i = e.length;
  if (i === 0)
    return "";
  let n = 0;
  for (; n < i && e.charAt(i - n - 1) === t; )
    n++;
  return e.slice(0, i - n);
}
function O_(e, t) {
  if (e.indexOf(t[1]) === -1)
    return -1;
  let r = 0;
  for (let i = 0; i < e.length; i++)
    if (e[i] === "\\")
      i++;
    else if (e[i] === t[0])
      r++;
    else if (e[i] === t[1] && (r--, r < 0))
      return i;
  return r > 0 ? -2 : -1;
}
function ul(e, t, r, i, n) {
  const a = t.href, o = t.title || null, s = e[1].replace(n.other.outputLinkReplace, "$1");
  i.state.inLink = !0;
  const l = {
    type: e[0].charAt(0) === "!" ? "image" : "link",
    raw: r,
    href: a,
    title: o,
    text: s,
    tokens: i.inlineTokens(s)
  };
  return i.state.inLink = !1, l;
}
function D_(e, t, r) {
  const i = e.match(r.other.indentCodeCompensation);
  if (i === null)
    return t;
  const n = i[1];
  return t.split(`
`).map((a) => {
    const o = a.match(r.other.beginningSpace);
    if (o === null)
      return a;
    const [s] = o;
    return s.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
var mn = class {
  // set by the lexer
  constructor(e) {
    ot(this, "options");
    ot(this, "rules");
    // set by the lexer
    ot(this, "lexer");
    this.options = e || Ze;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(this.rules.other.codeRemoveIndent, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : Or(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], i = D_(r, t[3] || "", this.rules);
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (this.rules.other.endingHash.test(r)) {
        const i = Or(r, "#");
        (this.options.pedantic || !i || this.rules.other.endingSpaceChar.test(i)) && (r = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: Or(t[0], `
`)
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = Or(t[0], `
`).split(`
`), i = "", n = "";
      const a = [];
      for (; r.length > 0; ) {
        let o = !1;
        const s = [];
        let l;
        for (l = 0; l < r.length; l++)
          if (this.rules.other.blockquoteStart.test(r[l]))
            s.push(r[l]), o = !0;
          else if (!o)
            s.push(r[l]);
          else
            break;
        r = r.slice(l);
        const c = s.join(`
`), h = c.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        i = i ? `${i}
${c}` : c, n = n ? `${n}
${h}` : h;
        const u = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(h, a, !0), this.lexer.state.top = u, r.length === 0)
          break;
        const f = a.at(-1);
        if ((f == null ? void 0 : f.type) === "code")
          break;
        if ((f == null ? void 0 : f.type) === "blockquote") {
          const p = f, g = p.raw + `
` + r.join(`
`), m = this.blockquote(g);
          a[a.length - 1] = m, i = i.substring(0, i.length - p.raw.length) + m.raw, n = n.substring(0, n.length - p.text.length) + m.text;
          break;
        } else if ((f == null ? void 0 : f.type) === "list") {
          const p = f, g = p.raw + `
` + r.join(`
`), m = this.list(g);
          a[a.length - 1] = m, i = i.substring(0, i.length - f.raw.length) + m.raw, n = n.substring(0, n.length - p.raw.length) + m.raw, r = g.substring(a.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return {
        type: "blockquote",
        raw: i,
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const i = r.length > 1, n = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = i ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = i ? r : "[*+-]");
      const a = this.rules.other.listItemRegex(r);
      let o = !1;
      for (; e; ) {
        let l = !1, c = "", h = "";
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        c = t[0], e = e.substring(c.length);
        let u = t[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (x) => " ".repeat(3 * x.length)), f = e.split(`
`, 1)[0], p = !u.trim(), g = 0;
        if (this.options.pedantic ? (g = 2, h = u.trimStart()) : p ? g = t[1].length + 1 : (g = t[2].search(this.rules.other.nonSpaceChar), g = g > 4 ? 1 : g, h = u.slice(g), g += t[1].length), p && this.rules.other.blankLine.test(f) && (c += f + `
`, e = e.substring(f.length + 1), l = !0), !l) {
          const x = this.rules.other.nextBulletRegex(g), b = this.rules.other.hrRegex(g), _ = this.rules.other.fencesBeginRegex(g), S = this.rules.other.headingBeginRegex(g), w = this.rules.other.htmlBeginRegex(g);
          for (; e; ) {
            const C = e.split(`
`, 1)[0];
            let v;
            if (f = C, this.options.pedantic ? (f = f.replace(this.rules.other.listReplaceNesting, "  "), v = f) : v = f.replace(this.rules.other.tabCharGlobal, "    "), _.test(f) || S.test(f) || w.test(f) || x.test(f) || b.test(f))
              break;
            if (v.search(this.rules.other.nonSpaceChar) >= g || !f.trim())
              h += `
` + v.slice(g);
            else {
              if (p || u.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || _.test(u) || S.test(u) || b.test(u))
                break;
              h += `
` + f;
            }
            !p && !f.trim() && (p = !0), c += C + `
`, e = e.substring(C.length + 1), u = v.slice(g);
          }
        }
        n.loose || (o ? n.loose = !0 : this.rules.other.doubleBlankLine.test(c) && (o = !0));
        let m = null, y;
        this.options.gfm && (m = this.rules.other.listIsTask.exec(h), m && (y = m[0] !== "[ ] ", h = h.replace(this.rules.other.listReplaceTask, ""))), n.items.push({
          type: "list_item",
          raw: c,
          task: !!m,
          checked: y,
          loose: !1,
          text: h,
          tokens: []
        }), n.raw += c;
      }
      const s = n.items.at(-1);
      if (s)
        s.raw = s.raw.trimEnd(), s.text = s.text.trimEnd();
      else
        return;
      n.raw = n.raw.trimEnd();
      for (let l = 0; l < n.items.length; l++)
        if (this.lexer.state.top = !1, n.items[l].tokens = this.lexer.blockTokens(n.items[l].text, []), !n.loose) {
          const c = n.items[l].tokens.filter((u) => u.type === "space"), h = c.length > 0 && c.some((u) => this.rules.other.anyLine.test(u.raw));
          n.loose = h;
        }
      if (n.loose)
        for (let l = 0; l < n.items.length; l++)
          n.items[l].loose = !0;
      return n;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), i = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", n = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: i,
        title: n
      };
    }
  }
  table(e) {
    var o;
    const t = this.rules.block.table.exec(e);
    if (!t || !this.rules.other.tableDelimiter.test(t[2]))
      return;
    const r = hl(t[1]), i = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), n = (o = t[3]) != null && o.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], a = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === i.length) {
      for (const s of i)
        this.rules.other.tableAlignRight.test(s) ? a.align.push("right") : this.rules.other.tableAlignCenter.test(s) ? a.align.push("center") : this.rules.other.tableAlignLeft.test(s) ? a.align.push("left") : a.align.push(null);
      for (let s = 0; s < r.length; s++)
        a.header.push({
          text: r[s],
          tokens: this.lexer.inline(r[s]),
          header: !0,
          align: a.align[s]
        });
      for (const s of n)
        a.rows.push(hl(s, a.header.length).map((l, c) => ({
          text: l,
          tokens: this.lexer.inline(l),
          header: !1,
          align: a.align[c]
        })));
      return a;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: t[1]
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(r)) {
        if (!this.rules.other.endAngleBracket.test(r))
          return;
        const a = Or(r.slice(0, -1), "\\");
        if ((r.length - a.length) % 2 === 0)
          return;
      } else {
        const a = O_(t[2], "()");
        if (a === -2)
          return;
        if (a > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + a;
          t[2] = t[2].substring(0, a), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], n = "";
      if (this.options.pedantic) {
        const a = this.rules.other.pedanticHrefTitle.exec(i);
        a && (i = a[1], n = a[3]);
      } else
        n = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), this.rules.other.startAngleBracket.test(i) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(r) ? i = i.slice(1) : i = i.slice(1, -1)), ul(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: n && n.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer, this.rules);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const i = (r[2] || r[1]).replace(this.rules.other.multipleSpaceGlobal, " "), n = t[i.toLowerCase()];
      if (!n) {
        const a = r[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return ul(r, n, r[0], this.lexer, this.rules);
    }
  }
  emStrong(e, t, r = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && r.match(this.rules.other.unicodeAlphaNumeric)) return;
    if (!(i[1] || i[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const a = [...i[0]].length - 1;
      let o, s, l = a, c = 0;
      const h = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, t = t.slice(-1 * e.length + a); (i = h.exec(t)) != null; ) {
        if (o = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !o) continue;
        if (s = [...o].length, i[3] || i[4]) {
          l += s;
          continue;
        } else if ((i[5] || i[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (l -= s, l > 0) continue;
        s = Math.min(s, s + l + c);
        const u = [...i[0]][0].length, f = e.slice(0, a + i.index + u + s);
        if (Math.min(a, s) % 2) {
          const g = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: g,
            tokens: this.lexer.inlineTokens(g)
          };
        }
        const p = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(this.rules.other.newLineCharGlobal, " ");
      const i = this.rules.other.nonSpaceChar.test(r), n = this.rules.other.startingSpaceChar.test(r) && this.rules.other.endingSpaceChar.test(r);
      return i && n && (r = r.substring(1, r.length - 1)), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, i;
      return t[2] === "@" ? (r = t[1], i = "mailto:" + r) : (r = t[1], i = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: i,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, n;
      if (t[2] === "@")
        i = t[0], n = "mailto:" + i;
      else {
        let a;
        do
          a = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (a !== t[0]);
        i = t[0], t[1] === "www." ? n = "http://" + t[0] : n = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: n,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      const r = this.lexer.state.inRawBlock;
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        escaped: r
      };
    }
  }
}, ce = class Ua {
  constructor(t) {
    ot(this, "tokens");
    ot(this, "options");
    ot(this, "state");
    ot(this, "tokenizer");
    ot(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || Ze, this.options.tokenizer = this.options.tokenizer || new mn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const r = {
      other: Ft,
      block: ki.normal,
      inline: Er.normal
    };
    this.options.pedantic ? (r.block = ki.pedantic, r.inline = Er.pedantic) : this.options.gfm && (r.block = ki.gfm, this.options.breaks ? r.inline = Er.breaks : r.inline = Er.gfm), this.tokenizer.rules = r;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: ki,
      inline: Er
    };
  }
  /**
   * Static Lex Method
   */
  static lex(t, r) {
    return new Ua(r).lex(t);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(t, r) {
    return new Ua(r).inlineTokens(t);
  }
  /**
   * Preprocessing
   */
  lex(t) {
    t = t.replace(Ft.carriageReturn, `
`), this.blockTokens(t, this.tokens);
    for (let r = 0; r < this.inlineQueue.length; r++) {
      const i = this.inlineQueue[r];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, r = [], i = !1) {
    var n, a, o;
    for (this.options.pedantic && (t = t.replace(Ft.tabCharGlobal, "    ").replace(Ft.spaceLine, "")); t; ) {
      let s;
      if ((a = (n = this.options.extensions) == null ? void 0 : n.block) != null && a.some((c) => (s = c.call({ lexer: this }, t, r)) ? (t = t.substring(s.raw.length), r.push(s), !0) : !1))
        continue;
      if (s = this.tokenizer.space(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        s.raw.length === 1 && c !== void 0 ? c.raw += `
` : r.push(s);
        continue;
      }
      if (s = this.tokenizer.code(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (s = this.tokenizer.fences(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.heading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.hr(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.blockquote(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.list(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.html(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.def(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.raw, this.inlineQueue.at(-1).src = c.text) : this.tokens.links[s.tag] || (this.tokens.links[s.tag] = {
          href: s.href,
          title: s.title
        });
        continue;
      }
      if (s = this.tokenizer.table(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.lheading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      let l = t;
      if ((o = this.options.extensions) != null && o.startBlock) {
        let c = 1 / 0;
        const h = t.slice(1);
        let u;
        this.options.extensions.startBlock.forEach((f) => {
          u = f.call({ lexer: this }, h), typeof u == "number" && u >= 0 && (c = Math.min(c, u));
        }), c < 1 / 0 && c >= 0 && (l = t.substring(0, c + 1));
      }
      if (this.state.top && (s = this.tokenizer.paragraph(l))) {
        const c = r.at(-1);
        i && (c == null ? void 0 : c.type) === "paragraph" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s), i = l.length !== t.length, t = t.substring(s.raw.length);
        continue;
      }
      if (s = this.tokenizer.text(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (t) {
        const c = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(c);
          break;
        } else
          throw new Error(c);
      }
    }
    return this.state.top = !0, r;
  }
  inline(t, r = []) {
    return this.inlineQueue.push({ src: t, tokens: r }), r;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(t, r = []) {
    var s, l, c;
    let i = t, n = null;
    if (this.tokens.links) {
      const h = Object.keys(this.tokens.links);
      if (h.length > 0)
        for (; (n = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; )
          h.includes(n[0].slice(n[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (n = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; )
      i = i.slice(0, n.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; (n = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; )
      i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    let a = !1, o = "";
    for (; t; ) {
      a || (o = ""), a = !1;
      let h;
      if ((l = (s = this.options.extensions) == null ? void 0 : s.inline) != null && l.some((f) => (h = f.call({ lexer: this }, t, r)) ? (t = t.substring(h.raw.length), r.push(h), !0) : !1))
        continue;
      if (h = this.tokenizer.escape(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.tag(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.link(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.reflink(t, this.tokens.links)) {
        t = t.substring(h.raw.length);
        const f = r.at(-1);
        h.type === "text" && (f == null ? void 0 : f.type) === "text" ? (f.raw += h.raw, f.text += h.text) : r.push(h);
        continue;
      }
      if (h = this.tokenizer.emStrong(t, i, o)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.codespan(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.br(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.del(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.autolink(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (!this.state.inLink && (h = this.tokenizer.url(t))) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      let u = t;
      if ((c = this.options.extensions) != null && c.startInline) {
        let f = 1 / 0;
        const p = t.slice(1);
        let g;
        this.options.extensions.startInline.forEach((m) => {
          g = m.call({ lexer: this }, p), typeof g == "number" && g >= 0 && (f = Math.min(f, g));
        }), f < 1 / 0 && f >= 0 && (u = t.substring(0, f + 1));
      }
      if (h = this.tokenizer.inlineText(u)) {
        t = t.substring(h.raw.length), h.raw.slice(-1) !== "_" && (o = h.raw.slice(-1)), a = !0;
        const f = r.at(-1);
        (f == null ? void 0 : f.type) === "text" ? (f.raw += h.raw, f.text += h.text) : r.push(h);
        continue;
      }
      if (t) {
        const f = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(f);
          break;
        } else
          throw new Error(f);
      }
    }
    return r;
  }
}, yn = class {
  // set by the parser
  constructor(e) {
    ot(this, "options");
    ot(this, "parser");
    this.options = e || Ze;
  }
  space(e) {
    return "";
  }
  code({ text: e, lang: t, escaped: r }) {
    var a;
    const i = (a = (t || "").match(Ft.notSpaceStart)) == null ? void 0 : a[0], n = e.replace(Ft.endingNewline, "") + `
`;
    return i ? '<pre><code class="language-' + Zt(i) + '">' + (r ? n : Zt(n, !0)) + `</code></pre>
` : "<pre><code>" + (r ? n : Zt(n, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: e }) {
    return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
  }
  html({ text: e }) {
    return e;
  }
  heading({ tokens: e, depth: t }) {
    return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
  }
  hr(e) {
    return `<hr>
`;
  }
  list(e) {
    const t = e.ordered, r = e.start;
    let i = "";
    for (let o = 0; o < e.items.length; o++) {
      const s = e.items[o];
      i += this.listitem(s);
    }
    const n = t ? "ol" : "ul", a = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + n + a + `>
` + i + "</" + n + `>
`;
  }
  listitem(e) {
    var r;
    let t = "";
    if (e.task) {
      const i = this.checkbox({ checked: !!e.checked });
      e.loose ? ((r = e.tokens[0]) == null ? void 0 : r.type) === "paragraph" ? (e.tokens[0].text = i + " " + e.tokens[0].text, e.tokens[0].tokens && e.tokens[0].tokens.length > 0 && e.tokens[0].tokens[0].type === "text" && (e.tokens[0].tokens[0].text = i + " " + Zt(e.tokens[0].tokens[0].text), e.tokens[0].tokens[0].escaped = !0)) : e.tokens.unshift({
        type: "text",
        raw: i + " ",
        text: i + " ",
        escaped: !0
      }) : t += i + " ";
    }
    return t += this.parser.parse(e.tokens, !!e.loose), `<li>${t}</li>
`;
  }
  checkbox({ checked: e }) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: e }) {
    return `<p>${this.parser.parseInline(e)}</p>
`;
  }
  table(e) {
    let t = "", r = "";
    for (let n = 0; n < e.header.length; n++)
      r += this.tablecell(e.header[n]);
    t += this.tablerow({ text: r });
    let i = "";
    for (let n = 0; n < e.rows.length; n++) {
      const a = e.rows[n];
      r = "";
      for (let o = 0; o < a.length; o++)
        r += this.tablecell(a[o]);
      i += this.tablerow({ text: r });
    }
    return i && (i = `<tbody>${i}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + i + `</table>
`;
  }
  tablerow({ text: e }) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e) {
    const t = this.parser.parseInline(e.tokens), r = e.header ? "th" : "td";
    return (e.align ? `<${r} align="${e.align}">` : `<${r}>`) + t + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong({ tokens: e }) {
    return `<strong>${this.parser.parseInline(e)}</strong>`;
  }
  em({ tokens: e }) {
    return `<em>${this.parser.parseInline(e)}</em>`;
  }
  codespan({ text: e }) {
    return `<code>${Zt(e, !0)}</code>`;
  }
  br(e) {
    return "<br>";
  }
  del({ tokens: e }) {
    return `<del>${this.parser.parseInline(e)}</del>`;
  }
  link({ href: e, title: t, tokens: r }) {
    const i = this.parser.parseInline(r), n = cl(e);
    if (n === null)
      return i;
    e = n;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + Zt(t) + '"'), a += ">" + i + "</a>", a;
  }
  image({ href: e, title: t, text: r, tokens: i }) {
    i && (r = this.parser.parseInline(i, this.parser.textRenderer));
    const n = cl(e);
    if (n === null)
      return Zt(r);
    e = n;
    let a = `<img src="${e}" alt="${r}"`;
    return t && (a += ` title="${Zt(t)}"`), a += ">", a;
  }
  text(e) {
    return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : Zt(e.text);
  }
}, ro = class {
  // no need for block level renderers
  strong({ text: e }) {
    return e;
  }
  em({ text: e }) {
    return e;
  }
  codespan({ text: e }) {
    return e;
  }
  del({ text: e }) {
    return e;
  }
  html({ text: e }) {
    return e;
  }
  text({ text: e }) {
    return e;
  }
  link({ text: e }) {
    return "" + e;
  }
  image({ text: e }) {
    return "" + e;
  }
  br() {
    return "";
  }
}, he = class Xa {
  constructor(t) {
    ot(this, "options");
    ot(this, "renderer");
    ot(this, "textRenderer");
    this.options = t || Ze, this.options.renderer = this.options.renderer || new yn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new ro();
  }
  /**
   * Static Parse Method
   */
  static parse(t, r) {
    return new Xa(r).parse(t);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(t, r) {
    return new Xa(r).parseInline(t);
  }
  /**
   * Parse Loop
   */
  parse(t, r = !0) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        const c = s, h = this.options.extensions.renderers[c.type].call({ parser: this }, c);
        if (h !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(c.type)) {
          i += h || "";
          continue;
        }
      }
      const l = s;
      switch (l.type) {
        case "space": {
          i += this.renderer.space(l);
          continue;
        }
        case "hr": {
          i += this.renderer.hr(l);
          continue;
        }
        case "heading": {
          i += this.renderer.heading(l);
          continue;
        }
        case "code": {
          i += this.renderer.code(l);
          continue;
        }
        case "table": {
          i += this.renderer.table(l);
          continue;
        }
        case "blockquote": {
          i += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          i += this.renderer.list(l);
          continue;
        }
        case "html": {
          i += this.renderer.html(l);
          continue;
        }
        case "paragraph": {
          i += this.renderer.paragraph(l);
          continue;
        }
        case "text": {
          let c = l, h = this.renderer.text(c);
          for (; o + 1 < t.length && t[o + 1].type === "text"; )
            c = t[++o], h += `
` + this.renderer.text(c);
          r ? i += this.renderer.paragraph({
            type: "paragraph",
            raw: h,
            text: h,
            tokens: [{ type: "text", raw: h, text: h, escaped: !0 }]
          }) : i += h;
          continue;
        }
        default: {
          const c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(t, r = this.renderer) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        const c = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (c !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          i += c || "";
          continue;
        }
      }
      const l = s;
      switch (l.type) {
        case "escape": {
          i += r.text(l);
          break;
        }
        case "html": {
          i += r.html(l);
          break;
        }
        case "link": {
          i += r.link(l);
          break;
        }
        case "image": {
          i += r.image(l);
          break;
        }
        case "strong": {
          i += r.strong(l);
          break;
        }
        case "em": {
          i += r.em(l);
          break;
        }
        case "codespan": {
          i += r.codespan(l);
          break;
        }
        case "br": {
          i += r.br(l);
          break;
        }
        case "del": {
          i += r.del(l);
          break;
        }
        case "text": {
          i += r.text(l);
          break;
        }
        default: {
          const c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
}, da, Ii = (da = class {
  constructor(e) {
    ot(this, "options");
    ot(this, "block");
    this.options = e || Ze;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
  /**
   * Provide function to tokenize markdown
   */
  provideLexer() {
    return this.block ? ce.lex : ce.lexInline;
  }
  /**
   * Provide function to parse tokens
   */
  provideParser() {
    return this.block ? he.parse : he.parseInline;
  }
}, ot(da, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
])), da), R_ = class {
  constructor(...e) {
    ot(this, "defaults", Xs());
    ot(this, "options", this.setOptions);
    ot(this, "parse", this.parseMarkdown(!0));
    ot(this, "parseInline", this.parseMarkdown(!1));
    ot(this, "Parser", he);
    ot(this, "Renderer", yn);
    ot(this, "TextRenderer", ro);
    ot(this, "Lexer", ce);
    ot(this, "Tokenizer", mn);
    ot(this, "Hooks", Ii);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, n;
    let r = [];
    for (const a of e)
      switch (r = r.concat(t.call(this, a)), a.type) {
        case "table": {
          const o = a;
          for (const s of o.header)
            r = r.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const l of s)
              r = r.concat(this.walkTokens(l.tokens, t));
          break;
        }
        case "list": {
          const o = a;
          r = r.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = a;
          (n = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && n[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const l = o[s].flat(1 / 0);
            r = r.concat(this.walkTokens(l, t));
          }) : o.tokens && (r = r.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const i = { ...r };
      if (i.async = this.defaults.async || i.async || !1, r.extensions && (r.extensions.forEach((n) => {
        if (!n.name)
          throw new Error("extension name required");
        if ("renderer" in n) {
          const a = t.renderers[n.name];
          a ? t.renderers[n.name] = function(...o) {
            let s = n.renderer.apply(this, o);
            return s === !1 && (s = a.apply(this, o)), s;
          } : t.renderers[n.name] = n.renderer;
        }
        if ("tokenizer" in n) {
          if (!n.level || n.level !== "block" && n.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = t[n.level];
          a ? a.unshift(n.tokenizer) : t[n.level] = [n.tokenizer], n.start && (n.level === "block" ? t.startBlock ? t.startBlock.push(n.start) : t.startBlock = [n.start] : n.level === "inline" && (t.startInline ? t.startInline.push(n.start) : t.startInline = [n.start]));
        }
        "childTokens" in n && n.childTokens && (t.childTokens[n.name] = n.childTokens);
      }), i.extensions = t), r.renderer) {
        const n = this.defaults.renderer || new yn(this.defaults);
        for (const a in r.renderer) {
          if (!(a in n))
            throw new Error(`renderer '${a}' does not exist`);
          if (["options", "parser"].includes(a))
            continue;
          const o = a, s = r.renderer[o], l = n[o];
          n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h || "";
          };
        }
        i.renderer = n;
      }
      if (r.tokenizer) {
        const n = this.defaults.tokenizer || new mn(this.defaults);
        for (const a in r.tokenizer) {
          if (!(a in n))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const o = a, s = r.tokenizer[o], l = n[o];
          n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h;
          };
        }
        i.tokenizer = n;
      }
      if (r.hooks) {
        const n = this.defaults.hooks || new Ii();
        for (const a in r.hooks) {
          if (!(a in n))
            throw new Error(`hook '${a}' does not exist`);
          if (["options", "block"].includes(a))
            continue;
          const o = a, s = r.hooks[o], l = n[o];
          Ii.passThroughHooks.has(a) ? n[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(n, c)).then((u) => l.call(n, u));
            const h = s.call(n, c);
            return l.call(n, h);
          } : n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h;
          };
        }
        i.hooks = n;
      }
      if (r.walkTokens) {
        const n = this.defaults.walkTokens, a = r.walkTokens;
        i.walkTokens = function(o) {
          let s = [];
          return s.push(a.call(this, o)), n && (s = s.concat(n.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return ce.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return he.parse(e, t ?? this.defaults);
  }
  parseMarkdown(e) {
    return (r, i) => {
      const n = { ...i }, a = { ...this.defaults, ...n }, o = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && n.async === !1)
        return o(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof r > "u" || r === null)
        return o(new Error("marked(): input parameter is undefined or null"));
      if (typeof r != "string")
        return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
      a.hooks && (a.hooks.options = a, a.hooks.block = e);
      const s = a.hooks ? a.hooks.provideLexer() : e ? ce.lex : ce.lexInline, l = a.hooks ? a.hooks.provideParser() : e ? he.parse : he.parseInline;
      if (a.async)
        return Promise.resolve(a.hooks ? a.hooks.preprocess(r) : r).then((c) => s(c, a)).then((c) => a.hooks ? a.hooks.processAllTokens(c) : c).then((c) => a.walkTokens ? Promise.all(this.walkTokens(c, a.walkTokens)).then(() => c) : c).then((c) => l(c, a)).then((c) => a.hooks ? a.hooks.postprocess(c) : c).catch(o);
      try {
        a.hooks && (r = a.hooks.preprocess(r));
        let c = s(r, a);
        a.hooks && (c = a.hooks.processAllTokens(c)), a.walkTokens && this.walkTokens(c, a.walkTokens);
        let h = l(c, a);
        return a.hooks && (h = a.hooks.postprocess(h)), h;
      } catch (c) {
        return o(c);
      }
    };
  }
  onError(e, t) {
    return (r) => {
      if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
        const i = "<p>An error occurred:</p><pre>" + Zt(r.message + "", !0) + "</pre>";
        return t ? Promise.resolve(i) : i;
      }
      if (t)
        return Promise.reject(r);
      throw r;
    };
  }
}, je = new R_();
function at(e, t) {
  return je.parse(e, t);
}
at.options = at.setOptions = function(e) {
  return je.setOptions(e), at.defaults = je.defaults, nf(at.defaults), at;
};
at.getDefaults = Xs;
at.defaults = Ze;
at.use = function(...e) {
  return je.use(...e), at.defaults = je.defaults, nf(at.defaults), at;
};
at.walkTokens = function(e, t) {
  return je.walkTokens(e, t);
};
at.parseInline = je.parseInline;
at.Parser = he;
at.parser = he.parse;
at.Renderer = yn;
at.TextRenderer = ro;
at.Lexer = ce;
at.lexer = ce.lex;
at.Tokenizer = mn;
at.Hooks = Ii;
at.parse = at;
at.options;
at.setOptions;
at.use;
at.walkTokens;
at.parseInline;
he.parse;
ce.lex;
function gf(e) {
  for (var t = [], r = 1; r < arguments.length; r++)
    t[r - 1] = arguments[r];
  var i = Array.from(typeof e == "string" ? [e] : e);
  i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
  var n = i.reduce(function(s, l) {
    var c = l.match(/\n([\t ]+|(?!\s).)/g);
    return c ? s.concat(c.map(function(h) {
      var u, f;
      return (f = (u = h.match(/[\t ]/g)) === null || u === void 0 ? void 0 : u.length) !== null && f !== void 0 ? f : 0;
    })) : s;
  }, []);
  if (n.length) {
    var a = new RegExp(`
[	 ]{` + Math.min.apply(Math, n) + "}", "g");
    i = i.map(function(s) {
      return s.replace(a, `
`);
    });
  }
  i[0] = i[0].replace(/^\r?\n/, "");
  var o = i[0];
  return t.forEach(function(s, l) {
    var c = o.match(/(?:^|\n)( *)$/), h = c ? c[1] : "", u = s;
    typeof s == "string" && s.includes(`
`) && (u = String(s).split(`
`).map(function(f, p) {
      return p === 0 ? f : "" + h + f;
    }).join(`
`)), o += u + i[l + 1];
  }), o;
}
var I_ = {
  body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>',
  height: 80,
  width: 80
}, Va = /* @__PURE__ */ new Map(), mf = /* @__PURE__ */ new Map(), P_ = /* @__PURE__ */ d((e) => {
  for (const t of e) {
    if (!t.name)
      throw new Error(
        'Invalid icon loader. Must have a "name" property with non-empty string value.'
      );
    if (F.debug("Registering icon pack:", t.name), "loader" in t)
      mf.set(t.name, t.loader);
    else if ("icons" in t)
      Va.set(t.name, t.icons);
    else
      throw F.error("Invalid icon loader:", t), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
  }
}, "registerIconPacks"), yf = /* @__PURE__ */ d(async (e, t) => {
  const r = NC(e, !0, t !== void 0);
  if (!r)
    throw new Error(`Invalid icon name: ${e}`);
  const i = r.prefix || t;
  if (!i)
    throw new Error(`Icon name must contain a prefix: ${e}`);
  let n = Va.get(i);
  if (!n) {
    const o = mf.get(i);
    if (!o)
      throw new Error(`Icon set not found: ${r.prefix}`);
    try {
      n = { ...await o(), prefix: i }, Va.set(i, n);
    } catch (s) {
      throw F.error(s), new Error(`Failed to load icon set: ${r.prefix}`);
    }
  }
  const a = WC(n, r.name);
  if (!a)
    throw new Error(`Icon not found: ${e}`);
  return a;
}, "getRegisteredIconData"), N_ = /* @__PURE__ */ d(async (e) => {
  try {
    return await yf(e), !0;
  } catch {
    return !1;
  }
}, "isIconAvailable"), yi = /* @__PURE__ */ d(async (e, t, r) => {
  let i;
  try {
    i = await yf(e, t == null ? void 0 : t.fallbackPrefix);
  } catch (o) {
    F.error(o), i = I_;
  }
  const n = VC(i, t);
  return t_(JC(n.body), {
    ...n.attributes,
    ...r
  });
}, "getIconSVG");
function xf(e, { markdownAutoWrap: t }) {
  const i = e.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`), n = gf(i);
  return t === !1 ? n.replace(/ /g, "&nbsp;") : n;
}
d(xf, "preprocessMarkdown");
function bf(e, t = {}) {
  const r = xf(e, t), i = at.lexer(r), n = [[]];
  let a = 0;
  function o(s, l = "normal") {
    s.type === "text" ? s.text.split(`
`).forEach((h, u) => {
      u !== 0 && (a++, n.push([])), h.split(" ").forEach((f) => {
        f = f.replace(/&#39;/g, "'"), f && n[a].push({ content: f, type: l });
      });
    }) : s.type === "strong" || s.type === "em" ? s.tokens.forEach((c) => {
      o(c, s.type);
    }) : s.type === "html" && n[a].push({ content: s.text, type: "normal" });
  }
  return d(o, "processNode"), i.forEach((s) => {
    var l;
    s.type === "paragraph" ? (l = s.tokens) == null || l.forEach((c) => {
      o(c);
    }) : s.type === "html" && n[a].push({ content: s.text, type: "normal" });
  }), n;
}
d(bf, "markdownToLines");
function Cf(e, { markdownAutoWrap: t } = {}) {
  const r = at.lexer(e);
  function i(n) {
    var a, o, s;
    return n.type === "text" ? t === !1 ? n.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : n.text.replace(/\n */g, "<br/>") : n.type === "strong" ? `<strong>${(a = n.tokens) == null ? void 0 : a.map(i).join("")}</strong>` : n.type === "em" ? `<em>${(o = n.tokens) == null ? void 0 : o.map(i).join("")}</em>` : n.type === "paragraph" ? `<p>${(s = n.tokens) == null ? void 0 : s.map(i).join("")}</p>` : n.type === "space" ? "" : n.type === "html" ? `${n.text}` : n.type === "escape" ? n.text : `Unsupported markdown: ${n.type}`;
  }
  return d(i, "output"), r.map(i).join("");
}
d(Cf, "markdownToHTML");
function _f(e) {
  return Intl.Segmenter ? [...new Intl.Segmenter().segment(e)].map((t) => t.segment) : [...e];
}
d(_f, "splitTextToChars");
function wf(e, t) {
  const r = _f(t.content);
  return io(e, [], r, t.type);
}
d(wf, "splitWordToFitWidth");
function io(e, t, r, i) {
  if (r.length === 0)
    return [
      { content: t.join(""), type: i },
      { content: "", type: i }
    ];
  const [n, ...a] = r, o = [...t, n];
  return e([{ content: o.join(""), type: i }]) ? io(e, o, a, i) : (t.length === 0 && n && (t.push(n), r.shift()), [
    { content: t.join(""), type: i },
    { content: r.join(""), type: i }
  ]);
}
d(io, "splitWordToFitWidthRecursion");
function vf(e, t) {
  if (e.some(({ content: r }) => r.includes(`
`)))
    throw new Error("splitLineToFitWidth does not support newlines in the line");
  return xn(e, t);
}
d(vf, "splitLineToFitWidth");
function xn(e, t, r = [], i = []) {
  if (e.length === 0)
    return i.length > 0 && r.push(i), r.length > 0 ? r : [];
  let n = "";
  e[0].content === " " && (n = " ", e.shift());
  const a = e.shift() ?? { content: " ", type: "normal" }, o = [...i];
  if (n !== "" && o.push({ content: n, type: "normal" }), o.push(a), t(o))
    return xn(e, t, r, o);
  if (i.length > 0)
    r.push(i), e.unshift(a);
  else if (a.content) {
    const [s, l] = wf(t, a);
    r.push([s]), l.content && e.unshift(l);
  }
  return xn(e, t, r);
}
d(xn, "splitLineToFitWidthRecursion");
function Za(e, t) {
  t && e.attr("style", t);
}
d(Za, "applyStyle");
async function kf(e, t, r, i, n = !1) {
  const a = e.append("foreignObject");
  a.attr("width", `${10 * r}px`), a.attr("height", `${10 * r}px`);
  const o = a.append("xhtml:div");
  let s = t.label;
  t.label && yr(t.label) && (s = await fs(t.label.replace(kr.lineBreakRegex, `
`), nt()));
  const l = t.isNode ? "nodeLabel" : "edgeLabel", c = o.append("span");
  c.html(s), Za(c, t.labelStyle), c.attr("class", `${l} ${i}`), Za(o, t.labelStyle), o.style("display", "table-cell"), o.style("white-space", "nowrap"), o.style("line-height", "1.5"), o.style("max-width", r + "px"), o.style("text-align", "center"), o.attr("xmlns", "http://www.w3.org/1999/xhtml"), n && o.attr("class", "labelBkg");
  let h = o.node().getBoundingClientRect();
  return h.width === r && (o.style("display", "table"), o.style("white-space", "break-spaces"), o.style("width", r + "px"), h = o.node().getBoundingClientRect()), a.node();
}
d(kf, "addHtmlSpan");
function Yn(e, t, r) {
  return e.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", t * r - 0.1 + "em").attr("dy", r + "em");
}
d(Yn, "createTspan");
function Sf(e, t, r) {
  const i = e.append("text"), n = Yn(i, 1, t);
  Gn(n, r);
  const a = n.node().getComputedTextLength();
  return i.remove(), a;
}
d(Sf, "computeWidthOfText");
function z_(e, t, r) {
  var o;
  const i = e.append("text"), n = Yn(i, 1, t);
  Gn(n, [{ content: r, type: "normal" }]);
  const a = (o = n.node()) == null ? void 0 : o.getBoundingClientRect();
  return a && i.remove(), a;
}
d(z_, "computeDimensionOfText");
function Tf(e, t, r, i = !1) {
  const a = t.append("g"), o = a.insert("rect").attr("class", "background").attr("style", "stroke: none"), s = a.append("text").attr("y", "-10.1");
  let l = 0;
  for (const c of r) {
    const h = /* @__PURE__ */ d((f) => Sf(a, 1.1, f) <= e, "checkWidth"), u = h(c) ? [c] : vf(c, h);
    for (const f of u) {
      const p = Yn(s, l, 1.1);
      Gn(p, f), l++;
    }
  }
  if (i) {
    const c = s.node().getBBox(), h = 2;
    return o.attr("x", c.x - h).attr("y", c.y - h).attr("width", c.width + 2 * h).attr("height", c.height + 2 * h), a.node();
  } else
    return s.node();
}
d(Tf, "createFormattedText");
function Gn(e, t) {
  e.text(""), t.forEach((r, i) => {
    const n = e.append("tspan").attr("font-style", r.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", r.type === "strong" ? "bold" : "normal");
    i === 0 ? n.text(r.content) : n.text(" " + r.content);
  });
}
d(Gn, "updateTextContentAndStyles");
async function Bf(e) {
  const t = [];
  e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (i, n, a) => (t.push(
    (async () => {
      const o = `${n}:${a}`;
      return await N_(o) ? await yi(o, void 0, { class: "label-icon" }) : `<i class='${Mn(i).replace(":", " ")}'></i>`;
    })()
  ), i));
  const r = await Promise.all(t);
  return e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => r.shift() ?? "");
}
d(Bf, "replaceIconSubstring");
var Le = /* @__PURE__ */ d(async (e, t = "", {
  style: r = "",
  isTitle: i = !1,
  classes: n = "",
  useHtmlLabels: a = !0,
  isNode: o = !0,
  width: s = 200,
  addSvgBackground: l = !1
} = {}, c) => {
  if (F.debug(
    "XYZ createText",
    t,
    r,
    i,
    n,
    a,
    o,
    "addSvgBackground: ",
    l
  ), a) {
    const h = Cf(t, c), u = await Bf(Ve(h)), f = t.replace(/\\\\/g, "\\"), p = {
      isNode: o,
      label: yr(t) ? f : u,
      labelStyle: r.replace("fill:", "color:")
    };
    return await kf(e, p, s, n, l);
  } else {
    const h = t.replace(/<br\s*\/?>/g, "<br/>"), u = bf(h.replace("<br>", "<br/>"), c), f = Tf(
      s,
      e,
      u,
      t ? l : !1
    );
    if (o) {
      /stroke:/.exec(r) && (r = r.replace("stroke:", "lineColor:"));
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      et(f).attr("style", p);
    } else {
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
      et(f).select("rect").attr("style", p.replace(/background:/g, "fill:"));
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      et(f).select("text").attr("style", g);
    }
    return f;
  }
}, "createText");
function sa(e, t, r) {
  if (e && e.length) {
    const [i, n] = t, a = Math.PI / 180 * r, o = Math.cos(a), s = Math.sin(a);
    for (const l of e) {
      const [c, h] = l;
      l[0] = (c - i) * o - (h - n) * s + i, l[1] = (c - i) * s + (h - n) * o + n;
    }
  }
}
function q_(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}
function W_(e, t, r, i = 1) {
  const n = r, a = Math.max(t, 0.1), o = e[0] && e[0][0] && typeof e[0][0] == "number" ? [e] : e, s = [0, 0];
  if (n) for (const c of o) sa(c, s, n);
  const l = function(c, h, u) {
    const f = [];
    for (const b of c) {
      const _ = [...b];
      q_(_[0], _[_.length - 1]) || _.push([_[0][0], _[0][1]]), _.length > 2 && f.push(_);
    }
    const p = [];
    h = Math.max(h, 0.1);
    const g = [];
    for (const b of f) for (let _ = 0; _ < b.length - 1; _++) {
      const S = b[_], w = b[_ + 1];
      if (S[1] !== w[1]) {
        const C = Math.min(S[1], w[1]);
        g.push({ ymin: C, ymax: Math.max(S[1], w[1]), x: C === S[1] ? S[0] : w[0], islope: (w[0] - S[0]) / (w[1] - S[1]) });
      }
    }
    if (g.sort((b, _) => b.ymin < _.ymin ? -1 : b.ymin > _.ymin ? 1 : b.x < _.x ? -1 : b.x > _.x ? 1 : b.ymax === _.ymax ? 0 : (b.ymax - _.ymax) / Math.abs(b.ymax - _.ymax)), !g.length) return p;
    let m = [], y = g[0].ymin, x = 0;
    for (; m.length || g.length; ) {
      if (g.length) {
        let b = -1;
        for (let _ = 0; _ < g.length && !(g[_].ymin > y); _++) b = _;
        g.splice(0, b + 1).forEach((_) => {
          m.push({ s: y, edge: _ });
        });
      }
      if (m = m.filter((b) => !(b.edge.ymax <= y)), m.sort((b, _) => b.edge.x === _.edge.x ? 0 : (b.edge.x - _.edge.x) / Math.abs(b.edge.x - _.edge.x)), (u !== 1 || x % h == 0) && m.length > 1) for (let b = 0; b < m.length; b += 2) {
        const _ = b + 1;
        if (_ >= m.length) break;
        const S = m[b].edge, w = m[_].edge;
        p.push([[Math.round(S.x), y], [Math.round(w.x), y]]);
      }
      y += u, m.forEach((b) => {
        b.edge.x = b.edge.x + u * b.edge.islope;
      }), x++;
    }
    return p;
  }(o, a, i);
  if (n) {
    for (const c of o) sa(c, s, -n);
    (function(c, h, u) {
      const f = [];
      c.forEach((p) => f.push(...p)), sa(f, h, u);
    })(l, s, -n);
  }
  return l;
}
function xi(e, t) {
  var r;
  const i = t.hachureAngle + 90;
  let n = t.hachureGap;
  n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, 0.1));
  let a = 1;
  return t.roughness >= 1 && (((r = t.randomizer) === null || r === void 0 ? void 0 : r.next()) || Math.random()) > 0.7 && (a = n), W_(e, n, i, a || 1);
}
class no {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    return this._fillPolygons(t, r);
  }
  _fillPolygons(t, r) {
    const i = xi(t, r);
    return { type: "fillSketch", ops: this.renderLines(i, r) };
  }
  renderLines(t, r) {
    const i = [];
    for (const n of t) i.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], r));
    return i;
  }
}
function Un(e) {
  const t = e[0], r = e[1];
  return Math.sqrt(Math.pow(t[0] - r[0], 2) + Math.pow(t[1] - r[1], 2));
}
class H_ extends no {
  fillPolygons(t, r) {
    let i = r.hachureGap;
    i < 0 && (i = 4 * r.strokeWidth), i = Math.max(i, 0.1);
    const n = xi(t, Object.assign({}, r, { hachureGap: i })), a = Math.PI / 180 * r.hachureAngle, o = [], s = 0.5 * i * Math.cos(a), l = 0.5 * i * Math.sin(a);
    for (const [c, h] of n) Un([c, h]) && o.push([[c[0] - s, c[1] + l], [...h]], [[c[0] + s, c[1] - l], [...h]]);
    return { type: "fillSketch", ops: this.renderLines(o, r) };
  }
}
class j_ extends no {
  fillPolygons(t, r) {
    const i = this._fillPolygons(t, r), n = Object.assign({}, r, { hachureAngle: r.hachureAngle + 90 }), a = this._fillPolygons(t, n);
    return i.ops = i.ops.concat(a.ops), i;
  }
}
class Y_ {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = xi(t, r = Object.assign({}, r, { hachureAngle: 0 }));
    return this.dotsOnLines(i, r);
  }
  dotsOnLines(t, r) {
    const i = [];
    let n = r.hachureGap;
    n < 0 && (n = 4 * r.strokeWidth), n = Math.max(n, 0.1);
    let a = r.fillWeight;
    a < 0 && (a = r.strokeWidth / 2);
    const o = n / 4;
    for (const s of t) {
      const l = Un(s), c = l / n, h = Math.ceil(c) - 1, u = l - h * n, f = (s[0][0] + s[1][0]) / 2 - n / 4, p = Math.min(s[0][1], s[1][1]);
      for (let g = 0; g < h; g++) {
        const m = p + u + g * n, y = f - o + 2 * Math.random() * o, x = m - o + 2 * Math.random() * o, b = this.helper.ellipse(y, x, a, a, r);
        i.push(...b.ops);
      }
    }
    return { type: "fillSketch", ops: i };
  }
}
class G_ {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = xi(t, r);
    return { type: "fillSketch", ops: this.dashedLine(i, r) };
  }
  dashedLine(t, r) {
    const i = r.dashOffset < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashOffset, n = r.dashGap < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashGap, a = [];
    return t.forEach((o) => {
      const s = Un(o), l = Math.floor(s / (i + n)), c = (s + n - l * (i + n)) / 2;
      let h = o[0], u = o[1];
      h[0] > u[0] && (h = o[1], u = o[0]);
      const f = Math.atan((u[1] - h[1]) / (u[0] - h[0]));
      for (let p = 0; p < l; p++) {
        const g = p * (i + n), m = g + i, y = [h[0] + g * Math.cos(f) + c * Math.cos(f), h[1] + g * Math.sin(f) + c * Math.sin(f)], x = [h[0] + m * Math.cos(f) + c * Math.cos(f), h[1] + m * Math.sin(f) + c * Math.sin(f)];
        a.push(...this.helper.doubleLineOps(y[0], y[1], x[0], x[1], r));
      }
    }), a;
  }
}
class U_ {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap, n = r.zigzagOffset < 0 ? i : r.zigzagOffset, a = xi(t, r = Object.assign({}, r, { hachureGap: i + n }));
    return { type: "fillSketch", ops: this.zigzagLines(a, n, r) };
  }
  zigzagLines(t, r, i) {
    const n = [];
    return t.forEach((a) => {
      const o = Un(a), s = Math.round(o / (2 * r));
      let l = a[0], c = a[1];
      l[0] > c[0] && (l = a[1], c = a[0]);
      const h = Math.atan((c[1] - l[1]) / (c[0] - l[0]));
      for (let u = 0; u < s; u++) {
        const f = 2 * u * r, p = 2 * (u + 1) * r, g = Math.sqrt(2 * Math.pow(r, 2)), m = [l[0] + f * Math.cos(h), l[1] + f * Math.sin(h)], y = [l[0] + p * Math.cos(h), l[1] + p * Math.sin(h)], x = [m[0] + g * Math.cos(h + Math.PI / 4), m[1] + g * Math.sin(h + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(m[0], m[1], x[0], x[1], i), ...this.helper.doubleLineOps(x[0], x[1], y[0], y[1], i));
      }
    }), n;
  }
}
const Ot = {};
class X_ {
  constructor(t) {
    this.seed = t;
  }
  next() {
    return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
  }
}
const V_ = 0, oa = 1, fl = 2, Si = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function la(e, t) {
  return e.type === t;
}
function ao(e) {
  const t = [], r = function(o) {
    const s = new Array();
    for (; o !== ""; ) if (o.match(/^([ \t\r\n,]+)/)) o = o.substr(RegExp.$1.length);
    else if (o.match(/^([aAcChHlLmMqQsStTvVzZ])/)) s[s.length] = { type: V_, text: RegExp.$1 }, o = o.substr(RegExp.$1.length);
    else {
      if (!o.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/)) return [];
      s[s.length] = { type: oa, text: `${parseFloat(RegExp.$1)}` }, o = o.substr(RegExp.$1.length);
    }
    return s[s.length] = { type: fl, text: "" }, s;
  }(e);
  let i = "BOD", n = 0, a = r[n];
  for (; !la(a, fl); ) {
    let o = 0;
    const s = [];
    if (i === "BOD") {
      if (a.text !== "M" && a.text !== "m") return ao("M0,0" + e);
      n++, o = Si[a.text], i = a.text;
    } else la(a, oa) ? o = Si[i] : (n++, o = Si[a.text], i = a.text);
    if (!(n + o < r.length)) throw new Error("Path data ended short");
    for (let l = n; l < n + o; l++) {
      const c = r[l];
      if (!la(c, oa)) throw new Error("Param not a number: " + i + "," + c.text);
      s[s.length] = +c.text;
    }
    if (typeof Si[i] != "number") throw new Error("Bad segment: " + i);
    {
      const l = { key: i, data: s };
      t.push(l), n += o, a = r[n], i === "M" && (i = "L"), i === "m" && (i = "l");
    }
  }
  return t;
}
function Lf(e) {
  let t = 0, r = 0, i = 0, n = 0;
  const a = [];
  for (const { key: o, data: s } of e) switch (o) {
    case "M":
      a.push({ key: "M", data: [...s] }), [t, r] = s, [i, n] = s;
      break;
    case "m":
      t += s[0], r += s[1], a.push({ key: "M", data: [t, r] }), i = t, n = r;
      break;
    case "L":
      a.push({ key: "L", data: [...s] }), [t, r] = s;
      break;
    case "l":
      t += s[0], r += s[1], a.push({ key: "L", data: [t, r] });
      break;
    case "C":
      a.push({ key: "C", data: [...s] }), t = s[4], r = s[5];
      break;
    case "c": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "C", data: l }), t = l[4], r = l[5];
      break;
    }
    case "Q":
      a.push({ key: "Q", data: [...s] }), t = s[2], r = s[3];
      break;
    case "q": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "Q", data: l }), t = l[2], r = l[3];
      break;
    }
    case "A":
      a.push({ key: "A", data: [...s] }), t = s[5], r = s[6];
      break;
    case "a":
      t += s[5], r += s[6], a.push({ key: "A", data: [s[0], s[1], s[2], s[3], s[4], t, r] });
      break;
    case "H":
      a.push({ key: "H", data: [...s] }), t = s[0];
      break;
    case "h":
      t += s[0], a.push({ key: "H", data: [t] });
      break;
    case "V":
      a.push({ key: "V", data: [...s] }), r = s[0];
      break;
    case "v":
      r += s[0], a.push({ key: "V", data: [r] });
      break;
    case "S":
      a.push({ key: "S", data: [...s] }), t = s[2], r = s[3];
      break;
    case "s": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "S", data: l }), t = l[2], r = l[3];
      break;
    }
    case "T":
      a.push({ key: "T", data: [...s] }), t = s[0], r = s[1];
      break;
    case "t":
      t += s[0], r += s[1], a.push({ key: "T", data: [t, r] });
      break;
    case "Z":
    case "z":
      a.push({ key: "Z", data: [] }), t = i, r = n;
  }
  return a;
}
function Mf(e) {
  const t = [];
  let r = "", i = 0, n = 0, a = 0, o = 0, s = 0, l = 0;
  for (const { key: c, data: h } of e) {
    switch (c) {
      case "M":
        t.push({ key: "M", data: [...h] }), [i, n] = h, [a, o] = h;
        break;
      case "C":
        t.push({ key: "C", data: [...h] }), i = h[4], n = h[5], s = h[2], l = h[3];
        break;
      case "L":
        t.push({ key: "L", data: [...h] }), [i, n] = h;
        break;
      case "H":
        i = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "V":
        n = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "S": {
        let u = 0, f = 0;
        r === "C" || r === "S" ? (u = i + (i - s), f = n + (n - l)) : (u = i, f = n), t.push({ key: "C", data: [u, f, ...h] }), s = h[0], l = h[1], i = h[2], n = h[3];
        break;
      }
      case "T": {
        const [u, f] = h;
        let p = 0, g = 0;
        r === "Q" || r === "T" ? (p = i + (i - s), g = n + (n - l)) : (p = i, g = n);
        const m = i + 2 * (p - i) / 3, y = n + 2 * (g - n) / 3, x = u + 2 * (p - u) / 3, b = f + 2 * (g - f) / 3;
        t.push({ key: "C", data: [m, y, x, b, u, f] }), s = p, l = g, i = u, n = f;
        break;
      }
      case "Q": {
        const [u, f, p, g] = h, m = i + 2 * (u - i) / 3, y = n + 2 * (f - n) / 3, x = p + 2 * (u - p) / 3, b = g + 2 * (f - g) / 3;
        t.push({ key: "C", data: [m, y, x, b, p, g] }), s = u, l = f, i = p, n = g;
        break;
      }
      case "A": {
        const u = Math.abs(h[0]), f = Math.abs(h[1]), p = h[2], g = h[3], m = h[4], y = h[5], x = h[6];
        u === 0 || f === 0 ? (t.push({ key: "C", data: [i, n, y, x, y, x] }), i = y, n = x) : (i !== y || n !== x) && (Af(i, n, y, x, u, f, p, g, m).forEach(function(b) {
          t.push({ key: "C", data: b });
        }), i = y, n = x);
        break;
      }
      case "Z":
        t.push({ key: "Z", data: [] }), i = a, n = o;
    }
    r = c;
  }
  return t;
}
function Dr(e, t, r) {
  return [e * Math.cos(r) - t * Math.sin(r), e * Math.sin(r) + t * Math.cos(r)];
}
function Af(e, t, r, i, n, a, o, s, l, c) {
  const h = (u = o, Math.PI * u / 180);
  var u;
  let f = [], p = 0, g = 0, m = 0, y = 0;
  if (c) [p, g, m, y] = c;
  else {
    [e, t] = Dr(e, t, -h), [r, i] = Dr(r, i, -h);
    const O = (e - r) / 2, B = (t - i) / 2;
    let M = O * O / (n * n) + B * B / (a * a);
    M > 1 && (M = Math.sqrt(M), n *= M, a *= M);
    const T = n * n, $ = a * a, L = T * $ - T * B * B - $ * O * O, N = T * B * B + $ * O * O, U = (s === l ? -1 : 1) * Math.sqrt(Math.abs(L / N));
    m = U * n * B / a + (e + r) / 2, y = U * -a * O / n + (t + i) / 2, p = Math.asin(parseFloat(((t - y) / a).toFixed(9))), g = Math.asin(parseFloat(((i - y) / a).toFixed(9))), e < m && (p = Math.PI - p), r < m && (g = Math.PI - g), p < 0 && (p = 2 * Math.PI + p), g < 0 && (g = 2 * Math.PI + g), l && p > g && (p -= 2 * Math.PI), !l && g > p && (g -= 2 * Math.PI);
  }
  let x = g - p;
  if (Math.abs(x) > 120 * Math.PI / 180) {
    const O = g, B = r, M = i;
    g = l && g > p ? p + 120 * Math.PI / 180 * 1 : p + 120 * Math.PI / 180 * -1, f = Af(r = m + n * Math.cos(g), i = y + a * Math.sin(g), B, M, n, a, o, 0, l, [g, O, m, y]);
  }
  x = g - p;
  const b = Math.cos(p), _ = Math.sin(p), S = Math.cos(g), w = Math.sin(g), C = Math.tan(x / 4), v = 4 / 3 * n * C, D = 4 / 3 * a * C, R = [e, t], E = [e + v * _, t - D * b], A = [r + v * w, i - D * S], P = [r, i];
  if (E[0] = 2 * R[0] - E[0], E[1] = 2 * R[1] - E[1], c) return [E, A, P].concat(f);
  {
    f = [E, A, P].concat(f);
    const O = [];
    for (let B = 0; B < f.length; B += 3) {
      const M = Dr(f[B][0], f[B][1], h), T = Dr(f[B + 1][0], f[B + 1][1], h), $ = Dr(f[B + 2][0], f[B + 2][1], h);
      O.push([M[0], M[1], T[0], T[1], $[0], $[1]]);
    }
    return O;
  }
}
const Z_ = { randOffset: function(e, t) {
  return V(e, t);
}, randOffsetWithRange: function(e, t, r) {
  return bn(e, t, r);
}, ellipse: function(e, t, r, i, n) {
  const a = Ff(r, i, n);
  return Ka(e, t, n, a).opset;
}, doubleLineOps: function(e, t, r, i, n) {
  return Se(e, t, r, i, n, !0);
} };
function $f(e, t, r, i, n) {
  return { type: "path", ops: Se(e, t, r, i, n) };
}
function Pi(e, t, r) {
  const i = (e || []).length;
  if (i > 2) {
    const n = [];
    for (let a = 0; a < i - 1; a++) n.push(...Se(e[a][0], e[a][1], e[a + 1][0], e[a + 1][1], r));
    return t && n.push(...Se(e[i - 1][0], e[i - 1][1], e[0][0], e[0][1], r)), { type: "path", ops: n };
  }
  return i === 2 ? $f(e[0][0], e[0][1], e[1][0], e[1][1], r) : { type: "path", ops: [] };
}
function K_(e, t, r, i, n) {
  return function(a, o) {
    return Pi(a, !0, o);
  }([[e, t], [e + r, t], [e + r, t + i], [e, t + i]], n);
}
function pl(e, t) {
  if (e.length) {
    const r = typeof e[0][0] == "number" ? [e] : e, i = Ti(r[0], 1 * (1 + 0.2 * t.roughness), t), n = t.disableMultiStroke ? [] : Ti(r[0], 1.5 * (1 + 0.22 * t.roughness), ml(t));
    for (let a = 1; a < r.length; a++) {
      const o = r[a];
      if (o.length) {
        const s = Ti(o, 1 * (1 + 0.2 * t.roughness), t), l = t.disableMultiStroke ? [] : Ti(o, 1.5 * (1 + 0.22 * t.roughness), ml(t));
        for (const c of s) c.op !== "move" && i.push(c);
        for (const c of l) c.op !== "move" && n.push(c);
      }
    }
    return { type: "path", ops: i.concat(n) };
  }
  return { type: "path", ops: [] };
}
function Ff(e, t, r) {
  const i = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(e / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(r.curveStepCount, r.curveStepCount / Math.sqrt(200) * i)), a = 2 * Math.PI / n;
  let o = Math.abs(e / 2), s = Math.abs(t / 2);
  const l = 1 - r.curveFitting;
  return o += V(o * l, r), s += V(s * l, r), { increment: a, rx: o, ry: s };
}
function Ka(e, t, r, i) {
  const [n, a] = yl(i.increment, e, t, i.rx, i.ry, 1, i.increment * bn(0.1, bn(0.4, 1, r), r), r);
  let o = Cn(n, null, r);
  if (!r.disableMultiStroke && r.roughness !== 0) {
    const [s] = yl(i.increment, e, t, i.rx, i.ry, 1.5, 0, r), l = Cn(s, null, r);
    o = o.concat(l);
  }
  return { estimatedPoints: a, opset: { type: "path", ops: o } };
}
function dl(e, t, r, i, n, a, o, s, l) {
  const c = e, h = t;
  let u = Math.abs(r / 2), f = Math.abs(i / 2);
  u += V(0.01 * u, l), f += V(0.01 * f, l);
  let p = n, g = a;
  for (; p < 0; ) p += 2 * Math.PI, g += 2 * Math.PI;
  g - p > 2 * Math.PI && (p = 0, g = 2 * Math.PI);
  const m = 2 * Math.PI / l.curveStepCount, y = Math.min(m / 2, (g - p) / 2), x = xl(y, c, h, u, f, p, g, 1, l);
  if (!l.disableMultiStroke) {
    const b = xl(y, c, h, u, f, p, g, 1.5, l);
    x.push(...b);
  }
  return o && (s ? x.push(...Se(c, h, c + u * Math.cos(p), h + f * Math.sin(p), l), ...Se(c, h, c + u * Math.cos(g), h + f * Math.sin(g), l)) : x.push({ op: "lineTo", data: [c, h] }, { op: "lineTo", data: [c + u * Math.cos(p), h + f * Math.sin(p)] })), { type: "path", ops: x };
}
function gl(e, t) {
  const r = Mf(Lf(ao(e))), i = [];
  let n = [0, 0], a = [0, 0];
  for (const { key: o, data: s } of r) switch (o) {
    case "M":
      a = [s[0], s[1]], n = [s[0], s[1]];
      break;
    case "L":
      i.push(...Se(a[0], a[1], s[0], s[1], t)), a = [s[0], s[1]];
      break;
    case "C": {
      const [l, c, h, u, f, p] = s;
      i.push(...Q_(l, c, h, u, f, p, a, t)), a = [f, p];
      break;
    }
    case "Z":
      i.push(...Se(a[0], a[1], n[0], n[1], t)), a = [n[0], n[1]];
  }
  return { type: "path", ops: i };
}
function ca(e, t) {
  const r = [];
  for (const i of e) if (i.length) {
    const n = t.maxRandomnessOffset || 0, a = i.length;
    if (a > 2) {
      r.push({ op: "move", data: [i[0][0] + V(n, t), i[0][1] + V(n, t)] });
      for (let o = 1; o < a; o++) r.push({ op: "lineTo", data: [i[o][0] + V(n, t), i[o][1] + V(n, t)] });
    }
  }
  return { type: "fillPath", ops: r };
}
function Qe(e, t) {
  return function(r, i) {
    let n = r.fillStyle || "hachure";
    if (!Ot[n]) switch (n) {
      case "zigzag":
        Ot[n] || (Ot[n] = new H_(i));
        break;
      case "cross-hatch":
        Ot[n] || (Ot[n] = new j_(i));
        break;
      case "dots":
        Ot[n] || (Ot[n] = new Y_(i));
        break;
      case "dashed":
        Ot[n] || (Ot[n] = new G_(i));
        break;
      case "zigzag-line":
        Ot[n] || (Ot[n] = new U_(i));
        break;
      default:
        n = "hachure", Ot[n] || (Ot[n] = new no(i));
    }
    return Ot[n];
  }(t, Z_).fillPolygons(e, t);
}
function ml(e) {
  const t = Object.assign({}, e);
  return t.randomizer = void 0, e.seed && (t.seed = e.seed + 1), t;
}
function Ef(e) {
  return e.randomizer || (e.randomizer = new X_(e.seed || 0)), e.randomizer.next();
}
function bn(e, t, r, i = 1) {
  return r.roughness * i * (Ef(r) * (t - e) + e);
}
function V(e, t, r = 1) {
  return bn(-e, e, t, r);
}
function Se(e, t, r, i, n, a = !1) {
  const o = a ? n.disableMultiStrokeFill : n.disableMultiStroke, s = Qa(e, t, r, i, n, !0, !1);
  if (o) return s;
  const l = Qa(e, t, r, i, n, !0, !0);
  return s.concat(l);
}
function Qa(e, t, r, i, n, a, o) {
  const s = Math.pow(e - r, 2) + Math.pow(t - i, 2), l = Math.sqrt(s);
  let c = 1;
  c = l < 200 ? 1 : l > 500 ? 0.4 : -16668e-7 * l + 1.233334;
  let h = n.maxRandomnessOffset || 0;
  h * h * 100 > s && (h = l / 10);
  const u = h / 2, f = 0.2 + 0.2 * Ef(n);
  let p = n.bowing * n.maxRandomnessOffset * (i - t) / 200, g = n.bowing * n.maxRandomnessOffset * (e - r) / 200;
  p = V(p, n, c), g = V(g, n, c);
  const m = [], y = () => V(u, n, c), x = () => V(h, n, c), b = n.preserveVertices;
  return o ? m.push({ op: "move", data: [e + (b ? 0 : y()), t + (b ? 0 : y())] }) : m.push({ op: "move", data: [e + (b ? 0 : V(h, n, c)), t + (b ? 0 : V(h, n, c))] }), o ? m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + y(), g + t + (i - t) * f + y(), p + e + 2 * (r - e) * f + y(), g + t + 2 * (i - t) * f + y(), r + (b ? 0 : y()), i + (b ? 0 : y())] }) : m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + x(), g + t + (i - t) * f + x(), p + e + 2 * (r - e) * f + x(), g + t + 2 * (i - t) * f + x(), r + (b ? 0 : x()), i + (b ? 0 : x())] }), m;
}
function Ti(e, t, r) {
  if (!e.length) return [];
  const i = [];
  i.push([e[0][0] + V(t, r), e[0][1] + V(t, r)]), i.push([e[0][0] + V(t, r), e[0][1] + V(t, r)]);
  for (let n = 1; n < e.length; n++) i.push([e[n][0] + V(t, r), e[n][1] + V(t, r)]), n === e.length - 1 && i.push([e[n][0] + V(t, r), e[n][1] + V(t, r)]);
  return Cn(i, null, r);
}
function Cn(e, t, r) {
  const i = e.length, n = [];
  if (i > 3) {
    const a = [], o = 1 - r.curveTightness;
    n.push({ op: "move", data: [e[1][0], e[1][1]] });
    for (let s = 1; s + 2 < i; s++) {
      const l = e[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * e[s + 1][0] - o * e[s - 1][0]) / 6, l[1] + (o * e[s + 1][1] - o * e[s - 1][1]) / 6], a[2] = [e[s + 1][0] + (o * e[s][0] - o * e[s + 2][0]) / 6, e[s + 1][1] + (o * e[s][1] - o * e[s + 2][1]) / 6], a[3] = [e[s + 1][0], e[s + 1][1]], n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[3][0], a[3][1]] });
    }
  } else i === 3 ? (n.push({ op: "move", data: [e[1][0], e[1][1]] }), n.push({ op: "bcurveTo", data: [e[1][0], e[1][1], e[2][0], e[2][1], e[2][0], e[2][1]] })) : i === 2 && n.push(...Qa(e[0][0], e[0][1], e[1][0], e[1][1], r, !0, !0));
  return n;
}
function yl(e, t, r, i, n, a, o, s) {
  const l = [], c = [];
  if (s.roughness === 0) {
    e /= 4, c.push([t + i * Math.cos(-e), r + n * Math.sin(-e)]);
    for (let h = 0; h <= 2 * Math.PI; h += e) {
      const u = [t + i * Math.cos(h), r + n * Math.sin(h)];
      l.push(u), c.push(u);
    }
    c.push([t + i * Math.cos(0), r + n * Math.sin(0)]), c.push([t + i * Math.cos(e), r + n * Math.sin(e)]);
  } else {
    const h = V(0.5, s) - Math.PI / 2;
    c.push([V(a, s) + t + 0.9 * i * Math.cos(h - e), V(a, s) + r + 0.9 * n * Math.sin(h - e)]);
    const u = 2 * Math.PI + h - 0.01;
    for (let f = h; f < u; f += e) {
      const p = [V(a, s) + t + i * Math.cos(f), V(a, s) + r + n * Math.sin(f)];
      l.push(p), c.push(p);
    }
    c.push([V(a, s) + t + i * Math.cos(h + 2 * Math.PI + 0.5 * o), V(a, s) + r + n * Math.sin(h + 2 * Math.PI + 0.5 * o)]), c.push([V(a, s) + t + 0.98 * i * Math.cos(h + o), V(a, s) + r + 0.98 * n * Math.sin(h + o)]), c.push([V(a, s) + t + 0.9 * i * Math.cos(h + 0.5 * o), V(a, s) + r + 0.9 * n * Math.sin(h + 0.5 * o)]);
  }
  return [c, l];
}
function xl(e, t, r, i, n, a, o, s, l) {
  const c = a + V(0.1, l), h = [];
  h.push([V(s, l) + t + 0.9 * i * Math.cos(c - e), V(s, l) + r + 0.9 * n * Math.sin(c - e)]);
  for (let u = c; u <= o; u += e) h.push([V(s, l) + t + i * Math.cos(u), V(s, l) + r + n * Math.sin(u)]);
  return h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), Cn(h, null, l);
}
function Q_(e, t, r, i, n, a, o, s) {
  const l = [], c = [s.maxRandomnessOffset || 1, (s.maxRandomnessOffset || 1) + 0.3];
  let h = [0, 0];
  const u = s.disableMultiStroke ? 1 : 2, f = s.preserveVertices;
  for (let p = 0; p < u; p++) p === 0 ? l.push({ op: "move", data: [o[0], o[1]] }) : l.push({ op: "move", data: [o[0] + (f ? 0 : V(c[0], s)), o[1] + (f ? 0 : V(c[0], s))] }), h = f ? [n, a] : [n + V(c[p], s), a + V(c[p], s)], l.push({ op: "bcurveTo", data: [e + V(c[p], s), t + V(c[p], s), r + V(c[p], s), i + V(c[p], s), h[0], h[1]] });
  return l;
}
function Rr(e) {
  return [...e];
}
function bl(e, t = 0) {
  const r = e.length;
  if (r < 3) throw new Error("A curve must have at least three points.");
  const i = [];
  if (r === 3) i.push(Rr(e[0]), Rr(e[1]), Rr(e[2]), Rr(e[2]));
  else {
    const n = [];
    n.push(e[0], e[0]);
    for (let s = 1; s < e.length; s++) n.push(e[s]), s === e.length - 1 && n.push(e[s]);
    const a = [], o = 1 - t;
    i.push(Rr(n[0]));
    for (let s = 1; s + 2 < n.length; s++) {
      const l = n[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * n[s + 1][0] - o * n[s - 1][0]) / 6, l[1] + (o * n[s + 1][1] - o * n[s - 1][1]) / 6], a[2] = [n[s + 1][0] + (o * n[s][0] - o * n[s + 2][0]) / 6, n[s + 1][1] + (o * n[s][1] - o * n[s + 2][1]) / 6], a[3] = [n[s + 1][0], n[s + 1][1]], i.push(a[1], a[2], a[3]);
    }
  }
  return i;
}
function Ni(e, t) {
  return Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2);
}
function J_(e, t, r) {
  const i = Ni(t, r);
  if (i === 0) return Ni(e, t);
  let n = ((e[0] - t[0]) * (r[0] - t[0]) + (e[1] - t[1]) * (r[1] - t[1])) / i;
  return n = Math.max(0, Math.min(1, n)), Ni(e, $e(t, r, n));
}
function $e(e, t, r) {
  return [e[0] + (t[0] - e[0]) * r, e[1] + (t[1] - e[1]) * r];
}
function Ja(e, t, r, i) {
  const n = i || [];
  if (function(s, l) {
    const c = s[l + 0], h = s[l + 1], u = s[l + 2], f = s[l + 3];
    let p = 3 * h[0] - 2 * c[0] - f[0];
    p *= p;
    let g = 3 * h[1] - 2 * c[1] - f[1];
    g *= g;
    let m = 3 * u[0] - 2 * f[0] - c[0];
    m *= m;
    let y = 3 * u[1] - 2 * f[1] - c[1];
    return y *= y, p < m && (p = m), g < y && (g = y), p + g;
  }(e, t) < r) {
    const s = e[t + 0];
    n.length ? (a = n[n.length - 1], o = s, Math.sqrt(Ni(a, o)) > 1 && n.push(s)) : n.push(s), n.push(e[t + 3]);
  } else {
    const l = e[t + 0], c = e[t + 1], h = e[t + 2], u = e[t + 3], f = $e(l, c, 0.5), p = $e(c, h, 0.5), g = $e(h, u, 0.5), m = $e(f, p, 0.5), y = $e(p, g, 0.5), x = $e(m, y, 0.5);
    Ja([l, f, m, x], 0, r, n), Ja([x, y, g, u], 0, r, n);
  }
  var a, o;
  return n;
}
function tw(e, t) {
  return _n(e, 0, e.length, t);
}
function _n(e, t, r, i, n) {
  const a = n || [], o = e[t], s = e[r - 1];
  let l = 0, c = 1;
  for (let h = t + 1; h < r - 1; ++h) {
    const u = J_(e[h], o, s);
    u > l && (l = u, c = h);
  }
  return Math.sqrt(l) > i ? (_n(e, t, c + 1, i, a), _n(e, c, r, i, a)) : (a.length || a.push(o), a.push(s)), a;
}
function ha(e, t = 0.15, r) {
  const i = [], n = (e.length - 1) / 3;
  for (let a = 0; a < n; a++)
    Ja(e, 3 * a, t, i);
  return r && r > 0 ? _n(i, 0, i.length, r) : i;
}
const Nt = "none";
class wn {
  constructor(t) {
    this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: 0.95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: 0.8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
  }
  static newSeed() {
    return Math.floor(Math.random() * 2 ** 31);
  }
  _o(t) {
    return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions;
  }
  _d(t, r, i) {
    return { shape: t, sets: r || [], options: i || this.defaultOptions };
  }
  line(t, r, i, n, a) {
    const o = this._o(a);
    return this._d("line", [$f(t, r, i, n, o)], o);
  }
  rectangle(t, r, i, n, a) {
    const o = this._o(a), s = [], l = K_(t, r, i, n, o);
    if (o.fill) {
      const c = [[t, r], [t + i, r], [t + i, r + n], [t, r + n]];
      o.fillStyle === "solid" ? s.push(ca([c], o)) : s.push(Qe([c], o));
    }
    return o.stroke !== Nt && s.push(l), this._d("rectangle", s, o);
  }
  ellipse(t, r, i, n, a) {
    const o = this._o(a), s = [], l = Ff(i, n, o), c = Ka(t, r, o, l);
    if (o.fill) if (o.fillStyle === "solid") {
      const h = Ka(t, r, o, l).opset;
      h.type = "fillPath", s.push(h);
    } else s.push(Qe([c.estimatedPoints], o));
    return o.stroke !== Nt && s.push(c.opset), this._d("ellipse", s, o);
  }
  circle(t, r, i, n) {
    const a = this.ellipse(t, r, i, i, n);
    return a.shape = "circle", a;
  }
  linearPath(t, r) {
    const i = this._o(r);
    return this._d("linearPath", [Pi(t, !1, i)], i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this._o(l), h = [], u = dl(t, r, i, n, a, o, s, !0, c);
    if (s && c.fill) if (c.fillStyle === "solid") {
      const f = Object.assign({}, c);
      f.disableMultiStroke = !0;
      const p = dl(t, r, i, n, a, o, !0, !1, f);
      p.type = "fillPath", h.push(p);
    } else h.push(function(f, p, g, m, y, x, b) {
      const _ = f, S = p;
      let w = Math.abs(g / 2), C = Math.abs(m / 2);
      w += V(0.01 * w, b), C += V(0.01 * C, b);
      let v = y, D = x;
      for (; v < 0; ) v += 2 * Math.PI, D += 2 * Math.PI;
      D - v > 2 * Math.PI && (v = 0, D = 2 * Math.PI);
      const R = (D - v) / b.curveStepCount, E = [];
      for (let A = v; A <= D; A += R) E.push([_ + w * Math.cos(A), S + C * Math.sin(A)]);
      return E.push([_ + w * Math.cos(D), S + C * Math.sin(D)]), E.push([_, S]), Qe([E], b);
    }(t, r, i, n, a, o, c));
    return c.stroke !== Nt && h.push(u), this._d("arc", h, c);
  }
  curve(t, r) {
    const i = this._o(r), n = [], a = pl(t, i);
    if (i.fill && i.fill !== Nt) if (i.fillStyle === "solid") {
      const o = pl(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(o.ops) });
    } else {
      const o = [], s = t;
      if (s.length) {
        const l = typeof s[0][0] == "number" ? [s] : s;
        for (const c of l) c.length < 3 ? o.push(...c) : c.length === 3 ? o.push(...ha(bl([c[0], c[0], c[1], c[2]]), 10, (1 + i.roughness) / 2)) : o.push(...ha(bl(c), 10, (1 + i.roughness) / 2));
      }
      o.length && n.push(Qe([o], i));
    }
    return i.stroke !== Nt && n.push(a), this._d("curve", n, i);
  }
  polygon(t, r) {
    const i = this._o(r), n = [], a = Pi(t, !0, i);
    return i.fill && (i.fillStyle === "solid" ? n.push(ca([t], i)) : n.push(Qe([t], i))), i.stroke !== Nt && n.push(a), this._d("polygon", n, i);
  }
  path(t, r) {
    const i = this._o(r), n = [];
    if (!t) return this._d("path", n, i);
    t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
    const a = i.fill && i.fill !== "transparent" && i.fill !== Nt, o = i.stroke !== Nt, s = !!(i.simplification && i.simplification < 1), l = function(h, u, f) {
      const p = Mf(Lf(ao(h))), g = [];
      let m = [], y = [0, 0], x = [];
      const b = () => {
        x.length >= 4 && m.push(...ha(x, u)), x = [];
      }, _ = () => {
        b(), m.length && (g.push(m), m = []);
      };
      for (const { key: w, data: C } of p) switch (w) {
        case "M":
          _(), y = [C[0], C[1]], m.push(y);
          break;
        case "L":
          b(), m.push([C[0], C[1]]);
          break;
        case "C":
          if (!x.length) {
            const v = m.length ? m[m.length - 1] : y;
            x.push([v[0], v[1]]);
          }
          x.push([C[0], C[1]]), x.push([C[2], C[3]]), x.push([C[4], C[5]]);
          break;
        case "Z":
          b(), m.push([y[0], y[1]]);
      }
      if (_(), !f) return g;
      const S = [];
      for (const w of g) {
        const C = tw(w, f);
        C.length && S.push(C);
      }
      return S;
    }(t, 1, s ? 4 - 4 * (i.simplification || 1) : (1 + i.roughness) / 2), c = gl(t, i);
    if (a) if (i.fillStyle === "solid") if (l.length === 1) {
      const h = gl(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(h.ops) });
    } else n.push(ca(l, i));
    else n.push(Qe(l, i));
    return o && (s ? l.forEach((h) => {
      n.push(Pi(h, !1, i));
    }) : n.push(c)), this._d("path", n, i);
  }
  opsToPath(t, r) {
    let i = "";
    for (const n of t.ops) {
      const a = typeof r == "number" && r >= 0 ? n.data.map((o) => +o.toFixed(r)) : n.data;
      switch (n.op) {
        case "move":
          i += `M${a[0]} ${a[1]} `;
          break;
        case "bcurveTo":
          i += `C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;
          break;
        case "lineTo":
          i += `L${a[0]} ${a[1]} `;
      }
    }
    return i.trim();
  }
  toPaths(t) {
    const r = t.sets || [], i = t.options || this.defaultOptions, n = [];
    for (const a of r) {
      let o = null;
      switch (a.type) {
        case "path":
          o = { d: this.opsToPath(a), stroke: i.stroke, strokeWidth: i.strokeWidth, fill: Nt };
          break;
        case "fillPath":
          o = { d: this.opsToPath(a), stroke: Nt, strokeWidth: 0, fill: i.fill || Nt };
          break;
        case "fillSketch":
          o = this.fillSketch(a, i);
      }
      o && n.push(o);
    }
    return n;
  }
  fillSketch(t, r) {
    let i = r.fillWeight;
    return i < 0 && (i = r.strokeWidth / 2), { d: this.opsToPath(t), stroke: r.fill || Nt, strokeWidth: i, fill: Nt };
  }
  _mergedShape(t) {
    return t.filter((r, i) => i === 0 || r.op !== "move");
  }
}
class ew {
  constructor(t, r) {
    this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new wn(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.ctx, a = t.options.fixedDecimalPlaceDigits;
    for (const o of r) switch (o.type) {
      case "path":
        n.save(), n.strokeStyle = i.stroke === "none" ? "transparent" : i.stroke, n.lineWidth = i.strokeWidth, i.strokeLineDash && n.setLineDash(i.strokeLineDash), i.strokeLineDashOffset && (n.lineDashOffset = i.strokeLineDashOffset), this._drawToContext(n, o, a), n.restore();
        break;
      case "fillPath": {
        n.save(), n.fillStyle = i.fill || "";
        const s = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
        this._drawToContext(n, o, a, s), n.restore();
        break;
      }
      case "fillSketch":
        this.fillSketch(n, o, i);
    }
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2), t.save(), i.fillLineDash && t.setLineDash(i.fillLineDash), i.fillLineDashOffset && (t.lineDashOffset = i.fillLineDashOffset), t.strokeStyle = i.fill || "", t.lineWidth = n, this._drawToContext(t, r, i.fixedDecimalPlaceDigits), t.restore();
  }
  _drawToContext(t, r, i, n = "nonzero") {
    t.beginPath();
    for (const a of r.ops) {
      const o = typeof i == "number" && i >= 0 ? a.data.map((s) => +s.toFixed(i)) : a.data;
      switch (a.op) {
        case "move":
          t.moveTo(o[0], o[1]);
          break;
        case "bcurveTo":
          t.bezierCurveTo(o[0], o[1], o[2], o[3], o[4], o[5]);
          break;
        case "lineTo":
          t.lineTo(o[0], o[1]);
      }
    }
    r.type === "fillPath" ? t.fill(n) : t.stroke();
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o), o;
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o), o;
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o), o;
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a), a;
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i), i;
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i), i;
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c), c;
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i), i;
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i), i;
  }
}
const Bi = "http://www.w3.org/2000/svg";
class rw {
  constructor(t, r) {
    this.svg = t, this.gen = new wn(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, a = n.createElementNS(Bi, "g"), o = t.options.fixedDecimalPlaceDigits;
    for (const s of r) {
      let l = null;
      switch (s.type) {
        case "path":
          l = n.createElementNS(Bi, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", i.stroke), l.setAttribute("stroke-width", i.strokeWidth + ""), l.setAttribute("fill", "none"), i.strokeLineDash && l.setAttribute("stroke-dasharray", i.strokeLineDash.join(" ").trim()), i.strokeLineDashOffset && l.setAttribute("stroke-dashoffset", `${i.strokeLineDashOffset}`);
          break;
        case "fillPath":
          l = n.createElementNS(Bi, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", "none"), l.setAttribute("stroke-width", "0"), l.setAttribute("fill", i.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || l.setAttribute("fill-rule", "evenodd");
          break;
        case "fillSketch":
          l = this.fillSketch(n, s, i);
      }
      l && a.appendChild(l);
    }
    return a;
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2);
    const a = t.createElementNS(Bi, "path");
    return a.setAttribute("d", this.opsToPath(r, i.fixedDecimalPlaceDigits)), a.setAttribute("stroke", i.fill || ""), a.setAttribute("stroke-width", n + ""), a.setAttribute("fill", "none"), i.fillLineDash && a.setAttribute("stroke-dasharray", i.fillLineDash.join(" ").trim()), i.fillLineDashOffset && a.setAttribute("stroke-dashoffset", `${i.fillLineDashOffset}`), a;
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  opsToPath(t, r) {
    return this.gen.opsToPath(t, r);
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o);
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o);
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o);
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a);
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i);
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c);
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i);
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i);
  }
}
var W = { canvas: (e, t) => new ew(e, t), svg: (e, t) => new rw(e, t), generator: (e) => new wn(e), newSeed: () => wn.newSeed() }, Q = /* @__PURE__ */ d(async (e, t, r) => {
  var u, f;
  let i;
  const n = t.useHtmlLabels || bt((u = nt()) == null ? void 0 : u.htmlLabels);
  r ? i = r : i = "node default";
  const a = e.insert("g").attr("class", i).attr("id", t.domId || t.id), o = a.insert("g").attr("class", "label").attr("style", Et(t.labelStyle));
  let s;
  t.label === void 0 ? s = "" : s = typeof t.label == "string" ? t.label : t.label[0];
  const l = await Le(o, ze(Ve(s), nt()), {
    useHtmlLabels: n,
    width: t.width || ((f = nt().flowchart) == null ? void 0 : f.wrappingWidth),
    // @ts-expect-error -- This is currently not used. Should this be `classes` instead?
    cssClasses: "markdown-node-label",
    style: t.labelStyle,
    addSvgBackground: !!t.icon || !!t.img
  });
  let c = l.getBBox();
  const h = ((t == null ? void 0 : t.padding) ?? 0) / 2;
  if (n) {
    const p = l.children[0], g = et(l), m = p.getElementsByTagName("img");
    if (m) {
      const y = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...m].map(
          (x) => new Promise((b) => {
            function _() {
              if (x.style.display = "flex", x.style.flexDirection = "column", y) {
                const S = nt().fontSize ? nt().fontSize : window.getComputedStyle(document.body).fontSize, w = 5, [C = Yl.fontSize] = Wn(S), v = C * w + "px";
                x.style.minWidth = v, x.style.maxWidth = v;
              } else
                x.style.width = "100%";
              b(x);
            }
            d(_, "setupImage"), setTimeout(() => {
              x.complete && _();
            }), x.addEventListener("error", _), x.addEventListener("load", _);
          })
        )
      );
    }
    c = p.getBoundingClientRect(), g.attr("width", c.width), g.attr("height", c.height);
  }
  return n ? o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")") : o.attr("transform", "translate(0, " + -c.height / 2 + ")"), t.centerLabel && o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")"), o.insert("rect", ":first-child"), { shapeSvg: a, bbox: c, halfPadding: h, label: o };
}, "labelHelper"), ua = /* @__PURE__ */ d(async (e, t, r) => {
  var l, c, h, u, f, p;
  const i = r.useHtmlLabels || bt((c = (l = nt()) == null ? void 0 : l.flowchart) == null ? void 0 : c.htmlLabels), n = e.insert("g").attr("class", "label").attr("style", r.labelStyle || ""), a = await Le(n, ze(Ve(t), nt()), {
    useHtmlLabels: i,
    width: r.width || ((u = (h = nt()) == null ? void 0 : h.flowchart) == null ? void 0 : u.wrappingWidth),
    style: r.labelStyle,
    addSvgBackground: !!r.icon || !!r.img
  });
  let o = a.getBBox();
  const s = r.padding / 2;
  if (bt((p = (f = nt()) == null ? void 0 : f.flowchart) == null ? void 0 : p.htmlLabels)) {
    const g = a.children[0], m = et(a);
    o = g.getBoundingClientRect(), m.attr("width", o.width), m.attr("height", o.height);
  }
  return i ? n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")") : n.attr("transform", "translate(0, " + -o.height / 2 + ")"), r.centerLabel && n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), n.insert("rect", ":first-child"), { shapeSvg: e, bbox: o, halfPadding: s, label: n };
}, "insertLabel"), j = /* @__PURE__ */ d((e, t) => {
  const r = t.node().getBBox();
  e.width = r.width, e.height = r.height;
}, "updateNodeBounds"), Z = /* @__PURE__ */ d((e, t) => (e.look === "handDrawn" ? "rough-node" : "node") + " " + e.cssClasses + " " + (t || ""), "getNodeClasses");
function rt(e) {
  const t = e.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`);
  return t.push("Z"), t.join(" ");
}
d(rt, "createPathFromPoints");
function Te(e, t, r, i, n, a) {
  const o = [], l = r - e, c = i - t, h = l / a, u = 2 * Math.PI / h, f = t + c / 2;
  for (let p = 0; p <= 50; p++) {
    const g = p / 50, m = e + g * l, y = f + n * Math.sin(u * (m - e));
    o.push({ x: m, y });
  }
  return o;
}
d(Te, "generateFullSineWavePoints");
function so(e, t, r, i, n, a) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(so, "generateCirclePoints");
var iw = /* @__PURE__ */ d((e, t) => {
  var r = e.x, i = e.y, n = t.x - r, a = t.y - i, o = e.width / 2, s = e.height / 2, l, c;
  return Math.abs(a) * o > Math.abs(n) * s ? (a < 0 && (s = -s), l = a === 0 ? 0 : s * n / a, c = s) : (n < 0 && (o = -o), l = o, c = n === 0 ? 0 : o * a / n), { x: r + l, y: i + c };
}, "intersectRect"), Br = iw;
function Of(e, t) {
  t && e.attr("style", t);
}
d(Of, "applyStyle");
async function Df(e) {
  const t = et(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")), r = t.append("xhtml:div");
  let i = e.label;
  e.label && yr(e.label) && (i = await fs(e.label.replace(kr.lineBreakRegex, `
`), nt()));
  const n = e.isNode ? "nodeLabel" : "edgeLabel";
  return r.html(
    '<span class="' + n + '" ' + (e.labelStyle ? 'style="' + e.labelStyle + '"' : "") + // codeql [js/html-constructed-from-input] : false positive
    ">" + i + "</span>"
  ), Of(r, e.labelStyle), r.style("display", "inline-block"), r.style("padding-right", "1px"), r.style("white-space", "nowrap"), r.attr("xmlns", "http://www.w3.org/1999/xhtml"), t.node();
}
d(Df, "addHtmlLabel");
var nw = /* @__PURE__ */ d(async (e, t, r, i) => {
  let n = e || "";
  if (typeof n == "object" && (n = n[0]), bt(nt().flowchart.htmlLabels)) {
    n = n.replace(/\\n|\n/g, "<br />"), F.info("vertexText" + n);
    const a = {
      isNode: i,
      label: Ve(n).replace(
        /fa[blrs]?:fa-[\w-]+/g,
        (s) => `<i class='${s.replace(":", " ")}'></i>`
      ),
      labelStyle: t && t.replace("fill:", "color:")
    };
    return await Df(a);
  } else {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "text");
    a.setAttribute("style", t.replace("color:", "fill:"));
    let o = [];
    typeof n == "string" ? o = n.split(/\\n|\n|<br\s*\/?>/gi) : Array.isArray(n) ? o = n : o = [];
    for (const s of o) {
      const l = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      l.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), l.setAttribute("dy", "1em"), l.setAttribute("x", "0"), r ? l.setAttribute("class", "title-row") : l.setAttribute("class", "row"), l.textContent = s.trim(), a.appendChild(l);
    }
    return a;
  }
}, "createLabel"), Ie = nw, me = /* @__PURE__ */ d((e, t, r, i, n) => [
  "M",
  e + n,
  t,
  // Move to the first point
  "H",
  e + r - n,
  // Draw horizontal line to the beginning of the right corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r,
  t + n,
  // Draw arc to the right top corner
  "V",
  t + i - n,
  // Draw vertical line down to the beginning of the right bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r - n,
  t + i,
  // Draw arc to the right bottom corner
  "H",
  e + n,
  // Draw horizontal line to the beginning of the left bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e,
  t + i - n,
  // Draw arc to the left bottom corner
  "V",
  t + n,
  // Draw vertical line up to the beginning of the left top corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + n,
  t,
  // Draw arc to the left top corner
  "Z"
  // Close the path
].join(" "), "createRoundedRectPathD"), aw = /* @__PURE__ */ d((e) => {
  const { handDrawnSeed: t } = nt();
  return {
    fill: e,
    hachureAngle: 120,
    // angle of hachure,
    hachureGap: 4,
    fillWeight: 2,
    roughness: 0.7,
    stroke: e,
    seed: t
  };
}, "solidStateFill"), Lr = /* @__PURE__ */ d((e) => {
  const t = sw([...e.cssCompiledStyles || [], ...e.cssStyles || []]);
  return { stylesMap: t, stylesArray: [...t] };
}, "compileStyles"), sw = /* @__PURE__ */ d((e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    const [i, n] = r.split(":");
    t.set(i.trim(), n == null ? void 0 : n.trim());
  }), t;
}, "styles2Map"), Rf = /* @__PURE__ */ d((e) => e === "color" || e === "font-size" || e === "font-family" || e === "font-weight" || e === "font-style" || e === "text-decoration" || e === "text-align" || e === "text-transform" || e === "line-height" || e === "letter-spacing" || e === "word-spacing" || e === "text-shadow" || e === "text-overflow" || e === "white-space" || e === "word-wrap" || e === "word-break" || e === "overflow-wrap" || e === "hyphens", "isLabelStyle"), Y = /* @__PURE__ */ d((e) => {
  const { stylesArray: t } = Lr(e), r = [], i = [], n = [], a = [];
  return t.forEach((o) => {
    const s = o[0];
    Rf(s) ? r.push(o.join(":") + " !important") : (i.push(o.join(":") + " !important"), s.includes("stroke") && n.push(o.join(":") + " !important"), s === "fill" && a.push(o.join(":") + " !important"));
  }), {
    labelStyles: r.join(";"),
    nodeStyles: i.join(";"),
    stylesArray: t,
    borderStyles: n,
    backgroundStyles: a
  };
}, "styles2String"), H = /* @__PURE__ */ d((e, t) => {
  var l;
  const { themeVariables: r, handDrawnSeed: i } = nt(), { nodeBorder: n, mainBkg: a } = r, { stylesMap: o } = Lr(e);
  return Object.assign(
    {
      roughness: 0.7,
      fill: o.get("fill") || a,
      fillStyle: "hachure",
      // solid fill
      fillWeight: 4,
      hachureGap: 5.2,
      stroke: o.get("stroke") || n,
      seed: i,
      strokeWidth: ((l = o.get("stroke-width")) == null ? void 0 : l.replace("px", "")) || 1.3,
      fillLineDash: [0, 0]
    },
    t
  );
}, "userNodeOverrides"), If = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = Y(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = bt(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Le(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0
  });
  let m = g.getBBox();
  if (bt(r.flowchart.htmlLabels)) {
    const v = g.children[0], D = et(g);
    m = v.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let S;
  if (t.look === "handDrawn") {
    const v = W.svg(u), D = H(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 3,
      seed: n
    }), R = v.path(me(b, _, y, x, 0), D);
    S = u.insert(() => (F.debug("Rough node insert CXC", R), R), ":first-child"), S.select("path:nth-child(2)").attr("style", c.join(";")), S.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    S = u.insert("rect", ":first-child"), S.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = ks(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), s) {
    const v = p.select("span");
    v && v.attr("style", s);
  }
  const C = S.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(v) {
    return Br(t, v);
  }, { cluster: u, labelBBox: m };
}, "rect"), ow = /* @__PURE__ */ d((e, t) => {
  const r = e.insert("g").attr("class", "note-cluster").attr("id", t.id), i = r.insert("rect", ":first-child"), n = 0 * t.padding, a = n / 2;
  i.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - a).attr("y", t.y - t.height / 2 - a).attr("width", t.width + n).attr("height", t.height + n).attr("fill", "none");
  const o = i.node().getBBox();
  return t.width = o.width, t.height = o.height, t.intersect = function(s) {
    return Br(t, s);
  }, { cluster: r, labelBBox: { width: 0, height: 0 } };
}, "noteGroup"), lw = /* @__PURE__ */ d(async (e, t) => {
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { altBackground: a, compositeBackground: o, compositeTitleBackground: s, nodeBorder: l } = i, c = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-id", t.id).attr("data-look", t.look), h = c.insert("g", ":first-child"), u = c.insert("g").attr("class", "cluster-label");
  let f = c.append("rect");
  const p = u.node().appendChild(await Ie(t.label, t.labelStyle, void 0, !0));
  let g = p.getBBox();
  if (bt(r.flowchart.htmlLabels)) {
    const R = p.children[0], E = et(p);
    g = R.getBoundingClientRect(), E.attr("width", g.width), E.attr("height", g.height);
  }
  const m = 0 * t.padding, y = m / 2, x = (t.width <= g.width + t.padding ? g.width + t.padding : t.width) + m;
  t.width <= g.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const b = t.height + m, _ = t.height + m - g.height - 6, S = t.x - x / 2, w = t.y - b / 2;
  t.width = x;
  const C = t.y - t.height / 2 - y + g.height + 2;
  let v;
  if (t.look === "handDrawn") {
    const R = t.cssClasses.includes("statediagram-cluster-alt"), E = W.svg(c), A = t.rx || t.ry ? E.path(me(S, w, x, b, 10), {
      roughness: 0.7,
      fill: s,
      fillStyle: "solid",
      stroke: l,
      seed: n
    }) : E.rectangle(S, w, x, b, { seed: n });
    v = c.insert(() => A, ":first-child");
    const P = E.rectangle(S, C, x, _, {
      fill: R ? a : o,
      fillStyle: R ? "hachure" : "solid",
      stroke: l,
      seed: n
    });
    v = c.insert(() => A, ":first-child"), f = c.insert(() => P);
  } else
    v = h.insert("rect", ":first-child"), v.attr("class", "outer").attr("x", S).attr("y", w).attr("width", x).attr("height", b).attr("data-look", t.look), f.attr("class", "inner").attr("x", S).attr("y", C).attr("width", x).attr("height", _);
  u.attr(
    "transform",
    `translate(${t.x - g.width / 2}, ${w + 1 - (bt(r.flowchart.htmlLabels) ? 0 : 3)})`
  );
  const D = v.node().getBBox();
  return t.height = D.height, t.offsetX = 0, t.offsetY = g.height - t.padding / 2, t.labelBBox = g, t.intersect = function(R) {
    return Br(t, R);
  }, { cluster: c, labelBBox: g };
}, "roundedWithTitle"), cw = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = Y(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = bt(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Le(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0,
    width: t.width
  });
  let m = g.getBBox();
  if (bt(r.flowchart.htmlLabels)) {
    const v = g.children[0], D = et(g);
    m = v.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let S;
  if (t.look === "handDrawn") {
    const v = W.svg(u), D = H(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 4,
      seed: n
    }), R = v.path(me(b, _, y, x, t.rx), D);
    S = u.insert(() => (F.debug("Rough node insert CXC", R), R), ":first-child"), S.select("path:nth-child(2)").attr("style", c.join(";")), S.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    S = u.insert("rect", ":first-child"), S.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = ks(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), s) {
    const v = p.select("span");
    v && v.attr("style", s);
  }
  const C = S.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(v) {
    return Br(t, v);
  }, { cluster: u, labelBBox: m };
}, "kanbanSection"), hw = /* @__PURE__ */ d((e, t) => {
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { nodeBorder: a } = i, o = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-look", t.look), s = o.insert("g", ":first-child"), l = 0 * t.padding, c = t.width + l;
  t.diff = -t.padding;
  const h = t.height + l, u = t.x - c / 2, f = t.y - h / 2;
  t.width = c;
  let p;
  if (t.look === "handDrawn") {
    const y = W.svg(o).rectangle(u, f, c, h, {
      fill: "lightgrey",
      roughness: 0.5,
      strokeLineDash: [5],
      stroke: a,
      seed: n
    });
    p = o.insert(() => y, ":first-child");
  } else
    p = s.insert("rect", ":first-child"), p.attr("class", "divider").attr("x", u).attr("y", f).attr("width", c).attr("height", h).attr("data-look", t.look);
  const g = p.node().getBBox();
  return t.height = g.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function(m) {
    return Br(t, m);
  }, { cluster: o, labelBBox: {} };
}, "divider"), uw = If, fw = {
  rect: If,
  squareRect: uw,
  roundedWithTitle: lw,
  noteGroup: ow,
  divider: hw,
  kanbanSection: cw
}, Pf = /* @__PURE__ */ new Map(), pw = /* @__PURE__ */ d(async (e, t) => {
  const r = t.shape || "rect", i = await fw[r](e, t);
  return Pf.set(t.id, i), i;
}, "insertCluster"), ET = /* @__PURE__ */ d(() => {
  Pf = /* @__PURE__ */ new Map();
}, "clear");
function Nf(e, t) {
  return e.intersect(t);
}
d(Nf, "intersectNode");
var dw = Nf;
function zf(e, t, r, i) {
  var n = e.x, a = e.y, o = n - i.x, s = a - i.y, l = Math.sqrt(t * t * s * s + r * r * o * o), c = Math.abs(t * r * o / l);
  i.x < n && (c = -c);
  var h = Math.abs(t * r * s / l);
  return i.y < a && (h = -h), { x: n + c, y: a + h };
}
d(zf, "intersectEllipse");
var qf = zf;
function Wf(e, t, r) {
  return qf(e, t, t, r);
}
d(Wf, "intersectCircle");
var gw = Wf;
function Hf(e, t, r, i) {
  var n, a, o, s, l, c, h, u, f, p, g, m, y, x, b;
  if (n = t.y - e.y, o = e.x - t.x, l = t.x * e.y - e.x * t.y, f = n * r.x + o * r.y + l, p = n * i.x + o * i.y + l, !(f !== 0 && p !== 0 && ts(f, p)) && (a = i.y - r.y, s = r.x - i.x, c = i.x * r.y - r.x * i.y, h = a * e.x + s * e.y + c, u = a * t.x + s * t.y + c, !(h !== 0 && u !== 0 && ts(h, u)) && (g = n * s - a * o, g !== 0)))
    return m = Math.abs(g / 2), y = o * c - s * l, x = y < 0 ? (y - m) / g : (y + m) / g, y = a * l - n * c, b = y < 0 ? (y - m) / g : (y + m) / g, { x, y: b };
}
d(Hf, "intersectLine");
function ts(e, t) {
  return e * t > 0;
}
d(ts, "sameSign");
var mw = Hf;
function jf(e, t, r) {
  let i = e.x, n = e.y, a = [], o = Number.POSITIVE_INFINITY, s = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(h) {
    o = Math.min(o, h.x), s = Math.min(s, h.y);
  }) : (o = Math.min(o, t.x), s = Math.min(s, t.y));
  let l = i - e.width / 2 - o, c = n - e.height / 2 - s;
  for (let h = 0; h < t.length; h++) {
    let u = t[h], f = t[h < t.length - 1 ? h + 1 : 0], p = mw(
      e,
      r,
      { x: l + u.x, y: c + u.y },
      { x: l + f.x, y: c + f.y }
    );
    p && a.push(p);
  }
  return a.length ? (a.length > 1 && a.sort(function(h, u) {
    let f = h.x - r.x, p = h.y - r.y, g = Math.sqrt(f * f + p * p), m = u.x - r.x, y = u.y - r.y, x = Math.sqrt(m * m + y * y);
    return g < x ? -1 : g === x ? 0 : 1;
  }), a[0]) : e;
}
d(jf, "intersectPolygon");
var yw = jf, q = {
  node: dw,
  circle: gw,
  ellipse: qf,
  polygon: yw,
  rect: Br
};
function Yf(e, t) {
  const { labelStyles: r } = Y(t);
  t.labelStyle = r;
  const i = Z(t);
  let n = i;
  i || (n = "anchor");
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = 1, { cssStyles: s } = t, l = W.svg(a), c = H(t, { fill: "black", stroke: "none", fillStyle: "solid" });
  t.look !== "handDrawn" && (c.roughness = 0);
  const h = l.circle(0, 0, o * 2, c), u = a.insert(() => h, ":first-child");
  return u.attr("class", "anchor").attr("style", Et(s)), j(t, u), t.intersect = function(f) {
    return F.info("Circle intersect", t, o, f), q.circle(t, o, f);
  }, a;
}
d(Yf, "anchor");
function es(e, t, r, i, n, a, o) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, p = u / n, g = f / a, m = Math.sqrt(p ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = l + y * a * Math.sin(h) * (o ? -1 : 1), b = c - y * n * Math.cos(h) * (o ? -1 : 1), _ = Math.atan2((t - b) / a, (e - x) / n);
  let w = Math.atan2((i - b) / a, (r - x) / n) - _;
  o && w < 0 && (w += 2 * Math.PI), !o && w > 0 && (w -= 2 * Math.PI);
  const C = [];
  for (let v = 0; v < 20; v++) {
    const D = v / 19, R = _ + D * w, E = x + n * Math.cos(R), A = b + a * Math.sin(R);
    C.push({ x: E, y: A });
  }
  return C;
}
d(es, "generateArcPoints");
async function Gf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = a.width + t.padding + 20, s = a.height + t.padding, l = s / 2, c = l / (2.5 + s / 50), { cssStyles: h } = t, u = [
    { x: o / 2, y: -s / 2 },
    { x: -o / 2, y: -s / 2 },
    ...es(-o / 2, -s / 2, -o / 2, s / 2, c, l, !1),
    { x: o / 2, y: s / 2 },
    ...es(o / 2, s / 2, o / 2, -s / 2, c, l, !0)
  ], f = W.svg(n), p = H(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = rt(u), m = f.path(g, p), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(${c / 2}, 0)`), j(t, y), t.intersect = function(x) {
    return q.polygon(t, u, x);
  }, n;
}
d(Gf, "bowTieRect");
function ye(e, t, r, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(n) {
      return n.x + "," + n.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + r / 2 + ")");
}
d(ye, "insertPolygonShape");
async function Uf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = a.height + t.padding, s = 12, l = a.width + t.padding + s, c = 0, h = l, u = -o, f = 0, p = [
    { x: c + s, y: u },
    { x: h, y: u },
    { x: h, y: f },
    { x: c, y: f },
    { x: c, y: u + s },
    { x: c + s, y: u }
  ];
  let g;
  const { cssStyles: m } = t;
  if (t.look === "handDrawn") {
    const y = W.svg(n), x = H(t, {}), b = rt(p), _ = y.path(b, x);
    g = n.insert(() => _, ":first-child").attr("transform", `translate(${-l / 2}, ${o / 2})`), m && g.attr("style", m);
  } else
    g = ye(n, l, o, p);
  return i && g.attr("style", i), j(t, g), t.intersect = function(y) {
    return q.polygon(t, p, y);
  }, n;
}
d(Uf, "card");
function Xf(e, t) {
  const { nodeStyles: r } = Y(t);
  t.label = "";
  const i = e.insert("g").attr("class", Z(t)).attr("id", t.domId ?? t.id), { cssStyles: n } = t, a = Math.max(28, t.width ?? 0), o = [
    { x: 0, y: a / 2 },
    { x: a / 2, y: 0 },
    { x: 0, y: -a / 2 },
    { x: -a / 2, y: 0 }
  ], s = W.svg(i), l = H(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = rt(o), h = s.path(c, l), u = i.insert(() => h, ":first-child");
  return n && t.look !== "handDrawn" && u.selectAll("path").attr("style", n), r && t.look !== "handDrawn" && u.selectAll("path").attr("style", r), t.width = 28, t.height = 28, t.intersect = function(f) {
    return q.polygon(t, o, f);
  }, i;
}
d(Xf, "choice");
async function Vf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o } = await Q(e, t, Z(t)), s = a.width / 2 + o;
  let l;
  const { cssStyles: c } = t;
  if (t.look === "handDrawn") {
    const h = W.svg(n), u = H(t, {}), f = h.circle(0, 0, s * 2, u);
    l = n.insert(() => f, ":first-child"), l.attr("class", "basic label-container").attr("style", Et(c));
  } else
    l = n.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", i).attr("r", s).attr("cx", 0).attr("cy", 0);
  return j(t, l), t.intersect = function(h) {
    return F.info("Circle intersect", t, s, h), q.circle(t, s, h);
  }, n;
}
d(Vf, "circle");
function Zf(e) {
  const t = Math.cos(Math.PI / 4), r = Math.sin(Math.PI / 4), i = e * 2, n = { x: i / 2 * t, y: i / 2 * r }, a = { x: -(i / 2) * t, y: i / 2 * r }, o = { x: -(i / 2) * t, y: -(i / 2) * r }, s = { x: i / 2 * t, y: -(i / 2) * r };
  return `M ${a.x},${a.y} L ${s.x},${s.y}
                   M ${n.x},${n.y} L ${o.x},${o.y}`;
}
d(Zf, "createLine");
function Kf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r, t.label = "";
  const n = e.insert("g").attr("class", Z(t)).attr("id", t.domId ?? t.id), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), { cssStyles: o } = t, s = W.svg(n), l = H(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = s.circle(0, 0, a * 2, l), h = Zf(a), u = s.path(h, l), f = n.insert(() => c, ":first-child");
  return f.insert(() => u), o && t.look !== "handDrawn" && f.selectAll("path").attr("style", o), i && t.look !== "handDrawn" && f.selectAll("path").attr("style", i), j(t, f), t.intersect = function(p) {
    return F.info("crossedCircle intersect", t, { radius: a, point: p }), q.circle(t, a, p);
  }, n;
}
d(Kf, "crossedCircle");
function oe(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(oe, "generateCirclePoints");
async function Qf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...oe(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...oe(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...oe(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...oe(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...oe(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...oe(s / 2 + s * 0.1, -c, c, 20, -180, -270),
    ...oe(s / 2 + s * 0.1, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...oe(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2, y: l / 2 + c }
  ], p = W.svg(n), g = H(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = rt(u).replace("Z", ""), x = p.path(y, g), b = rt(f), _ = p.path(b, { ...g }), S = n.insert("g", ":first-child");
  return S.insert(() => _, ":first-child").attr("stroke-opacity", 0), S.insert(() => x, ":first-child"), S.attr("class", "text"), h && t.look !== "handDrawn" && S.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && S.selectAll("path").attr("style", i), S.attr("transform", `translate(${c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + c - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, S), t.intersect = function(w) {
    return q.polygon(t, f, w);
  }, n;
}
d(Qf, "curlyBraceLeft");
function le(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: p, y: g });
  }
  return o;
}
d(le, "generateCirclePoints");
async function Jf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...le(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...le(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...le(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...le(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: -s / 2, y: -l / 2 - c },
    { x: s / 2, y: -l / 2 - c },
    ...le(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...le(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...le(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...le(s / 2, l / 2, c, 20, 0, 90),
    { x: s / 2, y: l / 2 + c },
    { x: -s / 2, y: l / 2 + c }
  ], p = W.svg(n), g = H(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = rt(u).replace("Z", ""), x = p.path(y, g), b = rt(f), _ = p.path(b, { ...g }), S = n.insert("g", ":first-child");
  return S.insert(() => _, ":first-child").attr("stroke-opacity", 0), S.insert(() => x, ":first-child"), S.attr("class", "text"), h && t.look !== "handDrawn" && S.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && S.selectAll("path").attr("style", i), S.attr("transform", `translate(${-c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, S), t.intersect = function(w) {
    return q.polygon(t, f, w);
  }, n;
}
d(Jf, "curlyBraceRight");
function wt(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(wt, "generateCirclePoints");
async function tp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...wt(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...wt(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...wt(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...wt(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    ...wt(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...wt(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...wt(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...wt(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], p = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...wt(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...wt(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...wt(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...wt(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2 - c - c / 2, y: l / 2 + c },
    ...wt(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...wt(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...wt(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...wt(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], g = W.svg(n), m = H(t, { fill: "none" });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = rt(u).replace("Z", ""), b = g.path(x, m), S = rt(f).replace("Z", ""), w = g.path(S, m), C = rt(p), v = g.path(C, { ...m }), D = n.insert("g", ":first-child");
  return D.insert(() => v, ":first-child").attr("stroke-opacity", 0), D.insert(() => b, ":first-child"), D.insert(() => w, ":first-child"), D.attr("class", "text"), h && t.look !== "handDrawn" && D.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(${c - c / 4}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, D), t.intersect = function(R) {
    return q.polygon(t, p, R);
  }, n;
}
d(tp, "curlyBraces");
async function ep(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = 80, s = 20, l = Math.max(o, (a.width + (t.padding ?? 0) * 2) * 1.25, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = W.svg(n), p = H(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = l, m = c, y = g - h, x = m / 4, b = [
    { x: y, y: 0 },
    { x, y: 0 },
    { x: 0, y: m / 2 },
    { x, y: m },
    { x: y, y: m },
    ...so(-y, -m / 2, h, 50, 270, 90)
  ], _ = rt(b), S = f.path(_, p), w = n.insert(() => S, ":first-child");
  return w.attr("class", "basic label-container"), u && t.look !== "handDrawn" && w.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && w.selectChildren("path").attr("style", i), w.attr("transform", `translate(${-l / 2}, ${-c / 2})`), j(t, w), t.intersect = function(C) {
    return q.polygon(t, b, C);
  }, n;
}
d(ep, "curvedTrapezoid");
var xw = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createCylinderPathD"), bw = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createOuterCylinderPathD"), Cw = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function rp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + t.padding, t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + t.padding, t.height ?? 0);
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = W.svg(n), g = bw(0, 0, s, h, l, c), m = Cw(0, c, s, h, l, c), y = p.path(g, H(t, {})), x = p.path(m, H(t, { fill: "none" }));
    u = n.insert(() => x, ":first-child"), u = n.insert(() => y, ":first-child"), u.attr("class", "basic label-container"), f && u.attr("style", f);
  } else {
    const p = xw(0, 0, s, h, l, c);
    u = n.insert("path", ":first-child").attr("d", p).attr("class", "basic label-container").attr("style", Et(f)).attr("style", i);
  }
  return u.attr("label-offset-y", c), u.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), j(t, u), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + (t.padding ?? 0) / 1.5 - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(p) {
    const g = q.rect(t, p), m = g.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(m) < (t.width ?? 0) / 2 || Math.abs(m) == (t.width ?? 0) / 2 && Math.abs(g.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let y = c * c * (1 - m * m / (l * l));
      y > 0 && (y = Math.sqrt(y)), y = c - y, p.y - (t.y ?? 0) > 0 && (y = -y), g.y += y;
    }
    return g;
  }, n;
}
d(rp, "cylinder");
async function ip(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = a.width + t.padding, l = a.height + t.padding, c = l * 0.2, h = -s / 2, u = -l / 2 - c / 2, { cssStyles: f } = t, p = W.svg(n), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u + c },
    { x: -h, y: u + c },
    { x: -h, y: -u },
    { x: h, y: -u },
    { x: h, y: u },
    { x: -h, y: u },
    { x: -h, y: u + c }
  ], y = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${h + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))}, ${u + c + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, x), t.intersect = function(b) {
    return q.rect(t, b);
  }, n;
}
d(ip, "dividedRectangle");
async function np(e, t) {
  var f, p;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o } = await Q(e, t, Z(t)), l = a.width / 2 + o + 5, c = a.width / 2 + o;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const g = W.svg(n), m = H(t, { roughness: 0.2, strokeWidth: 2.5 }), y = H(t, { roughness: 0.2, strokeWidth: 1.5 }), x = g.circle(0, 0, l * 2, m), b = g.circle(0, 0, c * 2, y);
    h = n.insert("g", ":first-child"), h.attr("class", Et(t.cssClasses)).attr("style", Et(u)), (f = h.node()) == null || f.appendChild(x), (p = h.node()) == null || p.appendChild(b);
  } else {
    h = n.insert("g", ":first-child");
    const g = h.insert("circle", ":first-child"), m = h.insert("circle");
    h.attr("class", "basic label-container").attr("style", i), g.attr("class", "outer-circle").attr("style", i).attr("r", l).attr("cx", 0).attr("cy", 0), m.attr("class", "inner-circle").attr("style", i).attr("r", c).attr("cx", 0).attr("cy", 0);
  }
  return j(t, h), t.intersect = function(g) {
    return F.info("DoubleCircle intersect", t, l, g), q.circle(t, l, g);
  }, n;
}
d(np, "doublecircle");
function ap(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.label = "", t.labelStyle = i;
  const a = e.insert("g").attr("class", Z(t)).attr("id", t.domId ?? t.id), o = 7, { cssStyles: s } = t, l = W.svg(a), { nodeBorder: c } = r, h = H(t, { fillStyle: "solid" });
  t.look !== "handDrawn" && (h.roughness = 0);
  const u = l.circle(0, 0, o * 2, h), f = a.insert(() => u, ":first-child");
  return f.selectAll("path").attr("style", `fill: ${c} !important;`), s && s.length > 0 && t.look !== "handDrawn" && f.selectAll("path").attr("style", s), n && t.look !== "handDrawn" && f.selectAll("path").attr("style", n), j(t, f), t.intersect = function(p) {
    return F.info("filledCircle intersect", t, { radius: o, point: p }), q.circle(t, o, p);
  }, a;
}
d(ap, "filledCircle");
async function sp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = a.width + (t.padding ?? 0), l = s + a.height, c = s + a.height, h = [
    { x: 0, y: -l },
    { x: c, y: -l },
    { x: c / 2, y: 0 }
  ], { cssStyles: u } = t, f = W.svg(n), p = H(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = rt(h), m = f.path(g, p), y = n.insert(() => m, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`);
  return u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), t.width = s, t.height = l, j(t, y), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${-l / 2 + (t.padding ?? 0) / 2 + (a.y - (a.top ?? 0))})`
  ), t.intersect = function(x) {
    return F.info("Triangle intersect", t, h, x), q.polygon(t, h, x);
  }, n;
}
d(sp, "flippedTriangle");
function op(e, t, { dir: r, config: { state: i, themeVariables: n } }) {
  const { nodeStyles: a } = Y(t);
  t.label = "";
  const o = e.insert("g").attr("class", Z(t)).attr("id", t.domId ?? t.id), { cssStyles: s } = t;
  let l = Math.max(70, (t == null ? void 0 : t.width) ?? 0), c = Math.max(10, (t == null ? void 0 : t.height) ?? 0);
  r === "LR" && (l = Math.max(10, (t == null ? void 0 : t.width) ?? 0), c = Math.max(70, (t == null ? void 0 : t.height) ?? 0));
  const h = -1 * l / 2, u = -1 * c / 2, f = W.svg(o), p = H(t, {
    stroke: n.lineColor,
    fill: n.lineColor
  });
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = f.rectangle(h, u, l, c, p), m = o.insert(() => g, ":first-child");
  s && t.look !== "handDrawn" && m.selectAll("path").attr("style", s), a && t.look !== "handDrawn" && m.selectAll("path").attr("style", a), j(t, m);
  const y = (i == null ? void 0 : i.padding) ?? 0;
  return t.width && t.height && (t.width += y / 2 || 0, t.height += y / 2 || 0), t.intersect = function(x) {
    return q.rect(t, x);
  }, o;
}
d(op, "forkJoin");
async function lp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const n = 80, a = 50, { shapeSvg: o, bbox: s } = await Q(e, t, Z(t)), l = Math.max(n, s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a, s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = W.svg(o), p = H(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -l / 2, y: -c / 2 },
    { x: l / 2 - h, y: -c / 2 },
    ...so(-l / 2 + h, 0, h, 50, 90, 270),
    { x: l / 2 - h, y: c / 2 },
    { x: -l / 2, y: c / 2 }
  ], m = rt(g), y = f.path(m, p), x = o.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), j(t, x), t.intersect = function(b) {
    return F.info("Pill intersect", t, { radius: h, point: b }), q.polygon(t, g, b);
  }, o;
}
d(lp, "halfRoundedRectangle");
var _w = /* @__PURE__ */ d((e, t, r, i, n) => [
  `M${e + n},${t}`,
  `L${e + r - n},${t}`,
  `L${e + r},${t - i / 2}`,
  `L${e + r - n},${t - i}`,
  `L${e + n},${t - i}`,
  `L${e},${t - i / 2}`,
  "Z"
].join(" "), "createHexagonPathD");
async function cp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = 4, s = a.height + t.padding, l = s / o, c = a.width + 2 * l + t.padding, h = [
    { x: l, y: 0 },
    { x: c - l, y: 0 },
    { x: c, y: -s / 2 },
    { x: c - l, y: -s },
    { x: l, y: -s },
    { x: 0, y: -s / 2 }
  ];
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = W.svg(n), g = H(t, {}), m = _w(0, 0, c, s, l), y = p.path(m, g);
    u = n.insert(() => y, ":first-child").attr("transform", `translate(${-c / 2}, ${s / 2})`), f && u.attr("style", f);
  } else
    u = ye(n, c, s, h);
  return i && u.attr("style", i), t.width = c, t.height = s, j(t, u), t.intersect = function(p) {
    return q.polygon(t, h, p);
  }, n;
}
d(cp, "hexagon");
async function hp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.label = "", t.labelStyle = r;
  const { shapeSvg: n } = await Q(e, t, Z(t)), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), o = Math.max(30, (t == null ? void 0 : t.height) ?? 0), { cssStyles: s } = t, l = W.svg(n), c = H(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const h = [
    { x: 0, y: 0 },
    { x: a, y: 0 },
    { x: 0, y: o },
    { x: a, y: o }
  ], u = rt(h), f = l.path(u, c), p = n.insert(() => f, ":first-child");
  return p.attr("class", "basic label-container"), s && t.look !== "handDrawn" && p.selectChildren("path").attr("style", s), i && t.look !== "handDrawn" && p.selectChildren("path").attr("style", i), p.attr("transform", `translate(${-a / 2}, ${-o / 2})`), j(t, p), t.intersect = function(g) {
    return F.info("Pill intersect", t, { points: h }), q.polygon(t, h, g);
  }, n;
}
d(hp, "hourglass");
async function up(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await Q(e, t, "icon-shape default"), f = t.pos === "t", p = s, g = s, { nodeBorder: m } = r, { stylesMap: y } = Lr(t), x = -g / 2, b = -p / 2, _ = t.label ? 8 : 0, S = W.svg(c), w = H(t, { stroke: "none", fill: "none" });
  t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid");
  const C = S.rectangle(x, b, g, p, w), v = Math.max(g, h.width), D = p + h.height + _, R = S.rectangle(-v / 2, -D / 2, v, D, {
    ...w,
    fill: "transparent",
    stroke: "none"
  }), E = c.insert(() => C, ":first-child"), A = c.insert(() => R);
  if (t.icon) {
    const P = c.append("g");
    P.html(
      `<g>${await yi(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const O = P.node().getBBox(), B = O.width, M = O.height, T = O.x, $ = O.y;
    P.attr(
      "transform",
      `translate(${-B / 2 - T},${f ? h.height / 2 + _ / 2 - M / 2 - $ : -h.height / 2 - _ / 2 - M / 2 - $})`
    ), P.attr("style", `color: ${y.get("stroke") ?? m};`);
  }
  return u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -D / 2 : D / 2 - h.height})`
  ), E.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + _ / 2 : -h.height / 2 - _ / 2})`
  ), j(t, A), t.intersect = function(P) {
    if (F.info("iconSquare intersect", t, P), !t.label)
      return q.rect(t, P);
    const O = t.x ?? 0, B = t.y ?? 0, M = t.height ?? 0;
    let T = [];
    return f ? T = [
      { x: O - h.width / 2, y: B - M / 2 },
      { x: O + h.width / 2, y: B - M / 2 },
      { x: O + h.width / 2, y: B - M / 2 + h.height + _ },
      { x: O + g / 2, y: B - M / 2 + h.height + _ },
      { x: O + g / 2, y: B + M / 2 },
      { x: O - g / 2, y: B + M / 2 },
      { x: O - g / 2, y: B - M / 2 + h.height + _ },
      { x: O - h.width / 2, y: B - M / 2 + h.height + _ }
    ] : T = [
      { x: O - g / 2, y: B - M / 2 },
      { x: O + g / 2, y: B - M / 2 },
      { x: O + g / 2, y: B - M / 2 + p },
      { x: O + h.width / 2, y: B - M / 2 + p },
      { x: O + h.width / 2 / 2, y: B + M / 2 },
      { x: O - h.width / 2, y: B + M / 2 },
      { x: O - h.width / 2, y: B - M / 2 + p },
      { x: O - g / 2, y: B - M / 2 + p }
    ], q.polygon(t, T, P);
  }, c;
}
d(up, "icon");
async function fp(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await Q(e, t, "icon-shape default"), f = 20, p = t.label ? 8 : 0, g = t.pos === "t", { nodeBorder: m, mainBkg: y } = r, { stylesMap: x } = Lr(t), b = W.svg(c), _ = H(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const S = x.get("fill");
  _.stroke = S ?? y;
  const w = c.append("g");
  t.icon && w.html(
    `<g>${await yi(t.icon, {
      height: s,
      width: s,
      fallbackPrefix: ""
    })}</g>`
  );
  const C = w.node().getBBox(), v = C.width, D = C.height, R = C.x, E = C.y, A = Math.max(v, D) * Math.SQRT2 + f * 2, P = b.circle(0, 0, A, _), O = Math.max(A, h.width), B = A + h.height + p, M = b.rectangle(-O / 2, -B / 2, O, B, {
    ..._,
    fill: "transparent",
    stroke: "none"
  }), T = c.insert(() => P, ":first-child"), $ = c.insert(() => M);
  return w.attr(
    "transform",
    `translate(${-v / 2 - R},${g ? h.height / 2 + p / 2 - D / 2 - E : -h.height / 2 - p / 2 - D / 2 - E})`
  ), w.attr("style", `color: ${x.get("stroke") ?? m};`), u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${g ? -B / 2 : B / 2 - h.height})`
  ), T.attr(
    "transform",
    `translate(0,${g ? h.height / 2 + p / 2 : -h.height / 2 - p / 2})`
  ), j(t, $), t.intersect = function(L) {
    return F.info("iconSquare intersect", t, L), q.rect(t, L);
  }, c;
}
d(fp, "iconCircle");
async function pp(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await Q(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = Lr(t), _ = -m / 2, S = -g / 2, w = t.label ? 8 : 0, C = W.svg(c), v = H(t, {});
  t.look !== "handDrawn" && (v.roughness = 0, v.fillStyle = "solid");
  const D = b.get("fill");
  v.stroke = D ?? x;
  const R = C.path(me(_, S, m, g, 5), v), E = Math.max(m, h.width), A = g + h.height + w, P = C.rectangle(-E / 2, -A / 2, E, A, {
    ...v,
    fill: "transparent",
    stroke: "none"
  }), O = c.insert(() => R, ":first-child").attr("class", "icon-shape2"), B = c.insert(() => P);
  if (t.icon) {
    const M = c.append("g");
    M.html(
      `<g>${await yi(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const T = M.node().getBBox(), $ = T.width, L = T.height, N = T.x, U = T.y;
    M.attr(
      "transform",
      `translate(${-$ / 2 - N},${p ? h.height / 2 + w / 2 - L / 2 - U : -h.height / 2 - w / 2 - L / 2 - U})`
    ), M.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -A / 2 : A / 2 - h.height})`
  ), O.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), j(t, B), t.intersect = function(M) {
    if (F.info("iconSquare intersect", t, M), !t.label)
      return q.rect(t, M);
    const T = t.x ?? 0, $ = t.y ?? 0, L = t.height ?? 0;
    let N = [];
    return p ? N = [
      { x: T - h.width / 2, y: $ - L / 2 },
      { x: T + h.width / 2, y: $ - L / 2 },
      { x: T + h.width / 2, y: $ - L / 2 + h.height + w },
      { x: T + m / 2, y: $ - L / 2 + h.height + w },
      { x: T + m / 2, y: $ + L / 2 },
      { x: T - m / 2, y: $ + L / 2 },
      { x: T - m / 2, y: $ - L / 2 + h.height + w },
      { x: T - h.width / 2, y: $ - L / 2 + h.height + w }
    ] : N = [
      { x: T - m / 2, y: $ - L / 2 },
      { x: T + m / 2, y: $ - L / 2 },
      { x: T + m / 2, y: $ - L / 2 + g },
      { x: T + h.width / 2, y: $ - L / 2 + g },
      { x: T + h.width / 2 / 2, y: $ + L / 2 },
      { x: T - h.width / 2, y: $ + L / 2 },
      { x: T - h.width / 2, y: $ - L / 2 + g },
      { x: T - m / 2, y: $ - L / 2 + g }
    ], q.polygon(t, N, M);
  }, c;
}
d(pp, "iconRounded");
async function dp(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await Q(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = Lr(t), _ = -m / 2, S = -g / 2, w = t.label ? 8 : 0, C = W.svg(c), v = H(t, {});
  t.look !== "handDrawn" && (v.roughness = 0, v.fillStyle = "solid");
  const D = b.get("fill");
  v.stroke = D ?? x;
  const R = C.path(me(_, S, m, g, 0.1), v), E = Math.max(m, h.width), A = g + h.height + w, P = C.rectangle(-E / 2, -A / 2, E, A, {
    ...v,
    fill: "transparent",
    stroke: "none"
  }), O = c.insert(() => R, ":first-child"), B = c.insert(() => P);
  if (t.icon) {
    const M = c.append("g");
    M.html(
      `<g>${await yi(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const T = M.node().getBBox(), $ = T.width, L = T.height, N = T.x, U = T.y;
    M.attr(
      "transform",
      `translate(${-$ / 2 - N},${p ? h.height / 2 + w / 2 - L / 2 - U : -h.height / 2 - w / 2 - L / 2 - U})`
    ), M.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -A / 2 : A / 2 - h.height})`
  ), O.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), j(t, B), t.intersect = function(M) {
    if (F.info("iconSquare intersect", t, M), !t.label)
      return q.rect(t, M);
    const T = t.x ?? 0, $ = t.y ?? 0, L = t.height ?? 0;
    let N = [];
    return p ? N = [
      { x: T - h.width / 2, y: $ - L / 2 },
      { x: T + h.width / 2, y: $ - L / 2 },
      { x: T + h.width / 2, y: $ - L / 2 + h.height + w },
      { x: T + m / 2, y: $ - L / 2 + h.height + w },
      { x: T + m / 2, y: $ + L / 2 },
      { x: T - m / 2, y: $ + L / 2 },
      { x: T - m / 2, y: $ - L / 2 + h.height + w },
      { x: T - h.width / 2, y: $ - L / 2 + h.height + w }
    ] : N = [
      { x: T - m / 2, y: $ - L / 2 },
      { x: T + m / 2, y: $ - L / 2 },
      { x: T + m / 2, y: $ - L / 2 + g },
      { x: T + h.width / 2, y: $ - L / 2 + g },
      { x: T + h.width / 2 / 2, y: $ + L / 2 },
      { x: T - h.width / 2, y: $ + L / 2 },
      { x: T - h.width / 2, y: $ - L / 2 + g },
      { x: T - m / 2, y: $ - L / 2 + g }
    ], q.polygon(t, N, M);
  }, c;
}
d(dp, "iconSquare");
async function gp(e, t, { config: { flowchart: r } }) {
  const i = new Image();
  i.src = (t == null ? void 0 : t.img) ?? "", await i.decode();
  const n = Number(i.naturalWidth.toString().replace("px", "")), a = Number(i.naturalHeight.toString().replace("px", ""));
  t.imageAspectRatio = n / a;
  const { labelStyles: o } = Y(t);
  t.labelStyle = o;
  const s = r == null ? void 0 : r.wrappingWidth;
  t.defaultWidth = r == null ? void 0 : r.wrappingWidth;
  const l = Math.max(
    t.label ? s ?? 0 : 0,
    (t == null ? void 0 : t.assetWidth) ?? n
  ), c = t.constraint === "on" && t != null && t.assetHeight ? t.assetHeight * t.imageAspectRatio : l, h = t.constraint === "on" ? c / t.imageAspectRatio : (t == null ? void 0 : t.assetHeight) ?? a;
  t.width = Math.max(c, s ?? 0);
  const { shapeSvg: u, bbox: f, label: p } = await Q(e, t, "image-shape default"), g = t.pos === "t", m = -c / 2, y = -h / 2, x = t.label ? 8 : 0, b = W.svg(u), _ = H(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const S = b.rectangle(m, y, c, h, _), w = Math.max(c, f.width), C = h + f.height + x, v = b.rectangle(-w / 2, -C / 2, w, C, {
    ..._,
    fill: "none",
    stroke: "none"
  }), D = u.insert(() => S, ":first-child"), R = u.insert(() => v);
  if (t.img) {
    const E = u.append("image");
    E.attr("href", t.img), E.attr("width", c), E.attr("height", h), E.attr("preserveAspectRatio", "none"), E.attr(
      "transform",
      `translate(${-c / 2},${g ? C / 2 - h : -C / 2})`
    );
  }
  return p.attr(
    "transform",
    `translate(${-f.width / 2 - (f.x - (f.left ?? 0))},${g ? -h / 2 - f.height / 2 - x / 2 : h / 2 - f.height / 2 + x / 2})`
  ), D.attr(
    "transform",
    `translate(0,${g ? f.height / 2 + x / 2 : -f.height / 2 - x / 2})`
  ), j(t, R), t.intersect = function(E) {
    if (F.info("iconSquare intersect", t, E), !t.label)
      return q.rect(t, E);
    const A = t.x ?? 0, P = t.y ?? 0, O = t.height ?? 0;
    let B = [];
    return g ? B = [
      { x: A - f.width / 2, y: P - O / 2 },
      { x: A + f.width / 2, y: P - O / 2 },
      { x: A + f.width / 2, y: P - O / 2 + f.height + x },
      { x: A + c / 2, y: P - O / 2 + f.height + x },
      { x: A + c / 2, y: P + O / 2 },
      { x: A - c / 2, y: P + O / 2 },
      { x: A - c / 2, y: P - O / 2 + f.height + x },
      { x: A - f.width / 2, y: P - O / 2 + f.height + x }
    ] : B = [
      { x: A - c / 2, y: P - O / 2 },
      { x: A + c / 2, y: P - O / 2 },
      { x: A + c / 2, y: P - O / 2 + h },
      { x: A + f.width / 2, y: P - O / 2 + h },
      { x: A + f.width / 2 / 2, y: P + O / 2 },
      { x: A - f.width / 2, y: P + O / 2 },
      { x: A - f.width / 2, y: P - O / 2 + h },
      { x: A - c / 2, y: P - O / 2 + h }
    ], q.polygon(t, B, E);
  }, u;
}
d(gp, "imageSquare");
async function mp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: -3 * s / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), p = rt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = ye(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d(mp, "inv_trapezoid");
async function bi(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o } = await Q(e, t, Z(t)), s = Math.max(o.width + r.labelPaddingX * 2, (t == null ? void 0 : t.width) || 0), l = Math.max(o.height + r.labelPaddingY * 2, (t == null ? void 0 : t.height) || 0), c = -s / 2, h = -l / 2;
  let u, { rx: f, ry: p } = t;
  const { cssStyles: g } = t;
  if (r != null && r.rx && r.ry && (f = r.rx, p = r.ry), t.look === "handDrawn") {
    const m = W.svg(a), y = H(t, {}), x = f || p ? m.path(me(c, h, s, l, f || 0), y) : m.rectangle(c, h, s, l, y);
    u = a.insert(() => x, ":first-child"), u.attr("class", "basic label-container").attr("style", Et(g));
  } else
    u = a.insert("rect", ":first-child"), u.attr("class", "basic label-container").attr("style", n).attr("rx", Et(f)).attr("ry", Et(p)).attr("x", c).attr("y", h).attr("width", s).attr("height", l);
  return j(t, u), t.intersect = function(m) {
    return q.rect(t, m);
  }, a;
}
d(bi, "drawRect");
async function yp(e, t) {
  const { shapeSvg: r, bbox: i, label: n } = await Q(e, t, "label"), a = r.insert("rect", ":first-child");
  return a.attr("width", 0.1).attr("height", 0.1), r.attr("class", "label edgeLabel"), n.attr(
    "transform",
    `translate(${-(i.width / 2) - (i.x - (i.left ?? 0))}, ${-(i.height / 2) - (i.y - (i.top ?? 0))})`
  ), j(t, a), t.intersect = function(l) {
    return q.rect(t, l);
  }, r;
}
d(yp, "labelRect");
async function xp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: -(3 * s) / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), p = rt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = ye(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d(xp, "lean_left");
async function bp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: -3 * s / 6, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), p = rt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = ye(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d(bp, "lean_right");
function Cp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.label = "", t.labelStyle = r;
  const n = e.insert("g").attr("class", Z(t)).attr("id", t.domId ?? t.id), { cssStyles: a } = t, o = Math.max(35, (t == null ? void 0 : t.width) ?? 0), s = Math.max(35, (t == null ? void 0 : t.height) ?? 0), l = 7, c = [
    { x: o, y: 0 },
    { x: 0, y: s + l / 2 },
    { x: o - 2 * l, y: s + l / 2 },
    { x: 0, y: 2 * s },
    { x: o, y: s - l / 2 },
    { x: 2 * l, y: s - l / 2 }
  ], h = W.svg(n), u = H(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = rt(c), p = h.path(f, u), g = n.insert(() => p, ":first-child");
  return a && t.look !== "handDrawn" && g.selectAll("path").attr("style", a), i && t.look !== "handDrawn" && g.selectAll("path").attr("style", i), g.attr("transform", `translate(-${o / 2},${-s})`), j(t, g), t.intersect = function(m) {
    return F.info("lightningBolt intersect", t, m), q.polygon(t, c, m);
  }, n;
}
d(Cp, "lightningBolt");
var ww = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createCylinderPathD"), vw = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createOuterCylinderPathD"), kw = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function _p(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0), t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + (t.padding ?? 0), t.height ?? 0), u = h * 0.1;
  let f;
  const { cssStyles: p } = t;
  if (t.look === "handDrawn") {
    const g = W.svg(n), m = vw(0, 0, s, h, l, c, u), y = kw(0, c, s, h, l, c), x = H(t, {}), b = g.path(m, x), _ = g.path(y, x);
    n.insert(() => _, ":first-child").attr("class", "line"), f = n.insert(() => b, ":first-child"), f.attr("class", "basic label-container"), p && f.attr("style", p);
  } else {
    const g = ww(0, 0, s, h, l, c, u);
    f = n.insert("path", ":first-child").attr("d", g).attr("class", "basic label-container").attr("style", Et(p)).attr("style", i);
  }
  return f.attr("label-offset-y", c), f.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), j(t, f), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(g) {
    const m = q.rect(t, g), y = m.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(y) < (t.width ?? 0) / 2 || Math.abs(y) == (t.width ?? 0) / 2 && Math.abs(m.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let x = c * c * (1 - y * y / (l * l));
      x > 0 && (x = Math.sqrt(x)), x = c - x, g.y - (t.y ?? 0) > 0 && (x = -x), m.y += x;
    }
    return m;
  }, n;
}
d(_p, "linedCylinder");
async function wp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, { cssStyles: u } = t, f = W.svg(n), p = H(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: h / 2 },
    ...Te(
      -s / 2 - s / 2 * 0.1,
      h / 2,
      s / 2 + s / 2 * 0.1,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2, y: -h / 2 },
    { x: -s / 2, y: h / 2 * 1.1 },
    { x: -s / 2, y: -h / 2 }
  ], m = f.polygon(
    g.map((x) => [x.x, x.y]),
    p
  ), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) + s / 2 * 0.1 / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, y), t.intersect = function(x) {
    return q.polygon(t, g, x);
  }, n;
}
d(wp, "linedWaveEdgedRect");
async function vp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, p = W.svg(n), g = H(t, {}), m = [
    { x: h - c, y: u + c },
    { x: h - c, y: u + l + c },
    { x: h + s - c, y: u + l + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u + l - c },
    { x: h + s + c, y: u + l - c },
    { x: h + s + c, y: u - c },
    { x: h + c, y: u - c },
    { x: h + c, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = [
    { x: h, y: u + c },
    { x: h + s - c, y: u + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u },
    { x: h, y: u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = rt(m), b = p.path(x, g), _ = rt(y), S = p.path(_, { ...g, fill: "none" }), w = n.insert(() => S, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) - c - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), j(t, w), t.intersect = function(C) {
    return q.polygon(t, m, C);
  }, n;
}
d(vp, "multiRect");
async function kp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, u = -s / 2, f = -h / 2, p = 5, { cssStyles: g } = t, m = Te(
    u - p,
    f + h + p,
    u + s - p,
    f + h + p,
    c,
    0.8
  ), y = m == null ? void 0 : m[m.length - 1], x = [
    { x: u - p, y: f + p },
    { x: u - p, y: f + h + p },
    ...m,
    { x: u + s - p, y: y.y - p },
    { x: u + s, y: y.y - p },
    { x: u + s, y: y.y - 2 * p },
    { x: u + s + p, y: y.y - 2 * p },
    { x: u + s + p, y: f - p },
    { x: u + p, y: f - p },
    { x: u + p, y: f },
    { x: u, y: f },
    { x: u, y: f + p }
  ], b = [
    { x: u, y: f + p },
    { x: u + s - p, y: f + p },
    { x: u + s - p, y: y.y - p },
    { x: u + s, y: y.y - p },
    { x: u + s, y: f },
    { x: u, y: f }
  ], _ = W.svg(n), S = H(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const w = rt(x), C = _.path(w, S), v = rt(b), D = _.path(v, S), R = n.insert(() => C, ":first-child");
  return R.insert(() => D), R.attr("class", "basic label-container"), g && t.look !== "handDrawn" && R.selectAll("path").attr("style", g), i && t.look !== "handDrawn" && R.selectAll("path").attr("style", i), R.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - p - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + p - c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, R), t.intersect = function(E) {
    return q.polygon(t, x, E);
  }, n;
}
d(kp, "multiWaveEdgedRectangle");
async function Sp(e, t, { config: { themeVariables: r } }) {
  var x;
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i, t.useHtmlLabels || ((x = Pt().flowchart) == null ? void 0 : x.htmlLabels) !== !1 || (t.centerLabel = !0);
  const { shapeSvg: o, bbox: s } = await Q(e, t, Z(t)), l = Math.max(s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = -l / 2, u = -c / 2, { cssStyles: f } = t, p = W.svg(o), g = H(t, {
    fill: r.noteBkgColor,
    stroke: r.noteBorderColor
  });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = p.rectangle(h, u, l, c, g), y = o.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), f && t.look !== "handDrawn" && y.selectAll("path").attr("style", f), n && t.look !== "handDrawn" && y.selectAll("path").attr("style", n), j(t, y), t.intersect = function(b) {
    return q.rect(t, b);
  }, o;
}
d(Sp, "note");
var Sw = /* @__PURE__ */ d((e, t, r) => [
  `M${e + r / 2},${t}`,
  `L${e + r},${t - r / 2}`,
  `L${e + r / 2},${t - r}`,
  `L${e},${t - r / 2}`,
  "Z"
].join(" "), "createDecisionBoxPathD");
async function Tp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = a.width + t.padding, s = a.height + t.padding, l = o + s, c = [
    { x: l / 2, y: 0 },
    { x: l, y: -l / 2 },
    { x: l / 2, y: -l },
    { x: 0, y: -l / 2 }
  ];
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const f = W.svg(n), p = H(t, {}), g = Sw(0, 0, l), m = f.path(g, p);
    h = n.insert(() => m, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`), u && h.attr("style", u);
  } else
    h = ye(n, l, l, c);
  return i && h.attr("style", i), j(t, h), t.intersect = function(f) {
    return F.debug(
      `APA12 Intersect called SPLIT
point:`,
      f,
      `
node:
`,
      t,
      `
res:`,
      q.polygon(t, c, f)
    ), q.polygon(t, c, f);
  }, n;
}
d(Tp, "question");
async function Bp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, u = h / 2, f = [
    { x: c + u, y: h },
    { x: c, y: 0 },
    { x: c + u, y: -h },
    { x: -c, y: -h },
    { x: -c, y: h }
  ], { cssStyles: p } = t, g = W.svg(n), m = H(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = rt(f), x = g.path(y, m), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container"), p && t.look !== "handDrawn" && b.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), b.attr("transform", `translate(${-u / 2},0)`), o.attr(
    "transform",
    `translate(${-u / 2 - a.width / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), j(t, b), t.intersect = function(_) {
    return q.polygon(t, f, _);
  }, n;
}
d(Bp, "rect_left_inv_arrow");
async function Lp(e, t) {
  var D, R;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  let n;
  t.cssClasses ? n = "node " + t.cssClasses : n = "node default";
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = a.insert("g"), s = a.insert("g").attr("class", "label").attr("style", i), l = t.description, c = t.label, h = s.node().appendChild(await Ie(c, t.labelStyle, !0, !0));
  let u = { width: 0, height: 0 };
  if (bt((R = (D = nt()) == null ? void 0 : D.flowchart) == null ? void 0 : R.htmlLabels)) {
    const E = h.children[0], A = et(h);
    u = E.getBoundingClientRect(), A.attr("width", u.width), A.attr("height", u.height);
  }
  F.info("Text 2", l);
  const f = l || [], p = h.getBBox(), g = s.node().appendChild(
    await Ie(
      f.join ? f.join("<br/>") : f,
      t.labelStyle,
      !0,
      !0
    )
  ), m = g.children[0], y = et(g);
  u = m.getBoundingClientRect(), y.attr("width", u.width), y.attr("height", u.height);
  const x = (t.padding || 0) / 2;
  et(g).attr(
    "transform",
    "translate( " + (u.width > p.width ? 0 : (p.width - u.width) / 2) + ", " + (p.height + x + 5) + ")"
  ), et(h).attr(
    "transform",
    "translate( " + (u.width < p.width ? 0 : -(p.width - u.width) / 2) + ", 0)"
  ), u = s.node().getBBox(), s.attr(
    "transform",
    "translate(" + -u.width / 2 + ", " + (-u.height / 2 - x + 3) + ")"
  );
  const b = u.width + (t.padding || 0), _ = u.height + (t.padding || 0), S = -u.width / 2 - x, w = -u.height / 2 - x;
  let C, v;
  if (t.look === "handDrawn") {
    const E = W.svg(a), A = H(t, {}), P = E.path(
      me(S, w, b, _, t.rx || 0),
      A
    ), O = E.line(
      -u.width / 2 - x,
      -u.height / 2 - x + p.height + x,
      u.width / 2 + x,
      -u.height / 2 - x + p.height + x,
      A
    );
    v = a.insert(() => (F.debug("Rough node insert CXC", P), O), ":first-child"), C = a.insert(() => (F.debug("Rough node insert CXC", P), P), ":first-child");
  } else
    C = o.insert("rect", ":first-child"), v = o.insert("line"), C.attr("class", "outer title-state").attr("style", i).attr("x", -u.width / 2 - x).attr("y", -u.height / 2 - x).attr("width", u.width + (t.padding || 0)).attr("height", u.height + (t.padding || 0)), v.attr("class", "divider").attr("x1", -u.width / 2 - x).attr("x2", u.width / 2 + x).attr("y1", -u.height / 2 - x + p.height + x).attr("y2", -u.height / 2 - x + p.height + x);
  return j(t, C), t.intersect = function(E) {
    return q.rect(t, E);
  }, a;
}
d(Lp, "rectWithTitle");
async function Mp(e, t) {
  const r = {
    rx: 5,
    ry: 5,
    labelPaddingX: ((t == null ? void 0 : t.padding) || 0) * 1,
    labelPaddingY: ((t == null ? void 0 : t.padding) || 0) * 1
  };
  return bi(e, t, r);
}
d(Mp, "roundedRect");
async function Ap(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = (t == null ? void 0 : t.padding) ?? 0, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = -a.width / 2 - s, u = -a.height / 2 - s, { cssStyles: f } = t, p = W.svg(n), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u },
    { x: h + l + 8, y: u },
    { x: h + l + 8, y: u + c },
    { x: h - 8, y: u + c },
    { x: h - 8, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container").attr("style", Et(f)), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-l / 2 + 4 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), j(t, x), t.intersect = function(b) {
    return q.rect(t, b);
  }, n;
}
d(Ap, "shadedProcess");
async function $p(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, { cssStyles: u } = t, f = W.svg(n), p = H(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: c, y: h },
    { x: c, y: h + l },
    { x: c + s, y: h + l },
    { x: c + s, y: h - l / 2 }
  ], m = rt(g), y = f.path(m, p), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), x.attr("transform", `translate(0, ${l / 4})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))}, ${-l / 4 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), j(t, x), t.intersect = function(b) {
    return q.polygon(t, g, b);
  }, n;
}
d($p, "slopedRect");
async function Fp(e, t) {
  const r = {
    rx: 0,
    ry: 0,
    labelPaddingX: ((t == null ? void 0 : t.padding) || 0) * 2,
    labelPaddingY: ((t == null ? void 0 : t.padding) || 0) * 1
  };
  return bi(e, t, r);
}
d(Fp, "squareRect");
async function Ep(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = a.height + t.padding, s = a.width + o / 4 + t.padding;
  let l;
  const { cssStyles: c } = t;
  if (t.look === "handDrawn") {
    const h = W.svg(n), u = H(t, {}), f = me(-s / 2, -o / 2, s, o, o / 2), p = h.path(f, u);
    l = n.insert(() => p, ":first-child"), l.attr("class", "basic label-container").attr("style", Et(c));
  } else
    l = n.insert("rect", ":first-child"), l.attr("class", "basic label-container").attr("style", i).attr("rx", o / 2).attr("ry", o / 2).attr("x", -s / 2).attr("y", -o / 2).attr("width", s).attr("height", o);
  return j(t, l), t.intersect = function(h) {
    return q.rect(t, h);
  }, n;
}
d(Ep, "stadium");
async function Op(e, t) {
  return bi(e, t, {
    rx: 5,
    ry: 5
  });
}
d(Op, "state");
function Dp(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i;
  const { cssStyles: a } = t, { lineColor: o, stateBorder: s, nodeBorder: l } = r, c = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), h = W.svg(c), u = H(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = h.circle(0, 0, 14, {
    ...u,
    stroke: o,
    strokeWidth: 2
  }), p = s ?? l, g = h.circle(0, 0, 5, {
    ...u,
    fill: p,
    stroke: p,
    strokeWidth: 2,
    fillStyle: "solid"
  }), m = c.insert(() => f, ":first-child");
  return m.insert(() => g), a && m.selectAll("path").attr("style", a), n && m.selectAll("path").attr("style", n), j(t, m), t.intersect = function(y) {
    return q.circle(t, 7, y);
  }, c;
}
d(Dp, "stateEnd");
function Rp(e, t, { config: { themeVariables: r } }) {
  const { lineColor: i } = r, n = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let a;
  if (t.look === "handDrawn") {
    const s = W.svg(n).circle(0, 0, 14, aw(i));
    a = n.insert(() => s), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  } else
    a = n.insert("circle", ":first-child"), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  return j(t, a), t.intersect = function(o) {
    return q.circle(t, 7, o);
  }, n;
}
d(Rp, "stateStart");
async function Ip(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = ((t == null ? void 0 : t.padding) || 0) / 2, s = a.width + t.padding, l = a.height + t.padding, c = -a.width / 2 - o, h = -a.height / 2 - o, u = [
    { x: 0, y: 0 },
    { x: s, y: 0 },
    { x: s, y: -l },
    { x: 0, y: -l },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: s + 8, y: 0 },
    { x: s + 8, y: -l },
    { x: -8, y: -l },
    { x: -8, y: 0 }
  ];
  if (t.look === "handDrawn") {
    const f = W.svg(n), p = H(t, {}), g = f.rectangle(c - 8, h, s + 16, l, p), m = f.line(c, h, c, h + l, p), y = f.line(c + s, h, c + s, h + l, p);
    n.insert(() => m, ":first-child"), n.insert(() => y, ":first-child");
    const x = n.insert(() => g, ":first-child"), { cssStyles: b } = t;
    x.attr("class", "basic label-container").attr("style", Et(b)), j(t, x);
  } else {
    const f = ye(n, s, l, u);
    i && f.attr("style", i), j(t, f);
  }
  return t.intersect = function(f) {
    return q.polygon(t, u, f);
  }, n;
}
d(Ip, "subroutine");
async function Pp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = -o / 2, c = -s / 2, h = 0.2 * s, u = 0.2 * s, { cssStyles: f } = t, p = W.svg(n), g = H(t, {}), m = [
    { x: l - h / 2, y: c },
    { x: l + o + h / 2, y: c },
    { x: l + o + h / 2, y: c + s },
    { x: l - h / 2, y: c + s }
  ], y = [
    { x: l + o - h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s - u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = rt(m), b = p.path(x, g), _ = rt(y), S = p.path(_, { ...g, fillStyle: "solid" }), w = n.insert(() => S, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), j(t, w), t.intersect = function(C) {
    return q.polygon(t, m, C);
  }, n;
}
d(Pp, "taggedRect");
async function Np(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = 0.2 * s, u = 0.2 * l, f = l + c, { cssStyles: p } = t, g = W.svg(n), m = H(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = [
    { x: -s / 2 - s / 2 * 0.1, y: f / 2 },
    ...Te(
      -s / 2 - s / 2 * 0.1,
      f / 2,
      s / 2 + s / 2 * 0.1,
      f / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -f / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -f / 2 }
  ], x = -s / 2 + s / 2 * 0.1, b = -f / 2 - u * 0.4, _ = [
    { x: x + s - h, y: (b + l) * 1.4 },
    { x: x + s, y: b + l - u },
    { x: x + s, y: (b + l) * 0.9 },
    ...Te(
      x + s,
      (b + l) * 1.3,
      x + s - h,
      (b + l) * 1.5,
      -l * 0.03,
      0.5
    )
  ], S = rt(y), w = g.path(S, m), C = rt(_), v = g.path(C, {
    ...m,
    fillStyle: "solid"
  }), D = n.insert(() => v, ":first-child");
  return D.insert(() => w, ":first-child"), D.attr("class", "basic label-container"), p && t.look !== "handDrawn" && D.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, D), t.intersect = function(R) {
    return q.polygon(t, y, R);
  }, n;
}
d(Np, "taggedWaveEdgedRectangle");
async function zp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = Math.max(a.width + t.padding, (t == null ? void 0 : t.width) || 0), s = Math.max(a.height + t.padding, (t == null ? void 0 : t.height) || 0), l = -o / 2, c = -s / 2, h = n.insert("rect", ":first-child");
  return h.attr("class", "text").attr("style", i).attr("rx", 0).attr("ry", 0).attr("x", l).attr("y", c).attr("width", o).attr("height", s), j(t, h), t.intersect = function(u) {
    return q.rect(t, u);
  }, n;
}
d(zp, "text");
var Tw = /* @__PURE__ */ d((e, t, r, i, n, a) => `M${e},${t}
    a${n},${a} 0,0,1 0,${-i}
    l${r},0
    a${n},${a} 0,0,1 0,${i}
    M${r},${-i}
    a${n},${a} 0,0,0 0,${i}
    l${-r},0`, "createCylinderPathD"), Bw = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t}`,
  `M${e + r},${t}`,
  `a${n},${a} 0,0,0 0,${-i}`,
  `l${-r},0`,
  `a${n},${a} 0,0,0 0,${i}`,
  `l${r},0`
].join(" "), "createOuterCylinderPathD"), Lw = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e + r / 2},${-i / 2}`, `a${n},${a} 0,0,0 0,${i}`].join(" "), "createInnerCylinderPathD");
async function qp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o, halfPadding: s } = await Q(
    e,
    t,
    Z(t)
  ), l = t.look === "neo" ? s * 2 : s, c = a.height + l, h = c / 2, u = h / (2.5 + c / 50), f = a.width + u + l, { cssStyles: p } = t;
  let g;
  if (t.look === "handDrawn") {
    const m = W.svg(n), y = Bw(0, 0, f, c, u, h), x = Lw(0, 0, f, c, u, h), b = m.path(y, H(t, {})), _ = m.path(x, H(t, { fill: "none" }));
    g = n.insert(() => _, ":first-child"), g = n.insert(() => b, ":first-child"), g.attr("class", "basic label-container"), p && g.attr("style", p);
  } else {
    const m = Tw(0, 0, f, c, u, h);
    g = n.insert("path", ":first-child").attr("d", m).attr("class", "basic label-container").attr("style", Et(p)).attr("style", i), g.attr("class", "basic label-container"), p && g.selectAll("path").attr("style", p), i && g.selectAll("path").attr("style", i);
  }
  return g.attr("label-offset-x", u), g.attr("transform", `translate(${-f / 2}, ${c / 2} )`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - u - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), j(t, g), t.intersect = function(m) {
    const y = q.rect(t, m), x = y.y - (t.y ?? 0);
    if (h != 0 && (Math.abs(x) < (t.height ?? 0) / 2 || Math.abs(x) == (t.height ?? 0) / 2 && Math.abs(y.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - u)) {
      let b = u * u * (1 - x * x / (h * h));
      b != 0 && (b = Math.sqrt(Math.abs(b))), b = u - b, m.x - (t.x ?? 0) > 0 && (b = -b), y.x += b;
    }
    return y;
  }, n;
}
d(qp, "tiltedCylinder");
async function Wp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = a.width + t.padding, s = a.height + t.padding, l = [
    { x: -3 * s / 6, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), p = rt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = ye(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return q.polygon(t, l, u);
  }, n;
}
d(Wp, "trapezoid");
async function Hp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = 60, s = 20, l = Math.max(o, a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), { cssStyles: h } = t, u = W.svg(n), f = H(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const p = [
    { x: -l / 2 * 0.8, y: -c / 2 },
    { x: l / 2 * 0.8, y: -c / 2 },
    { x: l / 2, y: -c / 2 * 0.6 },
    { x: l / 2, y: c / 2 },
    { x: -l / 2, y: c / 2 },
    { x: -l / 2, y: -c / 2 * 0.6 }
  ], g = rt(p), m = u.path(g, f), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectChildren("path").attr("style", h), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), j(t, y), t.intersect = function(x) {
    return q.polygon(t, p, x);
  }, n;
}
d(Hp, "trapezoidalPentagon");
async function jp(e, t) {
  var b;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = bt((b = nt().flowchart) == null ? void 0 : b.htmlLabels), l = a.width + (t.padding ?? 0), c = l + a.height, h = l + a.height, u = [
    { x: 0, y: 0 },
    { x: h, y: 0 },
    { x: h / 2, y: -c }
  ], { cssStyles: f } = t, p = W.svg(n), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = rt(u), y = p.path(m, g), x = n.insert(() => y, ":first-child").attr("transform", `translate(${-c / 2}, ${c / 2})`);
  return f && t.look !== "handDrawn" && x.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), t.width = l, t.height = c, j(t, x), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${c / 2 - (a.height + (t.padding ?? 0) / (s ? 2 : 1) - (a.y - (a.top ?? 0)))})`
  ), t.intersect = function(_) {
    return F.info("Triangle intersect", t, u, _), q.polygon(t, u, _);
  }, n;
}
d(jp, "triangle");
async function Yp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 8, h = l + c, { cssStyles: u } = t, p = 70 - s, g = p > 0 ? p / 2 : 0, m = W.svg(n), y = H(t, {});
  t.look !== "handDrawn" && (y.roughness = 0, y.fillStyle = "solid");
  const x = [
    { x: -s / 2 - g, y: h / 2 },
    ...Te(
      -s / 2 - g,
      h / 2,
      s / 2 + g,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + g, y: -h / 2 },
    { x: -s / 2 - g, y: -h / 2 }
  ], b = rt(x), _ = m.path(b, y), S = n.insert(() => _, ":first-child");
  return S.attr("class", "basic label-container"), u && t.look !== "handDrawn" && S.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && S.selectAll("path").attr("style", i), S.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c - (a.y - (a.top ?? 0))})`
  ), j(t, S), t.intersect = function(w) {
    return q.polygon(t, x, w);
  }, n;
}
d(Yp, "waveEdgedRectangle");
async function Gp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Q(e, t, Z(t)), o = 100, s = 50, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = l / c;
  let u = l, f = c;
  u > f * h ? f = u / h : u = f * h, u = Math.max(u, o), f = Math.max(f, s);
  const p = Math.min(f * 0.2, f / 4), g = f + p * 2, { cssStyles: m } = t, y = W.svg(n), x = H(t, {});
  t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid");
  const b = [
    { x: -u / 2, y: g / 2 },
    ...Te(-u / 2, g / 2, u / 2, g / 2, p, 1),
    { x: u / 2, y: -g / 2 },
    ...Te(u / 2, -g / 2, -u / 2, -g / 2, p, -1)
  ], _ = rt(b), S = y.path(_, x), w = n.insert(() => S, ":first-child");
  return w.attr("class", "basic label-container"), m && t.look !== "handDrawn" && w.selectAll("path").attr("style", m), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), j(t, w), t.intersect = function(C) {
    return q.polygon(t, b, C);
  }, n;
}
d(Gp, "waveRectangle");
async function Up(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Q(e, t, Z(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, p = W.svg(n), g = H(t, {}), m = [
    { x: h - c, y: u - c },
    { x: h - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u - c }
  ], y = `M${h - c},${u - c} L${h + s},${u - c} L${h + s},${u + l} L${h - c},${u + l} L${h - c},${u - c}
                M${h - c},${u} L${h + s},${u}
                M${h},${u - c} L${h},${u + l}`;
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = p.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("transform", `translate(${c / 2}, ${c / 2})`), b.attr("class", "basic label-container"), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) + c / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, b), t.intersect = function(_) {
    return q.polygon(t, m, _);
  }, n;
}
d(Up, "windowPane");
async function oo(e, t) {
  var lt, ft, yt, Mt;
  const r = t;
  if (r.alias && (t.label = r.alias), t.look === "handDrawn") {
    const { themeVariables: tt } = Pt(), { background: it } = tt, gt = {
      ...t,
      id: t.id + "-background",
      look: "default",
      cssStyles: ["stroke: none", `fill: ${it}`]
    };
    await oo(e, gt);
  }
  const i = Pt();
  t.useHtmlLabels = i.htmlLabels;
  let n = ((lt = i.er) == null ? void 0 : lt.diagramPadding) ?? 10, a = ((ft = i.er) == null ? void 0 : ft.entityPadding) ?? 6;
  const { cssStyles: o } = t, { labelStyles: s, nodeStyles: l } = Y(t);
  if (r.attributes.length === 0 && t.label) {
    const tt = {
      rx: 0,
      ry: 0,
      labelPaddingX: n,
      labelPaddingY: n * 1.5
    };
    de(t.label, i) + tt.labelPaddingX * 2 < i.er.minEntityWidth && (t.width = i.er.minEntityWidth);
    const it = await bi(e, t, tt);
    if (!bt(i.htmlLabels)) {
      const gt = it.select("text"), pt = (yt = gt.node()) == null ? void 0 : yt.getBBox();
      gt.attr("transform", `translate(${-pt.width / 2}, 0)`);
    }
    return it;
  }
  i.htmlLabels || (n *= 1.25, a *= 1.25);
  let c = Z(t);
  c || (c = "node default");
  const h = e.insert("g").attr("class", c).attr("id", t.domId || t.id), u = await tr(h, t.label ?? "", i, 0, 0, ["name"], s);
  u.height += a;
  let f = 0;
  const p = [], g = [];
  let m = 0, y = 0, x = 0, b = 0, _ = !0, S = !0;
  for (const tt of r.attributes) {
    const it = await tr(
      h,
      tt.type,
      i,
      0,
      f,
      ["attribute-type"],
      s
    );
    m = Math.max(m, it.width + n);
    const gt = await tr(
      h,
      tt.name,
      i,
      0,
      f,
      ["attribute-name"],
      s
    );
    y = Math.max(y, gt.width + n);
    const pt = await tr(
      h,
      tt.keys.join(),
      i,
      0,
      f,
      ["attribute-keys"],
      s
    );
    x = Math.max(x, pt.width + n);
    const ut = await tr(
      h,
      tt.comment,
      i,
      0,
      f,
      ["attribute-comment"],
      s
    );
    b = Math.max(b, ut.width + n);
    const _t = Math.max(it.height, gt.height, pt.height, ut.height) + a;
    g.push({ yOffset: f, rowHeight: _t }), f += _t;
  }
  let w = 4;
  x <= n && (_ = !1, x = 0, w--), b <= n && (S = !1, b = 0, w--);
  const C = h.node().getBBox();
  if (u.width + n * 2 - (m + y + x + b) > 0) {
    const tt = u.width + n * 2 - (m + y + x + b);
    m += tt / w, y += tt / w, x > 0 && (x += tt / w), b > 0 && (b += tt / w);
  }
  const v = m + y + x + b, D = W.svg(h), R = H(t, {});
  t.look !== "handDrawn" && (R.roughness = 0, R.fillStyle = "solid");
  let E = 0;
  g.length > 0 && (E = g.reduce((tt, it) => tt + ((it == null ? void 0 : it.rowHeight) ?? 0), 0));
  const A = Math.max(C.width + n * 2, (t == null ? void 0 : t.width) || 0, v), P = Math.max((E ?? 0) + u.height, (t == null ? void 0 : t.height) || 0), O = -A / 2, B = -P / 2;
  h.selectAll("g:not(:first-child)").each((tt, it, gt) => {
    const pt = et(gt[it]), ut = pt.attr("transform");
    let _t = 0, xe = 0;
    if (ut) {
      const Qn = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(ut);
      Qn && (_t = parseFloat(Qn[1]), xe = parseFloat(Qn[2]), pt.attr("class").includes("attribute-name") ? _t += m : pt.attr("class").includes("attribute-keys") ? _t += m + y : pt.attr("class").includes("attribute-comment") && (_t += m + y + x));
    }
    pt.attr(
      "transform",
      `translate(${O + n / 2 + _t}, ${xe + B + u.height + a / 2})`
    );
  }), h.select(".name").attr("transform", "translate(" + -u.width / 2 + ", " + (B + a / 2) + ")");
  const M = D.rectangle(O, B, A, P, R), T = h.insert(() => M, ":first-child").attr("style", o.join("")), { themeVariables: $ } = Pt(), { rowEven: L, rowOdd: N, nodeBorder: U } = $;
  p.push(0);
  for (const [tt, it] of g.entries()) {
    const pt = (tt + 1) % 2 === 0 && it.yOffset !== 0, ut = D.rectangle(O, u.height + B + (it == null ? void 0 : it.yOffset), A, it == null ? void 0 : it.rowHeight, {
      ...R,
      fill: pt ? L : N,
      stroke: U
    });
    h.insert(() => ut, "g.label").attr("style", o.join("")).attr("class", `row-rect-${pt ? "even" : "odd"}`);
  }
  let J = D.line(O, u.height + B, A + O, u.height + B, R);
  h.insert(() => J).attr("class", "divider"), J = D.line(m + O, u.height + B, m + O, P + B, R), h.insert(() => J).attr("class", "divider"), _ && (J = D.line(
    m + y + O,
    u.height + B,
    m + y + O,
    P + B,
    R
  ), h.insert(() => J).attr("class", "divider")), S && (J = D.line(
    m + y + x + O,
    u.height + B,
    m + y + x + O,
    P + B,
    R
  ), h.insert(() => J).attr("class", "divider"));
  for (const tt of p)
    J = D.line(
      O,
      u.height + B + tt,
      A + O,
      u.height + B + tt,
      R
    ), h.insert(() => J).attr("class", "divider");
  if (j(t, T), l && t.look !== "handDrawn") {
    const tt = l.split(";"), it = (Mt = tt == null ? void 0 : tt.filter((gt) => gt.includes("stroke"))) == null ? void 0 : Mt.map((gt) => `${gt}`).join("; ");
    h.selectAll("path").attr("style", it ?? ""), h.selectAll(".row-rect-even path").attr("style", l);
  }
  return t.intersect = function(tt) {
    return q.rect(t, tt);
  }, h;
}
d(oo, "erBox");
async function tr(e, t, r, i = 0, n = 0, a = [], o = "") {
  const s = e.insert("g").attr("class", `label ${a.join(" ")}`).attr("transform", `translate(${i}, ${n})`).attr("style", o);
  t !== go(t) && (t = go(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
  const l = s.node().appendChild(
    await Le(
      s,
      t,
      {
        width: de(t, r) + 100,
        style: o,
        useHtmlLabels: r.htmlLabels
      },
      r
    )
  );
  if (t.includes("&lt;") || t.includes("&gt;")) {
    let h = l.children[0];
    for (h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); h.childNodes[0]; )
      h = h.childNodes[0], h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
  }
  let c = l.getBBox();
  if (bt(r.htmlLabels)) {
    const h = l.children[0];
    h.style.textAlign = "start";
    const u = et(l);
    c = h.getBoundingClientRect(), u.attr("width", c.width), u.attr("height", c.height);
  }
  return c;
}
d(tr, "addText");
async function Xp(e, t, r, i, n = r.class.padding ?? 12) {
  const a = i ? 0 : 3, o = e.insert("g").attr("class", Z(t)).attr("id", t.domId || t.id);
  let s = null, l = null, c = null, h = null, u = 0, f = 0, p = 0;
  if (s = o.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    const b = t.annotations[0];
    await Hr(s, { text: `«${b}»` }, 0), u = s.node().getBBox().height;
  }
  l = o.insert("g").attr("class", "label-group text"), await Hr(l, t, 0, ["font-weight: bolder"]);
  const g = l.node().getBBox();
  f = g.height, c = o.insert("g").attr("class", "members-group text");
  let m = 0;
  for (const b of t.members) {
    const _ = await Hr(c, b, m, [b.parseClassifier()]);
    m += _ + a;
  }
  p = c.node().getBBox().height, p <= 0 && (p = n / 2), h = o.insert("g").attr("class", "methods-group text");
  let y = 0;
  for (const b of t.methods) {
    const _ = await Hr(h, b, y, [b.parseClassifier()]);
    y += _ + a;
  }
  let x = o.node().getBBox();
  if (s !== null) {
    const b = s.node().getBBox();
    s.attr("transform", `translate(${-b.width / 2})`);
  }
  return l.attr("transform", `translate(${-g.width / 2}, ${u})`), x = o.node().getBBox(), c.attr(
    "transform",
    `translate(0, ${u + f + n * 2})`
  ), x = o.node().getBBox(), h.attr(
    "transform",
    `translate(0, ${u + f + (p ? p + n * 4 : n * 2)})`
  ), x = o.node().getBBox(), { shapeSvg: o, bbox: x };
}
d(Xp, "textHelper");
async function Hr(e, t, r, i = []) {
  const n = e.insert("g").attr("class", "label").attr("style", i.join("; ")), a = Pt();
  let o = "useHtmlLabels" in t ? t.useHtmlLabels : bt(a.htmlLabels) ?? !0, s = "";
  "text" in t ? s = t.text : s = t.label, !o && s.startsWith("\\") && (s = s.substring(1)), yr(s) && (o = !0);
  const l = await Le(
    n,
    Mn(Ve(s)),
    {
      width: de(s, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o
    },
    a
  );
  let c, h = 1;
  if (o) {
    const u = l.children[0], f = et(l);
    h = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (h += u.innerHTML.split("<mrow>").length - 1);
    const p = u.getElementsByTagName("img");
    if (p) {
      const g = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...p].map(
          (m) => new Promise((y) => {
            function x() {
              var b;
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const _ = ((b = a.fontSize) == null ? void 0 : b.toString()) ?? window.getComputedStyle(document.body).fontSize, w = parseInt(_, 10) * 5 + "px";
                m.style.minWidth = w, m.style.maxWidth = w;
              } else
                m.style.width = "100%";
              y(m);
            }
            d(x, "setupImage"), setTimeout(() => {
              m.complete && x();
            }), m.addEventListener("error", x), m.addEventListener("load", x);
          })
        )
      );
    }
    c = u.getBoundingClientRect(), f.attr("width", c.width), f.attr("height", c.height);
  } else {
    i.includes("font-weight: bolder") && et(l).selectAll("tspan").attr("font-weight", ""), h = l.children.length;
    const u = l.children[0];
    (l.textContent === "" || l.textContent.includes("&gt")) && (u.textContent = s[0] + s.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), s[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), c = l.getBBox();
  }
  return n.attr("transform", "translate(0," + (-c.height / (2 * h) + r) + ")"), c.height;
}
d(Hr, "addText");
async function Vp(e, t) {
  var R, E;
  const r = nt(), i = r.class.padding ?? 12, n = i, a = t.useHtmlLabels ?? bt(r.htmlLabels) ?? !0, o = t;
  o.annotations = o.annotations ?? [], o.members = o.members ?? [], o.methods = o.methods ?? [];
  const { shapeSvg: s, bbox: l } = await Xp(e, t, r, a, n), { labelStyles: c, nodeStyles: h } = Y(t);
  t.labelStyle = c, t.cssStyles = o.styles || "";
  const u = ((R = o.styles) == null ? void 0 : R.join(";")) || h || "";
  t.cssStyles || (t.cssStyles = u.replaceAll("!important", "").split(";"));
  const f = o.members.length === 0 && o.methods.length === 0 && !((E = r.class) != null && E.hideEmptyMembersBox), p = W.svg(s), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = l.width;
  let y = l.height;
  o.members.length === 0 && o.methods.length === 0 ? y += n : o.members.length > 0 && o.methods.length === 0 && (y += n * 2);
  const x = -m / 2, b = -y / 2, _ = p.rectangle(
    x - i,
    b - i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0),
    m + 2 * i,
    y + 2 * i + (f ? i * 2 : o.members.length === 0 && o.methods.length === 0 ? -i : 0),
    g
  ), S = s.insert(() => _, ":first-child");
  S.attr("class", "basic label-container");
  const w = S.node().getBBox();
  s.selectAll(".text").each((A, P, O) => {
    var N;
    const B = et(O[P]), M = B.attr("transform");
    let T = 0;
    if (M) {
      const J = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(M);
      J && (T = parseFloat(J[2]));
    }
    let $ = T + b + i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0);
    a || ($ -= 4);
    let L = x;
    (B.attr("class").includes("label-group") || B.attr("class").includes("annotation-group")) && (L = -((N = B.node()) == null ? void 0 : N.getBBox().width) / 2 || 0, s.selectAll("text").each(function(U, J, lt) {
      window.getComputedStyle(lt[J]).textAnchor === "middle" && (L = 0);
    })), B.attr("transform", `translate(${L}, ${$})`);
  });
  const C = s.select(".annotation-group").node().getBBox().height - (f ? i / 2 : 0) || 0, v = s.select(".label-group").node().getBBox().height - (f ? i / 2 : 0) || 0, D = s.select(".members-group").node().getBBox().height - (f ? i / 2 : 0) || 0;
  if (o.members.length > 0 || o.methods.length > 0 || f) {
    const A = p.line(
      w.x,
      C + v + b + i,
      w.x + w.width,
      C + v + b + i,
      g
    );
    s.insert(() => A).attr("class", "divider").attr("style", u);
  }
  if (f || o.members.length > 0 || o.methods.length > 0) {
    const A = p.line(
      w.x,
      C + v + D + b + n * 2 + i,
      w.x + w.width,
      C + v + D + b + i + n * 2,
      g
    );
    s.insert(() => A).attr("class", "divider").attr("style", u);
  }
  if (o.look !== "handDrawn" && s.selectAll("path").attr("style", u), S.select(":nth-child(2)").attr("style", u), s.selectAll(".divider").select("path").attr("style", u), t.labelStyle ? s.selectAll("span").attr("style", t.labelStyle) : s.selectAll("span").attr("style", u), !a) {
    const A = RegExp(/color\s*:\s*([^;]*)/), P = A.exec(u);
    if (P) {
      const O = P[0].replace("color", "fill");
      s.selectAll("tspan").attr("style", O);
    } else if (c) {
      const O = A.exec(c);
      if (O) {
        const B = O[0].replace("color", "fill");
        s.selectAll("tspan").attr("style", B);
      }
    }
  }
  return j(t, S), t.intersect = function(A) {
    return q.rect(t, A);
  }, s;
}
d(Vp, "classBox");
async function Zp(e, t) {
  var C, v;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const n = t, a = t, o = 20, s = 20, l = "verifyMethod" in t, c = Z(t), h = e.insert("g").attr("class", c).attr("id", t.domId ?? t.id);
  let u;
  l ? u = await Kt(
    h,
    `&lt;&lt;${n.type}&gt;&gt;`,
    0,
    t.labelStyle
  ) : u = await Kt(h, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle);
  let f = u;
  const p = await Kt(
    h,
    n.name,
    f,
    t.labelStyle + "; font-weight: bold;"
  );
  if (f += p + s, l) {
    const D = await Kt(
      h,
      `${n.requirementId ? `id: ${n.requirementId}` : ""}`,
      f,
      t.labelStyle
    );
    f += D;
    const R = await Kt(
      h,
      `${n.text ? `Text: ${n.text}` : ""}`,
      f,
      t.labelStyle
    );
    f += R;
    const E = await Kt(
      h,
      `${n.risk ? `Risk: ${n.risk}` : ""}`,
      f,
      t.labelStyle
    );
    f += E, await Kt(
      h,
      `${n.verifyMethod ? `Verification: ${n.verifyMethod}` : ""}`,
      f,
      t.labelStyle
    );
  } else {
    const D = await Kt(
      h,
      `${a.type ? `Type: ${a.type}` : ""}`,
      f,
      t.labelStyle
    );
    f += D, await Kt(
      h,
      `${a.docRef ? `Doc Ref: ${a.docRef}` : ""}`,
      f,
      t.labelStyle
    );
  }
  const g = (((C = h.node()) == null ? void 0 : C.getBBox().width) ?? 200) + o, m = (((v = h.node()) == null ? void 0 : v.getBBox().height) ?? 200) + o, y = -g / 2, x = -m / 2, b = W.svg(h), _ = H(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const S = b.rectangle(y, x, g, m, _), w = h.insert(() => S, ":first-child");
  if (w.attr("class", "basic label-container").attr("style", i), h.selectAll(".label").each((D, R, E) => {
    const A = et(E[R]), P = A.attr("transform");
    let O = 0, B = 0;
    if (P) {
      const L = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(P);
      L && (O = parseFloat(L[1]), B = parseFloat(L[2]));
    }
    const M = B - m / 2;
    let T = y + o / 2;
    (R === 0 || R === 1) && (T = O), A.attr("transform", `translate(${T}, ${M + o})`);
  }), f > u + p + s) {
    const D = b.line(
      y,
      x + u + p + s,
      y + g,
      x + u + p + s,
      _
    );
    h.insert(() => D).attr("style", i);
  }
  return j(t, w), t.intersect = function(D) {
    return q.rect(t, D);
  }, h;
}
d(Zp, "requirementBox");
async function Kt(e, t, r, i = "") {
  if (t === "")
    return 0;
  const n = e.insert("g").attr("class", "label").attr("style", i), a = nt(), o = a.htmlLabels ?? !0, s = await Le(
    n,
    Mn(Ve(t)),
    {
      width: de(t, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o,
      style: i
    },
    a
  );
  let l;
  if (o) {
    const c = s.children[0], h = et(s);
    l = c.getBoundingClientRect(), h.attr("width", l.width), h.attr("height", l.height);
  } else {
    const c = s.children[0];
    for (const h of c.children)
      h.textContent = h.textContent.replaceAll("&gt;", ">").replaceAll("&lt;", "<"), i && h.setAttribute("style", i);
    l = s.getBBox(), l.height += 6;
  }
  return n.attr("transform", `translate(${-l.width / 2},${-l.height / 2 + r})`), l.height;
}
d(Kt, "addText");
var Mw = /* @__PURE__ */ d((e) => {
  switch (e) {
    case "Very High":
      return "red";
    case "High":
      return "orange";
    case "Medium":
      return null;
    case "Low":
      return "blue";
    case "Very Low":
      return "lightblue";
  }
}, "colorFromPriority");
async function Kp(e, t, { config: r }) {
  var P, O;
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i || "";
  const a = 10, o = t.width;
  t.width = (t.width ?? 200) - 10;
  const {
    shapeSvg: s,
    bbox: l,
    label: c
  } = await Q(e, t, Z(t)), h = t.padding || 10;
  let u = "", f;
  "ticket" in t && t.ticket && ((P = r == null ? void 0 : r.kanban) != null && P.ticketBaseUrl) && (u = (O = r == null ? void 0 : r.kanban) == null ? void 0 : O.ticketBaseUrl.replace("#TICKET#", t.ticket), f = s.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank"));
  const p = {
    useHtmlLabels: t.useHtmlLabels,
    labelStyle: t.labelStyle || "",
    width: t.width,
    img: t.img,
    padding: t.padding || 8,
    centerLabel: !1
  };
  let g, m;
  f ? { label: g, bbox: m } = await ua(
    f,
    "ticket" in t && t.ticket || "",
    p
  ) : { label: g, bbox: m } = await ua(
    s,
    "ticket" in t && t.ticket || "",
    p
  );
  const { label: y, bbox: x } = await ua(
    s,
    "assigned" in t && t.assigned || "",
    p
  );
  t.width = o;
  const b = 10, _ = (t == null ? void 0 : t.width) || 0, S = Math.max(m.height, x.height) / 2, w = Math.max(l.height + b * 2, (t == null ? void 0 : t.height) || 0) + S, C = -_ / 2, v = -w / 2;
  c.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-S - l.height / 2) + ")"
  ), g.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-S + l.height / 2) + ")"
  ), y.attr(
    "transform",
    "translate(" + (h + _ / 2 - x.width - 2 * a) + ", " + (-S + l.height / 2) + ")"
  );
  let D;
  const { rx: R, ry: E } = t, { cssStyles: A } = t;
  if (t.look === "handDrawn") {
    const B = W.svg(s), M = H(t, {}), T = R || E ? B.path(me(C, v, _, w, R || 0), M) : B.rectangle(C, v, _, w, M);
    D = s.insert(() => T, ":first-child"), D.attr("class", "basic label-container").attr("style", A || null);
  } else {
    D = s.insert("rect", ":first-child"), D.attr("class", "basic label-container __APA__").attr("style", n).attr("rx", R ?? 5).attr("ry", E ?? 5).attr("x", C).attr("y", v).attr("width", _).attr("height", w);
    const B = "priority" in t && t.priority;
    if (B) {
      const M = s.append("line"), T = C + 2, $ = v + Math.floor((R ?? 0) / 2), L = v + w - Math.floor((R ?? 0) / 2);
      M.attr("x1", T).attr("y1", $).attr("x2", T).attr("y2", L).attr("stroke-width", "4").attr("stroke", Mw(B));
    }
  }
  return j(t, D), t.height = w, t.intersect = function(B) {
    return q.rect(t, B);
  }, s;
}
d(Kp, "kanbanItem");
var Aw = [
  {
    semanticName: "Process",
    name: "Rectangle",
    shortName: "rect",
    description: "Standard process shape",
    aliases: ["proc", "process", "rectangle"],
    internalAliases: ["squareRect"],
    handler: Fp
  },
  {
    semanticName: "Event",
    name: "Rounded Rectangle",
    shortName: "rounded",
    description: "Represents an event",
    aliases: ["event"],
    internalAliases: ["roundedRect"],
    handler: Mp
  },
  {
    semanticName: "Terminal Point",
    name: "Stadium",
    shortName: "stadium",
    description: "Terminal point",
    aliases: ["terminal", "pill"],
    handler: Ep
  },
  {
    semanticName: "Subprocess",
    name: "Framed Rectangle",
    shortName: "fr-rect",
    description: "Subprocess",
    aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"],
    handler: Ip
  },
  {
    semanticName: "Database",
    name: "Cylinder",
    shortName: "cyl",
    description: "Database storage",
    aliases: ["db", "database", "cylinder"],
    handler: rp
  },
  {
    semanticName: "Start",
    name: "Circle",
    shortName: "circle",
    description: "Starting point",
    aliases: ["circ"],
    handler: Vf
  },
  {
    semanticName: "Decision",
    name: "Diamond",
    shortName: "diam",
    description: "Decision-making step",
    aliases: ["decision", "diamond", "question"],
    handler: Tp
  },
  {
    semanticName: "Prepare Conditional",
    name: "Hexagon",
    shortName: "hex",
    description: "Preparation or condition step",
    aliases: ["hexagon", "prepare"],
    handler: cp
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Right",
    shortName: "lean-r",
    description: "Represents input or output",
    aliases: ["lean-right", "in-out"],
    internalAliases: ["lean_right"],
    handler: bp
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Left",
    shortName: "lean-l",
    description: "Represents output or input",
    aliases: ["lean-left", "out-in"],
    internalAliases: ["lean_left"],
    handler: xp
  },
  {
    semanticName: "Priority Action",
    name: "Trapezoid Base Bottom",
    shortName: "trap-b",
    description: "Priority action",
    aliases: ["priority", "trapezoid-bottom", "trapezoid"],
    handler: Wp
  },
  {
    semanticName: "Manual Operation",
    name: "Trapezoid Base Top",
    shortName: "trap-t",
    description: "Represents a manual task",
    aliases: ["manual", "trapezoid-top", "inv-trapezoid"],
    internalAliases: ["inv_trapezoid"],
    handler: mp
  },
  {
    semanticName: "Stop",
    name: "Double Circle",
    shortName: "dbl-circ",
    description: "Represents a stop point",
    aliases: ["double-circle"],
    internalAliases: ["doublecircle"],
    handler: np
  },
  {
    semanticName: "Text Block",
    name: "Text Block",
    shortName: "text",
    description: "Text block",
    handler: zp
  },
  {
    semanticName: "Card",
    name: "Notched Rectangle",
    shortName: "notch-rect",
    description: "Represents a card",
    aliases: ["card", "notched-rectangle"],
    handler: Uf
  },
  {
    semanticName: "Lined/Shaded Process",
    name: "Lined Rectangle",
    shortName: "lin-rect",
    description: "Lined process shape",
    aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"],
    handler: Ap
  },
  {
    semanticName: "Start",
    name: "Small Circle",
    shortName: "sm-circ",
    description: "Small starting point",
    aliases: ["start", "small-circle"],
    internalAliases: ["stateStart"],
    handler: Rp
  },
  {
    semanticName: "Stop",
    name: "Framed Circle",
    shortName: "fr-circ",
    description: "Stop point",
    aliases: ["stop", "framed-circle"],
    internalAliases: ["stateEnd"],
    handler: Dp
  },
  {
    semanticName: "Fork/Join",
    name: "Filled Rectangle",
    shortName: "fork",
    description: "Fork or join in process flow",
    aliases: ["join"],
    internalAliases: ["forkJoin"],
    handler: op
  },
  {
    semanticName: "Collate",
    name: "Hourglass",
    shortName: "hourglass",
    description: "Represents a collate operation",
    aliases: ["hourglass", "collate"],
    handler: hp
  },
  {
    semanticName: "Comment",
    name: "Curly Brace",
    shortName: "brace",
    description: "Adds a comment",
    aliases: ["comment", "brace-l"],
    handler: Qf
  },
  {
    semanticName: "Comment Right",
    name: "Curly Brace",
    shortName: "brace-r",
    description: "Adds a comment",
    handler: Jf
  },
  {
    semanticName: "Comment with braces on both sides",
    name: "Curly Braces",
    shortName: "braces",
    description: "Adds a comment",
    handler: tp
  },
  {
    semanticName: "Com Link",
    name: "Lightning Bolt",
    shortName: "bolt",
    description: "Communication link",
    aliases: ["com-link", "lightning-bolt"],
    handler: Cp
  },
  {
    semanticName: "Document",
    name: "Document",
    shortName: "doc",
    description: "Represents a document",
    aliases: ["doc", "document"],
    handler: Yp
  },
  {
    semanticName: "Delay",
    name: "Half-Rounded Rectangle",
    shortName: "delay",
    description: "Represents a delay",
    aliases: ["half-rounded-rectangle"],
    handler: lp
  },
  {
    semanticName: "Direct Access Storage",
    name: "Horizontal Cylinder",
    shortName: "h-cyl",
    description: "Direct access storage",
    aliases: ["das", "horizontal-cylinder"],
    handler: qp
  },
  {
    semanticName: "Disk Storage",
    name: "Lined Cylinder",
    shortName: "lin-cyl",
    description: "Disk storage",
    aliases: ["disk", "lined-cylinder"],
    handler: _p
  },
  {
    semanticName: "Display",
    name: "Curved Trapezoid",
    shortName: "curv-trap",
    description: "Represents a display",
    aliases: ["curved-trapezoid", "display"],
    handler: ep
  },
  {
    semanticName: "Divided Process",
    name: "Divided Rectangle",
    shortName: "div-rect",
    description: "Divided process shape",
    aliases: ["div-proc", "divided-rectangle", "divided-process"],
    handler: ip
  },
  {
    semanticName: "Extract",
    name: "Triangle",
    shortName: "tri",
    description: "Extraction process",
    aliases: ["extract", "triangle"],
    handler: jp
  },
  {
    semanticName: "Internal Storage",
    name: "Window Pane",
    shortName: "win-pane",
    description: "Internal storage",
    aliases: ["internal-storage", "window-pane"],
    handler: Up
  },
  {
    semanticName: "Junction",
    name: "Filled Circle",
    shortName: "f-circ",
    description: "Junction point",
    aliases: ["junction", "filled-circle"],
    handler: ap
  },
  {
    semanticName: "Loop Limit",
    name: "Trapezoidal Pentagon",
    shortName: "notch-pent",
    description: "Loop limit step",
    aliases: ["loop-limit", "notched-pentagon"],
    handler: Hp
  },
  {
    semanticName: "Manual File",
    name: "Flipped Triangle",
    shortName: "flip-tri",
    description: "Manual file operation",
    aliases: ["manual-file", "flipped-triangle"],
    handler: sp
  },
  {
    semanticName: "Manual Input",
    name: "Sloped Rectangle",
    shortName: "sl-rect",
    description: "Manual input step",
    aliases: ["manual-input", "sloped-rectangle"],
    handler: $p
  },
  {
    semanticName: "Multi-Document",
    name: "Stacked Document",
    shortName: "docs",
    description: "Multiple documents",
    aliases: ["documents", "st-doc", "stacked-document"],
    handler: kp
  },
  {
    semanticName: "Multi-Process",
    name: "Stacked Rectangle",
    shortName: "st-rect",
    description: "Multiple processes",
    aliases: ["procs", "processes", "stacked-rectangle"],
    handler: vp
  },
  {
    semanticName: "Stored Data",
    name: "Bow Tie Rectangle",
    shortName: "bow-rect",
    description: "Stored data",
    aliases: ["stored-data", "bow-tie-rectangle"],
    handler: Gf
  },
  {
    semanticName: "Summary",
    name: "Crossed Circle",
    shortName: "cross-circ",
    description: "Summary",
    aliases: ["summary", "crossed-circle"],
    handler: Kf
  },
  {
    semanticName: "Tagged Document",
    name: "Tagged Document",
    shortName: "tag-doc",
    description: "Tagged document",
    aliases: ["tag-doc", "tagged-document"],
    handler: Np
  },
  {
    semanticName: "Tagged Process",
    name: "Tagged Rectangle",
    shortName: "tag-rect",
    description: "Tagged process",
    aliases: ["tagged-rectangle", "tag-proc", "tagged-process"],
    handler: Pp
  },
  {
    semanticName: "Paper Tape",
    name: "Flag",
    shortName: "flag",
    description: "Paper tape",
    aliases: ["paper-tape"],
    handler: Gp
  },
  {
    semanticName: "Odd",
    name: "Odd",
    shortName: "odd",
    description: "Odd shape",
    internalAliases: ["rect_left_inv_arrow"],
    handler: Bp
  },
  {
    semanticName: "Lined Document",
    name: "Lined Document",
    shortName: "lin-doc",
    description: "Lined document",
    aliases: ["lined-document"],
    handler: wp
  }
], $w = /* @__PURE__ */ d(() => {
  const t = [
    ...Object.entries({
      // States
      state: Op,
      choice: Xf,
      note: Sp,
      // Rectangles
      rectWithTitle: Lp,
      labelRect: yp,
      // Icons
      iconSquare: dp,
      iconCircle: fp,
      icon: up,
      iconRounded: pp,
      imageSquare: gp,
      anchor: Yf,
      // Kanban diagram
      kanbanItem: Kp,
      // class diagram
      classBox: Vp,
      // er diagram
      erBox: oo,
      // Requirement diagram
      requirementBox: Zp
    }),
    ...Aw.flatMap((r) => [
      r.shortName,
      ..."aliases" in r ? r.aliases : [],
      ..."internalAliases" in r ? r.internalAliases : []
    ].map((n) => [n, r.handler]))
  ];
  return Object.fromEntries(t);
}, "generateShapeMap"), Qp = $w();
function Fw(e) {
  return e in Qp;
}
d(Fw, "isValidShape");
var Xn = /* @__PURE__ */ new Map();
async function Jp(e, t, r) {
  let i, n;
  t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect");
  const a = t.shape ? Qp[t.shape] : void 0;
  if (!a)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`);
  if (t.link) {
    let o;
    r.config.securityLevel === "sandbox" ? o = "_top" : t.linkTarget && (o = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", o ?? null), n = await a(i, t, r);
  } else
    n = await a(e, t, r), i = n;
  return t.tooltip && n.attr("title", t.tooltip), Xn.set(t.id, i), t.haveCallback && i.attr("class", i.attr("class") + " clickable"), i;
}
d(Jp, "insertNode");
var OT = /* @__PURE__ */ d((e, t) => {
  Xn.set(t.id, e);
}, "setNodeElem"), DT = /* @__PURE__ */ d(() => {
  Xn.clear();
}, "clear"), RT = /* @__PURE__ */ d((e) => {
  const t = Xn.get(e.id);
  F.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const r = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - r) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode"), Ew = /* @__PURE__ */ d((e, t, r, i, n, a) => {
  t.arrowTypeStart && Cl(e, "start", t.arrowTypeStart, r, i, n, a), t.arrowTypeEnd && Cl(e, "end", t.arrowTypeEnd, r, i, n, a);
}, "addEdgeMarkers"), Ow = {
  arrow_cross: { type: "cross", fill: !1 },
  arrow_point: { type: "point", fill: !0 },
  arrow_barb: { type: "barb", fill: !0 },
  arrow_circle: { type: "circle", fill: !1 },
  aggregation: { type: "aggregation", fill: !1 },
  extension: { type: "extension", fill: !1 },
  composition: { type: "composition", fill: !0 },
  dependency: { type: "dependency", fill: !0 },
  lollipop: { type: "lollipop", fill: !1 },
  only_one: { type: "onlyOne", fill: !1 },
  zero_or_one: { type: "zeroOrOne", fill: !1 },
  one_or_more: { type: "oneOrMore", fill: !1 },
  zero_or_more: { type: "zeroOrMore", fill: !1 },
  requirement_arrow: { type: "requirement_arrow", fill: !1 },
  requirement_contains: { type: "requirement_contains", fill: !1 }
}, Cl = /* @__PURE__ */ d((e, t, r, i, n, a, o) => {
  var u;
  const s = Ow[r];
  if (!s) {
    F.warn(`Unknown arrow type: ${r}`);
    return;
  }
  const l = s.type, h = `${n}_${a}-${l}${t === "start" ? "Start" : "End"}`;
  if (o && o.trim() !== "") {
    const f = o.replace(/[^\dA-Za-z]/g, "_"), p = `${h}_${f}`;
    if (!document.getElementById(p)) {
      const g = document.getElementById(h);
      if (g) {
        const m = g.cloneNode(!0);
        m.id = p, m.querySelectorAll("path, circle, line").forEach((x) => {
          x.setAttribute("stroke", o), s.fill && x.setAttribute("fill", o);
        }), (u = g.parentNode) == null || u.appendChild(m);
      }
    }
    e.attr(`marker-${t}`, `url(${i}#${p})`);
  } else
    e.attr(`marker-${t}`, `url(${i}#${h})`);
}, "addEdgeMarker"), vn = /* @__PURE__ */ new Map(), vt = /* @__PURE__ */ new Map(), IT = /* @__PURE__ */ d(() => {
  vn.clear(), vt.clear();
}, "clear"), Ir = /* @__PURE__ */ d((e) => e ? e.reduce((r, i) => r + ";" + i, "") : "", "getLabelStyles"), Dw = /* @__PURE__ */ d(async (e, t) => {
  let r = bt(nt().flowchart.htmlLabels);
  const i = await Le(e, t.label, {
    style: Ir(t.labelStyle),
    useHtmlLabels: r,
    addSvgBackground: !0,
    isNode: !1
  });
  F.info("abc82", t, t.labelType);
  const n = e.insert("g").attr("class", "edgeLabel"), a = n.insert("g").attr("class", "label");
  a.node().appendChild(i);
  let o = i.getBBox();
  if (r) {
    const l = i.children[0], c = et(i);
    o = l.getBoundingClientRect(), c.attr("width", o.width), c.attr("height", o.height);
  }
  a.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), vn.set(t.id, n), t.width = o.width, t.height = o.height;
  let s;
  if (t.startLabelLeft) {
    const l = await Ie(
      t.startLabelLeft,
      Ir(t.labelStyle)
    ), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), vt.get(t.id) || vt.set(t.id, {}), vt.get(t.id).startLeft = c, jr(s, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const l = await Ie(
      t.startLabelRight,
      Ir(t.labelStyle)
    ), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = c.node().appendChild(l), h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), vt.get(t.id) || vt.set(t.id, {}), vt.get(t.id).startRight = c, jr(s, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const l = await Ie(t.endLabelLeft, Ir(t.labelStyle)), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), c.node().appendChild(l), vt.get(t.id) || vt.set(t.id, {}), vt.get(t.id).endLeft = c, jr(s, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const l = await Ie(t.endLabelRight, Ir(t.labelStyle)), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), c.node().appendChild(l), vt.get(t.id) || vt.set(t.id, {}), vt.get(t.id).endRight = c, jr(s, t.endLabelRight);
  }
  return i;
}, "insertEdgeLabel");
function jr(e, t) {
  nt().flowchart.htmlLabels && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
d(jr, "setTerminalWidth");
var Rw = /* @__PURE__ */ d((e, t) => {
  F.debug("Moving label abc88 ", e.id, e.label, vn.get(e.id), t);
  let r = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = nt(), { subGraphTitleTotalMargin: n } = ks(i);
  if (e.label) {
    const a = vn.get(e.id);
    let o = e.x, s = e.y;
    if (r) {
      const l = Jt.calcLabelPosition(r);
      F.debug(
        "Moving label " + e.label + " from (",
        o,
        ",",
        s,
        ") to (",
        l.x,
        ",",
        l.y,
        ") abc88"
      ), t.updatedPath && (o = l.x, s = l.y);
    }
    a.attr("transform", `translate(${o}, ${s + n / 2})`);
  }
  if (e.startLabelLeft) {
    const a = vt.get(e.id).startLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = Jt.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.startLabelRight) {
    const a = vt.get(e.id).startRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = Jt.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        r
      );
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelLeft) {
    const a = vt.get(e.id).endLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = Jt.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelRight) {
    const a = vt.get(e.id).endRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = Jt.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
}, "positionEdgeLabel"), Iw = /* @__PURE__ */ d((e, t) => {
  const r = e.x, i = e.y, n = Math.abs(t.x - r), a = Math.abs(t.y - i), o = e.width / 2, s = e.height / 2;
  return n >= o || a >= s;
}, "outsideNode"), Pw = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(r)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, n = e.y, a = Math.abs(i - r.x), o = e.width / 2;
  let s = r.x < t.x ? o - a : o + a;
  const l = e.height / 2, c = Math.abs(t.y - r.y), h = Math.abs(t.x - r.x);
  if (Math.abs(n - t.y) * o > Math.abs(i - t.x) * l) {
    let u = r.y < t.y ? t.y - l - n : n - l - t.y;
    s = h * u / c;
    const f = {
      x: r.x < t.x ? r.x + s : r.x - h + s,
      y: r.y < t.y ? r.y + c - u : r.y - c + u
    };
    return s === 0 && (f.x = t.x, f.y = t.y), h === 0 && (f.x = t.x), c === 0 && (f.y = t.y), F.debug(`abc89 top/bottom calc, Q ${c}, q ${u}, R ${h}, r ${s}`, f), f;
  } else {
    r.x < t.x ? s = t.x - o - i : s = i - o - t.x;
    let u = c * s / h, f = r.x < t.x ? r.x + h - s : r.x - h + s, p = r.y < t.y ? r.y + u : r.y - u;
    return F.debug(`sides calc abc89, Q ${c}, q ${u}, R ${h}, r ${s}`, { _x: f, _y: p }), s === 0 && (f = t.x, p = t.y), h === 0 && (f = t.x), c === 0 && (p = t.y), { x: f, y: p };
  }
}, "intersection"), _l = /* @__PURE__ */ d((e, t) => {
  F.warn("abc88 cutPathAtIntersect", e, t);
  let r = [], i = e[0], n = !1;
  return e.forEach((a) => {
    if (F.info("abc88 checking point", a, t), !Iw(t, a) && !n) {
      const o = Pw(t, i, a);
      F.debug("abc88 inside", a, i, o), F.debug("abc88 intersection", o, t);
      let s = !1;
      r.forEach((l) => {
        s = s || l.x === o.x && l.y === o.y;
      }), r.some((l) => l.x === o.x && l.y === o.y) ? F.warn("abc88 no intersect", o, r) : r.push(o), n = !0;
    } else
      F.warn("abc88 outside", a, i), i = a, n || r.push(a);
  }), F.debug("returning points", r), r;
}, "cutPathAtIntersect");
function td(e) {
  const t = [], r = [];
  for (let i = 1; i < e.length - 1; i++) {
    const n = e[i - 1], a = e[i], o = e[i + 1];
    (n.x === a.x && a.y === o.y && Math.abs(a.x - o.x) > 5 && Math.abs(a.y - n.y) > 5 || n.y === a.y && a.x === o.x && Math.abs(a.x - n.x) > 5 && Math.abs(a.y - o.y) > 5) && (t.push(a), r.push(i));
  }
  return { cornerPoints: t, cornerPointPositions: r };
}
d(td, "extractCornerPoints");
var wl = /* @__PURE__ */ d(function(e, t, r) {
  const i = t.x - e.x, n = t.y - e.y, a = Math.sqrt(i * i + n * n), o = r / a;
  return { x: t.x - o * i, y: t.y - o * n };
}, "findAdjacentPoint"), Nw = /* @__PURE__ */ d(function(e) {
  const { cornerPointPositions: t } = td(e), r = [];
  for (let i = 0; i < e.length; i++)
    if (t.includes(i)) {
      const n = e[i - 1], a = e[i + 1], o = e[i], s = wl(n, o, 5), l = wl(a, o, 5), c = l.x - s.x, h = l.y - s.y;
      r.push(s);
      const u = Math.sqrt(2) * 2;
      let f = { x: o.x, y: o.y };
      if (Math.abs(a.x - n.x) > 10 && Math.abs(a.y - n.y) >= 10) {
        F.debug(
          "Corner point fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
        const p = 5;
        o.x === s.x ? f = {
          x: c < 0 ? s.x - p + u : s.x + p - u,
          y: h < 0 ? s.y - u : s.y + u
        } : f = {
          x: c < 0 ? s.x - u : s.x + u,
          y: h < 0 ? s.y - p + u : s.y + p - u
        };
      } else
        F.debug(
          "Corner point skipping fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
      r.push(f, l);
    } else
      r.push(e[i]);
  return r;
}, "fixCorners"), zw = /* @__PURE__ */ d(function(e, t, r, i, n, a, o) {
  var R;
  const { handDrawnSeed: s } = nt();
  let l = t.points, c = !1;
  const h = n;
  var u = a;
  const f = [];
  for (const E in t.cssCompiledStyles)
    Rf(E) || f.push(t.cssCompiledStyles[E]);
  u.intersect && h.intersect && (l = l.slice(1, t.points.length - 1), l.unshift(h.intersect(l[0])), F.debug(
    "Last point APA12",
    t.start,
    "-->",
    t.end,
    l[l.length - 1],
    u,
    u.intersect(l[l.length - 1])
  ), l.push(u.intersect(l[l.length - 1]))), t.toCluster && (F.info("to cluster abc88", r.get(t.toCluster)), l = _l(t.points, r.get(t.toCluster).node), c = !0), t.fromCluster && (F.debug(
    "from cluster abc88",
    r.get(t.fromCluster),
    JSON.stringify(l, null, 2)
  ), l = _l(l.reverse(), r.get(t.fromCluster).node).reverse(), c = !0);
  let p = l.filter((E) => !Number.isNaN(E.y));
  p = Nw(p);
  let g = Ri;
  switch (g = sn, t.curve) {
    case "linear":
      g = sn;
      break;
    case "basis":
      g = Ri;
      break;
    case "cardinal":
      g = bu;
      break;
    case "bumpX":
      g = du;
      break;
    case "bumpY":
      g = gu;
      break;
    case "catmullRom":
      g = _u;
      break;
    case "monotoneX":
      g = Bu;
      break;
    case "monotoneY":
      g = Lu;
      break;
    case "natural":
      g = Au;
      break;
    case "step":
      g = $u;
      break;
    case "stepAfter":
      g = Eu;
      break;
    case "stepBefore":
      g = Fu;
      break;
    default:
      g = Ri;
  }
  const { x: m, y } = lm(t), x = Ob().x(m).y(y).curve(g);
  let b;
  switch (t.thickness) {
    case "normal":
      b = "edge-thickness-normal";
      break;
    case "thick":
      b = "edge-thickness-thick";
      break;
    case "invisible":
      b = "edge-thickness-invisible";
      break;
    default:
      b = "edge-thickness-normal";
  }
  switch (t.pattern) {
    case "solid":
      b += " edge-pattern-solid";
      break;
    case "dotted":
      b += " edge-pattern-dotted";
      break;
    case "dashed":
      b += " edge-pattern-dashed";
      break;
    default:
      b += " edge-pattern-solid";
  }
  let _, S = x(p);
  const w = Array.isArray(t.style) ? t.style : t.style ? [t.style] : [];
  let C = w.find((E) => E == null ? void 0 : E.startsWith("stroke:"));
  if (t.look === "handDrawn") {
    const E = W.svg(e);
    Object.assign([], p);
    const A = E.path(S, {
      roughness: 0.3,
      seed: s
    });
    b += " transition", _ = et(A).select("path").attr("id", t.id).attr("class", " " + b + (t.classes ? " " + t.classes : "")).attr("style", w ? w.reduce((O, B) => O + ";" + B, "") : "");
    let P = _.attr("d");
    _.attr("d", P), e.node().appendChild(_.node());
  } else {
    const E = f.join(";"), A = w ? w.reduce((B, M) => B + M + ";", "") : "";
    let P = "";
    t.animate && (P = " edge-animation-fast"), t.animation && (P = " edge-animation-" + t.animation);
    const O = E ? E + ";" + A + ";" : A;
    _ = e.append("path").attr("d", S).attr("id", t.id).attr(
      "class",
      " " + b + (t.classes ? " " + t.classes : "") + (P ?? "")
    ).attr("style", O), C = (R = O.match(/stroke:([^;]+)/)) == null ? void 0 : R[1];
  }
  let v = "";
  (nt().flowchart.arrowMarkerAbsolute || nt().state.arrowMarkerAbsolute) && (v = tc(!0)), F.info("arrowTypeStart", t.arrowTypeStart), F.info("arrowTypeEnd", t.arrowTypeEnd), Ew(_, t, v, o, i, C);
  let D = {};
  return c && (D.updatedPath = l), D.originalPath = t.points, D;
}, "insertEdge"), qw = /* @__PURE__ */ d((e, t, r, i) => {
  t.forEach((n) => {
    iv[n](e, r, i);
  });
}, "insertMarkers"), Ww = /* @__PURE__ */ d((e, t, r) => {
  F.trace("Making markers for ", r), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), Hw = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), jw = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), Yw = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), Gw = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), Uw = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), Xw = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), Vw = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), Zw = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), Kw = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18");
}, "only_one"), Qw = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), n.append("path").attr("d", "M21,0 L21,18");
}, "zero_or_one"), Jw = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18");
}, "one_or_more"), tv = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), n.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18");
}, "zero_or_more"), ev = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr(
    "d",
    `M0,0
      L20,10
      M20,10
      L0,20`
  );
}, "requirement_arrow"), rv = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g");
  i.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), i.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), i.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10);
}, "requirement_contains"), iv = {
  extension: Ww,
  composition: Hw,
  aggregation: jw,
  dependency: Yw,
  lollipop: Gw,
  point: Uw,
  circle: Xw,
  cross: Vw,
  barb: Zw,
  only_one: Kw,
  zero_or_one: Qw,
  one_or_more: Jw,
  zero_or_more: tv,
  requirement_arrow: ev,
  requirement_contains: rv
}, nv = qw, av = {
  common: kr,
  getConfig: Pt,
  insertCluster: pw,
  insertEdge: zw,
  insertEdgeLabel: Dw,
  insertMarkers: nv,
  insertNode: Jp,
  interpolateToCurve: Ws,
  labelHelper: Q,
  log: F,
  positionEdgeLabel: Rw
}, oi = {}, ed = /* @__PURE__ */ d((e) => {
  for (const t of e)
    oi[t.name] = t;
}, "registerLayoutLoaders"), sv = /* @__PURE__ */ d(() => {
  ed([
    {
      name: "dagre",
      loader: /* @__PURE__ */ d(async () => await import("./dagre-IE2X5DAH-BQaK-xNm.js"), "loader")
    }
  ]);
}, "registerDefaultLayoutLoaders");
sv();
var PT = /* @__PURE__ */ d(async (e, t) => {
  if (!(e.layoutAlgorithm in oi))
    throw new Error(`Unknown layout algorithm: ${e.layoutAlgorithm}`);
  const r = oi[e.layoutAlgorithm];
  return (await r.loader()).render(e, t, av, {
    algorithm: r.algorithm
  });
}, "render"), NT = /* @__PURE__ */ d((e = "", { fallback: t = "dagre" } = {}) => {
  if (e in oi)
    return e;
  if (t in oi)
    return F.warn(`Layout algorithm ${e} is not registered. Using ${t} as fallback.`), t;
  throw new Error(`Both layout algorithms ${e} and ${t} are not registered.`);
}, "getRegisteredLayoutAlgorithm"), vl = {
  name: "mermaid",
  version: "11.7.0",
  description: "Markdown-ish syntax for generating flowcharts, mindmaps, sequence diagrams, class diagrams, gantt charts, git graphs and more.",
  type: "module",
  module: "./dist/mermaid.core.mjs",
  types: "./dist/mermaid.d.ts",
  exports: {
    ".": {
      types: "./dist/mermaid.d.ts",
      import: "./dist/mermaid.core.mjs",
      default: "./dist/mermaid.core.mjs"
    },
    "./*": "./*"
  },
  keywords: [
    "diagram",
    "markdown",
    "flowchart",
    "sequence diagram",
    "gantt",
    "class diagram",
    "git graph",
    "mindmap",
    "packet diagram",
    "c4 diagram",
    "er diagram",
    "pie chart",
    "pie diagram",
    "quadrant chart",
    "requirement diagram",
    "graph"
  ],
  scripts: {
    clean: "rimraf dist",
    dev: "pnpm -w dev",
    "docs:code": "typedoc src/defaultConfig.ts src/config.ts src/mermaid.ts && prettier --write ./src/docs/config/setup",
    "docs:build": "rimraf ../../docs && pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts",
    "docs:verify": "pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts --verify",
    "docs:pre:vitepress": "pnpm --filter ./src/docs prefetch && rimraf src/vitepress && pnpm docs:code && tsx scripts/docs.cli.mts --vitepress && pnpm --filter ./src/vitepress install --no-frozen-lockfile --ignore-scripts",
    "docs:build:vitepress": "pnpm docs:pre:vitepress && (cd src/vitepress && pnpm run build) && cpy --flat src/docs/landing/ ./src/vitepress/.vitepress/dist/landing",
    "docs:dev": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:dev:docker": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev:docker" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:serve": "pnpm docs:build:vitepress && vitepress serve src/vitepress",
    "docs:spellcheck": 'cspell "src/docs/**/*.md"',
    "docs:release-version": "tsx scripts/update-release-version.mts",
    "docs:verify-version": "tsx scripts/update-release-version.mts --verify",
    "types:build-config": "tsx scripts/create-types-from-json-schema.mts",
    "types:verify-config": "tsx scripts/create-types-from-json-schema.mts --verify",
    checkCircle: "npx madge --circular ./src",
    prepublishOnly: "pnpm docs:verify-version"
  },
  repository: {
    type: "git",
    url: "https://github.com/mermaid-js/mermaid"
  },
  author: "Knut Sveidqvist",
  license: "MIT",
  standard: {
    ignore: [
      "**/parser/*.js",
      "dist/**/*.js",
      "cypress/**/*.js"
    ],
    globals: [
      "page"
    ]
  },
  dependencies: {
    "@braintree/sanitize-url": "^7.0.4",
    "@iconify/utils": "^2.1.33",
    "@mermaid-js/parser": "workspace:^",
    "@types/d3": "^7.4.3",
    cytoscape: "^3.29.3",
    "cytoscape-cose-bilkent": "^4.1.0",
    "cytoscape-fcose": "^2.2.0",
    d3: "^7.9.0",
    "d3-sankey": "^0.12.3",
    "dagre-d3-es": "7.0.11",
    dayjs: "^1.11.13",
    dompurify: "^3.2.5",
    katex: "^0.16.9",
    khroma: "^2.1.0",
    "lodash-es": "^4.17.21",
    marked: "^15.0.7",
    roughjs: "^4.6.6",
    stylis: "^4.3.6",
    "ts-dedent": "^2.2.0",
    uuid: "^11.1.0"
  },
  devDependencies: {
    "@adobe/jsonschema2md": "^8.0.2",
    "@iconify/types": "^2.0.0",
    "@types/cytoscape": "^3.21.9",
    "@types/cytoscape-fcose": "^2.2.4",
    "@types/d3-sankey": "^0.12.4",
    "@types/d3-scale": "^4.0.9",
    "@types/d3-scale-chromatic": "^3.1.0",
    "@types/d3-selection": "^3.0.11",
    "@types/d3-shape": "^3.1.7",
    "@types/jsdom": "^21.1.7",
    "@types/katex": "^0.16.7",
    "@types/lodash-es": "^4.17.12",
    "@types/micromatch": "^4.0.9",
    "@types/stylis": "^4.2.7",
    "@types/uuid": "^10.0.0",
    ajv: "^8.17.1",
    chokidar: "^4.0.3",
    concurrently: "^9.1.2",
    "csstree-validator": "^4.0.1",
    globby: "^14.0.2",
    jison: "^0.4.18",
    "js-base64": "^3.7.7",
    jsdom: "^26.0.0",
    "json-schema-to-typescript": "^15.0.4",
    micromatch: "^4.0.8",
    "path-browserify": "^1.0.1",
    prettier: "^3.5.2",
    remark: "^15.0.1",
    "remark-frontmatter": "^5.0.0",
    "remark-gfm": "^4.0.1",
    rimraf: "^6.0.1",
    "start-server-and-test": "^2.0.10",
    "type-fest": "^4.35.0",
    typedoc: "^0.27.8",
    "typedoc-plugin-markdown": "^4.4.2",
    typescript: "~5.7.3",
    "unist-util-flatmap": "^1.0.0",
    "unist-util-visit": "^5.0.0",
    vitepress: "^1.0.2",
    "vitepress-plugin-search": "1.0.4-alpha.22"
  },
  files: [
    "dist/",
    "README.md"
  ],
  publishConfig: {
    access: "public"
  }
}, ov = /* @__PURE__ */ d((e) => {
  var n;
  const { securityLevel: t } = nt();
  let r = et("body");
  if (t === "sandbox") {
    const o = ((n = et(`#i${e}`).node()) == null ? void 0 : n.contentDocument) ?? document;
    r = et(o.body);
  }
  return r.select(`#${e}`);
}, "selectSvgElement"), rd = "comm", id = "rule", nd = "decl", lv = "@import", cv = "@namespace", hv = "@keyframes", uv = "@layer", ad = Math.abs, lo = String.fromCharCode;
function sd(e) {
  return e.trim();
}
function zi(e, t, r) {
  return e.replace(t, r);
}
function fv(e, t, r) {
  return e.indexOf(t, r);
}
function nr(e, t) {
  return e.charCodeAt(t) | 0;
}
function wr(e, t, r) {
  return e.slice(t, r);
}
function Qt(e) {
  return e.length;
}
function pv(e) {
  return e.length;
}
function Li(e, t) {
  return t.push(e), e;
}
var Vn = 1, vr = 1, od = 0, jt = 0, mt = 0, Mr = "";
function co(e, t, r, i, n, a, o, s) {
  return { value: e, root: t, parent: r, type: i, props: n, children: a, line: Vn, column: vr, length: o, return: "", siblings: s };
}
function dv() {
  return mt;
}
function gv() {
  return mt = jt > 0 ? nr(Mr, --jt) : 0, vr--, mt === 10 && (vr = 1, Vn--), mt;
}
function Ut() {
  return mt = jt < od ? nr(Mr, jt++) : 0, vr++, mt === 10 && (vr = 1, Vn++), mt;
}
function _e() {
  return nr(Mr, jt);
}
function qi() {
  return jt;
}
function Zn(e, t) {
  return wr(Mr, e, t);
}
function li(e) {
  switch (e) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function mv(e) {
  return Vn = vr = 1, od = Qt(Mr = e), jt = 0, [];
}
function yv(e) {
  return Mr = "", e;
}
function fa(e) {
  return sd(Zn(jt - 1, rs(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function xv(e) {
  for (; (mt = _e()) && mt < 33; )
    Ut();
  return li(e) > 2 || li(mt) > 3 ? "" : " ";
}
function bv(e, t) {
  for (; --t && Ut() && !(mt < 48 || mt > 102 || mt > 57 && mt < 65 || mt > 70 && mt < 97); )
    ;
  return Zn(e, qi() + (t < 6 && _e() == 32 && Ut() == 32));
}
function rs(e) {
  for (; Ut(); )
    switch (mt) {
      case e:
        return jt;
      case 34:
      case 39:
        e !== 34 && e !== 39 && rs(mt);
        break;
      case 40:
        e === 41 && rs(e);
        break;
      case 92:
        Ut();
        break;
    }
  return jt;
}
function Cv(e, t) {
  for (; Ut() && e + mt !== 57; )
    if (e + mt === 84 && _e() === 47)
      break;
  return "/*" + Zn(t, jt - 1) + "*" + lo(e === 47 ? e : Ut());
}
function _v(e) {
  for (; !li(_e()); )
    Ut();
  return Zn(e, jt);
}
function wv(e) {
  return yv(Wi("", null, null, null, [""], e = mv(e), 0, [0], e));
}
function Wi(e, t, r, i, n, a, o, s, l) {
  for (var c = 0, h = 0, u = o, f = 0, p = 0, g = 0, m = 1, y = 1, x = 1, b = 0, _ = "", S = n, w = a, C = i, v = _; y; )
    switch (g = b, b = Ut()) {
      case 40:
        if (g != 108 && nr(v, u - 1) == 58) {
          fv(v += zi(fa(b), "&", "&\f"), "&\f", ad(c ? s[c - 1] : 0)) != -1 && (x = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        v += fa(b);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        v += xv(g);
        break;
      case 92:
        v += bv(qi() - 1, 7);
        continue;
      case 47:
        switch (_e()) {
          case 42:
          case 47:
            Li(vv(Cv(Ut(), qi()), t, r, l), l), (li(g || 1) == 5 || li(_e() || 1) == 5) && Qt(v) && wr(v, -1, void 0) !== " " && (v += " ");
            break;
          default:
            v += "/";
        }
        break;
      case 123 * m:
        s[c++] = Qt(v) * x;
      case 125 * m:
      case 59:
      case 0:
        switch (b) {
          case 0:
          case 125:
            y = 0;
          case 59 + h:
            x == -1 && (v = zi(v, /\f/g, "")), p > 0 && (Qt(v) - u || m === 0 && g === 47) && Li(p > 32 ? Sl(v + ";", i, r, u - 1, l) : Sl(zi(v, " ", "") + ";", i, r, u - 2, l), l);
            break;
          case 59:
            v += ";";
          default:
            if (Li(C = kl(v, t, r, c, h, n, s, _, S = [], w = [], u, a), a), b === 123)
              if (h === 0)
                Wi(v, t, C, C, S, a, u, s, w);
              else {
                switch (f) {
                  case 99:
                    if (nr(v, 3) === 110) break;
                  case 108:
                    if (nr(v, 2) === 97) break;
                  default:
                    h = 0;
                  case 100:
                  case 109:
                  case 115:
                }
                h ? Wi(e, C, C, i && Li(kl(e, C, C, 0, 0, n, s, _, n, S = [], u, w), w), n, w, u, s, i ? S : w) : Wi(v, C, C, C, [""], w, 0, s, w);
              }
        }
        c = h = p = 0, m = x = 1, _ = v = "", u = o;
        break;
      case 58:
        u = 1 + Qt(v), p = g;
      default:
        if (m < 1) {
          if (b == 123)
            --m;
          else if (b == 125 && m++ == 0 && gv() == 125)
            continue;
        }
        switch (v += lo(b), b * m) {
          case 38:
            x = h > 0 ? 1 : (v += "\f", -1);
            break;
          case 44:
            s[c++] = (Qt(v) - 1) * x, x = 1;
            break;
          case 64:
            _e() === 45 && (v += fa(Ut())), f = _e(), h = u = Qt(_ = v += _v(qi())), b++;
            break;
          case 45:
            g === 45 && Qt(v) == 2 && (m = 0);
        }
    }
  return a;
}
function kl(e, t, r, i, n, a, o, s, l, c, h, u) {
  for (var f = n - 1, p = n === 0 ? a : [""], g = pv(p), m = 0, y = 0, x = 0; m < i; ++m)
    for (var b = 0, _ = wr(e, f + 1, f = ad(y = o[m])), S = e; b < g; ++b)
      (S = sd(y > 0 ? p[b] + " " + _ : zi(_, /&\f/g, p[b]))) && (l[x++] = S);
  return co(e, t, r, n === 0 ? id : s, l, c, h, u);
}
function vv(e, t, r, i) {
  return co(e, t, r, rd, lo(dv()), wr(e, 2, -2), 0, i);
}
function Sl(e, t, r, i, n) {
  return co(e, t, r, nd, wr(e, 0, i), wr(e, i + 1, -1), i, n);
}
function is(e, t) {
  for (var r = "", i = 0; i < e.length; i++)
    r += t(e[i], i, e, t) || "";
  return r;
}
function kv(e, t, r, i) {
  switch (e.type) {
    case uv:
      if (e.children.length) break;
    case lv:
    case cv:
    case nd:
      return e.return = e.return || e.value;
    case rd:
      return "";
    case hv:
      return e.return = e.value + "{" + is(e.children, i) + "}";
    case id:
      if (!Qt(e.value = e.props.join(","))) return "";
  }
  return Qt(r = is(e.children, i)) ? e.return = e.value + "{" + r + "}" : "";
}
var Sv = Iu(Object.keys, Object), Tv = Object.prototype, Bv = Tv.hasOwnProperty;
function Lv(e) {
  if (!zn(e))
    return Sv(e);
  var t = [];
  for (var r in Object(e))
    Bv.call(e, r) && r != "constructor" && t.push(r);
  return t;
}
var ns = Xe(ne, "DataView"), as = Xe(ne, "Promise"), ss = Xe(ne, "Set"), os = Xe(ne, "WeakMap"), Tl = "[object Map]", Mv = "[object Object]", Bl = "[object Promise]", Ll = "[object Set]", Ml = "[object WeakMap]", Al = "[object DataView]", Av = Ue(ns), $v = Ue(si), Fv = Ue(as), Ev = Ue(ss), Ov = Ue(os), Fe = Sr;
(ns && Fe(new ns(new ArrayBuffer(1))) != Al || si && Fe(new si()) != Tl || as && Fe(as.resolve()) != Bl || ss && Fe(new ss()) != Ll || os && Fe(new os()) != Ml) && (Fe = function(e) {
  var t = Sr(e), r = t == Mv ? e.constructor : void 0, i = r ? Ue(r) : "";
  if (i)
    switch (i) {
      case Av:
        return Al;
      case $v:
        return Tl;
      case Fv:
        return Bl;
      case Ev:
        return Ll;
      case Ov:
        return Ml;
    }
  return t;
});
var Dv = "[object Map]", Rv = "[object Set]", Iv = Object.prototype, Pv = Iv.hasOwnProperty;
function $l(e) {
  if (e == null)
    return !0;
  if (qn(e) && (pn(e) || typeof e == "string" || typeof e.splice == "function" || zs(e) || qs(e) || fn(e)))
    return !e.length;
  var t = Fe(e);
  if (t == Dv || t == Rv)
    return !e.size;
  if (zn(e))
    return !Lv(e).length;
  for (var r in e)
    if (Pv.call(e, r))
      return !1;
  return !0;
}
var ld = "c4", Nv = /* @__PURE__ */ d((e) => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(e), "detector"), zv = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./c4Diagram-E5VUS4TQ-DEMLXh6u.js");
  return { id: ld, diagram: e };
}, "loader"), qv = {
  id: ld,
  detector: Nv,
  loader: zv
}, Wv = qv, cd = "flowchart", Hv = /* @__PURE__ */ d((e, t) => {
  var r, i;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" || ((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" ? !1 : /^\s*graph/.test(e);
}, "detector"), jv = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-OUUYVNGO-Ba7G95Y6.js");
  return { id: cd, diagram: e };
}, "loader"), Yv = {
  id: cd,
  detector: Hv,
  loader: jv
}, Gv = Yv, hd = "flowchart-v2", Uv = /* @__PURE__ */ d((e, t) => {
  var r, i, n;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-d3" ? !1 : (((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" && (t.layout = "elk"), /^\s*graph/.test(e) && ((n = t == null ? void 0 : t.flowchart) == null ? void 0 : n.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(e));
}, "detector"), Xv = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-OUUYVNGO-Ba7G95Y6.js");
  return { id: hd, diagram: e };
}, "loader"), Vv = {
  id: hd,
  detector: Uv,
  loader: Xv
}, Zv = Vv, ud = "er", Kv = /* @__PURE__ */ d((e) => /^\s*erDiagram/.test(e), "detector"), Qv = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./erDiagram-FWMTN743-DdEXAbgz.js");
  return { id: ud, diagram: e };
}, "loader"), Jv = {
  id: ud,
  detector: Kv,
  loader: Qv
}, tk = Jv, fd = "gitGraph", ek = /* @__PURE__ */ d((e) => /^\s*gitGraph/.test(e), "detector"), rk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./gitGraphDiagram-SOPYED2O-BX_PUCEk.js");
  return { id: fd, diagram: e };
}, "loader"), ik = {
  id: fd,
  detector: ek,
  loader: rk
}, nk = ik, pd = "gantt", ak = /* @__PURE__ */ d((e) => /^\s*gantt/.test(e), "detector"), sk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./ganttDiagram-Y4ZJHTSR-D19dQQDv.js");
  return { id: pd, diagram: e };
}, "loader"), ok = {
  id: pd,
  detector: ak,
  loader: sk
}, lk = ok, dd = "info", ck = /* @__PURE__ */ d((e) => /^\s*info/.test(e), "detector"), hk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./infoDiagram-LZPS564M-WtTUCs7p.js");
  return { id: dd, diagram: e };
}, "loader"), uk = {
  id: dd,
  detector: ck,
  loader: hk
}, gd = "pie", fk = /* @__PURE__ */ d((e) => /^\s*pie/.test(e), "detector"), pk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./pieDiagram-JVH3GP2A-ppx395t1.js");
  return { id: gd, diagram: e };
}, "loader"), dk = {
  id: gd,
  detector: fk,
  loader: pk
}, md = "quadrantChart", gk = /* @__PURE__ */ d((e) => /^\s*quadrantChart/.test(e), "detector"), mk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./quadrantDiagram-2GFVJBMM-BQR1ydpn.js");
  return { id: md, diagram: e };
}, "loader"), yk = {
  id: md,
  detector: gk,
  loader: mk
}, xk = yk, yd = "xychart", bk = /* @__PURE__ */ d((e) => /^\s*xychart-beta/.test(e), "detector"), Ck = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./xychartDiagram-4SJQ7YKO-CzMEptRS.js");
  return { id: yd, diagram: e };
}, "loader"), _k = {
  id: yd,
  detector: bk,
  loader: Ck
}, wk = _k, xd = "requirement", vk = /* @__PURE__ */ d((e) => /^\s*requirement(Diagram)?/.test(e), "detector"), kk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./requirementDiagram-PBTKI7ZP-BKCbRyA4.js");
  return { id: xd, diagram: e };
}, "loader"), Sk = {
  id: xd,
  detector: vk,
  loader: kk
}, Tk = Sk, bd = "sequence", Bk = /* @__PURE__ */ d((e) => /^\s*sequenceDiagram/.test(e), "detector"), Lk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sequenceDiagram-BLN7LXEI-DXi1muVE.js");
  return { id: bd, diagram: e };
}, "loader"), Mk = {
  id: bd,
  detector: Bk,
  loader: Lk
}, Ak = Mk, Cd = "class", $k = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(e);
}, "detector"), Fk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-EGQPL23Y-DMKykbn5.js");
  return { id: Cd, diagram: e };
}, "loader"), Ek = {
  id: Cd,
  detector: $k,
  loader: Fk
}, Ok = Ek, _d = "classDiagram", Dk = /* @__PURE__ */ d((e, t) => {
  var r;
  return /^\s*classDiagram/.test(e) && ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(e);
}, "detector"), Rk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-v2-4EBKGCBT-DMKykbn5.js");
  return { id: _d, diagram: e };
}, "loader"), Ik = {
  id: _d,
  detector: Dk,
  loader: Rk
}, Pk = Ik, wd = "state", Nk = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(e);
}, "detector"), zk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-WEXRT5W7-BsDYOLat.js");
  return { id: wd, diagram: e };
}, "loader"), qk = {
  id: wd,
  detector: Nk,
  loader: zk
}, Wk = qk, vd = "stateDiagram", Hk = /* @__PURE__ */ d((e, t) => {
  var r;
  return !!(/^\s*stateDiagram-v2/.test(e) || /^\s*stateDiagram/.test(e) && ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper");
}, "detector"), jk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-v2-SNKRMT2F-CcdhCbZC.js");
  return { id: vd, diagram: e };
}, "loader"), Yk = {
  id: vd,
  detector: Hk,
  loader: jk
}, Gk = Yk, kd = "journey", Uk = /* @__PURE__ */ d((e) => /^\s*journey/.test(e), "detector"), Xk = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./journeyDiagram-KRBQ73NG-CmlhEkBk.js");
  return { id: kd, diagram: e };
}, "loader"), Vk = {
  id: kd,
  detector: Uk,
  loader: Xk
}, Zk = Vk, Kk = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`rendering svg for syntax error
`);
  const i = ov(t), n = i.append("g");
  i.attr("viewBox", "0 0 2412 512"), ec(i, 100, 512, !0), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"
  ), n.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), n.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${r}`);
}, "draw"), Sd = { draw: Kk }, Qk = Sd, Jk = {
  db: {},
  renderer: Sd,
  parser: {
    parse: /* @__PURE__ */ d(() => {
    }, "parse")
  }
}, tS = Jk, Td = "flowchart-elk", eS = /* @__PURE__ */ d((e, t = {}) => {
  var r;
  return (
    // If diagram explicitly states flowchart-elk
    /^\s*flowchart-elk/.test(e) || // If a flowchart/graph diagram has their default renderer set to elk
    /^\s*flowchart|graph/.test(e) && ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "elk" ? (t.layout = "elk", !0) : !1
  );
}, "detector"), rS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-OUUYVNGO-Ba7G95Y6.js");
  return { id: Td, diagram: e };
}, "loader"), iS = {
  id: Td,
  detector: eS,
  loader: rS
}, nS = iS, Bd = "timeline", aS = /* @__PURE__ */ d((e) => /^\s*timeline/.test(e), "detector"), sS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./timeline-definition-GH3MJCYT-X3BxckYs.js");
  return { id: Bd, diagram: e };
}, "loader"), oS = {
  id: Bd,
  detector: aS,
  loader: sS
}, lS = oS, Ld = "mindmap", cS = /* @__PURE__ */ d((e) => /^\s*mindmap/.test(e), "detector"), hS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./mindmap-definition-RDSO3R44-BFStd8YG.js");
  return { id: Ld, diagram: e };
}, "loader"), uS = {
  id: Ld,
  detector: cS,
  loader: hS
}, fS = uS, Md = "kanban", pS = /* @__PURE__ */ d((e) => /^\s*kanban/.test(e), "detector"), dS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./kanban-definition-TWHLSRP4-CMia_Byy.js");
  return { id: Md, diagram: e };
}, "loader"), gS = {
  id: Md,
  detector: pS,
  loader: dS
}, mS = gS, Ad = "sankey", yS = /* @__PURE__ */ d((e) => /^\s*sankey-beta/.test(e), "detector"), xS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sankeyDiagram-XYA53EP7-B2QLqKQv.js");
  return { id: Ad, diagram: e };
}, "loader"), bS = {
  id: Ad,
  detector: yS,
  loader: xS
}, CS = bS, $d = "packet", _S = /* @__PURE__ */ d((e) => /^\s*packet-beta/.test(e), "detector"), wS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-3XXCIKAB-Dw8mtPCi.js");
  return { id: $d, diagram: e };
}, "loader"), vS = {
  id: $d,
  detector: _S,
  loader: wS
}, Fd = "radar", kS = /* @__PURE__ */ d((e) => /^\s*radar-beta/.test(e), "detector"), SS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-DTTGSU4T-BNnNo3RB.js");
  return { id: Fd, diagram: e };
}, "loader"), TS = {
  id: Fd,
  detector: kS,
  loader: SS
}, Ed = "block", BS = /* @__PURE__ */ d((e) => /^\s*block-beta/.test(e), "detector"), LS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./blockDiagram-ZUX3OVTL-CPYM4uU3.js");
  return { id: Ed, diagram: e };
}, "loader"), MS = {
  id: Ed,
  detector: BS,
  loader: LS
}, AS = MS, Od = "architecture", $S = /* @__PURE__ */ d((e) => /^\s*architecture/.test(e), "detector"), FS = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./architectureDiagram-KYWUMXXP-C8-HmmxG.js");
  return { id: Od, diagram: e };
}, "loader"), ES = {
  id: Od,
  detector: $S,
  loader: FS
}, OS = ES, Fl = !1, Kn = /* @__PURE__ */ d(() => {
  Fl || (Fl = !0, Gi("error", tS, (e) => e.toLowerCase().trim() === "error"), Gi(
    "---",
    // --- diagram type may appear if YAML front-matter is not parsed correctly
    {
      db: {
        clear: /* @__PURE__ */ d(() => {
        }, "clear")
      },
      styles: {},
      // should never be used
      renderer: {
        draw: /* @__PURE__ */ d(() => {
        }, "draw")
      },
      parser: {
        parse: /* @__PURE__ */ d(() => {
          throw new Error(
            "Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"
          );
        }, "parse")
      },
      init: /* @__PURE__ */ d(() => null, "init")
      // no op
    },
    (e) => e.toLowerCase().trimStart().startsWith("---")
  ), ga(nS, fS, OS), ga(
    Wv,
    mS,
    Pk,
    Ok,
    tk,
    lk,
    uk,
    dk,
    Tk,
    Ak,
    Zv,
    Gv,
    lS,
    nk,
    Gk,
    Wk,
    Zk,
    xk,
    CS,
    vS,
    wk,
    AS,
    TS
  ));
}, "addDiagrams"), DS = /* @__PURE__ */ d(async () => {
  F.debug("Loading registered diagrams");
  const t = (await Promise.allSettled(
    Object.entries(dr).map(async ([r, { detector: i, loader: n }]) => {
      if (n)
        try {
          ba(r);
        } catch {
          try {
            const { diagram: a, id: o } = await n();
            Gi(o, a, i);
          } catch (a) {
            throw F.error(`Failed to load external diagram with key ${r}. Removing from detectors.`), delete dr[r], a;
          }
        }
    })
  )).filter((r) => r.status === "rejected");
  if (t.length > 0) {
    F.error(`Failed to load ${t.length} external diagrams`);
    for (const r of t)
      F.error(r);
    throw new Error(`Failed to load ${t.length} external diagrams`);
  }
}, "loadRegisteredDiagrams"), RS = "graphics-document document";
function Dd(e, t) {
  e.attr("role", RS), t !== "" && e.attr("aria-roledescription", t);
}
d(Dd, "setA11yDiagramInfo");
function Rd(e, t, r, i) {
  if (e.insert !== void 0) {
    if (r) {
      const n = `chart-desc-${i}`;
      e.attr("aria-describedby", n), e.insert("desc", ":first-child").attr("id", n).text(r);
    }
    if (t) {
      const n = `chart-title-${i}`;
      e.attr("aria-labelledby", n), e.insert("title", ":first-child").attr("id", n).text(t);
    }
  }
}
d(Rd, "addSVGa11yTitleDescription");
var Ne, ls = (Ne = class {
  constructor(t, r, i, n, a) {
    this.type = t, this.text = r, this.db = i, this.parser = n, this.renderer = a;
  }
  static async fromText(t, r = {}) {
    var c, h;
    const i = Pt(), n = us(t, i);
    t = OC(t) + `
`;
    try {
      ba(n);
    } catch {
      const u = cg(n);
      if (!u)
        throw new ql(`Diagram ${n} not found.`);
      const { id: f, diagram: p } = await u();
      Gi(f, p);
    }
    const { db: a, parser: o, renderer: s, init: l } = ba(n);
    return o.parser && (o.parser.yy = a), (c = a.clear) == null || c.call(a), l == null || l(i), r.title && ((h = a.setDiagramTitle) == null || h.call(a, r.title)), await o.parse(t), new Ne(n, t, a, o, s);
  }
  async render(t, r) {
    await this.renderer.draw(this.text, t, r, this);
  }
  getParser() {
    return this.parser;
  }
  getType() {
    return this.type;
  }
}, d(Ne, "Diagram"), Ne), El = [], IS = /* @__PURE__ */ d(() => {
  El.forEach((e) => {
    e();
  }), El = [];
}, "attachFunctions"), PS = /* @__PURE__ */ d((e) => e.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function Id(e) {
  const t = e.match(zl);
  if (!t)
    return {
      text: e,
      metadata: {}
    };
  let r = om(t[1], {
    // To support config, we need JSON schema.
    // https://www.yaml.org/spec/1.2/spec.html#id2803231
    schema: sm
  }) ?? {};
  r = typeof r == "object" && !Array.isArray(r) ? r : {};
  const i = {};
  return r.displayMode && (i.displayMode = r.displayMode.toString()), r.title && (i.title = r.title.toString()), r.config && (i.config = r.config), {
    text: e.slice(t[0].length),
    metadata: i
  };
}
d(Id, "extractFrontMatter");
var NS = /* @__PURE__ */ d((e) => e.replace(/\r\n?/g, `
`).replace(
  /<(\w+)([^>]*)>/g,
  (t, r, i) => "<" + r + i.replace(/="([^"]*)"/g, "='$1'") + ">"
), "cleanupText"), zS = /* @__PURE__ */ d((e) => {
  const { text: t, metadata: r } = Id(e), { displayMode: i, title: n, config: a = {} } = r;
  return i && (a.gantt || (a.gantt = {}), a.gantt.displayMode = i), { title: n, config: a, text: t };
}, "processFrontmatter"), qS = /* @__PURE__ */ d((e) => {
  const t = Jt.detectInit(e) ?? {}, r = Jt.detectDirective(e, "wrap");
  return Array.isArray(r) ? t.wrap = r.some(({ type: i }) => i === "wrap") : (r == null ? void 0 : r.type) === "wrap" && (t.wrap = !0), {
    text: _C(e),
    directive: t
  };
}, "processDirectives");
function ho(e) {
  const t = NS(e), r = zS(t), i = qS(r.text), n = Us(r.config, i.directive);
  return e = PS(i.text), {
    code: e,
    title: r.title,
    config: n
  };
}
d(ho, "preprocessDiagram");
function Pd(e) {
  const t = new TextEncoder().encode(e), r = Array.from(t, (i) => String.fromCodePoint(i)).join("");
  return btoa(r);
}
d(Pd, "toBase64");
var WS = 5e4, HS = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", jS = "sandbox", YS = "loose", GS = "http://www.w3.org/2000/svg", US = "http://www.w3.org/1999/xlink", XS = "http://www.w3.org/1999/xhtml", VS = "100%", ZS = "100%", KS = "border:0;margin:0;", QS = "margin:0", JS = "allow-top-navigation-by-user-activation allow-popups", tT = 'The "iframe" tag is not supported by your browser.', eT = ["foreignobject"], rT = ["dominant-baseline"];
function uo(e) {
  const t = ho(e);
  return ji(), Sg(t.config ?? {}), t;
}
d(uo, "processAndSetConfigs");
async function Nd(e, t) {
  Kn();
  try {
    const { code: r, config: i } = uo(e);
    return { diagramType: (await qd(r)).type, config: i };
  } catch (r) {
    if (t != null && t.suppressErrors)
      return !1;
    throw r;
  }
}
d(Nd, "parse");
var Ol = /* @__PURE__ */ d((e, t, r = []) => `
.${e} ${t} { ${r.join(" !important; ")} !important; }`, "cssImportantStyles"), iT = /* @__PURE__ */ d((e, t = /* @__PURE__ */ new Map()) => {
  var i;
  let r = "";
  if (e.themeCSS !== void 0 && (r += `
${e.themeCSS}`), e.fontFamily !== void 0 && (r += `
:root { --mermaid-font-family: ${e.fontFamily}}`), e.altFontFamily !== void 0 && (r += `
:root { --mermaid-alt-font-family: ${e.altFontFamily}}`), t instanceof Map) {
    const s = e.htmlLabels ?? ((i = e.flowchart) == null ? void 0 : i.htmlLabels) ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
    t.forEach((l) => {
      $l(l.styles) || s.forEach((c) => {
        r += Ol(l.id, c, l.styles);
      }), $l(l.textStyles) || (r += Ol(
        l.id,
        "tspan",
        ((l == null ? void 0 : l.textStyles) || []).map((c) => c.replace("color", "fill"))
      ));
    });
  }
  return r;
}, "createCssStyles"), nT = /* @__PURE__ */ d((e, t, r, i) => {
  const n = iT(e, r), a = Hg(t, n, e.themeVariables);
  return is(wv(`${i}{${a}}`), kv);
}, "createUserStyles"), aT = /* @__PURE__ */ d((e = "", t, r) => {
  let i = e;
  return !r && !t && (i = i.replace(
    /marker-end="url\([\d+./:=?A-Za-z-]*?#/g,
    'marker-end="url(#'
  )), i = Ve(i), i = i.replace(/<br>/g, "<br/>"), i;
}, "cleanUpSvgCode"), sT = /* @__PURE__ */ d((e = "", t) => {
  var n, a;
  const r = (a = (n = t == null ? void 0 : t.viewBox) == null ? void 0 : n.baseVal) != null && a.height ? t.viewBox.baseVal.height + "px" : ZS, i = Pd(`<body style="${QS}">${e}</body>`);
  return `<iframe style="width:${VS};height:${r};${KS}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${JS}">
  ${tT}
</iframe>`;
}, "putIntoIFrame"), Dl = /* @__PURE__ */ d((e, t, r, i, n) => {
  const a = e.append("div");
  a.attr("id", r), i && a.attr("style", i);
  const o = a.append("svg").attr("id", t).attr("width", "100%").attr("xmlns", GS);
  return n && o.attr("xmlns:xlink", n), o.append("g"), e;
}, "appendDivSvgG");
function cs(e, t) {
  return e.append("iframe").attr("id", t).attr("style", "width: 100%; height: 100%;").attr("sandbox", "");
}
d(cs, "sandboxedIframe");
var oT = /* @__PURE__ */ d((e, t, r, i) => {
  var n, a, o;
  (n = e.getElementById(t)) == null || n.remove(), (a = e.getElementById(r)) == null || a.remove(), (o = e.getElementById(i)) == null || o.remove();
}, "removeExistingElements"), lT = /* @__PURE__ */ d(async function(e, t, r) {
  var P, O, B, M, T, $;
  Kn();
  const i = uo(t);
  t = i.code;
  const n = Pt();
  F.debug(n), t.length > ((n == null ? void 0 : n.maxTextSize) ?? WS) && (t = HS);
  const a = "#" + e, o = "i" + e, s = "#" + o, l = "d" + e, c = "#" + l, h = /* @__PURE__ */ d(() => {
    const N = et(f ? s : c).node();
    N && "remove" in N && N.remove();
  }, "removeTempElements");
  let u = et("body");
  const f = n.securityLevel === jS, p = n.securityLevel === YS, g = n.fontFamily;
  if (r !== void 0) {
    if (r && (r.innerHTML = ""), f) {
      const L = cs(et(r), o);
      u = et(L.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = et(r);
    Dl(u, e, l, `font-family: ${g}`, US);
  } else {
    if (oT(document, e, l, o), f) {
      const L = cs(et("body"), o);
      u = et(L.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = et("body");
    Dl(u, e, l);
  }
  let m, y;
  try {
    m = await ls.fromText(t, { title: i.title });
  } catch (L) {
    if (n.suppressErrorRendering)
      throw h(), L;
    m = await ls.fromText("error"), y = L;
  }
  const x = u.select(c).node(), b = m.type, _ = x.firstChild, S = _.firstChild, w = (O = (P = m.renderer).getClasses) == null ? void 0 : O.call(P, t, m), C = nT(n, b, w, a), v = document.createElement("style");
  v.innerHTML = C, _.insertBefore(v, S);
  try {
    await m.renderer.draw(t, e, vl.version, m);
  } catch (L) {
    throw n.suppressErrorRendering ? h() : Qk.draw(t, e, vl.version), L;
  }
  const D = u.select(`${c} svg`), R = (M = (B = m.db).getAccTitle) == null ? void 0 : M.call(B), E = ($ = (T = m.db).getAccDescription) == null ? void 0 : $.call(T);
  Wd(b, D, R, E), u.select(`[id="${e}"]`).selectAll("foreignobject > *").attr("xmlns", XS);
  let A = u.select(c).node().innerHTML;
  if (F.debug("config.arrowMarkerAbsolute", n.arrowMarkerAbsolute), A = aT(A, f, bt(n.arrowMarkerAbsolute)), f) {
    const L = u.select(c + " svg").node();
    A = sT(A, L);
  } else p || (A = pr.sanitize(A, {
    ADD_TAGS: eT,
    ADD_ATTR: rT,
    HTML_INTEGRATION_POINTS: { foreignobject: !0 }
  }));
  if (IS(), y)
    throw y;
  return h(), {
    diagramType: b,
    svg: A,
    bindFunctions: m.db.bindFunctions
  };
}, "render");
function zd(e = {}) {
  var i;
  const t = kt({}, e);
  t != null && t.fontFamily && !((i = t.themeVariables) != null && i.fontFamily) && (t.themeVariables || (t.themeVariables = {}), t.themeVariables.fontFamily = t.fontFamily), vg(t), t != null && t.theme && t.theme in ue ? t.themeVariables = ue[t.theme].getThemeVariables(
    t.themeVariables
  ) : t && (t.themeVariables = ue.default.getThemeVariables(t.themeVariables));
  const r = typeof t == "object" ? wg(t) : Ul();
  hs(r.logLevel), Kn();
}
d(zd, "initialize");
var qd = /* @__PURE__ */ d((e, t = {}) => {
  const { code: r } = ho(e);
  return ls.fromText(r, t);
}, "getDiagramFromText");
function Wd(e, t, r, i) {
  Dd(t, e), Rd(t, r, i, t.attr("id"));
}
d(Wd, "addA11yInfo");
var Ye = Object.freeze({
  render: lT,
  parse: Nd,
  getDiagramFromText: qd,
  initialize: zd,
  getConfig: Pt,
  setConfig: Xl,
  getSiteConfig: Ul,
  updateSiteConfig: kg,
  reset: /* @__PURE__ */ d(() => {
    ji();
  }, "reset"),
  globalReset: /* @__PURE__ */ d(() => {
    ji(gr);
  }, "globalReset"),
  defaultConfig: gr
});
hs(Pt().logLevel);
ji(Pt());
var cT = /* @__PURE__ */ d((e, t, r) => {
  F.warn(e), Gs(e) ? (r && r(e.str, e.hash), t.push({ ...e, message: e.str, error: e })) : (r && r(e), e instanceof Error && t.push({
    str: e.message,
    message: e.message,
    hash: e.name,
    error: e
  }));
}, "handleError"), Hd = /* @__PURE__ */ d(async function(e = {
  querySelector: ".mermaid"
}) {
  try {
    await hT(e);
  } catch (t) {
    if (Gs(t) && F.error(t.str), zt.parseError && zt.parseError(t), !e.suppressErrors)
      throw F.error("Use the suppressErrors option to suppress these errors"), t;
  }
}, "run"), hT = /* @__PURE__ */ d(async function({ postRenderCallback: e, querySelector: t, nodes: r } = {
  querySelector: ".mermaid"
}) {
  const i = Ye.getConfig();
  F.debug(`${e ? "" : "No "}Callback function found`);
  let n;
  if (r)
    n = r;
  else if (t)
    n = document.querySelectorAll(t);
  else
    throw new Error("Nodes and querySelector are both undefined");
  F.debug(`Found ${n.length} diagrams`), (i == null ? void 0 : i.startOnLoad) !== void 0 && (F.debug("Start On Load: " + (i == null ? void 0 : i.startOnLoad)), Ye.updateSiteConfig({ startOnLoad: i == null ? void 0 : i.startOnLoad }));
  const a = new Jt.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed);
  let o;
  const s = [];
  for (const l of Array.from(n)) {
    if (F.info("Rendering diagram: " + l.id), l.getAttribute("data-processed"))
      continue;
    l.setAttribute("data-processed", "true");
    const c = `mermaid-${a.next()}`;
    o = l.innerHTML, o = gf(Jt.entityDecode(o)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    const h = Jt.detectInit(o);
    h && F.debug("Detected early reinit: ", h);
    try {
      const { svg: u, bindFunctions: f } = await Ud(c, o, l);
      l.innerHTML = u, e && await e(c), f && f(l);
    } catch (u) {
      cT(u, s, zt.parseError);
    }
  }
  if (s.length > 0)
    throw s[0];
}, "runThrowsErrors"), jd = /* @__PURE__ */ d(function(e) {
  Ye.initialize(e);
}, "initialize"), uT = /* @__PURE__ */ d(async function(e, t, r) {
  F.warn("mermaid.init is deprecated. Please use run instead."), e && jd(e);
  const i = { postRenderCallback: r, querySelector: ".mermaid" };
  typeof t == "string" ? i.querySelector = t : t && (t instanceof HTMLElement ? i.nodes = [t] : i.nodes = t), await Hd(i);
}, "init"), fT = /* @__PURE__ */ d(async (e, {
  lazyLoad: t = !0
} = {}) => {
  Kn(), ga(...e), t === !1 && await DS();
}, "registerExternalDiagrams"), Yd = /* @__PURE__ */ d(function() {
  if (zt.startOnLoad) {
    const { startOnLoad: e } = Ye.getConfig();
    e && zt.run().catch((t) => F.error("Mermaid failed to initialize", t));
  }
}, "contentLoaded");
typeof document < "u" && window.addEventListener("load", Yd, !1);
var pT = /* @__PURE__ */ d(function(e) {
  zt.parseError = e;
}, "setParseErrorHandler"), kn = [], pa = !1, Gd = /* @__PURE__ */ d(async () => {
  if (!pa) {
    for (pa = !0; kn.length > 0; ) {
      const e = kn.shift();
      if (e)
        try {
          await e();
        } catch (t) {
          F.error("Error executing queue", t);
        }
    }
    pa = !1;
  }
}, "executeQueue"), dT = /* @__PURE__ */ d(async (e, t) => new Promise((r, i) => {
  const n = /* @__PURE__ */ d(() => new Promise((a, o) => {
    Ye.parse(e, t).then(
      (s) => {
        a(s), r(s);
      },
      (s) => {
        var l;
        F.error("Error parsing", s), (l = zt.parseError) == null || l.call(zt, s), o(s), i(s);
      }
    );
  }), "performCall");
  kn.push(n), Gd().catch(i);
}), "parse"), Ud = /* @__PURE__ */ d((e, t, r) => new Promise((i, n) => {
  const a = /* @__PURE__ */ d(() => new Promise((o, s) => {
    Ye.render(e, t, r).then(
      (l) => {
        o(l), i(l);
      },
      (l) => {
        var c;
        F.error("Error parsing", l), (c = zt.parseError) == null || c.call(zt, l), s(l), n(l);
      }
    );
  }), "performCall");
  kn.push(a), Gd().catch(n);
}), "render"), zt = {
  startOnLoad: !0,
  mermaidAPI: Ye,
  parse: dT,
  render: Ud,
  init: uT,
  run: Hd,
  registerExternalDiagrams: fT,
  registerLayoutLoaders: ed,
  initialize: jd,
  parseError: void 0,
  contentLoaded: Yd,
  setParseErrorHandler: pT,
  detectType: us,
  registerIconPacks: P_
}, gT = zt;
/*! Check if previously processed */
/*!
 * Wait for document loaded before starting the execution
 */
const zT = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: gT
}, Symbol.toStringTag, { value: "Module" }));
export {
  rc as $,
  Gr as A,
  og as B,
  Qg as C,
  Us as D,
  Pt as E,
  Yl as F,
  TC as G,
  ov as H,
  vl as I,
  sm as J,
  gg as K,
  yr as L,
  xT as M,
  Wn as N,
  tc as O,
  fs as P,
  go as Q,
  Ob as R,
  Ri as S,
  SC as T,
  hi as U,
  zg as V,
  ci as W,
  z as X,
  X as Y,
  yC as Z,
  d as _,
  Gg as a,
  Ms as a$,
  Ab as a0,
  Es as a1,
  kT as a2,
  BT as a3,
  Ke as a4,
  Po as a5,
  Io as a6,
  MT as a7,
  LT as a8,
  TT as a9,
  pC as aA,
  a2 as aB,
  sC as aC,
  Ps as aD,
  $l as aE,
  z_ as aF,
  $b as aG,
  yi as aH,
  P_ as aI,
  I_ as aJ,
  Ge as aK,
  dC as aL,
  Yu as aM,
  In as aN,
  qn as aO,
  pn as aP,
  Uu as aQ,
  ju as aR,
  j2 as aS,
  It as aT,
  ix as aU,
  Ls as aV,
  Qh as aW,
  pi as aX,
  eu as aY,
  _T as aZ,
  Jd as a_,
  wT as aa,
  vT as ab,
  $T as ac,
  ST as ad,
  AT as ae,
  pw as af,
  Jp as ag,
  RT as ah,
  lm as ai,
  bt as aj,
  Le as ak,
  ks as al,
  Bf as am,
  Ve as an,
  Ju as ao,
  K as ap,
  ee as aq,
  nv as ar,
  DT as as,
  IT as at,
  ET as au,
  j as av,
  OT as aw,
  zw as ax,
  Rw as ay,
  Dw as az,
  Yg as b,
  Ce as b0,
  $o as b1,
  hx as b2,
  ii as b3,
  fC as b4,
  aC as b5,
  G1 as b6,
  Ns as b7,
  z2 as b8,
  mC as b9,
  gi as ba,
  Sr as bb,
  hn as bc,
  K2 as bd,
  Lv as be,
  di as bf,
  fn as bg,
  Y2 as bh,
  Pu as bi,
  V1 as bj,
  Z1 as bk,
  Fe as bl,
  Jo as bm,
  K1 as bn,
  zs as bo,
  X1 as bp,
  t2 as bq,
  Tr as br,
  Be as bs,
  Xo as bt,
  qs as bu,
  zu as bv,
  ss as bw,
  gC as bx,
  zn as by,
  zT as bz,
  nt as c,
  et as d,
  ec as e,
  kt as f,
  Xg as g,
  de as h,
  ze as i,
  Ph as j,
  kr as k,
  F as l,
  ef as m,
  bT as n,
  NT as o,
  Vg as p,
  Zg as q,
  PT as r,
  Ug as s,
  om as t,
  Jt as u,
  Fw as v,
  MC as w,
  FT as x,
  jg as y,
  CT as z
};
