import { I as f } from "./Index-DcB-GfxT.js";
export {
  f as default
};
