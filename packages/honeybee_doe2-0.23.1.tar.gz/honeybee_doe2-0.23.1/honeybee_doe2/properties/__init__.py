"""honeybee-doe2 properties."""
