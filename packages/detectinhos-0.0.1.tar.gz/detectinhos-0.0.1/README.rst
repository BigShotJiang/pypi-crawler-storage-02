detectinhos
===========

.. image:: https://github.com/kqf/detectinhos/actions/workflows/tests.yml/badge.svg
   :target: https://github.com/kqf/detectinhos/actions
   :alt: Tests

.. image:: https://img.shields.io/pypi/dm/detectinhos.svg
   :target: https://pypi.org/project/detectinhos/
   :alt: PyPI Downloads

``detectinhos`` is a library that helps to train and ship object detectors somehow.

----

Installation
------------

Install via pip:

.. code-block:: bash

    pip install detectinhos

----

Usage
-----

To use ``detectinhos``, do the following:
Example:

.. code-block:: python

    import detectinhos
