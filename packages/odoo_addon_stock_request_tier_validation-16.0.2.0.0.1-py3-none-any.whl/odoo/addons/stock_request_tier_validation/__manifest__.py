# Copyright 2019-2020 ForgeFlow S.L. (https://www.forgeflow.com)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
{
    "name": "Stock Request Tier Validation",
    "summary": "Extends the functionality of Stock Requests to "
    "support a tier validation process.",
    "version": "16.0.2.0.0",
    "category": "Warehouse",
    "website": "https://github.com/OCA/stock-logistics-request",
    "author": "ForgeFlow, Odoo Community Association (OCA)",
    "maintainers": ["LoisRForgeFlow", "etobella"],
    "license": "AGPL-3",
    "application": False,
    "installable": True,
    "depends": ["stock_request", "base_tier_validation"],
    "data": [
        "data/stock_request_tier_definition.xml",
        "views/stock_request_order_view.xml",
        "views/stock_request_view.xml",
    ],
}
