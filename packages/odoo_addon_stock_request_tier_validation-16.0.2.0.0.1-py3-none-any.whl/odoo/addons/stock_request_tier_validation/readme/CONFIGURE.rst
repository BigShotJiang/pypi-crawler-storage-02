A default tier is created allowing Stock Request Manager to approve Stock
Request and Stock Request Orders.

In addition, you may want to add more tiers, so:

#. Go to *Settings > Technical > Tier Validations > Tier Definition*.
#. Create as many tiers as you want for Stock Request model.
