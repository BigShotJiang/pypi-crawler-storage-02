========
posparse
========

Overview
--------

posparse

Installation
------------

To install ``posparse``, you can use ``pip``. Open your terminal and run:

.. code-block:: bash

    pip install posparse

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/posparse/#files>`_
* `Index <https://pypi.org/project/posparse/>`_
* `Source <https://github.com/johannes-programming/posparse/>`_

Credits
-------

* Author: Johannes
* Email: `johannes-programming@mailfence.com <mailto:johannes-programming@mailfence.com>`_

Thank you for using ``posparse``!