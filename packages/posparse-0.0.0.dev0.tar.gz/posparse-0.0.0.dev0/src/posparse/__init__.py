from posparse.core import *
from posparse.tests import *

if __name__ == "__main__":
    main()
