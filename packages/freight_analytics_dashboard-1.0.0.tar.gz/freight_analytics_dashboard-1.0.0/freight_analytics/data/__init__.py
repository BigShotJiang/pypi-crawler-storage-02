"""Data module for freight analytics package."""

# This module contains the data files for the package
