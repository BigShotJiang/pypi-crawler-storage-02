# Conjunto.CMS

CMS provides basic Content Management System functions. This is packaged in a subapp because not all applications need this.

* If you are planning to make an application that is like a SPA, you probably don't need this.
* If you are have a lot of dynamic content, this app is for you.