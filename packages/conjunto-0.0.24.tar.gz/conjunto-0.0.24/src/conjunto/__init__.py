"Django application framework/helpers using HTMX, tabler.io, tables2, crispy-forms & more."

__version__ = "0.0.24"
