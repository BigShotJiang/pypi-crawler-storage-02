# Management commands


Conjunto adds management commands for your convenience:

### update_permissions
::: conjunto.management.commands.update_permissions
    show_root_heading: false
    members:



