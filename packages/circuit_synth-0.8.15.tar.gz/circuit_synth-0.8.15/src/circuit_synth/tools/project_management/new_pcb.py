#!/usr/bin/env python3
"""
DEPRECATED: This file has been consolidated into new_project.py

The cs-new-pcb command has been removed in favor of cs-new-project.
This file is kept temporarily to avoid import errors but should be deleted.
"""


# Placeholder to prevent import errors
def main():
    """Deprecated: Use cs-new-project instead"""
    print("ERROR: cs-new-pcb has been consolidated into cs-new-project")
    print("Please use: cs-new-project")
    exit(1)


if __name__ == "__main__":
    main()
