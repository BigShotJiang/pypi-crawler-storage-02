__author__ = 'Антон Глызин'

from query_tables.tables import Tables, TablesAsync

__all__ =[
    'Tables',
    'TablesAsync'
]