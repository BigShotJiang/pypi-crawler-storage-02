"""Unit tests for metrics."""
