"""Unit tests for endpoints implementations."""
