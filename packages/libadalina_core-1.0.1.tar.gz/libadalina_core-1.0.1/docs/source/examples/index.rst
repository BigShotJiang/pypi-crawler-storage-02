Examples
========

This section provides examples of how to use the libadalina-core library for various geospatial data processing tasks.

.. toctree::
   :maxdepth: 1

   hospitals_in_provinces
   population_in_provinces
   population_served_by_hospitals