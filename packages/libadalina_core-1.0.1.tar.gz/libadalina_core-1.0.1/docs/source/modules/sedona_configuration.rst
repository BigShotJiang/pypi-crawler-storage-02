Sedona Configuration
====================

The sedona_configuration module provides functions for configuring and initializing Apache Sedona.

.. automodule:: libadalina_core.sedona_configuration.sedona_configuration
   :members:
   :undoc-members:
   :show-inheritance:

JDK Installer
-------------

.. automodule:: libadalina_core.sedona_configuration.jdk_installer
   :members:
   :undoc-members:
   :show-inheritance:
