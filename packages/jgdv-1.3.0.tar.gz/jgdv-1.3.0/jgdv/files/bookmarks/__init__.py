"""

"""
from .bookmark import Bookmark
from .collection import BookmarkCollection
