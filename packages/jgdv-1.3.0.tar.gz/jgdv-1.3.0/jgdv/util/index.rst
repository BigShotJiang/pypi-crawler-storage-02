.. -*- mode: ReST -*-

.. _util:

=========
Utilities
=========

.. contents:: Contents


A :ref:`module<jgdv.util>` for miscellaneous utilities which don't fit elsewhere.
Currently :func:`plugin_selector<jgdv.util.plugins.selector.plugin_selector>`.
