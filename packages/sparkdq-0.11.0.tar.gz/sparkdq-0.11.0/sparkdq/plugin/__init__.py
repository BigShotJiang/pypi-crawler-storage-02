from .check_config_registry import load_config_module, register_check_config

__all__ = ["register_check_config", "load_config_module"]
