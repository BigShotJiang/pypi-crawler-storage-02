.. _sparkdq.management:

sparkdq.management
==================

.. automodule:: sparkdq.management
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:
