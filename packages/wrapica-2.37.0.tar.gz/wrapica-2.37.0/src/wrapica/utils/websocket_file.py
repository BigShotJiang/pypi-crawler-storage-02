#!/usr/bin/env python3

"""
Websocket handlers for the live analysis logs
"""