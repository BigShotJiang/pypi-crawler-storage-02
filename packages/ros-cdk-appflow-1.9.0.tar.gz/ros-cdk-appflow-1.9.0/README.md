## Aliyun ROS APPFLOW Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as APPFLOW from '@alicloud/ros-cdk-appflow';
```
