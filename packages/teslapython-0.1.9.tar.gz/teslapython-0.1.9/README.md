Process variable (PV) to 4-20 mA conversion:

    Where,
    X is Process Variable
    LRV is Lower Range Value
    URV is Upper Range Value

4-20 mA to Process variable (PV) conversion:

    Where,
    Y is 4 -20 mA signal
    LRV is Lower Range Value
    URV is Upper Range Value