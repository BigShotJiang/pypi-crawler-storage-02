v0.2.2 (2025-08-07)
======

- Fixes short_name for MLM 5.1

v0.2.1 (2025-06-26)
======

- Fixes distro_version for MLM 5.0 and 5.1

v0.2.0 (2025-05-16)
======

- Build for only one version of python

v0.1.0 (2025-04-08)
======

- Drop cloud specifics from parser.
- Only drop generation id if it exists.
- Fix generation id regex pattern

v0.0.3 (2025-04-02)
======

- Fix bug in import name

v0.0.2 (2025-04-02)
======

- Merge code and add packaging artifacts

v0.0.1 (2024-12-20)
======

- Initial release
