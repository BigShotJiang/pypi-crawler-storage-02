# suse-cloud-image-name-parser
Parse Public Cloud image names that match the SUSE naming convention

API implementation to parse image names that match the SUSE Public Cloud image naming convention.
