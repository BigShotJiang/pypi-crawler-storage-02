# egui-pysync: a server/client for synchronizing states between python and egui UIs

TODO: Write a project documentation
