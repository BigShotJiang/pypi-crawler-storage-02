VERSION = "0.6.1"
__version__ = VERSION
