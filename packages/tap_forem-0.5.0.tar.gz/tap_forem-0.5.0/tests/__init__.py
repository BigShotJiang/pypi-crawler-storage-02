"""Test suite for tap-forem."""
