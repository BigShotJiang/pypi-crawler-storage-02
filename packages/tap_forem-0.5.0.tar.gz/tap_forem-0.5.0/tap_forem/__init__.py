"""Singer tap for the Forem API."""
