"""Tap executable."""

from __future__ import annotations

from tap_forem.tap import TapForem

TapForem.cli()
