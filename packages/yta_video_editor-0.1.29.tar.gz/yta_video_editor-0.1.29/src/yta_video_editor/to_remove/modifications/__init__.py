"""
TODO: Check if we want to keep something from
this module or we can remove it. The interesting
part is the way it was handling the 'start' and
'end' time.
"""