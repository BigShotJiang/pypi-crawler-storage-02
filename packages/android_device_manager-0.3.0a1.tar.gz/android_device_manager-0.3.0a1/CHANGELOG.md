# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-08-06)

- Initial Release
