# AVD Module

Manage Android Virtual Devices (AVDs).

::: android_device_manager.avd.AVDManager

::: android_device_manager.avd.AVDConfiguration

::: android_device_manager.avd.exceptions