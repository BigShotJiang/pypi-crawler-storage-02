# Constants

::: android_device_manager.AndroidProp