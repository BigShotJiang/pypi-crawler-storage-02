# API Reference

Detailed API documentation for **Android Device Manager**.

---

## 🔗 **Contents**

- [AndroidDevice](android_device.md)
- [ADB](adb.md)
- [AVD](avd.md)
- [Emulator](emulator.md)
- [Constants](constants.md)