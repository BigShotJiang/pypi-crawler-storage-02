from .detector import has_blue_color

__all__ = ["has_blue_color"]
