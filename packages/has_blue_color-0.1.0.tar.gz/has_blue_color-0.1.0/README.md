# has-blue-color

Una librería para detectar si una imagen contiene color azul usando OpenCV.

## Instalación
```bash
pip install has-blue-color
