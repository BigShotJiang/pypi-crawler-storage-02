# sage_setup: distribution = sagemath-glucose
# delvewheel: patch

from sage.all__sagemath_combinat import *
