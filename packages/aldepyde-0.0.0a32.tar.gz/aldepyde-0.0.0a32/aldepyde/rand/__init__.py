from aldepyde.rand.RandomProtein import *

__all__ = ['RandomProtein']