from aldepyde.biomolecule.Residue import Residue

__all__ = ['amino_acid']

class amino_acid(Residue):
    pass