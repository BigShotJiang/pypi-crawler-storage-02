from aldepyde.biomolecule.Residue import Residue

__all__ = ['dna']

class dna(Residue):
    pass