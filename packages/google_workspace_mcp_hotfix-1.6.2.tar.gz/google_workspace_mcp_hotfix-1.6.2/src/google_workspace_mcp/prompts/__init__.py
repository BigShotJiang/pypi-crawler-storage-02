"""MCP Prompt modules for Google Workspace."""

__all__ = []
