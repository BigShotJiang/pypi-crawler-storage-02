"""
Desktop environment plugin for Open World Agents.

This plugin provides desktop interaction capabilities including:
- Screen capture
- Mouse and keyboard control
- Window management
"""
