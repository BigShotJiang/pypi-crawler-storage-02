from abc import ABC, abstractmethod


class transformer(ABC):
       @classmethod
       @abstractmethod
       def transform(self):
              pass