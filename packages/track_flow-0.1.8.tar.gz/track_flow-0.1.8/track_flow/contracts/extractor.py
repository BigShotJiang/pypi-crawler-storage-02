from abc import ABC, abstractmethod

class extractor(ABC):
       @classmethod
       @abstractmethod
       def extract(Self):
              pass