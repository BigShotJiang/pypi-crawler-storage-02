https://github.com/KuantumBS/grikod
