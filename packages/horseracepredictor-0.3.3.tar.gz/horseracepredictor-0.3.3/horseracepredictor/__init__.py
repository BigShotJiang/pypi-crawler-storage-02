# horseracepredictor/__init__.py

from .predictor import HorseRacePredictor
