"""Unit tests for SQLSpec loader module.

Comprehensive tests for SQL file loading, parsing, and caching functionality
using CORE_ROUND_3 architecture.
"""
