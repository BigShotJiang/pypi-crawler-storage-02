import logging


log = logging.getLogger("baseoutput")


class baseoutput:
    def __str__(self):
        return "the base class for the output processors, not used directly"
