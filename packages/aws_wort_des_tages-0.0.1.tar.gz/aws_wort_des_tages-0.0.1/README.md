# aws-wort-des-tages

## Install as package

```bash
pip install aws-wort-des-tages
```

```python
from aws_wort_des_tages import ...
```

## Contributing

```bash
# clone the repo
git clone https://github.com/momomozhang/aws-wort-des-tages.git

# install the dev dependencies
make install

# run the tests
make test
```
