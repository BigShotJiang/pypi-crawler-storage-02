# krypto_gui_smalk

gui for [smalk krypto](https://github.com/The220th/alerk_pack/blob/main/alerk_pack/crypto.py) testing.

For more details about smalk and alerk look [this](https://github.com/The220th/alerk).

# Installation

```bash
pip install --upgrade pip
pip3 install krypto_gui_smalk
```

# Start

```bash
krypto_gui_smalk
```

Or just run

```bash
start_krypto_gui_smalk_windows.bat  # windows

bash start_krypto_gui_smalk_linux.sh  # GNU/Linux
```
