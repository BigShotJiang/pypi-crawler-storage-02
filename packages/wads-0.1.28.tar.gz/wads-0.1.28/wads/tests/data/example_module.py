"""Example module for testing package generation"""


def plus(x, y):
    return x + y
