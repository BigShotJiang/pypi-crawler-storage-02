"""
    This algorithm takes the selected instructions and schedules them in
    a linear form.
"""


class InstructionScheduler:
    def schedule(self, graph, frame):
        # TODO: schedule traces in better order.
        # This is optional!
        pass
