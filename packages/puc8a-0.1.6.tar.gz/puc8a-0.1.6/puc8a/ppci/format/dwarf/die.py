class Die:
    """ Base Debugging Information Entry (DIE) """

    pass
