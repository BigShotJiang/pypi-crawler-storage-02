""" Reading and writing of CIL """


def read_cil():
    """ Read CIL code. """
    raise NotImplementedError()


def write_cil():
    """ Write CIL code. """
    raise NotImplementedError()
