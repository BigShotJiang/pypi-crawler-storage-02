from ...common import SourceLocation


class Node:
    """ Base class of all nodes in a AST """

    __slots__ = ()
