""" Generic functions accross several languages """
