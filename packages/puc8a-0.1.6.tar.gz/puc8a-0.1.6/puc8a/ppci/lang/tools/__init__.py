"""
    This module contains the pcc (python compiler compiler).
    It is an alternative to bison or yacc etc..
"""
