""" PUC8a architecture """

from .arch import PUC8aArch

__all__ = ["PUC8aArch"]
