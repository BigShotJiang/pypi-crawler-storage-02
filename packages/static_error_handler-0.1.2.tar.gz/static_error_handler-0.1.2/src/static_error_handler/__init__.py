from .static_error_handler import Ok, Err, Result, panic, __version__

__all__ = ["Ok", "Err", "Result", "panic", "__version__"]
