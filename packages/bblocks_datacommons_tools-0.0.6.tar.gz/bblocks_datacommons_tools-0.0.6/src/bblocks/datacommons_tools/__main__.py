"""Enable ``python -m bblocks.datacommons_tools``."""

from bblocks.datacommons_tools.cli.main import main

if __name__ == "__main__":
    raise SystemExit(main())
