from osbot_utils.base_classes.Kwargs_To_Self import Kwargs_To_Self

DEFAULT_FIELD_NAME__ID             = 'id'
ROW_BASE_CLASS                     = Kwargs_To_Self
SQL_TABLE__MODULE_NAME__ROW_SCHEMA = 'Dynamic_Class__Sqlite__Table'
