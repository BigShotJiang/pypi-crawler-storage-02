from docetl.optimizers.map_optimizer.optimizer import MapOptimizer

__all__ = ["MapOptimizer"]
