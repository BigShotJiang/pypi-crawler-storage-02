from .genie_epics_api import BLOCK_NAMES
