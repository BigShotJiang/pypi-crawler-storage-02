"""
This private module exists to allow testing utility code to be shared between genie_python's
unit tests, and the external system tests.
"""
