.. genie_python documentation master file, created by
   sphinx-quickstart on Tue Aug 19 09:26:50 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to genie_python's documentation!
========================================

Commands
--------

.. toctree::
   :maxdepth: 2

.. automodule:: genie
   :members:

.. automodule:: genie_advanced
   :members:

.. automodule:: genie_alerts
   :members:

.. automodule:: genie_toggle_settings
   :members:
