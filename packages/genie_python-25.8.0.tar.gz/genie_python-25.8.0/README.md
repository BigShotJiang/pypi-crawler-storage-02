# genie_python

Instrument control and scripting library at the ISIS Neutron & Muon source.

---

Documentation: https://isiscomputinggroup.github.io/genie/genie_python

Source: https://github.com/ISISComputingGroup/genie

PyPi: https://pypi.org/project/genie_python/
