# script which will cause an error when imported


def an_error():
    global
