def valid_py2():
    print("Hi!")
    print "Bonjour!"
    return True
