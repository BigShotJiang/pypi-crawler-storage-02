def test_script():
    print("test")
