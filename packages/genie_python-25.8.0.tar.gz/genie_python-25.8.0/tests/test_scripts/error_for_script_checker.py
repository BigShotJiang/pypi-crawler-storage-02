# script which will cause an error in the script checker but is valid python


def set_end():
    end


myend = 10
