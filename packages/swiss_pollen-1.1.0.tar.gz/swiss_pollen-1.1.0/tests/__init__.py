"""Tests for swiss-pollen."""
