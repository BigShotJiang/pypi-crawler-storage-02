# openrouter-haystack

[![PyPI - Version](https://img.shields.io/pypi/v/openrouter-haystack.svg)](https://pypi.org/project/openrouter-haystack)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/openrouter-haystack.svg)](https://pypi.org/project/openrouterhaystack)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install openrouter-haystack
```

## License

`openrouter-haystack` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
