# apolo-apps-client
Apolo internal client for platform-apps API
