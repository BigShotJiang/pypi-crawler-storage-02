from .pyswot import find_school_names, is_academic

__all__ = ["is_academic", "find_school_names"]
