# Example: Figures

```{literalinclude} ../../examples/figures.py
:language: python
:linenos:
```

Output:

```{literalinclude} ../../examples/data/2307.01282/figures_output.txt
```