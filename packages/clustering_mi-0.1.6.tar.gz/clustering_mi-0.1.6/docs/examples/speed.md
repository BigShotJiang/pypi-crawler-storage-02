# Example: Speed

```{literalinclude} ../../examples/speed.py
:language: python
:linenos:
```
