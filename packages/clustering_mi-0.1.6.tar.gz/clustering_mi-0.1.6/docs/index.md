```{toctree}
:maxdepth: 2
:hidden:
:caption: Contents:
:glob:

modules.md
examples/figures.md
```

# clustering-mi

```{include} ../README.md
:start-after: <!-- SPHINX-START -->
```
