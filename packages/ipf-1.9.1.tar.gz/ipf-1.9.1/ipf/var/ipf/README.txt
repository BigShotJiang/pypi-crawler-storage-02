
This directory is used to store log files, pids of daemons, current positions in files being watched, and so on.
