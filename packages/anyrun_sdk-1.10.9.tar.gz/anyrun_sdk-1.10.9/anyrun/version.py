"""Defines ANY.RUN release version."""

__version__ = '1.10.9'
