"""Contains the entry-point to the ViRelAy application."""

from virelay.application import run_cli_app

run_cli_app()
