
from setuptools import setup

setup(package_data={'flask_socketio-stubs': ['__init__.pyi', 'namespace.pyi', 'test_client.pyi', 'METADATA.toml', 'py.typed']})
