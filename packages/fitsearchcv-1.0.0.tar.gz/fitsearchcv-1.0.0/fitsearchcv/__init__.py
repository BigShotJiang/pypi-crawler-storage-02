from .selectors import selector_mean

__all__ = ["selector_mean"]
