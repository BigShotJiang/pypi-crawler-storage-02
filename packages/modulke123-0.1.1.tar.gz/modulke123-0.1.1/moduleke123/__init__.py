def sum(a, b):
    sum = a + b;
    print (sum)