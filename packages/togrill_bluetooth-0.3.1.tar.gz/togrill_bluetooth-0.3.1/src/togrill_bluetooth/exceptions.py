class DecodeError(Exception):
    pass
