from typing import TypedDict


class GetIdResponse(TypedDict):
    IdentityId: str


