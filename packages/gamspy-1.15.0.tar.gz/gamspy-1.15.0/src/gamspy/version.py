from __future__ import annotations

from importlib import metadata

__version__ = metadata.version("gamspy")
