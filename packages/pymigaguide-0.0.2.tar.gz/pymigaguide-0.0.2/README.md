# pymigaguide

An Amiga .guide reader/converter.

