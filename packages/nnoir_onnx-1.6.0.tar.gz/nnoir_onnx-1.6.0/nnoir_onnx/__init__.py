from nnoir_onnx import _version

from .onnx import ONNX
from .utils import *

__version__ = _version.__version__
