from typing import Literal

LLMModel = Literal[
      "gpt-3.5",
      "gpt-3.5-turbo",
      "gpt-4o",
      "mistral-medium-2505"
]