from typing import Literal

STTProvider = Literal[
    "OpenAI",
    "Deepgram"
]