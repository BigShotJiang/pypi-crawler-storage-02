from typing import Literal

STTModel = Literal[
    "gpt-4o-transcribe"
]