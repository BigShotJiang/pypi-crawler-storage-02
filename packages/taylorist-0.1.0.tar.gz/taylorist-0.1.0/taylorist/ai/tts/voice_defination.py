from typing import Literal

TTSVoice = Literal[
    "alloy",
    "alexa"
]