from typing import Literal

TTSModel = Literal[
      "tts-1",
      "tts-1-hd",
]