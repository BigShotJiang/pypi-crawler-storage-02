# Taylorist

Taylorist eliminates all the Provider–Model–API confusion in Taylorist, LLM, STT, TTS, and other AI modalities, enabling usage through a standardized interface with a single API key. Essentially, it is divided into modality-based classes that operate with InputX, X, and OutputX. Taylorist also tracks costs by default.