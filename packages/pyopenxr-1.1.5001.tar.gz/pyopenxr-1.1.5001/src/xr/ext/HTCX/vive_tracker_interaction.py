
NAME = "XR_HTCX_vive_tracker_interaction"
