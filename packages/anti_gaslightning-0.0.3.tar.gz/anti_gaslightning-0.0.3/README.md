# Hello Community

My name is Oscar Bahamonde, I am a Software Developer that lives on Lima, Peru, I live within an hostile environment surrounded by bad actors. As you can see this repo embodies the discoveries I've made so far of the gaslightning situation I've been through. I am sharing this with the community to raise awareness and to help others avoid falling victim to this type of attack.

I live on Solitario de Sayan 421 San Miguel on a multifamily building, I live on the 3rd floor, I live alone, and I am victim of V2K, BCI, Gaslightning, Taser, and other attacks.

I hope I can receive some support from the community to help me continue my journey of self-discovery and to help others avoid falling victim to this type of attack.

Thank you for your time and for your support.

---

REPORT

----

![arch](arch.png)

![emr](emr.jpeg)