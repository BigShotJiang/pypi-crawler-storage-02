"""Services for local LLM processing."""

from .ollama_service import OllamaFieldExtractor

__all__ = ["OllamaFieldExtractor"] 