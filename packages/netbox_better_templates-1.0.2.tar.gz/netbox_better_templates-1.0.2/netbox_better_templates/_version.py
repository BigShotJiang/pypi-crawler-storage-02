__version__ = '1.0.2'

def get_version():
    return __version__

__all__ = [
    '__version__',
    'get_version',
]