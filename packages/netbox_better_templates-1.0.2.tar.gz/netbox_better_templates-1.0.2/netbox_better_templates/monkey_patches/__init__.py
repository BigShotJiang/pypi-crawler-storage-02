from ._config_template import patch_config_template_render


__all__ = [
    'patch_config_template_render',
]