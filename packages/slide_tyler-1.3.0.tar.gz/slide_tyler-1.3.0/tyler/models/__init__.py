"""
Models package initialization.
""" 