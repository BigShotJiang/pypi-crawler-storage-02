=============
Nicolas Cache
=============


.. image:: https://img.shields.io/pypi/v/nicolas-cache.svg
        :target: https://pypi.python.org/pypi/nicolas-cache

.. image:: https://readthedocs.org/projects/nicolas-cache/badge/?version=latest
        :target: https://nicolas-cache.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Python Caching library with tagging support


* Free software: Unlicense
* Documentation: https://nicolas-cache.readthedocs.io.


Features
--------

* TODO


Disclaimer
----------

This project has been mainly developed using Claude Code (claude.ai/code), an AI-powered coding assistant.


Credits
-------

This package was created with Cookiecutter and the `audreyr/cookiecutter-pypackage` project template.
