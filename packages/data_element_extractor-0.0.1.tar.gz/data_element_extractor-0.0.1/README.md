# Data Element Extractor
