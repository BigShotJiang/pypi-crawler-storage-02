``AnalyticsClient`` class
=============================

..  automodule:: ledger_analytics.api
    :members:
