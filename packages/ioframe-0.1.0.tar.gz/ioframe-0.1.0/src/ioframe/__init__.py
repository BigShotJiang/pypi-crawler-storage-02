"""The ``ioframe`` library puts together various dataframe readers and writers."""

from __future__ import annotations

__version__ = "0.1.0"
