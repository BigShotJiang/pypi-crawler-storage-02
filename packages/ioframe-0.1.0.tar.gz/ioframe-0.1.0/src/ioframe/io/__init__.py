"""Package that define the base classes of datframe readers and writers."""

from __future__ import annotations
