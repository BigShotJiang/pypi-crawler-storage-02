from ._version import version, NAME

__version__ = version
__pyproject_name__ = NAME
