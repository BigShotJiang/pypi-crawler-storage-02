"""HUGR extension definitions for tket2 circuits.

| ⚠️ WARNING                  |
|:----------------------------|
| This package has been renamed to `tket-exts`. Please update your dependencies accordingly |

"""

# This is updated by our release-please workflow, triggered by this
# annotation: x-release-please-version
__version__ = "0.10.0"

raise RuntimeError(
    "The `tket2-exts` package has been renamed to `tket-exts`. Please update your dependencies accordingly."
)
