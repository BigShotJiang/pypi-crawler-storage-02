from front import APP_KEY


def mk_config(api):

    return {
        APP_KEY: {'title': 'Illustration App'},
    }
