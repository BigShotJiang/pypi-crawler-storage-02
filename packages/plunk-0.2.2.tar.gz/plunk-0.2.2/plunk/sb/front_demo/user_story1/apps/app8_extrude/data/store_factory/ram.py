def mk_ram_store(**kwargs):
    return dict(**kwargs)
