# code taken from platform_poc
from .ram import mk_ram_store
from .mongodb import mk_mongodb_store
