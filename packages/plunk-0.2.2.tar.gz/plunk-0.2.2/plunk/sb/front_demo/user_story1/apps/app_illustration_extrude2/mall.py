from platform_poc.data.store_factory import mk_ram_store

mall = {'illustration_description_store': mk_ram_store()}
