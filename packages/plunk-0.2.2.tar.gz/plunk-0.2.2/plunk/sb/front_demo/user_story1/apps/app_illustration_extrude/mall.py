from platform_poc.data.store_factory import mk_ram_store


mall = dict(x_store=mk_ram_store())
# mall = {'x_store': dict()}
