import streamlit as st

# url = "http://localhost:8502/0def13cc-e9e4-40a2-b4d1-2c692dd102cb"
url = 'blob:http://localhost:8502/667b3c48-e46c-4be5-a2cd-b8747f59ed24'
st.audio(url)
