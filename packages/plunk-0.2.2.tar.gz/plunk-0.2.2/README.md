
# plunk
A Python utility hub for those homeless code snippets


To install:	```pip install plunk```
