Documentation for SatSim
========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   contributing
   api
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
