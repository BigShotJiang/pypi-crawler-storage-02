"""Tests for `satsim.cli`."""
# import warnings
# warnings.filterwarnings("ignore", category=DeprecationWarning, module="tensorflow")

# from click.testing import CliRunner
# from satsim import cli


# TODO find way to run graph and eager at the same time
# def test_run_graph():

#     runner = CliRunner()
#     result = runner.invoke(cli.main, ['--debug', 'DEBUG', 'run', '--device', '0', '--mode', 'graph', '--output_dir', './.images' ,'./tests/config_dynamic.json'])
#     assert result.exit_code == 0
