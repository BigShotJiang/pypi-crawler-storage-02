from .xp3_tool import uuid, CallAi

__all__ = [
    "uuid",
    "CallAi"
]

__version__ = "3.0"