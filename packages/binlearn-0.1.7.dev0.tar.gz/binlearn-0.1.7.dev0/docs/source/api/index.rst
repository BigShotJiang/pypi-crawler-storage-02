API Reference
=============

Complete API documentation for all binlearn classes and functions.

.. toctree::
   :maxdepth: 2

   methods/index
   base/index
   utils/index
   tools/index
   errors
