User Guide
==========

Comprehensive guide to using binlearn effectively.

.. toctree::
   :maxdepth: 2

   overview
   binning_methods
   data_types
   configuration
   error_handling
   performance
   best_practices
