"""Tests for the binning package."""
