#match.py

class Match:
    def __init__(self):
        pass