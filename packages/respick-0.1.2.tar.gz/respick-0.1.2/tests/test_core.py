from respick.core import find_best_divider

def test_dummy():
    assert find_best_divider(3.3, 0.6) == []
