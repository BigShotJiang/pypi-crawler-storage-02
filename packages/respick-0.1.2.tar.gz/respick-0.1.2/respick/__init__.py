from .core import find_best_divider  # 导出核心函数

__all__ = ["find_best_divider"]      # 控制 from yourcli import * 的行为
