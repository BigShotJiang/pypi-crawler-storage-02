# (removed) Simple TUI is deprecated in favor of advanced_tui.
# This file is intentionally left empty and will be removed from the repository.
