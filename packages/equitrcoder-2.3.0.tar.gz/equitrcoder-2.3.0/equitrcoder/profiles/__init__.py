# Agent profiles for specialized use cases
