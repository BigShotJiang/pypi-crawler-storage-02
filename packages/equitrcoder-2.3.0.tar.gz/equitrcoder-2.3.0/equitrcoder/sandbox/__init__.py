# Sandbox execution components
