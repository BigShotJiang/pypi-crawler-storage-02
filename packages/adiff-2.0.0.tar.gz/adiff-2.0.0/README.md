# adiff

A CLI tool to compare XML files with a main reference XML, and optionally export colored Excel reports.

## Install

```bash
pip install adiff

