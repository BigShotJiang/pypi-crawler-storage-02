from time import sleep

while True:
    sleep(100000)
