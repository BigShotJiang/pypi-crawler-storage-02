# TODO: write tests for the client module
