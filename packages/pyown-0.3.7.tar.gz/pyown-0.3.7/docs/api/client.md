---
title: Client module
summary: Provides the main interface to the OpenWebNet gateway.
---

The Client module provides the main interface to the OpenWebNet gateway.

::: pyown.client.BaseClient

::: pyown.client.Client
    options:
        show_inheritance_diagram: true


::: pyown.client.SessionType
