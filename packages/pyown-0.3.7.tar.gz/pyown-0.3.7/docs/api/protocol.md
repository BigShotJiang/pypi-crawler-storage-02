---
title: Protocol module
summary: Manages the low-level communication with the server.
---

This module manages the low-level communication with the server and provides functions to send and receive messages.


::: pyown.protocol.OWNProtocol
