---
title: Gateway module
summary: Provides the main interface to the OpenWebNet gateway.
---

The Gateway module provides the main interface to the OpenWebNet gateway.

::: pyown.items.gateway.gateway.WhatGateway
    options:
        show_inheritance_diagram: true

::: pyown.items.gateway.gateway.GatewayModel
    options:
        show_inheritance_diagram: true

::: pyown.items.gateway.gateway.Gateway
    options:
        show_inheritance_diagram: true

