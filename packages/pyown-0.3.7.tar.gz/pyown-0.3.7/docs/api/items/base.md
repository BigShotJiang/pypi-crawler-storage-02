---
title: Base item module
summary: Provides the base class for all items.
---

This module provides the base class for all items.

::: pyown.items.base.BaseItem
    options:
        show_inheritance_diagram: true

::: pyown.items.base.CoroutineCallback

::: pyown.items.base.EventMessage

::: pyown.items.utils.ITEM_TYPES
