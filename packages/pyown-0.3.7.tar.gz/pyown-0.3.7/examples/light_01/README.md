# light_01

This example demonstrates how to create a simple light source and control it.