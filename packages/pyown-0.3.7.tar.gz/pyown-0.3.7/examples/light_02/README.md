# light_02

This example demonstrates how to listen for light events from an event client.