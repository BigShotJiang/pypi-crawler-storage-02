# energy_management_01

This example demonstrates how to read events for instantaneous power consumption.