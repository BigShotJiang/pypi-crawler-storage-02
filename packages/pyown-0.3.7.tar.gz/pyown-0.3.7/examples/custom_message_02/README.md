# custom_message_02

This example shows how to connect to a MyHome® gateway and send custom messages.
In this case, we request the energy consumption.