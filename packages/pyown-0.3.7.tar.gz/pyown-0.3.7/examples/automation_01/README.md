# automation_01

This example demonstrates how to manage a blind/shutter using the `Automation` class.