# automation_02

This example demonstrates how to listen for state changes of a blind/shutter using the `Automation` class.