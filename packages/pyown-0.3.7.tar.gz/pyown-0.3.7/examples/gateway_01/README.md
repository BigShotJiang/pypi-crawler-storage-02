# gateway_01

This example shows how to read information from a MyHome® gateway using the `Gateway` class.
