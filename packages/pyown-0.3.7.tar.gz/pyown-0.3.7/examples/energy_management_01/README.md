# energy_management_01

This example demonstrates how to create a simple a energy meter item and read the instantaneous power consumption.
