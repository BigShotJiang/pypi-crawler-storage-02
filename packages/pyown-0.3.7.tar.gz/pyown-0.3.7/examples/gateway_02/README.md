# gateway_02

This example shows how to listen for information changes from a MyHome® gateway using the `Gateway` class.
