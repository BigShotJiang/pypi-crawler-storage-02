# Meteo BZ - API Client

Python client for the meteo API, provided by _Provincia autonoma di Bolzano - Informatica Alto Adige SPA_. Its legal terms can be found [here](https://data.civis.bz.it/legal). The documentation of the API is available [here](https://data.civis.bz.it/dataset/misure-meteo-e-idrografiche).

```
83200MS - Bolzano
23200MS - Meran
35100WS - Jaufenkamm
```
