"""
자동 생성 파일입니다. 직접 수정하지 마세요.
생성일자: 2025-08-12
생성 위치: model/abstract/__init__.py
"""
from .abstract_model import AbstractModel

__all__ = [
    "AbstractModel"
]
