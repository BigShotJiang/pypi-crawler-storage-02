``` bash
$ pip install compose-go
$ docker-compose version
```
