"""Utilities for working with :mod:`.ixmp`.

Code here should be either:

1. For backwards compatibility to earlier versions of ixmp supported according to the
   :ref:`policy-upstream-versions`, or
2. Temporary, pending migration upstream to ixmp itself.
"""

# Currently nothing
