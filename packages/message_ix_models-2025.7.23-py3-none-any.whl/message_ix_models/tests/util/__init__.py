"""Tests of submodules of :mod:`message_ix_models.util`."""
