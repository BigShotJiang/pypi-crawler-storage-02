"""Code for constructing models/scenarios in the MESSAGEix-GLOBIOM model family."""

from .config import Config

__all__ = ["Config"]
