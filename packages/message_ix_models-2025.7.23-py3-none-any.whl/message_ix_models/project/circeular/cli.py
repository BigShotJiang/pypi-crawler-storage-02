import click


@click.group("circeular")
def cli():
    """CircEUlar project.

    https://docs.messageix.org/projects/models/en/latest/project/circeular.html
    """
