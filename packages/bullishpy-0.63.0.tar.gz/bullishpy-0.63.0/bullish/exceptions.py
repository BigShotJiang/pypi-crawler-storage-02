class DatabaseFileNotFoundError(FileNotFoundError):
    """Raised when the database file is not found."""
