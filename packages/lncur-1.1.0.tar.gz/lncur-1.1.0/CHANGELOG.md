# 1.0.3
- rewrite to make the cli into a python package
