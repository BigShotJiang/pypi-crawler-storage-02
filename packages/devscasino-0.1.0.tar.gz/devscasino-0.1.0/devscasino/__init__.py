from .game import play
