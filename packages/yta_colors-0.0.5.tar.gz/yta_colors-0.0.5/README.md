# Youtube Autonomous Colors Module

The way to handle and validate colors.