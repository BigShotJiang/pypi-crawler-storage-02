import os
import queue
import signal
import subprocess
import sys
import threading
import time

import ffmpeg
import numpy as np

from .common import SAMPLE_RATE, LoopWorkerBase, INFO


def _transport(ytdlp_proc, ffmpeg_proc):
    while (ytdlp_proc.poll() is None) and (ffmpeg_proc.poll() is None):
        try:
            chunk = ytdlp_proc.stdout.read(1024)
            ffmpeg_proc.stdin.write(chunk)
        except (BrokenPipeError, OSError):
            pass
    ytdlp_proc.kill()
    ffmpeg_proc.kill()


def _open_stream(url: str, format: str, cookies: str, proxy: str):
    cmd = ['yt-dlp', url, '-f', format, '-o', '-', '-q']
    if cookies:
        cmd.extend(['--cookies', cookies])
    if proxy:
        cmd.extend(['--proxy', proxy])
    ytdlp_process = subprocess.Popen(cmd, stdout=subprocess.PIPE)

    try:
        ffmpeg_process = (ffmpeg.input('pipe:', loglevel='panic').output('pipe:',
                                                                         format='f32le',
                                                                         acodec='pcm_f32le',
                                                                         ac=1,
                                                                         ar=SAMPLE_RATE).run_async(pipe_stdin=True,
                                                                                                   pipe_stdout=True))
    except ffmpeg.Error as e:
        raise RuntimeError(f'Failed to load audio: {e.stderr.decode()}') from e

    thread = threading.Thread(target=_transport, args=(ytdlp_process, ffmpeg_process))
    thread.start()
    return ffmpeg_process, ytdlp_process


class StreamAudioGetter(LoopWorkerBase):

    def __init__(self, url: str, format: str, cookies: str, proxy: str, frame_duration: float) -> None:
        self._cleanup_ytdlp_cache()

        print(f'{INFO}Opening stream: {url}')
        self.ffmpeg_process, self.ytdlp_process = _open_stream(url, format, cookies, proxy)
        self.byte_size = round(frame_duration * SAMPLE_RATE * 4)  # Factor 4 comes from float32 (4 bytes per sample)
        signal.signal(signal.SIGINT, self._exit_handler)

    def __del__(self):
        self._cleanup_ytdlp_cache()

    def _exit_handler(self, signum, frame):
        self.ffmpeg_process.kill()
        if self.ytdlp_process:
            self.ytdlp_process.kill()
        sys.exit(0)

    def _cleanup_ytdlp_cache(self):
        for file in os.listdir('./'):
            if file.startswith('--Frag'):
                os.remove(file)

    def loop(self, output_queue: queue.SimpleQueue[np.array]):
        while self.ffmpeg_process.poll() is None:
            in_bytes = self.ffmpeg_process.stdout.read(self.byte_size)
            if not in_bytes:
                break
            if len(in_bytes) != self.byte_size:
                continue
            audio = np.frombuffer(in_bytes, np.float32).flatten()
            output_queue.put(audio)

        self.ffmpeg_process.kill()
        if self.ytdlp_process:
            self.ytdlp_process.kill()


class LocalFileAudioGetter(LoopWorkerBase):

    def __init__(self, file_path: str, frame_duration: float) -> None:
        print(f'{INFO}Opening local file: {file_path}')
        try:
            self.ffmpeg_process = (ffmpeg.input(file_path,
                                                loglevel='panic').output('pipe:',
                                                                         format='f32le',
                                                                         acodec='pcm_f32le',
                                                                         ac=1,
                                                                         ar=SAMPLE_RATE).run_async(pipe_stdin=True,
                                                                                                   pipe_stdout=True))
        except ffmpeg.Error as e:
            raise RuntimeError(f'Failed to load audio: {e.stderr.decode()}') from e
        self.byte_size = round(frame_duration * SAMPLE_RATE * 4)  # Factor 4 comes from float32 (4 bytes per sample)
        signal.signal(signal.SIGINT, self._exit_handler)

    def _exit_handler(self, signum, frame):
        self.ffmpeg_process.kill()
        sys.exit(0)

    def loop(self, output_queue: queue.SimpleQueue[np.array]):
        while self.ffmpeg_process.poll() is None:
            in_bytes = self.ffmpeg_process.stdout.read(self.byte_size)
            if not in_bytes:
                break
            if len(in_bytes) != self.byte_size:
                continue
            audio = np.frombuffer(in_bytes, np.float32).flatten()
            output_queue.put(audio)

        self.ffmpeg_process.kill()


class DeviceAudioGetter(LoopWorkerBase):

    def __init__(self, device_index: int, frame_duration: float, recording_interval: float) -> None:
        import sounddevice as sd
        if device_index:
            sd.default.device[0] = device_index
        sd.default.dtype[0] = np.float32
        self.frame_duration = frame_duration
        self.recording_frame_num = max(1, round(recording_interval / frame_duration))

        device_name = sd.query_devices(sd.default.device[0])['name']
        print(f'{INFO}Recording device: {device_name}')

    def loop(self, output_queue: queue.SimpleQueue[np.array]):

        def audio_callback(indata: np.ndarray, frames: int, time_info, status) -> None:
            if status:
                print(status)

            audio = indata.flatten()
            split_audios = np.array_split(audio, self.recording_frame_num)
            for split_audio in split_audios:
                output_queue.put(split_audio)

        import sounddevice as sd
        with sd.InputStream(
            samplerate=SAMPLE_RATE,
            blocksize=round(SAMPLE_RATE * self.frame_duration * self.recording_frame_num),
            channels=1,
            callback=audio_callback
        ):
            while True:
                time.sleep(5)
