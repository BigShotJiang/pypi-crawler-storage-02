========
Examples
========

A collection of Jupyter Notebooks to serve as interactive tutorials.

.. toctree::
    :maxdepth: 1

    notebooks/01_Quickstart
    notebooks/02_Visualization
    notebooks/03_TemplateVersions
