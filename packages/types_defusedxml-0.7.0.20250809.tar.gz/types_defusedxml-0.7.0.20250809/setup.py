
from setuptools import setup

setup(package_data={'defusedxml-stubs': ['ElementTree.pyi', '__init__.pyi', 'cElementTree.pyi', 'common.pyi', 'expatbuilder.pyi', 'expatreader.pyi', 'lxml.pyi', 'minidom.pyi', 'pulldom.pyi', 'sax.pyi', 'xmlrpc.pyi', 'METADATA.toml', 'py.typed']})
