// Copyright 2018-2025 contributors to the OpenLineage project
// SPDX-License-Identifier: Apache-2.0
pub mod test_alias_resolving;
mod test_use;
pub mod tests_alter;
pub mod tests_copy;
pub mod tests_create;
pub mod tests_cte;
pub mod tests_delete;
pub mod tests_drop;
pub mod tests_error_handling;
pub mod tests_insert;
pub mod tests_merge;
pub mod tests_select;
pub mod tests_tpcds;
pub mod tests_truncate;
pub mod tests_update;
