// Copyright 2018-2025 contributors to the OpenLineage project
// SPDX-License-Identifier: Apache-2.0

fn main() {
    pyo3_build_config::add_extension_module_link_args();
}
