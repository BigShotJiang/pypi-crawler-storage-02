:doc:`/index`

.. _deepsearch_label:

DeepSearch
==========

.. toctree::
   :maxdepth: 3

.. automodule:: deepdiff.search

.. autoclass:: grep
    :members:

.. autoclass:: DeepSearch
    :members:

Back to :doc:`/index`
