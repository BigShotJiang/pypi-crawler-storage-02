<template>
  <Suspense>
    <router-view />
  </Suspense>
</template>

<script setup></script>
