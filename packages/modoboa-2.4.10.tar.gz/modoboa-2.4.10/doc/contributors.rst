Contributors
============

.. Add yourself

- `Antidot <http://antidot.com>`_
- `Bearstech <http://bearstech.com>`_
- `CAP-REL <https://cap-rel.fr/>`_
- `Dalnix <https://www.dalnix.se/>`_
