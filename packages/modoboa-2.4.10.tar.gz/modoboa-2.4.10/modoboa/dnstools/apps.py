from django.apps import AppConfig


class DnstoolsConfig(AppConfig):
    name = "modoboa.dnstools"
