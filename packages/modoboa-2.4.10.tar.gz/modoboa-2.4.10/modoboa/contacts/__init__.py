default_app_config = "modoboa.contacts.apps.ModoboaContactsConfig"
