from mcp_server_gaokao.tools.query_major_info import QueryMajorInfo

__all__ = [
    "QueryMajorInfo",
]
