from mcp_server_gaokao.server import main


