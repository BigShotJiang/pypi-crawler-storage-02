This module lets you notify partners about sent payment or debit orders.

You can do that by e-mail and/or by SMS. It is automated by default.
