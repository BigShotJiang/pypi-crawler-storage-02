- Multiple SMS notifications to the same partner cannot be sent in
  batch. Always group payments before notifying. Odoo considers these
  SMS as duplicated and avoids sending more than one per batch. This
  behavior is hardcoded.
