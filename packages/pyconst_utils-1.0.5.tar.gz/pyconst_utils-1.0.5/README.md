# constant
Constant type to enforce constness and immutability in Python