# Frequenz Client Common Library Release Notes

## Summary

This release introduces the `v1alpha8` module to support a new API version.

## Upgrading

<!-- Here goes notes on how to upgrade from previous versions, including deprecations and what they should be replaced with -->

## New Features

- Provide access to new API using new `v1alpha8` module.
- Mapping for the new `Event` message has been added.

## Bug Fixes

- Updated display of protobuf version warnings
