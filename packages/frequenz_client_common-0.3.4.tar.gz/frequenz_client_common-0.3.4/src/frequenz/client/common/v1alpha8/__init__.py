# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Types introduced or modified in the v1alpha8 version of the common api."""
