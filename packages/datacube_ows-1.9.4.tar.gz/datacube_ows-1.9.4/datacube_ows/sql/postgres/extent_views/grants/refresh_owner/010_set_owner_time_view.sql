-- Set owner of time view.

ALTER MATERIALIZED VIEW ows.time_view OWNER TO ows_view_owner;
