-- Granting read permission to materialised view

GRANT SELECT ON ows.space_time_view TO {role};
