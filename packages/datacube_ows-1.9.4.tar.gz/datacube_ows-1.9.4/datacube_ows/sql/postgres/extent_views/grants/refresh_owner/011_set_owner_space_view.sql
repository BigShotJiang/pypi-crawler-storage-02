-- Set owner of space view.

ALTER MATERIALIZED VIEW ows.space_view OWNER TO ows_view_owner;
