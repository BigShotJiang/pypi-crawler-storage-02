-- Granting permission to space view to owner role

GRANT agdc_user TO ows_view_owner;
