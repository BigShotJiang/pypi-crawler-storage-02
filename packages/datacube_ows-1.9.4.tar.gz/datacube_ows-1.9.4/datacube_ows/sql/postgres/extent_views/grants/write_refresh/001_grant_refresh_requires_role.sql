-- Granting View Owner role (refresh permissions)

GRANT ows_view_owner TO {role};
