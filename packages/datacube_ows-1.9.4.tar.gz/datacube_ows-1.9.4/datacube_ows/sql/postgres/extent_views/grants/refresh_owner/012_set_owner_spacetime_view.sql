-- Set owner of space-time view.

ALTER MATERIALIZED VIEW ows.space_time_view OWNER TO ows_view_owner;
