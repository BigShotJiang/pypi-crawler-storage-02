-- Refreshing combined SPACE-TIME materialized view (concurrently)

REFRESH MATERIALIZED VIEW CONCURRENTLY ows.space_time_view
