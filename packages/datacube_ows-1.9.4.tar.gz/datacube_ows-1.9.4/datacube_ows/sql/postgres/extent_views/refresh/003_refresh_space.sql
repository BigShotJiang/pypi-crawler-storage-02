-- Refreshing SPACE materialized view (blocking)

REFRESH MATERIALIZED VIEW ows.space_view
