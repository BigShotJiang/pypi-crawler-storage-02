-- Refreshing TIME materialized view (Blocking)

REFRESH MATERIALIZED VIEW ows.time_view
