-- Grant read access to ODC (agdc) tables to view owner role.

grant usage on schema agdc to ows_view_owner;
