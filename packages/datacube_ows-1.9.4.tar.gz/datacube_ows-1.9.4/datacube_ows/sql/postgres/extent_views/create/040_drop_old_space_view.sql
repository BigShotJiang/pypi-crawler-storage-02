-- Dropping OLD space view

DROP MATERIALIZED VIEW IF EXISTS ows.space_view
