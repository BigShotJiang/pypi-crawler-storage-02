-- Dropping OLD spacetime view (and indexes)

DROP MATERIALIZED VIEW IF EXISTS ows.space_time_view_old
