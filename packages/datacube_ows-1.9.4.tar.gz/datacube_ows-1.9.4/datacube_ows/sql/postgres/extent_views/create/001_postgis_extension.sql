-- Installing Postgis extensions

create extension if not exists postgis
