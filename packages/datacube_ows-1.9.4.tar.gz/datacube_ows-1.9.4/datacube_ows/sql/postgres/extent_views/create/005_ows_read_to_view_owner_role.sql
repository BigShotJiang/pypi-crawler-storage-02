-- Grant read access to OWS tables to view owner role.

GRANT USAGE ON SCHEMA ows TO ows_view_owner;
