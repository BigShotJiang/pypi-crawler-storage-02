-- Renaming new Materialised View Index 3/4

ALTER INDEX ows.space_time_view_ds_idx_new
  RENAME TO space_time_view_ds_idx
