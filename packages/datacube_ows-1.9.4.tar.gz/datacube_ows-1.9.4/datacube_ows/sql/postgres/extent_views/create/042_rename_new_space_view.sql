-- Renaming NEW space_view

ALTER MATERIALIZED VIEW ows.space_view_new
RENAME to space_view
