-- Setting default timezone to UTC

set timezone to 'Etc/UTC'
