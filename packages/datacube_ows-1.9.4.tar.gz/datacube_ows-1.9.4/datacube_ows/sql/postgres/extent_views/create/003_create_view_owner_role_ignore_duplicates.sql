-- Create database role to own the materialised views

create role ows_view_owner;
