-- Renaming new Materialised View Index 2/4

ALTER INDEX ows.space_time_view_time_idx_new
  RENAME TO space_time_view_time_idx
