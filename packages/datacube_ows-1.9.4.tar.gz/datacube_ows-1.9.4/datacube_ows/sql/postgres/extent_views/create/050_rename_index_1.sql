-- Renaming new Materialised View Index 1/4

ALTER INDEX ows.space_time_view_geom_idx_new
  RENAME TO space_time_view_geom_idx
