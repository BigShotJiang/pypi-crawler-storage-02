-- Renaming new Materialised View Index 4/4

ALTER INDEX ows.space_time_view_idx_new
  RENAME TO space_time_view_idx
