-- Renaming NEW time_view

ALTER MATERIALIZED VIEW ows.time_view_new
  RENAME TO time_view
