-- Dropping OLD time view

DROP MATERIALIZED VIEW IF EXISTS ows.time_view
