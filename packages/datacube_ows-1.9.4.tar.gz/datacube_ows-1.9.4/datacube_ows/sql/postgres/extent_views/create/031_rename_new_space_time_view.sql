-- Renaming new view to space_time_view (OWS back up)

ALTER MATERIALIZED VIEW ows.space_time_view_new
RENAME to space_time_view
