-- Granting agdc_user role to {role}

GRANT agdc_user to {role};
