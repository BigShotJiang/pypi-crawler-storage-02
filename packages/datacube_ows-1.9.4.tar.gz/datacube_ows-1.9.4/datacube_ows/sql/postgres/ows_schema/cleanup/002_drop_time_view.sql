-- Dropping OLD time view

DROP MATERIALIZED VIEW IF EXISTS time_view;
