-- Dropping OLD space view

DROP MATERIALIZED VIEW IF EXISTS space_view;
