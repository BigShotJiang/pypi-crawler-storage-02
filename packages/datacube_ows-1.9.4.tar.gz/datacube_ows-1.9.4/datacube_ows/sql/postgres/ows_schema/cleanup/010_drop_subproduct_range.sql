-- Dropping OLD subproduct range table.

DROP TABLE IF EXISTS wms.sub_product_ranges;
