-- Dropping OLD multiproduct range table.

DROP TABLE IF EXISTS wms.multiproduct_ranges;
