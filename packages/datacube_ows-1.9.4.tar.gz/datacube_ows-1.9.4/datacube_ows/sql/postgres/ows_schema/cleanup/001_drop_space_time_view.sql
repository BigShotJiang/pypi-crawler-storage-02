-- Dropping OLD spacetime view (and indexes)

DROP MATERIALIZED VIEW IF EXISTS space_time_view;
