-- Dropping OLD product range table.

DROP TABLE IF EXISTS wms.product_ranges;
