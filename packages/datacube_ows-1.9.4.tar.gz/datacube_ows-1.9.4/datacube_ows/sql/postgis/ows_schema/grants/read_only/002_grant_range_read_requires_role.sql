-- Granting select on layer ranges table to {role}

GRANT SELECT ON ows.layer_ranges TO {role};
