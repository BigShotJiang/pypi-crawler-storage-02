-- Granting odc_user role to {role}

GRANT odc_user to {role};
