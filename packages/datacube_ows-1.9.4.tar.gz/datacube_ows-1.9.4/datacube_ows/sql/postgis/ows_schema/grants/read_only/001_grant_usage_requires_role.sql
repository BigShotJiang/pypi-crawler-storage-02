-- Granting usage on schema

GRANT USAGE ON SCHEMA ows TO {role}
