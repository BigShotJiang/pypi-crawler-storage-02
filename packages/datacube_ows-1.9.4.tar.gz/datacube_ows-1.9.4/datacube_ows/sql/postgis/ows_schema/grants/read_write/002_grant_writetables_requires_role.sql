-- Granting update/insert/delete on all tables in schema

GRANT update, select, insert, delete ON ALL TABLES IN SCHEMA ows TO {role}
