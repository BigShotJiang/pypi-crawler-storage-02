-- Creating/replacing ows schema

create schema if not exists ows;
