# Copyright (c) Alibaba, Inc. and its affiliates.
memory_mapping = {}
