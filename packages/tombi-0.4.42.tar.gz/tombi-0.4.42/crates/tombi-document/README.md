# Document

This crate is a library for representing TOML data.

It is for representing data that supports Serialize/Deserialize by serde.
