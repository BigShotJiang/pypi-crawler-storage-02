.. Drizzle documentation master file, created by
   sphinx-quickstart on Tue Oct 11 09:04:48 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

The Drizzle Library 
===================

.. currentmodule:: drizzle

Contents:

.. toctree::
   :maxdepth: 2

   user
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
