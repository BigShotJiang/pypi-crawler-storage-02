"""Configuration settings for the PEM application."""

DATABASE_URL = "sqlite:///pem.db"
