"""
This library generates cardiac segmentations in CBCT images
"""
__version__ = '0.1.1'