# AiologySimilarity

This is an easy to use similarity detection package which you can easily setting it up and start working with it !!

To download ,and use this package : `pip install AiologySimilarity`

This package is subset package of Aiology ,and it works offline without any AI token !!

Have a look at [Aiology Website](https://Aiology.pythonanywhere.com)

# Similarity

This package only includes this module ,and this module includes two functions :

`check_words` -> To check for similarity between words

`check_frames` -> To check for similarity between two frames

> [!NOTE]
>All of this methods introduced in the package guide


# Used Algorithms

This package is used two algorithms ,one for words similarity detection ,and one for frames similarity detection.

I wrote all this algorithms based on my math knowledge ,and I like to call them IMA-SAME-ALGORITHM (used for images) ,and WORD-SAME-ALGORITHM (used for words) :D


# What's new ?

fix some bugs


# Conclusion

This is a powerful ,but small ai package which provide you useful tools

I hope this will be useful for you


### Single Star

### Seyed Moied Seyedi 