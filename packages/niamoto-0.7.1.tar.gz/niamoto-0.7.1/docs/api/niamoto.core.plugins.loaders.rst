niamoto.core.plugins.loaders package
====================================

Submodules
----------

niamoto.core.plugins.loaders.direct\_reference module
-----------------------------------------------------

.. automodule:: niamoto.core.plugins.loaders.direct_reference
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.loaders.join\_table module
-----------------------------------------------

.. automodule:: niamoto.core.plugins.loaders.join_table
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.loaders.nested\_set module
-----------------------------------------------

.. automodule:: niamoto.core.plugins.loaders.nested_set
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.loaders.spatial module
-------------------------------------------

.. automodule:: niamoto.core.plugins.loaders.spatial
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.loaders.stats\_loader module
-------------------------------------------------

.. automodule:: niamoto.core.plugins.loaders.stats_loader
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: niamoto.core.plugins.loaders
   :members:
   :show-inheritance:
   :undoc-members:
