
.. image:: https://badge.fury.io/py/galaxy-test-base.svg
   :target: https://pypi.org/project/galaxy-test-base/



Overview
--------

The Galaxy_ testing base package.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
