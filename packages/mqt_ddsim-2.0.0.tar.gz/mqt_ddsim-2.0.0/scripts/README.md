# Scripts for MQT DDSIM

The scripts in this folder should help to replicate the results we published in papers.
However, please note that these scripts assume a certain behavior of the simulator that may (and in fact very likely) change in the future.

A good idea to get started is to check out the last commit where a particular script has been changed and run it from there.
