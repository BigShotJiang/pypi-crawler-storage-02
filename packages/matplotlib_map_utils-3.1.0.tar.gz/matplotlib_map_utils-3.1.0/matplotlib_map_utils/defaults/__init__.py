from .north_arrow import _DEFAULTS_NA
from .scale_bar import _DEFAULTS_SB

__all__ = ["_DEFAULTS_NA","_DEFAULTS_SB"]