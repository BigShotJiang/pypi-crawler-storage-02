# DataversePython
Authenticate and work with Dataverse tables over Python and Pandas
