import pathlib as pl

FileType = str | pl.Path
