"""
Niteco - Collection of Python packages and tools.
"""

__version__ = "0.1.0"