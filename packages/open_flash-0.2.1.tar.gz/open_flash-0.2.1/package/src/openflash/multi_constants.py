# # multi_constants.py
# Constants
# 0/false if not heaving, 1/true if yes heaving
g = 9.81
rho = 1023
#-> calculate omega from m0, g