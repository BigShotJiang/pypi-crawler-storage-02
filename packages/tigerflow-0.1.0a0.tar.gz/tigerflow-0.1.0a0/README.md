# Tigerflow

A pipeline framework optimized for HPC with Slurm integration.
