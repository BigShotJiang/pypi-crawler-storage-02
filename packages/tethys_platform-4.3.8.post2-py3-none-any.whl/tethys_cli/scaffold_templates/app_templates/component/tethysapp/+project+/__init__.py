# Included for native namespace package support
