"""
********************************************************************************
* Name: tethys_config/__init__.py
* Author: Nathan Swain
* Created On: 2014
* Copyright: (c) Brigham Young University 2014
* License: BSD 2-Clause
********************************************************************************
"""

# Load the custom app config
default_app_config = "tethys_config.apps.TethysPortalConfig"
