"""
********************************************************************************
* Name: models.py
* Author: Nathan Swain
* Created On: 2014
* Copyright: (c) Brigham Young University 2014
* License: BSD 2-Clause
********************************************************************************
"""

from django.db import models


class SettingsCategory(models.Model):
    name = models.TextField(max_length=30)

    class Meta:
        verbose_name = "Settings Category"
        verbose_name_plural = "Site Settings"
        ordering = ["pk"]

    def __str__(self):
        return self.name


class Setting(models.Model):
    name = models.TextField(max_length=30)
    content = models.TextField(max_length=500, blank=True)
    date_modified = models.DateTimeField("date modified", auto_now=True)
    category = models.ForeignKey(SettingsCategory, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

    @classmethod
    def as_dict(cls):
        all_settings = cls.objects.all()

        settings_dict = dict()

        for setting in all_settings:
            code_name = setting.name.lower().replace(" ", "_")
            settings_dict[code_name] = setting.content

        return settings_dict


def get_custom_template(name, default):
    custom_template = Setting.objects.get(name=name).content
    if custom_template:
        template = (
            custom_template.lstrip("/")
            if custom_template.startswith("/")
            else custom_template
        )
    else:
        template = default
    return template
