/*****************************************************************************
 * FILE: tethys_datasets.js
 * DATE: 2014
 * AUTHOR: Nathan Swain
 * COPYRIGHT: (c) Brigham Young University 2014
 * LICENSE: BSD 2-Clause
 *****************************************************************************/