"""
********************************************************************************
* Name: __init__.py
* Author: tbayer
* Created On: February 12, 2019
* Copyright: (c) Aquaveo 2018
********************************************************************************
"""

default_app_config = "tethys_quotas.apps.TethysQuotasConfig"
