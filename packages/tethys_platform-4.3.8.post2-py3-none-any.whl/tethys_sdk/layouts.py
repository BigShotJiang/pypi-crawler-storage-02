"""
********************************************************************************
* Name: layouts.py
* Author: Nathan Swain
* Created On: 29 June 2021
* License: BSD 2-Clause
********************************************************************************
"""

# flake8: noqa
# DO NOT ERASE
from tethys_layouts.views.map_layout import MapLayout
