# flake8: noqa
from .deprecation import deprecation_warning

DOCS_BASE_URL = "https://docs.tethysplatform.org/en/stable/"
