"""
********************************************************************************
* Name: tethys_compute/__init__.py
* Author: Scott Christensen
* Created On: 2015
* Copyright: (c) Brigham Young University 2015
* License: BSD 2-Clause
********************************************************************************
"""

default_app_config = "tethys_compute.apps.TethysComputeConfig"
