class DaskJobException(Exception):
    """
    Custom Dask job exception.
    """

    pass
