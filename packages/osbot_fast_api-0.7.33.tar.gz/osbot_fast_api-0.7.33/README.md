# OSBot-Fast-API
OSBot helpers for FastAPI..
