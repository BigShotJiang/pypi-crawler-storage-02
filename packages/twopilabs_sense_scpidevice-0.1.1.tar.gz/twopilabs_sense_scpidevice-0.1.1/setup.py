from setuptools import setup
setup() # Use configuration from setup.cfg
