pidibble.baserecord module
==========================

.. automodule:: pidibble.baserecord
   :members:
   :show-inheritance:
   :undoc-members:
