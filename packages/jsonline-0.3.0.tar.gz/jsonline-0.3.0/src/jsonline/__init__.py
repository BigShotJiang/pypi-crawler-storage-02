from .jsonline import JsonLine, open

__version__ = "0.2.1"
__all__ = ["JsonLine", "open"]
