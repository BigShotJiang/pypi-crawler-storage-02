# EnOcean ESP3 to ESP2 Gateway Adapter

EnOcean gateway adapter from ESP3 to ESP2 for [Eltako Home Assistant Integration](https://github.com/grimmpp/home-assistant-eltako).

This component is mainly required to support USB300, USB400 and USB515 (Wireless EnOcean USB stick/transceiver) which is using ESP3 protocol unlike all other Eltako devices which are using ESP2.

Support for [Enocean Multigateway (MGW) LAN and Wifi](https://www.piotek.de/PioTek-MGW-POE). 
