tinymce.addI18n('fr', {
    "H3 header": "En-tête H3",
    "H4 header": "En-tête H4",
    "Toggle H3 header": "Basculer l'en-tête H3",
    "Toggle H4 header": "Basculer l'en-tête H4"
});
