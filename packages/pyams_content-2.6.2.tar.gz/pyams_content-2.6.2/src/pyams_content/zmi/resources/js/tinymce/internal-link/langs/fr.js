tinymce.addI18n('fr', {
    "Link list": "Liste de liens",
    "Toggle h3 header": "En-tête H3",
    "Toggle h4 header": "En-tête H4",
    "Insert internal link": "Insérer un lien interne",
    "Internal link...": "Lien interne...",
    "Internal number": "N° interne",
    "Link target unique reference": "N° interne de la cible du lien",
    "Link text": "Texte à afficher",
    "Displayed link text content": "Texte du lien",
    "Internal number and link text are required!":
        "Le numéro interne et le texte à afficher sont obligatoires !",
    "Custom styles": "Styles spécifiques"
});
