# Quantum Machine Learning

```{toctree}
:maxdepth: 1

basic
binary
iris
hybrid
```
