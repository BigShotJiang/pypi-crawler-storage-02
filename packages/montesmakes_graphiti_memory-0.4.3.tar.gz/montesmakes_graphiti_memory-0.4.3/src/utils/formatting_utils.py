"""Formatting utilities for Graphiti MCP Server.

This module contains functions for formatting and transforming data
structures, particularly for API responses and result formatting.
"""

from typing import Any

from graphiti_core.edges import EntityEdge


def format_fact_result(edge: EntityEdge) -> dict[str, Any]:
    """Format an entity edge into a readable result.

    Since EntityEdge is a Pydantic BaseModel, we can use its built-in serialization capabilities.

    Args:
        edge: The EntityEdge to format

    Returns:
        A dictionary representation of the edge with serialized dates and excluded embeddings
    """
    result = edge.model_dump(
        mode="json",
        exclude={
            "fact_embedding",
        },
    )
    result.get("attributes", {}).pop("fact_embedding", None)
    return result
