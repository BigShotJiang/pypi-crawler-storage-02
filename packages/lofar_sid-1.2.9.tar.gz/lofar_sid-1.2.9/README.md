# lofar_sid

This Repo contains the  Following Proto defintions:

*  hosted by the TANGO-opah-GRPC  (StationName:50032) 


In order to use this in your python project you can use the PIP_EXTRA_INDEX_URL , e.g.

 use PIP_EXTRA_INDEX_URL = https://git.astron.nl/api/v4/projects/772/packages/pypi/simple

