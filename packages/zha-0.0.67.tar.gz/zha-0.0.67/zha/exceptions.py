"""Exceptions for Zigbee Home Automation."""


class ZHAException(Exception):
    """Base ZHA exception."""
