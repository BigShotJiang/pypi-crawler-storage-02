"""Setup file for zha."""

import setuptools

if __name__ == "__main__":
    setuptools.setup()
