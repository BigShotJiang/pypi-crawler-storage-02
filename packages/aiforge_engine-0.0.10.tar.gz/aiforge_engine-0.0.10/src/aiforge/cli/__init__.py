"""AIForge CLI 模块"""

from .main import main

__all__ = ["main"]
