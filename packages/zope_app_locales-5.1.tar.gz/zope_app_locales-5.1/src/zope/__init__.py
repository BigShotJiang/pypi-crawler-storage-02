__import__('pkg_resources').declare_namespace(__name__)  # pragma: no cover
