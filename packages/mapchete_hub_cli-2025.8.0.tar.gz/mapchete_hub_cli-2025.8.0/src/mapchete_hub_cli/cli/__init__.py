from mapchete_hub_cli.cli.main import mhub


__all__ = ["mhub"]
