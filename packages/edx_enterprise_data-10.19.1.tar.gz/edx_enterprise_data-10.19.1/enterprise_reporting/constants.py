"""
Constants for enterprise_reporting.
"""


SFTP_OPS_GENIE_EMAIL_ALERT_FROM_EMAIL = "enterprise-integrations@edx.org"
SFTP_OPS_GENIE_EMAIL_ALERT_EMAILS = ['enterprise-reporting-sftp@2u-internal.opsgenie.net']
