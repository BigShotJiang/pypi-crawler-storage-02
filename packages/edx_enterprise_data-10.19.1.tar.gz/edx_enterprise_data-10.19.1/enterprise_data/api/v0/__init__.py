"""
API endpoint for enterprise data app.
"""
