"""
Enterprise data api application. This Django app exposes API endpoints used by enterprises.
"""

__version__ = "10.19.1"
