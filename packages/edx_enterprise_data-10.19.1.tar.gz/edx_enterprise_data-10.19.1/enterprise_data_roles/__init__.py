"""
Enterprise data roles application. This Django app contains logic for user roles and permission checks.
"""
