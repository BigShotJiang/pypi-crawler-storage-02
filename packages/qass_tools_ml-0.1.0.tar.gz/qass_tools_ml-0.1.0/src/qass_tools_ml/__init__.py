def main() -> None:
    print("Hello from qass-tools-ml!")
