"""
Placeholder package for predicat-events.
"""
__all__ = []
__version__ = "0.0.0a1"
