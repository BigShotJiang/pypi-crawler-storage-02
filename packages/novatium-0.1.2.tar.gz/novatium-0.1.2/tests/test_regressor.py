def test_regressor_import():
    from novatium import NovaRegressor
    assert NovaRegressor is not None
