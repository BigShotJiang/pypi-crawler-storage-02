from bluer_journal import VERSION


def test_version():
    assert VERSION
