# tadamz-gui

A frontend for the targeted analysis of LC-MS(/MS) data using the tadamz package.

## Usage

To open the GUI, enter `tadamz_gui` in the command line.
