with open("{{ filename }}", "r") as file:
    exec(file.read())
