#!/usr/bin/env python

import greetings

print(greetings.message)
