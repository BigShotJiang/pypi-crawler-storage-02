def validate():
    """Helper validate function"""
    return "helper validate"
