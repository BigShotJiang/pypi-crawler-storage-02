#!/usr/bin/env python

from greeting import message

print(message)
