from . import greeting

__all__ = ["message"]

message = greeting.message
