"""Version information for the package."""

__version__ = "3.0.0"
__build__ = 0x030000
