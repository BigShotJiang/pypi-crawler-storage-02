"""Helper utilities."""


def helper_function(data):
    """Helper function for processing data."""
    return f"Helped: {data}"
