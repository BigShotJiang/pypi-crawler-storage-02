"""Greeting module"""


def get_greeting(name):
    return f"Hello, {name}!"
