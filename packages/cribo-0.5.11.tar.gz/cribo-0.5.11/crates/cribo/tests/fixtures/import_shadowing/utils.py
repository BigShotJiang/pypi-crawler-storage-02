# Top-level utils - this is what will be found!
def transform(text):
    return "TOP_LEVEL_UTILS"
