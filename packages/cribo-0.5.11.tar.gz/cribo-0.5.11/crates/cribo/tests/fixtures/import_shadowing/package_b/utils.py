# Package B's utils - converts to lowercase
def transform(text):
    return text.lower() + "_from_package_b"
