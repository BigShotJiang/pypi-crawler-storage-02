# API package

# Empty expressions in package init (should be removed)
42  # Should be removed
"api package"  # Should be removed
None  # Should be removed
