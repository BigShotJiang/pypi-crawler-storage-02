"""Set module version.

Year.Month.Day[alpha/beta/..]
Alphas will be numbered like this -> 2024.12.10a0
"""
VERSION = '2025.08.04'
