from wagtail.models import Page


class TestPage(Page):
    pass
