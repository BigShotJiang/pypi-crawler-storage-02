__version__ = "1.0.5"

from .letrbinr import LetrBinr
from .letrbinr import LetrBinRAND