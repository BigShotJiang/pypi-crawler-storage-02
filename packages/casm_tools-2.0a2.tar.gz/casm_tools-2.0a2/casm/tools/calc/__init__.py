"""The casm-calc program"""
