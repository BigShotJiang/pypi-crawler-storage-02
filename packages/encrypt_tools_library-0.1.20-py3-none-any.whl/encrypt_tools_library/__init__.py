__version__ = "0.1.20"  # 必须与pyproject.toml完全一致
__name__ = "encrypt-tools-library"  # 可选但推荐
