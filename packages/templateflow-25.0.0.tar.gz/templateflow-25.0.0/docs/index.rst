.. include:: links.rst

About
-----
.. include:: ../README.rst
    :start-line: 3

Contents
--------
.. toctree::
    :maxdepth: 2

    installation
    examples
    cli
    datalad
    api
    changes
