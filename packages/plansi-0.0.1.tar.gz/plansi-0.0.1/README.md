# 👾 plansi

Plays videos as ANSI

## ▶ Usage

```bash
# play to terminal
uvx plansi video.mp4

# write to asciinema file
uvx plansi video.mp4 video.cast
```
