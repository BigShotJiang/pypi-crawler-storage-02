"""plansi - Plays videos as differential ANSI in terminals."""

from .player import Player

__version__ = "0.0.1"
__all__ = ["Player"]
