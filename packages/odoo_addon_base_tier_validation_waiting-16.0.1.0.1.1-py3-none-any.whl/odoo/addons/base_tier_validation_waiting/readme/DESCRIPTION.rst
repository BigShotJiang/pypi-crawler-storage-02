This module extends base_tier_validation to add an initial **"waiting"** status to tier reviews.
It also auto moves next review to pending status when needed and handles notification if set.
