Set "Notify reviewers on reaching pending" if you want to send a notification when pending status is reached
