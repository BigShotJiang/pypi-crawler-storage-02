class InvalidAttributesError(Exception):
    pass


class FlexFieldCreationError(Exception):
    pass
