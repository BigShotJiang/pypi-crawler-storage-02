django_jsoneditor_ace_options = {
    highlightActiveLine: true,
};
