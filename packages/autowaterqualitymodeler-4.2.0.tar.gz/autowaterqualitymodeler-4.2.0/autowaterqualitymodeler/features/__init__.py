"""
特征计算模块 - 提供各种光谱特征计算功能
"""

from .calculator import FeatureCalculator

__all__ = ['FeatureCalculator']