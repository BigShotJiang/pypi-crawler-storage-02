#!/usr/bin/env python3
"""
Tucker Trucker - Boston Terrier Delivery Game
Entry point for running the game
"""

if __name__ == "__main__":
    from tucker_trucker.main import main
    main()
