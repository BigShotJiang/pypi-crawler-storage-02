# Tucker Trucker 🐕🚛

A 2D market timing and strategy game featuring Tucker, a Boston Terrier who runs a delivery business in a bustling pet marketplace!

## Game Overview

You play as Tucker, an entrepreneurial Boston Terrier who travels between different pet markets to buy and sell goods. Your goal is to make smart trading decisions, timing your purchases and sales to maximize profit while managing your limited cargo capacity.

## Features

- **Adorable Boston Terrier protagonist** with custom sprite design
- **Dynamic market system** with fluctuating prices and demand
- **5 unique pet markets** scattered around the game world
- **5 different goods types**: Bones, Treats, Toys, Food, and Medicine
- **Real-time trading mechanics** with supply and demand
- **Day/night cycle** that affects market conditions
- **Inventory management** with limited cargo capacity
- **Strategic gameplay** requiring market timing and route planning

## How to Play

### Controls
- **WASD** or **Arrow Keys**: Move Tucker around the world
- **E**: Toggle inventory panel
- **R**: Interact with nearby markets (when close enough)
- **ESC**: Close menus and trading interfaces

### Trading Controls (when at a market)
- **1-5**: Select different goods (Bones, Treats, Toys, Food, Medicine)
- **+/-**: Increase/decrease trade quantity
- **B**: Buy selected goods from market
- **S**: Sell selected goods to market

### Game Mechanics

1. **Movement**: Guide Tucker around the game world to visit different markets
2. **Trading**: Each market has different prices and stock levels for various goods
3. **Market Dynamics**: Prices fluctuate based on supply and demand over time
4. **Cargo Management**: You can only carry 10 items at once - choose wisely!
5. **Profit Strategy**: Buy low at one market, sell high at another
6. **Time Management**: Each day brings new market conditions

### Markets
- **Doggy Depot** (Top Left)
- **Paws & Claws Market** (Top Right)
- **The Bone Zone** (Bottom Left)
- **Furry Friends Store** (Bottom Right)
- **Pet Paradise** (Center)

### Goods Types
- 🦴 **Bones**: Classic dog treats with steady demand
- 🍪 **Treats**: Popular snacks with variable pricing
- 🧸 **Toys**: Entertainment goods with seasonal demand
- 🥫 **Food**: Essential supplies with consistent market
- 💊 **Medicine**: High-value specialty items

## Strategy Tips

1. **Watch the demand indicators**: High/Med/Low demand affects pricing
2. **Plan efficient routes**: Minimize travel time between profitable trades
3. **Monitor market money**: Markets need cash to buy your goods
4. **Track price trends**: Some goods increase in value over time
5. **Manage inventory space**: Don't get stuck with unsellable goods
6. **Start small**: Begin with low-risk trades to build capital

## Installation & Running

### Easy Installation (Recommended)
Install directly from PyPI:
```bash
pip install tucker-trucker
```

Then run the game:
```bash
tucker-trucker
```

### Manual Installation
If you want to run from source:

### Manual Installation
If you want to run from source:

#### Prerequisites
- Python 3.7 or higher
- pygame library
- numpy library

#### Running the Game
```bash
# Clone the repository
git clone https://github.com/jeremevans/tucker-trucker.git
cd tucker-trucker

# Install dependencies
pip install -r requirements.txt

# Run the game
python run_game.py
```

Or using the package module:
```bash
python -m tucker_trucker
```

## Development

This game is built with:
- **Python 3.x**
- **Pygame** for graphics and game engine
- **Object-oriented design** with modular components

### File Structure
```
TuckerTrucker/
├── main.py              # Main game entry point
├── game/
│   ├── __init__.py      # Package initialization
│   ├── constants.py     # Game constants and configuration
│   ├── entities.py      # Game objects (Player, Markets, Goods)
│   ├── game_engine.py   # Main game logic and coordination
│   └── ui.py           # User interface and rendering
└── README.md           # This file
```

## Future Enhancements

- 🚛 **Truck upgrades** for increased cargo capacity and speed
- 🏆 **Achievement system** for trading milestones
- 🌦️ **Weather effects** that impact travel and demand
- 📊 **Price history charts** for better market analysis
- 🎵 **Sound effects and music**
- 💰 **Loan system** for expanding business operations
- 🏪 **Player-owned market stalls**
- 📦 **Special delivery contracts** with time bonuses

## Credits

Created with ❤️ for Boston Terrier lovers and strategy game enthusiasts!

---

*Woof! Happy trading! 🐕💼*
