from leb.just_focus.scripts.gaussian import main


def test_gaussian_script() -> None:
    main(plot=False)
