pathsim.blocks.differentiator module
====================================

.. automodule:: pathsim.blocks.differentiator
   :members:
   :show-inheritance:
   :undoc-members:
