## Aliyun ROS COMPUTENEST Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as COMPUTENEST from '@alicloud/ros-cdk-computenest';
```
