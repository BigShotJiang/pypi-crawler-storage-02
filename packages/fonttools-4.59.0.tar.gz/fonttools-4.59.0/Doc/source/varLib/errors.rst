######
errors
######

.. automodule:: fontTools.varLib.errors
   :members:
   :undoc-members:
