############################################
svgLib: Read and write SVG-in-OpenType fonts
############################################

.. toctree::
   :maxdepth: 1

   path/index
