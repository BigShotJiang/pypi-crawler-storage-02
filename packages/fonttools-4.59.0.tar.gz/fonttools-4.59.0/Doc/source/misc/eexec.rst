###################################################################
eexec: Routines for PostScript CharString encryption and decryption
###################################################################

.. currentmodule:: fontTools.misc.eexec

.. automodule:: fontTools.misc.eexec
   :members:
   :undoc-members:
