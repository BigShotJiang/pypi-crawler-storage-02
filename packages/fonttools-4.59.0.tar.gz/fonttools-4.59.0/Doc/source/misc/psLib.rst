#############################################
psLib: Tools for working with PostScript data
#############################################

.. currentmodule:: fontTools.misc.psLib

.. automodule:: fontTools.misc.psLib
   :members:
   :undoc-members:
