#########################################
plistlib: Tools for handling .plist files
#########################################

.. currentmodule:: fontTools.misc.plistlib

.. automodule:: fontTools.misc.plistlib
   :members: totree, fromtree, load, loads, dump, dumps
   :undoc-members:
