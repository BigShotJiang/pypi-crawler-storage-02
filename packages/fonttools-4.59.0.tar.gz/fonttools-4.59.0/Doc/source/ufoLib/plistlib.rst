#####################################################################
plistlib: Support for reading and writing .plist files *[deprecated]*
#####################################################################

.. important::
   
    .. automodule:: fontTools.ufoLib.plistlib
       :members:
       :undoc-members:
