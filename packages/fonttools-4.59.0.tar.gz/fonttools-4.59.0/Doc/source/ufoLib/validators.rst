#####################################
validators: Data-validation functions
#####################################

.. automodule:: fontTools.ufoLib.validators
   :members:
   :undoc-members:
