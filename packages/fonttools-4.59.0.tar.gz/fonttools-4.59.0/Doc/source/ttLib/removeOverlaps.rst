##############################################################
removeOverlaps: Tools to remove overlapping contours in glyphs
##############################################################

.. rubric:: Overview
   :heading-level: 2

The :mod:`fontTools.ttLib.removeOverlaps` module is a helper for
:mod:`fontTools.ttLib`.

.. automodule:: fontTools.ttLib.removeOverlaps
   :members:
   :undoc-members:
