###########################################################
scaleUpem: Tools to change the units-per-Em value in a font
###########################################################

.. rubric:: Overview
   :heading-level: 2

The :mod:`fontTools.ttLib.scaleUpem` module is a helper for
:mod:`fontTools.ttLib`.

.. automodule:: fontTools.ttLib.scaleUpem
   :members:
   :undoc-members:
