``kern``: Kerning table
-----------------------

The ``kern`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._k_e_r_n
   :members:
   :undoc-members:

