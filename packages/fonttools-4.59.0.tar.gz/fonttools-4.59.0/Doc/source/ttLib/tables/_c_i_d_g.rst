``cidg``: CID to Glyph ID table
-------------------------------

The ``cidg`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._c_i_d_g
   :members:
   :undoc-members:
