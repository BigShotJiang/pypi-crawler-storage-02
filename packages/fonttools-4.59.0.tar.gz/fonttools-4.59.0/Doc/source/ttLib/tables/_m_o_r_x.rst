``morx``: Extended Glyph Metamorphosis Table
--------------------------------------------

The ``morx`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._m_o_r_x
   :members:
   :undoc-members:

