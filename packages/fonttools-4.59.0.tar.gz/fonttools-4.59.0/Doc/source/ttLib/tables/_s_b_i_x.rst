``sbix``: Standard Bitmap Graphics table
----------------------------------------

The ``sbix`` table is an OpenType table.

This ``sbix`` table converter module depends on the
:mod:`.sbixGlyph` and :mod:`.sbixStrike` modules.


.. automodule:: fontTools.ttLib.tables._s_b_i_x
   :members:
   :undoc-members:
