``LTSH``: Linear Threshold table
--------------------------------

The ``LTSH`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.L_T_S_H_
   :members:
   :undoc-members:

