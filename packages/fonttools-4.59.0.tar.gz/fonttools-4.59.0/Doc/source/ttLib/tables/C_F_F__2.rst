``CFF2``: Compact Font Format (CFF) Version 2 table
---------------------------------------------------

The ``CFF2`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.C_F_F__2
   :members:
   :undoc-members:

