``fvar``: Font Variations table
-------------------------------

The ``fvar`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._f_v_a_r
   :members:
   :undoc-members:

