``hmtx``: Horizontal Metrics table
----------------------------------

The ``hmtx`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._h_m_t_x
   :members:
   :undoc-members:

