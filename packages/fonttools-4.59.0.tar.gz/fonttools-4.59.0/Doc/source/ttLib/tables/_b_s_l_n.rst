``bsln``: Baseline
------------------

The ``bsln`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._b_s_l_n
   :members:
   :undoc-members:
