``head``: Font Header table
---------------------------

The ``head`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._h_e_a_d
   :members:
   :undoc-members:

