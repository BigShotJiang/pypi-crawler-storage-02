``GPKG``: SING Glyphlet Wrapper table
-------------------------------------

The ``GPKG`` table is an Adobe Glyphlets table.

.. automodule:: fontTools.ttLib.tables.G_P_K_G_
   :members:
   :undoc-members:

