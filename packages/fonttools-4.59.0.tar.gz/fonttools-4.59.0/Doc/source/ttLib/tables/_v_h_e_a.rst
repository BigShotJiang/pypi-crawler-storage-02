``vhea``: Vertical Header table
-------------------------------

The ``vhea`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._v_h_e_a
   :members:
   :undoc-members:

