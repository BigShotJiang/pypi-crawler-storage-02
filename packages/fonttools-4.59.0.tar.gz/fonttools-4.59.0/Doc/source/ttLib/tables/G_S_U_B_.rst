``GSUB``: Glyph Substitution table
----------------------------------

The ``GSUB`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.G_S_U_B_
   :members:
   :undoc-members:

