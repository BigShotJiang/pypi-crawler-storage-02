###################################################
ttProgram: TrueType bytecode assembler/disassembler
###################################################

.. rubric:: Overview:
   :heading-level: 2

The :mod:`fontTools.ttLib.ttProgram` module is a helper for
:mod:`fontTools.ttLib`.

.. automodule:: fontTools.ttLib.tables.ttProgram
   :members:
   :undoc-members:
    
    .. rubric:: Module members:
       :heading-level: 2
