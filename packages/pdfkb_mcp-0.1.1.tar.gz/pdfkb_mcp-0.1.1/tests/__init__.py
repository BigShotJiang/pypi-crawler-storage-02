"""Test suite for the PDF Knowledgebase MCP server."""
