"""
Built-in source code function extraction for a subset of languages.
"""

from codablellm.languages.c import CExtractor

__all__ = ["CExtractor"]
