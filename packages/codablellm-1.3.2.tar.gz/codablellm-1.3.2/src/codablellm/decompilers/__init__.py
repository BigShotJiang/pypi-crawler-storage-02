"""
Built-in support for a subset of decompilers.
"""

from codablellm.decompilers.ghidra import Ghidra

__all__ = ["Ghidra"]
