COPYRIGHT_HEAD = """Part of {project_name}.
See {license_file} in the project root for details."""
FIX_PRETTY = False
FIX_STRICT = False
