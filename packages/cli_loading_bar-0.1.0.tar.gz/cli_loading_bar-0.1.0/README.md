# Loading
Library that provides various types of loading bar for your console application

*Documentation is coming*
