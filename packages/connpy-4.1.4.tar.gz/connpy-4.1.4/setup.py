from setuptools import setup

# Setting up
setup()
