"""抖音无水印链接提取 MCP 服务器"""

__version__ = "1.2.0"
__author__ = "yzfly"
__email__ = "yz.liu.me@gmail.com"

from .server import main

__all__ = ["main"]