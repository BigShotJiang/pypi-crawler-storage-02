#pragma once

double lnC1(double T, double nu);