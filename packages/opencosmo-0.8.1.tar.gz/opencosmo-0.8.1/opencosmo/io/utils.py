def make_dataset_schema():
    pass
