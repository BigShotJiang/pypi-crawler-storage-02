from bafser.alembic import run

run()
