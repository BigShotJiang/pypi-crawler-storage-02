## cdf 

### Improved

- [alpha] The `cdf profile assets` and `cdf profile raw` now can count
up to 500,000 rows in a RAW table. Before, it would stop at 10,000 rows.

## templates

No changes.