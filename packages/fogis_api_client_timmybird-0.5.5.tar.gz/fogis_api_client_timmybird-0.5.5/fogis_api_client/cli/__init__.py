"""CLI tools for the FOGIS API client."""
