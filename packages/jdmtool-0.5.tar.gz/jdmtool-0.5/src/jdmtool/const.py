APP_NAME = 'jdmtool'

GRM_FEAT_KEY = 'grm_feat_key.zip'
