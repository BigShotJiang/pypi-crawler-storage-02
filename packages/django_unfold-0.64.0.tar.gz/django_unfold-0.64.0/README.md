![screenshot](https://github.com/user-attachments/assets/87aaad04-f454-42aa-b9ac-e14d41f189ac)

## Unfold - Django Admin Theme

[![PyPI - Version](https://img.shields.io/pypi/v/django-unfold.svg?style=for-the-badge)](https://pypi.org/project/django-unfold/)
[![Discord](https://img.shields.io/discord/1297493955231088650?style=for-the-badge&logo=discord&logoColor=%23ffffff&color=7289da)](https://discord.gg/9sQj9MEbNz)
[![Build](https://img.shields.io/github/actions/workflow/status/unfoldadmin/django-unfold/release.yml?style=for-the-badge)](https://github.com/unfoldadmin/django-unfold/actions?query=workflow%3Arelease)
![Pre Commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white&style=for-the-badge)
![Code Style - Ruff](https://img.shields.io/badge/code%20style-ruff-30173D.svg?style=for-the-badge)

Transform your Django admin into a powerful, modern administrative interface with Unfold. This open-source theme enhances Django's default admin with beautiful design, advanced features, and developer-friendly customization options. Built on proven best practices, Unfold seamlessly integrates with your existing Django admin while providing all the tools needed to create sophisticated administrative areas that both developers and end-users will love.

- **Documentation:** The full documentation is available at [unfoldadmin.com](https://unfoldadmin.com?utm_medium=github&utm_source=unfold).
- **Unfold:** The demo site is available at [unfoldadmin.com](https://unfoldadmin.com?utm_medium=github&utm_source=unfold).
- **Formula:** A repository with a demo implementation is available at [github.com/unfoldadmin/formula](https://github.com/unfoldadmin/formula?utm_medium=github&utm_source=unfold).
- **Turbo:** A Django & Next.js boilerplate implementing Unfold is available at [github.com/unfoldadmin/turbo](https://github.com/unfoldadmin/turbo?utm_medium=github&utm_source=unfold).
- **Discord:** Join our Unfold community on [Discord](https://discord.gg/9sQj9MEbNz).

## Profesional tools & services

Looking for professional help with your Django or Unfold project? We offer a range of tools and services to support your development process:

### Consulting services

Professional consulting services for Django applications — from architecture and performance optimization to feature development and Unfold integration.
Ideal for teams looking to scale, modernize, or customize their Django projects with expert support. Learn more at [unfoldadmin.com/consulting](https://unfoldadmin.com/consulting/?utm_medium=github&utm_source=unfold).

### Support package

If you need assistance with integrating or customizing Unfold, support packages are available. They include live 1:1 calls, implementation review, and ongoing Discord-based support — fixed price, no ongoing commitment. Learn more at [unfoldadmin.com/support](https://unfoldadmin.com/support/?utm_medium=github&utm_source=unfold).

### Unfold Studio

Unfold Studio lets you visually customize your Django admin without writing code — update colors, logos, sidebar, and interface styles to match your brand in minutes. Give your admin a polished, professional look that feels truly yours. Available at [unfoldadmin.com/studio](https://unfoldadmin.com/studio).

## Fresh Features & Enhancements

- **django-constance**: Official support with a completely new design and UX improvements
- **Paginated inlines:** Break down large record sets into pages within inlines for better admin performance
- **Conditional fields:** Show or hide fields dynamically based on the values of other fields in the form
- **Infinite paginator:** Efficiently handle large datasets with seamless pagination that reduces server load
- **Checkbox & radio filters:** Enhanced filter options with checkbox and radio interfaces for intuitive filtering

## Core Features & Capabilities

- **Visual Interface**: Provides a modern user interface based on the Tailwind CSS framework.
- **Sidebar navigation**: Simplifies the creation of sidebar menus with icons, collapsible sections, and more.
- **Dark mode support**: Includes both light and dark mode themes.
- **Flexible actions**: Provides multiple ways to define actions throughout the admin interface.
- **Advanced filters**: Features custom dropdowns, autocomplete, numeric, datetime, and text field filters.
- **Dashboard tools**: Includes helpers for building custom dashboard pages.
- **UI components**: Offers reusable interface components such as cards, buttons, and charts.
- **Crispy forms**: Custom template pack for django-crispy-forms to style forms with Unfold's design system
- **WYSIWYG editor**: Built-in support for WYSIWYG editing through Trix.
- **Array widget:** Built-in widget for `django.contrib.postgres.fields.ArrayField`
- **Inline tabs:** Group inlines into tab navigation in the change form
- **Conditional fields:** Show or hide fields dynamically based on the values of other fields in the form
- **Model tabs:** Allow defining custom tab navigation for models
- **Fieldset tabs:** Merge multiple fieldsets into tabs in the change form
- **Sortable inlines:** Allow sorting inlines by dragging and dropping
- **Environment label:** Distinguish between environments by displaying a label
- **Nonrelated inlines:** Display nonrelated models as inlines in the change form
- **Paginated inlines:** Break down large record sets into pages within inlines for better admin performance
- **Favicons:** Built-in support for configuring various site favicons
- **Themes:** Allow customization of color scheme, background color, border radius, and more
- **Font colors:** Adjust font colors for better readability
- **Changeform modes:** Display fields in compressed mode in the change form
- **Language switcher:** Allow changing language directly from the admin area
- **Infinite paginator:** Efficiently handle large datasets with seamless pagination that reduces server load
- **Parallel admin:** Supports [running the default admin](https://unfoldadmin.com/blog/migrating-django-admin-unfold/?utm_medium=github&utm_source=unfold) alongside Unfold.
- **Third-party packages:** Provides default support for multiple popular applications.
- **Configuration:** Allows basic options to be changed in `settings.py`.
- **Dependencies:** Built entirely on `django.contrib.admin`.
- **VS Code:** Project configuration and development container included.

## Third-party package support

- [django-guardian](https://github.com/django-guardian/django-guardian) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-guardian/)
- [django-import-export](https://github.com/django-import-export/django-import-export) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-import-export/)
- [django-simple-history](https://github.com/jazzband/django-simple-history) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-simple-history/)
- [django-constance](https://github.com/jazzband/django-constance) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-constance/)
- [django-celery-beat](https://github.com/celery/django-celery-beat) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-celery-beat/)
- [django-modeltranslation](https://github.com/deschler/django-modeltranslation) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-modeltranslation/)
- [django-money](https://github.com/django-money/django-money) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-money/)
- [django-location-field](https://github.com/caioariede/django-location-field) - [Integration guide](https://unfoldadmin.com/docs/integrations/django-location-field/)

## Credits

- **Tailwind**: [Tailwind CSS](https://github.com/tailwindlabs/tailwindcss) - Licensed under the [MIT License](https://opensource.org/licenses/MIT).
- **Icons**: [Material Symbols](https://github.com/google/material-design-icons) - Licensed under the [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0).
- **Font**: [Inter](https://github.com/rsms/inter) - Licensed under the [SIL Open Font License 1.1](https://scripts.sil.org/OFL).
- **Charts**: [Chart.js](https://github.com/chartjs/Chart.js) - Licensed under the [MIT License](https://opensource.org/licenses/MIT).
- **JavaScript Framework**: [Alpine.js](https://github.com/alpinejs/alpine) - Licensed under the [MIT License](https://opensource.org/licenses/MIT).
- **AJAX calls**: [HTMX](https://htmx.org/) - Licensed under the [BSD 2-Clause License](https://opensource.org/licenses/BSD-2-Clause).
- **Custom Scrollbars**: [SimpleBar](https://github.com/Grsmto/simplebar) - Licensed under the [MIT License](https://opensource.org/licenses/MIT).
- **Range Slider**: [noUiSlider](https://github.com/leongersen/noUiSlider) - Licensed under the [MIT License](https://opensource.org/licenses/MIT).
- **Number Formatting**: [wNumb](https://github.com/leongersen/wnumb) - Licensed under the [MIT License](https://opensource.org/licenses/MIT).
