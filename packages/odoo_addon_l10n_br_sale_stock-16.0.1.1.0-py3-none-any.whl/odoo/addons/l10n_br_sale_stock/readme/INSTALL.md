This module depends on:

- sale_stock
- l10n_br_sale
- l10n_br_stock_account
