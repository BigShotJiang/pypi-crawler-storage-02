## 15.0.1.0.0 (2024-09-17)

- \[MIG\] Migration to version 15.0

## 12.0.1.0.0 (2020-05-29)

- \[MIG\] Migration to version 12.0

## 10.0.1.0.0 (2019-09-13)

- \[MIG\] Migration to version 10.0
