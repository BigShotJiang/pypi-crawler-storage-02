# Single source of truth for version
# This file has no dependencies to avoid import issues during build
__version__ = "0.2.3"