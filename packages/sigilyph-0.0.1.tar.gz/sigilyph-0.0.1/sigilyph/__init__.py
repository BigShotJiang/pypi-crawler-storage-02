'''
FilePath: /python-Sigilyph/sigilyph/__init__.py
Descripttion: 
Author: Yixiang Chen
version: 
Date: 2025-05-13 11:01:07
LastEditors: Yixiang Chen
LastEditTime: 2025-08-12 16:39:15
'''

from sigilyph.core.sigilyph_class import Sigilyph