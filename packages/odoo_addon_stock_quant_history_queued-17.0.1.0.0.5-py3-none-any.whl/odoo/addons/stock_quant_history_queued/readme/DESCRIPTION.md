This module use queue job to regenerate stock.quant.history
asynchronously.

This add the *In Progress* state on stock history snapshot and delegate
the generation to a queue job process.
