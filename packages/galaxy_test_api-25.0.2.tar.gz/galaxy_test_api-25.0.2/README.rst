
.. image:: https://badge.fury.io/py/galaxy-test-api.svg
   :target: https://pypi.org/project/galaxy-test-api/



Overview
--------

The Galaxy_ API tests.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
