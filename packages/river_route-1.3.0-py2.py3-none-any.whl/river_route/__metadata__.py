__version__ = '1.3.0'
__author__ = 'Riley Hales PhD'
__url__ = 'https://github.com/rileyhales/river-route'
