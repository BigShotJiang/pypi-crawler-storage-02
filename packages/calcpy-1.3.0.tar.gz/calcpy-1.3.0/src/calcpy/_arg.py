class Missing:
    def __repr__(self):
        return "Missing"


MISSING = Missing()  # Constant indicates that the argument is missing.
