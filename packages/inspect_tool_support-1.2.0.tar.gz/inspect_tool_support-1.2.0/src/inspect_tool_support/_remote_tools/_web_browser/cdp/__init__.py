"""
Types and pure functional helpers associated with Chrome DevTools Protocol

https://chromedevtools.github.io/devtools-protocol/
"""
