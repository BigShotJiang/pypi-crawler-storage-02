from .target import target_service

__all__ = [
    "target_service",
]
