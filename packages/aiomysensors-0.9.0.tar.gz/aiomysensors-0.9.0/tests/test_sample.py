"""Provide a sample test passing with pytest."""


def test_pass() -> None:
    """Test that pytest works."""
    assert True, "dummy sample test"
