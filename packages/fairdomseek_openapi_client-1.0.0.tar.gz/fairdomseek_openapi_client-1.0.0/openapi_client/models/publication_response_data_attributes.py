# coding: utf-8

"""
    JSON API to FAIRDOM SEEK

    <a name=\"api\"></a>The JSON API to FAIRDOM SEEK is a [JSON API](http://jsonapi.org) specification describing how to read and write to a SEEK instance.  The API is defined in the [OpenAPI specification](https://swagger.io/specification) currently in [version 2](https://github.com/OAI/OpenAPI-Specification/blob/master/versions/2.0.md)  Example IPython notebooks showing use of the API are available on [GitHub](https://github.com/FAIRdom/api-workshop)  ## Policy <a name=\"Policy\"></a> A Policy specifies the visibility of an object to people using SEEK. A <a href=\"#projects\">**Project**</a> may specify the default policy for objects belonging to that <a href=\"#projects\">**Project**</a>  The **Policy** specifies the visibility of the object to non-registered people or <a href=\"#people\">**People**</a> not allowed special access.  The access may be one of (in order of increasing \"power\"):  * no_access * view * download * edit * manage  In addition a **Policy** may give special access to specific <a href=\"#people\">**People**</a>, People working at an <a href=\"#institutions\">**Institution**</a> or working on a <a href=\"#projects\">**Project**</a>.  ## License <a name=\"License\"></a> The license specifies the license that will apply to any <a href=\"#dataFiles\">**DataFiles**</a>, <a href=\"#models\">**Models**</a>, <a href=\"#sops\">**SOPs**</a>, <a href=\"#documents\">**Documents**</a> and <a href=\"#presentations\">**Presentations**</a> associated with a <a href=\"#projects\">**Project**</a>.  The license can currently be:  * `CC0-1.0` - [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) * `CC-BY-4.0` - [Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/) * `CC-BY-SA-4.0` - [Creative Commons Attribution Share-Alike 4.0](https://creativecommons.org/licenses/by-sa/4.0/) * `ODC-BY-1.0` - [Open Data Commons Attribution License 1.0](http://www.opendefinition.org/licenses/odc-by) * `ODbL-1.0` - [Open Data Commons Open Database License 1.0](http://www.opendefinition.org/licenses/odc-odbl) * `ODC-PDDL-1.0` - [Open Data Commons Public Domain Dedication and Licence 1.0](http://www.opendefinition.org/licenses/odc-pddl) * `notspecified` - License Not Specified * `other-at` - Other (Attribution) * `other-open` - Other (Open) * `other-pd` - Other (Public Domain) * `AFL-3.0` - [Academic Free License 3.0](http://www.opensource.org/licenses/AFL-3.0) * `Against-DRM` - [Against DRM](http://www.opendefinition.org/licenses/against-drm) * `CC-BY-NC-4.0` - [Creative Commons Attribution-NonCommercial 4.0](https://creativecommons.org/licenses/by-nc/4.0/) * `DSL` - [Design Science License](http://www.opendefinition.org/licenses/dsl) * `FAL-1.3` - [Free Art License 1.3](http://www.opendefinition.org/licenses/fal) * `GFDL-1.3-no-cover-texts-no-invariant-sections` - [GNU Free Documentation License 1.3 with no cover texts and no invariant sections](http://www.opendefinition.org/licenses/gfdl) * `geogratis` - [Geogratis](http://geogratis.gc.ca/geogratis/licenceGG) * `hesa-withrights` - [Higher Education Statistics Agency Copyright with data.gov.uk rights](http://www.hesa.ac.uk/index.php?option=com_content&amp;task=view&amp;id=2619&amp;Itemid=209) * `localauth-withrights` - Local Authority Copyright with data.gov.uk rights * `MirOS` - [MirOS Licence](http://www.opensource.org/licenses/MirOS) * `NPOSL-3.0` - [Non-Profit Open Software License 3.0](http://www.opensource.org/licenses/NPOSL-3.0) * `OGL-UK-1.0` - [Open Government Licence 1.0 (United Kingdom)](http://reference.data.gov.uk/id/open-government-licence) * `OGL-UK-2.0` - [Open Government Licence 2.0 (United Kingdom)](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/2/) * `OGL-UK-3.0` - [Open Government Licence 3.0 (United Kingdom)](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/) * `OGL-Canada-2.0` - [Open Government License 2.0 (Canada)](http://data.gc.ca/eng/open-government-licence-canada) * `OSL-3.0` - [Open Software License 3.0](http://www.opensource.org/licenses/OSL-3.0) * `dli-model-use` - [Statistics Canada: Data Liberation Initiative (DLI) - Model Data Use Licence](http://data.library.ubc.ca/datalib/geographic/DMTI/license.html) * `Talis` - [Talis Community License](http://www.opendefinition.org/licenses/tcl) * `ukclickusepsi` - UK Click Use PSI * `ukcrown-withrights` - UK Crown Copyright with data.gov.uk rights * `ukpsi` - [UK PSI Public Sector Information](http://www.opendefinition.org/licenses/ukpsi)  ## ContentBlob <a name=\"ContentBlob\"></a> <a name=\"contentBlobs\"></a> The content of a <a href=\"#dataFiles\">**DataFile**</a>, <a href=\"#documents\">**Document**</a>, <a href=\"#models\">**Model**</a>, <a href=\"#sops\">**SOP**</a> or <a href=\"#presentations\">**Presentation**</a> is specified as a set of **ContentBlobs**.  When a resource with content is created, it is possible to specify a ContentBlob either as:  * A remote ContentBlob with:   * **URI to the content's location**   * The original filename for the content   * The content type of the remote content as a [MIME media type](https://en.wikipedia.org/wiki/Media_type) * A placeholder that will be filled with uploaded content   * **The original filename for the content**   * **The content type of the content as a [MIME media type](https://en.wikipedia.org/wiki/Media_type)**  The creation of the resource will return a JSON document containing ContentBlobs corresponding to the remote ContentBlob and to the ContentBlob placeholder. The blobs contain a URI to their location.  A placeholder can then be satisfied by uploading a file to the location URI. For example by a placeholder such as   ``` \"content_blobs\": [   {     \"original_filename\": \"a_pdf_file.pdf\",     \"content_type\": \"application/pdf\",     \"link\": \"http://fairdomhub.org/data_files/57/content_blobs/313\"   } ], ```  may be satisfied by uploading a file to http://fairdomhub.org/data_files/57/content_blobs/313 using the <a href=\"#uploadAssetContent\">uploadAssetContent</a> operation  The content of a resource may be downloaded by first *reading* the resource and then *downloading* the ContentBlobs from their URI.  ## Extended Metadata  Some types support [Extended Metadata](https://docs.seek4science.org/tech/extended-metadata), which allows additional attributes to be defined according to an Extended Metadata Type.  Types currently supported are <a href=\"#investigations\">**Investigation**</a>, <a href=\"#studies\">**Study**</a>, <a href=\"#assays\">**Assay**</a>,  <a href=\"#dataFiles\">**DataFile**</a>, <a href=\"#sops\">**SOP**</a>, <a href=\"#presentations\">**Presentation**</a>, <a href=\"#documents\">**Document**</a>, <a href=\"#models\">**Model**</a>, <a href=\"#events\">**Event**</a>, <a href=\"#collections\">**Collection**</a>, <a href=\"#projects\">**Project**</a>  The responses and requests for each of these types include an additional optional attribute _extended_attributes_ which describes  * _extended_metadata_type_id_ - the id of the extended metadata type which can be used to find more details about what its attributes are. * _attribute_map_ - which is a map of key / value pairs where the key is the attribute name   For example, a Study may have extended metadata, defined by an Extended Metadata Type with id 12, that has attributes for age, name, and date_of_birth. These could be shown, within its attributes, as:  ``` \"extended_attributes\": {   \"extended_metadata_type_id\": \"12\",   \"attribute_map\": {     \"age\": 44,     \"name\": \"Fred Bloggs\",     \"date_of_birth\": \"2024-01-01\"   } } ```  If you wish to create or update a study to make use of this extended metadata, the request payload would be described the same.  Upon creation or update there would be a validation check that the attributes are valid.  The API supports listing all available Extended Metadata Types, and inspecting an individual type by its id. For more information see the [Extended Metadata Type definitions](api#tag/extendedMetadataTypes).

    The version of the OpenAPI document: 0.3
    Contact: support@fair-dom.org
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field, StrictFloat, StrictInt
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing_extensions import Annotated
from openapi_client.models.asset_link import AssetLink
from openapi_client.models.assets_creator import AssetsCreator
from openapi_client.models.content_blob import ContentBlob
from openapi_client.models.policy import Policy
from openapi_client.models.version import Version
from typing import Optional, Set
from typing_extensions import Self

class PublicationResponseDataAttributes(BaseModel):
    """
    PublicationResponseDataAttributes
    """ # noqa: E501
    title: Annotated[str, Field(min_length=1, strict=True)]
    journal: Annotated[str, Field(min_length=1, strict=True)]
    published_date: Annotated[str, Field(min_length=1, strict=True)]
    doi: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    pubmed_id: Optional[StrictInt]
    abstract: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    citation: Annotated[str, Field(min_length=1, strict=True)]
    editor: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    booktitle: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    publisher: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    url: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    link_to_pub: Annotated[str, Field(min_length=1, strict=True)]
    publication_type: Annotated[str, Field(min_length=1, strict=True)]
    authors: Optional[List[Annotated[str, Field(min_length=1, strict=True)]]] = None
    content_blobs: Optional[Annotated[List[ContentBlob], Field(min_length=0)]] = None
    policy: Optional[Policy] = None
    discussion_links: Optional[Annotated[List[AssetLink], Field(min_length=0)]] = None
    misc_links: Optional[Annotated[List[AssetLink], Field(min_length=0)]] = None
    tags: Optional[List[Annotated[str, Field(min_length=1, strict=True)]]] = None
    latest_version: Optional[Union[StrictFloat, StrictInt]] = None
    versions: Optional[Annotated[List[Version], Field(min_length=1)]] = None
    version: Optional[Union[StrictFloat, StrictInt]] = None
    revision_comments: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    other_creators: Optional[Annotated[str, Field(min_length=1, strict=True)]] = None
    creators: Optional[Annotated[List[AssetsCreator], Field(min_length=0)]] = None
    __properties: ClassVar[List[str]] = ["title", "journal", "published_date", "doi", "pubmed_id", "abstract", "citation", "editor", "booktitle", "publisher", "url", "link_to_pub", "publication_type", "authors", "content_blobs", "policy", "discussion_links", "misc_links", "tags", "latest_version", "versions", "version", "revision_comments", "created_at", "updated_at", "other_creators", "creators"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of PublicationResponseDataAttributes from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of each item in content_blobs (list)
        _items = []
        if self.content_blobs:
            for _item_content_blobs in self.content_blobs:
                if _item_content_blobs:
                    _items.append(_item_content_blobs.to_dict())
            _dict['content_blobs'] = _items
        # override the default output from pydantic by calling `to_dict()` of policy
        if self.policy:
            _dict['policy'] = self.policy.to_dict()
        # override the default output from pydantic by calling `to_dict()` of each item in discussion_links (list)
        _items = []
        if self.discussion_links:
            for _item_discussion_links in self.discussion_links:
                if _item_discussion_links:
                    _items.append(_item_discussion_links.to_dict())
            _dict['discussion_links'] = _items
        # override the default output from pydantic by calling `to_dict()` of each item in misc_links (list)
        _items = []
        if self.misc_links:
            for _item_misc_links in self.misc_links:
                if _item_misc_links:
                    _items.append(_item_misc_links.to_dict())
            _dict['misc_links'] = _items
        # override the default output from pydantic by calling `to_dict()` of each item in versions (list)
        _items = []
        if self.versions:
            for _item_versions in self.versions:
                if _item_versions:
                    _items.append(_item_versions.to_dict())
            _dict['versions'] = _items
        # override the default output from pydantic by calling `to_dict()` of each item in creators (list)
        _items = []
        if self.creators:
            for _item_creators in self.creators:
                if _item_creators:
                    _items.append(_item_creators.to_dict())
            _dict['creators'] = _items
        # set to None if pubmed_id (nullable) is None
        # and model_fields_set contains the field
        if self.pubmed_id is None and "pubmed_id" in self.model_fields_set:
            _dict['pubmed_id'] = None

        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of PublicationResponseDataAttributes from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "title": obj.get("title"),
            "journal": obj.get("journal"),
            "published_date": obj.get("published_date"),
            "doi": obj.get("doi"),
            "pubmed_id": obj.get("pubmed_id"),
            "abstract": obj.get("abstract"),
            "citation": obj.get("citation"),
            "editor": obj.get("editor"),
            "booktitle": obj.get("booktitle"),
            "publisher": obj.get("publisher"),
            "url": obj.get("url"),
            "link_to_pub": obj.get("link_to_pub"),
            "publication_type": obj.get("publication_type"),
            "authors": obj.get("authors"),
            "content_blobs": [ContentBlob.from_dict(_item) for _item in obj["content_blobs"]] if obj.get("content_blobs") is not None else None,
            "policy": Policy.from_dict(obj["policy"]) if obj.get("policy") is not None else None,
            "discussion_links": [AssetLink.from_dict(_item) for _item in obj["discussion_links"]] if obj.get("discussion_links") is not None else None,
            "misc_links": [AssetLink.from_dict(_item) for _item in obj["misc_links"]] if obj.get("misc_links") is not None else None,
            "tags": obj.get("tags"),
            "latest_version": obj.get("latest_version"),
            "versions": [Version.from_dict(_item) for _item in obj["versions"]] if obj.get("versions") is not None else None,
            "version": obj.get("version"),
            "revision_comments": obj.get("revision_comments"),
            "created_at": obj.get("created_at"),
            "updated_at": obj.get("updated_at"),
            "other_creators": obj.get("other_creators"),
            "creators": [AssetsCreator.from_dict(_item) for _item in obj["creators"]] if obj.get("creators") is not None else None
        })
        return _obj


