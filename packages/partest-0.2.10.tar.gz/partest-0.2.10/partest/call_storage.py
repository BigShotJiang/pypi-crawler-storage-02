''' Data on the number of requests and types of tests are collected here. '''

call_count = {}
call_type = {}