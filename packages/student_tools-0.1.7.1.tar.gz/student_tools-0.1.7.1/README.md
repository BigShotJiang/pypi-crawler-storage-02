A collection of *English*, *Math*, and *Utility* tools, made for students.

---

**Package name:** student_tools

**Install with:** `pip install student-tools`

**Update with:** `pip install --upgrade student-tools`

**Use with:** `import st`

---

**Created by:** Error Dev **|** [https://devicals.github.io/](https://devicals.github.io/)