"""
Module with models for calculating melt |fO2| at various buffers.
"""

from MagmaPandas.fO2 import IW, QFM
