from MagmaPandas.Kd.Ol_melt import FeMg
