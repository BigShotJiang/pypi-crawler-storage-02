"""
Module with MagmaSeries classes
"""

from MagmaPandas.MagmaSeries.MagmaSeries_baseclass import *
