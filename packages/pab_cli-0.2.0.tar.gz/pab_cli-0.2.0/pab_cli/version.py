"""
Version information for PAB package.
"""

__version__ = "0.2.0"
