This folder contains sample data files (e.g., base.csv, crash.csv) for the agomax package.
Add your CSV files here to include them in the package distribution.
