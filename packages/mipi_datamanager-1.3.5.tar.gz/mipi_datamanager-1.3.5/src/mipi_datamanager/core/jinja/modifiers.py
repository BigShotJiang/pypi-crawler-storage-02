class ExcludeList(list):
    op = "NOT IN"
