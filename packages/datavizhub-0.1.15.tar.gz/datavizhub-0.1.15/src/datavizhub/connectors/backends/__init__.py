"""Backend adapters for connectors (HTTP, S3, FTP, Vimeo)."""

