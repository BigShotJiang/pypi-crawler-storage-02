"""Connectors package: ingest and egress submodules and shared backends."""

