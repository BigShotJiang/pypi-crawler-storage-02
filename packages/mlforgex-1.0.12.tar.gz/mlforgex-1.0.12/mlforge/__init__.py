__version__ = "1.0.12"

from .train import train_model
from .predict import predict
