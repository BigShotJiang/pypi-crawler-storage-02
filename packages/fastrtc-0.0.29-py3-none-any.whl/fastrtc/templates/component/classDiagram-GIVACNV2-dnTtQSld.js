import { c as r, C as s, a as e, s as t } from "./chunk-A2AXSNBT-CvJAk6vc.js";
import { _ as l } from "./mermaid.core-C363K4_Y.js";
var d = {
  parser: r,
  get db() {
    return new s();
  },
  renderer: e,
  styles: t,
  init: /* @__PURE__ */ l((a) => {
    a.class || (a.class = {}), a.class.arrowMarkerAbsolute = a.arrowMarkerAbsolute;
  }, "init")
};
export {
  d as diagram
};
