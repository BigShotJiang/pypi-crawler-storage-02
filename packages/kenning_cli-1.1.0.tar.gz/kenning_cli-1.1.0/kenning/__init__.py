# This file marks kenning as a Python package
# Kenning CLI package __init__
