class Config:
    exception_logger = None
