from .gui import run_gui

def main():
    print("Running GUI...")
    run_gui()

if __name__ == "__main__":
    main()