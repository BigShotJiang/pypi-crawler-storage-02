Authorizenet API Authentication
===============================

To authenticate with the Authorizenet API, use these utility functions to provide data to API calls.

.. automodule:: terminusgps.authorizenet.auth
   :members:
