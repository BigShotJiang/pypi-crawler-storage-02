class Markdown2PDFException(Exception):
    pass

class PaymentRequiredException(Markdown2PDFException):
    pass
