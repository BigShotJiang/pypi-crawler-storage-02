# Placeholder for future typing support
OfferDetails = dict
