"""Dragonfly Urban Weather Generator Classes."""
