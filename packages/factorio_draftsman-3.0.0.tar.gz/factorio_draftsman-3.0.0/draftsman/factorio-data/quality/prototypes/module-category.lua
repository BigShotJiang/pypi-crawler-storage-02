data:extend(
{
  {
    type = "module-category",
    name = "quality"
  }
}
)
