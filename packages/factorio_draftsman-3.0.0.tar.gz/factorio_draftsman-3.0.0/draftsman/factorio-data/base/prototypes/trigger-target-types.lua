data:extend(
{
  -- "common" is internal target type (doesn't need to be defined, the game creates it)
  -- {
  --   type = "trigger-target-type",
  --   name = "common"
  -- },

  {
    type = "trigger-target-type",
    name = "ground-unit"
  },
  {
    type = "trigger-target-type",
    name = "flying-robot"
  }
})
