function make_laser_sounds() return sound_variations("__base__/sound/fight/laser", 3) end
