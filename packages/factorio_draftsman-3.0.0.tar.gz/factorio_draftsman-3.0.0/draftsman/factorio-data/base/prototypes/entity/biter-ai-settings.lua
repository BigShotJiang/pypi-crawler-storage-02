return { destroy_when_commands_fail = true, allow_try_return_to_spawner = true }
