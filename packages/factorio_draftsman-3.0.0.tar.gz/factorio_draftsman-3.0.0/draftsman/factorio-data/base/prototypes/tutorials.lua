data:extend(
{
  {
    type = "tutorial",
    name = "trains-stations",
    scenario = "trains-stations"
  },
  {
    type = "tutorial",
    name = "trains-basic-signals",
    scenario = "trains-basic-signals"
  },
  {
    type = "tutorial",
    name = "trains-advanced-signals",
    scenario = "trains-advanced-signals"
  },
  {
    type = "tutorial",
    name = "stack-transfers",
    scenario = "stack-transfers"
  },
  {
    type = "tutorial",
    name = "entity-transfers",
    scenario = "entity-transfers"
  }
})
