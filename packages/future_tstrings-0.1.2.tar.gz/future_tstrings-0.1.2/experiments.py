from future_tstrings.main import main

main(["tests/_fstrings.py"])
