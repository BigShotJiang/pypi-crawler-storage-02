from . import install

install()
