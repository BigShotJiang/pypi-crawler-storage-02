# evals

::: patronus.evals
    options:
        show_submodules: true
        show_root_heading: true
