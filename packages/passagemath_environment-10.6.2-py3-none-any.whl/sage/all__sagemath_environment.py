# sage_setup: distribution = sagemath-environment
# delvewheel: patch
from sage.env import SAGE_ROOT, SAGE_SRC, SAGE_DOC_SRC, SAGE_LOCAL, DOT_SAGE, SAGE_ENV

from sage.misc.all__sagemath_environment import *
