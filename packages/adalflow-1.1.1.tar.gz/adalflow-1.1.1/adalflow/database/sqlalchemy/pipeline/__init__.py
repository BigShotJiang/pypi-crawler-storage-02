"A text splitting and text embedding pipeline using sqlalchemy"
