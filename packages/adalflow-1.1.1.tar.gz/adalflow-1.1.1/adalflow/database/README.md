This is where we show how we can leverage cloud db such as postgres along with its vector extension to store and query data.
