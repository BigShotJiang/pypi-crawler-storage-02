from .palette import color
from .palette import palette
