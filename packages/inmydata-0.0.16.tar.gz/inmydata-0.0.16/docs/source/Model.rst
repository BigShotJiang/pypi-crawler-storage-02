Model
=====

.. autoclass:: inmydata.ConversationalData.Model
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index: