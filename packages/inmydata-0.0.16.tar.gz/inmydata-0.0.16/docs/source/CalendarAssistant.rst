CalendarAssistant
=================

.. autoclass:: inmydata.CalendarAssistant.CalendarAssistant
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index:
    :special-members: __init__
