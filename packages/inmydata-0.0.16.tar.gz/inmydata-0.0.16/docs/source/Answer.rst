Answer
======

.. autoclass:: inmydata.ConversationalData.Answer
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index:
