LogicalOperator
===============

.. autoclass:: inmydata.StructuredData.LogicalOperator
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index: