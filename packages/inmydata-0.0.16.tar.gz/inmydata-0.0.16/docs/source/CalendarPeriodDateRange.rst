CalendarPeriodDateRange
=======================

.. autoclass:: inmydata.CalendarAssistant.CalendarPeriodDateRange
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index:
    :special-members: __init__
