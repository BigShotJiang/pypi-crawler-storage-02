QuestionResponse
================

.. autoclass:: inmydata.ConversationalData.QuestionResponse
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index:
