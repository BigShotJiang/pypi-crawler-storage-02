
FinancialPeriodDetails
======================

.. autoclass:: inmydata.CalendarAssistant.FinancialPeriodDetails
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index: