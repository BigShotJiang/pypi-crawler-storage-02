"""
Version information for the Limitly Python SDK
"""

__version__ = "1.0.0"
__author__ = "Limitly Team"
__email__ = "hi@limitly.dev"
__url__ = "https://github.com/limitlydev/limitly-python" 