#!/usr/bin/env bash
complete -W "\$(gf -list)" gf
