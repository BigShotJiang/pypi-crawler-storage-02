compdef _gf gf

function _gf {
    _arguments "1: :($(gf -list))"
}
