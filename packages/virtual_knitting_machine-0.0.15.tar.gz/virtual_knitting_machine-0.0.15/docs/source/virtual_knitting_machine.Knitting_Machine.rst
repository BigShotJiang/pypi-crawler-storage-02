virtual\_knitting\_machine.Knitting\_Machine module
===================================================

.. automodule:: virtual_knitting_machine.Knitting_Machine
   :members:
   :undoc-members:
   :show-inheritance:
