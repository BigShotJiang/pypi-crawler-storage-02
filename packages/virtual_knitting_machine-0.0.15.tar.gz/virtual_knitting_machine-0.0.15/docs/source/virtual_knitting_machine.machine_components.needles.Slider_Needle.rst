virtual\_knitting\_machine.machine\_components.needles.Slider\_Needle module
============================================================================

.. automodule:: virtual_knitting_machine.machine_components.needles.Slider_Needle
   :members:
   :undoc-members:
   :show-inheritance:
