virtual\_knitting\_machine.machine\_components.needles.Needle module
====================================================================

.. automodule:: virtual_knitting_machine.machine_components.needles.Needle
   :members:
   :undoc-members:
   :show-inheritance:
