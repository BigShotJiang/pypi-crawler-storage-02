virtual\_knitting\_machine.machine\_components.needles package
==============================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   virtual_knitting_machine.machine_components.needles.Needle
   virtual_knitting_machine.machine_components.needles.Sheet_Needle
   virtual_knitting_machine.machine_components.needles.Slider_Needle

Module contents
---------------

.. automodule:: virtual_knitting_machine.machine_components.needles
   :members:
   :undoc-members:
   :show-inheritance:
