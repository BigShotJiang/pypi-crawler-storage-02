"""Library version."""

VERSION="2025.7.11"
