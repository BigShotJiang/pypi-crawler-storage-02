# OmniCite

## Installation

```bash
pip install omnicite
```
