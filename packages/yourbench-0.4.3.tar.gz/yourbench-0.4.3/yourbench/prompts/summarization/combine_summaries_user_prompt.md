You will receive a list of chunk-level summaries from the *same* document.  Combine them into a single, well-structured paragraph that reads naturally and eliminates redundancy.

<chunk_summaries>
{chunk_summaries}
</chunk_summaries>

Return ONLY the final text inside <final_summary> tags. 