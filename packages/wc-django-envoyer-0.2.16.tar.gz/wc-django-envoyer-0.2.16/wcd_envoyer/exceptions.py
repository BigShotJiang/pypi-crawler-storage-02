class EnvoyerError(Exception):
    pass
