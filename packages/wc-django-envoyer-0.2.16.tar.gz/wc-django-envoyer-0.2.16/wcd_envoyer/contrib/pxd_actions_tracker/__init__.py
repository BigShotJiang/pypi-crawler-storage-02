default_app_config = 'wcd_envoyer.contrib.pxd_actions_tracker.apps.ActionsTrackerConfig'
