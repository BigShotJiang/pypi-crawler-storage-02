from .backend import *
from .registry_base import *


registry = ChannelRegistry()
add = registry.add
