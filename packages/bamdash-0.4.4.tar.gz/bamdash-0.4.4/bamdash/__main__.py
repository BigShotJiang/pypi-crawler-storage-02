#!/usr/bin/env python3
from virheat import command

if __name__ == '__main__':
    command.main()
