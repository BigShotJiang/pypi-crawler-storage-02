"""interactively visualize coverage and tracks"""
_program = "bamdash"
__version__ = "0.4.4"
