.. katcp-codec documentation master file, created by
   sphinx-quickstart on Sun Mar 24 18:40:02 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to katcp-codec's documentation!
=======================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   introduction
   installation
   usage
   design
   changelog
   Reference <modules>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
