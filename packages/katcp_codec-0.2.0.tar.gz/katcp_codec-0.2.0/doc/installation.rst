Installation
============

Run `pip install katcp_codec`.

The package is published with binary wheels for CPython 3.8+ on Linux
and MacOS (x86-64 and AArch 64), which means you will not need a Rust compiler
for those platforms. For other platforms, you will need the Rust compiler.
You can find simple installation instructions at
[rustup.rs](https://rustup.rs).
