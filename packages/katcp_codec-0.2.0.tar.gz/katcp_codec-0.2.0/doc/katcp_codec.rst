katcp\_codec package
====================

Module contents
---------------

.. automodule:: katcp_codec
   :members:
   :undoc-members:
   :show-inheritance:
