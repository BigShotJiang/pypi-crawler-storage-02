# Fast katcp encoding and decoding

This is a library for efficiently encoding and decoding the
[katcp](https://katcp-python.readthedocs.io/en/latest/_downloads/361189acb383a294be20d6c10c257cb4/NRF-KAT7-6.0-IFCE-002-Rev5-1.pdf)
protocol. Refer to the [online
manual](https://katcp-codec.readthedocs.io/en/latest) for more information.
