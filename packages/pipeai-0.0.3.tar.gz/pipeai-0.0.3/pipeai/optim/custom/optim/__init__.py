from .lamb import Lamb

__all__ = ['Lamb']
