from .easytrain import easytrain

__all__ = ['easytrain']
