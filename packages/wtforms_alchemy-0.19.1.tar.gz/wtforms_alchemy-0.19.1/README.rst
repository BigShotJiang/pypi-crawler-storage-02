WTForms-Alchemy
===============

|Version Status| |Downloads|

Tools for creating WTForms forms from SQLAlchemy models


Resources
---------

- `Documentation <https://wtforms-alchemy.readthedocs.io/>`_
- `Issue Tracker <http://github.com/kvesteri/wtforms-alchemy/issues>`_
- `Code <http://github.com/kvesteri/wtforms-alchemy/>`_

.. |Version Status| image:: https://img.shields.io/pypi/v/WTForms-Alchemy.svg
   :target: https://pypi.python.org/pypi/WTForms-Alchemy/
.. |Downloads| image:: https://img.shields.io/pypi/dm/WTForms-Alchemy.svg
   :target: https://pypi.python.org/pypi/WTForms-Alchemy/
