def main():
    print("Hello from spring-py!")


if __name__ == "__main__":
    main()
