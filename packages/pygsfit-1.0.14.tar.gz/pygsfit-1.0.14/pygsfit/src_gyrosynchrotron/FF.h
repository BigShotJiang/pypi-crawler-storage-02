#pragma once

void Find_jk_FFei(double ne, double T0, double nu_p, double nu_B, double theta, double kappa, int abcode, 
	              int sigma, double nu, double *j, double *k);
void Find_jk_FFen(double ne, double nH, double nHe, double T0, double nu_p, double nu_B, double theta, 
	              int sigma, double nu, double *j, double *k);