#ifdef IDLMSG
void IDLmsg(const char *fmt, ...);
#endif
#ifdef PyMSG
void Pymsg(const char *fmt, ...);
#endif

void LOGout(const char *fmt, ...);