from iolanta.plugin import Plugin


class IolantaBase(Plugin):
    """Base plugin."""
