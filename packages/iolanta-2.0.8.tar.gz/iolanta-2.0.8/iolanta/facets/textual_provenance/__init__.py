from iolanta.facets.textual_provenance.facets import TextualProvenanceFacet

__all__ = ['TextualProvenanceFacet']
