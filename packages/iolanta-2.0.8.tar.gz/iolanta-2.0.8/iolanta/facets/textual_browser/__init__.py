from iolanta.facets.textual_browser.facet import TextualBrowserFacet

__all__ = ['TextualBrowserFacet']
