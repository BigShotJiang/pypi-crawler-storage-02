To use this module, you need to:

- be sure that you have Billing Administrator or Accountant rights for
  accounting
- go to Invoicing/Reporting/Auditfile export
- create a new record, adjust values if the defaults are not appropriate
- click Generate auditfile
- click Download on the field Auditfile
