## Icon

<https://openclipart.org/detail/180891>
