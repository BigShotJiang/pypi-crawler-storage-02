This module allows you to export XAF audit files for the Dutch tax
authorities (Belastingdienst).

The currently exported version is 3.2

An option allows to export the XAF audit files in a format that is
accepted by Unit4.
