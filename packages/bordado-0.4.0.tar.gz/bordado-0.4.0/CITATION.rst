Citing Bordado
==============

This is research software **made by scientists**. Citations help us justify the
effort that goes into building and maintaining this project.

If you used it in your research, please consider citing the latest Zenodo
archive: https://doi.org/10.5281/zenodo.15051755
