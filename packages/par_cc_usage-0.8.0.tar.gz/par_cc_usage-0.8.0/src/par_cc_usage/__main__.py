"""Entry point for par_cc_usage when run as a module."""

from par_cc_usage.main import main

if __name__ == "__main__":
    main()
