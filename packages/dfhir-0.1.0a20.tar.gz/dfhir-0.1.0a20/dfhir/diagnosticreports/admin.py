"""diagnostic report app admin."""


# Register your models here.
