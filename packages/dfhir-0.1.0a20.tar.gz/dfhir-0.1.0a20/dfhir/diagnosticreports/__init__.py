"""diagnostic report module."""
