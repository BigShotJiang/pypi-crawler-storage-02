"""AllergyIntolerance module."""
