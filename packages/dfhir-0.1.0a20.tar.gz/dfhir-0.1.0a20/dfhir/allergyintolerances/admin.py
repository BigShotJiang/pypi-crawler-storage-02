"""AllergyIntolerance admin."""

# Register your models here.
