"""Base module for dfhir."""
