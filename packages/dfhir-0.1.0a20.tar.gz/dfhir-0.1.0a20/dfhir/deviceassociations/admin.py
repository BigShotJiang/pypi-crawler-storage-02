"""Deviceassociations admin."""

# Register your models here.
