"""Deviceassociations module."""
