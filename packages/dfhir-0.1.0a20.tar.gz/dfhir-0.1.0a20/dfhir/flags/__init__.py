"""Flag module."""
