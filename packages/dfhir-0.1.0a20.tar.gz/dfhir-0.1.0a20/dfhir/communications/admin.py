"""communications app admin configuration."""

# Register your models here.
