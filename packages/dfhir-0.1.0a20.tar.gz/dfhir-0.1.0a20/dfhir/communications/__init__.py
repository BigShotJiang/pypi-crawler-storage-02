"""communication module."""
