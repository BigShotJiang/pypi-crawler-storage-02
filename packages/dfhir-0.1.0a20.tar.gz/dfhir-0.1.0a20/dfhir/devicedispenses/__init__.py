"""Devicedispenses module."""
