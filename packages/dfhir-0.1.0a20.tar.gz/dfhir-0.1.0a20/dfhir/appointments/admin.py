"""Admin configuration for appointments app."""

# Register your models here.
