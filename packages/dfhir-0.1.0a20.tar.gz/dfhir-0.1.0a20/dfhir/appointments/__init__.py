"""Appointments module."""
