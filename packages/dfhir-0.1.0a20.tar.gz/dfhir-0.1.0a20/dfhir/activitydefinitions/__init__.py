"""activity definition views."""
