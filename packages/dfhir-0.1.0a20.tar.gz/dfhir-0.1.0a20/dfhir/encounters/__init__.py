"""Encounter module."""
