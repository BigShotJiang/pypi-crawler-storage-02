"""Appointment responses module."""
