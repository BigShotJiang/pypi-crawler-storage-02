"""Admin configuration for the appointmentresponses app."""

# Register your models here.
