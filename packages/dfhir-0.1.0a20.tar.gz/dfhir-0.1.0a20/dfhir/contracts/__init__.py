"""Contracts module."""
