"""Detected issues admin."""

# Register your models here.
