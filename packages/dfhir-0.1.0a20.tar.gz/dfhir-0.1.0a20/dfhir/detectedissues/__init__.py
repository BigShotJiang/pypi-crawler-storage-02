"""Detected issues module."""
