"""Devicerequests admin."""

# Register your models here.
