"""Devicerequests module."""
