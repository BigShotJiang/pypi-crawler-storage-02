"""Adverse events module."""
