"""Adverse events admin."""

# Register your models here.
