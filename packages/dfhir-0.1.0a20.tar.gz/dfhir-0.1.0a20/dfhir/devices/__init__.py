"""Devices module."""
