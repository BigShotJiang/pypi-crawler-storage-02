"""Device admin."""
# Register your models here.
