"""Clinical admin."""

# Register your models here.
