"""Clinical impressions module."""
