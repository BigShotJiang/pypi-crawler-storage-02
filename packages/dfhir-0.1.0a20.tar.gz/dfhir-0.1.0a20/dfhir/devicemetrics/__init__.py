"""Device metrics module."""
