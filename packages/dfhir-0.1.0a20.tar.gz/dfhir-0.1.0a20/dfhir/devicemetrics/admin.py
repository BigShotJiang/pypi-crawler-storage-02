"""Device metrics admin."""
