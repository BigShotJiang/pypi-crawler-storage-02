"""Coverage admin."""

# Register your models here.
