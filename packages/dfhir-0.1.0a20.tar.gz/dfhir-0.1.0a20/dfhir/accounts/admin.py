"""Admin configuration for the accounts app."""
# Register your models here.
