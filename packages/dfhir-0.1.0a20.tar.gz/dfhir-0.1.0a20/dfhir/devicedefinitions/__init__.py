"""Device definition module."""
