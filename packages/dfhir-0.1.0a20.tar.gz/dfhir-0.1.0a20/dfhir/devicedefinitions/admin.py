"""Device definition admin."""

# Register your models here.
