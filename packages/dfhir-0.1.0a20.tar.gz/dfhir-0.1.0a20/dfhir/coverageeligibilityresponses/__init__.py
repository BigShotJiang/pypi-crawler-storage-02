"""CoverageEligibilityResponse module."""
