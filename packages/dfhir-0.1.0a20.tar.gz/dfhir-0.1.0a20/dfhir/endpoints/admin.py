"""Endpoints admin."""

# Register your models here.
