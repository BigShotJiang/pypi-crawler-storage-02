"""biologically derived product dispenses module."""
