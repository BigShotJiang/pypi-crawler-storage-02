"""document reference module."""
