"""body structures admin module."""

# Register your models here.
