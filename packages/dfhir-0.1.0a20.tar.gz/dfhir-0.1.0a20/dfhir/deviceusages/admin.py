"""Device usage admin."""

# Register your models here.
