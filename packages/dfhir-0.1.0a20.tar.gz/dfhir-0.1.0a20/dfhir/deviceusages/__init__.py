"""Device usage module."""
