"""Claim response module."""
