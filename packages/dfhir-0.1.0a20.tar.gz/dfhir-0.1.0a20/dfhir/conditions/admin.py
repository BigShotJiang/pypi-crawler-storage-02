"""Admin configuration for conditions app."""
# Register your models here.
