"""Submitit frontend adapter for Flow SDK."""

from flow._internal.frontends.submitit.adapter import SubmititFrontendAdapter

__all__ = ["SubmititFrontendAdapter"]
