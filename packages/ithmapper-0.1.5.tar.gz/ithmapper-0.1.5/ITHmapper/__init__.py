from .pipeline import map_query_to_reference_cell_states
import warnings

warnings.filterwarnings(
    "ignore",           # action: ignore the warning
    module="hotspot"  # only ignore warnings from this module
)
