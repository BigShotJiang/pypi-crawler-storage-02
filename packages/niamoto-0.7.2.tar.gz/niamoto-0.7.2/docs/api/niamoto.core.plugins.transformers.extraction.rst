niamoto.core.plugins.transformers.extraction package
====================================================

Submodules
----------

niamoto.core.plugins.transformers.extraction.direct\_attribute module
---------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.extraction.direct_attribute
   :members:
   :show-inheritance:
   :undoc-members:

niamoto.core.plugins.transformers.extraction.geospatial\_extractor module
-------------------------------------------------------------------------

.. automodule:: niamoto.core.plugins.transformers.extraction.geospatial_extractor
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: niamoto.core.plugins.transformers.extraction
   :members:
   :show-inheritance:
   :undoc-members:
