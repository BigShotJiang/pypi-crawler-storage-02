class conv1d:
	def __init__(self):
		pass

	def call(self, x):
		pass


class conv2d:
	def __init__(self):
		pass

	def call(self, x):
		pass


class conv3d:
	def __init__(self):
		pass

	def call(self, x):
		pass
 
class conv_transpose1d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class conv_transpose2d:
	def __init__(self):
		pass

	def call(self, x):
		pass


class conv_transpose3d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class unfold:
	def __init__(self):
		pass

	def call(self, x):
		pass

class fold:
	def __init__(self):
		pass

	def call(self, x):
		pass


class avg_pool1d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class avg_pool2d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class avg_pool3d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class max_pool1d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class max_pool2d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class max_pool3d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class max_unpool1d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class max_unpool2d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class max_unpool3d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class lp_pool1d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class lp_pool2d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class lp_pool3d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class adaptive_max_pool1d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class adaptive_max_pool2d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class adaptive_max_pool3d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class adaptive_avg_pool1d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class adaptive_avg_pool2d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class adaptive_avg_pool3d:
	def __init__(self):
		pass

	def call(self, x):
		pass


class fractional_max_pool2d:
	def __init__(self):
		pass

	def call(self, x):
		pass

class fractional_max_pool3d:
	def __init__(self):
		pass

	def call(self, x):
		pass


class threshold:
	def __init__(self):

		pass

	def call(self, x):
		pass


class threshold_:
	def __init__(self):

		pass

	def call(self, x):
		pass

