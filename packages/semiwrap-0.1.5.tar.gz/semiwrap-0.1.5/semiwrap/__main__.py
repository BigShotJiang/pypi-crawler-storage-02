if __name__ == "__main__":
    from .tool import main

    main()
