"""A local Python module"""

__version__ = "0.4.5"

from .internals import *  # noqa
from .network import *  # noqa
from .utils import *  # noqa
