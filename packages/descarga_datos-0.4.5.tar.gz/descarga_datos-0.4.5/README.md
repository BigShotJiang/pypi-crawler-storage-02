# descarga_datos <a href="https://www.islas.org.mx/"><img src="https://www.islas.org.mx/img/logo.svg" align="right" width="256" /></a>

[![codecov](https://codecov.io/gh/IslasGECI/descarga_datos/branch/master/graph/badge.svg?token=oeUzR6GLF5)](https://codecov.io/gh/IslasGECI/descarga_datos)

Este repositorio contiene una CLI con la que se podrán descargar los datos
especificados en el archivo `analyses.json`.

## Instalación
RUN pip install git+https://github.com/IslasGECI/descarga_datos.git
