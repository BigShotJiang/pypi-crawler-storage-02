# Initial version authors

* Max Ott <max.ott@csiro.au>

# Partial list of contributors
