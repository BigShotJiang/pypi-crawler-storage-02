"""Jupyter Remote Runner - CLI interface to persistent Jupyter kernel."""

__version__ = "0.1.0"