#!/usr/bin/env python3
"""Entry point for running jupyter_remote_runner as a module."""

from .cli import main

if __name__ == '__main__':
    main()