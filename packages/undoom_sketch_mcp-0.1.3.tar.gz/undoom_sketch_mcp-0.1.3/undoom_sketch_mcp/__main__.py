#!/usr/bin/env python3
"""
Undoom Sketch MCP Server - 主入口点

通过 python -m undoom_sketch_mcp 启动服务器
"""

from .server import main

if __name__ == "__main__":
    main()