"""Main entrypoint for the edge-tts package."""

from .util import main

if __name__ == "__main__":
    main()
