from .core import faux, faux_dict

__all__ = ["faux", "faux_dict"]
