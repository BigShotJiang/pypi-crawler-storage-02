"""Claude Conversation Extractor

A tool to extract Claude conversations from JSON exports and convert them to markdown.
"""

__version__ = "0.1.0"
__author__ = "Jorge MB"
__email__ = "jorge.moreno@sngular.com"
