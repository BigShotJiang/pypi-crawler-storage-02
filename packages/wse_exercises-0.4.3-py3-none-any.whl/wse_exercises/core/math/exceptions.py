"""Mathematical package exceptions."""


class OperandGeneratorError(Exception):
    """Operand generator exceptions."""
