"""Defines mathematical package base classes."""
