ALBUMIN_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Albumin",
        "Albumin | Serum or Plasma | Chemistry - non-challenge",
        "Albumin [Mass/volume] in Serum or Plasma",
    ],
}
