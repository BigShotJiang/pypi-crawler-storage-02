from .albumin_vocab import ALBUMIN_TERMS

__all__ = ["ALBUMIN_TERMS"]
