HF_HOSPITALIZATION_CODES = {
    "icd9": ["425", "425.%", "428", "428.%"],
    "icd10": ["I42", "I42.%", "I50", "I50.%"],
}
