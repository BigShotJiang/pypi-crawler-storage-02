from .inpatient_or_emergency import INPATIENT_OR_EMERGENCY
from .outpatient import OUTPATIENT

__all__ = ["INPATIENT_OR_EMERGENCY", "OUTPATIENT"]
