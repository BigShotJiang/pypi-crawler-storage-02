DEATH_QUERY = """
SELECT
                person_id,
                death_date AS death_entry_date
            FROM
                death
"""
