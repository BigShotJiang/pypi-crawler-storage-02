from phenopipe.tasks.get_data.fixed_query import FixedQuery


class GetWearTime(FixedQuery):
    query: str = "WEAR_TIME_QUERY"
