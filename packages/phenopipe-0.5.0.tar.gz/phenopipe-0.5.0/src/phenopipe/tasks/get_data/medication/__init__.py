from .first_statins_data import FirstStatinsData

__all__ = ["FirstStatinsData"]
