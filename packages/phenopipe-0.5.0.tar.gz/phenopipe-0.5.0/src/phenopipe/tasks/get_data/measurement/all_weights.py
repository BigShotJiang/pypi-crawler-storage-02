from phenopipe.tasks.get_data.fixed_query import FixedQuery


class AllWeights(FixedQuery):
    query: str = "WEIGHT_QUERY"
