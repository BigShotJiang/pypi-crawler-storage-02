from .first_obesity_data import FirstObesityData
from .first_sleep_apnea_data import FirstSleepApneaData

__all__ = ["FirstObesityData", "FirstSleepApneaData"]
