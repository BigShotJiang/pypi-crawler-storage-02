from .search import Substructure, Searcher


class PolarHydrogenGroup:
    ...


