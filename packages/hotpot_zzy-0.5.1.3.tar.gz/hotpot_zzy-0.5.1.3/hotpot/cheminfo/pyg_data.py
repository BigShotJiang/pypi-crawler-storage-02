"""
python v3.9.0
@Project: hotpot
@File   : pyg_data
@Auther : Zhiyuan Zhang
@Data   : 2024/8/23
@Time   : 8:44
"""
from torch_geometric.data import Data
from torch_geometric.utils import from_smiles
