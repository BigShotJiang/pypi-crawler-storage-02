"""
python v3.9.0
@Project: hotpot
@File   : stereo
@Auther : Zhiyuan Zhang
@Data   : 2024/12/18
@Time   : 9:20
# TODO: Ref to OpenBabel and rdkit
"""
