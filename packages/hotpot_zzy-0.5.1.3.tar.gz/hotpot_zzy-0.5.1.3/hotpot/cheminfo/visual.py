"""
python v3.9.0
@Project: hotpot
@File   : visual
@Auther : Zhiyuan Zhang
@Data   : 2024/12/19
@Time   : 10:23
"""
import vtk
