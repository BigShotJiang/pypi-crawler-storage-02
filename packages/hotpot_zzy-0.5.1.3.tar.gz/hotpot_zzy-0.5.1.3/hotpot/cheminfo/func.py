"""
python v3.9.0
@Project: hotpot
@File   : func
@Auther : Zhiyuan Zhang
@Data   : 2024/11/21
@Time   : 9:58

Notes: def some useful functions
"""
