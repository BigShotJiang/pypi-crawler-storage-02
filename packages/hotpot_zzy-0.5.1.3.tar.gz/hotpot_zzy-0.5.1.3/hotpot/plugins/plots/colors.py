"""
python v3.9.0
@Project: hotpot
@File   : colors
@Auther : Zhiyuan Zhang
@Data   : 2024/10/9
@Time   : 12:54
"""


