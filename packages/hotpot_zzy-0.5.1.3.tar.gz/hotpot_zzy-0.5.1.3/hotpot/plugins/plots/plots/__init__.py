"""
python v3.9.0
@Project: hotpot
@File   : __init__.py
@Auther : Zhiyuan Zhang
@Data   : 2024/10/19
@Time   : 9:14
"""
from .general import *
from .beyes import *
from .ml import *
from .base import *
