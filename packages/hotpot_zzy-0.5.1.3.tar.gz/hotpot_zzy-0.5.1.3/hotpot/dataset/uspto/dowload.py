"""
python v3.9.0
@Project: hotpot
@File   : dowload
@Auther : Zhiyuan Zhang
@Data   : 2025/1/2
@Time   : 22:06
"""
urls = {'csv': 'https://zenodo.org/records/14588322/files/smi.tar.xz?download=1'}
