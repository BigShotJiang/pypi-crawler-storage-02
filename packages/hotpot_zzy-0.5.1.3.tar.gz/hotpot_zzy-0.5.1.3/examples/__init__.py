# -*- coding: utf-8 -*-
"""
===========================================================
 Project   : hotpot
 File      : __init__.py
 Created   : 2025/5/16 9:52
 Author    : zhang
 Python    : 
-----------------------------------------------------------
 Description
 ----------------------------------------------------------
 
===========================================================
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
