# -*- coding: utf-8 -*-
"""
===========================================================
 Project   : hotpot
 File      : __init__.py
 Created   : 2025/5/17 20:41
 Author    : zhang
 Python    : 
-----------------------------------------------------------
 Description
 ----------------------------------------------------------
 
===========================================================
"""
import os.path as osp
import sys

sys.path.append(osp.dirname(osp.dirname(osp.abspath(__file__))))
