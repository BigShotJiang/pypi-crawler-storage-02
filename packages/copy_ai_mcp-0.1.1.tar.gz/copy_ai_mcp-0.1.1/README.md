# Copy.ai MCP

A MCP server for Copy.ai.



```json

{
  "mcpServers": {
    "copy-ai": {
      "env": {
        "COPY_AI_API_KEY": "COPY_AI_API_KEY"
      },
      "command": "uvx",
      "args": [
        "copy-ai-mcp"
      ]
    }
  }
}
```