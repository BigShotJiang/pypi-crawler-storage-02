# sppyte

Common tasks with SharePoint REST service.

Under development to port existing NPM package for python development.
