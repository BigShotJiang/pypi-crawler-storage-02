

import pandas as pd

# from nb_log import get_logger
import nb_log

data = [
{"Name": "Alice", "Age": 25, "City": "New York"},
{"Name": "Bob", "Age": 30, "City": "Los Angeles"}
]

df = pd.DataFrame(data)