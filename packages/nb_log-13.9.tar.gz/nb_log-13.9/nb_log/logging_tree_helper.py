
from logging_tree import printout

if __name__ == '__main__':
    import funboost
    printout()