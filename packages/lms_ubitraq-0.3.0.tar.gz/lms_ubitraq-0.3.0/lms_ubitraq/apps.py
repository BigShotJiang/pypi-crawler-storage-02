from django.apps import AppConfig


class UbitraqConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lms_ubitraq'
    label = 'ubitraq'
