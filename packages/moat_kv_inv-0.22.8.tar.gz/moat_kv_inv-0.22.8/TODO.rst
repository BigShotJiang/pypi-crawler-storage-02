* document basic usage

* document command line
