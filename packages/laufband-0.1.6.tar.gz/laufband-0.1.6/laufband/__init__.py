import importlib.metadata

from laufband.laufband import Laufband

__all__ = ["Laufband"]
__version__ = importlib.metadata.version("laufband")
