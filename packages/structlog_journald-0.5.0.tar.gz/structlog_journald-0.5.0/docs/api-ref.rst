API Reference
=============

.. module:: structlog_journald

.. autoclass:: JournaldProcessor
   :members:
   :undoc-members:
   :show-inheritance:

.. autofunction:: is_journald_connected
