"""Internal implementation details for Claude Code Session Client."""
