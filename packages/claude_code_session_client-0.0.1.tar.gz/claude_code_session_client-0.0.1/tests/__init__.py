"""Tests for Claude Code Session Client."""
