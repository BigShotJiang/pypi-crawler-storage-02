"""
Example strategies and usage patterns for the Live Trading System.
"""
