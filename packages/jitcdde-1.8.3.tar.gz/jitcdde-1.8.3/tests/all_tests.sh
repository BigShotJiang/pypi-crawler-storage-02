rm *.so
python3 -m unittest discover -b -f
python3 compare_C_and_Python_core.py 30
python3 compare_C_and_Python_core_2.py 30
