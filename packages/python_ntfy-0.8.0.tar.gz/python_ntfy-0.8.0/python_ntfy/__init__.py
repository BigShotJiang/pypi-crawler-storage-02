from ._ntfy import NtfyClient as NtfyClient

__all__ = ["NtfyClient"]
