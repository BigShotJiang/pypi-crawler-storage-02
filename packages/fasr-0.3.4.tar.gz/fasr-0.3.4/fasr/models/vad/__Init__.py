from .fsmn import FSMNForVAD


__all__ = ["FSMNForVAD"]
