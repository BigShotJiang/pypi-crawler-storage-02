# BioImageSuiteLite/__init__.py
"""
BioImageSuiteLite: A Python GUI tool for cellular event analysis.
"""
__version__ = "0.1.3"

# You can selectively import key functions or classes here if needed
# for easier access from the package level, e.g.:
# from .gui_manager import main