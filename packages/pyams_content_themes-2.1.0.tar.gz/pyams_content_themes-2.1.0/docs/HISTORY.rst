Changelog
=========

2.1.0
-----
 - updated dependencies: jsrender, FontAwesome, FullCalendar...

2.0.5
-----
 - updated importlib.resources dependency

2.0.4
-----
 - packaging issue

2.0.3
-----
 - updated packaging

2.0.2
-----
 - updated support for Python 3.12

2.0.1
-----
 - added custom style to avoid inside breaks
 - always set window.PyAMS_search attribute to handle search filters without associated search form

2.0.0
-----
 - first released version
 - updated dependencies
 - added support for FullCalendar and DataTables
 - added support for Python 3.12

1.99.7
------
 - version mismatch

1.99.6
------
 - updated forms padding
 - updated required field marker position inside object widgets

1.99.5
------
 - added top and bottom scripts to main layout

1.99.4
------
 - added rotation transition to search filters switchers
 - updated object widget template
 - updated styles

1.99.3
------
 - update form layout

1.99.2
------
 - updated forms and widgets layouts
 - added aggregated filters support
 - added responsive font sizes
 - updated styles

1.99.1
------
 - added flex wrapper class to form buttons

1.99.0
------
 - first preliminary release
