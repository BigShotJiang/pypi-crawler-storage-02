import os

__version__ = "1.24.1"
__build_version__ = os.getenv("BUILD_VERSION", "0")
