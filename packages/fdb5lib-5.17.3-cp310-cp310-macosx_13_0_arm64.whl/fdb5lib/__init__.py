__version__ = '5.17.3'
__commit_hash__ = '9145a6e9840643668667698f526c0b9a9b2da210'
findlibs_dependencies = ["eckitlib", "eccodeslib", "metkitlib"]
