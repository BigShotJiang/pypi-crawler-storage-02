"""
aidesk - A simple web service with file operations and authentication
"""
__version__ = "0.2.0"
