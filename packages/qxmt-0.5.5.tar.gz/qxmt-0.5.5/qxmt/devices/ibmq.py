IBMQ_PROVIDER_NAME = "IBM_Quantum"
IBMQ_REAL_DEVICES = ["qiskit.remote"]
