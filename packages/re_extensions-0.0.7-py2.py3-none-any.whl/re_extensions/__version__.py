"""Version file."""

VERSION = (0, 0, 7)

__version__ = ".".join(map(str, VERSION))
