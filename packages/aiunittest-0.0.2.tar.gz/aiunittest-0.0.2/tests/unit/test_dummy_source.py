def another_function() -> None:
    pass
