class FocusTimeManager:

    def __init__(self, client_class):
        self._client = client_class
        self.access_token = ''

    #   ---------------------------------------------------------------------------------------------------------------
    #   Focus Timer Methods

    def start(self):
        """Starts the focus timer"""
        pass



