"""Holds some useful constants"""
DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
