"""Utility CLI tools for CAMELEON-DP (packaged for python -m tools.*)."""


