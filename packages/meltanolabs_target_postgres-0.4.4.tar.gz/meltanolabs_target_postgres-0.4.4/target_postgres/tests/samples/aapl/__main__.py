"""Executable for fundamentals tap.

Run:

$ uv run python samples/aapl
"""

from aapl import Fundamentals

Fundamentals.cli()
