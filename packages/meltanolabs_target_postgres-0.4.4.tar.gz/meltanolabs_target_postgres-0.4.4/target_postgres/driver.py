"""This module contains the Postgres driver name for SQLAlchemy."""

PSYCOPG3 = "postgresql+psycopg"
