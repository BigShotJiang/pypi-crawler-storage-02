from tmlib2 import mod

print(mod.add_one(5))