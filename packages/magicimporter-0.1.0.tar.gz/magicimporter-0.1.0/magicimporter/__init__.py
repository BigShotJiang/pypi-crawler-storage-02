from .core import magic_import
