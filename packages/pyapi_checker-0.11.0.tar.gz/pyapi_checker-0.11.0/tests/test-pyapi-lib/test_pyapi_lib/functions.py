def special_string_add(a: str, b: str) -> str:
    return a + b


def special_int_subtract(a: int, b: int) -> int:
    return a - b
