"""
Entry point for the pybind2csv CLI application.
"""

from pybind2csv.main import app

if __name__ == "__main__":
    app()
