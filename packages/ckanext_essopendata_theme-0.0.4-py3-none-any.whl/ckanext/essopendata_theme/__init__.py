# ckanext/essopendata_theme/__init__.py

__version__ = "0.0.3"