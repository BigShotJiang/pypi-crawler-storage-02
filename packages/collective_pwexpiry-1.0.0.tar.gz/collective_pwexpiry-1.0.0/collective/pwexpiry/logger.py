# -*- coding: utf-8 -*-
from collective.pwexpiry.config import PROJECTNAME

import logging


logger = logging.getLogger(PROJECTNAME)
