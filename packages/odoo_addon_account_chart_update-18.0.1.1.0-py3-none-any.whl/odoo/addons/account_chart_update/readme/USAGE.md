The wizard, accesible from *Accounting \> Settings \> Update Chart
Template*, lets the user select what kind of objects must be
checked/updated, and whether old records must be checked for changes and
updates.

It will display all the objects to be created / updated / deactivated
with some information about the detected differences, and allow the user
to exclude records individually.
