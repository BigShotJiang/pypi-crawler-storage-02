# This is an automatically generated file.
# DO NOT EDIT or your changes may be overwritten
from __future__ import annotations

import base64
from enum import IntEnum

from xdrlib3 import Packer, Unpacker

__all__ = ["MemoType"]


class MemoType(IntEnum):
    """
    XDR Source Code::

        enum MemoType
        {
            MEMO_NONE = 0,
            MEMO_TEXT = 1,
            MEMO_ID = 2,
            MEMO_HASH = 3,
            MEMO_RETURN = 4
        };
    """

    MEMO_NONE = 0
    MEMO_TEXT = 1
    MEMO_ID = 2
    MEMO_HASH = 3
    MEMO_RETURN = 4

    def pack(self, packer: Packer) -> None:
        packer.pack_int(self.value)

    @classmethod
    def unpack(cls, unpacker: Unpacker) -> MemoType:
        value = unpacker.unpack_int()
        return cls(value)

    def to_xdr_bytes(self) -> bytes:
        packer = Packer()
        self.pack(packer)
        return packer.get_buffer()

    @classmethod
    def from_xdr_bytes(cls, xdr: bytes) -> MemoType:
        unpacker = Unpacker(xdr)
        return cls.unpack(unpacker)

    def to_xdr(self) -> str:
        xdr_bytes = self.to_xdr_bytes()
        return base64.b64encode(xdr_bytes).decode()

    @classmethod
    def from_xdr(cls, xdr: str) -> MemoType:
        xdr_bytes = base64.b64decode(xdr.encode())
        return cls.from_xdr_bytes(xdr_bytes)
