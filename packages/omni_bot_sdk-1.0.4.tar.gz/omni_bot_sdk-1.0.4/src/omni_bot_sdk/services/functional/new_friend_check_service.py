"""
新好友校验服务模块。
提供新好友添加、校验等相关服务。
"""

from queue import Queue
from omni_bot_sdk.services.core.database_service import DatabaseService


class NewFriendCheckService:
    """
    开源版本 占位
    """

    def __init__(self, rpa_queue: Queue, db: DatabaseService):
        pass

    def start(self):
        pass

    def stop(self):
        pass
