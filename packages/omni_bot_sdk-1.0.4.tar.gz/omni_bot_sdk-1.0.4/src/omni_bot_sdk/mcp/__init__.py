"""
MCP (Message Control Panel) 模块包
"""
