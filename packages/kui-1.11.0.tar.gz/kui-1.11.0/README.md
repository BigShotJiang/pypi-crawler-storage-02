# Kuí

[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/kui?label=Support%20Python%20Version&style=flat-square)](https://pypi.org/project/kui/)

An easy-to-use web framework. Based on [baize](https://baize.aber.sh) and [pydantic](https://docs.pydantic.dev/).

## Install

```
pip install kui
```
