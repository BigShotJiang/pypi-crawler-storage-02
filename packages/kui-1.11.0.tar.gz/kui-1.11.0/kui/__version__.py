VERSION = (1, 11, 0)

__version__ = ".".join(map(str, VERSION))
