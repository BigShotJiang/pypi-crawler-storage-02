from .application import OpenAPI
from .extra_docs import describe_extra_docs

__all__ = ["describe_extra_docs", "OpenAPI"]
