
``wuttjamaican.app``
====================

.. automodule:: wuttjamaican.app
   :members:
