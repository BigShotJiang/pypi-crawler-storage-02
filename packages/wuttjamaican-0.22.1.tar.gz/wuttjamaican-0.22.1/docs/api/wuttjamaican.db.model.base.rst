
``wuttjamaican.db.model.base``
==============================

.. automodule:: wuttjamaican.db.model.base
   :members:
