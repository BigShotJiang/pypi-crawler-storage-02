
``wuttjamaican.db.model``
=========================

.. automodule:: wuttjamaican.db.model
   :members:
