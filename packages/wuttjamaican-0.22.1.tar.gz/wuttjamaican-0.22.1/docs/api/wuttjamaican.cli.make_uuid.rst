
``wuttjamaican.cli.make_uuid``
==============================

.. automodule:: wuttjamaican.cli.make_uuid
   :members:
