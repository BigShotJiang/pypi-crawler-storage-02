
``wuttjamaican.exc``
====================

.. automodule:: wuttjamaican.exc
   :members:
