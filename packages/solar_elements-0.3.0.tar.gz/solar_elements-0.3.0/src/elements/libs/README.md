Lots of Bitcoin libraries in here... it might be worth swapping them out for: https://btclib.org/
