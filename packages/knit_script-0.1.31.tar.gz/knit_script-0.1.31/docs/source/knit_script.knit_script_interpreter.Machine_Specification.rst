knit\_script.knit\_script\_interpreter.Machine\_Specification module
====================================================================

.. automodule:: knit_script.knit_script_interpreter.Machine_Specification
   :members:
   :undoc-members:
   :show-inheritance:
