knit\_script.knit\_script\_interpreter.statements.in\_direction\_statement module
=================================================================================

.. automodule:: knit_script.knit_script_interpreter.statements.in_direction_statement
   :members:
   :undoc-members:
   :show-inheritance:
