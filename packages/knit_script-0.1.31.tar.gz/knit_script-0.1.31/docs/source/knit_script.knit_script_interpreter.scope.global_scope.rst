knit\_script.knit\_script\_interpreter.scope.global\_scope module
=================================================================

.. automodule:: knit_script.knit_script_interpreter.scope.global_scope
   :members:
   :undoc-members:
   :show-inheritance:
