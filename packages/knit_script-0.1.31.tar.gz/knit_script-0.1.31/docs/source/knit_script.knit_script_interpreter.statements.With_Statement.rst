knit\_script.knit\_script\_interpreter.statements.With\_Statement module
========================================================================

.. automodule:: knit_script.knit_script_interpreter.statements.With_Statement
   :members:
   :undoc-members:
   :show-inheritance:
