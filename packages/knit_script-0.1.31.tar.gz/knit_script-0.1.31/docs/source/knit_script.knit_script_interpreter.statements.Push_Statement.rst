knit\_script.knit\_script\_interpreter.statements.Push\_Statement module
========================================================================

.. automodule:: knit_script.knit_script_interpreter.statements.Push_Statement
   :members:
   :undoc-members:
   :show-inheritance:
