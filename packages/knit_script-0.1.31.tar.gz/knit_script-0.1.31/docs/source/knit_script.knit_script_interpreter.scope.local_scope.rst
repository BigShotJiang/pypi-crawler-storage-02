knit\_script.knit\_script\_interpreter.scope.local\_scope module
================================================================

.. automodule:: knit_script.knit_script_interpreter.scope.local_scope
   :members:
   :undoc-members:
   :show-inheritance:
