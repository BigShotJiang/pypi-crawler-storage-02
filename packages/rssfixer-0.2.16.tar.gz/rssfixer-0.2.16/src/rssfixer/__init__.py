"""Call main."""

from .rss import main

if __name__ == "__main__":
    main()  # pragma: no cover
