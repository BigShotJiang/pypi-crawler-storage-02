from .gradient_descent_contraction import wc_gradient_descent_contraction

__all__ = ['gradient_descent_contraction', 'wc_gradient_descent_contraction',
           ]
