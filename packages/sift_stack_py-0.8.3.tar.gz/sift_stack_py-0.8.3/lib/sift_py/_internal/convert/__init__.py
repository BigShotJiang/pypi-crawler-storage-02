"""
Utilities for type-conversion and type-casting.
"""
