def hello():
    print("hello my name is prateek")