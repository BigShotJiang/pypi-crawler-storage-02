2024-07-31 Version: 1.1.3
- Update API DescribeAnycastEipAddress: update response param.


2024-02-04 Version: 1.1.2
- Generated python 2020-03-09 for Eipanycast.

2024-01-25 Version: 1.1.1
- Generated python 2020-03-09 for Eipanycast.

2023-08-25 Version: 1.1.0
- Generated python 2020-03-09 for Eipanycast.

2023-04-07 Version: 1.0.3
- Support tag for anycast.

2022-08-09 Version: 1.0.2
- Publish.

2021-12-16 Version: 1.0.1
- Generated python 2020-03-09 for Eipanycast.

2021-11-26 Version: 1.0.0
- Generated python 2020-03-09 for Eipanycast.

