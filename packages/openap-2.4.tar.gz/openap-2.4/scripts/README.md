# Aircraft related scripts and data

- Generate engine data from ICAO emission data bank
- Generate airport data from FR24
