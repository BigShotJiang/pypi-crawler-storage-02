from . import log
from .log.__log import Log
from .__corporatecard import create, get, query, page, update, cancel
