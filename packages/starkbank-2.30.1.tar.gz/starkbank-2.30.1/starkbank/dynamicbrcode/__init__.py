from .rule.__rule import Rule
from .__dynamicbrcode import create, get, query, page
