def to_column(field: str) -> str:
    return field.replace(".", "_")
