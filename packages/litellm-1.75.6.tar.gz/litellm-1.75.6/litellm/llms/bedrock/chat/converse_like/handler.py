"""
Uses base_llm_http_handler to call the 'converse like' endpoint.

Relevant issue: https://github.com/BerriAI/litellm/issues/8085
"""
