
print("WARNING: This import is vulnerable to dependency confusion. This attack has been prevented.")
def hello():
    print("HELLO WORLD")
