"""
Tests for miscellaneous regresessions.
"""


def test_Sources_import():
    from pycldf import Sources

