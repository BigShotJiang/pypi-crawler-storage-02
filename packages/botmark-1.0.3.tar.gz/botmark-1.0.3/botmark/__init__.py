__version__ = "1.0.3"
from .core import BotManager

__all__ = ["BotManager", "BotMarkAgent"]