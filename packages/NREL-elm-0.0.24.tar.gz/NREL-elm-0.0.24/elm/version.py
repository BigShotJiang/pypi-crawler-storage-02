"""
ELM version number
"""

__version__ = "0.0.24"
