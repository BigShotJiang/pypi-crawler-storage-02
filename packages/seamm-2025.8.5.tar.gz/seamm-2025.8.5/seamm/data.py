# -*- coding: utf-8 -*-

"""A module for holding data"""

forcefield = None
forcefield_type = None
structure = None
