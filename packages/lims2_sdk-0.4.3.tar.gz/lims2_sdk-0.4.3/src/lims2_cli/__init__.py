"""Lims2 CLI 包"""
