"""
Note to JSON - A markdown to structured JSON parser
"""

__version__ = "0.1.0"
__author__ = "Note to JSON Team"

from .parser import parse_file

__all__ = ["parse_file"]
