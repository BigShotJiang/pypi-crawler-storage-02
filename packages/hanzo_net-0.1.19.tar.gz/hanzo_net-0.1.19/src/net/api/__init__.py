from net.api.chatgpt_api import ChatGPTAPI as ChatGPTAPI
