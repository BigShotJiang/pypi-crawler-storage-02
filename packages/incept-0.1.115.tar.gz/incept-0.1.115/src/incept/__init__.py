# src/incept/__init__.py
import incept.config  # this runs the load_dotenv exactly once
