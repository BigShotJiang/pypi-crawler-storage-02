excelfred | Python library (alias "xl")
514 Excel Functions -> Python Module

Recreate Microsoft Excel formulas in Python using NumPy and Pandas. Supports ABS, ACCRINT, ACCRINTM, ACOS, ACOT, ACOSH, ACOTH, AMORLINC.