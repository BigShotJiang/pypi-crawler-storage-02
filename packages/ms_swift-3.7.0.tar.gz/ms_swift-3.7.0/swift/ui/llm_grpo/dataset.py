# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.dataset import Dataset


class GRPODataset(Dataset):

    group = 'llm_grpo'
