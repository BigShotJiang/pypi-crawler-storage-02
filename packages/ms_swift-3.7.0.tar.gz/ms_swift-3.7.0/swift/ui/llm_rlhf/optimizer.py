# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.optimizer import Optimizer


class RLHFOptimizer(Optimizer):

    group = 'llm_rlhf'
