# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.dataset import Dataset


class RLHFDataset(Dataset):

    group = 'llm_rlhf'
