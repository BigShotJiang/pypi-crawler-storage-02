# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.llm import infer_main

if __name__ == '__main__':
    infer_main()
