# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.llm import rollout_main

if __name__ == '__main__':
    rollout_main()
