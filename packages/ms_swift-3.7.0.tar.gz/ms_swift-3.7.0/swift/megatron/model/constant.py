# Copyright (c) Alibaba, Inc. and its affiliates.
class MegatronModelType:
    gpt = 'gpt'
