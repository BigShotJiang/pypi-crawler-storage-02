# -*- coding: utf-8 -*-

# Copyright © 2015-2018 Tiger Computing Ltd
# This file is part of pytiger and distributed under the terms
# of a BSD-like license
# See the file COPYING for details

# shortcut: from pytiger.monitoring import MonitoringCheck
from .monitoringcheck import MonitoringCheck  # noqa: F401
