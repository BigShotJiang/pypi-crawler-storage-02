# pytiger

[![Documentation Status](https://readthedocs.org/projects/pytiger/badge/?version=latest)](http://pytiger.readthedocs.io/en/latest/?badge=latest)

pytiger is the Tiger Computing Ltd python utility library.

Documentation: http://pytiger.readthedocs.io/
