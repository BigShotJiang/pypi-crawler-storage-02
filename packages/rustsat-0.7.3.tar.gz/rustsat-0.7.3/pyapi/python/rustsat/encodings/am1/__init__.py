from .rustsat.encodings.am1 import *

__doc__ = rustsat.encodings.am1.__doc__
if hasattr(rustsat.encodings.am1, "__all__"):
    __all__ = rustsat.encodings.am1.__all__
