# Changelog

All notable changes to this project will be documented in this file.

## [0.5.1] - 2024-06-12

### Miscellaneous Tasks

- Updated the following local packages: rustsat

## [0.5.0] - 2024-04-30

Factor Python API out into its own crate.
