=======
Credits
=======

Maintainer
----------

* Thomas Morris <thomas.w.morris@yale.edu>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst
