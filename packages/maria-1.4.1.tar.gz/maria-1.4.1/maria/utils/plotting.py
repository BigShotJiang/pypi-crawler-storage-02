HEX_CODE_LIST = [
    "#1f78b4",
    "#e31a1c",
    "#33a02c",
    "#ff7f00",
    "#6a3d9a",
    "#b15928",
    "#a6cee3",
    "#fb9a99",
    "#b2df8a",
    "#fdbf6f",
    "#cab2d6",
    "#ffff99",
]
