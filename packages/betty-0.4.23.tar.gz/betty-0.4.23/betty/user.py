"""
An API to interact with Betty's user.
"""


class UserFacing:
    """
    A sentinel to mark something as being visible to users (e.g. not internal).
    """
