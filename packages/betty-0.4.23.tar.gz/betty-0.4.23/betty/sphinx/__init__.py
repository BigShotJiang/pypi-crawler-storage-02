"""
Integrate Betty with `Sphinx <https://www.sphinx-doc.org>`_.
"""
