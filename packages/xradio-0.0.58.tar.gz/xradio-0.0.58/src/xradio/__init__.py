# import os
# from toolviper.utils.logger import setup_logger


# _logger_name = "xradio"
# if os.getenv("VIPER_LOGGER_NAME") != _logger_name:
#     os.environ["VIPER_LOGGER_NAME"] = _logger_name
#     setup_logger(
#         logger_name="xradio",
#         log_to_term=True,
#         log_to_file=False,  # True
#         log_file="xradio-logfile",
#         log_level="DEBUG",
#     )
