
pyb2d3 documentation
====================



.. toctree::
   :maxdepth: 1
   :caption: Contents:

   src/about_the_docs.rst
   src/installation.rst
   src/differences.rst
   src/api.rst
   src/samples/index.rst




.. include:: src/samples/sample_videos.rst
