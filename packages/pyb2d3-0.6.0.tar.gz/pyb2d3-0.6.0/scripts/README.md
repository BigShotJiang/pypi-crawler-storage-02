Scripts
=================

This folder contains various scripts used for different purposes in the project.
This should only be of interest to developers.
