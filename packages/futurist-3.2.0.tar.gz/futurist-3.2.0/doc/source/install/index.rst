============
Installation
============

At the command line::

    $ pip install futurist

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv futurist
    $ pip install futurist
