class AuthApiUrl:
    GET_TOKEN = "/api/v1/oauth2/token"
