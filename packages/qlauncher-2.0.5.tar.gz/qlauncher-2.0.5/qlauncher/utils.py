""" Utility functions for QLauncher"""
