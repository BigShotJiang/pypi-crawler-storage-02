default_app_config = "wise.apps.WiseConfig"
