"""iDeepLC: A deep Learning-based retention time predictor for unseen modified peptides with a novel encoding system"""

__version__ = "1.2.0"
