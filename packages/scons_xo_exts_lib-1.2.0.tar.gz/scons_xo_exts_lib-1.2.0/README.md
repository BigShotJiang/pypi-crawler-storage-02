# SCons XO Exts

SCons extensions

## About

Extensions for SCons, includes Python libraries and builders.

## Repository

Upstream repository is <https://gitlab.com/xgqt/xgqt-python-lib-scons-xo-exts/>.

## Package

Download from PYPI: <https://pypi.org/project/scons-xo-exts-lib/>.

## License

### Code

Code in this project is licensed under the MPL, version 2.0.

    This Source Code Form is subject to the terms of the Mozilla Public
    License, v. 2.0. If a copy of the MPL was not distributed with this
    file, You can obtain one at http://mozilla.org/MPL/2.0/.
