Generate random integers from low (inclusive) to high (exclusive), see numpy.random.randint for details
* "low" - Lower boundary of the interval (inclusive). Input must be either an integer or an array of integers
* "high" - Upper boundary of the interval (exclusive). Input must be either an integer or an array of integers
* "size" - Output shape, e.g., [m, n, k] will draw m * n * k samples. Leave this empty to draw a single value.