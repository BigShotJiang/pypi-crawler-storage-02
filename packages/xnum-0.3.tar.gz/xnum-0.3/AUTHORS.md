# Core Developers
----------
- Sepand Haghighi - Open Science Laboratory ([Github](https://github.com/sepandhaghighi)) **
- Sadra Sabouri - Open Science Laboratory ([Github](https://github.com/sadrasabouri))

** **Maintainer**

# Other Contributors
----------
- [ChatGPT](https://chat.openai.com/) ++

++ Graphic designer

