To use this module, you need to:

1.  Go to Configuration / Users / Users choose user and set Roles:

![image](/OCA/server-backend/base_user_role/static/description/user_form.png)
