from setuptools import setup, find_packages

setup(
    name="mi4-conventional-commits-lib",
    version="0.0.6",
    description="A conventional commits validation library",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="MI4",
    author_email="contact@mi4.fr",
    url="https://github.com/Mi4-Conventional-Commits-Lib/Mi4-Conventional-Commits-Lib",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Software Development :: Version Control",
    ],
    keywords=["conventional-commits", "validation", "git", "commit-message"],
    project_urls={
        "Bug Reports": "https://github.com/Mi4-Conventional-Commits-Lib/Mi4-Conventional-Commits-Lib/issues",
        "Source": "https://github.com/Mi4-Conventional-Commits-Lib/Mi4-Conventional-Commits-Lib",
        "Documentation": "https://github.com/Mi4-Conventional-Commits-Lib/Mi4-Conventional-Commits-Lib#readme",
    },
)
