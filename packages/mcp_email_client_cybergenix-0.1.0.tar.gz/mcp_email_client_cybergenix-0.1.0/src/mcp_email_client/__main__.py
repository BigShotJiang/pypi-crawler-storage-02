from mcp_email_client.server import main

if __name__ == "__main__":
    main()