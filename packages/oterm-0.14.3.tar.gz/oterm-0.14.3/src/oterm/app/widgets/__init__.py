import oterm.app.widgets.monkey  # noqa: F401
