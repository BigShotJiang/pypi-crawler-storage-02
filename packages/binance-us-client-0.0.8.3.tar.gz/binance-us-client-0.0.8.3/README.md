# Binance.US Client

> search <font color=#81D8D0 >`binance-us-client`</font> in pypi  
> 

> or execute `pip3 install binance-us-client` in bash directly
> 