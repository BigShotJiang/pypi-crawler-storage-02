"""
exception package
"""

from .symbol_exception import *
