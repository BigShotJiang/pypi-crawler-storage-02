"""symbol related exception"""


class SymbolException(Exception):
    """exception when get symbol data """
