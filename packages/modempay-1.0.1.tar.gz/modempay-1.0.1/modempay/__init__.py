from .main import ModemPay

__version__ = "1.0.0"
