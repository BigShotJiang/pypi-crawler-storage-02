#!/bin/bash

pushd $(dirname $0)/..

npm install

popd