import sys
from .cli import main

# This runs the main function and ensures the script exits with the correct status code.
if __name__ == "__main__":
    sys.exit(main())