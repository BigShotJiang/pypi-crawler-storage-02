"""mitol.apigateway"""

default_app_config = "mitol.apigateway.apps.ApigatewayApp"

__version__ = "2025.8.14"
__distributionname__ = "mitol-django-apigateway"
