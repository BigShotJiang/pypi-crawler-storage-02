"""
Instant GX MCP Server - Pure vanilla MCP
"""