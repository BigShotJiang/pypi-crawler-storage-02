#!/usr/bin/env python3
"""
Entry point for GX MCP Server (STDIO version)
"""

from .server import main

if __name__ == "__main__":
    main()
