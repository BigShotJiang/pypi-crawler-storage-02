"""
GX MCP Server - Vanilla MCP with STDIO transport
Exposes Great Expectations data validation as MCP tools
"""
