# Copyright 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


from openfl.federated.plan.plan import Plan
