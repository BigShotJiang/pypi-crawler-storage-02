"""Intelligent Capability definitions."""

from .common import CAPABILITY, ITU_TYPES
from .itucl_aai_i2x7o8 import ITUClArithmeticAdditionIntI2x7O8
