# from enum import Enum
#
# class Math(Enum):
#     ADDITION = 0
#     SUBTRACTION = 1
#     MULTIPLICATION = 2
#     DIVISION = 3
#
# class Intellect(Enum):
#     MATH = Math
#
#
# class CapGroup(Enum):
#     CGROUP1 =
