""" check_soa_serials """

__author__ = "cspeterson"
__version__ = "1.0.0"
__title__ = "check_soa_serials"
__license__ = "License :: OSI Approved :: MIT License"
