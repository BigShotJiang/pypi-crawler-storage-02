"""
Likes module for the X API.

This module provides access to the Likes endpoints of the X API.
"""

from .client import LikesClient

__all__ = ["LikesClient"]
