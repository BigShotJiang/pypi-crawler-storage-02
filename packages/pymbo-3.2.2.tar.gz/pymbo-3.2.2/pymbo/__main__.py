"""
Entry point for running pymbo as a module with python -m pymbo
"""

from .launcher import main

if __name__ == "__main__":
    main()