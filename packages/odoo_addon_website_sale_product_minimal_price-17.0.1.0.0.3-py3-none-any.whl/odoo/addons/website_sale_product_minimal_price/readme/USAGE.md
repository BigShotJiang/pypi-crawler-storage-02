1.  Go to backend and set a product with variants and extra price by
    attribute value or define a distinct prices in public price list for
    this variant.
2.  Go to Website Shop.
3.  You will see that in main products view appears the text "From "
    with minimal price if the product has a distinct prices by
    attribute.
4.  Click on product, the price displayed is the minimal variant price.
