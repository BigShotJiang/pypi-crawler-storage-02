from . import test_product_with_no_prices
from . import test_website_sale_product_minimal_price
