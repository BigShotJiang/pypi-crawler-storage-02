# Note: this directory is purely for libraries to be directly included instead of as dependencies
