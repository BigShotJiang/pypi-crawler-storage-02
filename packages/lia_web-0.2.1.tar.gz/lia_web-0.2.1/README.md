# Lia

**Write once, run everywhere** - A universal web framework adapter for Python that lets you write code once and use it across multiple web frameworks.

## Installation

```bash
uv add lia-web
```

## Overview

Lia provides a unified interface for common web framework operations, allowing you to write framework-agnostic code that can be easily adapted to work with FastAPI, Flask, Django, and other popular Python web frameworks.

## Features

This project is in early development!
