# yadumair

A simple Python package to generate bedtime stories using OpenAI's GPT-5 model.

## Installation

```bash
pip install yadumair
