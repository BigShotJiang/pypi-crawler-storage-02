# tektii/__version__.py
"""Version information for tektii python library."""

__version__ = "1.3.0"
