This module depends on:

- l10n_br_sale
- sale_invoice_plan
