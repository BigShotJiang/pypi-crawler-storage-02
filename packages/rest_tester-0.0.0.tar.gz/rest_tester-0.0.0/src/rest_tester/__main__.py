#!/usr/bin/env python3
"""
Makes the rest-tester package executable with python -m rest-tester
"""

from .main import main

if __name__ == "__main__":
    main()
