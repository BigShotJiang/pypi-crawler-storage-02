from .t3dpy import *

__doc__ = t3dpy.__doc__
if hasattr(t3dpy, "__all__"):
    __all__ = t3dpy.__all__