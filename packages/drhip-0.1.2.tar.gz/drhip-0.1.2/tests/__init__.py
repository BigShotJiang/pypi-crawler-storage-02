"""
Test suite for DRHIP (Data Reduction for HyPhy with Inference Processing).
"""
