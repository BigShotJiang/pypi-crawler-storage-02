import os

__version__ = "0.3.7"  # Update this manually when needed
__SOURCE_COMMIT_CORE__ = os.getenv("SOURCE_COMMIT_CORE", "")