"""Simply tests for PyPI."""

import prettypyplot as pplt


if __name__ == '__main__':
    pplt.use_style()
