"""Submodule conataining all colormaps."""
