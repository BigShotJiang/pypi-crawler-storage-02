import importlib.metadata

from .ouroboros import *


__version__ = importlib.metadata.version("ouroboros-gis")
