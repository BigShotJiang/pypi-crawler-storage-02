from ..variant import Variant

class MockVariant(Variant):
    pass