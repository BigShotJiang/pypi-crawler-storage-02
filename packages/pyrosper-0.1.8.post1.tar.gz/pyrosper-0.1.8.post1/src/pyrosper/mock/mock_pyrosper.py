from ..pyrosper import Pyrosper
from .mock_experiment import MockExperiment

class MockPyrosper(Pyrosper[MockExperiment]):
    pass
