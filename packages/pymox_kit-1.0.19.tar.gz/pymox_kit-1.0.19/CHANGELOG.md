# CHANGELOG

<!-- version list -->

## v1.0.19 (2025-08-04)


## v1.0.18 (2025-08-04)


## v1.0.17 (2025-08-04)


## v1.0.16 (2025-08-03)

### Bug Fixes

- Use GH TK
  ([`2f36175`](https://github.com/PyMoX-fr/Kit/commit/2f36175bd7df0e7681d948b68335de9eb1974e77))


## v1.0.15 (2025-08-03)

### Bug Fixes

- V 15
  ([`1d1d87d`](https://github.com/PyMoX-fr/Kit/commit/1d1d87d3afe14940b695f14ea4c058dc6e460e55))


## v1.0.14 (2025-08-03)

### Bug Fixes

- V 1.14
  ([`8568a3e`](https://github.com/PyMoX-fr/Kit/commit/8568a3e40e167eeb36290dddf1e49e39158f2c3a))


## v1.0.13 (2025-08-03)


## v1.0.12 (2025-08-03)

### Bug Fixes

- Fix toml
  ([`d99a8e5`](https://github.com/PyMoX-fr/Kit/commit/d99a8e58d4c81e0af6ead284a86c0d6d6e774f13))


## v1.0.11 (2025-08-03)

### Bug Fixes

- V1.11
  ([`2516d1e`](https://github.com/PyMoX-fr/Kit/commit/2516d1e3b5a83a6a5dba434bade20a907249b8f4))


## v1.0.10 (2025-08-03)


## v1.0.9 (2025-08-03)


## v1.0.8 (2025-08-03)


## v1.0.7 (2025-08-03)


## v1.0.6 (2025-08-03)

### Bug Fixes

- Set v5
  ([`a4272c3`](https://github.com/PyMoX-fr/Kit/commit/a4272c3e2a2dc2aa9ed0544f7228d43aaffe7649))


## v1.0.5 (2025-08-03)

### Bug Fixes

- Nett 2
  ([`855effa`](https://github.com/PyMoX-fr/Kit/commit/855effa8f3fdd91454b23e5891fd25511c9ae897))


## v1.0.0 (2025-08-03)

- Initial Release

## v1.0.0 (2025-08-03)

- Initial Release

## v1.0.4 (2025-08-03)

### Bug Fixes

- Set local dev for tokens()
  ([`3183e15`](https://github.com/PyMoX-fr/GC7/commit/3183e15b25687c51da31870827091a5e81f756ff))


## v1.0.3 (2025-08-03)


## v1.0.2 (2025-08-03)


## v1.0.1 (2025-08-03)

### Bug Fixes

- Set hello()
  ([`03efc80`](https://github.com/PyMoX-fr/GC7/commit/03efc8032804e20feadba5fd246e07c1bc133b4b))


## v1.0.0 (2025-08-03)

- Initial Release
