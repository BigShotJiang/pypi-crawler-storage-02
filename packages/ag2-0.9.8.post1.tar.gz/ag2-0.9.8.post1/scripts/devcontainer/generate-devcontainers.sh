#!/usr/bin/env bash

python3 scripts/devcontainer/generate-devcontainers.py
