"""Examples for Synq usage."""
