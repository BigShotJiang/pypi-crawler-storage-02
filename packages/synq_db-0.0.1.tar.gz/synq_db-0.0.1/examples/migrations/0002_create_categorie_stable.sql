-- CREATE TABLE categories
CREATE TABLE categories (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	description VARCHAR, 
	PRIMARY KEY (id)
);
