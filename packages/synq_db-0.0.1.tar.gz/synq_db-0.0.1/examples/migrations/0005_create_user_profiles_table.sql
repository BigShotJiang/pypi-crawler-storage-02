-- CREATE TABLE user_profiles
CREATE TABLE user_profiles (
	id INTEGER NOT NULL, 
	user_id INTEGER, 
	bio VARCHAR, 
	PRIMARY KEY (id)
);
