"""Allow running synq as a module: python -m synq"""

from synq.cli.main import cli

if __name__ == "__main__":
    cli()
