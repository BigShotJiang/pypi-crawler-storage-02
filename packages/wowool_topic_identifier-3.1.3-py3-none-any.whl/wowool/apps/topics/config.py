CONFIG = {
    "name": "Topics",
    "short_description": "The Topic application identifies the topics in your documents and their relevancy.",
    "long_description": "The Topic application enables you to identify the topics in your documents and their relevancy.",
}
