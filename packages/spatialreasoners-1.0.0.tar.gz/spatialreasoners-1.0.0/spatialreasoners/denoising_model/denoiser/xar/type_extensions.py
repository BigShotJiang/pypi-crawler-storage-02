from ..dit.type_extensions import DiTModelInputs, DiTModelOutput


xARModelInputs = DiTModelInputs
xARModelOutput = DiTModelOutput
