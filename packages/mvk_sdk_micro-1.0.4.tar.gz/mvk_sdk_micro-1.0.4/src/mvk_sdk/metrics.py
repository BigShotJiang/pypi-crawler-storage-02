"""Metrics support for MVK SDK v3.0.

Provides the Metric class and add_metered_usage function.
"""

import json
import logging
from typing import Any, Dict, Optional

from .tracer import get_current_span

logger = logging.getLogger(__name__)


class Metric:
    """Common metric kinds for MVK SDK.

    These are convenience constants. You can also use custom metric kinds.
    """

    # Token metrics
    PROMPT_TOKENS = "tokens.prompt"
    COMPLETION_TOKENS = "tokens.completion"
    EMBEDDING_TOKENS = "tokens.embedding"
    TOTAL_TOKENS = "tokens.total"

    # API metrics
    API_CALLS = "api.calls"

    # Image metrics
    IMAGES_GENERATED = "images.generated"
    IMAGES_PROCESSED = "images.processed"

    # Character metrics
    CHARACTERS_INPUT = "characters.input"
    CHARACTERS_OUTPUT = "characters.output"


def add_metered_usage(
    metric: str,
    value: float,
    uom: Optional[str] = None,
    model_name: Optional[str] = None,
    **metadata,
) -> None:
    """Add a metered usage metric to the current span.

    This is a convenience function that adds a single metric.
    For multiple metrics, call this function multiple times.

    Args:
        metric: Metric kind (e.g., Metric.PROMPT_TOKENS or "tokens.prompt")
        value: Numeric quantity
        uom: Unit of measure (defaults based on metric kind)
        model_name: Model name to include in metadata
        **metadata: Additional metadata

    Example:
        add_metered_usage(Metric.PROMPT_TOKENS, 150, model_name="gpt-4")
        add_metered_usage("api.calls", 1)
    """
    span = get_current_span()
    if not span:
        logger.warning("No active span to add metered usage to")
        return

    # Default UOM based on metric kind
    if uom is None:
        if "tokens" in metric:
            uom = "token"
        elif "api.calls" in metric:
            uom = "call"
        elif "images" in metric:
            uom = "image"
        elif "characters" in metric:
            uom = "character"
        else:
            uom = "unit"

    # Build metric dict
    metric_dict = {"metric_kind": metric, "uom": uom, "quantity": value}

    # Add metadata if provided
    if model_name or metadata:
        meta = {}
        if model_name:
            meta["model_name"] = model_name
        meta.update(metadata)
        metric_dict["metadata"] = meta

    # Get existing metered_usage or create new list
    if hasattr(span, "attributes") and "metered_usage" in span.attributes:
        try:
            # Parse existing metrics
            existing = json.loads(span.attributes["metered_usage"])
            if isinstance(existing, list):
                existing.append(metric_dict)
            else:
                existing = [metric_dict]
        except (json.JSONDecodeError, TypeError):
            existing = [metric_dict]
    else:
        existing = [metric_dict]

    # Set updated metrics
    if hasattr(span, "attributes"):
        span.attributes["metered_usage"] = json.dumps(existing)

    logger.debug(f"Added metered usage: {metric}={value} {uom}")
