"""Circuit breaker implementation for MVK SDK."""

import logging
import threading
import time
from enum import Enum
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """Circuit breaker states."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Failing, rejecting calls
    HALF_OPEN = "half_open"  # Testing if recovered


class CircuitBreaker:
    """Circuit breaker to prevent cascading failures."""

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: type[BaseException] = Exception,
    ):
        """Initialize circuit breaker.

        Args:
            name: Name for logging
            failure_threshold: Number of failures before opening circuit
            recovery_timeout: Seconds to wait before trying half-open
            expected_exception: Exception type to catch
        """
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception

        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: Optional[float] = None
        self._lock = threading.Lock()

        # Callbacks
        self._on_open: Optional[Callable[[], None]] = None
        self._on_close: Optional[Callable[[], None]] = None

    @property
    def state(self) -> CircuitState:
        """Get current circuit state."""
        with self._lock:
            # Check if we should transition from OPEN to HALF_OPEN
            if (
                self._state == CircuitState.OPEN
                and self._last_failure_time
                and time.time() - self._last_failure_time >= self.recovery_timeout
            ):
                self._state = CircuitState.HALF_OPEN
                logger.info(f"Circuit breaker '{self.name}' transitioning to HALF_OPEN")

            return self._state

    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Call function through circuit breaker.

        Args:
            func: Function to call
            *args: Function arguments
            **kwargs: Function keyword arguments

        Returns:
            Function result

        Raises:
            Exception: If circuit is open or function fails
        """
        if self.state == CircuitState.OPEN:
            raise Exception(f"Circuit breaker '{self.name}' is OPEN")

        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result

        except self.expected_exception as e:
            self._on_failure()
            raise

    def _on_success(self) -> None:
        """Handle successful call."""
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                # Recovered!
                self._state = CircuitState.CLOSED
                self._failure_count = 0
                logger.info(f"Circuit breaker '{self.name}' recovered, now CLOSED")

                if self._on_close:
                    self._on_close()

    def _on_failure(self) -> None:
        """Handle failed call."""
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()

            if self._state == CircuitState.HALF_OPEN:
                # Still failing, go back to OPEN
                self._state = CircuitState.OPEN
                logger.warning(f"Circuit breaker '{self.name}' still failing, back to OPEN")

            elif (
                self._state == CircuitState.CLOSED and self._failure_count >= self.failure_threshold
            ):
                # Too many failures, open circuit
                self._state = CircuitState.OPEN
                logger.error(
                    f"Circuit breaker '{self.name}' opened after " f"{self._failure_count} failures"
                )

                if self._on_open:
                    self._on_open()

    def reset(self) -> None:
        """Manually reset circuit breaker."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._last_failure_time = None
            logger.info(f"Circuit breaker '{self.name}' manually reset")

    def set_callbacks(
        self,
        on_open: Optional[Callable[[], None]] = None,
        on_close: Optional[Callable[[], None]] = None,
    ) -> None:
        """Set callback functions for state changes."""
        self._on_open = on_open
        self._on_close = on_close


class MemoryCircuitBreaker(CircuitBreaker):
    """Circuit breaker specifically for memory pressure."""

    def __init__(self, memory_threshold_mb: int = 500, check_interval: int = 5):
        """Initialize memory circuit breaker.

        Args:
            memory_threshold_mb: Memory usage threshold in MB
            check_interval: How often to check memory (seconds)
        """
        super().__init__(name="memory", failure_threshold=3, recovery_timeout=30)

        self.memory_threshold_bytes = memory_threshold_mb * 1024 * 1024
        self.check_interval = check_interval
        self._last_check: float = 0.0

    def check_memory(self) -> bool:
        """Check if memory usage is within limits.

        Returns:
            True if memory is OK, False if over threshold
        """
        # Only check at intervals
        now = time.time()
        if now - self._last_check < self.check_interval:
            return self.state != CircuitState.OPEN

        self._last_check = now

        try:
            import psutil

            process = psutil.Process()
            memory_usage = process.memory_info().rss

            if memory_usage > self.memory_threshold_bytes:
                logger.warning(
                    f"Memory usage {memory_usage / 1024 / 1024:.1f}MB exceeds "
                    f"threshold {self.memory_threshold_bytes / 1024 / 1024:.1f}MB"
                )
                self._on_failure()
                return False
            else:
                self._on_success()
                return True

        except ImportError:
            # psutil not available, assume OK
            return True
        except Exception as e:
            logger.error(f"Error checking memory: {e}")
            return True  # Don't break on monitoring errors


# Global circuit breakers
_export_circuit = CircuitBreaker(name="export", failure_threshold=10, recovery_timeout=60)

_memory_circuit = MemoryCircuitBreaker(memory_threshold_mb=500, check_interval=5)


def get_export_circuit() -> CircuitBreaker:
    """Get the export circuit breaker."""
    return _export_circuit


def get_memory_circuit() -> MemoryCircuitBreaker:
    """Get the memory circuit breaker."""
    return _memory_circuit


def check_circuit_breakers() -> bool:
    """Check all circuit breakers.

    Returns:
        True if all circuits are OK, False if any are open
    """
    # Check memory
    if not _memory_circuit.check_memory():
        return False

    # Check export
    if _export_circuit.state == CircuitState.OPEN:
        return False

    return True
