"""Console exporter for MVK SDK v4.0."""

import json
import logging
import sys
import threading
from typing import Any, Dict, List, Optional

from .base import SpanExporter

logger = logging.getLogger(__name__)


class ConsoleExporter(SpanExporter):
    """Export spans to console (stdout/stderr).

    Useful for debugging and development. No retry logic needed
    as console output should always succeed.

    Thread Safety: Uses lock to synchronize console output.
    """

    def __init__(self, output: str = "stdout", format: str = "json", pretty: bool = False):
        """Initialize console exporter.

        Args:
            output: Output stream ("stdout" or "stderr")
            format: Output format ("json" or "simple")
            pretty: Pretty print JSON if True
        """
        self.stream = sys.stdout if output == "stdout" else sys.stderr
        self.format = format
        self.pretty = pretty
        self._lock = threading.Lock()

        # Statistics
        self.stats = {"batches_exported": 0, "spans_exported": 0}

    def export(self, spans: List[Dict[str, Any]]) -> bool:
        """Export spans to console.

        Args:
            spans: List of span dictionaries

        Returns:
            Always True (console output doesn't fail)
        """
        if not spans:
            return True

        try:
            with self._lock:
                if self.format == "json":
                    self._export_json(spans)
                else:
                    self._export_simple(spans)

                self.stats["batches_exported"] += 1
                self.stats["spans_exported"] += len(spans)

            return True

        except Exception as e:
            logger.error(f"Failed to export to console: {e}")
            return False

    def _export_json(self, spans: List[Dict[str, Any]]) -> None:
        """Export spans as JSON."""
        for span in spans:
            if self.pretty:
                self.stream.write(json.dumps(span, indent=2))
                self.stream.write("\n")
            else:
                self.stream.write(json.dumps(span))
                self.stream.write("\n")
        self.stream.flush()

    def _export_simple(self, spans: List[Dict[str, Any]]) -> None:
        """Export spans in simple human-readable format."""
        for span in spans:
            # Format: [timestamp] KIND name (duration_ms)
            timestamp = span.get("start_time", 0)
            mvk_kind = span.get("mvk.span.kind", "UNKNOWN")
            name = span.get("name", "unnamed")
            duration = span.get("duration_ms", 0)

            self.stream.write(f"[{timestamp:.3f}] {mvk_kind:12} {name:40} ({duration:.1f}ms)")

            # Add key attributes
            if mvk_kind == "LLM":
                model = span.get("model_name", "")
                tokens = span.get("total_tokens", 0)
                if model or tokens:
                    self.stream.write(f" | model={model} tokens={tokens}")
            elif mvk_kind == "EMBEDDING":
                count = span.get("embeddings_count", 0)
                dims = span.get("embedding_dims", 0)
                if count or dims:
                    self.stream.write(f" | count={count} dims={dims}")
            elif mvk_kind == "RETRIEVER":
                matches = span.get("vectordb_match_count", 0)
                if matches:
                    self.stream.write(f" | matches={matches}")

            # Add error if present
            if span.get("status_code") == 2:  # ERROR
                msg = span.get("status_message", "Error")
                self.stream.write(f" | ERROR: {msg}")

            self.stream.write("\n")
        self.stream.flush()

    def shutdown(self) -> None:
        """Shutdown exporter and log stats."""
        logger.info(
            f"ConsoleExporter shutting down - "
            f"exported {self.stats['spans_exported']} spans "
            f"in {self.stats['batches_exported']} batches"
        )
