"""HTTP exporter for MVK SDK v5.0 with full OTLP/HTTP JSON compliance."""

import gzip
import json
import logging
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from .retrying import RetryingExporter

logger = logging.getLogger(__name__)


class HTTPExporter(RetryingExporter):
    """HTTP exporter that sends spans to MVK collector.

    Features:
    - Built-in retry with exponential backoff
    - Gzip compression
    - Connection pooling via urllib
    - Configurable timeouts
    - Fallback endpoint support
    """

    def __init__(
        self,
        endpoint: str,
        api_key: str,
        fallback_endpoint: Optional[str] = None,
        timeout_secs: int = 30,
        max_batch_size: int = 1000,
        compress: bool = True,
        resource_attributes: Optional[Dict[str, Any]] = None,
        # Retry configuration (v5.0 names)
        max_retry_hours: float = 4.0,
        initial_interval_secs: float = 1.0,
        max_interval_secs: int = 300,
        max_fast_retries: int = 10,
        # Backward compatibility
        initial_retry_interval_secs: Optional[float] = None,
        max_retry_interval_secs: Optional[int] = None,
    ):
        """Initialize HTTP exporter with v5.0 configuration.

        Args:
            endpoint: Primary endpoint URL
            api_key: API key for authentication
            fallback_endpoint: Fallback endpoint if primary fails
            timeout_secs: Request timeout in seconds
            max_batch_size: Maximum spans per batch
            compress: Whether to use gzip compression
            resource_attributes: Resource attributes for OTLP (service.*, etc)
            max_retry_hours: Maximum time to spend retrying
            initial_interval_secs: Initial retry delay (v5.0 name)
            max_interval_secs: Maximum delay between retries (v5.0 name)
            max_fast_retries: Number of fast retries
            initial_retry_interval_secs: Deprecated, use initial_interval_secs
            max_retry_interval_secs: Deprecated, use max_interval_secs
        """
        # Handle backward compatibility
        if initial_retry_interval_secs is not None:
            initial_interval_secs = initial_retry_interval_secs
        if max_retry_interval_secs is not None:
            max_interval_secs = max_retry_interval_secs

        # Initialize retry logic
        super().__init__(
            max_retry_hours=max_retry_hours,
            initial_interval_secs=initial_interval_secs,
            max_interval_secs=max_interval_secs,
            max_fast_retries=max_fast_retries,
        )
        self.endpoint = endpoint.rstrip("/")
        self.fallback_endpoint = fallback_endpoint.rstrip("/") if fallback_endpoint else None
        self.api_key = api_key
        self.timeout = timeout_secs
        self.max_batch_size = max_batch_size
        self.compress = compress
        self.resource_attributes = resource_attributes or {}

        # Validate endpoints
        self._validate_endpoint(self.endpoint)
        if self.fallback_endpoint:
            self._validate_endpoint(self.fallback_endpoint)

        # Additional stats for compression
        self.stats["compression_ratio"] = 0.0
        self.stats["fallback_used"] = 0

    def _validate_endpoint(self, endpoint: str) -> None:
        """Validate endpoint URL."""
        parsed = urlparse(endpoint)
        if not parsed.scheme or not parsed.netloc:
            raise ValueError(f"Invalid endpoint URL: {endpoint}")
        if parsed.scheme not in ("http", "https"):
            raise ValueError(f"Endpoint must use http or https: {endpoint}")

    def _do_export(self, spans: List[Dict[str, Any]]) -> Tuple[bool, Optional[int]]:
        """Perform the actual export operation.

        Args:
            spans: List of span dictionaries

        Returns:
            Tuple of (success, http_status_code)
        """
        # Limit batch size
        if len(spans) > self.max_batch_size:
            logger.warning(
                f"Batch size {len(spans)} exceeds max {self.max_batch_size}, " f"truncating"
            )
            spans = spans[: self.max_batch_size]

        # Convert spans to OTLP format and group by scope
        otlp_spans = self._convert_to_otlp(spans)

        # Group spans by scope (mvk.span.kind)
        spans_by_scope: Dict[str, List[Dict[str, Any]]] = {}
        for otlp_span in otlp_spans:
            # Extract mvk.span.kind from attributes to use as scope
            scope_name = "mvk-sdk"  # default
            for attr in otlp_span.get("attributes", []):
                if attr.get("key") == "mvk.span.kind":
                    scope_name = attr.get("value", {}).get("stringValue", "mvk-sdk")
                    break

            if scope_name not in spans_by_scope:
                spans_by_scope[scope_name] = []
            spans_by_scope[scope_name].append(otlp_span)

        # Build scopeSpans array
        scope_spans = []
        for scope_name, scope_spans_list in spans_by_scope.items():
            scope_spans.append(
                {"scope": {"name": scope_name, "version": "5.0.0"}, "spans": scope_spans_list}
            )

        # Prepare OTLP-compliant payload
        payload = {
            "resourceSpans": [
                {
                    "resource": {"attributes": self._get_resource_attributes()},
                    "scopeSpans": scope_spans,
                }
            ]
        }

        # Try primary endpoint
        success, status = self._send_batch(self.endpoint, payload)
        if success:
            return True, status

        # Try fallback endpoint if configured
        if self.fallback_endpoint and status != 401:  # Don't retry auth errors
            logger.info(f"Primary endpoint failed with status {status}, trying fallback")
            success, status = self._send_batch(self.fallback_endpoint, payload)
            if success:
                self.stats["fallback_used"] += 1
                return True, status

        return False, status

    def _send_batch(self, endpoint: str, payload: Dict[str, Any]) -> Tuple[bool, Optional[int]]:
        """Send a batch to specific endpoint.

        Args:
            endpoint: Target endpoint
            payload: Data to send

        Returns:
            Tuple of (success, http_status_code)
        """
        try:
            # Serialize payload
            data = json.dumps(payload).encode("utf-8")
            original_size = len(data)

            # Compress if enabled
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "X-MVK-SDK-Version": "5.0.0",
            }

            if self.compress:
                data = gzip.compress(data)
                headers["Content-Encoding"] = "gzip"

                # Update compression stats
                if original_size > 0:
                    ratio = 1.0 - (len(data) / original_size)
                    self.stats["compression_ratio"] = (
                        0.9 * self.stats["compression_ratio"] + 0.1 * ratio
                    )

            # Create request
            url = f"{endpoint}/v1/spans"
            req = Request(url, data=data, headers=headers, method="POST")

            # Send request
            with urlopen(req, timeout=self.timeout) as response:
                status = response.getcode()
                if 200 <= status < 300:
                    # Count spans in OTLP format
                    spans_count = 0
                    if "resourceSpans" in payload:
                        for rs in payload["resourceSpans"]:
                            for ss in rs.get("scopeSpans", []):
                                spans_count += len(ss.get("spans", []))
                    logger.debug(f"Successfully exported {spans_count} spans")
                    return True, status
                else:
                    logger.warning(f"Export failed with status {status}")
                    return False, status

        except HTTPError as e:
            logger.error(f"HTTP error exporting to {endpoint}: {e.code} - {e.reason}")
            return False, e.code

        except URLError as e:
            logger.error(f"URL error exporting to {endpoint}: {e.reason}")
            return False, None

        except Exception as e:
            logger.error(f"Unexpected error exporting to {endpoint}: {e}", exc_info=True)
            return False, None

    def _convert_to_otlp(self, spans: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Convert spans to OTLP format if needed.

        Args:
            spans: List of span dictionaries

        Returns:
            List of OTLP-compliant span dictionaries
        """
        otlp_spans = []
        for span in spans:
            # Check if span already has OTLP fields
            if "start_time_unix_nano" in span:
                # Already OTLP format
                otlp_spans.append(span)
            else:
                # Convert to OTLP format
                otlp_span = self._to_otlp_span(span)
                otlp_spans.append(otlp_span)
        return otlp_spans

    def _to_otlp_span(self, span: Dict[str, Any]) -> Dict[str, Any]:
        """Convert a single span to proper OTLP/HTTP JSON format.

        Args:
            span: Span dictionary in internal format

        Returns:
            OTLP/HTTP JSON compliant span dictionary with camelCase
        """
        # Convert timestamps to nanoseconds as strings (64-bit int in JSON)
        start_ns = str(int(span.get("start_time", 0) * 1_000_000_000))
        end_ns = str(int(span.get("end_time", span.get("start_time", 0)) * 1_000_000_000))

        # Map status
        status_code = "STATUS_CODE_UNSET"
        if "status" in span:
            if span["status"] == "ok":
                status_code = "STATUS_CODE_OK"
            elif span["status"] == "error":
                status_code = "STATUS_CODE_ERROR"
        elif "status_code" in span:
            # Already has OTLP status code
            status_code = span["status_code"]

        # Build OTLP span with camelCase fields
        otlp_span = {
            "traceId": span.get("trace_id", "").replace("-", ""),  # Remove hyphens
            "spanId": span.get("span_id", "").replace("-", "")[:16],  # 16 hex chars
            "name": span.get("name", "unknown"),
            "kind": "SPAN_KIND_INTERNAL",  # Default, will be overridden
            "startTimeUnixNano": start_ns,
            "endTimeUnixNano": end_ns,
            "status": {"code": status_code},
            "attributes": [],  # List of key-value objects
            "events": [],
            "links": [],
        }

        # Only add parentSpanId if it exists (omit for root spans)
        parent_id = span.get("parent_span_id") or span.get("parent_id")
        if parent_id:
            otlp_span["parentSpanId"] = parent_id

        # Only add status message if present
        status_msg = span.get("status_message", "")
        if status_msg:
            otlp_span["status"]["message"] = status_msg

        # Convert attributes to typed key-value pairs
        attributes_list = []

        for key, value in span.items():
            # Skip fields already handled
            if key in [
                "trace_id",
                "span_id",
                "parent_id",
                "parent_span_id",
                "name",
                "start_time",
                "end_time",
                "status",
                "status_code",
                "status_message",
                "events",
                "links",
                "attributes",
            ]:
                continue

            # Handle attributes if present
            if key == "attributes" and isinstance(value, dict):
                for attr_key, attr_value in value.items():
                    typed_attr = self._create_typed_attribute(attr_key, attr_value)
                    if typed_attr:
                        attributes_list.append(typed_attr)
                continue

            # Add to attributes with proper namespacing
            if key.startswith(("mvk.", "tags.", "http.", "db.")):
                # Already namespaced (skip service.* - goes to resource)
                if not key.startswith("service."):
                    typed_attr = self._create_typed_attribute(key, value)
                    if typed_attr:
                        attributes_list.append(typed_attr)
            elif key == "tags" and isinstance(value, dict):
                # Flatten tags with mvk.tags prefix for consistency
                for tag_key, tag_value in value.items():
                    typed_attr = self._create_typed_attribute(f"mvk.tags.{tag_key}", tag_value)
                    if typed_attr:
                        attributes_list.append(typed_attr)
            elif key in ["kind", "mvk_kind", "mvk.span.kind"]:
                # Store MVK span kind
                typed_attr = self._create_typed_attribute("mvk.span.kind", str(value))
                if typed_attr:
                    attributes_list.append(typed_attr)
                # Map to OTLP SpanKind
                if str(value) in ["LLM", "EMBEDDING", "RETRIEVER"]:
                    otlp_span["kind"] = "SPAN_KIND_CLIENT"
                elif str(value) in ["TOOL", "MEMORY", "AGENT_CALL"]:
                    otlp_span["kind"] = "SPAN_KIND_INTERNAL"
            else:
                # Add mvk prefix to custom fields
                typed_attr = self._create_typed_attribute(f"mvk.{key}", value)
                if typed_attr:
                    attributes_list.append(typed_attr)

        otlp_span["attributes"] = attributes_list

        # Handle events if present
        if "events" in span and isinstance(span["events"], list):
            for event in span["events"]:
                otlp_event = {
                    "timeUnixNano": str(int(event.get("timestamp", 0) * 1_000_000_000)),
                    "name": event.get("name", "unknown"),
                    "attributes": [],
                }
                # Convert event attributes to typed format
                if "attributes" in event and isinstance(event["attributes"], dict):
                    for key, value in event["attributes"].items():
                        typed_attr = self._create_typed_attribute(key, value)
                        if typed_attr:
                            otlp_event["attributes"].append(typed_attr)
                otlp_span["events"].append(otlp_event)

        return otlp_span

    def _create_typed_attribute(self, key: str, value: Any) -> Optional[Dict[str, Any]]:
        """Create a typed attribute for OTLP format.

        Args:
            key: Attribute key
            value: Attribute value

        Returns:
            Dict with key and typed value, or None if value is None
        """
        if value is None:
            return None

        typed_attr: Dict[str, Any] = {"key": key}

        # Determine type and set value
        if isinstance(value, bool):
            typed_attr["value"] = {"boolValue": value}
        elif isinstance(value, int):
            # Use intValue for regular ints, stringValue for large ones
            if -(2**63) <= value < 2**63:
                typed_attr["value"] = {"intValue": str(value)}  # Still string for JSON
            else:
                typed_attr["value"] = {"stringValue": str(value)}
        elif isinstance(value, float):
            typed_attr["value"] = {"doubleValue": value}
        elif isinstance(value, str):
            typed_attr["value"] = {"stringValue": value}
        elif isinstance(value, (list, tuple)):
            # Array value
            typed_attr["value"] = {
                "arrayValue": {"values": [self._create_typed_value(v) for v in value]}
            }
        elif isinstance(value, dict):
            # Convert dict to string for now (could be kvlistValue)
            typed_attr["value"] = {"stringValue": json.dumps(value)}
        else:
            # Default to string representation
            typed_attr["value"] = {"stringValue": str(value)}

        return typed_attr

    def _create_typed_value(self, value: Any) -> Dict[str, Any]:
        """Create a typed value for array elements."""
        if isinstance(value, bool):
            return {"boolValue": value}
        elif isinstance(value, int):
            return {"intValue": str(value)}
        elif isinstance(value, float):
            return {"doubleValue": value}
        else:
            return {"stringValue": str(value)}

    def _get_resource_attributes(self) -> List[Dict[str, Any]]:
        """Get resource attributes for OTLP export.

        Returns:
            List of typed attribute key-value pairs
        """
        attributes = []

        # Add resource attributes (service.*, mvk.tags.*, etc)
        for key, value in self.resource_attributes.items():
            # Service attributes and mvk.tags go to resource
            if key.startswith(("service.", "mvk.tags.")):
                typed_attr = self._create_typed_attribute(key, value)
                if typed_attr:
                    attributes.append(typed_attr)

        # Add SDK info
        attributes.append({"key": "sdk.name", "value": {"stringValue": "mvk-sdk"}})
        attributes.append({"key": "sdk.version", "value": {"stringValue": "5.0.0"}})

        # Ensure service.name exists
        if not any(attr["key"] == "service.name" for attr in attributes):
            attributes.append({"key": "service.name", "value": {"stringValue": "unknown"}})

        return attributes

    def shutdown(self) -> None:
        """Shutdown exporter and log final stats."""
        super().shutdown()
        logger.info(
            f"HTTPExporter (OTLP) additional stats - "
            f"compression ratio: {self.stats['compression_ratio']:.2%}, "
            f"fallback used: {self.stats['fallback_used']} times"
        )
