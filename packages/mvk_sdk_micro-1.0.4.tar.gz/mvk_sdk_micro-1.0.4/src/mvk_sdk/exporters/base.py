"""Base exporter interface for MVK SDK v4.0."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class SpanExporter(ABC):
    """Base interface for all span exporters.

    All exporters must implement this interface to work with
    the processor architecture. Exporters should be thread-safe.

    Note: Exporters handle their own retry logic with exponential
    backoff. This allows each exporter to implement retry strategies
    appropriate for their transport mechanism.
    """

    @abstractmethod
    def export(self, spans: List[Dict[str, Any]]) -> bool:
        """Export a batch of spans.

        This method must be thread-safe as it may be called
        from multiple processor threads.

        This method should handle retries internally with
        exponential backoff for transient failures.

        Args:
            spans: List of span dictionaries to export

        Returns:
            True if export eventually succeeded (after retries if needed),
            False if export failed permanently
        """
        pass

    @abstractmethod
    def shutdown(self) -> None:
        """Shutdown the exporter and release resources.

        This method must be thread-safe and idempotent.
        Multiple calls should be safe.

        This method should:
        - Flush any pending data
        - Close connections
        - Log final statistics
        """
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush any pending data.

        Args:
            timeout_millis: Maximum time to wait in milliseconds

        Returns:
            True if flush completed within timeout
        """
        # Default implementation - subclasses can override
        return True
