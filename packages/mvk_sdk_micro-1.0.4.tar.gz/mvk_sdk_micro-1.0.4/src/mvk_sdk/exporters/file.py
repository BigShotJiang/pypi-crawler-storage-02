"""File exporter for MVK SDK v4.0."""

import json
import logging
import os
import threading
from io import TextIOWrapper
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import SpanExporter

logger = logging.getLogger(__name__)


class FileExporter(SpanExporter):
    """Export spans to rotating log files.

    Writes spans in JSON Lines format (one JSON object per line).
    Supports automatic file rotation based on size.

    Thread Safety: Uses file locks for thread-safe writes.
    """

    def __init__(
        self,
        directory: str = "/tmp/mvk/spans",
        filename_prefix: str = "spans",
        max_file_size_mb: int = 100,
        max_files: int = 5,
        compress_rotated: bool = False,
    ):
        """Initialize file exporter.

        Args:
            directory: Directory to write span files
            filename_prefix: Prefix for span files
            max_file_size_mb: Max size per file before rotation
            max_files: Maximum number of files to keep
            compress_rotated: Whether to compress rotated files
        """
        self.directory = Path(directory)
        self.filename_prefix = filename_prefix
        self.max_file_size = max_file_size_mb * 1024 * 1024
        self.max_files = max_files
        self.compress_rotated = compress_rotated

        # Create directory if needed
        self.directory.mkdir(parents=True, exist_ok=True)

        # Current file
        self.current_file: Optional[TextIOWrapper] = None
        self.current_file_path: Optional[Path] = None
        self.current_file_size = 0
        self.file_index = 0

        # Thread safety
        self._lock = threading.Lock()

        # Statistics
        self.stats = {
            "batches_exported": 0,
            "spans_exported": 0,
            "files_rotated": 0,
            "bytes_written": 0,
        }

        # Open initial file
        self._open_new_file()

    def _open_new_file(self) -> None:
        """Open a new file for writing.

        Must be called with lock held.
        """
        # Close current file if open
        if self.current_file:
            self.current_file.close()
            logger.info(f"Closed file {self.current_file_path}")

        # Generate new filename
        self.current_file_path = (
            self.directory / f"{self.filename_prefix}.{self.file_index:05d}.jsonl"
        )

        # Open file
        self.current_file = open(self.current_file_path, "w", encoding="utf-8")
        self.current_file_size = 0
        logger.info(f"Opened new file {self.current_file_path}")

    def _rotate_if_needed(self) -> None:
        """Check if rotation is needed and rotate if so.

        Must be called with lock held.
        """
        if self.current_file_size >= self.max_file_size:
            # Close current file
            if self.current_file is not None:
                self.current_file.close()

            # Compress if requested
            if self.compress_rotated and self.current_file_path is not None:
                self._compress_file(self.current_file_path)

            # Increment file index
            self.file_index += 1
            self.stats["files_rotated"] += 1

            # Clean up old files if needed
            self._cleanup_old_files()

            # Open new file
            self._open_new_file()

    def _compress_file(self, filepath: Path) -> None:
        """Compress a file using gzip.

        Must be called with lock held.
        """
        try:
            import gzip

            compressed_path = filepath.with_suffix(".jsonl.gz")

            with open(filepath, "rb") as f_in:
                with gzip.open(compressed_path, "wb") as f_out:
                    f_out.write(f_in.read())

            # Remove original file
            filepath.unlink()
            logger.info(f"Compressed {filepath} to {compressed_path}")

        except Exception as e:
            logger.error(f"Failed to compress {filepath}: {e}")

    def _cleanup_old_files(self) -> None:
        """Remove old files if we exceed max_files.

        Must be called with lock held.
        """
        try:
            # List all span files
            pattern = f"{self.filename_prefix}.*.jsonl*"
            files = sorted(self.directory.glob(pattern))

            # Remove oldest files if needed (keep max_files - 1 since we're about to create a new one)
            while len(files) >= self.max_files:
                oldest = files.pop(0)
                oldest.unlink()
                logger.info(f"Removed old file {oldest}")

        except Exception as e:
            logger.error(f"Failed to cleanup old files: {e}")

    def export(self, spans: List[Dict[str, Any]]) -> bool:
        """Export spans to file.

        Args:
            spans: List of span dictionaries

        Returns:
            True if export succeeded, False otherwise
        """
        if not spans:
            return True

        try:
            with self._lock:
                for span in spans:
                    # Write as JSON line
                    line = json.dumps(span) + "\n"
                    line_bytes = line.encode("utf-8")

                    if self.current_file is not None:
                        self.current_file.write(line)
                        self.current_file_size += len(line_bytes)
                        self.stats["bytes_written"] += len(line_bytes)

                # Flush to ensure data is written
                if self.current_file is not None:
                    self.current_file.flush()

                # Update stats
                self.stats["batches_exported"] += 1
                self.stats["spans_exported"] += len(spans)

                # Check if rotation needed
                self._rotate_if_needed()

            return True

        except Exception as e:
            logger.error(f"Failed to export to file: {e}")
            return False

    def shutdown(self) -> None:
        """Shutdown exporter and close files."""
        with self._lock:
            if self.current_file:
                self.current_file.close()
                logger.info(f"Closed final file {self.current_file_path}")

        logger.info(
            f"FileExporter shutting down - "
            f"exported {self.stats['spans_exported']} spans "
            f"in {self.stats['batches_exported']} batches, "
            f"wrote {self.stats['bytes_written']} bytes, "
            f"rotated {self.stats['files_rotated']} files"
        )
