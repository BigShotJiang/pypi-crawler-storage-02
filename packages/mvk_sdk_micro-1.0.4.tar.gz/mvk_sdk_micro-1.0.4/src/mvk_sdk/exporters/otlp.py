"""OTLP exporter for MVK SDK v4.0."""

import gzip
import json
import logging
import threading
from typing import Any, Dict, List, Optional, Tuple

from .retrying import RetryingExporter

logger = logging.getLogger(__name__)


class OTLPExporter(RetryingExporter):
    """Export spans to OpenTelemetry Collector via OTLP.

    Supports both HTTP and gRPC protocols. Includes retry logic
    with exponential backoff for transient failures.

    Thread Safety: Thread-safe HTTP/gRPC clients.
    """

    def __init__(
        self,
        endpoint: str = "localhost:4317",
        protocol: str = "grpc",
        headers: Optional[Dict[str, str]] = None,
        insecure: bool = True,
        timeout_secs: int = 10,
        compression: str = "gzip",
        # Retry configuration
        max_retry_hours: float = 4.0,
        initial_retry_interval_secs: float = 1.0,
        max_retry_interval_secs: int = 300,
        max_fast_retries: int = 10,
    ):
        """Initialize OTLP exporter.

        Args:
            endpoint: Collector endpoint (host:port)
            protocol: Protocol to use ("grpc" or "http")
            headers: Additional headers to send
            insecure: Whether to use insecure connection
            timeout_secs: Request timeout in seconds
            compression: Compression type ("gzip" or "none")
            max_retry_hours: Maximum time to spend retrying
            initial_retry_interval_secs: Initial retry delay
            max_retry_interval_secs: Maximum delay between retries
            max_fast_retries: Number of fast retries
        """
        # Initialize retry logic
        super().__init__(
            max_retry_hours=max_retry_hours,
            initial_retry_interval_secs=initial_retry_interval_secs,
            max_retry_interval_secs=max_retry_interval_secs,
            max_fast_retries=max_fast_retries,
        )

        self.endpoint = endpoint
        self.protocol = protocol
        self.headers = headers or {}
        self.insecure = insecure
        self.timeout = timeout_secs
        self.compression = compression

        # Thread-safe clients
        self._lock = threading.Lock()
        self._grpc_channel = None
        self._http_session = None

    def _do_export(self, spans: List[Dict[str, Any]]) -> Tuple[bool, Optional[int]]:
        """Perform the actual export operation.

        Args:
            spans: List of span dictionaries

        Returns:
            Tuple of (success, status_code)
        """
        try:
            # Convert MVK spans to OTLP format
            otlp_spans = self._convert_to_otlp(spans)

            if self.protocol == "grpc":
                return self._export_grpc(otlp_spans)
            else:
                return self._export_http(otlp_spans)

        except Exception as e:
            logger.error(f"OTLP export failed: {e}")
            return False, None

    def _convert_to_otlp(self, spans: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Convert MVK spans to OTLP JSON format.

        Args:
            spans: List of MVK span dictionaries

        Returns:
            OTLP-formatted spans
        """
        resource_spans = []

        # Group spans by resource (agent_name)
        spans_by_resource: Dict[str, List[Dict[str, Any]]] = {}
        for span in spans:
            agent_name = span.get("mvk.agent.name", "unknown")
            if agent_name not in spans_by_resource:
                spans_by_resource[agent_name] = []
            spans_by_resource[agent_name].append(span)

        # Create ResourceSpans for each resource
        for agent_name, resource_spans_list in spans_by_resource.items():
            # Create resource
            resource = {
                "attributes": [
                    {"key": "service.name", "value": {"stringValue": agent_name}},
                    {"key": "sdk.name", "value": {"stringValue": "mvk-sdk"}},
                    {"key": "sdk.version", "value": {"stringValue": "4.0.0"}},
                ]
            }

            # Convert spans
            scope_spans = []
            for span in resource_spans_list:
                otlp_span = self._convert_span_to_otlp(span)
                scope_spans.append(otlp_span)

            resource_span = {
                "resource": resource,
                "scopeSpans": [
                    {"scope": {"name": "mvk-sdk", "version": "4.0.0"}, "spans": scope_spans}
                ],
            }
            resource_spans.append(resource_span)

        return {"resourceSpans": resource_spans}

    def _convert_span_to_otlp(self, span: Dict[str, Any]) -> Dict[str, Any]:
        """Convert a single MVK span to OTLP format.

        Args:
            span: MVK span dictionary

        Returns:
            OTLP-formatted span
        """
        # Convert timestamps to nanoseconds
        start_time_ns = int(span.get("start_time", 0) * 1e9)
        end_time_ns = int(span.get("end_time", 0) * 1e9)

        # Map OTEL SpanKind
        otel_kind = span.get("kind", 0)  # Default to INTERNAL

        # Build attributes
        attributes = []

        # Add MVK span kind as attribute
        if "mvk.span.kind" in span:
            attributes.append(
                {"key": "mvk.span.kind", "value": {"stringValue": span["mvk.span.kind"]}}
            )

        # Add other attributes
        skip_fields = {
            "trace_id",
            "span_id",
            "parent_span_id",
            "start_time",
            "end_time",
            "kind",
            "name",
            "status_code",
            "status_message",
            "mvk.span.kind",
        }

        for key, value in span.items():
            if key in skip_fields:
                continue

            # Convert value to OTLP attribute
            attr: Dict[str, Any] = {"key": key}
            if isinstance(value, str):
                attr["value"] = {"stringValue": value}
            elif isinstance(value, bool):
                attr["value"] = {"boolValue": value}
            elif isinstance(value, int):
                attr["value"] = {"intValue": value}
            elif isinstance(value, float):
                attr["value"] = {"doubleValue": value}
            elif isinstance(value, dict):
                # Convert dict to JSON string
                attr["value"] = {"stringValue": json.dumps(value)}
            else:
                # Convert to string
                attr["value"] = {"stringValue": str(value)}

            attributes.append(attr)

        # Build OTLP span
        otlp_span = {
            "traceId": span.get("trace_id", ""),
            "spanId": span.get("span_id", ""),
            "parentSpanId": span.get("parent_span_id", ""),
            "name": span.get("name", ""),
            "kind": otel_kind,
            "startTimeUnixNano": str(start_time_ns),
            "endTimeUnixNano": str(end_time_ns),
            "attributes": attributes,
        }

        # Add status if present
        status_code = span.get("status_code", 0)
        if status_code != 0:
            otlp_span["status"] = {"code": status_code, "message": span.get("status_message", "")}

        # Add events if present
        if "events" in span and isinstance(span["events"], list):
            otlp_events = []
            for event in span["events"]:
                otlp_event = {
                    "name": event.get("name", ""),
                    "timeUnixNano": str(int(event.get("timestamp", 0) * 1e9)),
                    "attributes": [],
                }
                if "attributes" in event:
                    for k, v in event["attributes"].items():
                        otlp_event["attributes"].append(
                            {"key": k, "value": {"stringValue": str(v)}}
                        )
                otlp_events.append(otlp_event)
            otlp_span["events"] = otlp_events

        return otlp_span

    def _export_http(self, otlp_data: Dict[str, Any]) -> Tuple[bool, Optional[int]]:
        """Export via OTLP/HTTP.

        Args:
            otlp_data: OTLP-formatted spans

        Returns:
            Tuple of (success, status_code)
        """
        try:
            import urllib.error
            import urllib.request

            # Prepare URL
            if self.insecure:
                url = f"http://{self.endpoint}/v1/traces"
            else:
                url = f"https://{self.endpoint}/v1/traces"

            # Serialize data
            data = json.dumps(otlp_data).encode("utf-8")

            # Prepare headers
            headers = {"Content-Type": "application/json", **self.headers}

            # Compress if needed
            if self.compression == "gzip":
                data = gzip.compress(data)
                headers["Content-Encoding"] = "gzip"

            # Create request
            req = urllib.request.Request(url, data=data, headers=headers, method="POST")

            # Send request
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    status = response.getcode()
                    if 200 <= status < 300:
                        logger.debug(f"OTLP export succeeded with status {status}")
                        return True, status
                    else:
                        logger.warning(f"OTLP export failed with status {status}")
                        return False, status

            except urllib.error.HTTPError as e:
                logger.error(f"OTLP HTTP error: {e.code} - {e.reason}")
                return False, e.code

            except urllib.error.URLError as e:
                logger.error(f"OTLP URL error: {e.reason}")
                return False, None

        except Exception as e:
            logger.error(f"OTLP export exception: {e}")
            return False, None

    def _export_grpc(self, otlp_data: Dict[str, Any]) -> Tuple[bool, Optional[int]]:
        """Export via OTLP/gRPC.

        Args:
            otlp_data: OTLP-formatted spans

        Returns:
            Tuple of (success, status_code)
        """
        # Note: gRPC requires additional dependencies (grpcio, protobuf)
        # This is a simplified implementation
        logger.warning("gRPC export not fully implemented in this version")
        return False, 501  # Not Implemented

    def shutdown(self) -> None:
        """Shutdown exporter and close connections."""
        with self._lock:
            if self._grpc_channel:
                try:
                    # Close gRPC channel if implemented
                    pass
                except:
                    pass

            if self._http_session:
                try:
                    # Close HTTP session if using one
                    pass
                except:
                    pass

        super().shutdown()
