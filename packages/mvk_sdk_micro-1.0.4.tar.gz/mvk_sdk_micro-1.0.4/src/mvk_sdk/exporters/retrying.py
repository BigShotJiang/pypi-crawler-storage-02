"""Base retrying exporter with exponential backoff for v5.0."""

import logging
import random
import time
from abc import abstractmethod
from typing import Any, Dict, List, Optional

from .base import SpanExporter

logger = logging.getLogger(__name__)


class RetryingExporter(SpanExporter):
    """Base exporter with built-in retry logic.

    This class provides exponential backoff retry logic that
    HTTP and OTLP exporters can use. Subclasses only need to
    implement _do_export() for the actual export logic.
    """

    def __init__(
        self,
        max_retry_hours: float = 4.0,
        initial_interval_secs: float = 1.0,  # v5.0 canonical name
        max_interval_secs: int = 300,  # v5.0 canonical name
        max_fast_retries: int = 10,
        backoff_multiplier: float = 2.0,
        jitter_percent: float = 0.1,
        # Backward compatibility aliases
        initial_retry_interval_secs: Optional[float] = None,
        max_retry_interval_secs: Optional[int] = None,
    ):
        """Initialize retrying exporter with v5.0 configuration.

        Args:
            max_retry_hours: Maximum time to spend retrying
            initial_interval_secs: Initial retry delay (v5.0 name)
            max_interval_secs: Maximum delay between retries (v5.0 name)
            max_fast_retries: Number of fast retries before long-term
            backoff_multiplier: Exponential backoff multiplier
            jitter_percent: Jitter percentage (0.1 = ±10%)
            initial_retry_interval_secs: Deprecated, use initial_interval_secs
            max_retry_interval_secs: Deprecated, use max_interval_secs
        """
        # Handle backward compatibility
        if initial_retry_interval_secs is not None:
            initial_interval_secs = initial_retry_interval_secs
        if max_retry_interval_secs is not None:
            max_interval_secs = max_retry_interval_secs

        self.max_retry_seconds = max_retry_hours * 3600
        self.initial_retry_interval = initial_interval_secs
        self.max_retry_interval = max_interval_secs
        self.max_fast_retries = max_fast_retries
        self.backoff_multiplier = backoff_multiplier
        self.jitter_percent = jitter_percent

        # Statistics
        self.stats: Dict[str, Any] = {
            "batches_sent": 0,
            "spans_sent": 0,
            "batches_failed": 0,
            "spans_failed": 0,
            "retries": 0,
            "total_retry_time_ms": 0,
        }

    @abstractmethod
    def _do_export(self, spans: List[Dict[str, Any]]) -> tuple[bool, Optional[int]]:
        """Perform the actual export.

        Subclasses must implement this method to perform the actual
        export operation without retry logic.

        Args:
            spans: List of span dictionaries to export

        Returns:
            Tuple of (success, http_status_code)
            - success: True if export succeeded, False otherwise
            - http_status_code: Optional HTTP status code for debugging
        """
        pass

    def export(self, spans: List[Dict[str, Any]]) -> bool:
        """Export spans with retry logic.

        Args:
            spans: List of span dictionaries to export

        Returns:
            True if export succeeded (after retries if needed),
            False if all retries exhausted
        """
        if not spans:
            return True

        start_time = time.time()
        retry_count = 0

        while True:
            # Calculate elapsed time
            elapsed = time.time() - start_time
            if elapsed > self.max_retry_seconds:
                logger.error(
                    f"Exceeded max retry duration of {self.max_retry_seconds}s, "
                    f"dropping {len(spans)} spans after {retry_count} retries"
                )
                self.stats["batches_failed"] += 1
                self.stats["spans_failed"] += len(spans)
                return False

            # Try to export
            try:
                success, status_code = self._do_export(spans)

                if success:
                    # Export succeeded
                    self.stats["batches_sent"] += 1
                    self.stats["spans_sent"] += len(spans)
                    if retry_count > 0:
                        logger.info(f"Export succeeded after {retry_count} retries")
                    return True

                # Check if we should retry based on status code
                if status_code is not None:
                    if status_code >= 400 and status_code < 500 and status_code != 429:
                        # Client error (except rate limiting) - don't retry
                        logger.error(f"Permanent export failure with status {status_code}")
                        self.stats["batches_failed"] += 1
                        self.stats["spans_failed"] += len(spans)
                        return False

            except Exception as e:
                logger.error(f"Export exception: {e}", exc_info=True)

            # Export failed, calculate backoff
            retry_count += 1
            self.stats["retries"] += 1

            # Calculate backoff delay
            if retry_count <= self.max_fast_retries:
                # Fast retries with exponential backoff
                base_delay = self.initial_retry_interval * (
                    self.backoff_multiplier ** (retry_count - 1)
                )
            else:
                # Long-term retries with capped interval
                base_delay = min(
                    self.initial_retry_interval * (self.backoff_multiplier**10),
                    self.max_retry_interval,
                )

            # Add jitter to prevent thundering herd
            jitter = base_delay * self.jitter_percent * (2 * random.random() - 1)
            delay = base_delay + jitter

            # Check if we have time for another retry
            if elapsed + delay > self.max_retry_seconds:
                logger.error(
                    f"Not enough time for retry {retry_count + 1}, " f"dropping {len(spans)} spans"
                )
                self.stats["batches_failed"] += 1
                self.stats["spans_failed"] += len(spans)
                return False

            logger.warning(
                f"Export failed (attempt {retry_count}), "
                f"retrying in {delay:.1f}s. "
                f"Elapsed: {elapsed:.1f}s of {self.max_retry_seconds}s max"
            )

            self.stats["total_retry_time_ms"] += int(delay * 1000)
            time.sleep(delay)

    def get_stats(self) -> Dict[str, Any]:
        """Get exporter statistics."""
        return self.stats.copy()

    def shutdown(self) -> None:
        """Log final statistics on shutdown."""
        logger.info(
            f"Exporter stats - "
            f"batches sent: {self.stats['batches_sent']}, "
            f"spans sent: {self.stats['spans_sent']}, "
            f"batches failed: {self.stats['batches_failed']}, "
            f"spans failed: {self.stats['spans_failed']}, "
            f"retries: {self.stats['retries']}, "
            f"total retry time: {self.stats['total_retry_time_ms']}ms"
        )
