"""Pinecone wrapper for MVK SDK v3.0 auto-instrumentation."""

import logging
from typing import Any, Dict, List, Optional, Union

import wrapt

from ..schema import MVKSpanKind
from ..tracer import get_tracer

logger = logging.getLogger(__name__)


def wrap_index_upsert(wrapped, instance, args, kwargs):
    """Wrap Pinecone index upsert method."""
    tracer = get_tracer()

    # Extract index name
    index_name = getattr(instance, "name", "unknown")
    if hasattr(instance, "_index_name"):
        index_name = instance._index_name

    request_attrs = {"operation": "upsert", "db_system": "pinecone", "vectordb_index": index_name}

    # Count vectors being upserted
    vectors = kwargs.get("vectors", args[0] if args else [])
    if isinstance(vectors, list):
        request_attrs["vector_count"] = len(vectors)

    # Start span
    span = tracer.start_span("pinecone.index.upsert", kind=MVKSpanKind.TOOL, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)

        # Extract result metrics
        if result and hasattr(result, "upserted_count"):
            span.attributes["upserted_count"] = result.upserted_count

        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_index_query(wrapped, instance, args, kwargs):
    """Wrap Pinecone index query method."""
    tracer = get_tracer()

    # Extract index name
    index_name = getattr(instance, "name", "unknown")
    if hasattr(instance, "_index_name"):
        index_name = instance._index_name

    request_attrs = {"operation": "query", "db_system": "pinecone", "vectordb_index": index_name}

    # Extract query parameters
    top_k = kwargs.get("top_k", 10)
    request_attrs["vectordb_match_count"] = top_k

    # Check if vector or id provided
    if "vector" in kwargs or (args and isinstance(args[0], list)):
        request_attrs["query_type"] = "vector"
    elif "id" in kwargs:
        request_attrs["query_type"] = "id"

    # Start span
    span = tracer.start_span("pinecone.index.query", kind=MVKSpanKind.RETRIEVER, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)

        # Extract result metrics
        if result and hasattr(result, "matches"):
            span.attributes["result_count"] = len(result.matches)

        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_index_delete(wrapped, instance, args, kwargs):
    """Wrap Pinecone index delete method."""
    tracer = get_tracer()

    # Extract index name
    index_name = getattr(instance, "name", "unknown")
    if hasattr(instance, "_index_name"):
        index_name = instance._index_name

    request_attrs = {"operation": "delete", "db_system": "pinecone", "vectordb_index": index_name}

    # Count IDs being deleted
    if "ids" in kwargs and isinstance(kwargs["ids"], list):
        request_attrs["delete_count"] = len(kwargs["ids"])
    elif "delete_all" in kwargs and kwargs["delete_all"]:
        request_attrs["delete_all"] = True

    # Start span
    span = tracer.start_span("pinecone.index.delete", kind=MVKSpanKind.TOOL, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)
        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_index_fetch(wrapped, instance, args, kwargs):
    """Wrap Pinecone index fetch method."""
    tracer = get_tracer()

    # Extract index name
    index_name = getattr(instance, "name", "unknown")
    if hasattr(instance, "_index_name"):
        index_name = instance._index_name

    request_attrs = {"operation": "fetch", "db_system": "pinecone", "vectordb_index": index_name}

    # Count IDs being fetched
    ids = kwargs.get("ids", args[0] if args else [])
    if isinstance(ids, list):
        request_attrs["fetch_count"] = len(ids)

    # Start span
    span = tracer.start_span("pinecone.index.fetch", kind=MVKSpanKind.RETRIEVER, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)

        # Extract result metrics
        if result and hasattr(result, "vectors") and isinstance(result.vectors, dict):
            span.attributes["result_count"] = len(result.vectors)

        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_create_index(wrapped, instance, args, kwargs):
    """Wrap Pinecone create_index method."""
    tracer = get_tracer()

    # Extract index name
    index_name = kwargs.get("name", args[0] if args else "unknown")

    request_attrs = {
        "operation": "create_index",
        "db_system": "pinecone",
        "vectordb_index": index_name,
    }

    # Extract dimension if provided
    if "dimension" in kwargs:
        request_attrs["embedding_dims"] = kwargs["dimension"]

    # Start span
    span = tracer.start_span("pinecone.create_index", kind=MVKSpanKind.TOOL, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)
        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_pinecone_index(wrapped, instance, args, kwargs):
    """Wrap Pinecone.Index() method that returns an index instance."""
    # Call original method first
    index = wrapped(*args, **kwargs)

    # Wrap the index methods
    if index:
        _wrap_index_methods(index)

    return index


def _wrap_index_methods(index):
    """Wrap methods on a Pinecone index instance."""
    try:
        # Wrap upsert method
        if hasattr(index, "upsert"):
            wrapt.wrap_function_wrapper(index, "upsert", wrap_index_upsert)

        # Wrap query method
        if hasattr(index, "query"):
            wrapt.wrap_function_wrapper(index, "query", wrap_index_query)

        # Wrap delete method
        if hasattr(index, "delete"):
            wrapt.wrap_function_wrapper(index, "delete", wrap_index_delete)

        # Wrap fetch method
        if hasattr(index, "fetch"):
            wrapt.wrap_function_wrapper(index, "fetch", wrap_index_fetch)
    except Exception as e:
        logger.debug(f"Failed to wrap index methods: {e}")


def patch():
    """Apply Pinecone patches."""
    try:
        import pinecone

        # For Pinecone v2.x
        if hasattr(pinecone, "Pinecone"):
            # Patch create_index
            wrapt.wrap_function_wrapper(pinecone.Pinecone, "create_index", wrap_create_index)
            logger.info("Patched pinecone.Pinecone.create_index")

            # Patch Index method
            wrapt.wrap_function_wrapper(pinecone.Pinecone, "Index", wrap_pinecone_index)
            logger.info("Patched pinecone.Pinecone.Index")

        # For older Pinecone versions (v1.x)
        if hasattr(pinecone, "create_index"):
            wrapt.wrap_function_wrapper(pinecone, "create_index", wrap_create_index)
            logger.info("Patched pinecone.create_index")

        if hasattr(pinecone, "Index"):
            # For getting index directly
            original_index = pinecone.Index

            def patched_index(*args, **kwargs):
                index = original_index(*args, **kwargs)
                if index:
                    _wrap_index_methods(index)
                return index

            pinecone.Index = patched_index
            logger.info("Patched pinecone.Index")

    except Exception as e:
        logger.warning(f"Failed to patch Pinecone: {e}")
