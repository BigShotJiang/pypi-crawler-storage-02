"""HTTPX wrapper for MVK SDK v5.0 with W3C TraceContext support."""

import logging
from typing import Any, Dict, Optional, Union

import wrapt

from ..propagator import propagator
from ..schema import MVKSpanKind
from ..tracer import get_current_span, get_tracer

logger = logging.getLogger(__name__)


def wrap_httpx_client(httpx_module):
    """Wrap HTTPX client for auto-instrumentation."""
    tracer = get_tracer()

    # Wrap Client class
    if hasattr(httpx_module, "Client"):
        original_client = httpx_module.Client

        class InstrumentedClient(original_client):
            """Instrumented HTTPX Client."""

            def request(self, method: str, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped request method with traceparent injection."""
                with tracer.start_span(
                    name=f"httpx.{method.lower()}",
                    kind=MVKSpanKind.TOOL,
                    operation="http_call",
                    operation_subtype=method.upper(),
                    tool_name="httpx",
                    http_method=method.upper(),
                    http_url=str(url),
                ) as span:
                    try:
                        # v5.0: Inject traceparent header for W3C TraceContext
                        headers = kwargs.get("headers", {})
                        if headers is None:
                            headers = {}

                        # Get current span for trace context
                        current_span = get_current_span()
                        if current_span and hasattr(current_span, "trace_id"):
                            trace_id = str(current_span.trace_id) if current_span.trace_id else ""
                            span_id = str(current_span.span_id) if current_span.span_id else ""
                            if trace_id and span_id:
                                propagator.inject(trace_id, span_id, headers)
                                kwargs["headers"] = headers

                        response = super().request(method, url, **kwargs)
                        span.set_attribute("http_status_code", response.status_code)
                        return response
                    except Exception as e:
                        span.set_error(e)
                        raise

            def get(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped GET method."""
                return self.request("GET", url, **kwargs)

            def post(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped POST method."""
                return self.request("POST", url, **kwargs)

            def put(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped PUT method."""
                return self.request("PUT", url, **kwargs)

            def patch(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped PATCH method."""
                return self.request("PATCH", url, **kwargs)

            def delete(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped DELETE method."""
                return self.request("DELETE", url, **kwargs)

            def head(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped HEAD method."""
                return self.request("HEAD", url, **kwargs)

            def options(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped OPTIONS method."""
                return self.request("OPTIONS", url, **kwargs)

        httpx_module.Client = InstrumentedClient
        logger.info("HTTPX Client wrapped successfully")

    # Wrap AsyncClient class
    if hasattr(httpx_module, "AsyncClient"):
        original_async_client = httpx_module.AsyncClient

        class InstrumentedAsyncClient(original_async_client):
            """Instrumented HTTPX AsyncClient."""

            async def request(self, method: str, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async request method with traceparent injection."""
                with tracer.start_span(
                    name=f"httpx.async.{method.lower()}",
                    kind=MVKSpanKind.TOOL,
                    operation="http_call",
                    operation_subtype=method.upper(),
                    tool_name="httpx",
                    http_method=method.upper(),
                    http_url=str(url),
                ) as span:
                    try:
                        # v5.0: Inject traceparent header for W3C TraceContext
                        headers = kwargs.get("headers", {})
                        if headers is None:
                            headers = {}

                        # Get current span for trace context
                        current_span = get_current_span()
                        if current_span and hasattr(current_span, "trace_id"):
                            trace_id = str(current_span.trace_id) if current_span.trace_id else ""
                            span_id = str(current_span.span_id) if current_span.span_id else ""
                            if trace_id and span_id:
                                propagator.inject(trace_id, span_id, headers)
                                kwargs["headers"] = headers

                        response = await super().request(method, url, **kwargs)
                        span.set_attribute("http_status_code", response.status_code)
                        return response
                    except Exception as e:
                        span.set_error(e)
                        raise

            async def get(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async GET method."""
                return await self.request("GET", url, **kwargs)

            async def post(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async POST method."""
                return await self.request("POST", url, **kwargs)

            async def put(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async PUT method."""
                return await self.request("PUT", url, **kwargs)

            async def patch(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async PATCH method."""
                return await self.request("PATCH", url, **kwargs)

            async def delete(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async DELETE method."""
                return await self.request("DELETE", url, **kwargs)

            async def head(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async HEAD method."""
                return await self.request("HEAD", url, **kwargs)

            async def options(self, url: Union[str, Any], **kwargs) -> Any:
                """Wrapped async OPTIONS method."""
                return await self.request("OPTIONS", url, **kwargs)

        httpx_module.AsyncClient = InstrumentedAsyncClient
        logger.info("HTTPX AsyncClient wrapped successfully")

    # Wrap top-level convenience functions
    _wrap_convenience_functions(httpx_module)


def _wrap_convenience_functions(httpx_module):
    """Wrap HTTPX convenience functions."""
    tracer = get_tracer()

    # Wrap httpx.request
    if hasattr(httpx_module, "request"):
        original_request = httpx_module.request

        def wrapped_request(method: str, url: Union[str, Any], **kwargs) -> Any:
            """Wrapped request function."""
            with tracer.start_span(
                name=f"httpx.{method.lower()}",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype=method.upper(),
                tool_name="httpx",
                http_method=method.upper(),
                http_url=str(url),
            ) as span:
                try:
                    response = original_request(method, url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.request = wrapped_request

    # Wrap httpx.get
    if hasattr(httpx_module, "get"):
        original_get = httpx_module.get

        def wrapped_get(url: Union[str, Any], **kwargs) -> Any:
            """Wrapped GET function."""
            with tracer.start_span(
                name="httpx.get",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype="GET",
                tool_name="httpx",
                http_method="GET",
                http_url=str(url),
            ) as span:
                try:
                    response = original_get(url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.get = wrapped_get

    # Wrap httpx.post
    if hasattr(httpx_module, "post"):
        original_post = httpx_module.post

        def wrapped_post(url: Union[str, Any], **kwargs) -> Any:
            """Wrapped POST function."""
            with tracer.start_span(
                name="httpx.post",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype="POST",
                tool_name="httpx",
                http_method="POST",
                http_url=str(url),
            ) as span:
                try:
                    response = original_post(url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.post = wrapped_post

    # Wrap httpx.put
    if hasattr(httpx_module, "put"):
        original_put = httpx_module.put

        def wrapped_put(url: Union[str, Any], **kwargs) -> Any:
            """Wrapped PUT function."""
            with tracer.start_span(
                name="httpx.put",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype="PUT",
                tool_name="httpx",
                http_method="PUT",
                http_url=str(url),
            ) as span:
                try:
                    response = original_put(url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.put = wrapped_put

    # Wrap httpx.patch
    if hasattr(httpx_module, "patch"):
        original_patch = httpx_module.patch

        def wrapped_patch(url: Union[str, Any], **kwargs) -> Any:
            """Wrapped PATCH function."""
            with tracer.start_span(
                name="httpx.patch",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype="PATCH",
                tool_name="httpx",
                http_method="PATCH",
                http_url=str(url),
            ) as span:
                try:
                    response = original_patch(url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.patch = wrapped_patch

    # Wrap httpx.delete
    if hasattr(httpx_module, "delete"):
        original_delete = httpx_module.delete

        def wrapped_delete(url: Union[str, Any], **kwargs) -> Any:
            """Wrapped DELETE function."""
            with tracer.start_span(
                name="httpx.delete",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype="DELETE",
                tool_name="httpx",
                http_method="DELETE",
                http_url=str(url),
            ) as span:
                try:
                    response = original_delete(url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.delete = wrapped_delete

    # Wrap httpx.head
    if hasattr(httpx_module, "head"):
        original_head = httpx_module.head

        def wrapped_head(url: Union[str, Any], **kwargs) -> Any:
            """Wrapped HEAD function."""
            with tracer.start_span(
                name="httpx.head",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype="HEAD",
                tool_name="httpx",
                http_method="HEAD",
                http_url=str(url),
            ) as span:
                try:
                    response = original_head(url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.head = wrapped_head

    # Wrap httpx.options
    if hasattr(httpx_module, "options"):
        original_options = httpx_module.options

        def wrapped_options(url: Union[str, Any], **kwargs) -> Any:
            """Wrapped OPTIONS function."""
            with tracer.start_span(
                name="httpx.options",
                kind=MVKSpanKind.TOOL,
                operation="http_call",
                operation_subtype="OPTIONS",
                tool_name="httpx",
                http_method="OPTIONS",
                http_url=str(url),
            ) as span:
                try:
                    response = original_options(url, **kwargs)
                    span.set_attribute("http_status_code", response.status_code)
                    return response
                except Exception as e:
                    span.set_error(e)
                    raise

        httpx_module.options = wrapped_options

    logger.info("HTTPX convenience functions wrapped successfully")


def patch():
    """Apply HTTPX patches."""
    try:
        import httpx

        wrap_httpx_client(httpx)
        logger.info("HTTPX patched successfully")
    except ImportError:
        logger.debug("HTTPX not installed, skipping auto-instrumentation")
    except Exception as e:
        logger.warning(f"Failed to patch HTTPX: {e}")
