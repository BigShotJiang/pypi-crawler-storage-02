"""OpenAI wrapper for MVK SDK v5.0 auto-instrumentation with W3C TraceContext."""

import logging
import time
from typing import Any, Dict, Optional

import wrapt

from ..metrics import Metric, add_metered_usage
from ..propagator import propagator
from ..schema import MVKSpanKind
from ..tracer import get_current_span, get_tracer

logger = logging.getLogger(__name__)


def extract_chat_attributes(response) -> Dict[str, Any]:
    """Extract attributes from chat completion response."""
    attrs = {}

    # Extract model info
    if hasattr(response, "model"):
        attrs["model_name"] = response.model
        attrs["model_provider_code"] = "openai"
        attrs["model_family"] = response.model.split("-")[0]  # gpt-4, gpt-3.5, etc

    # Extract usage if available
    if hasattr(response, "usage"):
        usage = response.usage
        if hasattr(usage, "prompt_tokens"):
            attrs["prompt_tokens"] = usage.prompt_tokens
        if hasattr(usage, "completion_tokens"):
            attrs["completion_tokens"] = usage.completion_tokens
        if hasattr(usage, "total_tokens"):
            attrs["total_tokens"] = usage.total_tokens

    # Extract operation info
    attrs["operation"] = "chat_completion"

    return attrs


def extract_embedding_attributes(response) -> Dict[str, Any]:
    """Extract attributes from embedding response."""
    attrs = {}

    # Extract model info
    if hasattr(response, "model"):
        attrs["model_name"] = response.model
        attrs["model_provider_code"] = "openai"
        attrs["model_family"] = "embedding"

    # Extract usage
    if hasattr(response, "usage"):
        usage = response.usage
        if hasattr(usage, "prompt_tokens"):
            attrs["prompt_tokens"] = usage.prompt_tokens
        if hasattr(usage, "total_tokens"):
            attrs["total_tokens"] = usage.total_tokens

    # Extract embedding info
    if hasattr(response, "data") and response.data:
        attrs["embeddings_count"] = len(response.data)
        if hasattr(response.data[0], "embedding"):
            attrs["embedding_dims"] = len(response.data[0].embedding)

    attrs["operation"] = "create_embedding"

    return attrs


def wrap_chat_completion_create(wrapped, instance, args, kwargs):
    """Wrap OpenAI chat completion create method with W3C TraceContext."""
    tracer = get_tracer()

    # Extract some request attributes
    request_attrs = {
        "model_name": kwargs.get("model", args[0] if args else "unknown"),
        "operation": "chat_completion",
    }

    # Start span
    span = tracer.start_span("openai.chat.completion", kind=MVKSpanKind.LLM, **request_attrs)

    try:
        # v5.0: Inject traceparent header for W3C TraceContext
        headers = kwargs.get("headers", {})
        if headers is None:
            headers = {}

        current_span = get_current_span()
        if current_span and hasattr(current_span, "trace_id"):
            propagator.inject(current_span.trace_id, current_span.span_id, headers)
            kwargs["headers"] = headers

        # Call original method
        start_time = time.time()
        response = wrapped(*args, **kwargs)

        # Extract response attributes
        response_attrs = extract_chat_attributes(response)
        for key, value in response_attrs.items():
            span.attributes[key] = value

        # Add time to first token if streaming
        if kwargs.get("stream", False):
            span.attributes["time_to_first_token_ms"] = (time.time() - start_time) * 1000

        # Add metered usage
        if "prompt_tokens" in response_attrs and "completion_tokens" in response_attrs:
            add_metered_usage(
                metric=Metric.PROMPT_TOKENS,
                value=response_attrs["prompt_tokens"],
                model_name=response_attrs.get("model_name", "unknown"),
            )
            add_metered_usage(
                metric=Metric.COMPLETION_TOKENS,
                value=response_attrs["completion_tokens"],
                model_name=response_attrs.get("model_name", "unknown"),
            )

        return response

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_embedding_create(wrapped, instance, args, kwargs):
    """Wrap OpenAI embedding create method with W3C TraceContext."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "model_name": kwargs.get("model", args[0] if args else "unknown"),
        "operation": "create_embedding",
    }

    # Count input texts
    input_param = kwargs.get("input", args[1] if len(args) > 1 else None)
    if input_param:
        if isinstance(input_param, list):
            request_attrs["embeddings_count"] = len(input_param)
        else:
            request_attrs["embeddings_count"] = 1

    # Start span
    span = tracer.start_span(
        "openai.embeddings.create", kind=MVKSpanKind.EMBEDDING, **request_attrs
    )

    try:
        # v5.0: Inject traceparent header for W3C TraceContext
        headers = kwargs.get("headers", {})
        if headers is None:
            headers = {}

        current_span = get_current_span()
        if current_span and hasattr(current_span, "trace_id"):
            propagator.inject(current_span.trace_id, current_span.span_id, headers)
            kwargs["headers"] = headers

        # Call original method
        response = wrapped(*args, **kwargs)

        # Extract response attributes
        response_attrs = extract_embedding_attributes(response)
        for key, value in response_attrs.items():
            span.attributes[key] = value

        # Add metered usage
        if "prompt_tokens" in response_attrs:
            add_metered_usage(
                metric=Metric.EMBEDDING_TOKENS,
                value=response_attrs["prompt_tokens"],
                model_name=response_attrs.get("model_name", "unknown"),
            )

        return response

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def patch():
    """Apply OpenAI patches."""
    try:
        import openai

        # Check OpenAI version and patch accordingly
        version = getattr(openai, "__version__", "0.0.0")
        major_version = int(version.split(".")[0])

        if major_version >= 1:
            # OpenAI v1.x style
            # Chat completions
            if hasattr(openai, "chat") and hasattr(openai.chat, "completions"):
                wrapt.wrap_function_wrapper(
                    openai.chat.completions, "create", wrap_chat_completion_create
                )
                logger.info("Patched openai.chat.completions.create")

            # Embeddings
            if hasattr(openai, "embeddings"):
                wrapt.wrap_function_wrapper(openai.embeddings, "create", wrap_embedding_create)
                logger.info("Patched openai.embeddings.create")
        else:
            # OpenAI v0.x style
            # ChatCompletion
            if hasattr(openai, "ChatCompletion"):
                wrapt.wrap_function_wrapper(
                    openai.ChatCompletion, "create", wrap_chat_completion_create
                )
                logger.info("Patched openai.ChatCompletion.create")

            # Embedding
            if hasattr(openai, "Embedding"):
                wrapt.wrap_function_wrapper(openai.Embedding, "create", wrap_embedding_create)
                logger.info("Patched openai.Embedding.create")

    except Exception as e:
        logger.warning(f"Failed to patch OpenAI: {e}")
