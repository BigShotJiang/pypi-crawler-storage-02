"""Cohere wrapper for MVK SDK v5.0 auto-instrumentation with W3C TraceContext."""

import logging
from typing import Any, Dict, Optional

import wrapt

from ..metrics import Metric, add_metered_usage
from ..propagator import propagator
from ..schema import MVKSpanKind
from ..tracer import get_current_span, get_tracer

logger = logging.getLogger(__name__)


def extract_chat_attributes(response: Any) -> Dict[str, Any]:
    """Extract attributes from Cohere chat response."""
    attrs: Dict[str, Any] = {}

    # Extract model info - Cohere doesn't always return model in response
    if hasattr(response, "model"):
        attrs["model_name"] = response.model
    attrs["model_provider_code"] = "cohere"
    attrs["model_family"] = "command"

    # Extract token usage
    if hasattr(response, "meta") and hasattr(response.meta, "billed_units"):
        units = response.meta.billed_units
        if hasattr(units, "input_tokens"):
            attrs["prompt_tokens"] = units.input_tokens
        if hasattr(units, "output_tokens"):
            attrs["completion_tokens"] = units.output_tokens

    # Extract operation info
    attrs["operation"] = "chat"

    return attrs


def extract_embed_attributes(response: Any) -> Dict[str, Any]:
    """Extract attributes from Cohere embed response."""
    attrs: Dict[str, Any] = {}

    attrs["model_provider_code"] = "cohere"
    attrs["model_family"] = "embed"
    attrs["operation"] = "embed"

    # Extract embeddings count
    if hasattr(response, "embeddings"):
        attrs["embeddings_count"] = len(response.embeddings)
        if response.embeddings and len(response.embeddings) > 0:
            attrs["embedding_dims"] = len(response.embeddings[0])

    # Extract token usage
    if hasattr(response, "meta") and hasattr(response.meta, "billed_units"):
        units = response.meta.billed_units
        if hasattr(units, "input_tokens"):
            attrs["prompt_tokens"] = units.input_tokens

    return attrs


def wrap_chat(wrapped, instance, args, kwargs):
    """Wrap Cohere chat method with W3C TraceContext."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "model_name": kwargs.get("model", "command"),
        "model_provider_code": "cohere",
        "operation": "chat",
    }

    # Start span
    span = tracer.start_span("cohere.chat", kind=MVKSpanKind.LLM, **request_attrs)

    try:
        # v5.0: Inject traceparent header for W3C TraceContext
        headers = kwargs.get("headers", {})
        if headers is None:
            headers = {}

        current_span = get_current_span()
        if current_span and hasattr(current_span, "trace_id"):
            propagator.inject(current_span.trace_id, current_span.span_id, headers)
            kwargs["headers"] = headers

        # Call original method
        response = wrapped(*args, **kwargs)

        # Extract response attributes
        response_attrs = extract_chat_attributes(response)
        for key, value in response_attrs.items():
            span.attributes[key] = value

        # Add metered usage
        if "prompt_tokens" in response_attrs:
            add_metered_usage(
                metric=Metric.PROMPT_TOKENS,
                value=response_attrs["prompt_tokens"],
                model_name=request_attrs["model_name"],
            )
        if "completion_tokens" in response_attrs:
            add_metered_usage(
                metric=Metric.COMPLETION_TOKENS,
                value=response_attrs["completion_tokens"],
                model_name=request_attrs["model_name"],
            )

        return response

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_embed(wrapped, instance, args, kwargs):
    """Wrap Cohere embed method with W3C TraceContext."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "model_name": kwargs.get("model", "embed-english-v2.0"),
        "model_provider_code": "cohere",
        "operation": "embed",
    }

    # Count input texts
    texts = kwargs.get("texts", args[0] if args else [])
    if isinstance(texts, list):
        request_attrs["embeddings_count"] = len(texts)

    # Start span
    span = tracer.start_span("cohere.embed", kind=MVKSpanKind.EMBEDDING, **request_attrs)

    try:
        # v5.0: Inject traceparent header for W3C TraceContext
        headers = kwargs.get("headers", {})
        if headers is None:
            headers = {}

        current_span = get_current_span()
        if current_span and hasattr(current_span, "trace_id"):
            propagator.inject(current_span.trace_id, current_span.span_id, headers)
            kwargs["headers"] = headers

        # Call original method
        response = wrapped(*args, **kwargs)

        # Extract response attributes
        response_attrs = extract_embed_attributes(response)
        for key, value in response_attrs.items():
            span.attributes[key] = value

        # Add metered usage
        if "prompt_tokens" in response_attrs:
            add_metered_usage(
                metric=Metric.EMBEDDING_TOKENS,
                value=response_attrs["prompt_tokens"],
                model_name=request_attrs["model_name"],
            )

        return response

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def patch():
    """Apply Cohere patches."""
    try:
        import cohere

        # Check if Client class exists
        if hasattr(cohere, "Client"):
            # Patch chat method
            wrapt.wrap_function_wrapper(cohere.Client, "chat", wrap_chat)
            logger.info("Patched cohere.Client.chat")

            # Patch embed method
            wrapt.wrap_function_wrapper(cohere.Client, "embed", wrap_embed)
            logger.info("Patched cohere.Client.embed")

        # For newer versions, patch at module level
        if hasattr(cohere, "chat"):
            wrapt.wrap_function_wrapper(cohere, "chat", wrap_chat)
            logger.info("Patched cohere.chat")

        if hasattr(cohere, "embed"):
            wrapt.wrap_function_wrapper(cohere, "embed", wrap_embed)
            logger.info("Patched cohere.embed")

    except Exception as e:
        logger.warning(f"Failed to patch Cohere: {e}")
