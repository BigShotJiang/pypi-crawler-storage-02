"""ChromaDB wrapper for MVK SDK v3.0 auto-instrumentation."""

import logging
from typing import Any, Dict, List, Optional, Union

import wrapt

from ..schema import MVKSpanKind
from ..tracer import get_tracer

logger = logging.getLogger(__name__)


def extract_collection_name(collection: Any) -> str:
    """Extract collection name from ChromaDB collection object."""
    if hasattr(collection, "name"):
        return str(collection.name)
    return "unknown"


def wrap_collection_add(wrapped, instance, args, kwargs):
    """Wrap ChromaDB collection add method."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "operation": "add",
        "db_system": "chromadb",
        "vectordb_index": extract_collection_name(instance),
    }

    # Count documents being added
    if "documents" in kwargs:
        docs = kwargs["documents"]
    elif "embeddings" in kwargs:
        docs = kwargs["embeddings"]
    elif args:
        docs = args[0]
    else:
        docs = []

    if isinstance(docs, list):
        request_attrs["document_count"] = len(docs)

    # Start span
    span = tracer.start_span("chromadb.collection.add", kind=MVKSpanKind.TOOL, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)

        # Add result info
        if result and isinstance(result, dict):
            if "ids" in result and isinstance(result["ids"], list):
                span.attributes["added_count"] = len(result["ids"])

        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_collection_query(wrapped, instance, args, kwargs):
    """Wrap ChromaDB collection query method."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "operation": "query",
        "db_system": "chromadb",
        "vectordb_index": extract_collection_name(instance),
    }

    # Extract query parameters
    n_results = kwargs.get("n_results", 10)
    request_attrs["vectordb_match_count"] = n_results

    # Check if query texts or embeddings provided
    if "query_texts" in kwargs and kwargs["query_texts"]:
        request_attrs["query_count"] = len(kwargs["query_texts"])
    elif "query_embeddings" in kwargs and kwargs["query_embeddings"]:
        request_attrs["query_count"] = len(kwargs["query_embeddings"])

    # Start span
    span = tracer.start_span(
        "chromadb.collection.query", kind=MVKSpanKind.RETRIEVER, **request_attrs
    )

    try:
        # Call original method
        result = wrapped(*args, **kwargs)

        # Extract result metrics
        if result and isinstance(result, dict):
            if "ids" in result and isinstance(result["ids"], list):
                # ChromaDB returns nested lists
                total_results = sum(len(ids) for ids in result["ids"] if isinstance(ids, list))
                span.attributes["result_count"] = total_results

        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_collection_delete(wrapped, instance, args, kwargs):
    """Wrap ChromaDB collection delete method."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "operation": "delete",
        "db_system": "chromadb",
        "vectordb_index": extract_collection_name(instance),
    }

    # Start span
    span = tracer.start_span("chromadb.collection.delete", kind=MVKSpanKind.TOOL, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)
        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_collection_update(wrapped, instance, args, kwargs):
    """Wrap ChromaDB collection update method."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "operation": "update",
        "db_system": "chromadb",
        "vectordb_index": extract_collection_name(instance),
    }

    # Count documents being updated
    if "ids" in kwargs and isinstance(kwargs["ids"], list):
        request_attrs["update_count"] = len(kwargs["ids"])

    # Start span
    span = tracer.start_span("chromadb.collection.update", kind=MVKSpanKind.TOOL, **request_attrs)

    try:
        # Call original method
        result = wrapped(*args, **kwargs)
        return result

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_client_create_collection(wrapped, instance, args, kwargs):
    """Wrap ChromaDB client create_collection method."""
    tracer = get_tracer()

    # Extract collection name
    collection_name = kwargs.get("name", args[0] if args else "unknown")

    request_attrs = {
        "operation": "create_collection",
        "db_system": "chromadb",
        "vectordb_index": collection_name,
    }

    # Start span
    span = tracer.start_span(
        "chromadb.client.create_collection", kind=MVKSpanKind.TOOL, **request_attrs
    )

    try:
        # Call original method
        collection = wrapped(*args, **kwargs)

        # Wrap collection methods
        if collection:
            _wrap_collection_methods(collection)

        return collection

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_client_get_collection(wrapped, instance, args, kwargs):
    """Wrap ChromaDB client get_collection method."""
    tracer = get_tracer()

    # Extract collection name
    collection_name = kwargs.get("name", args[0] if args else "unknown")

    request_attrs = {
        "operation": "get_collection",
        "db_system": "chromadb",
        "vectordb_index": collection_name,
    }

    # Start span
    span = tracer.start_span(
        "chromadb.client.get_collection", kind=MVKSpanKind.TOOL, **request_attrs
    )

    try:
        # Call original method
        collection = wrapped(*args, **kwargs)

        # Wrap collection methods
        if collection:
            _wrap_collection_methods(collection)

        return collection

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def _wrap_collection_methods(collection):
    """Wrap methods on a ChromaDB collection instance."""
    try:
        # Wrap add method
        if hasattr(collection, "add"):
            wrapt.wrap_function_wrapper(collection, "add", wrap_collection_add)

        # Wrap query method
        if hasattr(collection, "query"):
            wrapt.wrap_function_wrapper(collection, "query", wrap_collection_query)

        # Wrap delete method
        if hasattr(collection, "delete"):
            wrapt.wrap_function_wrapper(collection, "delete", wrap_collection_delete)

        # Wrap update method
        if hasattr(collection, "update"):
            wrapt.wrap_function_wrapper(collection, "update", wrap_collection_update)
    except Exception as e:
        logger.debug(f"Failed to wrap collection methods: {e}")


def patch():
    """Apply ChromaDB patches."""
    try:
        import chromadb

        # Patch Client methods
        if hasattr(chromadb, "Client"):
            # create_collection
            wrapt.wrap_function_wrapper(
                chromadb.Client, "create_collection", wrap_client_create_collection
            )
            logger.info("Patched chromadb.Client.create_collection")

            # get_collection
            wrapt.wrap_function_wrapper(
                chromadb.Client, "get_collection", wrap_client_get_collection
            )
            logger.info("Patched chromadb.Client.get_collection")

            # get_or_create_collection
            wrapt.wrap_function_wrapper(
                chromadb.Client,
                "get_or_create_collection",
                wrap_client_get_collection,  # Same wrapper works
            )
            logger.info("Patched chromadb.Client.get_or_create_collection")

        # For PersistentClient
        if hasattr(chromadb, "PersistentClient"):
            wrapt.wrap_function_wrapper(
                chromadb.PersistentClient, "create_collection", wrap_client_create_collection
            )
            wrapt.wrap_function_wrapper(
                chromadb.PersistentClient, "get_collection", wrap_client_get_collection
            )
            wrapt.wrap_function_wrapper(
                chromadb.PersistentClient, "get_or_create_collection", wrap_client_get_collection
            )
            logger.info("Patched chromadb.PersistentClient methods")

    except Exception as e:
        logger.warning(f"Failed to patch ChromaDB: {e}")
