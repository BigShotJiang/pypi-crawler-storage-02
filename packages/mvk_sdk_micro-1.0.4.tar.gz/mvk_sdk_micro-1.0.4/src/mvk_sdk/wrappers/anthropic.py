"""Anthropic wrapper for MVK SDK v5.0 auto-instrumentation with W3C TraceContext."""

import logging
import time
from typing import Any, Dict, Optional

import wrapt

from ..metrics import Metric, add_metered_usage
from ..propagator import propagator
from ..schema import MVKSpanKind
from ..tracer import get_current_span, get_tracer

logger = logging.getLogger(__name__)


def extract_message_attributes(response) -> Dict[str, Any]:
    """Extract attributes from Anthropic message response."""
    attrs = {}

    # Extract model info
    if hasattr(response, "model"):
        attrs["model_name"] = response.model
        attrs["model_provider_code"] = "anthropic"
        attrs["model_family"] = "claude"

    # Extract usage if available
    if hasattr(response, "usage"):
        usage = response.usage
        if hasattr(usage, "input_tokens"):
            attrs["prompt_tokens"] = usage.input_tokens
        if hasattr(usage, "output_tokens"):
            attrs["completion_tokens"] = usage.output_tokens

    # Extract operation info
    attrs["operation"] = "messages_create"

    # Extract stop reason
    if hasattr(response, "stop_reason"):
        attrs["stop_reason"] = response.stop_reason

    return attrs


def wrap_messages_create(wrapped, instance, args, kwargs):
    """Wrap Anthropic messages create method with W3C TraceContext."""
    tracer = get_tracer()

    # Extract some request attributes
    request_attrs = {
        "model_name": kwargs.get("model", args[0] if args else "unknown"),
        "model_provider_code": "anthropic",
        "operation": "messages_create",
    }

    # Extract max tokens if provided
    if "max_tokens" in kwargs:
        request_attrs["max_tokens"] = kwargs["max_tokens"]
    elif len(args) > 1:
        request_attrs["max_tokens"] = args[1]

    # Start span
    span = tracer.start_span("anthropic.messages.create", kind=MVKSpanKind.LLM, **request_attrs)

    try:
        # v5.0: Inject traceparent header for W3C TraceContext
        headers = kwargs.get("headers", {})
        if headers is None:
            headers = {}

        current_span = get_current_span()
        if current_span and hasattr(current_span, "trace_id"):
            propagator.inject(current_span.trace_id, current_span.span_id, headers)
            kwargs["headers"] = headers

        # Call original method
        start_time = time.time()
        response = wrapped(*args, **kwargs)

        # Extract response attributes
        response_attrs = extract_message_attributes(response)
        for key, value in response_attrs.items():
            span.attributes[key] = value

        # Add metered usage
        if "prompt_tokens" in response_attrs and "completion_tokens" in response_attrs:
            add_metered_usage(
                metric=Metric.PROMPT_TOKENS,
                value=response_attrs["prompt_tokens"],
                model_name=response_attrs.get("model_name", "unknown"),
            )
            add_metered_usage(
                metric=Metric.COMPLETION_TOKENS,
                value=response_attrs["completion_tokens"],
                model_name=response_attrs.get("model_name", "unknown"),
            )

        return response

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        span.end()


def wrap_messages_stream(wrapped, instance, args, kwargs):
    """Wrap Anthropic messages stream method with W3C TraceContext."""
    tracer = get_tracer()

    # Extract request attributes
    request_attrs = {
        "model_name": kwargs.get("model", args[0] if args else "unknown"),
        "model_provider_code": "anthropic",
        "operation": "messages_stream",
        "stream": True,
    }

    # Start span
    span = tracer.start_span("anthropic.messages.stream", kind=MVKSpanKind.LLM, **request_attrs)

    try:
        # v5.0: Inject traceparent header for W3C TraceContext
        headers = kwargs.get("headers", {})
        if headers is None:
            headers = {}

        current_span = get_current_span()
        if current_span and hasattr(current_span, "trace_id"):
            propagator.inject(current_span.trace_id, current_span.span_id, headers)
            kwargs["headers"] = headers

        # Call original method
        start_time = time.time()
        stream = wrapped(*args, **kwargs)

        # Track first token time
        first_token = True

        # Wrap the stream to track metrics
        def wrapped_stream():
            nonlocal first_token
            total_tokens = 0

            for chunk in stream:
                if first_token:
                    span.attributes["time_to_first_token_ms"] = (time.time() - start_time) * 1000
                    first_token = False

                # Count tokens if available
                if hasattr(chunk, "delta") and hasattr(chunk.delta, "text"):
                    # Rough estimate: 4 chars per token
                    total_tokens += len(chunk.delta.text) // 4

                yield chunk

            # Update token count
            if total_tokens > 0:
                span.attributes["completion_tokens"] = total_tokens

        return wrapped_stream()

    except Exception as e:
        span.set_error(e)
        raise

    finally:
        # Note: span will be ended when stream is exhausted or on error
        # For now, end it immediately
        span.end()


def patch():
    """Apply Anthropic patches."""
    try:
        import anthropic

        # Messages API (main interface)
        if hasattr(anthropic, "Anthropic"):
            # Patch messages.create
            wrapt.wrap_function_wrapper(
                anthropic.Anthropic, "messages.create", wrap_messages_create
            )
            logger.info("Patched anthropic.Anthropic.messages.create")

            # Also patch the client instance method
            original_init = anthropic.Anthropic.__init__

            def patched_init(self, *args, **kwargs):
                original_init(self, *args, **kwargs)
                if hasattr(self, "messages"):
                    wrapt.wrap_function_wrapper(self.messages, "create", wrap_messages_create)
                    wrapt.wrap_function_wrapper(self.messages, "stream", wrap_messages_stream)

            anthropic.Anthropic.__init__ = patched_init
            logger.info("Patched Anthropic client initialization")

        # AsyncAnthropic
        if hasattr(anthropic, "AsyncAnthropic"):
            # Similar patching for async client
            logger.info("AsyncAnthropic patching not yet implemented")

    except Exception as e:
        logger.warning(f"Failed to patch Anthropic: {e}")
