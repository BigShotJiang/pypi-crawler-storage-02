"""Weaviate wrapper for MVK SDK v3.0."""

import logging
from typing import Any, Dict, List, Optional

import wrapt

from ..schema import MVKSpanKind
from ..tracer import get_tracer

logger = logging.getLogger(__name__)


def wrap_weaviate_client(weaviate_module):
    """Wrap Weaviate client for auto-instrumentation."""
    tracer = get_tracer()

    # Wrap Client class
    if hasattr(weaviate_module, "Client"):
        original_client = weaviate_module.Client

        class InstrumentedClient(original_client):
            """Instrumented Weaviate Client."""

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                # Wrap query methods
                self._wrap_query_methods()
                self._wrap_batch_methods()
                self._wrap_data_methods()

            def _wrap_query_methods(self):
                """Wrap query methods."""
                if hasattr(self, "query"):
                    # Wrap get method
                    if hasattr(self.query, "get"):
                        original_get = self.query.get

                        def wrapped_get(class_name: str, properties: Optional[List[str]] = None):
                            """Wrapped get method."""
                            query_builder = original_get(class_name, properties)
                            # Wrap the do() method of the query builder
                            original_do = query_builder.do

                            def wrapped_do():
                                with tracer.start_span(
                                    name="weaviate.query.get",
                                    kind=MVKSpanKind.RETRIEVER,
                                    collection_name=class_name,
                                    operation="query",
                                    retriever_provider="weaviate",
                                ) as span:
                                    try:
                                        result = original_do()
                                        # Extract result count
                                        if isinstance(result, dict) and "data" in result:
                                            data = result["data"]
                                            if isinstance(data, dict) and "Get" in data:
                                                get_data = data["Get"]
                                                if (
                                                    isinstance(get_data, dict)
                                                    and class_name in get_data
                                                ):
                                                    results = get_data[class_name]
                                                    if isinstance(results, list):
                                                        span.set_attribute(
                                                            "retriever.k", len(results)
                                                        )
                                        return result
                                    except Exception as e:
                                        span.set_error(e)
                                        raise

                            query_builder.do = wrapped_do
                            return query_builder

                        self.query.get = wrapped_get

                    # Wrap aggregate method
                    if hasattr(self.query, "aggregate"):
                        original_aggregate = self.query.aggregate

                        def wrapped_aggregate(class_name: str):
                            """Wrapped aggregate method."""
                            query_builder = original_aggregate(class_name)
                            original_do = query_builder.do

                            def wrapped_do():
                                with tracer.start_span(
                                    name="weaviate.query.aggregate",
                                    kind=MVKSpanKind.RETRIEVER,
                                    collection_name=class_name,
                                    operation="aggregate",
                                    retriever_provider="weaviate",
                                ) as span:
                                    try:
                                        return original_do()
                                    except Exception as e:
                                        span.set_error(e)
                                        raise

                            query_builder.do = wrapped_do
                            return query_builder

                        self.query.aggregate = wrapped_aggregate

            def _wrap_batch_methods(self):
                """Wrap batch methods."""
                if hasattr(self, "batch"):
                    # Wrap create_objects
                    if hasattr(self.batch, "create_objects"):
                        original_create = self.batch.create_objects

                        def wrapped_create(objects):
                            with tracer.start_span(
                                name="weaviate.batch.create_objects",
                                kind=MVKSpanKind.TOOL,
                                operation="batch_create",
                                tool_name="weaviate",
                            ) as span:
                                try:
                                    span.set_attribute("batch_size", len(objects) if objects else 0)
                                    result = original_create(objects)
                                    return result
                                except Exception as e:
                                    span.set_error(e)
                                    raise

                        self.batch.create_objects = wrapped_create

            def _wrap_data_methods(self):
                """Wrap data object methods."""
                if hasattr(self, "data_object"):
                    # Wrap create
                    if hasattr(self.data_object, "create"):
                        original_create = self.data_object.create

                        def wrapped_create(data_object, class_name, uuid=None):
                            with tracer.start_span(
                                name="weaviate.data.create",
                                kind=MVKSpanKind.TOOL,
                                collection_name=class_name,
                                operation="create",
                                tool_name="weaviate",
                            ) as span:
                                try:
                                    result = original_create(data_object, class_name, uuid)
                                    return result
                                except Exception as e:
                                    span.set_error(e)
                                    raise

                        self.data_object.create = wrapped_create

                    # Wrap get
                    if hasattr(self.data_object, "get"):
                        original_get = self.data_object.get

                        def wrapped_get(uuid=None, class_name=None):
                            with tracer.start_span(
                                name="weaviate.data.get",
                                kind=MVKSpanKind.RETRIEVER,
                                collection_name=class_name,
                                operation="get",
                                retriever_provider="weaviate",
                            ) as span:
                                try:
                                    result = original_get(uuid, class_name)
                                    return result
                                except Exception as e:
                                    span.set_error(e)
                                    raise

                        self.data_object.get = wrapped_get

                    # Wrap delete
                    if hasattr(self.data_object, "delete"):
                        original_delete = self.data_object.delete

                        def wrapped_delete(uuid, class_name=None):
                            with tracer.start_span(
                                name="weaviate.data.delete",
                                kind=MVKSpanKind.TOOL,
                                collection_name=class_name,
                                operation="delete",
                                tool_name="weaviate",
                            ) as span:
                                try:
                                    result = original_delete(uuid, class_name)
                                    return result
                                except Exception as e:
                                    span.set_error(e)
                                    raise

                        self.data_object.delete = wrapped_delete

        weaviate_module.Client = InstrumentedClient
        logger.info("Weaviate Client wrapped successfully")

    # Wrap connect_to_local for v4+ API
    if hasattr(weaviate_module, "connect_to_local"):
        original_connect = weaviate_module.connect_to_local

        def wrapped_connect(*args, **kwargs):
            """Wrapped connect_to_local."""
            client = original_connect(*args, **kwargs)
            # Wrap collection methods
            _wrap_v4_client(client)
            return client

        weaviate_module.connect_to_local = wrapped_connect
        logger.info("Weaviate connect_to_local wrapped successfully")

    # Wrap connect_to_wcs for v4+ API
    if hasattr(weaviate_module, "connect_to_wcs"):
        original_connect = weaviate_module.connect_to_wcs

        def wrapped_connect(*args, **kwargs):
            """Wrapped connect_to_wcs."""
            client = original_connect(*args, **kwargs)
            # Wrap collection methods
            _wrap_v4_client(client)
            return client

        weaviate_module.connect_to_wcs = wrapped_connect
        logger.info("Weaviate connect_to_wcs wrapped successfully")


def _wrap_v4_client(client):
    """Wrap Weaviate v4 client methods."""
    tracer = get_tracer()

    if hasattr(client, "collections"):
        # Wrap get collection
        if hasattr(client.collections, "get"):
            original_get = client.collections.get

            def wrapped_get(name: str):
                """Wrapped get collection."""
                collection = original_get(name)
                # Wrap collection methods
                _wrap_collection(collection, name)
                return collection

            client.collections.get = wrapped_get


def _wrap_collection(collection, collection_name: str):
    """Wrap Weaviate collection methods."""
    tracer = get_tracer()

    # Wrap query methods
    if hasattr(collection, "query"):
        # Wrap near_text
        if hasattr(collection.query, "near_text"):
            original_near_text = collection.query.near_text

            def wrapped_near_text(query: str, limit: int = 10, **kwargs):
                with tracer.start_span(
                    name="weaviate.query.near_text",
                    kind=MVKSpanKind.RETRIEVER,
                    collection_name=collection_name,
                    operation="near_text",
                    retriever_provider="weaviate",
                    retriever_k=limit,
                ) as span:
                    try:
                        result = original_near_text(query, limit, **kwargs)
                        return result
                    except Exception as e:
                        span.set_error(e)
                        raise

            collection.query.near_text = wrapped_near_text

        # Wrap near_vector
        if hasattr(collection.query, "near_vector"):
            original_near_vector = collection.query.near_vector

            def wrapped_near_vector(vector: List[float], limit: int = 10, **kwargs):
                with tracer.start_span(
                    name="weaviate.query.near_vector",
                    kind=MVKSpanKind.RETRIEVER,
                    collection_name=collection_name,
                    operation="near_vector",
                    retriever_provider="weaviate",
                    retriever_k=limit,
                ) as span:
                    try:
                        result = original_near_vector(vector, limit, **kwargs)
                        return result
                    except Exception as e:
                        span.set_error(e)
                        raise

            collection.query.near_vector = wrapped_near_vector

        # Wrap bm25
        if hasattr(collection.query, "bm25"):
            original_bm25 = collection.query.bm25

            def wrapped_bm25(query: str, limit: int = 10, **kwargs):
                with tracer.start_span(
                    name="weaviate.query.bm25",
                    kind=MVKSpanKind.RETRIEVER,
                    collection_name=collection_name,
                    operation="bm25",
                    retriever_provider="weaviate",
                    retriever_k=limit,
                ) as span:
                    try:
                        result = original_bm25(query, limit, **kwargs)
                        return result
                    except Exception as e:
                        span.set_error(e)
                        raise

            collection.query.bm25 = wrapped_bm25

    # Wrap data methods
    if hasattr(collection, "data"):
        # Wrap insert
        if hasattr(collection.data, "insert"):
            original_insert = collection.data.insert

            def wrapped_insert(properties: Dict[str, Any], **kwargs):
                with tracer.start_span(
                    name="weaviate.data.insert",
                    kind=MVKSpanKind.TOOL,
                    collection_name=collection_name,
                    operation="insert",
                    tool_name="weaviate",
                ) as span:
                    try:
                        result = original_insert(properties, **kwargs)
                        return result
                    except Exception as e:
                        span.set_error(e)
                        raise

            collection.data.insert = wrapped_insert

        # Wrap insert_many
        if hasattr(collection.data, "insert_many"):
            original_insert_many = collection.data.insert_many

            def wrapped_insert_many(objects: List[Dict[str, Any]], **kwargs):
                with tracer.start_span(
                    name="weaviate.data.insert_many",
                    kind=MVKSpanKind.TOOL,
                    collection_name=collection_name,
                    operation="insert_many",
                    tool_name="weaviate",
                ) as span:
                    try:
                        span.set_attribute("batch_size", len(objects))
                        result = original_insert_many(objects, **kwargs)
                        return result
                    except Exception as e:
                        span.set_error(e)
                        raise

            collection.data.insert_many = wrapped_insert_many


def patch():
    """Apply Weaviate patches."""
    try:
        import weaviate

        wrap_weaviate_client(weaviate)
        logger.info("Weaviate patched successfully")
    except ImportError:
        logger.debug("Weaviate not installed, skipping auto-instrumentation")
    except Exception as e:
        logger.warning(f"Failed to patch Weaviate: {e}")
