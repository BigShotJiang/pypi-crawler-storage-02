"""Unified schema validator for MVK SDK v5.0 with OTLP compliance.

This module provides centralized validation for all spans, ensuring compliance
with both MVK schema requirements and OTLP v1 specifications. Supports strict
and lenient validation modes, proper ID format validation, timestamp conversion,
and attribute namespacing.
"""

import json
import logging
import os
import re
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger(__name__)

# Tag validation regex
TAG_KEY_PATTERN = re.compile(r"^[a-z0-9_-]{1,32}$")
TAG_VALUE_PATTERN = re.compile(r"^[a-z0-9_-]{1,32}$")
MAX_TAGS = 10

# OTLP validation patterns
TRACE_ID_PATTERN = re.compile(r"^[0-9a-f]{32}$")  # 32 hex chars
SPAN_ID_PATTERN = re.compile(r"^[0-9a-f]{16}$")  # 16 hex chars

# OTLP limits
MAX_ATTRIBUTES = 128
MAX_STRING_LENGTH = 8192
MAX_ARRAY_LENGTH = 128
MAX_EVENTS = 128
MAX_LINKS = 128
MAX_SPAN_NAME_LENGTH = 256

# OTLP SpanKind enum values
OTLP_SPAN_KINDS = {
    "SPAN_KIND_UNSPECIFIED",
    "SPAN_KIND_INTERNAL",
    "SPAN_KIND_SERVER",
    "SPAN_KIND_CLIENT",
    "SPAN_KIND_PRODUCER",
    "SPAN_KIND_CONSUMER",
}

# OTLP StatusCode enum values
OTLP_STATUS_CODES = {"STATUS_CODE_UNSET", "STATUS_CODE_OK", "STATUS_CODE_ERROR"}


# MVK semantic span kinds (stored in mvk.span.kind attribute)
class MVKSpanKind(str, Enum):
    """MVK semantic span kinds.

    These represent the type of operation being performed,
    stored in the 'mvk.span.kind' attribute. This is separate
    from OpenTelemetry's SpanKind (CLIENT, SERVER, etc.).
    """

    LLM = "LLM"
    EMBEDDING = "EMBEDDING"
    RETRIEVER = "RETRIEVER"
    TOOL = "TOOL"
    MEMORY = "MEMORY"
    AGENT_CALL = "AGENT_CALL"


# Required fields for all spans (v5.0 - always present)
REQUIRED_FIELDS = {
    "trace_id",
    "span_id",
    "parent_span_id",  # Required in v5.0 (use "0000000000000000" for root)
    "start_time",
    "end_time",
    "duration_ms",
    "status_code",
    "service.name",
    "service.instance.id",
    "mvk.agent.name",  # Derived from service.name
    "mvk.span.kind",  # MVK semantic kind (LLM, EMBEDDING, etc.)
    "name",
}

# Field type validators
FIELD_TYPES = {
    # OTEL core
    "trace_id": str,
    "span_id": str,
    "parent_span_id": str,  # Now required, not optional
    "start_time": (int, float),
    "end_time": (int, float),
    "duration_ms": (int, float),
    "status_code": int,
    "status_message": str,
    # Service identity (v5.0)
    "service.name": str,
    "service.version": str,
    "service.namespace": str,
    "service.instance.id": str,
    # MVK context
    "mvk.agent.name": str,
    "session_id": str,
    "user_id": str,  # First-class attribute for user identification
    "client_id": str,  # First-class attribute for client/caller identification
    "cloud_provider_code": str,  # Optional, user-provided only in v5.0
    "model_provider_code": str,
    "sdk": str,
    # Operation
    "kind": int,  # OTEL SpanKind (CLIENT=2, SERVER=1, etc.)
    "mvk.span.kind": str,  # MVK semantic kind (LLM, EMBEDDING, etc.)
    "name": str,
    "operation": str,
    "operation_subtype": str,
    # Model fields
    "model_name": str,
    "model_family": str,
    "model_type": str,
    "model_version": str,
    # Request metrics
    "prompt_tokens": int,
    "completion_tokens": int,
    "embeddings_count": int,
    "embedding_dims": int,
    "total_images": int,
    "image_size": str,
    "total_characters": int,
    # Retriever / DB
    "vectordb_index": str,
    "vectordb_match_count": int,
    "db_system": str,
    "db_operation": str,
    "db_table": str,
    "db_rows_affected": int,
    # Memory
    "memory_op": str,
    "bytes_read": int,
    "bytes_written": int,
    # Latency
    "time_to_first_token_ms": (int, float),
    "e2e_latency_ms": (int, float),
    # Tags and vendor
    "tags": (dict, str),  # JSON string or dict
    "vendor_attr": (dict, str),  # JSON string or dict
    "events": (list, str),  # JSON string or list
    "metered_usage": (list, str),  # JSON string or list
}

# Allowed attributes per MVK span kind
MVK_SPAN_KIND_ATTRIBUTES = {
    MVKSpanKind.LLM: {
        "model_name",
        "model_family",
        "model_type",
        "model_version",
        "prompt_tokens",
        "completion_tokens",
        "time_to_first_token_ms",
        "operation",
        "operation_subtype",
    },
    MVKSpanKind.EMBEDDING: {
        "model_name",
        "model_family",
        "model_type",
        "model_version",
        "embeddings_count",
        "embedding_dims",
        "operation",
    },
    MVKSpanKind.RETRIEVER: {
        "vectordb_index",
        "vectordb_match_count",
        "operation",
        "embeddings_count",
        "embedding_dims",
    },
    MVKSpanKind.TOOL: {
        "operation",
        "operation_subtype",
        "http_method",
        "http_status_code",
        "db_system",
        "db_operation",
        "db_table",
        "db_rows_affected",
    },
    MVKSpanKind.MEMORY: {"memory_op", "bytes_read", "bytes_written", "operation"},
    MVKSpanKind.AGENT_CALL: {"name", "operation", "operation_subtype"},
}


def validate_tags(tags: Dict[str, Any]) -> Tuple[Dict[str, str], List[str]]:
    """Validate and clean tags according to v3.0 rules.

    Args:
        tags: Dictionary of tags to validate

    Returns:
        Tuple of (valid_tags, error_messages)
    """
    valid_tags = {}
    errors = []

    if not isinstance(tags, dict):
        return {}, ["Tags must be a dictionary"]

    # Check tag count
    if len(tags) > MAX_TAGS:
        errors.append(f"Too many tags: {len(tags)} > {MAX_TAGS} maximum")

    for key, value in list(tags.items())[:MAX_TAGS]:
        # Validate key
        if not isinstance(key, str):
            errors.append(f"Tag key must be string, got {type(key).__name__}: {key}")
            continue

        if not TAG_KEY_PATTERN.match(key):
            errors.append(f"Invalid tag key '{key}': must match [a-z0-9_-]{{1,32}}")
            continue

        # Validate value
        if value is None:
            errors.append(f"Tag value for '{key}' cannot be None")
            continue

        # Convert value to string
        str_value = str(value)

        if not TAG_VALUE_PATTERN.match(str_value):
            errors.append(
                f"Invalid tag value '{str_value}' for key '{key}': must match [a-z0-9_-]{{1,32}}"
            )
            continue

        valid_tags[key] = str_value

    return valid_tags, errors


def validate_field_type(field: str, value: Any) -> Tuple[bool, Optional[str]]:
    """Validate a field's type.

    Args:
        field: Field name
        value: Field value

    Returns:
        Tuple of (is_valid, error_message)
    """
    if field not in FIELD_TYPES:
        # Unknown fields are allowed
        return True, None

    expected_types = FIELD_TYPES[field]
    if not isinstance(expected_types, tuple):
        expected_types = (expected_types,)

    if not isinstance(value, expected_types):
        type_names = " or ".join(t.__name__ for t in expected_types)
        return False, f"Field '{field}' must be {type_names}, got {type(value).__name__}"

    return True, None


def validate_trace_id(trace_id: str, strict: bool = False) -> Tuple[str, Optional[str]]:
    """Validate and fix OTLP trace ID format.

    Args:
        trace_id: Trace ID to validate
        strict: If True, don't attempt to fix

    Returns:
        Tuple of (valid_trace_id, error_message)
    """
    if not trace_id:
        return "", "Trace ID is required"

    # Remove hyphens if present (UUID format)
    if "-" in trace_id and not strict:
        trace_id = trace_id.replace("-", "")

    # Validate format
    if not TRACE_ID_PATTERN.match(trace_id):
        if strict:
            return trace_id, f"Invalid trace_id format: must be 32 hex characters, got '{trace_id}'"
        # Try to fix by padding or truncating
        if len(trace_id) < 32:
            trace_id = trace_id.zfill(32)
        elif len(trace_id) > 32:
            trace_id = trace_id[:32]
        # Ensure all hex
        try:
            int(trace_id, 16)
        except ValueError:
            return trace_id, f"Invalid trace_id: contains non-hex characters"

    return trace_id, None


def validate_span_id(span_id: str, strict: bool = False) -> Tuple[str, Optional[str]]:
    """Validate and fix OTLP span ID format.

    Args:
        span_id: Span ID to validate
        strict: If True, don't attempt to fix

    Returns:
        Tuple of (valid_span_id, error_message)
    """
    if not span_id:
        return "", "Span ID is required"

    # Remove hyphens if present
    if "-" in span_id and not strict:
        span_id = span_id.replace("-", "")

    # Validate format
    if not SPAN_ID_PATTERN.match(span_id):
        if strict:
            return span_id, f"Invalid span_id format: must be 16 hex characters, got '{span_id}'"
        # Try to fix by padding or truncating
        if len(span_id) < 16:
            span_id = span_id.zfill(16)
        elif len(span_id) > 16:
            span_id = span_id[:16]
        # Ensure all hex
        try:
            int(span_id, 16)
        except ValueError:
            return span_id, f"Invalid span_id: contains non-hex characters"

    return span_id, None


def validate_otlp_timestamp(
    timestamp: Union[int, float], field_name: str
) -> Tuple[int, Optional[str]]:
    """Validate OTLP timestamp (should be int64 nanoseconds).

    Args:
        timestamp: Timestamp value
        field_name: Name of the field for error messages

    Returns:
        Tuple of (nanosecond_timestamp, error_message)
    """
    if not isinstance(timestamp, (int, float)):
        return 0, f"{field_name} must be numeric, got {type(timestamp).__name__}"

    # Check if it's already in nanoseconds (very large number)
    if timestamp > 1e15:  # Likely already nanoseconds
        return int(timestamp), None

    # Convert from seconds to nanoseconds
    return int(timestamp * 1_000_000_000), None


def validate_otlp_span(span_dict: Dict[str, Any], strict: bool = False) -> Dict[str, Any]:
    """Validate span for OTLP compliance with camelCase fields.

    Args:
        span_dict: Span dictionary in OTLP format (camelCase)
        strict: If True, raise on violations. If False, fix issues.

    Returns:
        OTLP-compliant span dictionary

    Raises:
        ValueError: If strict=True and validation fails
    """
    errors = []
    warnings = []

    # Support both snake_case and camelCase for compatibility
    trace_id_key = "traceId" if "traceId" in span_dict else "trace_id"
    span_id_key = "spanId" if "spanId" in span_dict else "span_id"
    parent_span_id_key = "parentSpanId" if "parentSpanId" in span_dict else "parent_span_id"

    # Validate trace_id
    if trace_id_key in span_dict:
        trace_id, error = validate_trace_id(span_dict[trace_id_key], strict)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        span_dict["traceId"] = trace_id
        if trace_id_key == "trace_id":
            del span_dict["trace_id"]
    else:
        error = "Missing required field: traceId"
        if strict:
            raise ValueError(error)
        errors.append(error)

    # Validate span_id
    if span_id_key in span_dict:
        span_id, error = validate_span_id(span_dict[span_id_key], strict)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        span_dict["spanId"] = span_id
        if span_id_key == "span_id":
            del span_dict["span_id"]
    else:
        error = "Missing required field: spanId"
        if strict:
            raise ValueError(error)
        errors.append(error)

    # Validate parent_span_id if present
    if parent_span_id_key in span_dict and span_dict[parent_span_id_key]:
        parent_id, error = validate_span_id(span_dict[parent_span_id_key], strict)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        span_dict["parentSpanId"] = parent_id
        if parent_span_id_key == "parent_span_id":
            del span_dict["parent_span_id"]

    # Validate timestamps (support both snake_case and camelCase)
    start_time_key = (
        "startTimeUnixNano" if "startTimeUnixNano" in span_dict else "start_time_unix_nano"
    )
    end_time_key = "endTimeUnixNano" if "endTimeUnixNano" in span_dict else "end_time_unix_nano"

    if start_time_key in span_dict:
        # Convert string to int for validation if needed
        start_val = span_dict[start_time_key]
        if isinstance(start_val, str):
            start_val = int(start_val)
        start_ns, error = validate_otlp_timestamp(start_val, start_time_key)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        # Store as string for OTLP JSON (64-bit int)
        span_dict["startTimeUnixNano"] = str(start_ns)
        if start_time_key == "start_time_unix_nano":
            del span_dict["start_time_unix_nano"]

    if end_time_key in span_dict:
        # Convert string to int for validation if needed
        end_val = span_dict[end_time_key]
        if isinstance(end_val, str):
            end_val = int(end_val)
        end_ns, error = validate_otlp_timestamp(end_val, end_time_key)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        # Store as string for OTLP JSON (64-bit int)
        span_dict["endTimeUnixNano"] = str(end_ns)
        if end_time_key == "end_time_unix_nano":
            del span_dict["end_time_unix_nano"]

    # Validate OTLP SpanKind
    if "kind" in span_dict:
        if span_dict["kind"] not in OTLP_SPAN_KINDS:
            error = f"Invalid OTLP SpanKind: {span_dict['kind']}"
            if strict:
                raise ValueError(error)
            warnings.append(error)
            span_dict["kind"] = "SPAN_KIND_INTERNAL"

    # Validate status
    if "status" in span_dict:
        if not isinstance(span_dict["status"], dict):
            error = "Status must be an object with 'code' field"
            if strict:
                raise ValueError(error)
            span_dict["status"] = {"code": "STATUS_CODE_UNSET"}
        elif "code" not in span_dict["status"]:
            error = "Status object missing 'code' field"
            if strict:
                raise ValueError(error)
            span_dict["status"]["code"] = "STATUS_CODE_UNSET"
        elif span_dict["status"]["code"] not in OTLP_STATUS_CODES:
            error = f"Invalid status code: {span_dict['status']['code']}"
            if strict:
                raise ValueError(error)
            span_dict["status"]["code"] = "STATUS_CODE_UNSET"

    # Validate attributes (now a list of typed key-value pairs)
    if "attributes" in span_dict:
        if isinstance(span_dict["attributes"], list):
            # Already in OTLP format (list of typed attributes)
            # Check attribute count
            if len(span_dict["attributes"]) > MAX_ATTRIBUTES:
                error = f"Too many attributes: {len(span_dict['attributes'])} > {MAX_ATTRIBUTES}"
                if strict:
                    raise ValueError(error)
                warnings.append(error)
                # Truncate to max
                span_dict["attributes"] = span_dict["attributes"][:MAX_ATTRIBUTES]

            # Validate typed attribute values
            for attr in span_dict["attributes"]:
                if "key" in attr and "value" in attr:
                    value_obj = attr["value"]
                    # Check string length in stringValue
                    if "stringValue" in value_obj:
                        str_val = value_obj["stringValue"]
                        if isinstance(str_val, str) and len(str_val) > MAX_STRING_LENGTH:
                            if strict:
                                raise ValueError(
                                    f"Attribute '{attr['key']}' string too long: {len(str_val)} > {MAX_STRING_LENGTH}"
                                )
                            value_obj["stringValue"] = str_val[:MAX_STRING_LENGTH]
                    # Check array length in arrayValue
                    elif "arrayValue" in value_obj:
                        arr_val = value_obj["arrayValue"].get("values", [])
                        if len(arr_val) > MAX_ARRAY_LENGTH:
                            if strict:
                                raise ValueError(
                                    f"Attribute '{attr['key']}' array too long: {len(arr_val)} > {MAX_ARRAY_LENGTH}"
                                )
                            value_obj["arrayValue"]["values"] = arr_val[:MAX_ARRAY_LENGTH]
        elif isinstance(span_dict["attributes"], dict):
            # Legacy format - convert to typed list
            typed_attrs = []
            for key, value in span_dict["attributes"].items():
                typed_attr = {"key": key}
                if isinstance(value, bool):
                    typed_attr["value"] = {"boolValue": value}
                elif isinstance(value, int):
                    typed_attr["value"] = {"intValue": str(value)}
                elif isinstance(value, float):
                    typed_attr["value"] = {"doubleValue": value}
                elif isinstance(value, str):
                    # Check string length
                    if len(value) > MAX_STRING_LENGTH:
                        if strict:
                            raise ValueError(
                                f"Attribute '{key}' string too long: {len(value)} > {MAX_STRING_LENGTH}"
                            )
                        value = value[:MAX_STRING_LENGTH]
                    typed_attr["value"] = {"stringValue": value}
                elif isinstance(value, list):
                    # Check array length
                    if len(value) > MAX_ARRAY_LENGTH:
                        if strict:
                            raise ValueError(
                                f"Attribute '{key}' array too long: {len(value)} > {MAX_ARRAY_LENGTH}"
                            )
                        value = value[:MAX_ARRAY_LENGTH]
                    typed_attr["value"] = {
                        "arrayValue": {"values": [{"stringValue": str(v)} for v in value]}
                    }
                else:
                    typed_attr["value"] = {"stringValue": str(value)}
                typed_attrs.append(typed_attr)

            # Check attribute count
            if len(typed_attrs) > MAX_ATTRIBUTES:
                error = f"Too many attributes: {len(typed_attrs)} > {MAX_ATTRIBUTES}"
                if strict:
                    raise ValueError(error)
                warnings.append(error)
                typed_attrs = typed_attrs[:MAX_ATTRIBUTES]

            span_dict["attributes"] = typed_attrs
        else:
            error = "Attributes must be a list or dictionary"
            if strict:
                raise ValueError(error)
            span_dict["attributes"] = []

    # Validate span name length
    if "name" in span_dict:
        if isinstance(span_dict["name"], str) and len(span_dict["name"]) > MAX_SPAN_NAME_LENGTH:
            if strict:
                raise ValueError(
                    f"Span name too long: {len(span_dict['name'])} > {MAX_SPAN_NAME_LENGTH}"
                )
            span_dict["name"] = span_dict["name"][:MAX_SPAN_NAME_LENGTH]

    # Validate events
    if "events" in span_dict:
        if not isinstance(span_dict["events"], list):
            error = "Events must be an array"
            if strict:
                raise ValueError(error)
            span_dict["events"] = []
        elif len(span_dict["events"]) > MAX_EVENTS:
            if strict:
                raise ValueError(f"Too many events: {len(span_dict['events'])} > {MAX_EVENTS}")
            span_dict["events"] = span_dict["events"][:MAX_EVENTS]

    # Log warnings
    if warnings and not strict:
        logger.debug(f"OTLP validation warnings: {'; '.join(warnings[:3])}")

    return span_dict


def validate(span_dict: Dict[str, Any], strict: bool = False) -> Dict[str, Any]:
    """Validate and normalize span data according to MVK v3.0 schema.

    This is the central validation function that enforces all schema rules:
    - Required fields
    - Field types
    - Span kind validation
    - Tag constraints
    - Attribute filtering per span kind

    Args:
        span_dict: Span data to validate
        strict: If True, raise ValueError on first violation.
                If False, drop invalid fields and log warnings.
                Can be overridden by MVK_STRICT_VALIDATION env var.

    Returns:
        Cleaned span dictionary

    Raises:
        ValueError: If strict=True and validation fails
    """
    # Check environment variable override
    if os.getenv("MVK_STRICT_VALIDATION", "").lower() in ("1", "true", "yes"):
        strict = True

    errors = []
    warnings = []
    cleaned: Dict[str, Any] = {}

    # Validate required fields
    for field in REQUIRED_FIELDS:
        if field not in span_dict:
            error = f"Missing required field: {field}"
            errors.append(error)
            if strict:
                raise ValueError(error)

    # Validate MVK span kind
    mvk_kind = span_dict.get("mvk.span.kind")
    if mvk_kind and mvk_kind not in [k.value for k in MVKSpanKind]:
        error = f"Invalid MVK span kind: {mvk_kind}"
        errors.append(error)
        if strict:
            raise ValueError(error)
        mvk_kind = None  # Drop invalid kind
        span_dict = dict(span_dict)  # Make a copy to avoid modifying original
        del span_dict["mvk.span.kind"]  # Remove invalid kind from the dict

    # Get allowed attributes for this MVK span kind
    if mvk_kind:
        try:
            mvk_kind_enum = MVKSpanKind(mvk_kind)
            allowed_attrs = MVK_SPAN_KIND_ATTRIBUTES.get(mvk_kind_enum, set())
        except ValueError:
            allowed_attrs = set()
    else:
        allowed_attrs = set()

    # Always allowed fields (v5.0)
    always_allowed = {
        # OTEL core
        "trace_id",
        "span_id",
        "parent_span_id",
        "start_time",
        "end_time",
        "duration_ms",
        "status_code",
        "status_message",
        # Service identity
        "service.name",
        "service.version",
        "service.namespace",
        "service.instance.id",
        # MVK context
        "mvk.agent.name",
        "mvk.span.kind",
        "session_id",
        "cloud_provider_code",
        "model_provider_code",
        "sdk",
        # Operation basics
        "kind",
        "name",
        # Special fields
        "tags",
        "vendor_attr",
        "events",
        "metered_usage",
        # Latency
        "e2e_latency_ms",
    }

    # Process all fields
    for field, value in span_dict.items():
        # Skip None values
        if value is None:
            continue

        # Validate field type
        is_valid, type_error = validate_field_type(field, value)
        if not is_valid:
            assert type_error is not None
            if strict:
                raise ValueError(type_error)
            warnings.append(type_error)
            continue

        # Check if field is allowed for this span kind
        if field not in always_allowed and field not in allowed_attrs:
            # Check if it's a custom field (starts with x- or vendor prefix)
            if not (field.startswith("x-") or field.startswith("vendor.")):
                warning = f"Field '{field}' not allowed for MVK span kind '{mvk_kind}'"
                if strict:
                    raise ValueError(warning)
                warnings.append(warning)
                continue

        # Add to cleaned dict
        cleaned[field] = value

    # Validate and clean tags
    if "tags" in cleaned:
        tags = cleaned["tags"]
        # Handle JSON string
        if isinstance(tags, str):
            import json

            try:
                tags = json.loads(tags)
            except json.JSONDecodeError:
                error = "Invalid JSON in tags field"
                if strict:
                    raise ValueError(error)
                warnings.append(error)
                tags = {}

        valid_tags, tag_errors = validate_tags(tags)
        if tag_errors:
            if strict:
                raise ValueError(f"Tag validation failed: {'; '.join(tag_errors)}")
            warnings.extend(tag_errors)

        cleaned["tags"] = valid_tags

    # Calculate duration if not present
    if "start_time" in cleaned and "end_time" in cleaned and "duration_ms" not in cleaned:
        cleaned["duration_ms"] = (cleaned["end_time"] - cleaned["start_time"]) * 1000

    # Log warnings in non-strict mode
    if warnings and not strict:
        logger.debug(f"Schema validation warnings: {'; '.join(warnings[:3])}")

    return cleaned


def validate_span_for_export(span: Any) -> Dict[str, Any]:
    """Convert a Span object to validated dictionary for export.

    Args:
        span: Span object from tracer

    Returns:
        Validated span dictionary ready for export
    """
    # Extract span data
    span_dict = {
        "trace_id": span.context.trace_id,
        "span_id": span.context.span_id,
        "parent_span_id": span.context.parent_span_id,
        "start_time": span.start_time,
        "end_time": span.end_time or span.start_time,
        "name": span.name,
        "status_code": span._status.status_code.value,
    }

    if span._status.description:
        span_dict["status_message"] = span._status.description

    # Add attributes
    span_dict.update(span._attributes)

    # Add events if any
    if span._events:
        span_dict["events"] = span._events

    # Validate and return
    return validate(span_dict, strict=False)


def get_mvk_kind_for_name(name: str) -> str:
    """Infer MVK span kind from span name.

    Args:
        name: Span name

    Returns:
        Inferred MVK span kind
    """
    name_lower = name.lower()

    # LLM operations (check first as they're most specific)
    if any(x in name_lower for x in ["chat", "completion", "generate", "llm", "gpt", "claude"]):
        return MVKSpanKind.LLM

    # Embedding operations (check before retriever since "embed" is more specific than "vector")
    if any(x in name_lower for x in ["embed", "encoding", "encode"]):
        return MVKSpanKind.EMBEDDING

    # Retriever operations (check before general patterns)
    if any(x in name_lower for x in ["search", "retrieve", "query", "find", "lookup"]):
        return MVKSpanKind.RETRIEVER

    # Memory operations
    if any(x in name_lower for x in ["memory", "cache", "store", "load", "save"]):
        return MVKSpanKind.MEMORY

    # Check for "vector" last as it could be embedding or retriever
    if "vector" in name_lower:
        # If it has encoding/embed context, it's embedding
        if any(x in name_lower for x in ["encod", "embed"]):
            return MVKSpanKind.EMBEDDING
        # Otherwise assume retriever
        return MVKSpanKind.RETRIEVER

    # Tool operations
    if any(x in name_lower for x in ["tool", "function", "call", "execute", "api"]):
        return MVKSpanKind.TOOL

    # Default to TOOL for unknown
    return MVKSpanKind.AGENT_CALL


def to_wire_format(span_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Convert span to wire format with null field omission (v5.0).

    This function:
    1. Omits all None/null fields
    2. Ensures required fields are present
    3. Converts complex types to JSON strings for BigQuery
    4. Reduces span size by ~70%

    Args:
        span_dict: Validated span dictionary

    Returns:
        Wire format dictionary with nulls omitted
    """
    import json

    wire = {}

    # Process all fields, omitting nulls
    for field, value in span_dict.items():
        if value is None:
            continue

        # Convert complex types to JSON strings for BigQuery
        if field in ("tags", "vendor_attr", "events", "metered_usage"):
            if isinstance(value, (dict, list)):
                value = json.dumps(value)

        wire[field] = value

    # Ensure required fields are present
    for field in REQUIRED_FIELDS:
        if field not in wire:
            # Set defaults for missing required fields
            if field == "parent_span_id":
                wire[field] = "0" * 16  # Root span
            elif field == "status_code":
                wire[field] = 0  # Unset
            elif field == "duration_ms":
                wire[field] = 0.0
            elif field not in wire:
                logger.warning(f"Required field {field} missing in wire format")

    return wire


# Field mutability rules for v5.0
FIELD_MUTABILITY = {
    # Immutable - cannot be set by user
    "immutable": {
        "trace_id",
        "span_id",
        "parent_span_id",
        "start_time",
        "end_time",
        "duration_ms",
        "service.instance.id",
    },
    # Set only in mvk.instrument()
    "instrument_only": {"service.name", "service.version", "service.namespace"},
    # Set only in @mvk.track or mvk.create_span
    "span_only": {"mvk.span.kind", "operation", "operation_subtype", "cloud_provider_code", "name"},
    # Can be set in @mvk.context or @mvk.track
    "context_or_span": {"tags", "session_id"},
    # Auto-discovered, not user-settable
    "auto_only": {
        "model_provider_code",
        "sdk",
        "prompt_tokens",
        "completion_tokens",
        "total_tokens",
        "embeddings_count",
        "embedding_dims",
        "db_rows_affected",
        "bytes_read",
        "bytes_written",
        "time_to_first_token_ms",
        "e2e_latency_ms",
    },
}


def check_field_mutability(field: str, context: str) -> bool:
    """Check if a field can be set in the given context.

    Args:
        field: Field name
        context: Where the field is being set ("instrument", "context", "span", "auto")

    Returns:
        True if field can be set in this context
    """
    if field in FIELD_MUTABILITY["immutable"]:
        return False

    if context == "instrument":
        return field in FIELD_MUTABILITY["instrument_only"]
    elif context == "context":
        return field in FIELD_MUTABILITY["context_or_span"]
    elif context == "span":
        return field in (FIELD_MUTABILITY["span_only"] | FIELD_MUTABILITY["context_or_span"])
    elif context == "auto":
        return field in FIELD_MUTABILITY["auto_only"]

    # Unknown fields can be set anywhere (for extensibility)
    return True
