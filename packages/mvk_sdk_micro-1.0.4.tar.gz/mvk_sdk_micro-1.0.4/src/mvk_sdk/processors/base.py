"""Base processor interface for MVK SDK v4.0."""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class SpanProcessor(ABC):
    """Abstract base class for span processors.

    Processors handle span batching and orchestrate export.
    All methods must be thread-safe.
    """

    @abstractmethod
    def on_start(self, span: Any) -> None:
        """Called when a span starts.

        This method MUST NOT block or perform I/O.

        Args:
            span: The span that started
        """
        pass

    @abstractmethod
    def on_end(self, span_dict: Dict[str, Any]) -> None:
        """Called when a span ends.

        This method MUST NOT block for long. Queue the span
        for export if using batching.

        Args:
            span_dict: The completed span as a dictionary
        """
        pass

    @abstractmethod
    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force export of all pending spans.

        This method may block up to timeout_millis.

        Args:
            timeout_millis: Maximum time to wait in milliseconds

        Returns:
            True if all spans were exported within timeout
        """
        pass

    @abstractmethod
    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the processor and export remaining spans.

        This method should be idempotent - multiple calls should be safe.

        Args:
            timeout_millis: Maximum time to wait in milliseconds
        """
        pass
