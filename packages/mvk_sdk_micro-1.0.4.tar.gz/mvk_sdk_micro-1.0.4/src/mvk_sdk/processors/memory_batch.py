"""Memory batch span processor for MVK SDK v4.0."""

import logging
import queue
import threading
import time
from typing import Any, Dict, Optional

from ..exporters.base import SpanExporter
from .base import SpanProcessor

logger = logging.getLogger(__name__)


class MemoryBatchSpanProcessor(SpanProcessor):
    """Batches spans in memory before exporting.

    Spans are queued in memory and exported when:
    - The batch size is reached
    - The export interval expires
    - force_flush() is called
    - shutdown() is called

    Lost on process crash (no persistence).

    Thread Safety:
    - Uses thread-safe queue for span collection
    - Background thread for export
    - Locks protect shared state
    """

    def __init__(
        self,
        exporter: SpanExporter,
        max_queue_size: int = 2048,
        batch_size: int = 512,
        export_interval_secs: float = 5.0,
        max_export_batch_size: int = 512,
    ):
        """Initialize memory batch processor.

        Args:
            exporter: The exporter to use for sending spans
            max_queue_size: Maximum spans to queue in memory
            batch_size: Number of spans to trigger export
            export_interval_secs: Max time between exports
            max_export_batch_size: Maximum spans per export call
        """
        self.exporter = exporter
        self.max_queue_size = max_queue_size
        self.batch_size = batch_size
        self.export_interval_secs = export_interval_secs
        self.max_export_batch_size = max_export_batch_size

        # Thread-safe queue for spans
        self._queue: queue.Queue[Dict[str, Any]] = queue.Queue(maxsize=max_queue_size)

        # Thread synchronization
        self._lock = threading.RLock()  # Reentrant lock
        self._shutdown_event = threading.Event()
        self._force_flush_event = threading.Event()
        self._export_thread: Optional[threading.Thread] = None
        self._shutdown = False

        # Statistics
        self.stats = {"received": 0, "exported": 0, "dropped": 0, "failed": 0}

        # Start export thread
        self._start_export_thread()

    def _start_export_thread(self) -> None:
        """Start the background export thread."""
        self._export_thread = threading.Thread(
            target=self._export_loop, name="MemoryBatchExporter", daemon=True
        )
        self._export_thread.start()
        logger.info("Memory batch export thread started")

    def on_start(self, span: Any) -> None:
        """No-op for batch processor.

        Args:
            span: The span that started (unused)
        """
        pass

    def on_end(self, span_dict: Dict[str, Any]) -> None:
        """Add span to queue for batching.

        Args:
            span_dict: The completed span as a dictionary
        """
        if self._shutdown:
            return

        try:
            # Try to add to queue (non-blocking)
            self._queue.put_nowait(span_dict)

            with self._lock:
                self.stats["received"] += 1

            # Check if we should trigger export
            if self._queue.qsize() >= self.batch_size:
                self._force_flush_event.set()

        except queue.Full:
            # Queue is full, drop the span
            with self._lock:
                self.stats["dropped"] += 1
            logger.warning(f"Span queue full ({self.max_queue_size}), dropping span")

    def _export_loop(self) -> None:
        """Background thread that exports batches."""
        last_export_time = time.time()

        while not self._shutdown_event.is_set():
            try:
                # Calculate wait time
                time_since_export = time.time() - last_export_time
                timeout = self.export_interval_secs - time_since_export

                if timeout > 0:
                    # Wait for timeout or force flush
                    triggered = self._force_flush_event.wait(timeout=timeout)
                    if triggered:
                        logger.debug("Export triggered by force flush")

                # Clear the force flush flag
                self._force_flush_event.clear()

                # Collect batch from queue
                batch = []
                for _ in range(self.max_export_batch_size):
                    try:
                        span = self._queue.get_nowait()
                        batch.append(span)
                    except queue.Empty:
                        break

                # Export batch if we have spans
                if batch:
                    try:
                        # Exporter handles retry internally
                        success = self.exporter.export(batch)

                        with self._lock:
                            if success:
                                self.stats["exported"] += len(batch)
                                logger.debug(f"Exported batch of {len(batch)} spans")
                            else:
                                self.stats["failed"] += len(batch)
                                logger.warning(f"Failed to export batch of {len(batch)} spans")

                    except Exception as e:
                        logger.error(f"Export exception: {e}", exc_info=True)
                        with self._lock:
                            self.stats["failed"] += len(batch)

                last_export_time = time.time()

            except Exception as e:
                logger.error(f"Error in export loop: {e}", exc_info=True)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force export of all pending spans.

        Args:
            timeout_millis: Maximum time to wait in milliseconds

        Returns:
            True if all spans were exported within timeout
        """
        if self._shutdown:
            return False

        # Trigger export
        self._force_flush_event.set()

        # Wait for queue to empty
        start_time = time.time()
        timeout_secs = timeout_millis / 1000.0

        while time.time() - start_time < timeout_secs:
            if self._queue.empty():
                return True
            time.sleep(0.01)

        return False

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the processor and export remaining spans.

        Args:
            timeout_millis: Maximum time to wait in milliseconds
        """
        with self._lock:
            if self._shutdown:
                return
            self._shutdown = True

        logger.info("Shutting down memory batch processor")

        # Force flush remaining spans
        self.force_flush(timeout_millis // 2)

        # Stop export thread
        self._shutdown_event.set()
        if self._export_thread and self._export_thread.is_alive():
            self._export_thread.join(timeout=timeout_millis / 2000.0)
            if self._export_thread.is_alive():
                logger.warning("Export thread did not stop within timeout")

        # Shutdown exporter
        try:
            self.exporter.shutdown()
        except Exception as e:
            logger.error(f"Error shutting down exporter: {e}")

        # Log final statistics
        logger.info(
            f"MemoryBatchSpanProcessor shutdown - "
            f"received: {self.stats['received']}, "
            f"exported: {self.stats['exported']}, "
            f"dropped: {self.stats['dropped']}, "
            f"failed: {self.stats['failed']}"
        )
