"""Factory for creating processors and exporters from configuration."""

import logging
from typing import Any, Dict, Optional

from ..exporters.base import SpanExporter
from ..exporters.console import ConsoleExporter
from ..exporters.file import FileExporter
from ..exporters.http import HTTPExporter
from ..exporters.otlp import OTLPExporter
from ..wal import DiskWAL, MemoryWAL
from .base import SpanProcessor
from .direct import DirectSpanProcessor
from .memory_batch import MemoryBatchSpanProcessor
from .wal_batch import WALBatchSpanProcessor

logger = logging.getLogger(__name__)


class ProcessorFactory:
    """Factory for creating processors and exporters from configuration."""

    @staticmethod
    def create_from_config(config: Dict[str, Any]) -> SpanProcessor:
        """Create a processor from configuration.

        Args:
            config: Configuration dictionary with processor, exporter, and WAL settings

        Returns:
            Configured SpanProcessor instance

        Raises:
            ValueError: If configuration is invalid
        """
        # Create exporter first
        exporter_config = config.get("exporter", {})
        exporter = ProcessorFactory.create_exporter(exporter_config)

        # Create processor with exporter
        processor_config = config.get("processor", {})
        processor_type = processor_config.get("type", "memory_batch")

        if processor_type == "direct":
            return DirectSpanProcessor(exporter)

        elif processor_type == "memory_batch":
            return MemoryBatchSpanProcessor(
                exporter=exporter,
                max_queue_size=processor_config.get("max_queue_size", 2048),
                batch_size=processor_config.get("batch_size", 512),
                export_interval_secs=processor_config.get("export_interval_secs", 5.0),
                max_export_batch_size=processor_config.get("max_export_batch_size", 512),
            )

        elif processor_type == "wal_batch":
            # Create WAL
            wal_config = config.get("wal", {})
            wal = ProcessorFactory.create_wal(wal_config)

            return WALBatchSpanProcessor(
                exporter=exporter,
                wal=wal,
                batch_size=processor_config.get("batch_size", 512),
                export_interval_secs=processor_config.get("export_interval_secs", 5.0),
                max_export_batch_size=processor_config.get("max_export_batch_size", 512),
                max_age_hours=wal_config.get("max_age_hours", 12.0),
            )

        else:
            raise ValueError(f"Unknown processor type: {processor_type}")

    @staticmethod
    def create_exporter(config: Dict[str, Any]) -> SpanExporter:
        """Create an exporter from configuration.

        Args:
            config: Exporter configuration

        Returns:
            Configured SpanExporter instance

        Raises:
            ValueError: If configuration is invalid
        """
        exporter_type = config.get("type", "console")

        if exporter_type == "console":
            return ConsoleExporter(
                output=config.get("output", "stdout"),
                format=config.get("format", "json"),
                pretty=config.get("pretty", False),
            )

        elif exporter_type == "file":
            return FileExporter(
                directory=config.get("directory", "/tmp/mvk/spans"),
                filename_prefix=config.get("filename_prefix", "spans"),
                max_file_size_mb=config.get("max_file_size_mb", 100),
                max_files=config.get("max_files", 5),
                compress_rotated=config.get("compress_rotated", False),
            )

        elif exporter_type == "http":
            # Extract retry configuration
            retry_config = config.get("retry", {})

            return HTTPExporter(
                endpoint=config.get("endpoint", "https://api.mavvrik.ai"),
                api_key=config.get("api_key", ""),
                fallback_endpoint=config.get("fallback_endpoint"),
                timeout_secs=config.get("timeout_secs", 30),
                max_batch_size=config.get("max_batch_size", 1000),
                compress=config.get("compress", True),
                # Retry settings
                max_retry_hours=retry_config.get("max_retry_hours", 4.0),
                initial_retry_interval_secs=retry_config.get("initial_interval_secs", 1.0),
                max_retry_interval_secs=retry_config.get("max_interval_secs", 300),
                max_fast_retries=retry_config.get("max_fast_retries", 10),
            )

        elif exporter_type == "otlp":
            # Extract retry configuration
            retry_config = config.get("retry", {})

            return OTLPExporter(
                endpoint=config.get("endpoint", "localhost:4317"),
                protocol=config.get("protocol", "grpc"),
                headers=config.get("headers", {}),
                insecure=config.get("insecure", True),
                timeout_secs=config.get("timeout_secs", 10),
                compression=config.get("compression", "gzip"),
                # Retry settings
                max_retry_hours=retry_config.get("max_retry_hours", 4.0),
                initial_retry_interval_secs=retry_config.get("initial_interval_secs", 1.0),
                max_retry_interval_secs=retry_config.get("max_interval_secs", 300),
                max_fast_retries=retry_config.get("max_fast_retries", 10),
            )

        else:
            raise ValueError(f"Unknown exporter type: {exporter_type}")

    @staticmethod
    def create_wal(config: Dict[str, Any]) -> Any:
        """Create a WAL from configuration.

        Args:
            config: WAL configuration

        Returns:
            Configured WAL instance

        Raises:
            ValueError: If configuration is invalid
        """
        wal_type = config.get("type", "memory")

        if wal_type == "memory":
            return MemoryWAL(max_items=config.get("max_items", 10000))

        elif wal_type == "disk":
            return DiskWAL(path=config.get("path", "/var/tmp/mvk"))

        else:
            raise ValueError(f"Unknown WAL type: {wal_type}")

    @staticmethod
    def create_default() -> SpanProcessor:
        """Create a default processor for development.

        Returns:
            A DirectSpanProcessor with ConsoleExporter
        """
        exporter = ConsoleExporter(format="simple", pretty=True)
        return DirectSpanProcessor(exporter)
