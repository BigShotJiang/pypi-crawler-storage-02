"""Direct span processor for MVK SDK v4.0."""

import logging
import threading
from typing import Any, Dict

from ..exporters.base import SpanExporter
from .base import SpanProcessor

logger = logging.getLogger(__name__)


class DirectSpanProcessor(SpanProcessor):
    """Exports each span immediately without batching.

    This processor is synchronous - it blocks until the span is exported.
    Useful for debugging and low-volume scenarios.

    Thread Safety: Uses lock to protect statistics.
    """

    def __init__(self, exporter: SpanExporter):
        """Initialize direct processor.

        Args:
            exporter: The exporter to use for sending spans
        """
        self.exporter = exporter
        self._lock = threading.Lock()
        self._shutdown = False

        # Statistics
        self.stats = {"received": 0, "exported": 0, "failed": 0}

    def on_start(self, span: Any) -> None:
        """No-op for direct processor.

        Args:
            span: The span that started (unused)
        """
        pass

    def on_end(self, span_dict: Dict[str, Any]) -> None:
        """Export span immediately.

        This method blocks until the span is exported.

        Args:
            span_dict: The completed span as a dictionary
        """
        if self._shutdown:
            return

        with self._lock:
            self.stats["received"] += 1

        # Export synchronously (exporter handles retry)
        try:
            success = self.exporter.export([span_dict])

            with self._lock:
                if success:
                    self.stats["exported"] += 1
                else:
                    self.stats["failed"] += 1

        except Exception as e:
            logger.error(f"Failed to export span: {e}")
            with self._lock:
                self.stats["failed"] += 1

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """No-op for direct processor.

        Direct processor exports immediately, so there's nothing to flush.

        Args:
            timeout_millis: Timeout (unused)

        Returns:
            Always True
        """
        return True

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the processor.

        Args:
            timeout_millis: Timeout (unused for direct processor)
        """
        with self._lock:
            if self._shutdown:
                return
            self._shutdown = True

        # Shutdown exporter
        try:
            self.exporter.shutdown()
        except Exception as e:
            logger.error(f"Error shutting down exporter: {e}")

        # Log final statistics
        logger.info(
            f"DirectSpanProcessor shutdown - "
            f"received: {self.stats['received']}, "
            f"exported: {self.stats['exported']}, "
            f"failed: {self.stats['failed']}"
        )
