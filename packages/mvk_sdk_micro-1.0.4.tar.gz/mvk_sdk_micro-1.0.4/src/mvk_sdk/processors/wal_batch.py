"""WAL batch span processor for MVK SDK v4.0."""

import json
import logging
import threading
import time
from typing import Any, Dict, Optional

from ..exporters.base import SpanExporter
from ..wal.base import WALBase
from .base import SpanProcessor

logger = logging.getLogger(__name__)


class WALBatchSpanProcessor(SpanProcessor):
    """Batches spans using Write-Ahead Log for persistence.

    Spans are persisted to WAL immediately, then exported in batches.
    Survives process crashes and restarts.

    Thread Safety:
    - WAL handles its own thread safety
    - Background thread for export
    - Locks protect shared state
    """

    def __init__(
        self,
        exporter: SpanExporter,
        wal: WALBase,
        batch_size: int = 512,
        export_interval_secs: float = 5.0,
        max_export_batch_size: int = 512,
        max_age_hours: float = 12.0,
    ):
        """Initialize WAL batch processor.

        Args:
            exporter: The exporter to use for sending spans
            wal: Write-Ahead Log for persistence
            batch_size: Number of spans to trigger export
            export_interval_secs: Max time between exports
            max_export_batch_size: Maximum spans per export call
            max_age_hours: Maximum age before dropping spans
        """
        self.exporter = exporter
        self.wal = wal
        self.batch_size = batch_size
        self.export_interval_secs = export_interval_secs
        self.max_export_batch_size = max_export_batch_size
        self.max_age_seconds = max_age_hours * 3600

        # Thread synchronization
        self._lock = threading.RLock()
        self._shutdown_event = threading.Event()
        self._force_flush_event = threading.Event()
        self._export_thread: Optional[threading.Thread] = None
        self._shutdown = False

        # Statistics
        self.stats = {
            "received": 0,
            "exported": 0,
            "dropped": 0,
            "failed": 0,
            "wal_write_failures": 0,
            "expired": 0,
        }

        # Track pending spans for triggering export
        self._pending_count = 0

        # Start export thread
        self._start_export_thread()

    def _start_export_thread(self) -> None:
        """Start the background export thread."""
        self._export_thread = threading.Thread(
            target=self._export_loop, name="WALBatchExporter", daemon=True
        )
        self._export_thread.start()
        logger.info("WAL batch export thread started")

    def on_start(self, span: Any) -> None:
        """No-op for batch processor.

        Args:
            span: The span that started (unused)
        """
        pass

    def on_end(self, span_dict: Dict[str, Any]) -> None:
        """Write span to WAL.

        Args:
            span_dict: The completed span as a dictionary
        """
        if self._shutdown:
            return

        try:
            # Serialize and write to WAL
            span_bytes = json.dumps(span_dict).encode("utf-8")
            self.wal.append(span_bytes)

            with self._lock:
                self.stats["received"] += 1
                self._pending_count += 1

            # Check if we should trigger export
            if self._pending_count >= self.batch_size:
                self._force_flush_event.set()

        except Exception as e:
            # NO RETRY - Fail fast on storage errors
            logger.error(f"WAL write failed: {e}")
            with self._lock:
                self.stats["wal_write_failures"] += 1
                self.stats["dropped"] += 1

    def _export_loop(self) -> None:
        """Background thread that exports batches from WAL."""
        last_export_time = time.time()
        last_cleanup_time = time.time()
        cleanup_interval = 60.0  # Clean up expired spans every minute

        while not self._shutdown_event.is_set():
            try:
                # Calculate wait time
                time_since_export = time.time() - last_export_time
                timeout = self.export_interval_secs - time_since_export

                if timeout > 0:
                    # Wait for timeout or force flush
                    triggered = self._force_flush_event.wait(timeout=timeout)
                    if triggered:
                        logger.debug("Export triggered by force flush")

                # Clear the force flush flag
                self._force_flush_event.clear()

                # Clean up expired spans periodically
                if time.time() - last_cleanup_time > cleanup_interval:
                    expired = self.wal.clear_expired(int(self.max_age_seconds))
                    if expired > 0:
                        with self._lock:
                            self.stats["expired"] += expired
                        logger.info(f"Cleared {expired} expired spans from WAL")
                    last_cleanup_time = time.time()

                # Read batch from WAL
                batch_bytes = self.wal.read_batch(self.max_export_batch_size)

                if batch_bytes:
                    # Deserialize spans
                    batch = []
                    for span_bytes in batch_bytes:
                        try:
                            span = json.loads(span_bytes.decode("utf-8"))
                            batch.append(span)
                        except Exception as e:
                            logger.error(f"Failed to deserialize span from WAL: {e}")

                    # Export batch if we have valid spans
                    if batch:
                        try:
                            # Exporter handles retry internally
                            success = self.exporter.export(batch)

                            if success:
                                # Acknowledge successful export
                                self.wal.acknowledge(batch_bytes)

                                with self._lock:
                                    self.stats["exported"] += len(batch)
                                    self._pending_count = max(0, self._pending_count - len(batch))
                                logger.debug(f"Exported batch of {len(batch)} spans from WAL")
                            else:
                                # Export failed after retries, acknowledge to remove from WAL
                                # This prevents infinite retry of permanently failed spans
                                self.wal.acknowledge(batch_bytes)

                                with self._lock:
                                    self.stats["failed"] += len(batch)
                                    self._pending_count = max(0, self._pending_count - len(batch))
                                logger.warning(
                                    f"Failed to export batch of {len(batch)} spans, removed from WAL"
                                )

                        except Exception as e:
                            logger.error(f"Export exception: {e}", exc_info=True)
                            # Acknowledge to prevent infinite retry
                            self.wal.acknowledge(batch_bytes)
                            with self._lock:
                                self.stats["failed"] += len(batch)
                                self._pending_count = max(0, self._pending_count - len(batch))

                last_export_time = time.time()

            except Exception as e:
                logger.error(f"Error in WAL export loop: {e}", exc_info=True)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force export of all pending spans.

        Args:
            timeout_millis: Maximum time to wait in milliseconds

        Returns:
            True if all spans were exported within timeout
        """
        if self._shutdown:
            return False

        # Trigger export
        self._force_flush_event.set()

        # Wait for WAL to be empty
        start_time = time.time()
        timeout_secs = timeout_millis / 1000.0

        while time.time() - start_time < timeout_secs:
            if self.wal.size() == 0:
                return True
            time.sleep(0.1)

        return False

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the processor and export remaining spans.

        Args:
            timeout_millis: Maximum time to wait in milliseconds
        """
        with self._lock:
            if self._shutdown:
                return
            self._shutdown = True

        logger.info("Shutting down WAL batch processor")

        # Force flush remaining spans
        self.force_flush(timeout_millis // 2)

        # Stop export thread
        self._shutdown_event.set()
        if self._export_thread and self._export_thread.is_alive():
            self._export_thread.join(timeout=timeout_millis / 2000.0)
            if self._export_thread.is_alive():
                logger.warning("WAL export thread did not stop within timeout")

        # Shutdown exporter
        try:
            self.exporter.shutdown()
        except Exception as e:
            logger.error(f"Error shutting down exporter: {e}")

        # Log final statistics
        logger.info(
            f"WALBatchSpanProcessor shutdown - "
            f"received: {self.stats['received']}, "
            f"exported: {self.stats['exported']}, "
            f"dropped: {self.stats['dropped']}, "
            f"failed: {self.stats['failed']}, "
            f"WAL write failures: {self.stats['wal_write_failures']}, "
            f"expired: {self.stats['expired']}"
        )
