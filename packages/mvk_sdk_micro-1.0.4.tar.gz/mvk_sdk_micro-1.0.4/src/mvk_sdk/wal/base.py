"""Base class for Write-Ahead Log implementations."""

import time
from abc import ABC, abstractmethod
from typing import List, Optional


class WALBase(ABC):
    """Abstract base class for WAL implementations."""

    @abstractmethod
    def append(self, span_data: bytes) -> None:
        """Append span data to WAL.

        Args:
            span_data: Serialized span data
        """
        pass

    @abstractmethod
    def read_batch(self, max_items: int) -> List[bytes]:
        """Read a batch of spans for export.

        Args:
            max_items: Maximum number of items to read

        Returns:
            List of serialized span data
        """
        pass

    @abstractmethod
    def acknowledge(self, items: List[bytes]) -> None:
        """Mark items as successfully exported.

        Args:
            items: Items to acknowledge
        """
        pass

    @abstractmethod
    def size(self) -> int:
        """Get current number of items in WAL.

        Returns:
            Number of pending items
        """
        pass

    @abstractmethod
    def clear_expired(self, max_age_seconds: int) -> int:
        """Remove items older than max age.

        Args:
            max_age_seconds: Maximum age in seconds

        Returns:
            Number of items removed
        """
        pass

    def shutdown(self) -> None:
        """Shutdown WAL and cleanup resources.

        Default implementation does nothing.
        Override in implementations that need cleanup.
        """
        pass

    def wait_for_writes(self, timeout: float = 5.0) -> bool:
        """Wait for pending writes to complete.

        Args:
            timeout: Maximum time to wait in seconds

        Returns:
            True if writes completed, False if timeout

        Default implementation returns True immediately.
        Override in async implementations.
        """
        return True
