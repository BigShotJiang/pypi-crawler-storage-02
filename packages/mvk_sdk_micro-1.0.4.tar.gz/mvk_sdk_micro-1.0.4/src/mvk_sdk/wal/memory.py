"""Memory-based WAL implementation for MVK SDK."""

import logging
import threading
import time
from collections import deque
from typing import List, Tuple

from .base import WALBase

logger = logging.getLogger(__name__)


class MemoryWAL(WALBase):
    """In-memory WAL using deque for efficiency."""

    def __init__(self, max_items: int = 10000):
        """Initialize memory WAL.

        Args:
            max_items: Maximum items to store before dropping oldest
        """
        self.max_items = max_items
        self._items: deque = deque()  # No maxlen - we'll manage it manually
        self._lock = threading.Lock()
        self._pending: List[Tuple[bytes, float]] = []  # (data, timestamp)
        self._drop_count = 0  # Track dropped items

    def append(self, span_data: bytes) -> None:
        """Append span to memory WAL."""
        with self._lock:
            # Check if we're at capacity
            if len(self._items) >= self.max_items:
                # Drop oldest item and log warning
                dropped = self._items.popleft()
                self._drop_count += 1
                if self._drop_count % 100 == 1:  # Log every 100 drops
                    logger.warning(
                        f"MemoryWAL at capacity ({self.max_items}). "
                        f"Dropped {self._drop_count} items total."
                    )

            self._items.append((span_data, time.time()))

    def read_batch(self, max_items: int) -> List[bytes]:
        """Read batch of spans for export."""
        with self._lock:
            # Move items to pending list
            batch = []
            for _ in range(min(max_items, len(self._items))):
                if self._items:
                    item = self._items.popleft()
                    self._pending.append(item)
                    batch.append(item[0])  # Just the data, not timestamp
            return batch

    def acknowledge(self, items: List[bytes]) -> None:
        """Remove acknowledged items from pending."""
        with self._lock:
            # Remove acknowledged items from pending
            item_set = set(items)
            self._pending = [(data, ts) for data, ts in self._pending if data not in item_set]

    def size(self) -> int:
        """Get total items in WAL."""
        with self._lock:
            return len(self._items) + len(self._pending)

    def clear_expired(self, max_age_seconds: int) -> int:
        """Remove old items from WAL."""
        with self._lock:
            cutoff_time = time.time() - max_age_seconds

            # Remove expired from main queue
            removed = 0
            while self._items and self._items[0][1] < cutoff_time:
                self._items.popleft()
                removed += 1

            # Remove expired from pending
            original_pending = len(self._pending)
            self._pending = [(data, ts) for data, ts in self._pending if ts >= cutoff_time]
            removed += original_pending - len(self._pending)

            return removed
