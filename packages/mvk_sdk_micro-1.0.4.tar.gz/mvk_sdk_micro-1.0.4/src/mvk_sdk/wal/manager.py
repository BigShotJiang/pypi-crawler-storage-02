"""WAL manager that coordinates WAL operations and background export."""

import logging
import random
import threading
import time
from typing import Any, Callable, List, Optional

from ..circuit_breaker import (
    check_circuit_breakers,
    get_export_circuit,
    get_memory_circuit,
)
from .base import WALBase

logger = logging.getLogger(__name__)


class WALManager:
    """Manages WAL operations and background export thread."""

    def __init__(
        self,
        wal: WALBase,
        exporter: Optional[Callable[[List[bytes]], bool]] = None,
        flush_interval_secs: int = 2,
        batch_size: int = 250,
        max_age_hours: int = 12,
        max_retry_hours: float = 4.0,
        max_retry_interval_secs: int = 300,
        initial_retry_interval_secs: float = 1.0,
        max_fast_retries: int = 10,
    ):
        """Initialize WAL manager.

        Args:
            wal: WAL implementation to use
            exporter: Function to export batches, returns True on success
            flush_interval_secs: How often to export batches
            batch_size: Maximum items per export batch
            max_age_hours: Maximum age before dropping spans
            max_retry_hours: Maximum time to keep retrying exports (default 4 hours)
            max_retry_interval_secs: Maximum interval between retries (default 5 minutes)
            initial_retry_interval_secs: Initial retry interval (default 1s, per OTEL standards)
            max_fast_retries: Number of fast retries before switching to long-term (default 10)
        """
        self.wal = wal
        self.exporter = exporter
        self.flush_interval_secs = flush_interval_secs
        self.batch_size = batch_size
        self.max_age_seconds = max_age_hours * 3600
        self.max_retry_seconds = max_retry_hours * 3600
        self.max_retry_interval = max_retry_interval_secs
        self.initial_retry_interval = initial_retry_interval_secs
        self.max_fast_retries = max_fast_retries

        # Statistics
        self.stats = {
            "appended": 0,
            "exported": 0,
            "expired": 0,
            "failed": 0,
            "export_errors": 0,
            "retries": 0,
            "dropped_max_retries": 0,
        }

        # Track retry state for current batch
        self._current_batch_start_time: Optional[float] = None
        self._current_batch_retry_count = 0

        # Background thread
        self._shutdown = threading.Event()
        self._running = True
        self._export_thread = threading.Thread(
            target=self._export_loop,
            name="WALExporter",
            daemon=True,  # Daemon thread to avoid blocking process exit
        )
        self._export_thread.start()

        # Register cleanup on interpreter shutdown
        import weakref

        self._finalizer = weakref.finalize(
            self, self._emergency_shutdown, self._shutdown, self._export_thread
        )

    def append(self, span_data: bytes) -> None:
        """Append span to WAL."""
        # Check circuit breakers
        if not check_circuit_breakers():
            logger.warning("Circuit breaker open, dropping span")
            self.stats["failed"] += 1
            return

        try:
            self.wal.append(span_data)
            self.stats["appended"] += 1
        except Exception as e:
            logger.error(f"Failed to append to WAL: {e}")
            self.stats["failed"] += 1

    def _export_loop(self) -> None:
        """Background thread that exports spans from WAL."""
        logger.info("WAL export thread started")

        try:
            while self._running and not self._shutdown.is_set():
                try:
                    # Clear expired items periodically
                    # For very short max_age (testing), check every cycle
                    should_clear = (
                        self.max_age_seconds < 1.0 or self.stats.get("exported", 0) % 100 == 0
                    )
                    if should_clear:
                        expired = self.wal.clear_expired(self.max_age_seconds)
                        try:
                            has_expired = expired > 0
                        except Exception:
                            has_expired = False
                        if has_expired:
                            self.stats["expired"] += expired
                            logger.info(f"Cleared {expired} expired items from WAL")

                    # Check circuit breaker before exporting
                    export_circuit = get_export_circuit()
                    if export_circuit.state.value != "open":
                        # Export a batch
                        batch = self.wal.read_batch(self.batch_size)
                        if batch:
                            # Try to export with retry logic
                            try:
                                result = export_circuit.call(self._export_with_retry, batch)
                                if result is True:
                                    # Export succeeded - acknowledge and reset retry state
                                    self.wal.acknowledge(batch)
                                    self.stats["exported"] += len(batch)
                                    logger.debug(
                                        f"Successfully exported {len(batch)} items from WAL"
                                    )
                                elif result is False:
                                    # Max retries exceeded - acknowledge to remove from WAL
                                    self.wal.acknowledge(batch)
                                    logger.error(
                                        f"Dropped batch of {len(batch)} items after max retry duration"
                                    )
                                else:
                                    # result is None - retry later with backoff
                                    # Calculate wait time based on retry count
                                    if self._current_batch_retry_count <= self.max_fast_retries:
                                        base_wait = self.initial_retry_interval * (
                                            2 ** (self._current_batch_retry_count - 1)
                                        )
                                        jitter = base_wait * 0.1 * (2 * random.random() - 1)
                                        wait_time = base_wait + jitter
                                    else:
                                        long_term_attempt = (
                                            self._current_batch_retry_count - self.max_fast_retries
                                        )
                                        base_wait = min(
                                            self.initial_retry_interval
                                            * (2 ** min(long_term_attempt - 1, 10)),
                                            self.max_retry_interval,
                                        )
                                        jitter = base_wait * 0.1 * (2 * random.random() - 1)
                                        wait_time = base_wait + jitter

                                    # Wait with proper shutdown checking
                                    logger.debug(f"Waiting {wait_time:.1f}s before retry")
                                    for _ in range(int(wait_time * 10)):
                                        if not self._running or self._shutdown.is_set():
                                            break
                                        time.sleep(0.1)

                                    self.stats["export_errors"] += 1
                            except Exception as e:
                                logger.error(f"Export failed with circuit breaker: {e}")
                                self.stats["export_errors"] += 1

                except Exception as e:
                    logger.error(f"Error in WAL export loop: {e}", exc_info=True)

                # Sleep with small increments to check shutdown more frequently
                for _ in range(int(self.flush_interval_secs * 10)):
                    if not self._running or self._shutdown.is_set():
                        break
                    try:
                        time.sleep(0.1)
                    except:
                        # During interpreter shutdown, sleep might fail
                        break
        except:
            # Catch any exception during thread shutdown
            pass
        finally:
            logger.info("WAL export thread stopped")

    def shutdown(self) -> None:
        """Shutdown WAL manager and export thread."""
        logger.info("Shutting down WAL manager")

        # Signal shutdown
        self._running = False
        self._shutdown.set()

        # Cancel the finalizer to avoid double cleanup
        if hasattr(self, "_finalizer"):
            self._finalizer.detach()

        # Wait for thread to finish with short timeout
        if self._export_thread and self._export_thread.is_alive():
            self._export_thread.join(timeout=0.5)

            # If thread is still alive after timeout, it's ok - it's a daemon thread
            if self._export_thread.is_alive():
                logger.debug("WAL export thread will be terminated with process")

        # Log final stats
        logger.info(
            f"WAL stats - appended: {self.stats['appended']}, "
            f"exported: {self.stats['exported']}, "
            f"expired: {self.stats['expired']}, "
            f"failed: {self.stats['failed']}, "
            f"dropped (max retries): {self.stats['dropped_max_retries']}"
        )

    def _export_with_retry(self, batch: List[bytes]) -> Optional[bool]:
        """Export batch with retry logic.

        This is the central retry mechanism for all exports. The HTTPExporter
        itself does not implement retries - all retry logic is handled here
        with exponential backoff.

        For short-term failures (first few attempts), uses exponential backoff
        starting at 0.1s. For long-term failures (service outages), continues
        retrying with capped intervals up to the configured max retry duration.

        Args:
            batch: Items to export
            max_retries: Initial fast retry attempts before switching to long-term retry

        Returns:
            Optional[bool]:
              - True if export succeeded
              - False if should give up on this batch (max retry duration exceeded)
              - None if should retry later (caller will apply backoff)
        """
        if not self.exporter:
            # No exporter configured, just acknowledge
            return True

        # Track batch retry state
        current_time = time.time()
        if self._current_batch_start_time is None:
            self._current_batch_start_time = current_time
            self._current_batch_retry_count = 0

        # Check if we've exceeded max retry duration
        elapsed = current_time - self._current_batch_start_time
        if elapsed > self.max_retry_seconds:
            logger.error(
                f"Batch exceeded max retry duration of {self.max_retry_seconds/3600:.1f} hours, "
                f"dropping {len(batch)} spans"
            )
            self.stats["dropped_max_retries"] += len(batch)
            # Reset for next batch
            self._current_batch_start_time = None
            self._current_batch_retry_count = 0
            return False

        # Try to export
        try:
            success = self.exporter(batch)
            if success:
                # Reset retry state on success
                self._current_batch_start_time = None
                self._current_batch_retry_count = 0
                return True
        except Exception as e:
            logger.error(f"Error during export: {e}", exc_info=True)

        # Export failed, calculate backoff
        self._current_batch_retry_count += 1
        self.stats["retries"] += 1

        if self._current_batch_retry_count <= self.max_fast_retries:
            # Fast retries with exponential backoff
            # Following OTEL standards: start at 1s (configurable)
            base_wait = self.initial_retry_interval * (2 ** (self._current_batch_retry_count - 1))
            # Add jitter (±10%) to prevent thundering herd
            jitter = base_wait * 0.1 * (2 * random.random() - 1)
            wait_time = base_wait + jitter
        else:
            # Long-term retries with progressive backoff
            # Start at initial interval and double up to max_retry_interval
            long_term_attempt = self._current_batch_retry_count - self.max_fast_retries
            base_wait = min(
                self.initial_retry_interval * (2 ** min(long_term_attempt - 1, 10)),  # Cap at 2^10
                self.max_retry_interval,
            )
            # Add jitter for long-term retries too
            jitter = base_wait * 0.1 * (2 * random.random() - 1)
            wait_time = base_wait + jitter

        logger.warning(
            f"Export failed (attempt {self._current_batch_retry_count}), "
            f"retrying in {wait_time:.1f}s. "
            f"Total elapsed: {elapsed:.1f}s of {self.max_retry_seconds}s max"
        )

        # Don't sleep here - let the export loop handle timing
        # This allows for proper shutdown handling
        return None  # Signal to export loop to retry later

    def get_size(self) -> int:
        """Get current WAL size."""
        return self.wal.size()

    @staticmethod
    def _emergency_shutdown(shutdown_event, thread):
        """Emergency shutdown called by weakref finalizer."""
        try:
            shutdown_event.set()
        except:
            pass
