"""MVK SDK v5.0 - Ultralight OpenTelemetry-compatible SDK for Mavvrik.

This is the micro SDK with minimal dependencies (~450KB).
Features clean architecture with separate processors and exporters.
Full OTEL support including OTLP export to OpenTelemetry Collector.
W3C TraceContext support for distributed tracing.
"""

__version__ = "1.0.4"  # This will be updated by the release workflow

from .decorators import context, track

# Public API - everything is namespaced under mvk
from .instrument import get_service_instance_id, get_session_id, instrument, shutdown
from .metrics import Metric, add_metered_usage
from .schema import validate_tags
from .tracer import create_span, get_current_span, get_tracer

# Export public API
__all__ = [
    # Core functions
    "instrument",
    "shutdown",
    "get_tracer",
    "get_session_id",
    "get_service_instance_id",
    # Span creation
    "create_span",
    "get_current_span",
    # Decorators
    "track",
    "context",
    # Metrics
    "add_metered_usage",
    "Metric",
    # Helpers
    "validate_tags",
]
