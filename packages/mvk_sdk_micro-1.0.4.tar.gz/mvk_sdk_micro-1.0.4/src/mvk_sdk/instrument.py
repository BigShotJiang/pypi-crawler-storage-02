"""Instrumentation module for MVK SDK v5.0.

Provides the main instrument() function to initialize the SDK.
"""

import logging
import os
import threading
import uuid
from typing import Any, Dict, Optional

from .context import set_global_context
from .processors.factory import ProcessorFactory
from .schema import validate
from .tracer import get_tracer

logger = logging.getLogger(__name__)

# Global state
_initialized = False
_init_lock = threading.Lock()
_session_id: Optional[str] = None
_strict_validation: bool = False
_service_instance_id: str = str(uuid.uuid4())  # One per process


def instrument(
    resource: Dict[str, Any],
    config: Optional[Dict[str, Any]] = None,
    tags: Optional[Dict[str, str]] = None,
    instrumentation: Optional[Dict[str, bool]] = None,
) -> None:
    """Initialize MVK SDK instrumentation with v5.0 signature.

    This is the main entry point for SDK initialization. Must be called
    once per process before using any SDK features.

    Args:
        resource: Resource attributes following OTEL conventions:
            - service.name: Required service name
            - service.version: Optional service version
            - service.namespace: Optional namespace
        config: Optional configuration with v5.0 structure:
            - api_key: MVK API key for authentication
            - processor: Processor configuration
            - exporter: Exporter configuration
            - wal: WAL configuration (if using wal_batch processor)
            - strict_validation: Enable strict schema validation
        tags: Optional global tags (max 10)
        instrumentation: Enable/disable specific auto-instrumentation

    Raises:
        ValueError: If service.name not provided in resource
        RuntimeError: If already instrumented

    Example:
        mvk.instrument(
            resource={"service.name": "chat-service", "service.version": "1.0.0"},
            config={
                "api_key": "mvk_...",
                "processor": {"type": "memory_batch"},
                "exporter": {
                    "type": "http",
                    "endpoint": "https://api.mavvrik.ai"
                }
            },
            tags={"env": "prod", "region": "us-east-1"}
        )
    """
    global _initialized, _session_id, _wal_manager, _strict_validation, _service_instance_id

    with _init_lock:
        if _initialized:
            logger.warning("MVK SDK already initialized, ignoring duplicate call")
            return

        # Validate required fields
        if not resource or "service.name" not in resource:
            raise ValueError("resource must contain 'service.name'")

        service_name = resource["service.name"]

        # Handle backward compatibility - old signature
        if isinstance(resource, str):
            # Old signature: instrument(api_key, agent_name, config, patches)
            logger.warning("Using deprecated v4.0 signature, please update to v5.0")
            api_key = resource  # First arg was api_key
            agent_name = config  # Second arg was agent_name
            old_config = tags  # Third arg was config
            patches = instrumentation  # Fourth arg was patches

            # Convert to v5.0 format
            resource = {"service.name": agent_name}
            config = old_config or {}
            if "api_key" not in config:
                config["api_key"] = api_key
            tags = {}
            instrumentation = patches

        # Get API key from config
        config = config or {}
        api_key = config.get("api_key")
        if not api_key:
            # Try environment variable
            api_key = os.getenv("MVK_API_KEY")
            if not api_key:
                raise ValueError("api_key must be provided in config or MVK_API_KEY env var")

        # Ensure exporter has API key if not specified
        if "exporter" not in config:
            config["exporter"] = {}
        if "api_key" not in config["exporter"]:
            config["exporter"]["api_key"] = api_key

        _strict_validation = config.get("strict_validation", False)

        # Generate session ID
        _session_id = str(uuid.uuid4())

        # Configure global tracer
        global_tracer = get_tracer()
        global_tracer.configure(api_key, service_name, _strict_validation)

        # Set global context with OTLP-compliant attributes
        global_context = {
            "service.name": service_name,
            "service.version": resource.get("service.version"),
            "service.instance.id": _service_instance_id,
            "mvk.agent.name": service_name,  # Derived from service.name
            "mvk.session_id": _session_id,  # Use mvk prefix for consistency
        }

        # Add optional resource attributes
        if "service.namespace" in resource:
            global_context["service.namespace"] = resource["service.namespace"]

        # Add global tags (max 10)
        if tags:
            # Validate tag count
            if len(tags) > 10:
                logger.warning(f"Too many tags ({len(tags)}), limiting to 10")
                tags = dict(list(tags.items())[:10])

            # Validate tag format and flatten with tags.* prefix for OTLP
            import re

            tag_pattern = re.compile(r"^[a-z0-9_-]{1,32}$")
            for key, value in tags.items():
                if tag_pattern.match(key) and tag_pattern.match(str(value)):
                    # Flatten tags directly with tags.* prefix for OTLP compliance
                    global_context[f"tags.{key}"] = value
                else:
                    logger.warning(f"Invalid tag format: {key}={value}, skipping")

        set_global_context(global_context)

        # Create processor using factory
        try:
            processor = ProcessorFactory.create_from_config(config)
        except Exception as e:
            logger.error(f"Failed to create processor: {e}")
            # Fall back to default processor
            processor = ProcessorFactory.create_default()

        # Register processor with tracer
        global_tracer.add_span_processor(processor)

        # Apply auto-instrumentation patches
        _apply_patches(instrumentation)

        _initialized = True

        processor_type = config.get("processor", {}).get("type", "memory_batch")
        exporter_type = config.get("exporter", {}).get("type", "http")
        logger.info(
            f"MVK SDK v5.0 initialized (OTLP-compliant) - service: {service_name}, "
            f"processor: {processor_type}, exporter: {exporter_type}, "
            f"session: {_session_id}, instance: {_service_instance_id}, "
            f"strict_validation: {_strict_validation}"
        )


def _apply_patches(patches: Optional[Dict[str, bool]]) -> None:
    """Apply auto-instrumentation patches.

    Args:
        patches: Dict of library names to enable/disable
    """
    if patches is None:
        patches = {}

    # Default to all patches enabled
    default_patches = {
        "openai": True,
        "anthropic": True,
        "cohere": True,
        "mistral": True,
        "langchain": True,
        "llama_index": True,
        "chromadb": True,
        "pinecone": True,
        "weaviate": True,
        "httpx": True,
    }

    # Merge with user patches
    enabled_patches = {**default_patches, **patches}

    # Apply patches
    if enabled_patches.get("openai"):
        try:
            from .wrappers import openai as openai_wrapper

            openai_wrapper.patch()
        except ImportError:
            pass

    if enabled_patches.get("anthropic"):
        try:
            from .wrappers import anthropic as anthropic_wrapper

            anthropic_wrapper.patch()
        except ImportError:
            pass

    # TODO: Add other wrappers as they are implemented


def shutdown() -> None:
    """Shutdown the SDK and flush all pending spans."""
    global _initialized

    if not _initialized:
        return

    with _init_lock:
        # Get tracer and shutdown
        try:
            global_tracer = get_tracer()
            global_tracer.shutdown()
        except:
            pass

        _initialized = False

        logger.info("MVK SDK shutdown complete")


def get_session_id() -> Optional[str]:
    """Get the current session ID.

    Returns:
        Session ID if SDK is initialized, None otherwise
    """
    return _session_id


def configure_otlp_compliance(strict: bool = True) -> None:
    """Configure SDK for strict OTLP compliance.

    When enabled, enforces:
    - Proper ID formats (32 hex for trace_id, 16 hex for span_id)
    - Nanosecond timestamps
    - All custom fields in attributes map
    - OTLP SpanKind and StatusCode enums

    Args:
        strict: If True, raise errors on OTLP violations.
                If False, attempt to fix violations.
    """
    global _strict_validation
    _strict_validation = strict
    logger.info(f"OTLP compliance mode: {'strict' if strict else 'lenient'}")


def get_service_instance_id() -> str:
    """Get the service instance ID (unique per process).

    Returns:
        Service instance ID (UUID v4)
    """
    return _service_instance_id


def is_strict_validation() -> bool:
    """Check if strict validation is enabled.

    Returns:
        True if strict validation is enabled
    """
    return _strict_validation or os.getenv("MVK_STRICT_VALIDATION", "").lower() in (
        "1",
        "true",
        "yes",
    )
