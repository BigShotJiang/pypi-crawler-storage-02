"""Ultralight tracer implementation without OpenTelemetry dependencies.

This provides a minimal OpenTelemetry-compatible API surface for the micro SDK.
"""

import logging
import random
import threading
import time
from contextvars import ContextVar
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Context variable for current span
_current_span: ContextVar[Optional["Span"]] = ContextVar("current_span", default=None)


class SpanKind(Enum):
    """OpenTelemetry-compatible span kinds."""

    INTERNAL = 0
    SERVER = 1
    CLIENT = 2
    PRODUCER = 3
    CONSUMER = 4


class Status:
    """Span status."""

    class StatusCode(Enum):
        UNSET = 0
        OK = 1
        ERROR = 2

    def __init__(self, status_code: StatusCode, description: Optional[str] = None):
        self.status_code = status_code
        self.description = description


class Span:
    """Ultralight span implementation."""

    def __init__(
        self,
        name: str,
        context: "SpanContext",
        tracer: "Tracer",
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: Optional[Dict[str, Any]] = None,
        start_time: Optional[float] = None,
    ):
        self.name = name
        self.context = context
        self._tracer = tracer
        self.kind = kind
        self._attributes = attributes or {}
        self._events: List[Dict[str, Any]] = []
        self._status = Status(Status.StatusCode.UNSET)
        self._end_time: Optional[float] = None

        # Set start time
        self._start_time = start_time or time.time()

        # Track parent
        self._parent = _current_span.get()
        if self._parent:
            self.context.parent_span_id = self._parent.context.span_id

    @property
    def start_time(self) -> float:
        """Get span start time."""
        return self._start_time

    @property
    def end_time(self) -> Optional[float]:
        """Get span end time."""
        return self._end_time

    def set_attribute(self, key: str, value: Any) -> None:
        """Set a span attribute."""
        if self._end_time is not None:
            logger.warning("Attempted to set attribute on ended span")
            return
        self._attributes[key] = value

    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """Set multiple span attributes."""
        for key, value in attributes.items():
            self.set_attribute(key, value)

    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        """Add an event to the span."""
        if self._end_time is not None:
            logger.warning("Attempted to add event to ended span")
            return

        event = {"name": name, "timestamp": time.time(), "attributes": attributes or {}}
        self._events.append(event)

    def record_exception(self, exception: Exception) -> None:
        """Record an exception on the span."""
        self.set_status(Status(Status.StatusCode.ERROR, str(exception)))
        self.add_event(
            "exception",
            {"exception.type": type(exception).__name__, "exception.message": str(exception)},
        )

    def set_status(self, status: Status) -> None:
        """Set the span status."""
        if self._end_time is not None:
            logger.warning("Attempted to set status on ended span")
            return
        self._status = status

    def end(self, end_time: Optional[float] = None) -> None:
        """End the span."""
        if self._end_time is not None:
            logger.warning("Attempted to end already ended span")
            return

        self._end_time = end_time or time.time()

        # Process the span through the span processor
        if self._tracer._span_processor:
            self._tracer._span_processor.on_end(self)

    def __enter__(self):
        """Enter the span context."""
        self._token = _current_span.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit the span context."""
        if exc_val is not None:
            self.record_exception(exc_val)
        self.end()
        _current_span.reset(self._token)
        return False

    def get_span_context(self) -> "SpanContext":
        """Get the span context."""
        return self.context

    def is_recording(self) -> bool:
        """Check if span is recording."""
        return self._end_time is None


class SpanContext:
    """Span context containing trace and span IDs."""

    def __init__(self, trace_id: str, span_id: str, parent_span_id: Optional[str] = None):
        self.trace_id = trace_id
        self.span_id = span_id
        self.parent_span_id = parent_span_id

    @classmethod
    def generate(cls, parent: Optional["SpanContext"] = None) -> "SpanContext":
        """Generate a new span context."""
        if parent:
            # Continue existing trace
            trace_id = parent.trace_id
        else:
            # New trace
            trace_id = format(random.getrandbits(128), "032x")

        span_id = format(random.getrandbits(64), "016x")
        return cls(trace_id, span_id)


class Tracer:
    """Ultralight tracer implementation."""

    def __init__(self, name: str, version: Optional[str] = None):
        self.name = name
        self.version = version
        self._span_processor: Optional["SpanProcessor"] = None

    def start_span(
        self,
        name: str,
        context: Optional[SpanContext] = None,
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: Optional[Dict[str, Any]] = None,
        start_time: Optional[float] = None,
    ) -> Span:
        """Start a new span."""
        # Get or create context
        parent_span = _current_span.get()
        if context is None:
            if parent_span:
                context = SpanContext.generate(parent_span.context)
            else:
                context = SpanContext.generate()

        span = Span(name, context, self, kind, attributes, start_time)

        # Notify processor
        if self._span_processor:
            self._span_processor.on_start(span)

        return span

    def start_as_current_span(
        self,
        name: str,
        context: Optional[SpanContext] = None,
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: Optional[Dict[str, Any]] = None,
        start_time: Optional[float] = None,
    ) -> Span:
        """Start a new span and set it as current."""
        span = self.start_span(name, context, kind, attributes, start_time)
        return span  # Context management handled by span __enter__/__exit__


class TracerProvider:
    """Ultralight tracer provider."""

    def __init__(self, resource: Optional[Dict[str, Any]] = None):
        self.resource = resource or {}
        self._tracers: Dict[str, Tracer] = {}
        self._span_processors: List["SpanProcessor"] = []
        self._lock = threading.Lock()

    def get_tracer(self, name: str, version: Optional[str] = None) -> Tracer:
        """Get or create a tracer."""
        key = f"{name}:{version or ''}"

        with self._lock:
            if key not in self._tracers:
                tracer = Tracer(name, version)
                # Add all registered processors
                for processor in self._span_processors:
                    tracer._span_processor = processor
                self._tracers[key] = tracer

            return self._tracers[key]

    def add_span_processor(self, processor: "SpanProcessor") -> None:
        """Add a span processor."""
        with self._lock:
            self._span_processors.append(processor)
            # Update all existing tracers
            for tracer in self._tracers.values():
                tracer._span_processor = processor

    def shutdown(self) -> None:
        """Shutdown the tracer provider."""
        for processor in self._span_processors:
            processor.shutdown()


class SpanProcessor:
    """Base span processor interface."""

    def on_start(self, span: Span) -> None:
        """Called when a span is started."""
        pass

    def on_end(self, span: Span) -> None:
        """Called when a span is ended."""
        pass

    def shutdown(self) -> None:
        """Shutdown the processor."""
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush any pending spans."""
        return True


# Global tracer provider
_tracer_provider: Optional[TracerProvider] = None


def set_tracer_provider(provider: TracerProvider) -> None:
    """Set the global tracer provider."""
    global _tracer_provider
    _tracer_provider = provider


def get_tracer_provider() -> Optional[TracerProvider]:
    """Get the global tracer provider."""
    return _tracer_provider


def get_tracer(name: str = "mvk-sdk", version: Optional[str] = None) -> Tracer:
    """Get a tracer from the global provider."""
    provider = get_tracer_provider()
    if not provider:
        raise RuntimeError("No tracer provider configured. Call mvk.instrument() first.")
    return provider.get_tracer(name, version)


def get_current_span() -> Optional[Span]:
    """Get the currently active span."""
    return _current_span.get()
