"""Batch span processor for MVK SDK without OTEL dependencies."""

import json
import logging
import threading
import time
from collections import deque
from typing import Any, Callable, Dict, List, Optional

from .wal.base import WALBase
from .wal.manager import WALManager

logger = logging.getLogger(__name__)


class BatchSpanProcessor:
    """Batch processor that collects spans and exports them in batches.

    This is a lightweight implementation without OTEL dependencies.
    """

    def __init__(
        self,
        exporter: Optional[Callable[[List[Dict[str, Any]]], bool]],
        wal: Optional[WALBase] = None,
        wal_config: Optional[Dict[str, Any]] = None,
        max_queue_size: int = 2048,
        batch_size: int = 512,
        export_interval_secs: float = 5.0,
        max_export_batch_size: int = 512,
    ):
        """Initialize batch processor.

        Args:
            exporter: Function to export spans, returns True on success
            wal: Write-Ahead Log for reliability (optional)
            wal_config: Configuration for WAL Manager (optional)
            max_queue_size: Maximum spans to queue in memory
            batch_size: Number of spans to trigger export
            export_interval_secs: Max time between exports
            max_export_batch_size: Maximum spans per export call
        """
        self.exporter = exporter
        self.max_queue_size = max_queue_size
        self.batch_size = batch_size
        self.export_interval_secs = export_interval_secs
        self.max_export_batch_size = max_export_batch_size

        # Span queue
        self._queue: deque[Dict[str, Any]] = deque(maxlen=max_queue_size)
        self._lock = threading.Lock()

        # WAL integration
        self.wal_manager = None
        if wal:
            wal_config = wal_config or {}
            self.wal_manager = WALManager(
                wal=wal,
                exporter=self._export_from_wal,
                flush_interval_secs=wal_config.get("flush_interval_secs", 2),
                batch_size=wal_config.get("batch_size", 250),
                max_age_hours=wal_config.get("max_age_hours", 12),
                max_retry_hours=wal_config.get("max_retry_hours", 4.0),
                max_retry_interval_secs=wal_config.get("max_retry_interval_secs", 300),
                initial_retry_interval_secs=wal_config.get("initial_retry_interval_secs", 1.0),
                max_fast_retries=wal_config.get("max_fast_retries", 10),
            )

        # Export thread
        self._shutdown = threading.Event()
        self._force_flush = threading.Event()
        self._export_thread = threading.Thread(
            target=self._export_loop, name="BatchSpanExporter", daemon=True
        )
        self._export_thread.start()

        # Statistics
        self.stats = {"received": 0, "exported": 0, "dropped": 0, "failed": 0}

    def on_end(self, span_dict: Dict[str, Any]) -> None:
        """Process a finished span.

        Args:
            span_dict: Span data dictionary
        """
        self.stats["received"] += 1

        # If WAL is configured, write to WAL first
        if self.wal_manager:
            try:
                span_bytes = json.dumps(span_dict).encode("utf-8")
                self.wal_manager.append(span_bytes)
            except Exception as e:
                logger.error(f"Failed to write span to WAL: {e}")
                self.stats["failed"] += 1
                return

        # Add to memory queue
        with self._lock:
            if len(self._queue) >= self.max_queue_size:
                # Queue full, drop oldest
                self._queue.popleft()
                self.stats["dropped"] += 1

            self._queue.append(span_dict)

            # Check if we should trigger export
            if len(self._queue) >= self.batch_size:
                self._force_flush.set()

    def _export_loop(self) -> None:
        """Background thread that exports spans."""
        logger.info("Batch span export thread started")

        last_export = time.time()

        while not self._shutdown.is_set():
            # Wait for trigger or timeout
            timeout = self.export_interval_secs - (time.time() - last_export)
            if timeout > 0:
                self._force_flush.wait(timeout)

            # Clear the force flush flag
            self._force_flush.clear()

            # Export batch
            try:
                self._export_batch()
                last_export = time.time()
            except Exception as e:
                logger.error(f"Error in export loop: {e}", exc_info=True)

        # Final export on shutdown
        try:
            self._export_batch()
        except Exception:
            pass

        logger.info("Batch span export thread stopped")

    def _export_batch(self) -> None:
        """Export a batch of spans from memory queue."""
        if not self.exporter:
            return

        # Get batch from queue
        batch = []
        with self._lock:
            for _ in range(min(self.max_export_batch_size, len(self._queue))):
                if self._queue:
                    batch.append(self._queue.popleft())

        if not batch:
            return

        # Try to export
        try:
            success = self.exporter(batch)
            if success:
                self.stats["exported"] += len(batch)
                logger.debug(f"Exported batch of {len(batch)} spans")
            else:
                # Export failed, put back in queue if not using WAL
                if not self.wal_manager:
                    with self._lock:
                        # Put failed items back at the front
                        for span in reversed(batch):
                            self._queue.appendleft(span)
                self.stats["failed"] += len(batch)
                logger.warning(f"Failed to export batch of {len(batch)} spans")
        except Exception as e:
            logger.error(f"Exception during export: {e}", exc_info=True)
            self.stats["failed"] += len(batch)

            # Put back in queue if not using WAL
            if not self.wal_manager:
                with self._lock:
                    for span in reversed(batch):
                        self._queue.appendleft(span)

    def _export_from_wal(self, batch: List[bytes]) -> bool:
        """Export spans that were read from WAL.

        Args:
            batch: List of serialized span data

        Returns:
            True if export succeeded
        """
        if not self.exporter:
            return True

        try:
            # Deserialize spans
            spans = []
            for data in batch:
                try:
                    span = json.loads(data.decode("utf-8"))
                    spans.append(span)
                except Exception as e:
                    logger.error(f"Failed to deserialize span from WAL: {e}")

            if spans:
                return self.exporter(spans)

            return True
        except Exception as e:
            logger.error(f"Failed to export WAL batch: {e}")
            return False

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force export of all pending spans.

        Args:
            timeout_millis: Timeout in milliseconds

        Returns:
            True if all spans were exported
        """
        self._force_flush.set()

        # Wait for queue to empty
        start = time.time()
        timeout = timeout_millis / 1000.0

        while time.time() - start < timeout:
            with self._lock:
                if not self._queue:
                    return True
            time.sleep(0.01)

        return False

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the processor.

        Args:
            timeout_millis: Timeout in milliseconds
        """
        logger.info("Shutting down batch span processor")

        # Trigger final export
        self._force_flush.set()

        # Signal shutdown
        self._shutdown.set()

        # Wait for export thread
        timeout = timeout_millis / 1000.0
        self._export_thread.join(timeout)

        # Shutdown WAL if configured
        if self.wal_manager:
            self.wal_manager.shutdown()

        # Log stats
        logger.info(
            f"Processor stats - received: {self.stats['received']}, "
            f"exported: {self.stats['exported']}, "
            f"dropped: {self.stats['dropped']}, "
            f"failed: {self.stats['failed']}"
        )
