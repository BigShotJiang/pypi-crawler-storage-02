"""OTLP-compliant tracer for MVK SDK without OTEL dependencies."""

import json
import logging
import time
import uuid
from contextvars import ContextVar
from enum import Enum
from typing import Any, Dict, List, Optional

from .context import get_current_context
from .schema import MVKSpanKind, get_mvk_kind_for_name, validate

logger = logging.getLogger(__name__)

# Context variable for current span
_current_span: ContextVar[Optional["Span"]] = ContextVar("current_span", default=None)


# OTLP SpanKind enum
class OTLPSpanKind(str, Enum):
    INTERNAL = "SPAN_KIND_INTERNAL"
    SERVER = "SPAN_KIND_SERVER"
    CLIENT = "SPAN_KIND_CLIENT"
    PRODUCER = "SPAN_KIND_PRODUCER"
    CONSUMER = "SPAN_KIND_CONSUMER"


# OTLP Status Code enum
class OTLPStatusCode(str, Enum):
    UNSET = "STATUS_CODE_UNSET"
    OK = "STATUS_CODE_OK"
    ERROR = "STATUS_CODE_ERROR"


def generate_trace_id() -> str:
    """Generate OTLP-compliant 32-char hex trace ID."""
    return uuid.uuid4().hex


def generate_span_id() -> str:
    """Generate OTLP-compliant 16-char hex span ID."""
    return uuid.uuid4().hex[:16]


def to_nanoseconds(timestamp: float) -> int:
    """Convert float seconds timestamp to int nanoseconds."""
    return int(timestamp * 1_000_000_000)


class Span:
    """Lightweight span implementation."""

    def __init__(self, name: str, kind: str, attributes: Dict[str, Any]):
        # Generate OTLP-compliant IDs
        self.span_id = generate_span_id()
        self.trace_id = attributes.get("trace_id")
        if not self.trace_id:
            self.trace_id = generate_trace_id()
        elif "-" in self.trace_id:
            # Convert UUID format to hex if needed
            self.trace_id = self.trace_id.replace("-", "")

        self.parent_id = attributes.get("parent_id")
        self.parent_span_id = self.parent_id  # Alias for compatibility
        self.name = name
        self.mvk_kind = kind  # MVK semantic kind
        self.otlp_kind = self._map_to_otlp_kind(kind)  # OTLP SpanKind
        self.start_time = time.time()
        self.end_time = None
        self.duration_ms = None
        self.attributes = self._format_attributes(attributes)
        self.events: List[Dict[str, Any]] = []
        self.status_code = OTLPStatusCode.UNSET
        self.status_message = ""
        self.error: Optional[Dict[str, str]] = None
        self.error_type: Optional[str] = None
        self.error_message: Optional[str] = None
        self.metrics: List[Dict[str, Any]] = []

    def end(self):
        """End the span and send to processor."""
        if self.end_time is not None:
            return

        self.end_time = time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000

        # Set status to OK if not already set
        if self.status_code == OTLPStatusCode.UNSET:
            self.status_code = OTLPStatusCode.OK

        # Convert to OTLP-compliant dict
        otlp_span = self.to_otlp_dict()

        # Send to processor
        tracer = get_tracer()
        if tracer._processor:
            tracer._processor.on_end(otlp_span)

    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        """Add an event to the span."""
        event = {"name": name, "timestamp": time.time(), "attributes": attributes or {}}
        self.events.append(event)

    def set_error(self, error: Exception):
        """Set error on span."""
        self.status_code = OTLPStatusCode.ERROR
        self.status_message = str(error)
        self.error_type = type(error).__name__
        self.error_message = str(error)
        self.error = {"type": self.error_type, "message": self.error_message}
        self.add_event(
            "exception", {"exception.type": type(error).__name__, "exception.message": str(error)}
        )

    def __enter__(self):
        """Enter span context."""
        self._token = _current_span.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit span context."""
        if exc_val:
            self.set_error(exc_val)
        self.end()
        _current_span.reset(self._token)
        return False

    def set_attribute(self, key: str, value: Any):
        """Set an attribute on the span."""
        self.attributes[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """Convert span to dictionary (legacy format for backward compatibility)."""
        span_dict = {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_id": self.parent_id,
            "name": self.name,
            "kind": self.mvk_kind,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms
            or ((self.end_time - self.start_time) * 1000 if self.end_time else 0),
            "attributes": self.attributes,
            "events": self.events,
            "status": self.status_code.value.replace("STATUS_CODE_", "").lower(),
        }
        if self.error:
            span_dict["error"] = self.error
        if self.metrics:
            span_dict["metrics"] = self.metrics
        return span_dict

    def to_otlp_dict(self) -> Dict[str, Any]:
        """Convert span to OTLP-compliant dictionary format.

        Returns:
            OTLP-compliant span dictionary with proper ID formats,
            nanosecond timestamps, and all custom fields in attributes.
        """
        # Format events for OTLP with camelCase
        otlp_events = []
        for event in self.events:
            otlp_event = {
                "timeUnixNano": str(to_nanoseconds(event["timestamp"])),  # String for 64-bit int
                "name": event["name"],
                "attributes": [],
            }
            # Convert event attributes to typed format
            event_attrs = event.get("attributes", {})
            for key, value in event_attrs.items():
                if value is not None:
                    typed_attr = {"key": key}
                    if isinstance(value, bool):
                        typed_attr["value"] = {"boolValue": value}
                    elif isinstance(value, int):
                        typed_attr["value"] = {"intValue": str(value)}
                    elif isinstance(value, float):
                        typed_attr["value"] = {"doubleValue": value}
                    else:
                        typed_attr["value"] = {"stringValue": str(value)}
                    otlp_event["attributes"].append(typed_attr)
            otlp_events.append(otlp_event)

        # Build OTLP span with proper camelCase
        otlp_span: Dict[str, Any] = {
            "traceId": self.trace_id,
            "spanId": self.span_id,
            "name": self.name,
            "kind": self.otlp_kind.value,
            "startTimeUnixNano": str(to_nanoseconds(self.start_time)),  # String for 64-bit int
            "endTimeUnixNano": str(
                to_nanoseconds(self.end_time) if self.end_time else to_nanoseconds(self.start_time)
            ),
            "status": {"code": self.status_code.value},
            "attributes": self._format_attributes_for_otlp(),  # Convert to typed format
            "events": otlp_events,
            "links": [],
        }

        # Only add parentSpanId if it exists (omit for root spans)
        if self.parent_id:
            otlp_span["parentSpanId"] = self.parent_id

        # Only add status message if present
        if self.status_message:
            otlp_span["status"]["message"] = self.status_message

        # Only add dropped counts if non-zero
        if hasattr(self, "dropped_attributes_count") and self.dropped_attributes_count > 0:
            otlp_span["droppedAttributesCount"] = self.dropped_attributes_count
        if hasattr(self, "dropped_events_count") and self.dropped_events_count > 0:
            otlp_span["droppedEventsCount"] = self.dropped_events_count
        if hasattr(self, "dropped_links_count") and self.dropped_links_count > 0:
            otlp_span["droppedLinksCount"] = self.dropped_links_count

        return otlp_span

    def _map_to_otlp_kind(self, mvk_kind: str) -> OTLPSpanKind:
        """Map MVK semantic kind to OTLP SpanKind.

        Args:
            mvk_kind: MVK semantic kind (LLM, TOOL, etc.)

        Returns:
            OTLP SpanKind enum value
        """
        # Map MVK kinds to OTLP kinds
        mapping = {
            "LLM": OTLPSpanKind.CLIENT,  # LLM calls are client operations
            "EMBEDDING": OTLPSpanKind.CLIENT,  # Embedding calls are client operations
            "RETRIEVER": OTLPSpanKind.CLIENT,  # Retriever calls are client operations
            "TOOL": OTLPSpanKind.INTERNAL,  # Tools are internal operations
            "MEMORY": OTLPSpanKind.INTERNAL,  # Memory ops are internal
            "AGENT_CALL": OTLPSpanKind.INTERNAL,  # Agent calls are internal orchestration
            "HTTP": OTLPSpanKind.CLIENT,  # HTTP calls are client operations
            "DATABASE": OTLPSpanKind.CLIENT,  # DB calls are client operations
        }

        return mapping.get(mvk_kind, OTLPSpanKind.INTERNAL)

    def _format_attributes_for_otlp(self) -> List[Dict[str, Any]]:
        """Format attributes as typed key-value pairs for OTLP.

        Returns:
            List of typed attribute objects
        """
        typed_attrs = []

        for key, value in self.attributes.items():
            if value is None:
                continue

            typed_attr: Dict[str, Any] = {"key": key}

            # Determine type and set value
            if isinstance(value, bool):
                typed_attr["value"] = {"boolValue": value}
            elif isinstance(value, int):
                # Use string for 64-bit ints in JSON
                typed_attr["value"] = {"intValue": str(value)}
            elif isinstance(value, float):
                typed_attr["value"] = {"doubleValue": value}
            elif isinstance(value, str):
                typed_attr["value"] = {"stringValue": value}
            elif isinstance(value, (list, tuple)):
                # Array value
                typed_attr["value"] = {
                    "arrayValue": {"values": [self._create_typed_value(v) for v in value]}
                }
            elif isinstance(value, dict):
                # Convert dict to string for now
                typed_attr["value"] = {"stringValue": json.dumps(value)}
            else:
                # Default to string representation
                typed_attr["value"] = {"stringValue": str(value)}

            typed_attrs.append(typed_attr)

        return typed_attrs

    def _create_typed_value(self, value: Any) -> Dict[str, Any]:
        """Create a typed value for array elements."""
        if isinstance(value, bool):
            return {"boolValue": value}
        elif isinstance(value, int):
            return {"intValue": str(value)}
        elif isinstance(value, float):
            return {"doubleValue": value}
        else:
            return {"stringValue": str(value)}

    def _format_attributes(self, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """Format attributes with proper OTLP namespacing.

        Args:
            attributes: Raw attributes dictionary

        Returns:
            Formatted attributes with proper prefixes and flattened tags
        """
        formatted = {}

        # Extract tags for flattening
        tags = attributes.pop("tags", {})

        # Process each attribute
        for key, value in attributes.items():
            # Skip internal fields that shouldn't be in attributes
            if key in ["trace_id", "span_id", "parent_id", "parent_span_id"]:
                continue

            # Add proper prefixes based on key patterns
            if key.startswith("mvk."):
                # Already has mvk prefix
                formatted[key] = value
            elif key.startswith(("service.", "http.", "db.", "rpc.", "cloud.", "tags.")):
                # Standard OTEL semantic conventions or already prefixed tags
                formatted[key] = value
            elif key in [
                "agent_name",
                "agent_id",
                "session_id",
                "user_id",
                "client_id",
                "operation",
                "model_name",
                "model_provider",
                "prompt_tokens",
                "completion_tokens",
                "total_tokens",
                "duration_ms",
                "time_to_first_token_ms",
                "cloud_provider",
            ]:
                # MVK-specific fields that need prefix
                formatted[f"mvk.{key}"] = value
            else:
                # Other custom fields get mvk prefix
                formatted[f"mvk.{key}"] = value

        # Add MVK span kind if present
        if self.mvk_kind:
            formatted["mvk.span.kind"] = self.mvk_kind

        # Flatten tags with tags.* prefix
        for tag_key, tag_value in tags.items():
            formatted[f"tags.{tag_key}"] = tag_value

        # Ensure values are JSON-serializable
        for key, value in formatted.items():
            if isinstance(value, (dict, list)):
                # JSON-encode complex objects
                formatted[key] = json.dumps(value)
            elif isinstance(value, bool):
                # Keep booleans as-is (OTLP supports them)
                pass
            elif isinstance(value, (int, float)):
                # Keep numbers as-is
                pass
            else:
                # Convert everything else to string
                formatted[key] = str(value) if value is not None else ""

        return formatted

    def _flatten_attributes(self, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """Flatten attributes for OTLP events.

        Args:
            attributes: Event attributes

        Returns:
            Flattened attributes dictionary
        """
        flattened = {}
        for key, value in attributes.items():
            if isinstance(value, (dict, list)):
                flattened[key] = json.dumps(value)
            else:
                flattened[key] = value
        return flattened


class UltralightTracer:
    """Global tracer singleton for MVK SDK v3.0."""

    def __init__(self):
        self._processor = None
        self._api_key = None
        self._agent_name = None
        self._strict_validation = False

    def configure(self, api_key: str, agent_name: str, strict_validation: bool = False) -> None:
        """Configure the tracer with API key and agent name.

        Args:
            api_key: MVK API key
            agent_name: Name of the agent
            strict_validation: Whether to enforce strict validation
        """
        self._api_key = api_key
        self._agent_name = agent_name
        self._strict_validation = strict_validation

    def add_span_processor(self, processor) -> None:
        """Add a span processor to handle finished spans.

        Args:
            processor: Span processor instance
        """
        self._processor = processor

    def start_span(
        self, name: str, kind: Optional[str] = None, inherit_context: bool = True, **kwargs
    ) -> Span:
        """Start a new span.

        Args:
            name: Span name
            kind: Span kind (will be inferred if not provided)
            inherit_context: Whether to inherit current context (default True)
            **kwargs: Additional attributes

        Returns:
            Span instance
        """
        # Get current context attributes only if inheriting
        if inherit_context:
            context = get_current_context()
            # Merge with kwargs
            attributes = {**context, **kwargs}
        else:
            attributes = kwargs.copy()

        # Add agent name if configured
        if self._agent_name:
            attributes["mvk.agent.name"] = self._agent_name

        # Infer kind if not provided
        if not kind:
            kind = get_mvk_kind_for_name(name)

        # Validate kind if strict validation is enabled
        if kind and hasattr(self, "_strict_validation") and self._strict_validation:
            valid_kinds = [k.value for k in MVKSpanKind]
            if kind not in valid_kinds:
                raise ValueError(
                    f"Invalid span kind '{kind}'. Valid kinds: {', '.join(valid_kinds)}"
                )

        # Add kind to attributes for v5.0
        if kind:
            attributes["mvk.span.kind"] = kind

        # Get parent span if any
        parent = _current_span.get()
        if parent:
            attributes["trace_id"] = parent.trace_id
            attributes["parent_id"] = parent.span_id

        # Create span
        span = Span(name, kind, attributes)

        return span

    def shutdown(self) -> None:
        """Shutdown the tracer and its processor."""
        if self._processor:
            self._processor.shutdown()


# Global tracer instance
_global_tracer: Optional[UltralightTracer] = None


def get_tracer() -> UltralightTracer:
    """Get the global tracer instance.

    Returns:
        UltralightTracer: The global tracer singleton
    """
    global _global_tracer
    if _global_tracer is None:
        _global_tracer = UltralightTracer()
    return _global_tracer


def get_current_span() -> Optional[Span]:
    """Get the currently active span."""
    return _current_span.get()


def create_span(name: str, kind: Optional[str] = None, **kwargs) -> Span:
    """Create a new span without auto-instrumentation.

    This is the public API for manual span creation. It creates a span
    without any context inheritance or auto-instrumentation.

    Args:
        name: Span name
        kind: MVK span kind (LLM, TOOL, RETRIEVER, etc.)
        **kwargs: Additional attributes

    Returns:
        Span instance to be used as context manager

    Example:
        with mvk.create_span("custom_operation", kind="TOOL") as span:
            # Your code here
            pass
    """
    tracer = get_tracer()
    # v5.0: create_span does NOT inherit context
    return tracer.start_span(name, kind, inherit_context=False, **kwargs)
