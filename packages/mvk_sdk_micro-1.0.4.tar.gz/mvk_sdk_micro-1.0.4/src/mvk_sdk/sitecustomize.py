"""Auto-instrumentation for MVK SDK v3.0.

This module is imported automatically when Python starts if placed in the
site-packages directory or PYTHONPATH. It registers import hooks for
supported libraries.
"""

import logging
import sys

logger = logging.getLogger(__name__)


def register_patches():
    """Register import hooks for auto-instrumentation."""
    try:
        import wrapt
    except ImportError:
        logger.warning("wrapt not installed, auto-instrumentation disabled")
        return

    # OpenAI
    @wrapt.when_imported("openai")
    def patch_openai(openai):
        try:
            from .wrappers import openai as openai_wrapper

            openai_wrapper.patch()
            logger.debug("OpenAI auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch OpenAI: {e}")

    # Anthropic
    @wrapt.when_imported("anthropic")
    def patch_anthropic(anthropic):
        try:
            from .wrappers import anthropic as anthropic_wrapper

            anthropic_wrapper.patch()
            logger.debug("Anthropic auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch Anthropic: {e}")

    # Cohere
    @wrapt.when_imported("cohere")
    def patch_cohere(cohere):
        try:
            from .wrappers import cohere as cohere_wrapper

            cohere_wrapper.patch()
            logger.debug("Cohere auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch Cohere: {e}")

    # Mistral
    @wrapt.when_imported("mistralai")
    def patch_mistral(mistralai):
        try:
            from .wrappers import mistral as mistral_wrapper

            mistral_wrapper.patch()
            logger.debug("Mistral auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch Mistral: {e}")

    # LangChain
    @wrapt.when_imported("langchain")
    def patch_langchain(langchain):
        try:
            from .wrappers import langchain as langchain_wrapper

            langchain_wrapper.patch()
            logger.debug("LangChain auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch LangChain: {e}")

    # LlamaIndex
    @wrapt.when_imported("llama_index")
    def patch_llama_index(llama_index):
        try:
            from .wrappers import llama_index as llama_index_wrapper

            llama_index_wrapper.patch()
            logger.debug("LlamaIndex auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch LlamaIndex: {e}")

    # ChromaDB
    @wrapt.when_imported("chromadb")
    def patch_chromadb(chromadb):
        try:
            from .wrappers import chromadb as chromadb_wrapper

            chromadb_wrapper.patch()
            logger.debug("ChromaDB auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch ChromaDB: {e}")

    # Pinecone
    @wrapt.when_imported("pinecone")
    def patch_pinecone(pinecone):
        try:
            from .wrappers import pinecone as pinecone_wrapper

            pinecone_wrapper.patch()
            logger.debug("Pinecone auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch Pinecone: {e}")

    # Weaviate
    @wrapt.when_imported("weaviate")
    def patch_weaviate(weaviate):
        try:
            from .wrappers import weaviate as weaviate_wrapper

            weaviate_wrapper.patch()
            logger.debug("Weaviate auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch Weaviate: {e}")

    # HTTPX
    @wrapt.when_imported("httpx")
    def patch_httpx(httpx):
        try:
            from .wrappers import httpx as httpx_wrapper

            httpx_wrapper.patch()
            logger.debug("HTTPX auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"Failed to patch HTTPX: {e}")


# Register patches when this module is imported
register_patches()
