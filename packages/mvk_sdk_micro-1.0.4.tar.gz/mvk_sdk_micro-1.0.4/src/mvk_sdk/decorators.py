"""MVK SDK v5.0 decorators.

Provides @mvk.track and mvk.context for manual instrumentation.
Supports W3C TraceContext and selective field inheritance.
"""

import functools
import inspect
import logging
from contextvars import ContextVar
from typing import Any, Callable, Dict, Optional, TypeVar, Union

from .context import get_merged_context, pop_context, push_context
from .propagator import propagator
from .schema import MVKSpanKind, check_field_mutability
from .tracer import get_current_span, get_tracer

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def track(
    kind: Optional[Union[str, MVKSpanKind]] = None,
    name: Optional[str] = None,
    operation: Optional[str] = None,
    operation_subtype: Optional[str] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    client_id: Optional[str] = None,
    cloud_provider_code: Optional[str] = None,
    **attributes,
) -> Callable[[F], F]:
    """Decorator to track a function as a span with v5.0 features.

    This decorator:
    - ALWAYS creates a new span (never reuses)
    - Supports selective field inheritance from parent @mvk.track
    - Extracts traceparent from HTTP requests if applicable
    - Allows user-provided cloud_provider_code

    Args:
        kind: Span kind (LLM, EMBEDDING, RETRIEVER, TOOL, MEMORY, AGENT_CALL)
        name: Span name (defaults to function name)
        operation: Operation type
        operation_subtype: Operation subtype
        session_id: Session identifier (inherits from parent @mvk.track)
        user_id: User identifier (inherits from parent @mvk.track)
        client_id: Client/caller identifier (inherits from parent @mvk.track)
        cloud_provider_code: Optional user-provided cloud provider
        **attributes: Additional span attributes

    Returns:
        Decorated function

    Example:
        @mvk.track(kind="LLM", operation="chat_completion",
                   cloud_provider_code="aws")
        def call_llm(prompt: str) -> str:
            return openai.complete(prompt)
    """

    def decorator(func: F) -> F:
        # Get function name for span name
        func_name = name or func.__name__

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            tracer = get_tracer()

            # Build span attributes with OTLP namespacing
            span_attrs = {}

            # v5.0: Check for selective inheritance from parent @mvk.track
            parent_span = get_current_span()
            if parent_span:
                # Only inherit specific fields from parent @mvk.track
                if hasattr(parent_span, "attributes"):
                    parent_attrs = parent_span.attributes
                    # Selective inheritance: session_id, user_id, client_id, and mvk.agent.name
                    if "mvk.session_id" in parent_attrs and not session_id:
                        span_attrs["mvk.session_id"] = parent_attrs["mvk.session_id"]
                    if "mvk.user_id" in parent_attrs and not user_id:
                        span_attrs["mvk.user_id"] = parent_attrs["mvk.user_id"]
                    if "mvk.client_id" in parent_attrs and not client_id:
                        span_attrs["mvk.client_id"] = parent_attrs["mvk.client_id"]
                    if "mvk.agent.name" in parent_attrs:
                        span_attrs["mvk.agent.name"] = parent_attrs["mvk.agent.name"]

            # Get context attributes FIRST (from global and @mvk.context)
            context_attrs = get_merged_context()
            # v5.0: Include global context with proper namespacing
            for key, value in context_attrs.items():
                # Apply OTLP namespacing if needed
                if key == "tags" and isinstance(value, dict):
                    # Flatten tags with tags.* prefix
                    for tag_key, tag_value in value.items():
                        span_attrs[f"tags.{tag_key}"] = tag_value
                elif key.startswith(("service.", "tags.", "http.", "db.", "rpc.")):
                    # Already properly namespaced - keep as is
                    span_attrs[key] = value
                elif key.startswith("mvk."):
                    # Already has mvk prefix
                    # Don't override inherited session_id with global context
                    if key == "mvk.session_id" and "mvk.session_id" in span_attrs:
                        continue  # Keep inherited value
                    span_attrs[key] = value
                else:
                    # Add mvk prefix to custom fields
                    # Don't override inherited fields with context
                    prefixed_key = f"mvk.{key}"
                    if (
                        prefixed_key in ["mvk.session_id", "mvk.user_id", "mvk.client_id"]
                        and prefixed_key in span_attrs
                    ):
                        continue  # Keep inherited value
                    span_attrs[prefixed_key] = value

            # Add span-specific fields AFTER context (to allow override)
            if operation:
                span_attrs["mvk.operation"] = operation
            if operation_subtype:
                span_attrs["mvk.operation_subtype"] = operation_subtype
            if session_id:
                span_attrs["mvk.session_id"] = session_id
            if user_id:
                span_attrs["mvk.user_id"] = user_id
            if client_id:
                span_attrs["mvk.client_id"] = client_id
            if cloud_provider_code:
                # v5.0: User-provided cloud provider (no auto-detection)
                span_attrs["mvk.cloud_provider_code"] = cloud_provider_code

            # Add any additional decorator attributes with OTLP namespacing
            for key, value in attributes.items():
                # v5.0: Allow all custom attributes from decorator
                # Only block truly immutable fields
                if key not in {
                    "trace_id",
                    "span_id",
                    "parent_span_id",
                    "start_time",
                    "end_time",
                    "duration_ms",
                }:
                    # Apply OTLP namespacing if needed
                    if key == "tags" and isinstance(value, dict):
                        # Flatten tags with tags.* prefix
                        for tag_key, tag_value in value.items():
                            span_attrs[f"tags.{tag_key}"] = tag_value
                    elif key.startswith(("service.", "tags.", "http.", "db.", "rpc.")):
                        # Already properly namespaced - keep as is
                        span_attrs[key] = value
                    elif key.startswith("mvk."):
                        # Already has mvk prefix
                        span_attrs[key] = value
                    else:
                        # Add mvk prefix to custom fields
                        span_attrs[f"mvk.{key}"] = value
                else:
                    logger.debug(f"Field {key} is immutable and cannot be set")

            # v5.0: ALWAYS create new span (never reuse)
            # Don't inherit context again - we already merged it above
            span = tracer.start_span(
                func_name, kind=str(kind) if kind else None, inherit_context=False, **span_attrs
            )
            with span:
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:
                    span.set_error(e)
                    raise

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            tracer = get_tracer()

            # Build span attributes (same as sync)
            span_attrs = {}

            # v5.0: Check for selective inheritance from parent @mvk.track
            parent_span = get_current_span()
            if parent_span:
                # Only inherit specific fields from parent @mvk.track
                if hasattr(parent_span, "attributes"):
                    parent_attrs = parent_span.attributes
                    # Selective inheritance: session_id, user_id, client_id, and mvk.agent.name
                    if "mvk.session_id" in parent_attrs and not session_id:
                        span_attrs["mvk.session_id"] = parent_attrs["mvk.session_id"]
                    if "mvk.user_id" in parent_attrs and not user_id:
                        span_attrs["mvk.user_id"] = parent_attrs["mvk.user_id"]
                    if "mvk.client_id" in parent_attrs and not client_id:
                        span_attrs["mvk.client_id"] = parent_attrs["mvk.client_id"]
                    if "mvk.agent.name" in parent_attrs:
                        span_attrs["mvk.agent.name"] = parent_attrs["mvk.agent.name"]

            # Get context attributes FIRST (from global and @mvk.context)
            context_attrs = get_merged_context()
            # v5.0: Include global context with proper namespacing
            for key, value in context_attrs.items():
                # Apply OTLP namespacing if needed
                if key == "tags" and isinstance(value, dict):
                    # Flatten tags with tags.* prefix
                    for tag_key, tag_value in value.items():
                        span_attrs[f"tags.{tag_key}"] = tag_value
                elif key.startswith(("service.", "tags.", "http.", "db.", "rpc.")):
                    # Already properly namespaced - keep as is
                    span_attrs[key] = value
                elif key.startswith("mvk."):
                    # Already has mvk prefix
                    # Don't override inherited session_id with global context
                    if key == "mvk.session_id" and "mvk.session_id" in span_attrs:
                        continue  # Keep inherited value
                    span_attrs[key] = value
                else:
                    # Add mvk prefix to custom fields
                    # Don't override inherited fields with context
                    prefixed_key = f"mvk.{key}"
                    if (
                        prefixed_key in ["mvk.session_id", "mvk.user_id", "mvk.client_id"]
                        and prefixed_key in span_attrs
                    ):
                        continue  # Keep inherited value
                    span_attrs[prefixed_key] = value

            # Add span-specific fields AFTER context (to allow override)
            if operation:
                span_attrs["mvk.operation"] = operation
            if operation_subtype:
                span_attrs["mvk.operation_subtype"] = operation_subtype
            if session_id:
                span_attrs["mvk.session_id"] = session_id
            if user_id:
                span_attrs["mvk.user_id"] = user_id
            if client_id:
                span_attrs["mvk.client_id"] = client_id
            if cloud_provider_code:
                # v5.0: User-provided cloud provider (no auto-detection)
                span_attrs["mvk.cloud_provider_code"] = cloud_provider_code

            # Add any additional decorator attributes with OTLP namespacing
            for key, value in attributes.items():
                # v5.0: Allow all custom attributes from decorator
                # Only block truly immutable fields
                if key not in {
                    "trace_id",
                    "span_id",
                    "parent_span_id",
                    "start_time",
                    "end_time",
                    "duration_ms",
                }:
                    # Apply OTLP namespacing if needed
                    if key == "tags" and isinstance(value, dict):
                        # Flatten tags with tags.* prefix
                        for tag_key, tag_value in value.items():
                            span_attrs[f"tags.{tag_key}"] = tag_value
                    elif key.startswith(("service.", "tags.", "http.", "db.", "rpc.")):
                        # Already properly namespaced - keep as is
                        span_attrs[key] = value
                    elif key.startswith("mvk."):
                        # Already has mvk prefix
                        span_attrs[key] = value
                    else:
                        # Add mvk prefix to custom fields
                        span_attrs[f"mvk.{key}"] = value
                else:
                    logger.debug(f"Field {key} is immutable and cannot be set")

            # v5.0: ALWAYS create new span (never reuse)
            # Don't inherit context again - we already merged it above
            span = tracer.start_span(
                func_name, kind=str(kind) if kind else None, inherit_context=False, **span_attrs
            )
            with span:
                try:
                    result = await func(*args, **kwargs)
                    return result
                except Exception as e:
                    span.set_error(e)
                    raise

        # Return appropriate wrapper
        if inspect.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        else:
            return sync_wrapper  # type: ignore

    return decorator


class context:
    """Context manager and decorator for setting context attributes.

    This unified interface replaces both @mvk_track decorator and
    with mvk_track_context() from v2.1.

    Can be used as both decorator and context manager:

    As decorator:
        @mvk.context(tier="premium", region="us-west")
        def process_request():
            pass

    As context manager:
        with mvk.context(tier="premium", region="us-west"):
            process_request()
    """

    def __init__(self, **attributes):
        """Initialize with context attributes."""
        self.attributes = attributes

    def __enter__(self):
        """Enter context manager - push attributes to context stack."""
        push_context(self.attributes)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager - pop attributes from context stack."""
        pop_context()
        return False

    def __call__(self, func: F) -> F:
        """Decorator mode - wrap function with context."""

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            with self:
                return func(*args, **kwargs)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            with self:
                return await func(*args, **kwargs)

        # Return appropriate wrapper
        if inspect.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        else:
            return sync_wrapper  # type: ignore
