. ./tasks/scripts/sh_runner.ps1

RunShFileWithGitBash -ShFilePath "./tasks/shims/sync_template"
. ./.venv/Scripts/activate.ps1
