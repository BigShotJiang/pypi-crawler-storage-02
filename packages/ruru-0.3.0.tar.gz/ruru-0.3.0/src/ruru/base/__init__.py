"""Base module for argument matching functionality."""

from ruru.base.matching import match_arg

__all__ = ["match_arg"]
