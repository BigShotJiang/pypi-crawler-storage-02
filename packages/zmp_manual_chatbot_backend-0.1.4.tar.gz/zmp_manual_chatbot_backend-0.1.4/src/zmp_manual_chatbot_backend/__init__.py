"""
ZMP Manual Chatbot Backend package.
Implements FastAPI backend for chatbot, integrating with MCP Server and LLM.
"""
