from tests.fixtures.services.jwt.asymmetric import *  # NOQA
from tests.fixtures.services.jwt.automatic import *  # NOQA
from tests.fixtures.services.jwt.symmetric import *  # NOQA
