"""Fractal Tokens provides a flexible way to generate and verify JWT tokens for your Python applications."""

__version__ = "1.4.3"
