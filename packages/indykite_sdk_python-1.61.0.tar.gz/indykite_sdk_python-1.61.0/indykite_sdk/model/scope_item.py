class ScopeItem:
    def __init__(self, name=None, display_name=None, description=None, required=None):

        self.name = name
        self.display_name = display_name
        self.description = description
        self.required = required
