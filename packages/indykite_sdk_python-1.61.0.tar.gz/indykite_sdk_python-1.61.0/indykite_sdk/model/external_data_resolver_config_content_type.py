from enum import Enum


class ContentType(Enum):
    CONTENT_TYPE_INVALID = 0
    CONTENT_TYPE_JSON = 1
