from enum import Enum


class KeyType(Enum):
    JWK = 'jwk'
    PEM = 'pem'
