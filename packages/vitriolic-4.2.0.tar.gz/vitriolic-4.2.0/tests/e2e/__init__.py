"""End-to-end tests for Vitriolic tournament management system."""
