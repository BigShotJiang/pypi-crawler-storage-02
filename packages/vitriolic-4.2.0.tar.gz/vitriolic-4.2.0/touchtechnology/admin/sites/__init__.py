from touchtechnology.admin.sites.admin import AdminSite

site = AdminSite()
