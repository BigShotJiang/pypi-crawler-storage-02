$(function () {

  // Enable popover on pricing plans
  $('.pricing-plan-help').popover ({
    placement: 'right'
    , trigger: 'hover'
    , container: 'body'
    , delay: { show: 250, hide: 250 }
  })

})