class NotModelManager(Exception):
    """Cannot determine model and/or manager"""
