class RelatedVisitFieldError(Exception):
    pass


class RelatedVisitModelError(Exception):
    pass


class RelatedVisitReasonError(Exception):
    pass
