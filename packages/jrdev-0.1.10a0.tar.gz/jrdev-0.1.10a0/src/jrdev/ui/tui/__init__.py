"""
Textual UI components for JrDev
"""

from jrdev.ui.tui.code.code_confirmation_screen import CodeConfirmationScreen

__all__ = ["CodeConfirmationScreen", "TerminalOutputWidget"]
