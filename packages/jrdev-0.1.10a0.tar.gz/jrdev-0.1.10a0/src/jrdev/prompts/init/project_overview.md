Given the file tree and the provided file context's as well as the project conventions analysis, output a conceptual 3 
paragraph descriptive overview of the project. The response will be read by both LLM's and humans, so write it accordingly. Format 
response as markdown.