The project structure below is in a compact format for efficiency:
- ROOT=directory_name: The root directory name
- path/to/dir:[file1,file2,...]: Files in a directory
Each line represents either the root directory or a directory with its files.