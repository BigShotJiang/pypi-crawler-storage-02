from tagoapi import *


client = TAGOClient(auth=TAGOAuth("tlqkf"))