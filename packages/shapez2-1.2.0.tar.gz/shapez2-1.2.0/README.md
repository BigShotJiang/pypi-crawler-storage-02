A package to code tools for shapez 2

```
pip install shapez2
```

Requires [Pillow](https://pypi.org/project/pillow/)