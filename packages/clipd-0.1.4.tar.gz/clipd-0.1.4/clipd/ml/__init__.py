# TODO : clipd knn
# Will display some basic knn stats and autogenerate a py.file
