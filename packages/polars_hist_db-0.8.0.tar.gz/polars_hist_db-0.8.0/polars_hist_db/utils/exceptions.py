class NonRetryableException(Exception):
    """Raise for non-retryable exceptions"""
