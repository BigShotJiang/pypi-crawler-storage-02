if __name__ == "__main__":
    from sample.app import app
    exit_code = app.main()
    exit(exit_code)
