knit\_script.knit\_script\_interpreter.expressions.function\_expressions module
===============================================================================

.. automodule:: knit_script.knit_script_interpreter.expressions.function_expressions
   :members:
   :undoc-members:
   :show-inheritance:
