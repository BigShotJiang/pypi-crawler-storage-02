knit\_script.knit\_script\_interpreter.expressions.formatted\_string module
===========================================================================

.. automodule:: knit_script.knit_script_interpreter.expressions.formatted_string
   :members:
   :undoc-members:
   :show-inheritance:
