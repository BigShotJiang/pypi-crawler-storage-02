knit\_script.knit\_script\_std\_library.needles module
======================================================

.. automodule:: knit_script.knit_script_std_library.needles
   :members:
   :undoc-members:
   :show-inheritance:
