knit\_script.knit\_script\_interpreter.expressions.needle\_set\_expression module
=================================================================================

.. automodule:: knit_script.knit_script_interpreter.expressions.needle_set_expression
   :members:
   :undoc-members:
   :show-inheritance:
