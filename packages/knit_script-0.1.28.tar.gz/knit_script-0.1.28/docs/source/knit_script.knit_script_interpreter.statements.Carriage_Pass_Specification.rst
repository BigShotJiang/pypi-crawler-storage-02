knit\_script.knit\_script\_interpreter.statements.Carriage\_Pass\_Specification module
======================================================================================

.. automodule:: knit_script.knit_script_interpreter.statements.Carriage_Pass_Specification
   :members:
   :undoc-members:
   :show-inheritance:
