# Letta + local LLMs

See [https://letta.readme.io/docs/local_llm](https://letta.readme.io/docs/local_llm) for documentation on running Letta with custom LLM backends.
