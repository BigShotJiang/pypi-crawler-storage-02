DEFAULT_REALM = "master"  # https://www.keycloak.org/docs/latest/server_admin/index.html#the-master-realm
DEFAULT_REQUEST_TIMEOUT = 30
