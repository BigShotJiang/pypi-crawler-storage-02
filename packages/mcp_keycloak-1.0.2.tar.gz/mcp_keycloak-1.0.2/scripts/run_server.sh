#!/bin/bash

# Run with uv
uv run python -m src