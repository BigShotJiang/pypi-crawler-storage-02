"""Fetch FHIR data from your EHR easily and completely"""

__version__ = "0.4.0"
