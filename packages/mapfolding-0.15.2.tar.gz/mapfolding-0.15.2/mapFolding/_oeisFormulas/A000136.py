from mapFolding._oeisFormulas.A000682 import A000682

def A000136(n: int) -> int:
	return n * A000682(n)
