# sonolus.script.interval

::: sonolus.script.interval
