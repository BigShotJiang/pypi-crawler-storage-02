# 😄Emoji-bars, your colourful emoji bars

Welcome to emoji-bars,  a simple Python package making terminal loading bars and regular bars much easier!

BETA: THIS PROJECT IS STILL IN BETA TESTING

