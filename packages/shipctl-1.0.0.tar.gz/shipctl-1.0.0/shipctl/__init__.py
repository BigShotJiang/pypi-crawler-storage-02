import os

version = os.environ.get("SHIPCTL_VERSION", "2.0.0.dev0")

__version__ = version
