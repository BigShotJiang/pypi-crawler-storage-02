"""
Kinglet - A lightweight routing framework for Python Workers
"""

# Import everything from the main module
from .kinglet import *

__version__ = "1.1.0"
__author__ = "Mitchell Currie"