from django.apps import AppConfig


class CityCHAutocompleteConfig(AppConfig):
    name = "city_ch_autocomplete"
    label = "city_ch_autocomplete"
    default_auto_field = 'django.db.models.AutoField'
