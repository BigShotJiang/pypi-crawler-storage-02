from appodus_utils.domain.user.auth.social_login.providers.apple import AppleAuthProvider
from appodus_utils.domain.user.auth.social_login.providers.facebook import FacebookAuthProvider
from appodus_utils.domain.user.auth.social_login.providers.google import GoogleAuthProvider
