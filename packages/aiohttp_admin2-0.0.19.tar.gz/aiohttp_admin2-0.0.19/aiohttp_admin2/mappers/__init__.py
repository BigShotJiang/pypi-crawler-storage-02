# flake8: noqa
from aiohttp_admin2.mappers.base import Mapper
from aiohttp_admin2.mappers.fields import *
