# flake8: noqa
from aiohttp_admin2.resources.postgres_resource.postgres_resource import \
    PostgresResource
from aiohttp_admin2.resources.dict_resource.dict_resource import DictResource
from aiohttp_admin2.resources.abc import Instance
