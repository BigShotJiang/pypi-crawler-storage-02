__author__ = """Mykhailo Havelia"""
__email__ = 'misha.gavela@gmail.com'
__version__ = '0.0.19'


from aiohttp_admin2.views.aiohttp.setup import setup_admin

__all__ = ["setup_admin", ]
