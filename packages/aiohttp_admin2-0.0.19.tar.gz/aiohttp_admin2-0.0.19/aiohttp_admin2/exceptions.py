class AdminException(Exception):
    """The main exception for all exceptions in this library."""
