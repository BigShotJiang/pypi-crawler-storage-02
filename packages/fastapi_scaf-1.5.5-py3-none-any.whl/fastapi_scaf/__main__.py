"""
@author axiner
@version v1.0.0
@created 2024/07/29 22:22
@abstract main
@description
@history
"""
from fastapi_scaff.__main__ import main as _main


def main():
    _main()


if __name__ == "__main__":
    main()
