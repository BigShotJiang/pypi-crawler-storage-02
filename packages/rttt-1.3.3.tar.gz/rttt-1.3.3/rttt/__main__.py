from rttt import cli

cli.main()
