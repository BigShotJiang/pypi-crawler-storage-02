GLOBAL_PATTERN = r"[A-Z][A-Z_1-9]{2,}$"
