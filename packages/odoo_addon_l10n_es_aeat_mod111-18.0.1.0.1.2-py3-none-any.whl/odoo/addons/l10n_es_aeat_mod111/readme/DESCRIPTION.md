Modelo 111 de la AEAT. Retenciones e ingresos a cuenta. Rendimientos del
trabajo y de actividades económicas, premios y determinadas ganancias
patrimoniales e imputaciones de Renta. Autoliquidación.
