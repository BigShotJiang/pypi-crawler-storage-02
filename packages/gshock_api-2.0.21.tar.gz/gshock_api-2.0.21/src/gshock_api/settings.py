class Settings:
    time_format = ""
    date_format = ""
    language = ""
    auto_light = False
    light_duration = ""
    power_saving_mode = False
    button_tone = True
    time_adjustment = True


settings = Settings()
