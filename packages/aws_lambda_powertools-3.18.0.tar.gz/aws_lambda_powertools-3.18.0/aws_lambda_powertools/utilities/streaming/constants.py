MESSAGE_STREAM_NOT_WRITABLE = "this stream is not writable"
