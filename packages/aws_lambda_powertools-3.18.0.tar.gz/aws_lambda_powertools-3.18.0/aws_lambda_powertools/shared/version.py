"""Exposes version constant to avoid circular dependencies."""

VERSION = "3.18.0"
