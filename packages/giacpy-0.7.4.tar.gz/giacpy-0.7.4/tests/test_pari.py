from giacpy import giac
giac('pari()')
print(giac('pari_factor(6)'))
print(giac('pari_version("")'))
