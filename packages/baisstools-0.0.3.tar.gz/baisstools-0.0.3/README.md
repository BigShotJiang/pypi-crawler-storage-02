# Baiss Tools

## Installation (from PyPI)
```bash
pip install baisstools
```

## Installation (from github, using SSH, branch: main)
```bash
pip install git+ssh://git@github.com/tbeninnovation-mobileapp/baisstools.git@main
```

## Installation (from github, using SSH, branch: abdelmathin/gitinit)
```bash
pip install git+ssh://git@github.com/tbeninnovation-mobileapp/baisstools.git@abdelmathin/gitinit
```

## Uninstallation

```bash
pip uninstall baisstools
```
