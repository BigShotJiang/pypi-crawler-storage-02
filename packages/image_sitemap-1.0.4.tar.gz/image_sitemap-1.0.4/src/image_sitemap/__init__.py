from image_sitemap.__version__ import __version__  # noqa

from .main import Sitemap
