data Module
============================


.. automodule:: adaptivetesting.data
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:
