from dataclasses import dataclass


@dataclass
class ConfigOCCPData:
    url: str = None
