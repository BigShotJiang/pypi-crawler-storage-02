# MIDASFlow

[![PyPI version](https://badge.fury.io/py/midasflow.svg)](https://badge.fury.io/py/midasflow)
[![Documentation Status](https://readthedocs.org/projects/midasflow/badge/?version=latest)](https://midasflow.readthedocs.io/en/latest/?badge=latest)

[MIDASFlow](https://github.com/HuidaeCho/midasflow) is the Python package for the [Memory-Efficient I/O-Improved Drainage Analysis System (MIDAS)](https://github.com/HuidaeCho/midas).

## Change log

See [here](https://github.com/HuidaeCho/midasflow/blob/main/ChangeLog.md).

## Related projects

* [MIDAS](https://github.com/HuidaeCho/midas)
* [MIDAS QGIS plugin](https://github.com/HuidaeCho/midas-qgis)

## Versioning

`N(.N)*[{a|b|rc}N][.postN][.devN]`

* [PEP 440](https://www.python.org/dev/peps/pep-0440/)
* `{a|b|rc|.dev}N` towards and `.postN` away from the release
* Not fully compatible with [semantic versioning](https://semver.org/)
* Not using build numbers marching away from or towards a release, but check
  this [interesting
  comment](https://github.com/semver/semver/issues/51#issuecomment-9718111).

## License

Copyright (C) 2025 [Huidae Cho](https://hcho.isnew.info/)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <<https://www.gnu.org/licenses/>>.
