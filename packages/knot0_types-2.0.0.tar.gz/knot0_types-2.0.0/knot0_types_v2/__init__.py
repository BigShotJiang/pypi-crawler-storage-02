# Auto-generated package for Knot0 v2 types
# This will be populated by the generate-pydantic-models.py script