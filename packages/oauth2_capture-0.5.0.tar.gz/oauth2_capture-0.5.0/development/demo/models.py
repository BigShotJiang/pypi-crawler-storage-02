"""Models for the demo app."""
