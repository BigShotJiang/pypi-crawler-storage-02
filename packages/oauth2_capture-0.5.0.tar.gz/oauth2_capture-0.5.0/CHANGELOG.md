## 0.5.0 (2025-08-06)

### Feat

- migrate from flit to hatchling with trusted publishing

## 0.4.0 (2025-05-10)

### Feat

- **facebook**: added capture for facebook

### Fix

- **refresh_token**: fix the refresh token flow, added 429 retries and reddit posting

## 0.3.0 (2025-05-10)

### Feat

- **pinterest**: added pinterest as a provider

## 0.2.0 (2025-05-09)

### Feat

- **pinterest**: added pinterest as a provider

## 0.1.8 (2025-03-05)

### Feat

- **oauth**: show a nice table of acquired tokens
- **oauth2**: listing more metadata about captured tokens

## 0.1.6 (2025-03-05)

## 0.1.5 (2025-03-05)

### Fix

- **models**: changed default string for OAuthToken model

## 0.1.4 (2024-11-21)

## 0.1.3 (2024-11-21)

## 0.1.2 (2024-11-21)

## 0.1.1 (2024-11-21)

## 0.1.0 (2024-11-21)

### Feat

- **oath2_token**: added username property to help display see what username is attached

## 0.0.9 (2024-10-14)

### Fix

- **oauth2,logging**: safety checks on returned values in oauth2 flow

## 0.0.8 (2024-10-14)

### Fix

- **github,linkedin**: fix function signature for update_token
