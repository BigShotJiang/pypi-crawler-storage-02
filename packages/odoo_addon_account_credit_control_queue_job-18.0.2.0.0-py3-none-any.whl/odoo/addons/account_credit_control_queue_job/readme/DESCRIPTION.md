Once this module is installed, the emails will be sent in individual jobs.
