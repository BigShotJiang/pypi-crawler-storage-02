# Copyright 2025 360ERP (<https://www.360erp.com>)
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from . import res_config_settings
