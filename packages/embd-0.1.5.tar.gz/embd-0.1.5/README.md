# embd

Unix embedding driver for software 2.0
