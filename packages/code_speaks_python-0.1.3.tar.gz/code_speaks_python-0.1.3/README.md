# pydemo

A small demo Python package for testing PyPI uploads.

## Installation

```bash
pip install pydemo
