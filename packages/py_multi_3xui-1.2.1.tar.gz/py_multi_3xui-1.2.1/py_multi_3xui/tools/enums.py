import enum

class ExitDataFormat(enum.Enum):
    JSON = 1
    STRING = 2
    XML = 3