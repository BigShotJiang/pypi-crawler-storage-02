from mayan.apps.icons.icons import Icon

icon_app_list = Icon(driver_name='fontawesome', symbol='cubes')
