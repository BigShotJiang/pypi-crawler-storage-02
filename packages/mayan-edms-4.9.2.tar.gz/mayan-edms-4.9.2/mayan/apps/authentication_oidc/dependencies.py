from mayan.apps.dependencies.classes import PythonDependency

PythonDependency(
    module=__name__, name='mozilla-django-oidc', version_string='==4.0.1'
)
