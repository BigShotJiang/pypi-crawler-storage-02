# Basic error when parsing model files
class ParseError(Exception):
    pass
