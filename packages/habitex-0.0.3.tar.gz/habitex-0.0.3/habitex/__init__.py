import os
from habitex.archive_explorer import ArchiveExplorer
from habitex.hz_plots import PlotHZ

__version__ = "0.0.2"
habitex_dir = os.path.dirname(__file__)
