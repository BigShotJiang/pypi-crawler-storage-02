## httpetcd

Etcd client over HTTP

Some code is borrowed from `etcd3gw` package (but mostly is written from scratch):
* https://pypi.org/project/etcd3gw/
* https://opendev.org/openstack/etcd3gw
