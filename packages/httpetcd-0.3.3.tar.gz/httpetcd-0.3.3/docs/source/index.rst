.. httpetcd's documentation master file, created by
   sphinx-quickstart on Sun Aug  5 14:13:14 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Welcome to httpetcd's documentation!
=====================================

Etcd client over HTTP

.. toctree::
    :maxdepth: 2
    :caption: Оглавление:

    usage
    releasenotes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
