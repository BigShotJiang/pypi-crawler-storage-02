#!/usr/bin/env python3
"""Make yourbench runnable as a module."""

from yourbench.main import main


if __name__ == "__main__":
    main()
