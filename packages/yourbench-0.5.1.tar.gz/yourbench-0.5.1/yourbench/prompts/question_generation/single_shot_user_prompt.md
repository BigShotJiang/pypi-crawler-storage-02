<additional_instructions>
{additional_instructions}
</additional_instructions> 

<title>
{title}
</title>

<document_summary>
{document_summary}
</document_summary>

<text_chunk>
{text_chunk}
</text_chunk>
