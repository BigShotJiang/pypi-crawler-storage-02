# main.py (chatbot template)
print("Hello — this is the Chatbot template's main.py")
