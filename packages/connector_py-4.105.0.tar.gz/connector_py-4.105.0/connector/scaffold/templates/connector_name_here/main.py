from connector.cli import run_integration

from {name}.integration import integration


def main():
    run_integration(integration)


if __name__ == "__main__":
    main()
