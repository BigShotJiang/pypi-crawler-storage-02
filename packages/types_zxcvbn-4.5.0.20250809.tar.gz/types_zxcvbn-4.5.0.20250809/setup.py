
from setuptools import setup

setup(package_data={'zxcvbn-stubs': ['__init__.pyi', 'adjacency_graphs.pyi', 'feedback.pyi', 'frequency_lists.pyi', 'matching.pyi', 'scoring.pyi', 'time_estimates.pyi', 'METADATA.toml', 'py.typed']})
