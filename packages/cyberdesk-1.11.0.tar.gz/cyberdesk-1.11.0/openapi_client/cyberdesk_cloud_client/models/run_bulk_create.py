from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_input import FileInput
    from ..models.run_bulk_create_input_values_type_0 import RunBulkCreateInputValuesType0


T = TypeVar("T", bound="RunBulkCreate")


@_attrs_define
class RunBulkCreate:
    """Schema for bulk creating runs

    Attributes:
        workflow_id (UUID):
        count (int): Number of runs to create (max 1000)
        machine_id (Union[None, UUID, Unset]): Machine ID. If not provided, an available machine will be automatically
            selected.
        input_values (Union['RunBulkCreateInputValuesType0', None, Unset]): Input values for workflow variables
        file_inputs (Union[None, Unset, list['FileInput']]): Files to upload to the machine
    """

    workflow_id: UUID
    count: int
    machine_id: Union[None, UUID, Unset] = UNSET
    input_values: Union["RunBulkCreateInputValuesType0", None, Unset] = UNSET
    file_inputs: Union[None, Unset, list["FileInput"]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.run_bulk_create_input_values_type_0 import RunBulkCreateInputValuesType0

        workflow_id = str(self.workflow_id)

        count = self.count

        machine_id: Union[None, Unset, str]
        if isinstance(self.machine_id, Unset):
            machine_id = UNSET
        elif isinstance(self.machine_id, UUID):
            machine_id = str(self.machine_id)
        else:
            machine_id = self.machine_id

        input_values: Union[None, Unset, dict[str, Any]]
        if isinstance(self.input_values, Unset):
            input_values = UNSET
        elif isinstance(self.input_values, RunBulkCreateInputValuesType0):
            input_values = self.input_values.to_dict()
        else:
            input_values = self.input_values

        file_inputs: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.file_inputs, Unset):
            file_inputs = UNSET
        elif isinstance(self.file_inputs, list):
            file_inputs = []
            for file_inputs_type_0_item_data in self.file_inputs:
                file_inputs_type_0_item = file_inputs_type_0_item_data.to_dict()
                file_inputs.append(file_inputs_type_0_item)

        else:
            file_inputs = self.file_inputs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "workflow_id": workflow_id,
                "count": count,
            }
        )
        if machine_id is not UNSET:
            field_dict["machine_id"] = machine_id
        if input_values is not UNSET:
            field_dict["input_values"] = input_values
        if file_inputs is not UNSET:
            field_dict["file_inputs"] = file_inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_input import FileInput
        from ..models.run_bulk_create_input_values_type_0 import RunBulkCreateInputValuesType0

        d = dict(src_dict)
        workflow_id = UUID(d.pop("workflow_id"))

        count = d.pop("count")

        def _parse_machine_id(data: object) -> Union[None, UUID, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                machine_id_type_0 = UUID(data)

                return machine_id_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, UUID, Unset], data)

        machine_id = _parse_machine_id(d.pop("machine_id", UNSET))

        def _parse_input_values(data: object) -> Union["RunBulkCreateInputValuesType0", None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                input_values_type_0 = RunBulkCreateInputValuesType0.from_dict(data)

                return input_values_type_0
            except:  # noqa: E722
                pass
            return cast(Union["RunBulkCreateInputValuesType0", None, Unset], data)

        input_values = _parse_input_values(d.pop("input_values", UNSET))

        def _parse_file_inputs(data: object) -> Union[None, Unset, list["FileInput"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                file_inputs_type_0 = []
                _file_inputs_type_0 = data
                for file_inputs_type_0_item_data in _file_inputs_type_0:
                    file_inputs_type_0_item = FileInput.from_dict(file_inputs_type_0_item_data)

                    file_inputs_type_0.append(file_inputs_type_0_item)

                return file_inputs_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["FileInput"]], data)

        file_inputs = _parse_file_inputs(d.pop("file_inputs", UNSET))

        run_bulk_create = cls(
            workflow_id=workflow_id,
            count=count,
            machine_id=machine_id,
            input_values=input_values,
            file_inputs=file_inputs,
        )

        run_bulk_create.additional_properties = d
        return run_bulk_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
