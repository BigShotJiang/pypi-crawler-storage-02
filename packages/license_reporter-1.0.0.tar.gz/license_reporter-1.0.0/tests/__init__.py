"""
Test package for license_reporter.
"""
