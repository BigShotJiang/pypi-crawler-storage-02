from .cli import run_gcn10

__version__ = "0.1.0"
__all__ = ["run_gcn10"]
