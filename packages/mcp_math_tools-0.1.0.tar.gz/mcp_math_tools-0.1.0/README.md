# mcp_math_tools

A set of MCP-compatible math tools for LLMs and AI agents.

### Tools Included:

- Matrix multiplication
- Quadratic equation solver (symbolic with sympy)
- Eigenvalue and eigenvector solver
