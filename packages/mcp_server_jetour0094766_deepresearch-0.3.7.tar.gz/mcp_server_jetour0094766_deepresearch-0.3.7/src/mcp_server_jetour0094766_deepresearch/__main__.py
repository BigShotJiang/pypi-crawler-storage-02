#!/usr/bin/env python3
"""
DeepResearch MCP Server Entry Point
"""
from mcp_server_jetour0094766_deepresearch.server import main

if __name__ == "__main__":
    main()