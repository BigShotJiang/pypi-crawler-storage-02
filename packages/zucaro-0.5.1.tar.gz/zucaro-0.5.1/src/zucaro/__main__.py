#!/bin/python

if __name__ == "__main__":
    from zucaro import main

    main()
