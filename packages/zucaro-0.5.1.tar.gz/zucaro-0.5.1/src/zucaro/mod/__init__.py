from . import curse, fabric, forge, ftb, quilt

LOADERS = [fabric, forge, quilt]
PACKS = [curse, ftb]