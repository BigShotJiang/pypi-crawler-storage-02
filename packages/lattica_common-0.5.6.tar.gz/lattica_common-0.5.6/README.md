# Lattica Common

This is the common library for Lattica's Python client packages.

## Important Notice

This package is distributed under a restrictive proprietary license. Please see LICENSE.txt for the complete terms and conditions.

**Contact**: support@lattica.ai

© 2025 LatticaAI Inc. All rights reserved.
