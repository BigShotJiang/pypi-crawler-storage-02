default_app_config = "aiwaf.apps.AiwafConfig"

__version__ = "0.1.9.1.4"

# Note: Middleware classes are available from aiwaf.middleware
# Import them only when needed to avoid circular imports during Django app loading
