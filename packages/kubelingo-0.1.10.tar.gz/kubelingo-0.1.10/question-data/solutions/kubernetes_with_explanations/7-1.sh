source <(kubectl completion bash)
