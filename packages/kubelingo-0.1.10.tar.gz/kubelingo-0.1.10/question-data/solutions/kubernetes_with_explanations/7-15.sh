kubectl delete deployment frontend
