kubectl config set-context --current --namespace=production
