kubectl create deployment frontend --image=nginx:1.14
