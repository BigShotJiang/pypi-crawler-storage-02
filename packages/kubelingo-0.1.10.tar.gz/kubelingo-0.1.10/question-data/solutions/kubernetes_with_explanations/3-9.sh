kubectl create quota ns-quota --hard=pods=10 -n development
