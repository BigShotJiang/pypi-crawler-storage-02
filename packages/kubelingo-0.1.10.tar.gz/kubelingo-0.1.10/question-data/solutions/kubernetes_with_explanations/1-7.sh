kubectl run nginx --image=nginx --dry-run=client -o yaml > pod.yaml # then add resource requests
