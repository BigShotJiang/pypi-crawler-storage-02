kubectl create cm app-settings --from-file=/configs
