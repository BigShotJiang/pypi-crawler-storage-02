kubectl delete namespace dev
