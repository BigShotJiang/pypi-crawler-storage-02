kubectl rollout undo deployment frontend
