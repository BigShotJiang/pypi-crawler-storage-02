kubectl create secret generic db-creds --from-literal=username=admin --from-literal=password=password123
