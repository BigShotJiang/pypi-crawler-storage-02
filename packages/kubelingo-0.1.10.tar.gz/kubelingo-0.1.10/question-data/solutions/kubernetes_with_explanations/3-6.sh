kubectl run nginx --image=nginx -n development
