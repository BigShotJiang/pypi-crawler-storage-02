alias k=kubectl
