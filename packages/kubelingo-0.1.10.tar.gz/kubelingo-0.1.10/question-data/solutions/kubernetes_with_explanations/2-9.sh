kubectl rollout resume deployment/frontend
