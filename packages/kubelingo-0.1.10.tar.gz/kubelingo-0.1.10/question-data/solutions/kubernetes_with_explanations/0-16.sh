k get netpol
