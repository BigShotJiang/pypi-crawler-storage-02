kubectl config use-context minikube
