kubectl get cm env-config
