kubectl describe secret db-secret
