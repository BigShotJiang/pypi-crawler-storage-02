This is a complex scenario. Follow the prompt instructions on the specified instance.
