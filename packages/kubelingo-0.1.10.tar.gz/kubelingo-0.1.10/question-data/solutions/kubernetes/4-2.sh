kubectl get secret api-secrets -o yaml
