kubectl describe service frontend-svc
