kubectl exec -it busybox -- /bin/sh
