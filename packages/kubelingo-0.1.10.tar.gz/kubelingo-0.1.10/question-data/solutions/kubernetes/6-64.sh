kubectl explain pods
