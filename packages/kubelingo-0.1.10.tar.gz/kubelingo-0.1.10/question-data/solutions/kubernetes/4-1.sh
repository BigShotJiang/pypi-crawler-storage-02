kubectl get secret tls-cert
