kubectl describe pod busybox
