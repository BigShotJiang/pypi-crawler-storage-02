grep -q 'source <(kubectl completion bash)' ~/.bashrc
