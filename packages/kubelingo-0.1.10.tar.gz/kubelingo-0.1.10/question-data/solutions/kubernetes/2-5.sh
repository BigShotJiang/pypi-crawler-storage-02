kubectl get pods -n kube-system
