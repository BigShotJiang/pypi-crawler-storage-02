kubectl get pods busybox -o json
