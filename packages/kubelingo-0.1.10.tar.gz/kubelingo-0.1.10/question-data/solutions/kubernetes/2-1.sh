kubectl config view --minify | grep 'namespace: production'
