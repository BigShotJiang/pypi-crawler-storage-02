kubectl cluster-info
