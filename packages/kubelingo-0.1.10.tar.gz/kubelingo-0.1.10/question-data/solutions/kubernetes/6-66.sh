kubectl get pods --show-labels
