kubectl config get-contexts -o name
