kubectl get pods busybox -o yaml
