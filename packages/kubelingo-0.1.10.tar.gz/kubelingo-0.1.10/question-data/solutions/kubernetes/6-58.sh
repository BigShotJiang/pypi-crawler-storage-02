kubectl config current-context
