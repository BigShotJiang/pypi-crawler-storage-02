/pattern
