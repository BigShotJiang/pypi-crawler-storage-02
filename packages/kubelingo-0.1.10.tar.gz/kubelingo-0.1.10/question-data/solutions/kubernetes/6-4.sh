kubectl version
