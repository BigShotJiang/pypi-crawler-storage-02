[ -f config.yaml ] && grep -q 'kind: ConfigMap' config.yaml
