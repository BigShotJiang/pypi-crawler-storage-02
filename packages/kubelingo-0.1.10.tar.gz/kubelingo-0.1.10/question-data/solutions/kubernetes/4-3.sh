echo 'This is validated by user running the command.'
