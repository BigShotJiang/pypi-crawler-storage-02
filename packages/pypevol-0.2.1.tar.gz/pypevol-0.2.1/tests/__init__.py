"""Test package initialization."""

# Empty __init__.py file for tests package
