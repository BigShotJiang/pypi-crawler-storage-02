Documentation
=============

.. toctree::
   :maxdepth: 2

   figaro.cosmology
   figaro.credible_regions
   figaro.cumulative
   figaro.decorators
   figaro.diagnostic
   figaro.load
   figaro.marginal
   figaro.mixture
   figaro.montecarlo
   figaro.plot
   figaro.rate
   figaro.transform
   figaro.utils
