﻿figaro.transform
================

.. automodule:: figaro.transform

   
   
   .. rubric:: Module Attributes

   .. autosummary::
   
      log2PI
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      log_gradient_inv_jacobian
      probit_logJ
      probit_log_jacobian
      transform_from_probit
      transform_to_probit
   
   

   
   
   

   
   
   



