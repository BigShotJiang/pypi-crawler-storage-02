figaro.decorators module
========================

.. automodule:: figaro.decorators
   :members:
   :undoc-members:
   :show-inheritance:
