figaro.montecarlo module
========================

.. automodule:: figaro.montecarlo
   :members:
   :undoc-members:
   :show-inheritance:
