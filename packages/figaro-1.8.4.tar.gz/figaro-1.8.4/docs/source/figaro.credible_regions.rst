figaro.credible\_regions module
===============================

.. automodule:: figaro.credible_regions
   :members:
   :undoc-members:
   :show-inheritance:
