import requests
import dotenv
from dotenv import load_dotenv
from datetime import datetime

def greet_yangq():
    print("hello yangq")

if __name__ == "__main__":
    greet_yangq()
