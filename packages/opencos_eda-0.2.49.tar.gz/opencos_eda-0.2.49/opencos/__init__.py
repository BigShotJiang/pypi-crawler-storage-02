'''__init__ package for opencos.'''

from ._version import VERSION, NAME

__version__ = VERSION
__pyproject_name__ = NAME
