"""Tests for the Cline prompt integration with user prompts."""
