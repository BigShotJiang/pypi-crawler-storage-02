"""Mapping layer for converting between domain and infrastructure models."""
