"""Cloning infrastructure."""
