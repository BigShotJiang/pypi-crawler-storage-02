# dirflex/__init__.py
from .cli import main
