``craft_archives.defaults``
===========================

.. py:module:: craft_archives.defaults

This module allows modification of the default sources in a given root.

.. autofunction:: use_old_releases
