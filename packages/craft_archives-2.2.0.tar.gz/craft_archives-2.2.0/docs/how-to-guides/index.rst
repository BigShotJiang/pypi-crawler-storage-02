.. _how-to-guides:

How-to guides
=============

.. toctree::
   :maxdepth: 1

   add_repo
