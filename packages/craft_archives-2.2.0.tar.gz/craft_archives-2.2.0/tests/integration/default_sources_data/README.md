# Sources data

Each directory here is a test case for integration testing the `use_old_releases`
function. Each `*.new` file is the expected value of the file after running the
`use_old_releases` function. A flag file named `.is_eol` is placed in the directory
for any release that is expected to exist on the old-releases site.
