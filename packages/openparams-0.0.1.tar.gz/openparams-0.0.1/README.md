# openparams

Coming soon — streaming model weights for research.

This is a placeholder package to reserve the name on PyPI.

- Homepage: https://github.com/Aristide021/openweights
- License: MIT

