---
layout: default
title: Usage
nav_order: 4
has_children: true
permalink: /usage/
---

# Usage

This section covers how to use nGPT, including detailed command-line usage, configuration options, and specialized features like Git commit message generation.