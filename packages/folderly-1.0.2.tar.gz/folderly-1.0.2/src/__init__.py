"""
Folderly Source Package
Main package containing all Folderly functionality.
"""

__version__ = "1.0.0"
__author__ = "Folderly Team"

# This file makes the src directory a Python package
# Import modules as needed in other files 