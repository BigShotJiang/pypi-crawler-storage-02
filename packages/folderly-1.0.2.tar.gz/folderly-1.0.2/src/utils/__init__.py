"""
Utility functions for Folderly
Contains backup, undo, and utility operations.
"""

# This file makes the utils directory a Python package
# Import functions as needed in other files 