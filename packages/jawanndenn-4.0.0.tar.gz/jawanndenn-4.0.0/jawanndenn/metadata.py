# Copyright (C) 2016-2021 Sebastian Pipping <sebastian@pipping.org>
# Licensed under GNU Affero GPL v3 or later

APP_NAME = "jawanndenn"

_VERSION = (4, 0, 0)
VERSION_STR = ".".join(map(str, _VERSION))
