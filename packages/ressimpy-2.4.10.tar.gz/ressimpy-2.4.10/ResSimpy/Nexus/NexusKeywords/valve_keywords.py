# TODO: Not a complete list. Check manual for missing keywords.
# TODO: Delete the keywords that are not tokens (i.e. that are only values in a table)

VALVE_TABLE_KEYWORDS = ['VALVE', 'ICV', 'CHOKE']

VALVE_RATE_KEYWORDS = ['QALL', 'QOIL', 'QGAS', 'QWATER', 'QLIQ']

VALVE_KEYWORDS = VALVE_TABLE_KEYWORDS
