# TODO: Not a complete list. Check manual for missing keywords.
# TODO: Delete the keywords that are not tokens (i.e. that are only values in a table)

WATER_KEYWORDS = ['BW', 'CW', 'DENW', 'PPM', 'PREF', 'SALINITY', 'SUNITS', 'TEMP', 'VISW']
