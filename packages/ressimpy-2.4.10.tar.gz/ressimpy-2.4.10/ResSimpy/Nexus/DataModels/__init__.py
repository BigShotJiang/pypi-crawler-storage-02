"""Module containing the classes representing the parts of a Nexus model."""
