"""Constants for the Nexus module."""
from typing import Final

# Constants
DATE_WITH_TIME_LENGTH: Final[int] = 20
