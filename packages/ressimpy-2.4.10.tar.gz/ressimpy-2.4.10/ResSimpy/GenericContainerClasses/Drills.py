from abc import ABC
from dataclasses import dataclass, field
from typing import Literal, Sequence

from ResSimpy.DataModelBaseClasses.Drill import Drill
from ResSimpy.DataModelBaseClasses.OperationsMixin import NetworkOperationsMixIn


@dataclass(kw_only=True)
class Drills(NetworkOperationsMixIn, ABC):
    _drills: Sequence[Drill] = field(default_factory=list)

    @property
    def _network_element_name(self) -> Literal['drills']:
        return 'drills'
