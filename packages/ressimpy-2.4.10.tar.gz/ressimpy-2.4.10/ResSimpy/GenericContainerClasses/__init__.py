"""Contains the generic 'container classes' that manage the collections of the parts of the grid."""
