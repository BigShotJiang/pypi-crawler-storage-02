"""Module for handling mappings between ResSimpy attributes and their associated unit types."""
