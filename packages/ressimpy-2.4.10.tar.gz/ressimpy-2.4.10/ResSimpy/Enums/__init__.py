"""Module containing generic Enums."""

__all__ = ['HowEnum']
