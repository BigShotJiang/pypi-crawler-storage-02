"""Contains the Abstract Base Classes for objects that make up the parts of a model such as wells or grids."""
