"""Module containing all of the generic code related to dates and times."""
