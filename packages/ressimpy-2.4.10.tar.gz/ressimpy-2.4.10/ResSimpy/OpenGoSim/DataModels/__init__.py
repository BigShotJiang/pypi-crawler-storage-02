"""Module containing data models Enums for OpenGoSim."""
