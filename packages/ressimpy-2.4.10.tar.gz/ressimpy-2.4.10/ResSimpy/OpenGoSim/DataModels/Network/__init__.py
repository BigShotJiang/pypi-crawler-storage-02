"""A module containing the data objects for the OpenGoSim Network."""
