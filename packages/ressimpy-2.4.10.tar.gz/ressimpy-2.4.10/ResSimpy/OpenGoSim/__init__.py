"""ResSimpy OpenGoSim Module, containing the OpenGoSim derived classes and OpenGoSim specific modules."""
