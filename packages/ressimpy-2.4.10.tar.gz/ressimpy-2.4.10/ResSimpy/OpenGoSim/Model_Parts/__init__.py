"""Module containing all the OpenGoSim model parts."""
