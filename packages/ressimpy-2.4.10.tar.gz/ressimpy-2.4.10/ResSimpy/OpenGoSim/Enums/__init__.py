"""Module containing generic Enums for OpenGoSim."""
