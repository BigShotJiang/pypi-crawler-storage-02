#def main() -> None:
    #print("Hello from mystring-utils!")

from .stringutil import reverse_string, count_words, count_vowels, max_char_count

__all__ = ['reverse_string', 'max_char_count', 'count_words', 'count_vowels']