from .paths import OUTDIR, ensure_outdir, outpath, write_json, describe_outdir
