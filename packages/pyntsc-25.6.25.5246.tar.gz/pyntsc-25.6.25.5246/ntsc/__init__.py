from .ntsc import *

TYPE_2_OBJECT = {
    "createproject": ntsc.CreateProject,
    "testcase": ntsc.TestCase,
}