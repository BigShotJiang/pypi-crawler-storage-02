# -*- encoding: utf-8 -*-
# File: schemas.py
# Description: None

import enum


class RetrievalPostType(enum.Enum):
    TITLE_STRUCTURE = "TITLE_STRUCTURE"
