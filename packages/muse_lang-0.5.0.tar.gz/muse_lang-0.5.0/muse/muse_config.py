import pathlib
import os
APP_LOCATE = str(pathlib.Path(os.path.abspath(__file__)).parent)