from dataclasses import dataclass


@dataclass
class Parameter:
    name: str
    type: str
