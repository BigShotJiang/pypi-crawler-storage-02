from dataclasses import dataclass


@dataclass
class Property:
    name: str
    type: str
