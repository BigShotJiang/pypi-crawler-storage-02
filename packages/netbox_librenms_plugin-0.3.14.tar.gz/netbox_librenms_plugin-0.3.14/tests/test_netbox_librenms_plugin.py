#!/usr/bin/env python

"""Tests for `netbox_librenms_plugin` package."""
