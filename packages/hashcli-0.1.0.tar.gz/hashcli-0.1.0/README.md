# hash \#

Hash # (HAcker SHell).

## Installation

With pip:

    pip install hashcli
