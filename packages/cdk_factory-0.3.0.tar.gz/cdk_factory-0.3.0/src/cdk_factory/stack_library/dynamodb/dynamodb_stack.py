"""
DynamoDB Stack Pattern for CDK-Factory
Maintainers: Eric Wilson
MIT License.  See Project Root for the license information.
"""

from pathlib import Path
import aws_cdk as cdk
from aws_cdk import aws_dynamodb as dynamodb
from constructs import Construct
from cdk_factory.interfaces.istack import IStack
from aws_lambda_powertools import Logger
from cdk_factory.stack.stack_module_registry import register_stack
from typing import List, Dict, Any, Optional

logger = Logger(service="DynamoDBStack")


@register_stack("dynamodb_library_module")
class DynamoDBStack(IStack):
    """
    Reusable stack for AWS DynamoDB tables.
    Supports all major DynamoDB table parameters.
    """

    def __init__(self, scope: Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)
        self.db_config = None
        self.stack_config = None
        self.deployment = None
        self.workload = None
        self.table: dynamodb.TableV2 | None = None

    def build(self, stack_config, deployment, workload) -> None:
        self.stack_config = stack_config
        self.deployment = deployment
        self.workload = workload
        from cdk_factory.configurations.resources.dynamodb import DynamoDBConfig

        self.db_config = DynamoDBConfig(
            stack_config.dictionary.get("dynamodb", {}), deployment
        )

        # Determine if we're using an existing table or creating a new one
        if self.db_config.use_existing:
            self._import_existing_table()
        else:
            self._create_new_table()

    def _import_existing_table(self) -> None:
        """Import an existing DynamoDB table"""
        table_name = self.db_config.name

        logger.info(f"Importing existing DynamoDB table: {table_name}")

        self.table = dynamodb.Table.from_table_name(
            self, id=f"{table_name}-imported", table_name=table_name
        )

    def _create_new_table(self) -> None:
        """Create a new DynamoDB table with the specified configuration"""
        table_name = self.db_config.name

        # Define table properties
        removal_policy = (
            cdk.RemovalPolicy.DESTROY
            if "dev" in deployment.environment
            else cdk.RemovalPolicy.RETAIN
        )

        if deployment.dynamodb.enable_delete_protection:
            removal_policy = cdk.RETAIN

        props = {
            "table_name": table_name,
            "partition_key": dynamodb.Attribute(
                name="pk", type=dynamodb.AttributeType.STRING
            ),
            "sort_key": dynamodb.Attribute(
                name="sk", type=dynamodb.AttributeType.STRING
            ),
            "billing_mode": dynamodb.BillingMode.PAY_PER_REQUEST,
            "deletion_protection": self.db_config.enable_delete_protection,
            "point_in_time_recovery": self.db_config.point_in_time_recovery,
            "removal_policy": removal_policy,
        }

        # Create the table
        logger.info(f"Creating DynamoDB table: {table_name}")
        self.table = dynamodb.TableV2(self, id=table_name, **props)

        # Add GSIs if configured
        self._configure_gsi()
        # add replicas if configured
        self._configure_replicas()

    def _configure_replicas(self) -> None:
        """Configure replicas if specified in the config"""
        if not self.table or self.db_config.use_existing:
            return

        replica_regions = self.db_config.replica_regions
        if replica_regions:
            logger.info(
                f"Configuring table {self.db_config.name} with replicas in: {', '.join(replica_regions)}"
            )
            for region in replica_regions:
                self.table.add_replica(region)

    def _configure_gsi(self) -> None:
        """Configure Global Secondary Indexes if specified in the config"""
        if not self.table or self.db_config.use_existing:
            return

        # TODO: allow for custom GSI configuration
        gsi_count = self.db_config.gsi_count
        if gsi_count > 0:
            logger.info(
                f"Table {self.db_config.name} is configured to support up to {gsi_count} GSIs"
            )

        for i in range(gsi_count):
            self.table.add_global_secondary_index(
                index_name=f"gsi{i}",
                partition_key=dynamodb.Attribute(
                    name=f"gsi{i}_pk", type=dynamodb.AttributeType.STRING
                ),
                sort_key=dynamodb.Attribute(
                    name=f"gsi{i}_sk", type=dynamodb.AttributeType.STRING
                ),
                projection_type=dynamodb.ProjectionType.ALL,
            )
