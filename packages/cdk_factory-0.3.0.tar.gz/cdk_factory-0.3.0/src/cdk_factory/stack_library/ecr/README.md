# ECR Stack

The sole purpose is to wrap-up a deployment for ECR Repositories.  If you're like me, you want to deploy infrastructure items that rarely change in their own stack.  