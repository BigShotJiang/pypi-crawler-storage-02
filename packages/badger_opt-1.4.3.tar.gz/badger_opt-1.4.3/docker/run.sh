#!/bin/bash

export BADGER_ROOT=$PWD/playground
docker-compose run --name badger-handson badger
