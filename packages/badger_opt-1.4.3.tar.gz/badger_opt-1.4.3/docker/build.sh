#!/bin/bash

export BADGER_ROOT=$PWD/playground
docker-compose build
