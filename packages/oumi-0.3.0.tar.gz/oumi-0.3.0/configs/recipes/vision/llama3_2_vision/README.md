# Llama 3.2-Vision Instruct 11B

Configs for Llama 3.2-Vision Instruct 11B model. See https://huggingface.co/meta-llama/Llama-3.2-11B-Vision-Instruct
