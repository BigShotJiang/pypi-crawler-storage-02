# Phi-3-vision-128k-instruct

Configs for Phi-3-vision-128k-instruct 4.2B model. See https://huggingface.co/microsoft/Phi-3-vision-128k-instruct
