# Qwen2-VL 2B

Configs for Qwen2-VL 2B model. See https://huggingface.co/Qwen/Qwen2-VL-2B-Instruct
