# LLaVA 1.5 7B

Configs for LLaVA 1.5 7B model. See https://huggingface.co/llava-hf/llava-1.5-7b-hf.
