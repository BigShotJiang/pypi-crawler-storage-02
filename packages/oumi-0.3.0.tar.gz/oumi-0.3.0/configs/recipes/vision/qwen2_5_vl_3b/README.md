# **Qwen2.5-VL 3B**

Configs for the **`Qwen2.5-VL`** 3B model.
🔗 **Reference:** [Qwen2.5-VL-3B-Instruct on Hugging Face](https://huggingface.co/Qwen/Qwen2.5-VL-3B-Instruct)
