"""Generate conventional commit messages from your staged git changes using Model Context Protocol (MCP)."""

from mcp_git_commit_generator import main

main()
