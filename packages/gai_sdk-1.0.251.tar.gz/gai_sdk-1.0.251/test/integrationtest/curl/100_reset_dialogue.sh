curl -X POST http://localhost:8000/dialogue/create \
    -H "Content-Type: application/json" \
    -w "\n"