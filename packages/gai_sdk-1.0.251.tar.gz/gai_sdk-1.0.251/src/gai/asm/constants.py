HISTORY_PATH = (
    "~/.gai/data/{caller_id}/User/dialogue/{dialogue_id}/history/{order_no}.json"
)
