import "../styles/globals.css";

export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: "sans-serif" }}>
      <h1>Welcome to Next.js Pages Router!</h1>
      <p>
        This is your starter page in the <code>pages/</code> directory.
      </p>
    </div>
  );
}
