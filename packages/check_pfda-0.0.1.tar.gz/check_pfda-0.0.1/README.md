# check-pfda

> Compatibility goes here

Check-pfda is a package that tests student code and provides helpful feedback.

## Installation
`pip install check-pfda`


### Usage
1. Navigate to the root directory of a cloned assignment.
2. Run `pfda check`.

## Documentation
> Read The Docs page goes here
