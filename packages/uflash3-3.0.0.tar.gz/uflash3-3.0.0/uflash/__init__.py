# Copyright (c) 2025 Blackteahamburger <blackteahamburger@outlook.com>
#
# See the LICENSE file for more information.
"""Functions to convert Python scripts to .hex and flash to BBC micro:bit."""

from uflash.lib import *
