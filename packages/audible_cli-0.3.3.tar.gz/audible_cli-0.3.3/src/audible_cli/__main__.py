import sys

from . import cli

if __name__ == "__main__":
    sys.exit(
        cli.main(prog_name="python -m audible_cli")
    )
