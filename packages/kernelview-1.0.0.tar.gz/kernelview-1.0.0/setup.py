from setuptools import setup

# This will read all metadata from pyproject.toml
setup()