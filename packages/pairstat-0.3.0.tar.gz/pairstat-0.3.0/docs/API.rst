*****************************
Description of the Public API
*****************************

Here we document the Public API.

.. autofunction:: pairstat.vsf_props
.. autofunction:: pairstat.twopoint_correlation
