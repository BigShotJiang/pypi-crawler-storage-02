CLI Docs
========

Installation
------------

To check if the command line is installed correctly use ``ladybug-rhino --help``
