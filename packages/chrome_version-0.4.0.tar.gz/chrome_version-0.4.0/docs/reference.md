# API Reference

This module has only one function: `get_chrome_version()`. It returns the version of the Chrome installed on the system.

::: chrome_version.core
