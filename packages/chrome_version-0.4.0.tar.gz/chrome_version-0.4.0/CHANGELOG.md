# Changelog

Please check [this page in the documentation](https://hasansezertasan.github.io/chrome-version/changelog/).
