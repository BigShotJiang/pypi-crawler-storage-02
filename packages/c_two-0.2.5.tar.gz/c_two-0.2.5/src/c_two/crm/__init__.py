from .meta import ICRMMeta
from .template import generate_crm_template
