#!/usr/bin/env python3

from zdocker.build import BuildCommand


def zdocker_main():
    BuildCommand().run()
