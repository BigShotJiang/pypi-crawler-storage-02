git\_autograder.diff package
============================

Submodules
----------

git\_autograder.diff.diff module
--------------------------------

.. automodule:: git_autograder.diff.diff
   :members:
   :show-inheritance:
   :undoc-members:

git\_autograder.diff.diff\_helper module
----------------------------------------

.. automodule:: git_autograder.diff.diff_helper
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: git_autograder.diff
   :members:
   :show-inheritance:
   :undoc-members:
