# Simple logger for the plugin
import logging

logger = logging.getLogger(__name__)
