import { I as f } from "./Index-DTUgAySR.js";
export {
  f as default
};
