default_arguments = ['sub']
ignored_arguments = ['self', 'cls'] + default_arguments

