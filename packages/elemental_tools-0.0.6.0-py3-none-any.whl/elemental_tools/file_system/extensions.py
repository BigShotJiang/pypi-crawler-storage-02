class CSV:
    pass


class HTML:
    pass


class JSON:
    pass


class Undefined:
    pass