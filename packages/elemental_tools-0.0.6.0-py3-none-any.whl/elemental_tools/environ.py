suffix = ""
prefix = "elemental_"


supress_log = f"{prefix}supress_log{suffix}"
cpu_count = f"{prefix}cpu_count{suffix}"
debug = f"{prefix}debug{suffix}"
audio_generator_voice_id = f"{prefix}audio_generator_voice_id{suffix}"
audio_language = f"{prefix}audio_language{suffix}"
app_name = f"{prefix}app_name{suffix}"