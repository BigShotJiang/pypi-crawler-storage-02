# Strats

<p>
<a href="https://github.com/kazukiyoshida/strats/actions?query=event%3Apush+branch%3Amain" target="_blank">
  <img src="https://github.com/kazukiyoshida/strats/actions/workflows/test.yaml/badge.svg" alt="Test">
</a>
<a href="https://pypi.org/project/strats" target="_blank">
  <img src="https://img.shields.io/pypi/v/strats?label=pypi%20package&color=%2334D058" alt="PyPI - Version">
</a>
<a href="">
  <img src="https://img.shields.io/pypi/pyversions/strats?color=%2334D058" alt="Supported Python versions">
</a>
</p>

Strats is a modern, lightweight trading system framework with Python.
