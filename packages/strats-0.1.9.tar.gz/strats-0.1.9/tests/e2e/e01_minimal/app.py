from strats import Strats


def main():
    Strats().serve()


if __name__ == "__main__":
    main()
