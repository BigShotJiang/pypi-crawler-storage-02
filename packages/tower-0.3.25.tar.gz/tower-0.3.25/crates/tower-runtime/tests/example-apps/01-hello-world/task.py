for i in range(0, 5):
    print("Hello, world!")
