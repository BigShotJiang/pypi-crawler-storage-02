from ._config import Config
from .validate_spec import validate_spec

__all__ = ['validate_spec', 'Config']
