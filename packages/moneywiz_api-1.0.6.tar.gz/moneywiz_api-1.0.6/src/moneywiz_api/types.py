from typing import Literal

ID = int
GID = str
ENT_ID = int

CategoryType = Literal["Expenses", "Income"]
