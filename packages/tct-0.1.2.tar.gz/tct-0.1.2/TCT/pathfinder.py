"""
Pathfinder

TODO

"""

import urllib.parse

import requests

def find_paths():
    """
    This f
    """
