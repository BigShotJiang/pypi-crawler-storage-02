"""Entry point for the target."""

from __future__ import annotations

from target_csv.target import TargetCSV

TargetCSV.cli()
