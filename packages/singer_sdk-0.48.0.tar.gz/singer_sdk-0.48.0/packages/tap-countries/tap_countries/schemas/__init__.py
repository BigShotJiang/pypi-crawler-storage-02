"""Countries schemas."""
