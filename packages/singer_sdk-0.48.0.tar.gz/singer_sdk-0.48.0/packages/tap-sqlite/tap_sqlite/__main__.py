"""Entry point for the tap."""

from __future__ import annotations

from tap_sqlite import SQLiteTap

SQLiteTap.cli()
