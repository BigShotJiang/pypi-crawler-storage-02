"""A sample tap for testing SQL target property name transformations."""

from __future__ import annotations

from .tap import TapHostile

__all__ = [
    "TapHostile",
]
