{{ fullname }}
{{ "=" * fullname|length }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ name }}
    :members:
    :show-inheritance:
    :inherited-members: Stream
    :special-members: __init__
