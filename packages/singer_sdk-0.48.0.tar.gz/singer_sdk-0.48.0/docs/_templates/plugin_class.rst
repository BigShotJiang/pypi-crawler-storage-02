{{ fullname }}
{{ "=" * fullname|length }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ name }}
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__
