﻿singer_sdk.exceptions.FatalAPIError
===================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: FatalAPIError
    :members:
    :special-members: __init__, __call__