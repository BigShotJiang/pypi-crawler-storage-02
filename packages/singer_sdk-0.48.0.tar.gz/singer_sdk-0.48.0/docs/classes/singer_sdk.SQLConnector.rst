﻿singer_sdk.SQLConnector
=======================

.. currentmodule:: singer_sdk

.. autoclass:: SQLConnector
    :members:
    :special-members: __init__, __call__