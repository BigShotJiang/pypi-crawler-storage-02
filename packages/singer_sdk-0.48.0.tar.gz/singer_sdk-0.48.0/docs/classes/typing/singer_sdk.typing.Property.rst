﻿singer_sdk.typing.Property
==========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: Property
    :members:
    :special-members: __init__, __call__