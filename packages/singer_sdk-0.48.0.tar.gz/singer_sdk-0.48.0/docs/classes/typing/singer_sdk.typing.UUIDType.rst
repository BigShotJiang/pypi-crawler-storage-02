﻿singer_sdk.typing.UUIDType
==========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: UUIDType
    :members:
    :special-members: __init__, __call__