﻿singer_sdk.typing.Constant
==========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: Constant
    :members:
    :special-members: __init__, __call__