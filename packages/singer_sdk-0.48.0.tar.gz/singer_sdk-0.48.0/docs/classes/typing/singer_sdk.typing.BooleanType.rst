﻿singer_sdk.typing.BooleanType
=============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: BooleanType
    :members:
    :special-members: __init__, __call__