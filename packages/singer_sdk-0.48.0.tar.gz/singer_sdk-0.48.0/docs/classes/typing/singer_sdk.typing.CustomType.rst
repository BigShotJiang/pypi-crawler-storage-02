﻿singer_sdk.typing.CustomType
============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: CustomType
    :members:
    :special-members: __init__, __call__