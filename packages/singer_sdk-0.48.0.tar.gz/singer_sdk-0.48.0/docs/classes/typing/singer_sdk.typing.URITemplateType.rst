﻿singer_sdk.typing.URITemplateType
=================================

.. currentmodule:: singer_sdk.typing

.. autoclass:: URITemplateType
    :members:
    :special-members: __init__, __call__