﻿singer_sdk.typing.NumberType
============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: NumberType
    :members:
    :special-members: __init__, __call__
    :inherited-members: JSONTypeHelper