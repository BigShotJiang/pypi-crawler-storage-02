﻿singer_sdk.typing.DateTimeType
==============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: DateTimeType
    :members:
    :special-members: __init__, __call__