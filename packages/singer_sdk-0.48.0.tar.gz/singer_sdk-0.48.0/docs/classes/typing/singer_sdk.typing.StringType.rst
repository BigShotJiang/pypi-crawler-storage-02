﻿singer_sdk.typing.StringType
============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: StringType
    :members:
    :special-members: __init__, __call__