﻿singer_sdk.SQLTap
=================

.. currentmodule:: singer_sdk

.. autoclass:: SQLTap
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__