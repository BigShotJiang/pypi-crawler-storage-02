﻿singer_sdk.RecordSink
=====================

.. currentmodule:: singer_sdk

.. autoclass:: RecordSink
    :members:
    :special-members: __init__, __call__