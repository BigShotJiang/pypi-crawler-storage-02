﻿singer_sdk.exceptions.TapStreamConnectionFailure
================================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: TapStreamConnectionFailure
    :members:
    :special-members: __init__, __call__