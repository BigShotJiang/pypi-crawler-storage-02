﻿singer_sdk.BatchSink
====================

.. currentmodule:: singer_sdk

.. autoclass:: BatchSink
    :members:
    :special-members: __init__, __call__