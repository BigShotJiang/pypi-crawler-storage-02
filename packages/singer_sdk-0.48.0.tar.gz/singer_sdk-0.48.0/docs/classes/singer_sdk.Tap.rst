﻿singer_sdk.Tap
==============

.. currentmodule:: singer_sdk

.. autoclass:: Tap
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__