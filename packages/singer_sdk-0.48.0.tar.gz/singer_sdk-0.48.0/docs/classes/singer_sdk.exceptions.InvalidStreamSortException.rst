﻿singer_sdk.exceptions.InvalidStreamSortException
================================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: InvalidStreamSortException
    :members:
    :special-members: __init__, __call__