﻿singer_sdk.pagination.JSONPathPaginator
=======================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: JSONPathPaginator
    :members:
    :special-members: __init__, __call__