﻿singer_sdk.pagination.BaseHATEOASPaginator
==========================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: BaseHATEOASPaginator
    :members:
    :special-members: __init__, __call__