﻿singer_sdk.exceptions.MaxRecordsLimitException
==============================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: MaxRecordsLimitException
    :members:
    :special-members: __init__, __call__