﻿singer_sdk.exceptions.RecordsWithoutSchemaException
===================================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: RecordsWithoutSchemaException
    :members:
    :special-members: __init__, __call__