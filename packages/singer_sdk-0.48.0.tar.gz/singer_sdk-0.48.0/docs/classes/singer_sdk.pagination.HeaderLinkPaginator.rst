﻿singer_sdk.pagination.HeaderLinkPaginator
=========================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: HeaderLinkPaginator
    :members:
    :special-members: __init__, __call__