﻿singer_sdk.authenticators.BasicAuthenticator
============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: BasicAuthenticator
    :members:
    :special-members: __init__, __call__