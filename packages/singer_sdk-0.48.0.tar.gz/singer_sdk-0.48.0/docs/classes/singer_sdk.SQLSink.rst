﻿singer_sdk.SQLSink
==================

.. currentmodule:: singer_sdk

.. autoclass:: SQLSink
    :members:
    :special-members: __init__, __call__