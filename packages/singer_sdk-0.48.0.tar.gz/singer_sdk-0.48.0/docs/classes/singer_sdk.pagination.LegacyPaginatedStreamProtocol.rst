﻿singer_sdk.pagination.LegacyPaginatedStreamProtocol
===================================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: LegacyPaginatedStreamProtocol
    :members:
    :special-members: __init__, __call__