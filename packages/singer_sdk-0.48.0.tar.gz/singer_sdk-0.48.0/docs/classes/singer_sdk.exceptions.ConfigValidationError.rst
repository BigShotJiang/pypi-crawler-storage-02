﻿singer_sdk.exceptions.ConfigValidationError
===========================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: ConfigValidationError
    :members:
    :special-members: __init__, __call__