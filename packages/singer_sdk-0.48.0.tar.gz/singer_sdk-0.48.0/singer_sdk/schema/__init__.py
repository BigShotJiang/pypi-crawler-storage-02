"""Utilities for working with schemas."""
