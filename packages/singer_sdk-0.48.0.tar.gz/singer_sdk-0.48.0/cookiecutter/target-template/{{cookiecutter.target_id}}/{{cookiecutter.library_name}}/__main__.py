"""{{ cookiecutter.destination_name }} entry point."""

from __future__ import annotations

from {{ cookiecutter.library_name }}.target import Target{{ cookiecutter.destination_name }}

Target{{ cookiecutter.destination_name }}.cli()
