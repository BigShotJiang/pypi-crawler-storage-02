"""Test suite for {{ cookiecutter.mapper_id }}."""
