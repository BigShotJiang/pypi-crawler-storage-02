"""{{ cookiecutter.name }} entry point."""

from __future__ import annotations

from {{ cookiecutter.library_name }}.mapper import {{ cookiecutter.name }}Mapper

{{ cookiecutter.name }}Mapper.cli()
