"""Executable for fundamentals tap.

Run:

$ uv run python samples/aapl
"""

from __future__ import annotations

from .aapl import Fundamentals

Fundamentals.cli()
