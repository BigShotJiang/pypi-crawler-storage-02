# __init__.py

from ShopRequest import ShopRequest
from TaskRequest import TaskRequest