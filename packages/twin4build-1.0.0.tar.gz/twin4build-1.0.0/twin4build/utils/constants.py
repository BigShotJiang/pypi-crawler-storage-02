class Constants:
    specificHeatCapacity = {"water": 4180, "air": 1012}  # J/kg/K

    density = {"water": 1000, "air": 1.225}  # kg/m3
