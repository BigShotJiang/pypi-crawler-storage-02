def do_nothing(*args, **kwargs):
    pass
