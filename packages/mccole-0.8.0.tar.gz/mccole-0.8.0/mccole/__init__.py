"""Simple static site generator for tutorials"""
