from requestr.sessions import Session, parse_response
from requestr.api import get, options, head, post, put, patch, delete