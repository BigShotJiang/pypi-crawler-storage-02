# BiFuncLib
BiFuncLib is a Python library for biclustering with functional data. 
