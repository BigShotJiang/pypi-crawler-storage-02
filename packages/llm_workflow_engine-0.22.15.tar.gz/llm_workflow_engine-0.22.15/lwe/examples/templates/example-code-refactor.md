---
description: Code refactoring with syntax highlighting, auto-paste from clipboard
request_overrides:
  preset: gpt-4-code-generation
---

Refactor the following code to be less repetitive.

```{{ syntax_label }}
{{ clipboard }}
```

Just provide the code back, no description.
