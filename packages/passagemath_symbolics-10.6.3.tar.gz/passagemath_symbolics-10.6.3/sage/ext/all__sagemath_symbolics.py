# sage_setup: distribution = sagemath-symbolics
