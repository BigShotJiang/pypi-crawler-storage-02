"""Storage modules for Melodic."""

from .sqlite import SQLiteStorage

__all__ = ["SQLiteStorage"]
