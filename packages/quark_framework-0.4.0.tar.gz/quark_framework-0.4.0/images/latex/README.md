To create the figures used in the top level README.md, run:
```bash
./create_figures.py
```
The script uses `pdflatex`, `pdf2svg`, and `python`, all of which have to be available.