class SectionApi:
    get_mine_all_session = "/tp/session/mine/all"
    create_section_label = "/tp/section/label/create"
    create_section = "/tp/section/create"