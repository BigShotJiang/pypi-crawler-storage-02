# Llama-3.1-8B-T-128k

## Bot Information

**Creator:** @togetherai

**Description:** Llama 3.1 8B Instruct from Meta. Supports 128k tokens of context.

The points price is subject to change.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 100 points/message |

| Initial Points Cost | 100 points |


**Last Checked:** 2025-08-05 23:31:22.343319


## Technical Details

**Model ID:** `Llama-3.1-8B-T-128k`

**Object Type:** model

**Created:** 1721748216574

**Owned By:** poe

**Root:** Llama-3.1-8B-T-128k
