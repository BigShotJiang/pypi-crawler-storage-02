# LivePortrait

## Bot Information

**Creator:** @fal

**Description:** Animates given portraits with the motion's in the video. Powered by fal.ai

**Extra:** Powered by a server managed by @fal. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Video Output | 85 points / message |

| Initial Points Cost | 85 points |


**Last Checked:** 2025-08-05 23:29:10.359275


## Technical Details

**Model ID:** `LivePortrait`

**Object Type:** model

**Created:** 1720556185003

**Owned By:** poe

**Root:** LivePortrait
