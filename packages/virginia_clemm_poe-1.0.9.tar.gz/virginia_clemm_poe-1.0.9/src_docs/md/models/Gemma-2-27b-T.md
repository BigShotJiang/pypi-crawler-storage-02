# Gemma-2-27b-T

## Bot Information

**Creator:** @togetherai

**Description:** Gemma 2 27B Instruct from Google. For most use cases, https://poe.com/Gemini-2.0-Flash or https://poe.com/Gemini-2.0-Pro will produce better results.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 90 points/message |

| Initial Points Cost | 90 points |


**Last Checked:** 2025-08-05 23:25:06.097695


## Technical Details

**Model ID:** `Gemma-2-27b-T`

**Object Type:** model

**Created:** 1721258568677

**Owned By:** poe

**Root:** Gemma-2-27b-T
