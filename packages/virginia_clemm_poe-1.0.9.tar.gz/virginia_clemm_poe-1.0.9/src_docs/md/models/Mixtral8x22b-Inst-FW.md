# Mixtral8x22b-Inst-FW

## Bot Information

**Creator:** @fireworksai

**Description:** Mixtral 8x22B Mixture-of-Experts instruct model from Mistral hosted by Fireworks.

**Extra:** Powered by a server managed by @fireworksai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 120 points/message |

| Initial Points Cost | 120 points |


**Last Checked:** 2025-08-05 23:34:21.000610


## Technical Details

**Model ID:** `Mixtral8x22b-Inst-FW`

**Object Type:** model

**Created:** 1712949013942

**Owned By:** poe

**Root:** Mixtral8x22b-Inst-FW
