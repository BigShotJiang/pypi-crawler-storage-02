# FLUX-pro-1-T

## Bot Information

**Creator:** @togetherai

**Description:** The flagship model in the FLUX.1 lineup. Excels in prompt following, visual quality, image detail, and output diversity.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 1250 points/message |

| Initial Points Cost | 1250 points |


**Last Checked:** 2025-08-05 23:20:31.853626


## Technical Details

**Model ID:** `FLUX-pro-1-T`

**Object Type:** model

**Created:** 1730863349678

**Owned By:** poe

**Root:** FLUX-pro-1-T
