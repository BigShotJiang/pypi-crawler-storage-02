# Llama-3-8B-T

## Bot Information

**Creator:** @togetherai

**Description:** Llama 3 8B Instruct from Meta.

The points price is subject to change.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 15 points/message |

| Initial Points Cost | 15 points |


**Last Checked:** 2025-08-05 23:29:44.652580


## Technical Details

**Model ID:** `Llama-3-8B-T`

**Object Type:** model

**Created:** 1713463356287

**Owned By:** poe

**Root:** Llama-3-8B-T
