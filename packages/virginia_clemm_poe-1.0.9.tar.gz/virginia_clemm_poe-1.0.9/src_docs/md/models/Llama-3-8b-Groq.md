# Llama-3-8b-Groq

## Bot Information

**Creator:** @groq

**Description:** Llama 3 8b powered by the Groq LPU™ Inference Engine

**Extra:** Powered by Groq. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 10 points/message |

| Initial Points Cost | 10 points |


**Last Checked:** 2025-08-05 23:29:51.416038


## Technical Details

**Model ID:** `Llama-3-8b-Groq`

**Object Type:** model

**Created:** 1704930986258

**Owned By:** poe

**Root:** Llama-3-8b-Groq
