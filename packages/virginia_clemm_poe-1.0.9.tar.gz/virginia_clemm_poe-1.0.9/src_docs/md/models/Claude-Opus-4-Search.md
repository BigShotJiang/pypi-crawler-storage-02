# Claude-Opus-4-Search

## Bot Information

**Creator:** @anthropic

**Description:** Claude Opus 4 with access to real-time information from the web. Supports customizable thinking budget of up to 126k tokens.
To instruct the bot to use more thinking effort, add --thinking_budget and a number ranging from 0 to 126,000 to the end of your message.

**Extra:** Powered by Anthropic: claude-opus-4-20250514. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Input Text | 585 points/1k tokens |

| Input Image | 585 points/1k tokens |

| Bot Message | 4222 points/message |

| Chat History | Input rates are applied |

| Chat History Cache Discount | 90% discount oncached chat history |

| Initial Points Cost | 4356+ points |


**Last Checked:** 2025-08-05 23:16:50.012200


## Technical Details

**Model ID:** `Claude-Opus-4-Search`

**Object Type:** model

**Created:** 1750451340055

**Owned By:** poe

**Root:** Claude-Opus-4-Search
