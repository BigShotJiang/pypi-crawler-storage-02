# GPT-4-Classic-0314

## Bot Information

**Creator:** @openai

**Description:** OpenAI's GPT-4 model. Powered by gpt-4-0314 (non-Turbo) for text input and gpt-4o for image input. For most use cases, https://poe.com/GPT-4o will perform significantly better.

**Extra:** Powered by OpenAI: gpt-4-0314. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Input Text | 900 points/1k tokens |

| Input Image | 900 points/1k tokens |

| Bot Message | 334 points/message |

| Chat History | Input rates are applied |

| Initial Points Cost | 532+ points |


**Last Checked:** 2025-08-05 23:22:25.061131


## Technical Details

**Model ID:** `GPT-4-Classic-0314`

**Object Type:** model

**Created:** 1724707714433

**Owned By:** poe

**Root:** GPT-4-Classic-0314
