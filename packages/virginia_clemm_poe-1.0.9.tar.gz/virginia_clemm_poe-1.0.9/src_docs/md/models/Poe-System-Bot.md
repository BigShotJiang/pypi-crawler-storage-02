# Poe-System-Bot

## Bot Information

**Creator:** @poe

**Description:** A system bot that helps manage the chat.

**Extra:** Powered by Anthropic: claude-3-haiku-20240307. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 30 points/message |

| Initial Points Cost | 30 points |


**Last Checked:** 2025-08-05 23:36:17.731036


## Technical Details

**Model ID:** `Poe-System-Bot`

**Object Type:** model

**Created:** 1725041210466

**Owned By:** poe

**Root:** Poe-System-Bot
