# GPT-4o-mini

## Bot Information

**Creator:** @openai

**Description:** This intelligent small model from OpenAI is significantly smarter, cheaper, and just as fast as GPT-3.5 Turbo.

**Extra:** Powered by OpenAI: gpt-4o-mini-2024-07-18. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Input Text | 5 points/1k tokens |

| Input Image | 5 points/1k tokens |

| Bot Message | 5 points/message |

| Chat History | Input rates are applied |

| Chat History Cache Discount | 50% discount oncached chat history |

| Initial Points Cost | 6+ points |


**Last Checked:** 2025-08-05 23:23:20.637183


## Technical Details

**Model ID:** `GPT-4o-mini`

**Object Type:** model

**Created:** 1721338046069

**Owned By:** poe

**Root:** GPT-4o-mini
