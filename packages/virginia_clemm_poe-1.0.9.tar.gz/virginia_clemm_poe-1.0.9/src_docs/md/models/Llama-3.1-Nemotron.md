# Llama-3.1-Nemotron

## Bot Information

**Creator:** @togetherai

**Description:** Llama 3.1 Nemotron 70B from Nvidia. Excels in understanding, following instructions, writing and performing coding tasks. Strong reasoning abilities.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 200 points/message |

| Initial Points Cost | 200 points |


**Last Checked:** 2025-08-05 23:31:29.204173


## Technical Details

**Model ID:** `Llama-3.1-Nemotron`

**Object Type:** model

**Created:** 1731442142151

**Owned By:** poe

**Root:** Llama-3.1-Nemotron
