# Llama-3-70b-Inst-FW

## Bot Information

**Creator:** @fireworksai

**Description:** Meta's Llama-3-70B-Instruct hosted by Fireworks AI. For use cases, https://poe.com/Llama-3.3-70B-FW will be better.

**Extra:** Powered by a server managed by @fireworksai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Pricing

| Type | Cost |

|------|------|

| Total Cost | 75 points/message |

| Initial Points Cost | 75 points |


**Last Checked:** 2025-08-05 23:29:37.905640


## Technical Details

**Model ID:** `Llama-3-70b-Inst-FW`

**Object Type:** model

**Created:** 1713475738051

**Owned By:** poe

**Root:** Llama-3-70b-Inst-FW
