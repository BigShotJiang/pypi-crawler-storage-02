# Hidream-I1-full

## Bot Information

**Creator:** @fal

**Description:** Hidream-I1 is a state-of-the-art text to image model by Hidream. Use `--aspect` to set the aspect ratio. Valid aspect ratios are 16:9, 4:3, 1:1, 3:4, 9:16. Use `--negative_prompt` to set the negative prompt. Hosted by fal.ai.

**Extra:** Powered by a server managed by @fal. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** image

**Modality:** text->image


## Pricing

| Type | Cost |

|------|------|

| Image Output | 1417 points / message |

| Initial Points Cost | 1417 points |


**Last Checked:** 2025-08-05 23:26:38.962827


## Technical Details

**Model ID:** `Hidream-I1-full`

**Object Type:** model

**Created:** 1747144375790

**Owned By:** poe

**Root:** Hidream-I1-full
