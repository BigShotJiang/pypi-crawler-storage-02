"""constants used by the h5rdmtoolbox package"""

ANCILLARY_DATASET = 'ANCILLARY_DATASETS'
