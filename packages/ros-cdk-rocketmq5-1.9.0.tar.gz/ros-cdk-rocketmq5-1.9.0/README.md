## Aliyun ROS ROCKETMQ5 Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as ROCKETMQ5 from '@alicloud/ros-cdk-rocketmq5';
```
