def main() -> None:
    print("Hello from qass-tools-micromagnetic!")
