# depag-client

Client Python per il servizio SOAP SIB.DEPAG.