from labelu.internal.common.websocket import ConnectionManager


sampleConnectionManager = ConnectionManager()