
                  (function () {
                    window.__backend = {
  "version": "1.3.1",
  "name": "labelu",
  "build_time": "2025-08-11T11:26:59.453Z",
  "commit": "4b5017554d37ae983dc42599d2289dba9f0a0e76"
};
                  })();
                