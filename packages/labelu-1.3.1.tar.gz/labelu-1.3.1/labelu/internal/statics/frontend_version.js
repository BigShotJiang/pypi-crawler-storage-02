(function () {
  window.__frontend = {
    version: '5.9.1',
    deps: {
      '@labelu/audio-annotator-react': '1.9.0',
      '@labelu/components-react': '1.8.0',
      '@labelu/formatter': '1.0.2',
      '@labelu/i18n': '1.1.0',
      '@labelu/image': '1.5.0',
      '@labelu/image-annotator-react': '2.5.0',
      '@labelu/interface': '1.3.1',
      '@labelu/video-annotator-react': '1.5.0',
      '@labelu/video-react': '1.6.0',
    },
  };
})();
