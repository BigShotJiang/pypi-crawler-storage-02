The module allows to add advance payments on purchase orders and Request
for Quotation. The advance payments are allowed even before confirmation
and before starting the billing process.
