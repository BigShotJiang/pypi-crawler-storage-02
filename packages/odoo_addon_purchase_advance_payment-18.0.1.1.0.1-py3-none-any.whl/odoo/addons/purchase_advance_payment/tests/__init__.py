from . import test_purchase_advance_payment
