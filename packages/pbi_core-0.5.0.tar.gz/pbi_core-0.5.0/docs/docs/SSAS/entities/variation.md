# Variation


::: pbi_core.ssas.model_tables.variation.Variation