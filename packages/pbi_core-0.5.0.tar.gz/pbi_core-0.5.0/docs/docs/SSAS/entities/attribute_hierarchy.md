# Attribute Hierarchy

::: pbi_core.ssas.model_tables.attribute_hierarchy.AttributeHierarchy