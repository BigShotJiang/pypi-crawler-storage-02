from .alternate_of import AlternateOf  # Auto-generated to make this a Python package

__all__ = ["AlternateOf"]
