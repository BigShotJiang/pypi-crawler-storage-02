# Python Wrapper for AffaldDK Garbage System API

A module to retrieve Garbage Collection data for Danish Municipalities.

This module replaces [pyrenoweb](https://github.com/briis/pyrenoweb) that will archieved once everyone has migrated to this new API.



