# Hello Solana Program

## Build

```sh
$ git clone https://github.com/solana-developers/program-examples
$ cd program-examples/basics/hello-solana/native
$ cargo build-bpf --manifest-path=./program/Cargo.toml --bpf-out-dir=./program/target/so
```
