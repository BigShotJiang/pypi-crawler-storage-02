::: maggma.core.store
