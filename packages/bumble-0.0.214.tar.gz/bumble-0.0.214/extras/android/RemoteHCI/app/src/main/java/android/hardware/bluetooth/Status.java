/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package android.hardware.bluetooth;
public @interface Status {
  public static final int SUCCESS = 0;
  public static final int ALREADY_INITIALIZED = 1;
  public static final int UNABLE_TO_OPEN_INTERFACE = 2;
  public static final int HARDWARE_INITIALIZATION_ERROR = 3;
  public static final int UNKNOWN = 4;
}
