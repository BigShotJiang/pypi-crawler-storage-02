package android.os;

public class NativeHandle {
}
