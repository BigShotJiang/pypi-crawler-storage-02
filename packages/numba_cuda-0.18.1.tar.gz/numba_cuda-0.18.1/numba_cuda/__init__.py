# Copyright (c) 2024, NVIDIA CORPORATION.

from numba_cuda._version import __version__

__all__ = ["__version__"]
