def hello():
    return "Hello from lchdemo!"
