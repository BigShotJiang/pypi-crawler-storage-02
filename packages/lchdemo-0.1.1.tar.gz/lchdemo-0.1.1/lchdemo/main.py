def main():
    print("Hello, world! This is lchdemo.")

if __name__ == "__main__":
    main()
