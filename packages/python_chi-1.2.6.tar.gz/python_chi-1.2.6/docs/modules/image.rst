.. _image-module:

=========
chi.image
=========

The :mod:`chi.image` module exposes a functional interface for interacting with
disk images.

.. automodule:: chi.image
   :members:
