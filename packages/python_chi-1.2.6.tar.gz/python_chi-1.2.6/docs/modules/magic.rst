.. _magic-module:

=========
chi.magic
=========

The :mod:`chi.magic` module provides utility methods to magically orchestrate resources as a
very high level interface.

.. automodule:: chi.magic
   :members:
