.. _container-module:

=============
chi.container
=============

The :mod:`chi.container` module exposes a functional interface for interacting
with application containers.

.. important::
   Currently, only the CHI\@Edge site support container operations.

.. automodule:: chi.container
   :members:
