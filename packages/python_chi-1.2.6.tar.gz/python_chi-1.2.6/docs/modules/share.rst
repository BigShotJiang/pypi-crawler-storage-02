.. _share-module:

===========
chi.share
===========

The :mod:`chi.share` module exposes a functional interface for interacting
with shares of the testbed.

.. deprecated:: 1.0 See :mod:`chi.storage.Share`

.. automodule:: chi.share
   :members:
