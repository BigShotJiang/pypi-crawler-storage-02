2025-06-23 Version: 1.3.2
- Update API DescribePackageDeductions: add request parameters ResourceTypes.
- Update API DescribePackageDeductions: add response parameters Body.Deductions.$.InstanceId.
- Update API DescribePackageDeductions: add response parameters Body.Deductions.$.InstanceType.
- Update API DescribePackageDeductions: add response parameters Body.Deductions.$.SessionId.
- Update API DescribePackageDeductions: add response parameters Body.Deductions.$.UsedTimeWithScale.


2025-05-22 Version: 1.3.1
- Update API CreateMultiOrder: add request parameters OrderItems.$.BuyChange.


2025-05-09 Version: 1.3.0
- Support API DescribeMultiPrice.


2025-02-25 Version: 1.2.1
- Update API CreateMultiOrder: add param ResellerOwnerUid.


2025-02-10 Version: 1.2.0
- Support API CreateMultiOrder.
- Support API ModifyInstanceProperties.
- Update API DescribePackageDeductions: add param EndTime.
- Update API DescribePackageDeductions: add param StartTime.
- Update API DescribePackageDeductions: update param InstanceIds.
- Update API DescribePackageDeductions: update param PackageIds.
- Update API DescribePackageDeductions: update param PageNum.
- Update API DescribePackageDeductions: update param PageSize.
- Update API DescribePackageDeductions: update param ResourceType.
- Update API DescribePackageDeductions: update response param.


2025-02-07 Version: 1.1.0
- Support API ModifyInstanceProperties.
- Update API DescribePackageDeductions: add param EndTime.
- Update API DescribePackageDeductions: add param StartTime.
- Update API DescribePackageDeductions: update param InstanceIds.
- Update API DescribePackageDeductions: update param PackageIds.
- Update API DescribePackageDeductions: update param PageNum.
- Update API DescribePackageDeductions: update param PageSize.
- Update API DescribePackageDeductions: update param ResourceType.
- Update API DescribePackageDeductions: update response param.


2024-10-03 Version: 1.0.0
- Generated python 2021-12-21 for wss.

