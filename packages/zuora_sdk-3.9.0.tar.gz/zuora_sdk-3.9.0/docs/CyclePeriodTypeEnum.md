# CyclePeriodTypeEnum

the cycle period type for the commitment

## Enum

* `MONTH` (value: `'Month'`)

* `QUARTER` (value: `'Quarter'`)

* `YEAR` (value: `'Year'`)

* `WEEK` (value: `'Week'`)

* `SPECIFICWEEKS` (value: `'SpecificWeeks'`)

* `SPECIFICDAYS` (value: `'SpecificDays'`)

* `SPECIFICMONTHS` (value: `'SpecificMonths'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


