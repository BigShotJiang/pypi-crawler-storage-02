# ChargeProrationRuleDaysInMonth


## Enum

* `USEACTUALDAYS` (value: `'UseActualDays'`)

* `ASSUME30DAYS` (value: `'Assume30Days'`)

* `ASSUME30DAYSSTRICT` (value: `'Assume30DaysStrict'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


