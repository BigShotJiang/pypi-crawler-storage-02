# AccountingCodeStatus

The accounting code status.

## Enum

* `ACTIVE` (value: `'Active'`)

* `INACTIVE` (value: `'Inactive'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


