# BatchQueryEncrypted

If enabled, you must supply the formatting (zip or unzip) first and decrypt it to get the actual contents.         

## Enum

* `PGP` (value: `'pgp'`)

* `NONE` (value: `'none'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


