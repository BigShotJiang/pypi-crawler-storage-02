# CustomObjectAllFieldsDefinitionAllOfUpdatedByIdOrigin

Specifies whether the field is a system field or a custom field

## Enum

* `SYSTEM` (value: `'system'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


