# AccountingCodeCategory

The category associated with the accounting code.

## Enum

* `ASSETS` (value: `'Assets'`)

* `LIABILITIES` (value: `'Liabilities'`)

* `EQUITY` (value: `'Equity'`)

* `REVENUE` (value: `'Revenue'`)

* `EXPENSES` (value: `'Expenses'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


