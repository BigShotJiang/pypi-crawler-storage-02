# CreateOrderResponseRefundStatus

The status of the refund.

## Enum

* `SUCCESS` (value: `'Success'`)

* `ERROR` (value: `'Error'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


