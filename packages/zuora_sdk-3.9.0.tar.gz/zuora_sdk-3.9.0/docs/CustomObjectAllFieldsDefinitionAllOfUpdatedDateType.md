# CustomObjectAllFieldsDefinitionAllOfUpdatedDateType

The field data type

## Enum

* `STRING` (value: `'string'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


