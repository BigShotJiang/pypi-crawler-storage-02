# AB Toolkit 

AB Toolkit is a Python library for building event funnels, calculating conversions and visualizing results.

## Installation

pip install git+https://github.com/wellbel123/abcdf_toolkit.git

## Features

- **FunnelBuilder** — step-by-step funnel construction. Support for multi-events per step.

Statistics:

- **compute_step_stats** - z-test (two-sided and one-sided hypotheses) and p-value with Bonferroni correction  

Visualization:

— distributions and confidence intervals for groups and their differences.

Synthetic Data:

- **generate_synthetic_funnel** - generate data for using the funner with different features 

## Quick Start 

You can find examples [here](./examples.ipynb)
