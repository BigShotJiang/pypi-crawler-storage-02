"""
Utilities module for MFCS Memory
"""

from .config import Config

__all__ = [
    'Config',
]