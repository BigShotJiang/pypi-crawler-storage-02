module.exports = {
  path: 'cz-conventional-changelog'
};
