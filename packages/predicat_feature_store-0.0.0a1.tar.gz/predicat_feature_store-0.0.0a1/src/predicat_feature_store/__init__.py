"""
Placeholder package for predicat-feature-store.
"""
__all__ = []
__version__ = "0.0.0a1"
