# Selenium Speech Listener

A Python package that uses Selenium to capture live speech-to-text from a hosted web app.

## Installation
```bash
pip install byhacker-speech-to-text

Usage:

from byhacker_speech_to_text import speech_listener

speech_listener()
