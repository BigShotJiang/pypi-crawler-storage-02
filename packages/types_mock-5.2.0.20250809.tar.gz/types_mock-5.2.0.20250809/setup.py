
from setuptools import setup

setup(package_data={'mock-stubs': ['__init__.pyi', 'backports.pyi', 'mock.pyi', 'METADATA.toml', 'py.typed']})
