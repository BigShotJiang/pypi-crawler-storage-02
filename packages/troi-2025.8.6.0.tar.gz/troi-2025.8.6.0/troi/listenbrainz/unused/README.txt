Neither this patch nor the endpoint for it work right now, so moving out of the way until we can fix it.
