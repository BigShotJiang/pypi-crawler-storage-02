Delete a Lightdash dashboard permanently.

This action cannot be undone. The dashboard and its layout will be deleted, but the charts
referenced by the dashboard will remain available and can be used in other dashboards.
Requires confirmation flag to be set to true to prevent accidental deletions.

Examples:
- "Delete the old quarterly review dashboard"
- "Remove the unused test dashboard with ID def456"