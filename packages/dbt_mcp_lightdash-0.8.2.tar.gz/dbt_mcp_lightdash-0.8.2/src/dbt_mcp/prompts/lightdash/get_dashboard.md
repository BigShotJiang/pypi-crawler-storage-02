Get detailed information about a specific Lightdash dashboard.

Returns the full dashboard configuration including tiles (charts and markdown), layout, metadata, and space information.
Use this to understand dashboard structure before editing or to view dashboard contents.

Examples:
- "Show me the executive dashboard details"
- "Get the configuration for dashboard with ID xyz789"
- "What charts are on the sales dashboard?"