# ewha-congestions

A Python module for calculating and analyzing three types of congestion—Road, PM, and Pedestrian congestion—using trajectory data collected from CCTV systems. It includes safety-aware adjustments based on pedestrian-vehicle and pedestrian-pedestrian interactions.


## How to use

'''python
from ewha_congestions.three_congestions import processing_congestions

df = your data.
data index must be DatetimeIndex as "dtct_dt".
data must has point geometry as "geomatry", "snr_id", "distance", "speed", "acceleration", "traj_id", "direction", "mf_type", and "apr_code"

road_shp = your road data.
road data must has Polygon geometry of roads as "geometry" and CCTV ID as "snr_id".

road_shp = road_shp.to_crs("EPSG:5179") for calculate road area

road_cong, ped_cong, pm_cong = processing_congestions(df, road_shp, 3600).call()

'''
df: includes object tracking data with fields like snr_id, mf_type, apr_code, geometry, dtct_dt, speed, and acceleration.

road_df: includes road information with fields snr_id and geometry.

interval: time window (in seconds) over which congestion is aggregated and computed.

## Output
Each output (road_cong, ped_cong, pm_cong) is a DataFrame with:

CCTV_ID: unique identifier for each camera

time: timestamp of the congestion record

congestion_level: integer from 0 to 4

0: Excellent (≤ 0.2)

1: Good (≤ 0.4)

2: Normal (≤ 0.6)

3: Crowded (≤ 0.8)

4: Very Crowded (> 0.8)

Congestion Types
Type |	Description
Road Congestion |	Combined area occupied by all moving objects divided by the road polygon area
PM Congestion |	PM area only, normalized by unoccupied space (excluding pedestrian & vehicle)
Pedestrian Congestion |	Road congestion adjusted using pedestrian-pedestrian and pedestrian-vehicle conflicts

## Requirements
numpy
pandas
geopandas
movingpandas
tqdm
shapely
geopy

## License
This project is licensed under the JiyoonLee License.

## Contact
0197black@gmail.com
