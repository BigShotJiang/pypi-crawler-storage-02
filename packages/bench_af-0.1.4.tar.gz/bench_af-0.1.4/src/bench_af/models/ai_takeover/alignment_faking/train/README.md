## Description

Model that is trained on lesswrong posts about ais deceiving and overpowering humans

Example: https://www.alignmentforum.org/posts/KFJ2LFogYqzfGB3uX/how-ai-takeover-might-happen-in-2-years

Trained by supervised fine tuning on prompt response pairs of completing lesswrong articles