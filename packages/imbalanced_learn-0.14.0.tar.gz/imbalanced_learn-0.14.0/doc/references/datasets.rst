.. _datasets_ref:

Datasets
========

.. automodule:: imblearn.datasets
    :no-members:
    :no-inherited-members:

.. currentmodule:: imblearn.datasets

.. autosummary::
   :toctree: generated/
   :template: function.rst

   make_imbalance
   fetch_datasets
