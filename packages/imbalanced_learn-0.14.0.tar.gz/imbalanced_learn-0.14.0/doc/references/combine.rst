.. _combine_ref:

Combination of over- and under-sampling methods
===============================================

.. automodule:: imblearn.combine
   :no-members:
   :no-inherited-members:

.. currentmodule:: imblearn.combine

.. autosummary::
   :toctree: generated/
   :template: class.rst

   SMOTEENN
   SMOTETomek
