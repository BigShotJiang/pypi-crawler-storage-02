---
name: Documentation improvement
about: Create a report to help us improve the documentation
title: "[DOC]"
labels: Documentation, help wanted, good first issue
assignees: ''

---

#### Describe the issue linked to the documentation

Tell us about the confusion introduce in the documentation.

#### Suggest a potential alternative/fix

Tell us how we could improve the documentation in this regard.
