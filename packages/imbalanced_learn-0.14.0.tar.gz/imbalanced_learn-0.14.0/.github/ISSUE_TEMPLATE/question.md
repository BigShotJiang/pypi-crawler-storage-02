---
name: Question
about: If you have a usage question
title: ''
labels: ''
assignees: ''

---

**
If your issue is a usage question, submit it here instead:
- The imbalanced learn gitter: https://gitter.im/scikit-learn-contrib/imbalanced-learn
**
