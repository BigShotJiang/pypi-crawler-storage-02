---
name: Usage question
about: If you have a usage question
title: "[SO]"
labels: question
assignees: ''

---

** If your issue is a usage question, submit it here instead:**
- **The imbalanced learn gitter: https://gitter.im/scikit-learn-contrib/imbalanced-learn**
- **StackOverflow with the imblearn (or imbalanced-learn) tag:https://stackoverflow.com/questions/tagged/imblearn**

We are going to automatically close this issue if this is not link to a bug or an enhancement.
