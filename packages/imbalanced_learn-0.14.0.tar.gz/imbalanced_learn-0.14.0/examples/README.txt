.. _general_examples:

Examples
--------

General-purpose and introductory examples for the `imbalanced-learn` toolbox.
