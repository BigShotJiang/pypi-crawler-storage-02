Help
==============

First of all, thank you for your support and use of the package!

If you notice a bug, please `open an issue on GitHub <https://github.com/punch-mission/punchbowl/issues/new>`_.

If you need help using this code, please `start a discussion on GitHub <https://github.com/punch-mission/punchbowl/discussions/new/choose>`_.
We encourage using GitHub rather than email so that others can benefit from your inquiry too. We want to make this code
as user-friendly as possible. If you're encountering an issue, it's likely someone else is too; you can help
everyone by speaking up.
