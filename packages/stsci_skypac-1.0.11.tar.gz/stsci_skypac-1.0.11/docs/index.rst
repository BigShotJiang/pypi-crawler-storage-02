Welcome to skypac's documentation!
==================================

Content
=======

.. toctree::
   :maxdepth: 2

   source/skymatch
   source/skyline
   source/parseat
   source/region
   source/skystatistics
   source/utils
   source/pamutils
   source/LICENSE.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
