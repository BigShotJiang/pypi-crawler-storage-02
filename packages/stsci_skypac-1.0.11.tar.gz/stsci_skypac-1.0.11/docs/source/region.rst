=========================
Polygon filling algorithm
=========================

.. moduleauthor:: Nadezhda Dencheva, Mihai Cara <help@stsci.edu>

.. currentmodule:: stsci.skypac.region

.. automodule:: stsci.skypac.region
   :members:
