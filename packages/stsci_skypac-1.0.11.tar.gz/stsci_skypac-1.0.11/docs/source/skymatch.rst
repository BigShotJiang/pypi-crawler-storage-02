=============================
Sky matching for image mosaic
=============================

.. moduleauthor:: Mihai Cara <help@stsci.edu>

.. moduleauthor:: Pey-Lian Lim <help@stsci.edu>

.. moduleauthor:: Warren Hack <help@stsci.edu>

.. currentmodule:: stsci.skypac.skymatch

.. automodule:: stsci.skypac.skymatch
   :members:
..   :undoc-members:
