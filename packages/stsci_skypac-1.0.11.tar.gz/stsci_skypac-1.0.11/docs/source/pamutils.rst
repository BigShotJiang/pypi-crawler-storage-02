==============================
Pixel Area Map (PAM) utilities
==============================

.. moduleauthor:: Mihai Cara <help@stsci.edu>

.. currentmodule:: stsci.skypac.pamutils

.. automodule:: stsci.skypac.pamutils
   :members:
..   :undoc-members:
