=======
LICENSE
=======

.. include:: ../../LICENSE.txt
