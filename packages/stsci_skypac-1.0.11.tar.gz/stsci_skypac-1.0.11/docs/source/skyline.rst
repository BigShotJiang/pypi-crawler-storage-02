=============================================================
SkyLine (chip outline on the sky) management for image mosaic
=============================================================

.. moduleauthor:: Mihai Cara <help@stsci.edu>

.. moduleauthor:: Pey-Lian Lim <help@stsci.edu>

.. moduleauthor:: Warren Hack <help@stsci.edu>

.. currentmodule:: stsci.skypac.skyline

.. automodule:: stsci.skypac.skyline
   :members:
..   :undoc-members:
