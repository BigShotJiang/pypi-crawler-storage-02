===========================================================
Utility functions for parsing user catalog files for skypac
===========================================================

.. moduleauthor:: Mihai Cara <help@stsci.edu>

.. currentmodule:: stsci.skypac.parseat

.. automodule:: stsci.skypac.parseat
   :members:
