===================================
Sky statistics functions for skypac
===================================

.. moduleauthor:: Mihai Cara <help@stsci.edu>

.. currentmodule:: stsci.skypac.skystatistics

.. automodule:: stsci.skypac.skystatistics
   :members:

.. autoclass:: SkyStats
   :members:
   :no-index: SkyStats
