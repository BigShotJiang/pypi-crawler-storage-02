# stsci.skypac

[![Documentation Status](https://readthedocs.org/projects/stsci-skypac/badge/?version=latest)](http://stsci-skypac.readthedocs.io/en/latest/?badge=latest)
[![Build Status](https://ssbjenkins.stsci.edu/job/STScI/job/stsci.skypac/job/master/badge/icon)](https://ssbjenkins.stsci.edu/job/STScI/job/stsci.skypac/job/master/)
[![Powered by Astropy Badge](http://img.shields.io/badge/powered%20by-AstroPy-orange.svg?style=flat)](http://www.astropy.org/)

Sky matching for image mosaic.
