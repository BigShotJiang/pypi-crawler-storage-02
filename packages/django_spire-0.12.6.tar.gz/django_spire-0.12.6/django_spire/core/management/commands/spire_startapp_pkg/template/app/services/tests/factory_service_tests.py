from django.test import TestCase


class SpireChildAppFactoryServiceTestCase(TestCase):
    def setUp(self):
        super().setUp()
