from module.seeding.seeder import SpireChildAppModelSeeder

SpireChildAppModelSeeder.seed_database(count=10)