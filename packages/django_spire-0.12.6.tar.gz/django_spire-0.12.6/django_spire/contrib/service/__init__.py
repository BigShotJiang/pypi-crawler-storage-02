from django_spire.contrib.service.service import BaseService
from django_spire.contrib.service.django_model_service import BaseDjangoModelService

__all__ = [
    'BaseService',
    'BaseDjangoModelService'
]
