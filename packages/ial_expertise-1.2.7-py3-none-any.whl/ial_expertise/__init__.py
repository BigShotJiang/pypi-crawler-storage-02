#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
IAL expertise package: expertise outputs of IAL tasks.
"""

__version__ = "1.2.7"

from . import experts, task
