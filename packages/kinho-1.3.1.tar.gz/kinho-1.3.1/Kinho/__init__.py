from .neural import Neural

__author__ = 'Kinhosz'
__email__ = 'scruz.josecarlos@gmail.com'
__version__ = '1.3.1'
