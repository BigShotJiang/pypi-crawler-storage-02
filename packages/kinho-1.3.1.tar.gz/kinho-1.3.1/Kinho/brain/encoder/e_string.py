def fromString(data):
    return data.encode('utf-8')