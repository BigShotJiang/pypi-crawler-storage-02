from .e_float import fromFloat
from .e_int import fromInt
from .e_string import fromString
from .e_xor import genXor as securityCode