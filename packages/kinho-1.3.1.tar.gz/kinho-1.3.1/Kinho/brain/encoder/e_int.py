def fromInt(data):
    return data.to_bytes(4, byteorder='big')