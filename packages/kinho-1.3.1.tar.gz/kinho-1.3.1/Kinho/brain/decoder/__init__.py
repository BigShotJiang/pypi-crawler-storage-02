from .d_float import toFloat
from .d_int import toInt
from .d_string import toString