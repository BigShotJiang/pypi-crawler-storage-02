import unittest as ut

from Stiefel import *
from Flag import *

ut.main()
