# DISCOVER-Utils

DISCOVER-Utils is a utility package to use in combination with [DISCOVER](https://github.com/hcmlab/discover) or as stand-alone.
You can find the documentation [here](http://hcmlab.github.io/discover-utils/docbuild/)
