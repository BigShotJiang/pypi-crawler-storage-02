import pims
MoviePyReader = pims.MoviePyReader
