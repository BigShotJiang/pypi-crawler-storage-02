=================================
案例教程
=================================

.. toctree::

    tutorials/circuit_basics_cn.ipynb
    tutorials/qaoa_cn.ipynb
    tutorials/tfim_vqe_cn.ipynb
    tutorials/mnist_qml_cn.ipynb
    tutorials/torch_qml_cn.ipynb
    tutorials/qml_scenarios_cn.ipynb
    tutorials/vqe_h2o_cn.ipynb
    tutorials/tfim_vqe_diffreph_cn.ipynb
    tutorials/mera_cn.ipynb
    tutorials/gradient_benchmark_cn.ipynb
    tutorials/contractors_cn.ipynb
    tutorials/operator_spreading_cn.ipynb
    tutorials/optimization_and_expressibility_cn.ipynb
    tutorials/vqex_mbl_cn.ipynb
    tutorials/dqas_cn.ipynb
    tutorials/barren_plateaus_cn.ipynb
    tutorials/sklearn_svc_cn.ipynb