"""Test suite for src modules."""
