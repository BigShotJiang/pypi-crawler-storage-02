"""Track & archive Victoria's live emergency alerts."""

__version__ = "0.2.2"
