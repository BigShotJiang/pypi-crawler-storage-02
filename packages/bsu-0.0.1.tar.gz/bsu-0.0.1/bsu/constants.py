# -*- coding: utf-8 -*-
# Author:   zhouju
# At    :   2025/8/1
# Email :   zhouju@sunline.com
# About :   https://blog.codingcat.net
LANG_URL = "https://s1.hdslb.com/bfs/subtitle/subtitle_lan.json"
SLEEP_TIME = 3
