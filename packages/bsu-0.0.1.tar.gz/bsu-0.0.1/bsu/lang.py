# -*- coding: utf-8 -*-
# Author:   zhouju
# At    :   2025/7/31
# Email :   zhouju@sunline.com
# About :   https://blog.codingcat.net


import requests

from .constants import LANG_URL


def get_lang_list():
    response = requests.get(LANG_URL)
    if response.status_code != 200:
        return []
    lang_list = response.json()
    if not lang_list:
        return []
    else:
        return lang_list


def parse_lan_by_name(filename):
    # lang_list = get_lang_list()
    lang_list = [{"lan": "zh-CN", "doc_zh": "中文（中国）"}, {"lan": "zh-HK", "doc_zh": "中文（中国香港）"},
                 {"lan": "zh-Hans", "doc_zh": "中文（简体）"}, {"lan": "zh-TW", "doc_zh": "中文（中国台湾）"},
                 {"lan": "zh-Hant", "doc_zh": "中文（繁体）"}, {"lan": "en-US", "doc_zh": "英语（美国）"},
                 {"lan": "ja", "doc_zh": "日语"}, {"lan": "ko", "doc_zh": "韩语"},
                 {"lan": "zh-SG", "doc_zh": "中文（新加坡）"}, {"lan": "ab", "doc_zh": "阿布哈西亚语"},
                 {"lan": "aa", "doc_zh": "阿法尔语"}, {"lan": "af", "doc_zh": "南非荷兰语"},
                 {"lan": "sq", "doc_zh": "阿尔巴尼亚语"}, {"lan": "ase", "doc_zh": "美国手语"},
                 {"lan": "am", "doc_zh": "阿姆哈拉语"}, {"lan": "arc", "doc_zh": "阿拉米语"},
                 {"lan": "hy", "doc_zh": "亚美尼亚语"}, {"lan": "as", "doc_zh": "阿萨姆语"},
                 {"lan": "ay", "doc_zh": "艾马拉语"}, {"lan": "az", "doc_zh": "阿塞拜疆语"},
                 {"lan": "bn", "doc_zh": "孟加拉语"}, {"lan": "ba", "doc_zh": "巴什基尔语"},
                 {"lan": "eu", "doc_zh": "巴斯克语"}, {"lan": "be", "doc_zh": "白俄罗斯语"},
                 {"lan": "bh", "doc_zh": "比哈尔语"}, {"lan": "bi", "doc_zh": "比斯拉马语"},
                 {"lan": "bs", "doc_zh": "波斯尼亚语"}, {"lan": "br", "doc_zh": "布列塔尼语"},
                 {"lan": "bg", "doc_zh": "保加利亚语"}, {"lan": "yue", "doc_zh": "粤语"},
                 {"lan": "yue-HK", "doc_zh": "粤语（中国香港）"}, {"lan": "ca", "doc_zh": "加泰罗尼亚语"},
                 {"lan": "chr", "doc_zh": "切罗基语"}, {"lan": "cho", "doc_zh": "乔克托语"},
                 {"lan": "co", "doc_zh": "科西嘉语"}, {"lan": "hr", "doc_zh": "克罗地亚语"},
                 {"lan": "cs", "doc_zh": "捷克语"}, {"lan": "da", "doc_zh": "丹麦语"},
                 {"lan": "nl", "doc_zh": "荷兰语"}, {"lan": "nl-BE", "doc_zh": "荷兰语（比利时）"},
                 {"lan": "nl-NL", "doc_zh": "荷兰语（荷兰）"}, {"lan": "dz", "doc_zh": "宗卡语"},
                 {"lan": "en", "doc_zh": "英语"}, {"lan": "en-CA", "doc_zh": "英语（加拿大）"},
                 {"lan": "en-IE", "doc_zh": "英语（爱尔兰）"}, {"lan": "en-GB", "doc_zh": "英语（英国）"},
                 {"lan": "eo", "doc_zh": "世界语"}, {"lan": "et", "doc_zh": "爱沙尼亚语"},
                 {"lan": "fo", "doc_zh": "法罗语"}, {"lan": "fj", "doc_zh": "斐济语"},
                 {"lan": "fil", "doc_zh": "菲律宾语"}, {"lan": "fi", "doc_zh": "芬兰语"},
                 {"lan": "fr", "doc_zh": "法语"}, {"lan": "fr-BE", "doc_zh": "法语（比利时）"},
                 {"lan": "fr-CA", "doc_zh": "法语（加拿大）"}, {"lan": "fr-FR", "doc_zh": "法语（法国）"},
                 {"lan": "fr-CH", "doc_zh": "法语（瑞士）"}, {"lan": "ff", "doc_zh": "富拉语"},
                 {"lan": "gl", "doc_zh": "加利西亚语"}, {"lan": "ka", "doc_zh": "格鲁吉亚语"},
                 {"lan": "de", "doc_zh": "德语"}, {"lan": "de-AT", "doc_zh": "德语（奥地利）"},
                 {"lan": "de-DE", "doc_zh": "德语（德国）"}, {"lan": "de-CH", "doc_zh": "德语（瑞士）"},
                 {"lan": "el", "doc_zh": "希腊语"}, {"lan": "kl", "doc_zh": "格陵兰语"},
                 {"lan": "gn", "doc_zh": "瓜拉尼语"}, {"lan": "gu", "doc_zh": "古吉拉特语"},
                 {"lan": "hak", "doc_zh": "客家语"}, {"lan": "hak-TW", "doc_zh": "客家语（中国台湾）"},
                 {"lan": "ha", "doc_zh": "豪萨语"}, {"lan": "iw", "doc_zh": "希伯来语"},
                 {"lan": "hi", "doc_zh": "印地语"}, {"lan": "hi-Latn", "doc_zh": "印地语（注音）"},
                 {"lan": "hu", "doc_zh": "匈牙利语"}, {"lan": "is", "doc_zh": "冰岛语"},
                 {"lan": "ig", "doc_zh": "伊博语"}, {"lan": "id", "doc_zh": "印度尼西亚语"},
                 {"lan": "ia", "doc_zh": "国际语"}, {"lan": "ie", "doc_zh": "国际文字（E）"},
                 {"lan": "iu", "doc_zh": "因纽特语"}, {"lan": "ik", "doc_zh": "伊努皮克语"},
                 {"lan": "ga", "doc_zh": "爱尔兰语"}, {"lan": "it", "doc_zh": "意大利语"},
                 {"lan": "jv", "doc_zh": "爪哇语"}, {"lan": "kn", "doc_zh": "卡纳达语"},
                 {"lan": "ks", "doc_zh": "克什米尔语"}, {"lan": "kk", "doc_zh": "哈萨克语"},
                 {"lan": "km", "doc_zh": "高棉语"}, {"lan": "rw", "doc_zh": "卢旺达语"},
                 {"lan": "tlh", "doc_zh": "克林贡语"}, {"lan": "ku", "doc_zh": "库尔德语"},
                 {"lan": "ky", "doc_zh": "柯尔克孜语"}, {"lan": "lo", "doc_zh": "老挝语"},
                 {"lan": "la", "doc_zh": "拉丁语"}, {"lan": "lv", "doc_zh": "拉脱维亚语"},
                 {"lan": "ln", "doc_zh": "林加拉语"}, {"lan": "lt", "doc_zh": "立陶宛语"},
                 {"lan": "lb", "doc_zh": "卢森堡语"}, {"lan": "mk", "doc_zh": "马其顿语"},
                 {"lan": "mg", "doc_zh": "马拉加斯语"}, {"lan": "ms", "doc_zh": "马来语"},
                 {"lan": "ml", "doc_zh": "马拉雅拉姆语"}, {"lan": "mt", "doc_zh": "马耳他语"},
                 {"lan": "mi", "doc_zh": "毛利语"}, {"lan": "mr", "doc_zh": "马拉地语"},
                 {"lan": "mas", "doc_zh": "马赛语"}, {"lan": "nan", "doc_zh": "闽南语"},
                 {"lan": "nan-TW", "doc_zh": "闽南语（中国台湾）"}, {"lan": "lus", "doc_zh": "米佐语"},
                 {"lan": "mo", "doc_zh": "摩尔多瓦语"}, {"lan": "mn", "doc_zh": "蒙古语"},
                 {"lan": "my", "doc_zh": "缅甸语"}, {"lan": "na", "doc_zh": "瑙鲁语"},
                 {"lan": "nv", "doc_zh": "纳瓦霍语"}, {"lan": "ne", "doc_zh": "尼泊尔语"},
                 {"lan": "no", "doc_zh": "挪威语"}, {"lan": "oc", "doc_zh": "奥克语"},
                 {"lan": "or", "doc_zh": "奥里亚语"}, {"lan": "om", "doc_zh": "奥罗莫语"},
                 {"lan": "ps", "doc_zh": "普什图语"}, {"lan": "fa", "doc_zh": "波斯语"},
                 {"lan": "fa-AF", "doc_zh": "波斯语（阿富汗）"}, {"lan": "fa-IR", "doc_zh": "波斯语（伊朗）"},
                 {"lan": "pl", "doc_zh": "波兰语"}, {"lan": "pt", "doc_zh": "葡萄牙语"},
                 {"lan": "pt-BR", "doc_zh": "葡萄牙语（巴西）"}, {"lan": "pt-PT", "doc_zh": "葡萄牙语（葡萄牙）"},
                 {"lan": "pa", "doc_zh": "旁遮普语"}, {"lan": "qu", "doc_zh": "克丘亚语"},
                 {"lan": "ro", "doc_zh": "罗马尼亚语"}, {"lan": "rm", "doc_zh": "罗曼什语"},
                 {"lan": "rn", "doc_zh": "隆迪语"}, {"lan": "ru", "doc_zh": "俄语"},
                 {"lan": "ru-Latn", "doc_zh": "俄语（注音）"}, {"lan": "sm", "doc_zh": "萨摩亚语"},
                 {"lan": "sg", "doc_zh": "桑戈语"}, {"lan": "sa", "doc_zh": "梵语"},
                 {"lan": "gd", "doc_zh": "苏格兰盖尔语"}, {"lan": "sr", "doc_zh": "塞尔维亚语"},
                 {"lan": "sr-Cyrl", "doc_zh": "塞尔维亚语（西里尔文）"},
                 {"lan": "sr-Latn", "doc_zh": "塞尔维亚语（拉丁文）"}, {"lan": "sh", "doc_zh": "塞尔维亚-克罗地亚语"},
                 {"lan": "sdp", "doc_zh": "Sherdukpen"}, {"lan": "sn", "doc_zh": "绍纳语"},
                 {"lan": "scn", "doc_zh": "西西里语"}, {"lan": "sd", "doc_zh": "信德语"},
                 {"lan": "si", "doc_zh": "僧伽罗语"}, {"lan": "sk", "doc_zh": "斯洛伐克语"},
                 {"lan": "sl", "doc_zh": "斯洛文尼亚语"}, {"lan": "so", "doc_zh": "索马里语"},
                 {"lan": "st", "doc_zh": "南索托语"}, {"lan": "es", "doc_zh": "西班牙语"},
                 {"lan": "es-419", "doc_zh": "西班牙语（拉丁美洲）"}, {"lan": "es-MX", "doc_zh": "西班牙语（墨西哥）"},
                 {"lan": "es-ES", "doc_zh": "西班牙语（西班牙）"}, {"lan": "es-US", "doc_zh": "西班牙语（美国）"},
                 {"lan": "su", "doc_zh": "巽他语"}, {"lan": "sw", "doc_zh": "斯瓦希里语"},
                 {"lan": "ss", "doc_zh": "斯瓦蒂语"}, {"lan": "sv", "doc_zh": "瑞典语"},
                 {"lan": "tl", "doc_zh": "他加禄语"}, {"lan": "tg", "doc_zh": "塔吉克语"},
                 {"lan": "ta", "doc_zh": "泰米尔语"}, {"lan": "tt", "doc_zh": "鞑靼语"},
                 {"lan": "te", "doc_zh": "泰卢固语"}, {"lan": "th", "doc_zh": "泰语"},
                 {"lan": "ti", "doc_zh": "提格利尼亚语"}, {"lan": "to", "doc_zh": "汤加语"},
                 {"lan": "ts", "doc_zh": "聪加语"}, {"lan": "tn", "doc_zh": "茨瓦纳语"},
                 {"lan": "tr", "doc_zh": "土耳其语"}, {"lan": "tk", "doc_zh": "土库曼语"},
                 {"lan": "tw", "doc_zh": "契维语"}, {"lan": "uk", "doc_zh": "乌克兰语"},
                 {"lan": "ur", "doc_zh": "乌尔都语"}, {"lan": "uz", "doc_zh": "乌兹别克语"},
                 {"lan": "vi", "doc_zh": "越南语"}, {"lan": "vo", "doc_zh": "沃拉普克语"},
                 {"lan": "cy", "doc_zh": "威尔士语"}, {"lan": "fy", "doc_zh": "西弗里西亚语"},
                 {"lan": "wo", "doc_zh": "沃洛夫语"}, {"lan": "xh", "doc_zh": "科萨语"},
                 {"lan": "yi", "doc_zh": "意第绪语"}, {"lan": "yo", "doc_zh": "约鲁巴语"},
                 {"lan": "zu", "doc_zh": "祖鲁语"}]
    lang = None
    for i in lang_list:
        if f".{i['lan']}." in filename:
            lang = i['lan']
            break
    if not lang:
        raise Exception("未找到语言")
    else:
        return lang
