__version__ = "0.1.0"

def info():
    return "This is a dummy _libgcc_mutex package for PyPI."
