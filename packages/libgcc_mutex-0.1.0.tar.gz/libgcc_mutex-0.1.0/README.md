# libgcc-mutex\nA dummy Python package version of _libgcc_mutex.
