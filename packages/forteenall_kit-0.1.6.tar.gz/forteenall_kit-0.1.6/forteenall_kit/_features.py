# This file is auto-generated. Do not edit manually.
# For upadte this file pls run 'bash update.sh' on main forteenall project

# Invokers import
from forteenall_kit.invokers.spaceDup import Feature as Feature_spaceDup

features = {
    'spaceDup': Feature_spaceDup
}

