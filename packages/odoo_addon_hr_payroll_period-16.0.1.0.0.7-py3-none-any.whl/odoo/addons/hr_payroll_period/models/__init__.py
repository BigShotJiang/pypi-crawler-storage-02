# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import date_range_type
from . import hr_contract
from . import hr_fiscal_year
from . import hr_payslip
from . import hr_payslip_employees
from . import hr_payslip_run
from . import hr_period
from . import hr_employee
