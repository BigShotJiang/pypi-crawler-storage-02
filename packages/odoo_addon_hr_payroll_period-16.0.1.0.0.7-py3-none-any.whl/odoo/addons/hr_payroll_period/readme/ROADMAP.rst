#. Currently it is not possible to close the HR fiscal year before the end of
   the end of the last period. When implementing this feature, contracts and
   opened payslips should be updated with the new period assigned.
#. It is not possible to use the date_range module in server tools to generate
   semi-monthly periods so those periods are generated as in previous versions.
#. The date_range module does not allow to create a period for just one day.
