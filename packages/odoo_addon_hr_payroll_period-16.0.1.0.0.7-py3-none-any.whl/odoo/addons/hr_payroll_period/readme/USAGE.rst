Create a payslip batch
~~~~~~~~~~~~~~~~~~~~~~
Go to: Human Resources -> Payroll -> Payslip Batches

The first period of the fiscal year is already selected.
You may change it if you manage multiple types of schedules.

 - Click on Generate Payslips

The employees paid with the selected schedule are automatically selected.

 - Click on Generate

 - Confirm your payslips

 - Click on Close

The payroll period is closed automatically and the next one is open.
