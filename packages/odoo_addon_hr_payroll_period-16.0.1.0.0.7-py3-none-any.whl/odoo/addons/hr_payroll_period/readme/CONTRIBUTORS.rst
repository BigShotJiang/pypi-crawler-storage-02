* David Dufresne <david.dufresne@savoirfairelinux.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Pierre Lamarche <pierre.lamarche@savoirfairelinux.com>
* Salton Massally <smassally@idtlabs.sl>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Jordi Ballester Alomar <jordi.ballester@eficent.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Aaron Henriquez <aheficent@eficent.com>
