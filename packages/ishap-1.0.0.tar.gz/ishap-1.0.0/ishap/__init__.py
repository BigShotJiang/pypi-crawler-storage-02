# Import the main explainer class to make it accessible as `ishap.IShapExplainer`
from .explainer import IShapExplainer

# You can also import plotting functions if you want them at the top level
# from .plots import plot_ishap