# 设置代码格式化函数, 以下是使用ruff的示例
from pathlib import Path
import subprocess
def format(path):
   subprocess.run(["uvx", "ruff", "format", path])

target_path = Path() / "_target_config_1.py"

# def format(path):
#     pass