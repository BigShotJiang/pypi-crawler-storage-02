from gen_epix.omopdb.domain.service.omop import BaseOmopService


class OmopService(BaseOmopService):
    pass
