# pylint: disable=useless-import-alias
from gen_epix.omopdb.domain.repository.omop import (
    BaseOmopRepository as BaseOmopRepository,
)
from gen_epix.omopdb.domain.repository.organization import (
    BaseOrganizationRepository as BaseOrganizationRepository,
)
from gen_epix.omopdb.domain.repository.system import (
    BaseSystemRepository as BaseSystemRepository,
)
