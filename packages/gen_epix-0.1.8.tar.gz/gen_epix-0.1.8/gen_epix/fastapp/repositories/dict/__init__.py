# pylint: disable=useless-import-alias
from gen_epix.fastapp.repositories.dict.repository import (
    DictRepository as DictRepository,
)
from gen_epix.fastapp.repositories.dict.unit_of_work import (
    DictUnitOfWork as DictUnitOfWork,
)
