from __future__ import annotations

from gen_epix.seqdb.domain.service import BaseAbacService


class AbacService(BaseAbacService):

    def register_policies(self) -> None:
        """
        Placeholder for registering policies
        """
        pass
