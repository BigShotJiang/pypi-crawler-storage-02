# Discord Tools

Discord Tools is a collection of tools designed to enhance the functionality and ease of use for Discord bots.

## Features

- Easy to use
- Enhances Discord bot functionality
- Compatible with Python 3.10 and above

## Installation

You can install the package using pip:

```bash
pip install discord-py-utilities
```