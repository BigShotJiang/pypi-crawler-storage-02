# Credits

this project was made using the [Link Model Language (LinkML) framework](https://github.com/linkml/linkml)
