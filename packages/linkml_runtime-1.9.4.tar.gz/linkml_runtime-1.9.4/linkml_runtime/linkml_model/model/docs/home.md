# Introduction

Welcome to the LinkML metamodel reference guide. For full documentation see [linkml.io/linkml/](https://linkml.io/linkml/).

