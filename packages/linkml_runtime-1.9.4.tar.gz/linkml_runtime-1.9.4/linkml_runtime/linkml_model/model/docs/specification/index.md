# LinkML Specification

## Table of Contents

- [Preamble](00preamble)
- [Introduction](01introduction)
- [Instances](02instances)
- [Schemas](03schemas)
- [Derived Schemas](D04derived-schemas)
- [Validation](05validation)
- [Mapping](06mapping)
