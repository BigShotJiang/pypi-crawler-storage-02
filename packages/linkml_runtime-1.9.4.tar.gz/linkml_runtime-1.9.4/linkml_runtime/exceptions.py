class OrderingError(RuntimeError):
    """Exception raised when there is a problem with SchemaView ordering"""
