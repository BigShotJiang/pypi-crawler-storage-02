[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
![](https://github.com/FAIRmat-NFDI/pynxtools-spm/actions/workflows/pytest.yml/badge.svg)
![](https://github.com/FAIRmat-NFDI/pynxtools-spm/actions/workflows/pylint.yml/badge.svg)
![](https://github.com/FAIRmat-NFDI/pynxtools-spm/actions/workflows/publish.yml/badge.svg)
![](https://img.shields.io/pypi/pyversions/pynxtools-spm)
![](https://img.shields.io/pypi/l/pynxtools-spm)
![](https://img.shields.io/pypi/v/pynxtools-spm)
![](https://coveralls.io/repos/github/FAIRmat-NFDI/pynxtools_spm/badge.svg?branch=master)

 # SPM Reader
 !!WARNING!! The is under development.
 