mammos-dft
==========

This package provides functionality to get magnetic material properties from DFT methods.

.. toctree::
   :maxdepth: 1

   quickstart
