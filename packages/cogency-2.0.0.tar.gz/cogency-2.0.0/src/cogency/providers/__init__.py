"""Providers: External service integrations."""

from .openai import generate

__all__ = ["generate"]
