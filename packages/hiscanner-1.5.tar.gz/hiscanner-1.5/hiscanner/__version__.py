VERSION = (1, 5)
__version__ = '.'.join(map(str, VERSION))