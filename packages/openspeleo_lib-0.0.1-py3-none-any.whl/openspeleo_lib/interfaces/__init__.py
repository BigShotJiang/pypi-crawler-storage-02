from openspeleo_lib.interfaces.ariane.interface import ArianeInterface

__all__ = ["ArianeInterface"]
