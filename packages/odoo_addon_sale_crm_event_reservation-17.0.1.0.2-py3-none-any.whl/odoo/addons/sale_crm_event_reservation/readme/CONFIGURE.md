To make use of this module, a user needs these minimal permissions:

- Sales / User: Own Documents Only
- Events / User
