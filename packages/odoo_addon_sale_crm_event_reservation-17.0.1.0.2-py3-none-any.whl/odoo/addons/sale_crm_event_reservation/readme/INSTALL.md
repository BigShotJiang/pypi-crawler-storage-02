To install this module, you need to:

1.  Install *crm_event* and *event_sale_reservation* from
    <https://github.com/OCA/event>.
