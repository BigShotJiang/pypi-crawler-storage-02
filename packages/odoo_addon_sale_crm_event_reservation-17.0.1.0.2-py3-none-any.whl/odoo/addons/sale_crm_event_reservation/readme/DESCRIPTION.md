This module extends the functionality of *crm_event*,
*event_sale_reservation* and *sale_crm* to support fast generation of
event quotations from opportunities and to allow you to sell events like
a boss.
