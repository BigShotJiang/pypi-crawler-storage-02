:mod:`decimal128` -- Support for BSON Decimal128
================================================
.. automodule:: bson.decimal128
   :members:
