def main():
    print("Hello from final-task!")


if __name__ == "__main__":
    main()
