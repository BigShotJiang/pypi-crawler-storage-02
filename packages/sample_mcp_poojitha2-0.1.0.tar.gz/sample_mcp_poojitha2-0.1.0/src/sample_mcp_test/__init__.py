from .mcp_test import mcp
def main()->None:
    mcp.run()