__version__ = "3.2.0"
__version_info__ = tuple([int(num) for num in __version__.split(".")])

from .main import *  # noqa: F403
