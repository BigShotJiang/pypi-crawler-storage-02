from .control import Inspect
