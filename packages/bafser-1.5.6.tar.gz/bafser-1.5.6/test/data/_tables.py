from bafser import TablesBase


class Tables(TablesBase):
    pass
