"""Tests for HTTP instrumentation."""
