"""Commands for the `lilypad` CLI."""

from .local import local_command

__all__ = ["local_command"]
