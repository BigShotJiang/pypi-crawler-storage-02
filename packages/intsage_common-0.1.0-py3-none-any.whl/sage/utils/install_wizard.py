#!/usr/bin/env python3
"""
SAGE 安装向导
帮助用户选择和安装合适的功能包
"""

import subprocess
import sys
from typing import List, Dict, Tuple


def check_package_installed(package_name: str) -> bool:
    """检查包是否已安装"""
    try:
        __import__(package_name.replace('-', '_'))
        return True
    except ImportError:
        return False


def get_installation_status() -> Dict[str, bool]:
    """获取各功能包的安装状态"""
    packages = {
        'cli': False,
        'dev': False, 
        'frontend': False,
        'docs': False
    }
    
    try:
        import sage.cli
        packages['cli'] = True
    except ImportError:
        pass
        
    try:
        import sage.dev
        packages['dev'] = True
    except ImportError:
        pass
        
    try:
        import sage.frontend
        packages['frontend'] = True
    except ImportError:
        pass
    
    # 检查文档工具
    try:
        import sphinx
        packages['docs'] = True
    except ImportError:
        pass
    
    return packages


def show_installation_status():
    """显示当前安装状态"""
    print("\n📦 SAGE 功能包安装状态:")
    print("=" * 50)
    
    status = get_installation_status()
    
    features = [
        ('cli', 'CLI 工具', 'intsage-common[basic]'),
        ('dev', '开发工具', 'intsage-common[dev]'),
        ('frontend', 'Web 前端', 'intsage-common[frontend]'),
        ('docs', '文档工具', 'intsage-common[docs]'),
    ]
    
    for key, name, package in features:
        status_icon = "✅" if status[key] else "❌"
        print(f"  {status_icon} {name:<15} ({package})")
    
    print("\n💡 安装建议:")
    if not any(status.values()):
        print("  建议安装基础功能: pip install intsage-common[basic]")
    elif not status['dev'] and status['cli']:
        print("  建议添加开发工具: pip install intsage-common[dev]")
    elif all(status.values()):
        print("  🎉 所有功能包已安装！")


def interactive_installer():
    """交互式安装向导"""
    print("\n🚀 SAGE 安装向导")
    print("=" * 50)
    
    options = [
        ("basic", "基础功能 (utils + cli)", "intsage-common[basic]"),
        ("tools", "开发工具 (basic + dev)", "intsage-common[tools]"),
        ("web", "Web 功能 (frontend)", "intsage-common[frontend]"),
        ("full", "完整安装 (所有功能)", "intsage-common[full]"),
        ("custom", "自定义选择", None),
    ]
    
    print("\n请选择安装选项:")
    for i, (key, desc, package) in enumerate(options, 1):
        print(f"  {i}. {desc}")
        if package:
            print(f"     命令: pip install {package}")
    
    try:
        choice = input("\n请输入选项编号 (1-5): ").strip()
        choice_idx = int(choice) - 1
        
        if 0 <= choice_idx < len(options):
            key, desc, package = options[choice_idx]
            
            if key == "custom":
                return custom_installer()
            elif package:
                return install_package(package, desc)
        else:
            print("❌ 无效选项")
            return False
            
    except (ValueError, KeyboardInterrupt):
        print("\n操作已取消")
        return False


def custom_installer():
    """自定义功能选择安装"""
    print("\n🔧 自定义功能选择:")
    
    features = [
        ("cli", "CLI 工具"),
        ("dev", "开发工具"),
        ("frontend", "Web 前端"),
        ("docs", "文档工具"),
    ]
    
    selected = []
    for key, name in features:
        try:
            answer = input(f"安装 {name}? (y/n): ").strip().lower()
            if answer in ['y', 'yes', '是']:
                selected.append(key)
        except KeyboardInterrupt:
            print("\n操作已取消")
            return False
    
    if selected:
        package = f"intsage-common[{','.join(selected)}]"
        return install_package(package, f"自定义功能 ({', '.join(selected)})")
    else:
        print("❌ 未选择任何功能")
        return False


def install_package(package: str, description: str) -> bool:
    """安装指定的包"""
    print(f"\n🔄 正在安装 {description}...")
    print(f"命令: pip install {package}")
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", package],
            capture_output=True,
            text=True,
            check=True
        )
        print("✅ 安装成功！")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 安装失败: {e}")
        print(f"错误输出: {e.stderr}")
        return False


def main():
    """主函数"""
    print("🎯 SAGE 功能包管理工具")
    
    while True:
        print("\n选择操作:")
        print("  1. 查看安装状态")
        print("  2. 交互式安装")
        print("  3. 退出")
        
        try:
            choice = input("\n请输入选项编号: ").strip()
            
            if choice == "1":
                show_installation_status()
            elif choice == "2":
                interactive_installer()
            elif choice == "3":
                print("👋 再见！")
                break
            else:
                print("❌ 无效选项，请重新输入")
                
        except KeyboardInterrupt:
            print("\n\n👋 再见！")
            break


if __name__ == "__main__":
    main()
