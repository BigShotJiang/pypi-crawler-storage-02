# SPDX-FileCopyrightText: 2024-present pgbarletta <pbarletta@gmail.com>
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
__logging_name__ = "amberflow"

from .pipeline import Pipeline
from .cli import runflow
