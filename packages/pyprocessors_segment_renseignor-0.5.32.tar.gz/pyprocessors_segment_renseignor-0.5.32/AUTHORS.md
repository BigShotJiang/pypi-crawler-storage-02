# Authors

Contributors to pyprocessors_segment_renseignor include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
