"""Utils package for MCP STDIO adapter."""
