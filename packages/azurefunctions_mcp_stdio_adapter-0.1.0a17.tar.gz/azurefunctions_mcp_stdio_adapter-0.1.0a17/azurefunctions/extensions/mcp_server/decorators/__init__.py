"""Decorators package for MCP STDIO adapter."""
