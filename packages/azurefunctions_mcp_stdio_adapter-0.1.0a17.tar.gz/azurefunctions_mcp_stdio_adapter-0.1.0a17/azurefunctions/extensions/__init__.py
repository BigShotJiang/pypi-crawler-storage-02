"""Azure Functions extensions package."""

# This is a namespace package to allow coexistence with azurefunctions-extensions-base
__path__ = __import__("pkgutil").extend_path(__path__, __name__)
