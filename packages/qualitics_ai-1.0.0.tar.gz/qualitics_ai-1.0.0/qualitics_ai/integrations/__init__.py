"""Integration modules for external systems."""
