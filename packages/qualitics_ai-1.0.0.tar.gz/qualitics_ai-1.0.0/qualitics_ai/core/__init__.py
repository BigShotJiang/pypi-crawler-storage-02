"""Core modules for Qualitics AI."""
