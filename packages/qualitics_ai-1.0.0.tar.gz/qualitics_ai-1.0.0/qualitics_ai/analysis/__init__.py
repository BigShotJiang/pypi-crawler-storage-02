"""Analysis modules for AI-powered insights."""
