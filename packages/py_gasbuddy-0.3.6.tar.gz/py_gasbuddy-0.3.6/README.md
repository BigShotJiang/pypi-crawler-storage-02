![Codecov branch](https://img.shields.io/codecov/c/github/firstof9/py-gasbuddy/main?style=flat-square)
![GitHub commit activity (branch)](https://img.shields.io/github/commit-activity/m/firstof9/py-gasbuddy?style=flat-square)
![GitHub last commit](https://img.shields.io/github/last-commit/firstof9/py-gasbuddy?style=flat-square)
![GitHub release (latest SemVer)](https://img.shields.io/github/v/release/firstof9/py-gasbuddy?style=flat-square)
# py-gasbuddy
Python Library for GasBuddy GraphQL

A python library for retreiving data from GasBuddy

