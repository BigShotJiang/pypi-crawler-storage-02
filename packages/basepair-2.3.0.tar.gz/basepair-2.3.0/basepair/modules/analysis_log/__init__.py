'''Log module'''
from .abstract import Abstract
from .analysis import AnalysisLog
from .infra import InfraLog
