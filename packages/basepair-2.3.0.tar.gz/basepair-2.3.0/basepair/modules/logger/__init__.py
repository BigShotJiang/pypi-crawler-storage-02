'''Logger module'''
from .logger import Logger
