sandhi package
==============

Submodules
----------

sandhi.apavaada module
----------------------

.. automodule:: sandhi.apavaada
   :members:
   :undoc-members:
   :show-inheritance:

sandhi.cli module
-----------------

.. automodule:: sandhi.cli
   :members:
   :undoc-members:
   :show-inheritance:

sandhi.niyama module
--------------------

.. automodule:: sandhi.niyama
   :members:
   :undoc-members:
   :show-inheritance:

sandhi.sandhi module
--------------------

.. automodule:: sandhi.sandhi
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: sandhi
   :members:
   :undoc-members:
   :show-inheritance:
