a simple oxapay payment gateway helper

