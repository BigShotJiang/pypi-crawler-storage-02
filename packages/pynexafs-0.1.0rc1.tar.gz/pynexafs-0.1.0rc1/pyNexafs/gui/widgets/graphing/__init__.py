import pyNexafs.gui.widgets.graphing.matplotlib.graphs
