from .core import ProductionFAQSystem

__version__ = "0.1.0"
__author__ = "jayaprakash-shanmugam"
__email__ = "jayaprkash7@gmail.com"

__all__ = ["ProductionFAQSystem"]