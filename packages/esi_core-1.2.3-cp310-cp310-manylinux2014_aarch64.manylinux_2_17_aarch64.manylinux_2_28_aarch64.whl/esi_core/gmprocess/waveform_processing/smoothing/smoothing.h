void konno_ohmachi_c(double *spec, double *freqs, int npoints, double *ko_freqs,
                     double *ko_smooth, int nko, double bandwidth);

