void calculate_spectrals_c(double *acc, int np, double dt, double period,
	                       double damping, double *sacc, double *svel,
						   double *sdis);
