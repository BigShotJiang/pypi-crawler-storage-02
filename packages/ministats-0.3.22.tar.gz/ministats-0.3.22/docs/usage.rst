=====
Usage
=====

To use Mini Statistics in a project::

    import ministats
