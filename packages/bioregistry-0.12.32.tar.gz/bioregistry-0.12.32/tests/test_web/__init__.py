"""Test for the Bioregistry web application."""
