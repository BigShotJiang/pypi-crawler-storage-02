Setup with pip
**************

It is also possible to use "pip" to install the library. Before running this
command, please make sure that the :ref:`C++ software and libraries
<requirements>` needed to compile the library kernel are installed. Then,
install pyinterp with pip: ::

    $ pip install pyinterp
