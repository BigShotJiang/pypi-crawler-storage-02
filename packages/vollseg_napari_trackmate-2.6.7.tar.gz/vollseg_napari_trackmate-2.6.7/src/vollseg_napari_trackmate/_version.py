__version__ = version = "2.6.7"
__version_tuple__ = version_tuple = (2, 6, 7)
