from napatrackmater import test_tracks_xenopus


def get_test_tracks_xenopus():

    return [(test_tracks_xenopus(), {"name": "test_tracks_xenopus"})]
