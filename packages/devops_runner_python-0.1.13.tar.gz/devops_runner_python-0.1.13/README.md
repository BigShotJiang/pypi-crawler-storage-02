# devops-python

To test:

```
uv add --editable /abs/path
```
