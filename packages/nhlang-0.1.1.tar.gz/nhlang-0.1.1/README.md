# NH Language

**NH Language** là một ngôn ngữ lập trình đơn giản, do Hwi GD tạo ra.  
Được thiết kế để dễ học, dễ test các biến, vòng lặp, điều kiện, và in ra màn hình.

## Cài đặt

Cài trực tiếp từ PyPI (sau khi upload):

```bash
pip install nhlang
