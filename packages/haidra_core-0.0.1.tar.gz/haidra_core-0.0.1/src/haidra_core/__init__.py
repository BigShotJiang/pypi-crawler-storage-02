"""Contains core classes and functions for the Haidra ecosystem."""
