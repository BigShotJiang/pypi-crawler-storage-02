"""fontconfig package"""
from .fontconfig import *  # noqa: F401,F403

__version__ = "0.1.2"
