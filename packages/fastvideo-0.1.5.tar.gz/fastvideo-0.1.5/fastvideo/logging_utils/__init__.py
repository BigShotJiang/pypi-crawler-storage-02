# SPDX-License-Identifier: Apache-2.0

from fastvideo.logging_utils.formatter import NewLineFormatter

__all__ = [
    "NewLineFormatter",
]
