from fastvideo.configs.sample.base import SamplingParam

__all__ = ["SamplingParam"]
