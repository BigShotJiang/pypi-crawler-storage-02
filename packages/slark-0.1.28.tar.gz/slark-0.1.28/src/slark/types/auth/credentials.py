from typing import Literal

CredentailTypes = Literal["tenant", "user"]
