from .._common import BaseModel


class BaseElement(BaseModel):
    tag: str
