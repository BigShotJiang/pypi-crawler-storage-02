from ..base import BaseElement


class HlineElement(BaseElement):
    tag: str = "hr"