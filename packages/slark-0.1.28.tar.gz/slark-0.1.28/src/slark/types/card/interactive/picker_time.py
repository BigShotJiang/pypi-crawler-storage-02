from ..base import BaseElement


class PickerTimeElement(BaseElement):
    tag: str = "picker_time"