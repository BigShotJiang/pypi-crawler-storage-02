from ..base import BaseElement


class DatePickerElement(BaseElement):
    tag: str = "date_picker"