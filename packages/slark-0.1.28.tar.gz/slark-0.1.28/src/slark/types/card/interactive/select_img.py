from ..base import BaseElement


class SelectImgElement(BaseElement):
    tag: str = "select_img"