from ..base import BaseElement


class MultiSelectStaticElement(BaseElement):
    tag: str = "multi_select_static"