from ..base import BaseElement


class PickerDatetimeElement(BaseElement):
    tag: str = "picker_datetime"