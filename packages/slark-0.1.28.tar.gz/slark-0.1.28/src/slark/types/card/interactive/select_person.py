from ..base import BaseElement


class SelectPersonElement(BaseElement):
    tag: str = "select_person"