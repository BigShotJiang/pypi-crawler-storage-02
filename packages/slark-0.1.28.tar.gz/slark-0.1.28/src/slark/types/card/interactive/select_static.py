from ..base import BaseElement


class SelectStaticElement(BaseElement):
    tag: str = "select_static"