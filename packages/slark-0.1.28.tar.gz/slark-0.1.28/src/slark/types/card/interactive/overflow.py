from ..base import BaseElement


class OverflowElement(BaseElement):
    tag: str = "overflow"