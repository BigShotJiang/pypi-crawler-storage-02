from ..base import BaseElement


class MultiSelectPersonElement(BaseElement):
    tag: str = "multi_select_person"