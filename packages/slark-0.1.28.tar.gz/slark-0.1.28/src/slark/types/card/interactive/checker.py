from ..base import BaseElement


class CheckerElement(BaseElement):
    tag: str = "checker"