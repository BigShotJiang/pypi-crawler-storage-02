from slark.resources._resources import APIResource, AsyncAPIResource


class AsyncView(AsyncAPIResource):
    pass


class View(APIResource):
    pass
