import polars as pl


def welcome():
    return "Welcome! Functionality will be added soon!"


def data():
    return pl.DataFrame({"a": [1, 2, 3]})
