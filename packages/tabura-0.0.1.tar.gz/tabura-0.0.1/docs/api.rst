.. py:module:: tabura

Example
*******

.. python-apigen-group:: welcome