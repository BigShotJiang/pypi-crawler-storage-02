ni README.md -Value "# FitSearchCV`n`nA smarter alternative to GridSearchCV."
