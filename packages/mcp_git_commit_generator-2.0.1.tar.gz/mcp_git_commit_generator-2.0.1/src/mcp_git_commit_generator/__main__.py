"""Main entry point for the git commit generator module."""

from mcp_git_commit_generator import main

main()
