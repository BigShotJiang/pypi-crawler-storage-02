# typedcollections

A Python library for creating type-safe collections like lists, ensuring all elements match a given type.

## Installation

```bash
pip install typedcollections
