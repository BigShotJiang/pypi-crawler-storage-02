# -*- coding:utf-8 -*-

__version_info = (0, 1.2)
__version__ = ".".join([str(x) for x in __version_info])
