from pathlib import Path

import pytest

pytest._test_path = Path(__file__).parent
