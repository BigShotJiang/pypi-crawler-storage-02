"""
View blueprints for the URL Analyzer web interface.

This package contains the Flask blueprints for different sections of the web interface.
"""