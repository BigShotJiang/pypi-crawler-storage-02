"""
Benchmark Package

This package contains benchmarking tools for the URL Analyzer application.
"""