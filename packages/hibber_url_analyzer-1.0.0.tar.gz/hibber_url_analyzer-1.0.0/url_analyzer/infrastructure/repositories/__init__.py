"""
Repository Implementations

This package contains implementations of the repository interfaces
defined in the application layer.
"""