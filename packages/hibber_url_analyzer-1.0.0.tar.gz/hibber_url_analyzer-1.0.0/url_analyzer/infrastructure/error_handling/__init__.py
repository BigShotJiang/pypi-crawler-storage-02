"""
Error Handling Infrastructure

This package contains implementations of the error handling interfaces
defined in the application layer.
"""