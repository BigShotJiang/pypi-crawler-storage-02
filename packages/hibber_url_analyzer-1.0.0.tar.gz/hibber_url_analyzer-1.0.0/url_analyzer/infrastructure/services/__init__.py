"""
Service Implementations

This package contains implementations of the service interfaces
defined in the application layer.
"""