from pyasic.miners.backends.espminer import ESPMiner


class BitAxe(ESPMiner):
    """Handler for BitAxe"""

    pass
