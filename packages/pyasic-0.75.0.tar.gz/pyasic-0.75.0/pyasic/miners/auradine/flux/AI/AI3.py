from pyasic.miners.backends import Auradine
from pyasic.miners.device.models import AuradineAI3680


class AuradineFluxAI3680(AuradineAI3680, Auradine):
    pass
