"""
CLI commands for Tree-sitter debugging tools.
"""
