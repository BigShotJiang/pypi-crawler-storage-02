from .docx_reader import DocxReader

__all__ = ["DocxReader"]
