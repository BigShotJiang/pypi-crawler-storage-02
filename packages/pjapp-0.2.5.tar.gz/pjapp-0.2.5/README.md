# App for practicing Japanese

## Known issues:

En la versión de teléfono parece no guardarse el score (confirmado, no se guarda)