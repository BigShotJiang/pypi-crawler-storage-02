from datetime import datetime

from data_providers import WorklogExtractor
from data_providers.abstract_worklog_extractor import AbstractStatusChangeWorklogExtractor
from data_providers.worklog_extractor import IssueTotalSpentTimeExtractor
from data_providers.worktime_extractor import SimpleWorkTimeExtractor, WorkTimeExtractor


class JiraWorklogExtractor(WorklogExtractor):

    def __init__(self, jira_client, user_filter: list[str] = None, include_subtask_worklog=False) -> None:
        self.jira_client = jira_client
        self.user_filter = user_filter
        self.include_subtask_worklog = include_subtask_worklog

    def get_work_time_per_user(self, issue):
        worklogs = self._get_worklog_for_issue_with_subtasks(issue)

        working_time_per_user = {}
        for worklog in worklogs:
            worklog_user = self._extract_user_from_worklog(worklog)
            if self._is_allowed_user(worklog_user):
                worklog_time_spent = self._extract_time_in_seconds_from_worklog(worklog)

                working_time_per_user[worklog_user] = working_time_per_user.get(worklog_user, 0) + worklog_time_spent

        return working_time_per_user

    def _get_worklog_for_issue_with_subtasks(self, issue):
        worklogs = []
        worklogs.extend(self._get_worklogs_from_jira(issue['key']))
        if self.include_subtask_worklog:
            try:
                sub_task_keys = [subtask["key"] for subtask in issue["fields"]["subtasks"]]
                for subtask in sub_task_keys:
                    worklogs.extend(self._get_worklogs_from_jira(subtask))
            except AttributeError:
                pass
        return worklogs

    def _get_worklogs_from_jira(self, issue_key: str):
        data = self.jira_client.issue_get_worklog(issue_key)
        if 'worklogs' in data:
            return data['worklogs']
        return data

    def _is_allowed_user(self, worklog_user):
        if self.user_filter is None:
            return True
        if worklog_user in self.user_filter:
            return True
        return False

    @staticmethod
    def _extract_time_in_seconds_from_worklog(worklog):
        return worklog["timeSpentSeconds"]

    @staticmethod
    def _extract_user_from_worklog(worklog):
        return worklog["author"]["accountId"]


SIMPLE_WORKTIME_EXTRACTOR = SimpleWorkTimeExtractor()

class JiraStatusChangeWorklogExtractor(AbstractStatusChangeWorklogExtractor):

    def __init__(self, transition_statuses: list[str],
                 user_filter: list[str] = None,
                 time_format='%Y-%m-%dT%H:%M:%S.%f%z',
                 use_user_name=False,
                 use_status_codes=False,
                 worktime_extractor: WorkTimeExtractor = SIMPLE_WORKTIME_EXTRACTOR) -> None:

        super().__init__(transition_statuses=transition_statuses,
                         user_filter=user_filter,
                         worktime_extractor=worktime_extractor)
        self.time_format = time_format
        self.use_user_name = use_user_name
        self.use_status_codes = use_status_codes

    def _extract_chronological_changes_sequence(self, issue):
        if not isinstance(issue, dict):
            return []
        if 'changelog' not in issue or 'histories' not in issue['changelog']:
            return []

        changelog_history = []
        changelog = issue['changelog']['histories']
        for history_entry in changelog:
            if 'items' not in history_entry:
                continue
            for history_entry_item in history_entry['items']:
                if self._is_status_change_entry(history_entry_item) or self._is_user_change_entry(history_entry_item):
                    history_entry_item['created'] = history_entry['created']
                    changelog_history.append(history_entry_item)

        changelog_history.reverse()  # Jira returns newest first; reverse to chronological
        return changelog_history

    def _is_user_change_entry(self, changelog_entry):
        return 'fieldId' in changelog_entry and changelog_entry['fieldId'] == 'assignee'

    def _is_status_change_entry(self, changelog_entry):
        return 'fieldId' in changelog_entry and changelog_entry['fieldId'] == 'status'

    def _extract_user_from_change(self, changelog_entry):
        if self.use_user_name:
            return changelog_entry['toString']
        else:
            return changelog_entry['to']

    def _extract_change_time(self, changelog_entry):
        return datetime.strptime(changelog_entry['created'], self.time_format)

    def _is_status_changed_into_required(self, changelog_entry):
        if self.transition_statuses is None:
            return True
        if self.use_status_codes:
            return changelog_entry['to'] in self.transition_statuses
        else:
            return changelog_entry['toString'] in self.transition_statuses

    def _is_status_changed_from_required(self, changelog_entry):
        if self.transition_statuses is None:
            return True
        if self.use_status_codes:
            return changelog_entry['from'] in self.transition_statuses
        else:
            return changelog_entry['fromString'] in self.transition_statuses

    def _is_current_status_a_required_status(self, issue):
        if self.transition_statuses is None:
            return True
        if 'fields' not in issue or 'status' not in issue['fields']:
            return False
        if self.use_status_codes:
            return issue['fields']['status']['id'] in self.transition_statuses in self.transition_statuses
        else:
            return issue['fields']['status']['name'] in self.transition_statuses


class JiraResolutionTimeIssueTotalSpentTimeExtractor(IssueTotalSpentTimeExtractor):

    def __init__(self, time_format='%Y-%m-%dT%H:%M:%S.%f%z') -> None:
        self.time_format = time_format

    def get_total_spent_time(self, issue) -> int:
        resolution_date_str = issue['fields']['resolutiondate']
        if resolution_date_str is None:
            return 0

        resolution_date = datetime.strptime(resolution_date_str, self.time_format)
        creation_date = datetime.strptime(issue['fields']['created'], self.time_format)
        spent_time = (resolution_date - creation_date)
        return int(spent_time.total_seconds())
