# mode: error

class Test(object):
    pass

_ERRORS = u"""
3:0: C class 'Test' is declared but not defined
"""
