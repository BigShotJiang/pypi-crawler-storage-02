"""
Scripts package for Solveig entry points.
"""
