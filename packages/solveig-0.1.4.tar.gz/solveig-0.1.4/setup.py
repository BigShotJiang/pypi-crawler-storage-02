#!/usr/bin/env python3
"""
Legacy setup.py for backwards compatibility.
All configuration is now in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
