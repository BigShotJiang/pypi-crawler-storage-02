class ArgumentPaser():

    def __init__(self, args: dict):
        self.__args = args

    def 