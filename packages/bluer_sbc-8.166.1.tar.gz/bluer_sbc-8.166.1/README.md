# 🌀 bluer-sbc

🌀 `bluer-sbc` is a [`bluer-ai`](https://github.com/kamangir/bluer-ai) plugin for edge computing on [single board computers](https://github.com/kamangir/blue-bracket). 

```bash
pip install bluer_sbc

# @env dot list
@env dot cp <env-name> local
```

|   |   |   |
| --- | --- | --- |
| [`cheshmak`](./bluer_sbc/docs/cheshmak.md) [![image](https://github.com/kamangir/assets2/blob/main/cheshmak/01.png?raw=true)](./bluer_sbc/docs/cheshmak.md)  | [`bluer-swallow`](./bluer_sbc/docs/bluer-swallow.md) [![image](https://github.com/kamangir/assets2/blob/main/bluer-swallow/design/06.jpg?raw=true)](./bluer_sbc/docs/bluer-swallow.md)  | [`bryce`](./bluer_sbc/docs/bryce.md) [![image](https://github.com/kamangir/assets2/blob/main/bryce/08.jpg?raw=true)](./bluer_sbc/docs/bryce.md)  |
| [`blue3`](https://github.com/kamangir/blue-bracket/blob/main/designs/blue3.md) [![image](https://github.com/kamangir/blue-bracket/raw/main/images/blue3-1.jpg)](https://github.com/kamangir/blue-bracket/blob/main/designs/blue3.md)  | [`chenar-grove`](https://github.com/kamangir/blue-bracket/blob/main/designs/chenar-grove.md) [![image](https://github.com/kamangir/blue-bracket/raw/main/images/chenar-grove-1.jpg)](https://github.com/kamangir/blue-bracket/blob/main/designs/chenar-grove.md)  | [`cube`](https://github.com/kamangir/blue-bracket/blob/main/designs/cube.md) [![image](https://github.com/kamangir/blue-bracket/raw/main/images/cube-1.jpg)](https://github.com/kamangir/blue-bracket/blob/main/designs/cube.md)  |
| [`eye_nano`](https://github.com/kamangir/blue-bracket/blob/main/designs/eye_nano.md) [![image](https://github.com/kamangir/blue-bracket/raw/main/images/eye_nano-1.jpg)](https://github.com/kamangir/blue-bracket/blob/main/designs/eye_nano.md)  |  |  |

# aliases

[@camera](./bluer_sbc/docs/aliases/camera.md), 
[@sbc <hardware>](./bluer_sbc/docs/aliases/hardware.md).

---

> 🌀 [`blue-sbc`](https://github.com/kamangir/blue-sbc) for the [Global South](https://github.com/kamangir/bluer-south).

---


[![pylint](https://github.com/kamangir/bluer-sbc/actions/workflows/pylint.yml/badge.svg)](https://github.com/kamangir/bluer-sbc/actions/workflows/pylint.yml) [![pytest](https://github.com/kamangir/bluer-sbc/actions/workflows/pytest.yml/badge.svg)](https://github.com/kamangir/bluer-sbc/actions/workflows/pytest.yml) [![bashtest](https://github.com/kamangir/bluer-sbc/actions/workflows/bashtest.yml/badge.svg)](https://github.com/kamangir/bluer-sbc/actions/workflows/bashtest.yml) [![PyPI version](https://img.shields.io/pypi/v/bluer-sbc.svg)](https://pypi.org/project/bluer-sbc/) [![PyPI - Downloads](https://img.shields.io/pypi/dd/bluer-sbc)](https://pypistats.org/packages/bluer-sbc)

built by 🌀 [`bluer README`](https://github.com/kamangir/bluer-objects/tree/main/bluer_objects/README), based on 🌀 [`bluer_sbc-8.166.1`](https://github.com/kamangir/bluer-sbc).

