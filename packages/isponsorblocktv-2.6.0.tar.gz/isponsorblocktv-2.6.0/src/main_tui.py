from iSponsorBlockTV import setup_wizard
from iSponsorBlockTV.helpers import Config

config = Config("data/config.json")
setup_wizard.main(config)
