from . import helpers


def main():
    helpers.app_start()


if __name__ == "__main__":
    main()
