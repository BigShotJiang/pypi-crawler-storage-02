"""
Test package for easybench.

This package contains test modules and fixtures for testing easybench functionality.
"""
