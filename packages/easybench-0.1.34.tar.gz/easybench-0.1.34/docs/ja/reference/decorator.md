# Decorator

::: easybench.decorator
