# CLI

::: easybench.cli
