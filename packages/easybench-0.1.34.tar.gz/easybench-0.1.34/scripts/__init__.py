"""Utility scripts for the easybench project."""
