from enum import StrEnum
from typing import Self


class CaseStatus(StrEnum):
  """Case status enum"""

  PENDING = 'PENDING'
  FOLLOWED = 'FOLLOWED'
  CLOSED = 'CLOSED'

  def __str__(self: Self) -> str:
    """Readable property"""
    return self.name

  def __repr__(self: Self) -> str:
    """Readable property"""
    return f'CaseStatus.{self.name}'
