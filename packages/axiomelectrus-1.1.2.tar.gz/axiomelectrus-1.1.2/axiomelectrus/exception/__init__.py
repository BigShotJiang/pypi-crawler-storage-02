from .base import ElectrusException as ElectrusException

__all = [
    ElectrusException
]