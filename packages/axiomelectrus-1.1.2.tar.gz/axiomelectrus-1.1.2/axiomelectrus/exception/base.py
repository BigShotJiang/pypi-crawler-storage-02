class ElectrusException(Exception):
    """Custom Exception for Electrus related errors."""
    pass