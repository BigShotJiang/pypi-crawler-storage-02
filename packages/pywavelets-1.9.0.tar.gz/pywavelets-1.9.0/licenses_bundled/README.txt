The PyWavelets repository and source distributions bundle some code that is
adapted from compatibly licensed projects. We list these here, together with
the path to the files (relative to the root of the repository or sdist)
identifying the vendored code that required including a license file.

Name: NumPy
Files:  pywt/_pytesttester.py
License: BSD-3-Clause

Name: SciPy
Files:  meson.build, util/*
License: BSD-3-Clause
