#pragma once

#define CAT_HELPER(A, B) A##B
#define CAT(A, B) CAT_HELPER(A, B)
