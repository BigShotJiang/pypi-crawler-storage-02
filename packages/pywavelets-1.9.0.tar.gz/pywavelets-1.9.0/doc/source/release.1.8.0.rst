.. include:: ../release/1.8.0-notes.rst
