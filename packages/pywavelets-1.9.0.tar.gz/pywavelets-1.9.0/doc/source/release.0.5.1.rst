.. include:: ../release/0.5.1-notes.rst
