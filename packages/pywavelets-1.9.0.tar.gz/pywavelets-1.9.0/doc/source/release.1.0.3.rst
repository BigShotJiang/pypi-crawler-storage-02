.. include:: ../release/1.0.3-notes.rst
