.. _built-in wavelet filters: http://wavelets.pybytes.com/
.. _Cython: http://cython.org/
.. _demo: https://github.com/PyWavelets/pywt/tree/main/demo
.. _Anaconda: https://www.continuum.io
.. _GitHub: https://github.com/PyWavelets/pywt
.. _GitHub repository: https://github.com/PyWavelets/pywt
.. _GitHub Issues: https://github.com/PyWavelets/pywt/issues
.. _NumPy: https://www.numpy.org
.. _SciPy: https://www.scipy.org
.. _original developer: http://en.ig.ma
.. _Python: http://python.org/
.. _Python Package Index: http://pypi.python.org/pypi/PyWavelets/
.. _PyPI: http://pypi.python.org/pypi/PyWavelets/
.. _PyWavelets discussions group: http://groups.google.com/group/pywavelets
.. _Releases Page: https://github.com/PyWavelets/pywt/releases
.. _Matplotlib: http://matplotlib.org
.. _guidelines for pull requests: https://github.com/PyWavelets/pywt/tree/main/CONTRIBUTING.rst
.. _community guidelines: https://github.com/PyWavelets/pywt/tree/main/community_guidelines.rst
.. _code of conduct: https://github.com/PyWavelets/pywt/tree/main/doc/source/dev/conduct/community_guidelines.rst
.. _StackOverflow: https://stackoverflow.com
.. _wavelets.pybytes.com: http://wavelets.pybytes.com/
