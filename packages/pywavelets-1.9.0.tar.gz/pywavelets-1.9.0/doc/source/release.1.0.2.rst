.. include:: ../release/1.0.2-notes.rst
