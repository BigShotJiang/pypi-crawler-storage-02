# Copyright (c) Microsoft. All rights reserved.

from semantic_kernel.connectors.memory.azure_cosmosdb_no_sql.azure_cosmosdb_no_sql_memory_store import (
    AzureCosmosDBNoSQLMemoryStore,
)

__all__ = ["AzureCosmosDBNoSQLMemoryStore"]
