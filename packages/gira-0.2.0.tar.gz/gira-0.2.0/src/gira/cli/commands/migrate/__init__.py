"""Migration commands for structural changes."""
