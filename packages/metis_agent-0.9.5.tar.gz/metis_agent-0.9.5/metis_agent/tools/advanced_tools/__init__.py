"""Tool category module."""
