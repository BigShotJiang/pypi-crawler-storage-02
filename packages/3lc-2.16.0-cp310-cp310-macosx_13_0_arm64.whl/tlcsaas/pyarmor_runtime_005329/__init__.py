# Pyarmor 9.1.8 (pro), 005329, 2025-08-08T03:03:28.174552
from .pyarmor_runtime import __pyarmor__
