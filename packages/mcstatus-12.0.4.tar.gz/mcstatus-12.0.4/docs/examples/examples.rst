Examples
========

We have these examples at the moment:


.. toctree::
	:maxdepth: 1
	:caption: Examples

	ping_as_java_and_bedrock_in_one_time.rst
	ping_many_servers_at_once.rst
	player_list_from_query_with_fallback_on_status.rst


Feel free to propose us more examples, we will be happy to add them to the list!
