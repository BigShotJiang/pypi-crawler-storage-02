## Contributing

See [the documentation page](https://mcstatus.readthedocs.io/en/stable/pages/contributing/).
The documentation itself is built from the docs/ directory.
