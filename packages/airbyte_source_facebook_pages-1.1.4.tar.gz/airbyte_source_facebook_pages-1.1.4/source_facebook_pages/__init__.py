#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#


from .source import SourceFacebookPages

__all__ = ["SourceFacebookPages"]
