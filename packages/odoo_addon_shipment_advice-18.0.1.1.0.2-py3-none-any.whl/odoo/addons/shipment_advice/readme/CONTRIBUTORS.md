- Sébastien Alix \<sebastien.alix@camptocamp.com\>
- Guewen Baconnier \<guewen.baconnier@camptocamp.com\>
- Simone Orsi \<simahawk@gmail.com\>
- [Trobz](https://trobz.com):
  - Dung Tran \<dungtd@trobz.com\>
- Michael Tietz (MT Software) \<mtietz@mt-software.de\>
- Jacques-Etienne Baudoux \<je@bcim.be\>

## Design

- Joël Grand-Guillaume \<joel.grandguillaume@camptocamp.com\>
- Jacques-Etienne Baudoux \<je@bcim.be\>
