"""MCP tools for repository analysis.

This module contains MCP tool implementations for analyzing repository
changes, staging areas, and working directories.
"""
