"""Package initializer for local_git_analyzer.

Copyright 2025
SPDX-License-Identifier: Apache-2.0
Author: Manav Gupta <manavg@gmail.com>

This package contains modules for local git analysis.
"""
