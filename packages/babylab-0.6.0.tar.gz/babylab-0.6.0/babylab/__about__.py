"""
About the package.
"""

__version__ = "0.6.0"  # no cov
