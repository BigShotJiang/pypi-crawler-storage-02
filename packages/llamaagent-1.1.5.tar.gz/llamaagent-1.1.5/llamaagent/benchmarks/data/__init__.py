"""Benchmark data directory for LlamaAgent"""
