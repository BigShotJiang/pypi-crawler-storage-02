# pragma: no cover
"""llamaagent.tools.dynamic

Experimental dynamic-tool-synthesis has been removed from the public build.  This
placeholder module keeps the import path valid while excluding itself from
coverage metrics.  No executable code is provided.
"""
