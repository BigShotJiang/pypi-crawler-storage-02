# simpleMathX

Simple math library with basic functions: addition, subtraction, multiplication, and division.

## Installation

```bash
pip install simplemathx
```

## Usage

```python
from simplemathx import add, subtract, multiply, divide

def main():
    print("Add 10 + 5 =", add(10, 5))
    print("Subtract 10 - 5 =", subtract(10, 5))
    print("Multiply 10 * 5 =", multiply(10, 5))
    print("Divide 10 / 5 =", divide(10, 5))
    # This will raise an error because of division by zero
    print("Divide 10 / 0 =", divide(10, 0))

if __name__ == "__main__":
    main()
```

## Explanation

- `add(a, b)`: Returns the sum of `a` and `b`.
- `subtract(a, b)`: Returns the difference of `a` and `b`.
- `multiply(a, b)`: Returns the product of `a` and `b`.
- `divide(a, b)`: Returns the quotient of `a` divided by `b`. Raises a `ValueError` if `b` is zero.

## License

MIT License