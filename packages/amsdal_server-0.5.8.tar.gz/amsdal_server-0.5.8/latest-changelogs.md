## [v0.5.8](https://pypi.org/project/amsdal_server/0.5.8/) - 2025-08-12

### Added

- Disposition type for file downloads.
