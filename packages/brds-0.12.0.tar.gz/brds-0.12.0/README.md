# brds

[![CI](https://github.com/brahle/brds/actions/workflows/main.yml/badge.svg)](https://github.com/brahle/brds/actions/workflows/main.yml)

Bruno Rahle's Data Science library.

## Install it from PyPI

```bash
pip install brds
```

## Usage

```
Coming soon!
```

## Development

Read the [CONTRIBUTING.md](CONTRIBUTING.md) file.
