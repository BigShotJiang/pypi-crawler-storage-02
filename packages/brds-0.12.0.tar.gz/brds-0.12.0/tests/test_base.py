from brds.base import NAME
from brds import *


def test_base():
    assert NAME == "brds"
