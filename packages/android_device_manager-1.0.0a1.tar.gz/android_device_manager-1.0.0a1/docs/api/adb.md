# ADB Module

Interact with Android Debug Bridge (ADB).

::: android_device_manager.adb.client

::: android_device_manager.adb.exceptions