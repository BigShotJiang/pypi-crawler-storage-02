# Emulator Module

Emulate Android Virtual Devices (AVDs).

::: android_device_manager.emulator.EmulatorManager

::: android_device_manager.emulator.EmulatorConfiguration

::: android_device_manager.emulator.exceptions