# AndroidDevice

High-level class for managing Android devices.

::: android_device_manager.android_device.AndroidDevice

