# `AVDConfiguration` API

::: android_device_manager.avd.config