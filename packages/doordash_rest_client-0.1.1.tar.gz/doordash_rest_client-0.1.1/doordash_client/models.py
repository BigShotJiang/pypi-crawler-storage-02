"""
Simple data models (optional - you can work with dicts instead).
"""

from typing import Dict, Any

# For now, just use plain dictionaries
# Users can add their own type annotations if needed