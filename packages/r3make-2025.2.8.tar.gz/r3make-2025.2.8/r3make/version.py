YEAR:int = 2025
MINOR:int = 2
PATCH:int = 8
