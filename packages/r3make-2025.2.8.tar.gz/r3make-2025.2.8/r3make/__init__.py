""" # r3make
    | The simple CLI build tool <3
"""