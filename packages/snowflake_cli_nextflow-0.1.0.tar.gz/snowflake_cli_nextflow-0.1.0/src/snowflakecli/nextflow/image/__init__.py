# Nextflow image management module
