# AstrBot Star

`AstrBot Star` 就是插件。

在 AstrBot v4.0 版本后，AstrBot 内部将插件命名为 `star`。插件的 handler 称作 `star_handler`。