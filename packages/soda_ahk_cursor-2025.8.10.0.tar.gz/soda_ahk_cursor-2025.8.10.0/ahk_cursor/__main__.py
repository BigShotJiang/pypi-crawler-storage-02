from ahk_cursor.main import main

main()
