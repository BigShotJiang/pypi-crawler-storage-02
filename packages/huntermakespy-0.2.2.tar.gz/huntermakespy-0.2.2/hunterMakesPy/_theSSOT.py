"""Settings for this package."""
from hunterMakesPy import PackageSettings

settingsPackage = PackageSettings(identifierPackageFALLBACK="hunterMakesPy")
