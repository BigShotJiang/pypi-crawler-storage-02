"""Test modules for hunterMakesPy package.

This module contains comprehensive test suites for all major functions and features in the hunterMakesPy package. Tests can be run
independently or imported into your project.
"""
