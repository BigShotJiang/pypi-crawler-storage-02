# super_x/broadcast.py
from superbeta.utils import broadcast_shape, expand_flat, reduce_grad

# re-export para facilitar importación
__all__ = ["broadcast_shape", "expand_flat", "reduce_grad"]
