# RevDownloader

Librería Python para descarga de archivos de revistas.

## Instalación

```bash
pip install revdownloade
```
