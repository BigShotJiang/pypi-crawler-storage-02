# 🌡 Generic Temperature Converter

A lightweight Python package to convert temperatures between **Celsius**, **Fahrenheit**, and **Kelvin**.  
It works both as a **command-line tool** and as an **importable Python module**.


## 📦 Installation

pip install generic-temperature-converter



## 💻 Command-Line Usage

Once installed, you can run:

tempconv <value> <from_unit> <to_unit>


**Example:**

tempconv 100 C F


**Output:**

100.00°C = 212.00°F



## 📋 Supported Units

| Symbol | Unit Name   |
|--------|------------|
| `C`    | Celsius    |
| `F`    | Fahrenheit |
| `K`    | Kelvin     |




## 🐍 Python Module Usage

from generic_temperature_converter.converter import (
celsius_to_fahrenheit,
fahrenheit_to_celsius,
celsius_to_kelvin,
kelvin_to_celsius
)

print(celsius_to_fahrenheit(25)) # 77.0
print(fahrenheit_to_celsius(212)) # 100.0
print(celsius_to_kelvin(0)) # 273.15
print(kelvin_to_celsius(300)) # 26.85




## ✨ Features

- Supports **Celsius ↔ Fahrenheit**, **Celsius ↔ Kelvin**, and **Fahrenheit ↔ Kelvin** conversions.
- Works from both **CLI** and **Python scripts**.
- Handles floating-point rounding for clean output.



## 📄 License

This project is licensed under the **MIT License**.
