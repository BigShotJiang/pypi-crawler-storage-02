
<img src="./villa-x.png" width="400px"></img>

<img src="./fig1-lam.png" width="400px"></img>

## villa-X (wip)

Implementation of [ViLLa-X](https://arxiv.org/abs/2507.23682v1), "Enhancing Latent Action Modeling in Vision-Language-Action Models", from Tsinghua

## Citations

```bibtex
@inproceedings{Chen2025villaXEL,
    title   = {villa-X: Enhancing Latent Action Modeling in Vision-Language-Action Models},
    author  = {Xiaoyu Chen and Hangxing Wei and Pushi Zhang and Chuheng Zhang and Kaixin Wang and Yanjiang Guo and Rushuai Yang and Yucen Wang and Xinquan Xiao and Li Zhao and Jianyu Chen and Jiang Bian},
    year  = {2025},
    url   = {https://api.semanticscholar.org/CorpusID:280401068}
}
```
