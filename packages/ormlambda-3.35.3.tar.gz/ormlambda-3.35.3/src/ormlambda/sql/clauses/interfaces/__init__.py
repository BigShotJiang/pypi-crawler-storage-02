from .IDelete import IDelete  # noqa: F401
from .IInsert import IInsert  # noqa: F401
from .ISelect import ISelect  # noqa: F401
from .IUpdate import IUpdate  # noqa: F401
from .IUpsert import IUpsert  # noqa: F401
