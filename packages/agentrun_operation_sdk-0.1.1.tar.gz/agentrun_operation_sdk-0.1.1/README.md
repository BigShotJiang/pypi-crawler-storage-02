# hw-agentrun-sdk-python



## Getting started

### Start server
```sh
python agentrun_wrapper_test.py
```

### Start client
```sh
python cli.py
```

Input to test:
```sh
Example inputs:
  What is the weather now?
--------------------------------------------------

Input: What is the weather now
Response:
"The current weather is sunny."
```