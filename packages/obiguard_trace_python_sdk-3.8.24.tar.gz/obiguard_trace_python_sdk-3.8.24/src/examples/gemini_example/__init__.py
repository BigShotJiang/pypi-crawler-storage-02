from .main import basic


class GeminiRunner:
    def run(self):
        basic()
