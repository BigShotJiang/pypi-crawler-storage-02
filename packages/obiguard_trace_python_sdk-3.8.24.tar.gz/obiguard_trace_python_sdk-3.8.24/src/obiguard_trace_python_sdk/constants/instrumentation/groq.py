APIS = {
    "CHAT_COMPLETION": {
        "METHOD": "groq.chat.completions.create",
        "ENDPOINT": "/chat/completions",
    },
}
