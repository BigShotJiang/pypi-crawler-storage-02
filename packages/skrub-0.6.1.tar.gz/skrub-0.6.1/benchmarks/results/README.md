# Results

## Format

Results are saved with the format ``<name>-<YYYYMMDD>.parquet``.
