
===========
Development
===========

While `skrub` is still being born, we believe in openness and community
development from the start. Join us in building a great package to
facilitate learning on databases.

.. include:: includes/big_toc_css.rst

.. toctree::

    vision
    about
    CONTRIBUTING
    RELEASE_PROCESS
