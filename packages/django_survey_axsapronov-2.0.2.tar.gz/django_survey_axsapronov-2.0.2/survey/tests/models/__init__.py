from survey.tests.models.base_model_test import BaseModelTest

__all__ = ["BaseModelTest"]
