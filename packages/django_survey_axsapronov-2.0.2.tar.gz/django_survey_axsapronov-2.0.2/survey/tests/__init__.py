# Тесты для django-survey
# Тесты для django-survey

from survey.tests.base_test import BaseTest

__all__ = ["BaseTest"]
