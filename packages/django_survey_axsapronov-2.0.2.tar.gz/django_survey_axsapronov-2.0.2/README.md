# Personal FORK Django survey

A django survey app
