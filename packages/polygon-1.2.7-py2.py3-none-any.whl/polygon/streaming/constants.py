STREAM_CLUSTER_PREFIX_MAP = {"options": "O:", "forex": "C:", "crypto": "X:", "indices": "I:"}
