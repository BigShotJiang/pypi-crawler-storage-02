HTTPX Transports configured for Edgar SEC

[![PyPI Version](https://badge.fury.io/py/edgar_httpx.svg)](https://pypi.python.org/pypi/edgar_httpx)

[![BuildRelease](https://github.com/paultiq/edgar_httpx/actions/workflows/build_deploy.yml/badge.svg)](https://github.com/paultiq/edgar_httpx/actions/workflows/build_deploy.yml)
[![Tests](https://github.com/paultiq/edgar_httpx/actions/workflows/test.yml/badge.svg)](https://github.com/paultiq/edgar_httpx/actions/workflows/test.yml)
[![Coverage badge](https://github.com/paultiq/edgar_httpx/raw/python-coverage-comment-action-data/badge.svg)](https://github.com/paultiq/edgar_httpx/tree/python-coverage-comment-action-data)
