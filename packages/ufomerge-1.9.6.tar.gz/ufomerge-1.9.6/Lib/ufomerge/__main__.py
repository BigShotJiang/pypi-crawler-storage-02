from ufomerge.cli import main as real_main

if __name__ == "__main__":
    real_main()
