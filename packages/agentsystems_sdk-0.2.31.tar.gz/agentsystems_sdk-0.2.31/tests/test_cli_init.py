"""Tests for the init command with local scaffold."""

from unittest.mock import patch, MagicMock

import pytest
import typer

from agentsystems_sdk.commands.init import init_command


class TestInitCommand:
    """Tests for the init command with local scaffold."""

    @patch("agentsystems_sdk.commands.init.get_required_images")
    @patch("agentsystems_sdk.commands.init.docker_login_if_needed")
    @patch("agentsystems_sdk.commands.init.ensure_docker_installed")
    @patch("agentsystems_sdk.commands.init.set_key")
    @patch("agentsystems_sdk.commands.init.shutil.copy")
    @patch("agentsystems_sdk.commands.init.shutil.copytree")
    @patch("agentsystems_sdk.commands.init.run_command")
    @patch("agentsystems_sdk.commands.init.typer.prompt")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_interactive_mode(
        self,
        mock_stdin,
        mock_prompt,
        mock_run_command,
        mock_copytree,
        mock_shutil_copy,
        mock_set_key,
        mock_ensure_docker,
        mock_docker_login,
        mock_get_images,
        tmp_path,
    ):
        """Test init command in interactive mode with prompts."""
        # Setup
        mock_stdin.isatty.return_value = True  # Interactive mode

        # Mock user inputs via prompt
        mock_prompt.side_effect = [
            "test-project",  # Directory prompt
            "TestOrg",  # Organization name
            "admin@test.com",  # Email
            "password123",  # Password
            "docker-token-123",  # Docker token
        ]

        # Mock required images
        mock_get_images.return_value = [
            "agentsystems/agent-control-plane:latest",
            "langfuse/langfuse:latest",
        ]

        # Execute
        init_command(
            project_dir=None,  # Will prompt for directory
            docker_token=None,
        )

        # Verify scaffold was copied
        mock_copytree.assert_called_once()
        assert "deployments_scaffold" in str(mock_copytree.call_args[0][0])

        # Verify Docker was checked
        mock_ensure_docker.assert_called_once()

        # Verify Docker login
        mock_docker_login.assert_called_once_with("docker-token-123")

        # Verify images were pulled
        assert any(
            "docker" in str(call) and "pull" in str(call)
            for call in mock_run_command.call_args_list
        )

    @patch("agentsystems_sdk.commands.init.get_required_images")
    @patch("agentsystems_sdk.commands.init.docker_login_if_needed")
    @patch("agentsystems_sdk.commands.init.ensure_docker_installed")
    @patch("agentsystems_sdk.commands.init.set_key")
    @patch("agentsystems_sdk.commands.init.shutil.copy")
    @patch("agentsystems_sdk.commands.init.shutil.copytree")
    @patch("agentsystems_sdk.commands.init.run_command")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_non_interactive_mode(
        self,
        mock_stdin,
        mock_run_command,
        mock_copytree,
        mock_shutil_copy,
        mock_set_key,
        mock_ensure_docker,
        mock_docker_login,
        mock_get_images,
        tmp_path,
    ):
        """Test init command in non-interactive mode."""
        # Setup
        mock_stdin.isatty.return_value = False  # Non-interactive mode
        project_dir = tmp_path / "test-project"

        # Mock required images
        mock_get_images.return_value = ["agentsystems/agent-control-plane:latest"]

        # Execute
        init_command(
            project_dir=project_dir,
            docker_token="docker-token-123",
        )

        # Verify scaffold was copied
        mock_copytree.assert_called_once()
        assert "deployments_scaffold" in str(mock_copytree.call_args[0][0])
        assert str(project_dir) in str(mock_copytree.call_args[0][1])

    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_missing_project_dir_non_interactive(self, mock_stdin):
        """Test init command fails when project_dir missing in non-interactive mode."""
        mock_stdin.isatty.return_value = False

        with pytest.raises(typer.Exit) as exc_info:
            init_command(project_dir=None)

        assert exc_info.value.exit_code == 1

    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_non_empty_directory(self, mock_stdin, tmp_path):
        """Test init command fails when target directory is not empty."""
        mock_stdin.isatty.return_value = False
        project_dir = tmp_path / "existing-project"
        project_dir.mkdir()
        (project_dir / "existing-file.txt").write_text("content")

        with pytest.raises(typer.Exit) as exc_info:
            init_command(project_dir=project_dir)

        assert exc_info.value.exit_code == 1

    @patch("agentsystems_sdk.commands.init.pathlib.Path")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_scaffold_not_found(self, mock_stdin, mock_path, tmp_path):
        """Test init command fails when scaffold directory is not found."""
        mock_stdin.isatty.return_value = False
        project_dir = tmp_path / "test-project"

        # Mock scaffold directory not existing
        mock_scaffold = MagicMock()
        mock_scaffold.exists.return_value = False
        mock_path.return_value.__truediv__.return_value = mock_scaffold

        with pytest.raises(typer.Exit) as exc_info:
            init_command(project_dir=project_dir)

        assert exc_info.value.exit_code == 1

    @patch("agentsystems_sdk.commands.init.get_required_images")
    @patch("agentsystems_sdk.commands.init.ensure_docker_installed")
    @patch("agentsystems_sdk.commands.init.set_key")
    @patch("agentsystems_sdk.commands.init.shutil.copytree")
    @patch("agentsystems_sdk.commands.init.run_command")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_env_file_creation(
        self,
        mock_stdin,
        mock_run_command,
        mock_copytree,
        mock_set_key,
        mock_ensure_docker,
        mock_get_images,
        tmp_path,
    ):
        """Test init command creates .env file from .env.example."""
        # Setup
        mock_stdin.isatty.return_value = False
        project_dir = tmp_path / "test-project"

        # Mock copytree to create directory with .env.example
        def create_project_structure(src, dst):
            dst.mkdir(parents=True)
            (dst / ".env.example").write_text("# Example env file")

        mock_copytree.side_effect = create_project_structure
        mock_get_images.return_value = []

        # Execute
        init_command(
            project_dir=project_dir,
            docker_token=None,
        )

        # Verify set_key was called to populate the .env file
        assert mock_set_key.call_count > 0

        # Check that Langfuse variables were set
        langfuse_vars = [
            "LANGFUSE_INIT_ORG_ID",
            "LANGFUSE_INIT_ORG_NAME",
            "LANGFUSE_INIT_PROJECT_ID",
            "LANGFUSE_INIT_PROJECT_NAME",
            "LANGFUSE_INIT_USER_NAME",
            "LANGFUSE_INIT_USER_EMAIL",
            "LANGFUSE_INIT_USER_PASSWORD",
            "LANGFUSE_INIT_PROJECT_PUBLIC_KEY",
            "LANGFUSE_INIT_PROJECT_SECRET_KEY",
            "LANGFUSE_HOST",
            "LANGFUSE_PUBLIC_KEY",
            "LANGFUSE_SECRET_KEY",
        ]

        set_keys = [call[0][1] for call in mock_set_key.call_args_list]
        for var in langfuse_vars:
            assert var in set_keys

    @patch("agentsystems_sdk.commands.init.get_required_images")
    @patch("agentsystems_sdk.commands.init.docker_login_if_needed")
    @patch("agentsystems_sdk.commands.init.ensure_docker_installed")
    @patch("agentsystems_sdk.commands.init.set_key")
    @patch("agentsystems_sdk.commands.init.shutil.copytree")
    @patch("agentsystems_sdk.commands.init.run_command")
    @patch("agentsystems_sdk.commands.init.typer.prompt")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_docker_pull_failure_retry(
        self,
        mock_stdin,
        mock_prompt,
        mock_run_command,
        mock_copytree,
        mock_set_key,
        mock_ensure_docker,
        mock_docker_login,
        mock_get_images,
        tmp_path,
    ):
        """Test init command retries docker pull with token on failure."""
        # Setup
        mock_stdin.isatty.return_value = True
        project_dir = tmp_path / "test-project"

        # Mock user inputs
        mock_prompt.side_effect = [
            str(project_dir),  # Directory prompt
            "TestOrg",  # Organization name
            "admin@test.com",  # Email
            "password123",  # Password
            "",  # No initial docker token
            "docker-token-retry",  # Docker token prompt after pull failure
        ]

        # Mock required images
        mock_get_images.return_value = ["private/image:latest"]

        # Mock copytree to create directory
        def create_project_structure(src, dst):
            dst.mkdir(parents=True)
            (dst / ".env.example").write_text("")

        mock_copytree.side_effect = create_project_structure

        # Mock run_command to fail on first docker pull, succeed on retry
        pull_attempts = 0

        def mock_run_side_effect(cmd):
            nonlocal pull_attempts
            if "docker" in cmd and "pull" in cmd:
                pull_attempts += 1
                if pull_attempts == 1:
                    raise typer.Exit(code=1)
                # Success on second attempt

        mock_run_command.side_effect = mock_run_side_effect

        # Execute
        init_command(
            project_dir=None,
            docker_token=None,  # No initial docker token
        )

        # Verify docker login was called after failure
        mock_docker_login.assert_called_with("docker-token-retry")

        # Verify pull was attempted twice
        assert pull_attempts == 2

    @patch("agentsystems_sdk.commands.init.get_required_images")
    @patch("agentsystems_sdk.commands.init.ensure_docker_installed")
    @patch("agentsystems_sdk.commands.init.set_key")
    @patch("agentsystems_sdk.commands.init.shutil.copytree")
    @patch("agentsystems_sdk.commands.init.run_command")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_no_images_to_pull(
        self,
        mock_stdin,
        mock_run_command,
        mock_copytree,
        mock_set_key,
        mock_ensure_docker,
        mock_get_images,
        tmp_path,
    ):
        """Test init command handles case with no images to pull."""
        # Setup
        mock_stdin.isatty.return_value = False
        project_dir = tmp_path / "test-project"

        # Mock copytree to create directory
        def create_project_structure(src, dst):
            dst.mkdir(parents=True)

        mock_copytree.side_effect = create_project_structure
        mock_get_images.return_value = []  # No images

        # Execute
        init_command(
            project_dir=project_dir,
            docker_token=None,
        )

        # Verify no docker pull commands were executed
        assert not any(
            "docker" in str(call) and "pull" in str(call)
            for call in mock_run_command.call_args_list
        )

    @patch("agentsystems_sdk.commands.init.typer.prompt")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_email_validation(
        self,
        mock_stdin,
        mock_prompt,
        tmp_path,
    ):
        """Test init command validates email in interactive mode."""
        # Setup
        mock_stdin.isatty.return_value = True

        # Mock user inputs - invalid email first, then valid
        mock_prompt.side_effect = [
            str(tmp_path / "test-project"),  # Directory
            "TestOrg",  # Organization name
            "invalid-email",  # Invalid email
            "admin@test.com",  # Valid email
            "password123",  # Password
            "",  # Docker token
        ]

        # Mock other dependencies to avoid actual execution
        with patch("agentsystems_sdk.commands.init.shutil.copytree"):
            with patch("agentsystems_sdk.commands.init.ensure_docker_installed"):
                with patch("agentsystems_sdk.commands.init.docker_login_if_needed"):
                    with patch(
                        "agentsystems_sdk.commands.init.get_required_images",
                        return_value=[],
                    ):
                        with patch("agentsystems_sdk.commands.init.set_key"):
                            # Execute
                            init_command(project_dir=None)

                            # Verify email prompt was called twice (invalid, then valid)
                            email_calls = [
                                call
                                for call in mock_prompt.call_args_list
                                if "email" in str(call).lower()
                            ]
                            assert len(email_calls) >= 2

    @patch("agentsystems_sdk.commands.init.typer.prompt")
    @patch("agentsystems_sdk.commands.init.sys.stdin")
    def test_init_command_password_validation(
        self,
        mock_stdin,
        mock_prompt,
        tmp_path,
    ):
        """Test init command validates password length in interactive mode."""
        # Setup
        mock_stdin.isatty.return_value = True

        # Mock user inputs - short password first, then valid
        mock_prompt.side_effect = [
            str(tmp_path / "test-project"),  # Directory
            "TestOrg",  # Organization name
            "admin@test.com",  # Email
            "short",  # Password too short
            "password123",  # Valid password
            "",  # Docker token
        ]

        # Mock other dependencies to avoid actual execution
        with patch("agentsystems_sdk.commands.init.shutil.copytree"):
            with patch("agentsystems_sdk.commands.init.ensure_docker_installed"):
                with patch("agentsystems_sdk.commands.init.docker_login_if_needed"):
                    with patch(
                        "agentsystems_sdk.commands.init.get_required_images",
                        return_value=[],
                    ):
                        with patch("agentsystems_sdk.commands.init.set_key"):
                            # Execute
                            init_command(project_dir=None)

                            # Verify password prompt was called twice (short, then valid)
                            password_calls = [
                                call
                                for call in mock_prompt.call_args_list
                                if "password" in str(call).lower()
                            ]
                            assert len(password_calls) >= 2
