from .main import prototype_query

__all__ = ["prototype_query"]
__version__ = "1.1.0"
