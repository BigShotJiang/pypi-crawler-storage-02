class TripCost:
    def __init__(self, trip_no, vehicle_id, cost, sequence):
        self.trip_no = trip_no
        self.vehicle_id = vehicle_id
        self.cost = cost
        self.sequence = sequence
