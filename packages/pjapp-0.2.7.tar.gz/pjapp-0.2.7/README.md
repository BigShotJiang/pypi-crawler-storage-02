# App for practicing Japanese

## Known issues:

En la versión de teléfono parece no guardarse el score (confirmado, no se guarda) (ya se guarda, voy a ver si se repite) si se repite, no está revisando como se debe el valor más bajo

Crear cache con el csv de descarga permanente

## Testing solution:

En la versión de teléfono parece no guardarse el score (confirmado, no se guarda) (ya se guarda, voy a ver si se repite) si se repite, no está revisando como se debe el valor más bajo