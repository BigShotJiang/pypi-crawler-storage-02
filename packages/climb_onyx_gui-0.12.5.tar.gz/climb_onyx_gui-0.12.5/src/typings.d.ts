declare module '*.svg' {
  const script: string;
  export default script;
}
