from .impl import Source

protocol_lang = Source[object]("protocolLang")
yaml = Source[str]("yaml")
json = Source[str]("json")
