"""Solo MCP 工具模块"""
