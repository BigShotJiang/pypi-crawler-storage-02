# colbertfinance

Pequeña librería pedagógica para mostrar **paso a paso** el modelo de
portafolio de Markowitz (media-varianza).

Cada función calcula un paso y, además, guarda automáticamente un
Excel con los resultados para que los alumnos verifiquen los números.
