- Make the extended view to add the delivery date to the header of the form configurable
  with config settings.
