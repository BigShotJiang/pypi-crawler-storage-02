<!-- Central link variables; use with mkdocs-macros-plugin as {{ WEB_BASE }} etc. -->

[api_keys]: {{ WEB_BASE }}/account/apikeys
[ssh_keys]: {{ WEB_BASE }}/account/ssh-keys
[quotas_instances]: {{ WEB_BASE }}/instances/quotas
[quotas_storage]: {{ WEB_BASE }}/storage/quotas
[spot_graphs]: {{ WEB_BASE }}/instances/spot
[status]: {{ STATUS_BASE }}

