from .build import Builder
from .voice_chat_player import VoiceChatPlayer

class Advanced(
    Builder,
    VoiceChatPlayer,
):
    pass