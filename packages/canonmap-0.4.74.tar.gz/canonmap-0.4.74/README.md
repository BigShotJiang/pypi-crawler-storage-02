CanonMap
========

CanonMap is a Python library for data matching and canonicalization with multiple database connector support. It uses a `src/` layout and publishes the package `canonmap`.

Quick start
-----------

```python
from canonmap import MappingPipeline, EntityMappingRequest
```

For more information, see the repository homepage.


