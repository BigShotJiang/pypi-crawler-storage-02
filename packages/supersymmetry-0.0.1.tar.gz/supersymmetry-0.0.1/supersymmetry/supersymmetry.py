class Supersymmetry:

    def __init__(self) -> None:
        pass

    def search(self, query: str) -> str:
        return "search results"
