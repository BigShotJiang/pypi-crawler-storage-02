from __future__ import annotations

from .duplication_reverter import DuplicationReverter

__all__ = ("DuplicationReverter",)
