
# THIS FILE IS GENERATED FROM SigProfilerAssignment SETUP.PY
short_version = '0.2.5'
version = '0.2.5'
Update = 'v0.2.5:  Support for generating decomposition plots for custom signature sets.'

    