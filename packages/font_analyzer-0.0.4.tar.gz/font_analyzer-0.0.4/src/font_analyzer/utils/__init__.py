"""
Utility functions and helpers.
"""
