"""
Core functionality for font detection and analysis.
"""
