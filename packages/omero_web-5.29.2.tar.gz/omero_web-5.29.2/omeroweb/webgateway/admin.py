#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# webgateway/admin.py - django application admin view
#
# Copyright (c) 2008, 2009 Glencoe Software, Inc. All rights reserved.
#
# This software is distributed under the terms described by the LICENCE file
# you can find at the root of the distribution bundle, which states you are
# free to use it only for non commercial purposes.
# If the file is missing please request a copy by contacting
# jason@glencoesoftware.com.
#
# Author: Carlos Neves <carlos(at)glencoesoftware.com>

# from models import StoredConnection
# from django.contrib import admin
# from django.utils.translation import gettext_lazy as _

# class StoredConnectionOptions(admin.ModelAdmin):
#  list_display = ('base_path', 'config_file', 'username', 'failcount')

# admin.site.register(StoredConnection, StoredConnectionOptions)
