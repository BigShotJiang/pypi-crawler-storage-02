__version__ = "0.8.1"

from jupytergis_lab import GISDocument, explore  # noqa
