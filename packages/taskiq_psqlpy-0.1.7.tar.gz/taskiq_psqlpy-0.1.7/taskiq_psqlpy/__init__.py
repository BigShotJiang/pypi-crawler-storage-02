from taskiq_psqlpy.result_backend import PSQLPyResultBackend

__all__ = [
    "PSQLPyResultBackend",
]
