riggery
=======

'Riggery' is an object-oriented rigging codebase for Maya in the spirit of PyMEL, but written from the ground-up for
fast maths rigging  using operator overloading.