from ..datatypes import __pool__


class Data:

    __apitype__ = None
    __pool__ = __pool__
    __shape__ = None