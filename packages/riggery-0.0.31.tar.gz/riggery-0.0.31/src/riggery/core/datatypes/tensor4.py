from ..datatypes import __pool__


class Tensor4(__pool__['Tensor']):

    __shape__ = 4