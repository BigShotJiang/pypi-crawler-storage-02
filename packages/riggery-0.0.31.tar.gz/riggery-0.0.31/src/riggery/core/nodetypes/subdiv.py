from ..nodetypes import __pool__


class Subdiv(__pool__['SurfaceShape']):

    ...