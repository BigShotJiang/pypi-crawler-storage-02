from ..nodetypes import __pool__ as nodes


Shape = nodes['Shape']


class GeometryShape(nodes['Shape']):

    ...