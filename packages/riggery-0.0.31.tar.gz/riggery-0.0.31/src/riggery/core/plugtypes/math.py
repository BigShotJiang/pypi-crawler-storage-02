from ..plugtypes import __pool__ as plugs


class Math(plugs['Attribute']):

    __shape__ = None