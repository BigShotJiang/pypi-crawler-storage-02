"""General utilities package."""
from .functions import short
from .numbers import floatrange
from .iterables import expand_tuples_lists, crop_overlaps