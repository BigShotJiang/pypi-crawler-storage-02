
python rest_client.py &
python rest_server.py &