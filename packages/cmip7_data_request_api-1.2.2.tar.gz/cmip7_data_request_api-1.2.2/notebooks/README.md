A collection of notebook examples using the API library. 
