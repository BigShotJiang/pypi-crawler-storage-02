# -*- coding: utf-8 -*-
#1.安装依赖包
```cmd
pip install chinaunicom-ai
```

#2.dify_toolbox：dify调用方法

#3.asr_toolbox：paraformer与smallsensorvoice调用方法

#4.container_toolbox: 预置多容器动态创建与销毁
