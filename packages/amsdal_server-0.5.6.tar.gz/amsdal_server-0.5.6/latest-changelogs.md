## [v0.5.6](https://pypi.org/project/amsdal_server/0.5.6/) - 2025-08-05

### Changes

- Improvements for slack notifications middleware
