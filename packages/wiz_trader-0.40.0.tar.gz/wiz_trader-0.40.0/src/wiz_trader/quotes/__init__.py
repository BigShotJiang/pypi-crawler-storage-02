"""Quotes module for real-time market data."""

from .client import QuotesClient

__all__ = ["QuotesClient"]