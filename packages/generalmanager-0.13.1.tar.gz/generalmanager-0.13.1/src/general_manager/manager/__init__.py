from .generalManager import GeneralManager
from .input import Input
from ..api.property import graphQlProperty
