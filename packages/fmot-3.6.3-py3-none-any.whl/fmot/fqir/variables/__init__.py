from .variable_base import VariableBase, TensorSignature
from .tensor_proto import TensorProto
