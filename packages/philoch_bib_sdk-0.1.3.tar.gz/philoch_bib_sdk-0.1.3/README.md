# Philosophie.ch Bibliography SDK

This repository contains the standard development kit for the bibliography project of the [Philosophie.ch](https://philosophie.ch) association.
