"""Generic Installation tools."""

from lightning_utilities.install.requirements import Requirement, load_requirements

__all__ = ["Requirement", "load_requirements"]
