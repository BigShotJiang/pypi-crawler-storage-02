import threading

COMPILE_LOCK = threading.Lock()
