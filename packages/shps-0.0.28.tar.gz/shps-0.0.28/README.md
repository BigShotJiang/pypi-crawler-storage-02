# shps

<!--

Shape functions, clean and simple.

frame
    mesh
    state
    shape
    bases
    gauss
    nodes

rotor

rigid

plane
    shape
solid

-->

