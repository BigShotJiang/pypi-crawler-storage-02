"""RSS TUI - A terminal RSS reader built with Textual."""

__version__ = "0.1.0"
__author__ = "yehorscode"
__description__ = "RSS reader TUI application"
