from .main import accurate_wait

__all__ = ['accurate_wait']
