class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '1.1.0'
    git_sha = 'd8089662268f5c146920e765ccc86afdda6acf1e'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
