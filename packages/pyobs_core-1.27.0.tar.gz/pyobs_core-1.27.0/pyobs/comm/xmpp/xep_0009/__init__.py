from slixmpp.plugins.base import register_plugin
from .rpc import XEP_0009

register_plugin(XEP_0009)
