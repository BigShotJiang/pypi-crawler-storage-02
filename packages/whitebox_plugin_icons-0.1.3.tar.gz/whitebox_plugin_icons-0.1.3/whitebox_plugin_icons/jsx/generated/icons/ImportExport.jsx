const ImportExport = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={25} height={25} {...props}>
    <path d="m9.146 3.855-2.79 2.79c-.32.31-.1.85.35.85h1.79v6.01c0 .55.45 1 1 1s1-.45 1-1v-6.01h1.79c.45 0 .67-.54.35-.85l-2.79-2.79a.5.5 0 0 0-.7 0m7.35 13.66v-6.01c0-.55-.45-1-1-1s-1 .45-1 1v6.01h-1.79c-.45 0-.67.54-.35.85l2.79 2.78c.2.19.51.19.71 0l2.79-2.78c.32-.31.09-.85-.35-.85z" />
  </svg>
);
export { ImportExport };
export default ImportExport;

