# ingenia

# build and publish python SDK to pypi.org

```shell
poetry build
poetry config pypi-token.pypi $YOUR_PYPI_API_TOKEN
poetry publish
```
