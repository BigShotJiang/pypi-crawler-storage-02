"""Version information for xAgent package."""

__version__ = "0.1.15"
__author__ = "xAgent Team"
__email__ = "zhangjun310@live.com"
__description__ = "Multi-Modal AI Agent System"
