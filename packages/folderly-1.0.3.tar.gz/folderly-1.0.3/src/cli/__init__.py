"""
Command Line Interface for Folderly
Contains CLI functionality and user interactions.
"""

# This file makes the cli directory a Python package
# Import functions as needed in other files 