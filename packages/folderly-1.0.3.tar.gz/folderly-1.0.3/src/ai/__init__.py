"""
AI Integration for Folderly
Contains AI-powered features and function schemas.
"""

# This file makes the ai directory a Python package
# Import functions as needed in other files 