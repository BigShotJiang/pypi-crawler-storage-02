"""
Core functionality for Folderly
Contains main file operations and search functionality.
"""

# This file makes the core directory a Python package
# Import functions as needed in other files 