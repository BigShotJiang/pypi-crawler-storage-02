default_params = {
    "thinking":"default",
    "chunk_size": 3000,
    "concurrent": 30,
    "temperature": 0.7,
}