from platform import python_version

from django import get_version

DJANGO_VERSION = get_version()
PYTHON_VERSION = python_version()
