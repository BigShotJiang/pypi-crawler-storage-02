# Planet Simulation
A lib that simplify the process of the simulation of a planet
## Install
You can install this lib in (https://pypi.org/project/planet_simulator/)
```bash
pip install planet_simulator