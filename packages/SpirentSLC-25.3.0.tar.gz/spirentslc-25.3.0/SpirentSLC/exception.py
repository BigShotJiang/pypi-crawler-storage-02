class SLCError(Exception):
    """General exception indicating various types of SLC errors."""
    pass