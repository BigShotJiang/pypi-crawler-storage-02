"""This module contains an implementation of iTest
   yamlGet, yamlSet, yamlAdd, yamlDelete operations.
"""
