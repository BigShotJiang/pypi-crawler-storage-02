import os.path

resouces_path = os.path.dirname(os.path.abspath(__file__))
repo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'itars')
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
