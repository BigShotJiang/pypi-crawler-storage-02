# The Red Teaming module is now in DeepTeam for deepeval-v3.0 onwards

# Please go to https://github.com/confident-ai/deepteam to get the latest version.
