from enum import Enum


class TruthfulQAMode(Enum):
    MC1 = "mc1"
    MC2 = "mc2"
