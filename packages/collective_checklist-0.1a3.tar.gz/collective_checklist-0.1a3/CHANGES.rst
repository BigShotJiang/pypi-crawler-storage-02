Changelog
=========


0.1a3 (2025-08-08)
------------------

- only use picocss colors, to mess with bootstrap and websites fonts
  [MrTango]


0.1a2 (2024-08-30)
------------------

- depend on plone.app.z3cform >=4.4.1


0.1a1 (2024-08-30)
------------------

- Initial release.
  [MrTango]
