====================
collective.checklist
====================

User documentation
