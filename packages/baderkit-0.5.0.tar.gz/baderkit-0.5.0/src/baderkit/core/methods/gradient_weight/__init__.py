# -*- coding: utf-8 -*-

from .gradient_weight_method import GradientWeightMethod
