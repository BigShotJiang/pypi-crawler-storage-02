# -*- coding: utf-8 -*-

from .weight_method import WeightMethod
