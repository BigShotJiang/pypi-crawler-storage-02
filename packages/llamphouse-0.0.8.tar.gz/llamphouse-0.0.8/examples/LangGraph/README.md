Small example on how you can use LangGraph with LLAMPHouse.

This example includes a chatbot that can answer questions about the current temperature anywhere in the world.

## Installation

1. Clone the repo
1. Install the python [requirements](requirements.txt)
1. Run the [server](server.py)
1. Run the [client](client.py) and start asking questions about the temperature.