dataframely.collection module
=============================

.. automodule:: dataframely.collection
   :members:
   :show-inheritance:
   :undoc-members:
