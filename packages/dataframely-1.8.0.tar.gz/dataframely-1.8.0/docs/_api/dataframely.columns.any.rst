dataframely.columns.any module
==============================

.. automodule:: dataframely.columns.any
   :members:
   :show-inheritance:
   :undoc-members:
