dataframely.config module
=========================

.. automodule:: dataframely.config
   :members:
   :show-inheritance:
   :undoc-members:
