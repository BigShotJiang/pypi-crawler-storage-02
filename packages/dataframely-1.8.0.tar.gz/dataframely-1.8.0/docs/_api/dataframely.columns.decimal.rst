dataframely.columns.decimal module
==================================

.. automodule:: dataframely.columns.decimal
   :members:
   :show-inheritance:
   :undoc-members:
