from .test_agents.python.main import agent_fn as random_agent
all_agents = {
    "random_agent": random_agent,
}