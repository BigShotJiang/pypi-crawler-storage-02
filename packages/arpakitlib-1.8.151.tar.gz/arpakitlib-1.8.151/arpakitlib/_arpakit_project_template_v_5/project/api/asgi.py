from project.api.create_api_app import create_api_app

app = create_api_app()
