# Ruff

```
uv run ruff format
```

# Pytest with coverage

```
uv run pytest --cov=strarr --cov-report=html --cov-report=term-missing
```
