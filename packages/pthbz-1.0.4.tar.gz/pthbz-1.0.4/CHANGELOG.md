# Changelog

## 1.0.0 — 2025-08-11
- Initial release: sync and async clients, CLI, URL validation, QR utilities.

## 1.0.1 — 2025-08-11
- Add test

## 1.0.2 — 2025-08-11
- metadata/packaging cleanup

## 1.0.3 — 2025-08-11
- metadata/packaging cleanup

## 1.0.4 — 2025-08-11
- metadata/packaging cleanup