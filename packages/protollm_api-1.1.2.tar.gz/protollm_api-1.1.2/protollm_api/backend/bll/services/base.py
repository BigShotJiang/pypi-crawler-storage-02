from abc import ABC


class BaseBLLService(ABC):
    pass