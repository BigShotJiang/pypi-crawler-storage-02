#!/usr/bin/env python3
"""
Setup script for panDecay package.
"""

from setuptools import setup

# Use setuptools configuration from pyproject.toml
setup()