# Aegis Client

## Local Development

1. Install dependencies:

```bash
npm install
```

2. Start the development server:

```bash
npm run dev
```

## Building

Build the Client:

```bash
npm run build
```

## Deployment

Check the main readme to see how to deploy.
