"""
Main module for the DMPS package.
"""

def hello_world():
    """
    A simple hello world function.
    
    Returns:
        str: A greeting message.
    """
    return "Hello, World!"

if __name__ == "__main__":
    print(hello_world())
