# maintained for backward compatibility
from toyaikit.llm import OpenAIClient

