> [!NOTE]
> *BabelDOC サポート言語* ページに移動するには、[こちらをクリック](https://funstory-ai.github.io/BabelDOC/supported_languages/)してください。そこに記載されている情報は pdf2zh にも適用されます。

<div align="right"> 
<h6><small>このページの一部のコンテンツはGPTによって翻訳されており、エラーが含まれている可能性があります。</small></h6>