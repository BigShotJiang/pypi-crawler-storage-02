import gitops_server.settings

gitops_server.settings.CLUSTER_NAME = "test-cluster"
