## Aliyun ROS SAS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as SAS from '@alicloud/ros-cdk-sas';
```
