import os
from typing import Union

PathLike = Union[os.PathLike[str], str]
