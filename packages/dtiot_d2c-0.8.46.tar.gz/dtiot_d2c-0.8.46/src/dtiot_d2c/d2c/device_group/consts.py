
# Device group container definition     
DEVICE_GROUP_CND = "com.telekom.iot.orchestrator.deviceGroup"

# Description label name
DESCRIPTION_LABEL_NAME = "description"

