from dtiot_d2c.d2c.device.device import Device
from dtiot_d2c.d2c.device.message import Message
