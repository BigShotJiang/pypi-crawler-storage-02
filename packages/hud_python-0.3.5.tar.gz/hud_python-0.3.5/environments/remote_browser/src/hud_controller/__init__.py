"""HUD Remote Browser Controller - Manages remote browser environments via MCP."""

__version__ = "0.1.0"
