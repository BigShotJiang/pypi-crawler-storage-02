"""HUD Controller - Manages browser environment and MCP tools."""

__version__ = "0.1.0"
