"""Tests for MCP Agent module."""
