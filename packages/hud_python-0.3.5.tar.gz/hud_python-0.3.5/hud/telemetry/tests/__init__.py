# Tests for hud.telemetry module
