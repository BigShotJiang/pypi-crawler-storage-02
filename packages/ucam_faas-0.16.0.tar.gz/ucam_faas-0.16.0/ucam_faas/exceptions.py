class UCAMFAASException(Exception):
    pass


class UCAMFAASCouldNotProcess(UCAMFAASException):
    pass


class UCAMFAASCouldNotLoadTarget(UCAMFAASException):
    pass
