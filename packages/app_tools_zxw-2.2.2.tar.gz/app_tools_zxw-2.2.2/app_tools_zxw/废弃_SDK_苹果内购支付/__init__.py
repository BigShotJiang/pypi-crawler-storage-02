"""
苹果内购支付验证模块
"""
from .支付服务_async import 苹果内购支付服务, ApplePaymentResult

__all__ = ["苹果内购支付服务", "ApplePaymentResult"] 