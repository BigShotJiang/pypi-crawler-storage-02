from . import ai


def vibehowmanyrs(text: str) -> int:
    return ai.vibehowmanyrs(text)