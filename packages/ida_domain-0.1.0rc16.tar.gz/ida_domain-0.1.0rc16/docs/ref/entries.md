# `Entries`

::: ida_domain.entries
