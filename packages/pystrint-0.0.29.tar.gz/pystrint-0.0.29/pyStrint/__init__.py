"""Top-level package for StrInt."""

__author__ = """WANG Jingwan"""
__email__ = 'wanwang6-c@my.cityu.edu.hk'
__version__ = '0.0.20'