Advanced Tutorials
==================

This tutorial covers several features that are not covered in the :doc:`first tutorial <tutorial>`.

.. toctree:: 
    :maxdepth: 1

    advanced-tutorials/forced-transitions
    advanced-tutorials/general-cost
    advanced-tutorials/transition-dominance
