# Mister Webhooks Python SDK

Mister Webhooks is a service to help you consume webhook events without having to host your own webhook-receiver service.

## API Documentation

API documentation is [on Github](https://mister-webhooks.github.io/mister-webhooks-client/docs/python/).
