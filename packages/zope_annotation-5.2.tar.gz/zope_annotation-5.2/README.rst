``zope.annotation`` README
==========================

.. image:: https://img.shields.io/pypi/v/zope.annotation.svg
    :target: https://pypi.python.org/pypi/zope.annotation/
    :alt: Latest Version

.. image:: https://github.com/zopefoundation/zope.annotation/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.annotation/actions/workflows/tests.yml

.. image:: https://readthedocs.org/projects/zopeannotation/badge/?version=latest
        :target: http://zopeannotation.readthedocs.org/en/latest/
        :alt: Documentation Status

This package provides a mechanism to store additional information about
objects without need to modify object class.
