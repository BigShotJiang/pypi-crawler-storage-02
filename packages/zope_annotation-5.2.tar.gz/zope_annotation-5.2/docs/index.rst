:mod:`zope.annotation`
======================

.. toctree::
   :maxdepth: 2

   narrative
   api
   hacking
