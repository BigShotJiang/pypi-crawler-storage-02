"""Copyright (c) 2023 Henry Schreiner. All rights reserved.

validate-pyproject-schema-store: A plugin set for validate-pyproject and schema-store.
"""

from __future__ import annotations
