"""Version information for malwi."""

__version__ = "0.0.21"
