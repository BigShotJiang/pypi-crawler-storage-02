from wexample_wex_core.workdir.project_workdir import ProjectWorkdir


class FrameworkPackageWorkdir(ProjectWorkdir):
    pass
