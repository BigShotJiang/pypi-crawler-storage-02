from wexample_wex_core.common.workdir import Workdir


class FrameworkPackageSuiteWorkdir(Workdir):
    pass
