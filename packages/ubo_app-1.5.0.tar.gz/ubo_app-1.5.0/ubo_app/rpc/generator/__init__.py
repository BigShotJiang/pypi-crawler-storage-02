"""Generate proto files from actions and events defined in Python files."""
