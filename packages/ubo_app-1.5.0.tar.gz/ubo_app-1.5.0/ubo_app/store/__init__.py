"""Contains the main classes and functions for the store."""
