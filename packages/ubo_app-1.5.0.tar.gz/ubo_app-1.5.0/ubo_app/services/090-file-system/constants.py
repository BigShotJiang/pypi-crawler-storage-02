"""Constants for the file system application."""

SELECTOR_APPLICATION_ID = 'file-system:select:{id}'
