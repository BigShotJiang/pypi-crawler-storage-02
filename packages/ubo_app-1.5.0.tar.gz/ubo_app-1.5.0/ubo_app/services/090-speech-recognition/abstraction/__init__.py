"""Abstract base classes for speech recognition service."""
