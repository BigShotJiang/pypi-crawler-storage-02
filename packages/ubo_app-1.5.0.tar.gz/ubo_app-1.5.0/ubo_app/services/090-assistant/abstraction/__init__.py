"""Abstract base classes for assistant service."""
