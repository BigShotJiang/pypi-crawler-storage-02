# ruff: noqa: D100, D101, D102, D103, D104, D107
