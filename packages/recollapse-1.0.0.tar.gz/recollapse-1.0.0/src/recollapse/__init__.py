import warnings

from .core import Recollapse
from ._version import __version__

__all__ = ["Recollapse", "__version__"]

warnings.simplefilter("ignore")
