class MissingRepositoryLocation(Exception):
    pass


class WorktreeMissing(Exception):
    pass


class MissingProgram(Exception):
    pass
