from .i_upload_api import BaseUploadAPI
from .replicate import ReplicateUploadAPI
from .socaity import SocaityUploadAPI