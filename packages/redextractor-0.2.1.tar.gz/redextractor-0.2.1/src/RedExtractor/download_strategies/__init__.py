from .basic_download import SimpleDownload
from .mp3_format_download import MP3Download
from .internal_parallel_download import ParallelDownload