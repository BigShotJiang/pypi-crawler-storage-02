## MBI: Marginal-Based Estimation and Inference
**(with applications to differential privacy)**

<img src="pgm-logo.png" alt="drawing" width="123"/>

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.5548533.svg)](https://doi.org/10.5281/zenodo.5548533)
[![Continuous integration](https://github.com/ryan112358/private-pgm/actions/workflows/main.yml/badge.svg)](https://github.com/ryan112358/private-pgm/actions/workflows/main.yml)
[![Documentation Status](https://app.readthedocs.org/projects/private-pgm/badge/?version=latest)](https://private-pgm.readthedocs.io/en/latest/)

![Metrics for ryan112358/private-pgm repository](https://raw.githubusercontent.com/ryan112358/ryan112358/main/metrics.private-pgm.svg)


Documentation has been moved to
[https://private-pgm.readthedocs.io/en/latest/](https://private-pgm.readthedocs.io/en/latest/)!
