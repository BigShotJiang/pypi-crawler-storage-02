__author__ = 'Xavier G.'
__copyright__ = 'Copyright (c) 2024-2025 Xavier G.'
__email__ = 'xavier.moulti@kindwolf.org'
__licence__ = 'MIT'
__maintainer__ = __author__
__version__ = '1.34.1'
