from .common import moulti_test
assert moulti_test

def test_start(moulti_test):
	assert moulti_test()
