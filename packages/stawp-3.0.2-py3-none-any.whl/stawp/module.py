
class Module:

    def __init__(self, builder):
        pass

    def interpret(self, page, builder):
        pass

    def render(self, builder):
        pass

    def render_page(self, page, builder):
        pass

