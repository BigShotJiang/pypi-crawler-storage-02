spade package
=============

Submodules
----------

spade.agent module
------------------

.. automodule:: spade.agent
   :members:
   :undoc-members:
   :show-inheritance:

spade.behaviour module
----------------------

.. automodule:: spade.behaviour
   :members:
   :undoc-members:
   :show-inheritance:

spade.cli module
----------------

.. automodule:: spade.cli
   :members:
   :undoc-members:
   :show-inheritance:

spade.container module
----------------------

.. automodule:: spade.container
   :members:
   :undoc-members:
   :show-inheritance:

spade.message module
--------------------

.. automodule:: spade.message
   :members:
   :undoc-members:
   :show-inheritance:

spade.presence module
---------------------

.. automodule:: spade.presence
   :members:
   :undoc-members:
   :show-inheritance:

spade.template module
---------------------

.. automodule:: spade.template
   :members:
   :undoc-members:
   :show-inheritance:

spade.trace module
------------------

.. automodule:: spade.trace
   :members:
   :undoc-members:
   :show-inheritance:

spade.web module
----------------

.. automodule:: spade.web
   :members:
   :undoc-members:
   :show-inheritance:

spade.xmpp\_client module
-------------------------

.. automodule:: spade.xmpp_client
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: spade
   :members:
   :undoc-members:
   :show-inheritance:
