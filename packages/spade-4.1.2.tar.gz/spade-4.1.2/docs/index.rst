Welcome to SPADE's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   foreword
   model
   installation
   usage
   agents
   behaviours
   presence
   web
   extending
   api
   contributing
   conduct
   authors
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
