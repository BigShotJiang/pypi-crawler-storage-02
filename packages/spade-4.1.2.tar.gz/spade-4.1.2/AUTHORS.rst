=======
Credits
=======

Development Lead
----------------

* Javi Palanca <https://github.com/javipalanca>

Contributors
------------

* Sergio Alemany <https://github.com/Gersiete>
* Manel Soler <https://github.com/sosanzma>
* Aarón Raya <https://github.com/DinoThor>

