.. _decomposition_examples:

Decomposition
-------------

Examples concerning the :mod:`xlearn.decomposition` module.
