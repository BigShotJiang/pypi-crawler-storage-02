.. _ensemble_examples:

Ensemble methods
----------------

Examples concerning the :mod:`xlearn.ensemble` module.
