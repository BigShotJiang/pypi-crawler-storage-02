.. _linear_examples:

Generalized Linear Models
-------------------------

Examples concerning the :mod:`xlearn.linear_model` module.
