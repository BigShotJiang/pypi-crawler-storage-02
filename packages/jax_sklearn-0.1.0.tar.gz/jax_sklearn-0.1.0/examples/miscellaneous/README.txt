.. _miscellaneous_examples:

Miscellaneous
-------------

Miscellaneous and introductory examples for jax-sklearn.
