# Documentation for jax-sklearn

This directory contains the full manual and website as displayed at
https://jax-sklearn.org. See
https://jax-sklearn.org/dev/developers/contributing.html#documentation for
detailed information about the documentation.
