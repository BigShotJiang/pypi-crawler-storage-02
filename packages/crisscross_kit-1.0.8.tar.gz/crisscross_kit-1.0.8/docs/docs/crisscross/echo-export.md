Megastructures can be exported directly to an Echo liquid handler command sheet.  A convenience function for generating a plate output visualization is also provided.

::: crisscross.core_functions.megastructure_composition
