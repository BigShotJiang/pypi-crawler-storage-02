# TODO: Shall we generate this file with sql2code?
group_type = {
    'Unknown': 0,
    'Location': 1000,
    'City': 1200,
    'Country': 1300,
    'State': 1400,
    'Neighborhood': 1500,
    'Organization': 2000,
    'Job Title': 3001,
    'Interest': 4000,
    'Sport- Interest': 4100,
    'Looking for employees': 5100,
    'Looking for job': 6100,
    'Gender': 7010,
    'Marital status': 7020,
    'Relationship Status': 7030,
    'Event': 8001,
    'First Name': 9001,
    'Last Name': 9002,
    'County': 9004,
    'Region': 9005
}