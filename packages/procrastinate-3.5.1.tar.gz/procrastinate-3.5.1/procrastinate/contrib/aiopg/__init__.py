from __future__ import annotations

from .aiopg_connector import AiopgConnector

__all__ = ["AiopgConnector"]
