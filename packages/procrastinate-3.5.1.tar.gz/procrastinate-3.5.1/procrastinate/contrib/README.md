# Procrastinate contrib

This module contains optionnal parts of Procrastinate.
Those modules may require specific instructions, please consult the
documentation and the README.md.
