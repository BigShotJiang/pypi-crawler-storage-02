"""
Default encoding for importing CSV files
"""

CSV_ENCODING = "UTF-8"
