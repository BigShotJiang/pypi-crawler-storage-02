"""Constants used by the lighthouse OpenTelemetry integration.

This module defines constants used throughout the lighthouse OpenTelemetry integration.
"""

lighthouse_TRACER_NAME = "lighthouse-sdk"
