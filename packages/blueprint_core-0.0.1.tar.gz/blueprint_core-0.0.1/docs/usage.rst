=====
Usage
=====

To use blueprint-core in a project::

    import blueprint_core
