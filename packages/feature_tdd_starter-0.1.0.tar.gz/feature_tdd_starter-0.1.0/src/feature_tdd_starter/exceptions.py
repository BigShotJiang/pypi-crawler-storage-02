class InvalidGherkinSyntaxError(Exception):
    """Custom exception for Gherkin syntax errors."""
    pass