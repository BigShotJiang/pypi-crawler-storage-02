"""Rules for schema."""
