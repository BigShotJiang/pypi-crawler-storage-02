"""Rules for typing."""
