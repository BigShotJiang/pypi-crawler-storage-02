"""Rules for constraints."""
