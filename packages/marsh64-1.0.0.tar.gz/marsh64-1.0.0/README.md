# Marsh64

`Marsh64` is a lightweight Python library to encode Python code to a base64 string using marshal serialization, and run it transparently without exposing the internals.

## Installation

```bash
pip install marsh64
