from . import gromacs, gromacs_extra

name = "biobb_gromacs"
__all__ = ["gromacs", "gromacs_extra"]
__version__ = "5.1.1"
