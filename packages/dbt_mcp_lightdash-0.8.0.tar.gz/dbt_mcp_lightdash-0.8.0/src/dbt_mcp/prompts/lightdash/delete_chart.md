Delete a Lightdash chart permanently.

This action cannot be undone. Charts that are part of dashboards will be removed from those dashboards.
Requires confirmation flag to be set to true to prevent accidental deletions.

Examples:
- "Delete the old revenue chart with ID abc123"
- "Remove the unused test chart"