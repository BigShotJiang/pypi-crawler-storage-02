List all dashboards in the Lightdash project.

Returns dashboard names, IDs, descriptions, tile counts, and metadata.
Can optionally filter by space to see dashboards in a specific area.

Examples:
- "Show me all dashboards"
- "List dashboards in the Marketing space"
- "What dashboards are available?"