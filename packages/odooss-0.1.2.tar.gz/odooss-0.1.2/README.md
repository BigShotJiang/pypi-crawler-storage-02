
# Odoo Standard Scaffold

```zsh
 odooss create /home/agga/Documents/odoo-dev/ica_standard_structure/test --odoo_version 18.0 --python 3.10
```