"""
Default Flask app configuration.

Not needed anymore. Kept for compatibility.
"""
DEBUG = False
