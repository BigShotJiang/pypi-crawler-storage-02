Icons downloaded from <https://icons.getbootstrap.com> (licensed under MIT)
