# llama-stack-haystack

[![PyPI - Version](https://img.shields.io/pypi/v/llama-stack-haystack.svg)](https://pypi.org/project/llama-stack-haystack)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/llama-haystack.svg)](https://pypi.org/project/llama-stack-haystack)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install llama-stack-haystack
```

## License

`llama-stack-haystack` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
