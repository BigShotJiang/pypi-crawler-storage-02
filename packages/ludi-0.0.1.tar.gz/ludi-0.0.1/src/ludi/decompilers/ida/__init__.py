from .decompiler import Ida
