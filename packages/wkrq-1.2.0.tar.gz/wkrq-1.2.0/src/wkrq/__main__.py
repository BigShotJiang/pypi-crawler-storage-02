"""
Entry point for running wKrQ as a module: python -m wkrq
"""

from .cli import main

if __name__ == "__main__":
    main()
