# v1.1.0
Add the possibility to plot the polychromatic RMS of specific pairs depending on the incident field angle in the GUI.

# v1.0.2
Remove **Save computer RAM** option from graphical interface.
In fact, it is not useful when using the GUI, and 'no' option create a bug with the GUI, which I do not have the 
time to correct right now.

# v1.0.1
Use ray-optics 0.9.8, so can delete pyrftl/rayopt/wabre_test.py, and no modification of rayoptics is required by the user.

# v1.0.0
Initial commit
