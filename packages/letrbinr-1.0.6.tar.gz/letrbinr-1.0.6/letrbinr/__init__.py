__version__ = "1.0.6"

from .letrbinr import LetrBinr
from .letrbinr import LetrBinRAND