"""Inkognito - Privacy-preserving document processing FastMCP server."""

__version__ = "0.1.0"

__all__ = ["__version__"]