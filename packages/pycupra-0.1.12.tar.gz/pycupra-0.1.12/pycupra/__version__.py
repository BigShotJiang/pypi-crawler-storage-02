"""
pycupra - A Python 3 library for interacting with the My Cupra/My Seat portal.

For more details and documentation, visit the github page at https://github.com/WulfgarW/pycupra
"""
__version__ = "0.1.12"
