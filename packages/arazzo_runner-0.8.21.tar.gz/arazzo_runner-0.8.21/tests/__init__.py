"""
Tests for Arazzo Runner module
"""

import logging

# Configure logging for all tests
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("arazzo-test")
