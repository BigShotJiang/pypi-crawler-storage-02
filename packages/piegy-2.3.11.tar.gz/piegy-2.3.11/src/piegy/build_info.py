"""
Contains build info, whether it's local built, or a pre-compiled wheel.
Auto-generated at compile time.
"""

build_info = {
    "version": "2.3.10",
    "build date": "2025-08-11 20:12:18",
    "python used": "3.11.10",
    "platform": "darwin"
}
