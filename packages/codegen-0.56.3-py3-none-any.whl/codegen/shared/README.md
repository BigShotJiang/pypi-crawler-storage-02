# Codegen Shared

A codegen module to contain a miscellaneous set of shared utilities.

### Dependencies

This module should NOT contain any high level dependencies on other codegen modules.
It should only depend on standard libraries and other shared utilities.
