# Urls linking to the webapp
from codegen.cli.utils.url import generate_webapp_url

USER_SECRETS_ROUTE = generate_webapp_url(path="cli-token")
