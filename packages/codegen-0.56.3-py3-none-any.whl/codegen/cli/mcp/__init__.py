"""MCP (Model Context Protocol) server for Codegen."""
