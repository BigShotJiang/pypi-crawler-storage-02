import{aV as u,aW as m,g as h}from"./index.BkyptB01.js";var e,r;function W(){if(r)return e;r=1;var t=u(),a=m(),i=a(function(s,g,n,o){t(s,g,n,o)});return e=i,e}var c=W();const v=h(c);export{v as m};
