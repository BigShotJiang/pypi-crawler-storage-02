from mipx.tupledict import tupledict


TupleDict = tupledict
