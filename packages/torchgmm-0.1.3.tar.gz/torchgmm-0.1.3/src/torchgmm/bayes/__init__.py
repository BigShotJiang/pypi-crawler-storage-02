from .gmm import GaussianMixture

__all__ = [
    "GaussianMixture",
]
