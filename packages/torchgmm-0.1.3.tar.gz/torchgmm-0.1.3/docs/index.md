```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

api.md
changelog.md
contributing.md
benchmark.md
```
