# Clinform

A Python package for clinical forms management and data collection.

## Installation
```bash
pip install Clinform
```

## Usage
```python
import clinform
print(clinform.__version__)
```
