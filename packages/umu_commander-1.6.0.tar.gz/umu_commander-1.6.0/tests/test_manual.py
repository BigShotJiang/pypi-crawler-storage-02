import unittest


class Manual(unittest.TestCase):
    def test_manual_test(self):
        print("tracking.users")
        print("umu_config.create")
        print("umu_config.run")
