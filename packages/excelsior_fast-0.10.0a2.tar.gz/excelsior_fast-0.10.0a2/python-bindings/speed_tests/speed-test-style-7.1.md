| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed_style.py` | 121.740 ± 3.887 | 118.225 | 125.915 | 1.00 |
