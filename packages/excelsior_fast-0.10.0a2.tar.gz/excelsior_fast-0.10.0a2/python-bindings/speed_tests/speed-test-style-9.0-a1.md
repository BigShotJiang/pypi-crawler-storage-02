| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed_style.py` | 632.1 ± 24.4 | 615.6 | 660.1 | 1.00 |
