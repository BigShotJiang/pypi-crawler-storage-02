| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed_style.py` | 806.4 ± 3.1 | 803.4 | 809.6 | 1.00 |
