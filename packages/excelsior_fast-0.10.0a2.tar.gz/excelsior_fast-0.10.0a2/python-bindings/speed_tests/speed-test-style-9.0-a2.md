| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed_style.py` | 680.2 ± 5.9 | 673.6 | 685.1 | 1.00 |
