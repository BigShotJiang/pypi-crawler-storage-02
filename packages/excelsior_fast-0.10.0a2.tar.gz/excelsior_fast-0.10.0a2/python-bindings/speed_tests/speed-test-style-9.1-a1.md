| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed_style.py` | 768.2 ± 6.1 | 764.3 | 775.2 | 1.00 |
