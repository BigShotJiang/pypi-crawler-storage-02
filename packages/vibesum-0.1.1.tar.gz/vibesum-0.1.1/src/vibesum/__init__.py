from . import ai


def vibesum(a: int, b: int) -> int:
    return ai.vibesum(a, b)