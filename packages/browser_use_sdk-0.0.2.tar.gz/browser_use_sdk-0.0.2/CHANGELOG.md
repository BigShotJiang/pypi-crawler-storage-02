# Changelog

## 0.0.2 (2025-08-09)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/browser-use/browser-use-python/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([af51d4f](https://github.com/browser-use/browser-use-python/commit/af51d4f1d2ff224d0a2cba426b28d540d74f63ce))
* update SDK settings ([4fcafb0](https://github.com/browser-use/browser-use-python/commit/4fcafb0a1cbd6fda1c28c0996fe3de4eb033b107))
* update SDK settings ([20019d1](https://github.com/browser-use/browser-use-python/commit/20019d1ec80d3c75dfb7ca54131b66e9dc0dd542))
