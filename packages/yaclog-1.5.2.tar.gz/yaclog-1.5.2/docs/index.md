```{include} ../README.md
:end-before: ![a yak
```

```{toctree}
---
maxdepth: 2
caption: Contents
---

handbook/index
reference/index
```

```{toctree}
---
maxdepth: 1
---

Changelog <changelog>
License <license>
```

## Indices and tables

* {ref}`genindex`
* {ref}`modindex`
* {ref}`search`
