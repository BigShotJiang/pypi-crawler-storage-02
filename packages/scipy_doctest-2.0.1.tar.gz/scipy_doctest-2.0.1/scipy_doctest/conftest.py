from .impl import DTConfig


dt_config = DTConfig()
