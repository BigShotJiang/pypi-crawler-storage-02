This module adds a asset number for the asset's reference.

**Notes:**

If you check "Auto Asset Number by Sequence", you will not be able to
edit the asset number using that asset profile.
