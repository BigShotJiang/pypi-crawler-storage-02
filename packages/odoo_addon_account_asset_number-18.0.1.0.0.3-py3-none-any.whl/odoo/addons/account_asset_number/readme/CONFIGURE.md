You can set the default asset number by going to *Invoicing \>
Configuration \> Asset Profile*, and check *Auto Asset Number by
Sequence* then select *Asset Number Sequence*.
