# bridges-python

This is the Python implementation of the BRIDGES API

Authors: Matthew Mcquaigue, David Burlinson, Kalpathi Subramanian

Date: June 2018

## Install
### Recommended
Recommended installation from [pip](https://pypi.org/project/bridges/)  
`pip install bridges`

### From source  
To install from this repository  
`cd path/to/directory`  
`python setup.py install`


## Generating a new pip package
read [this](packaging.md)