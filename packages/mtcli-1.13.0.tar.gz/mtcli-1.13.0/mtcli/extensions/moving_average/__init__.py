from .models import model_rates, model_ma, model_mas
from .views import view_ma
from . import conf
from . import command
from .command import ma
