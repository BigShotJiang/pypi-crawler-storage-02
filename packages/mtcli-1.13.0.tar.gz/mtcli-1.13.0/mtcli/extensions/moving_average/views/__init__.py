from . import view_ma
