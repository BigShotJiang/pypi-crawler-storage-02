class UbiOpsException(Exception):
    pass


class UnAuthorizedException(UbiOpsException):
    pass
