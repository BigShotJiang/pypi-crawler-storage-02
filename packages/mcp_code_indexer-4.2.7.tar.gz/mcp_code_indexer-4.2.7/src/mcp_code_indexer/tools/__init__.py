"""MCP tools for file description management."""
