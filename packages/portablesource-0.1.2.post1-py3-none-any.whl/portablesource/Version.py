#!/usr/bin/env python3
__version__ = "0.1.2.post1"

if __name__ == "__main__":
    print(__version__)