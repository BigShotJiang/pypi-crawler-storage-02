
#ifndef MIMIR_PYTHON_COMMON_EQUAL_TO_HPP
#define MIMIR_PYTHON_COMMON_EQUAL_TO_HPP

namespace mimir
{

}

#endif