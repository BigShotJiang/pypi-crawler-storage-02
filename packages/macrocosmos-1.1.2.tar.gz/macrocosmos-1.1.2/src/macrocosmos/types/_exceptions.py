class MacrocosmosError(Exception):
    """Base exception for Macrocosmos errors."""

    pass
