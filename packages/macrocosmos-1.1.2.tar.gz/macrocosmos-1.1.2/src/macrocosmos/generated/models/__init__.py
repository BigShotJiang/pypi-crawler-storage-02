# Auto-generated Pydantic models from protobufs
