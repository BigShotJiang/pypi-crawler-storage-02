"""Chaturbate Poller CLI module."""

from chaturbate_poller.cli.commands import cli

__all__ = ["cli"]
