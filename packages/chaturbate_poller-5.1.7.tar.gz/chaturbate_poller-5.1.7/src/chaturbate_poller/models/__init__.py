"""Pydantic models for the Chaturbate Poller."""
