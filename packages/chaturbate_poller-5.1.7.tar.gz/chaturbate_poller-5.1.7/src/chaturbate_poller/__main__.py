"""Main module for the Chaturbate Poller."""

from chaturbate_poller.cli import cli  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    cli()
