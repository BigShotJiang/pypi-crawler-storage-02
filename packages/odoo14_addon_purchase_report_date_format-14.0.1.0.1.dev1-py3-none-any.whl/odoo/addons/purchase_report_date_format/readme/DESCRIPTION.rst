Shows following datetime fields of purchase reports in date format instead of datetime,
since presenting dates up to seconds is too much or unnecessary in many purchase
transactions.

Request for Quotation print:

* Expected Date

Purchase Order print:

* Order Date
* Order Deadline
* Requested Date
