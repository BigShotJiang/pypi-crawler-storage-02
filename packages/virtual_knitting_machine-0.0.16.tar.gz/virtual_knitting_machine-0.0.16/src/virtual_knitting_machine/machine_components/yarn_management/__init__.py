"""This package contains the classes used to manage the yarn-carriers in a knitting machine."""
