virtual\_knitting\_machine.machine\_components.needles.Sheet\_Needle module
===========================================================================

.. automodule:: virtual_knitting_machine.machine_components.needles.Sheet_Needle
   :members:
   :undoc-members:
   :show-inheritance:
