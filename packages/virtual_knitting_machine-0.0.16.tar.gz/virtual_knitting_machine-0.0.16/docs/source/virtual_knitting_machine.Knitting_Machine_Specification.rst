virtual\_knitting\_machine.Knitting\_Machine\_Specification module
==================================================================

.. automodule:: virtual_knitting_machine.Knitting_Machine_Specification
   :members:
   :undoc-members:
   :show-inheritance:
