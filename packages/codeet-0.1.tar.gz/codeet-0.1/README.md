# Codeet🧑‍💻
Codeet vertion:0.2

## Requirements
- Python 3.10 only

## Getting started
### Pip

```shell script
$ pip install codeet
```

## Who is Codeet useful for?
Codeet is made for those who are on the Codeet.ir site and learn Python from there.

## What features does Codeet have?
Codeet is not a package. Codeet created for install requirements need for "codeet.ir".
<br> 
who learn Python from Codeet can use it for various tasks.

### All rights reserved.
&copy; Safa Soft Electronics
<br>
Email: help@codeet.ir