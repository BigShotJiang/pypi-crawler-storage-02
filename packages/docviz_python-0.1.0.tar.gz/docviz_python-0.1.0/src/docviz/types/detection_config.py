class DetectionConfig:
    pass