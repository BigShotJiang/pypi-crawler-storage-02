class ExtractionConfig:
    pass