import enum


class Environment(enum.StrEnum):
    local = "local"
    prod = "prod"
