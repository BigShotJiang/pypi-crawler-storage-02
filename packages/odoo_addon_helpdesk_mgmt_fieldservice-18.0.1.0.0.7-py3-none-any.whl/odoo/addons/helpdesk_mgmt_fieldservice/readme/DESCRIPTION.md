This module allows the helpdesk user to track the status of related
service orders.
