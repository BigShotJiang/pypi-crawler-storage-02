# CAPM

<div align="center">

![Logo](https://raw.githubusercontent.com/robvanderleek/capm/main/docs/capm-logo.png)

</div>

<div align="center">

  *Code Analysis Package Manager 📦*

</div>

<div align="center">

</div>

## Building the binary distribution

Generate a self-contained binary:

```shell
uv run poe bundle
```
