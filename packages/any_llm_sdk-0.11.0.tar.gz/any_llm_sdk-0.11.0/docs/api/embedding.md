## Embedding

::: any_llm.embedding
::: any_llm.aembedding
