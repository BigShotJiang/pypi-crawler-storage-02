from .formatter import CustomLogger

logger = CustomLogger("logwise")
