# -*- coding: UTF-8 -*-
from behave import given


@given(u'a person named "{name}"')
def step_given_person_with_name(ctx, name):
    pass
