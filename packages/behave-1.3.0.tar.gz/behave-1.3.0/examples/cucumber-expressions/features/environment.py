from behave.cucumber_expression import use_step_matcher_for_cucumber_expressions

# -- HINT: Use StepMatcher4CucumberExpressions as default step-matcher.
use_step_matcher_for_cucumber_expressions()
