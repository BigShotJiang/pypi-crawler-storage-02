# -*- coding: utf-8 -*-
"""
Predecessor of `behave4cmd`_ library.
Currently used to provide self-tests for `behave`_.

.. _behave: https://github.com/behave/behave
.. _behave4cmd: https://github.com/behave/behave4cmd
"""

__version__ = "1.2.7.dev5"
