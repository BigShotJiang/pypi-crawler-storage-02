"""# lucidium.agents.commands

Defines the various commands possible for execution by agents.
"""

__all__ =   [
                "play"
            ]

from lucidium.agents.commands   import play