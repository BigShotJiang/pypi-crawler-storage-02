"""# lucidium.environments.tic_tac_toe

Tic-Tac-Toe environment package.
"""

__all__ = ["TicTacToe"]

from lucidium.environments.tic_tac_toe.__base__ import TicTacToe