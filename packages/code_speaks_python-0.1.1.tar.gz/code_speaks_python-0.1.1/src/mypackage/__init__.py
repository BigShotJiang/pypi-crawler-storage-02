from mypackage.core import hello

__version__ = "0.1.0"
