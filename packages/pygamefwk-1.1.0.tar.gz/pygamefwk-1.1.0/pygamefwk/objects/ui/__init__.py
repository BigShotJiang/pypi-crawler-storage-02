NEWLINE = '\n'

from pygamefwk.objects.ui.ui import UI
from pygamefwk.objects.ui.button import Button
from pygamefwk.objects.ui.inputfield import InputField
from pygamefwk.objects.ui.text import Text