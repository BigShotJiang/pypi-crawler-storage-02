# python code that checks variables submitted

