"""
Tests for the V2 SDK.

"""
