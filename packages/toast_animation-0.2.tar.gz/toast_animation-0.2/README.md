# flet_toasty
# Toast Animation

A Python package for creating animated toast notifications in Flet applications.

## Installation

You can install the package using pip:

```bash
pip install toast_animation
