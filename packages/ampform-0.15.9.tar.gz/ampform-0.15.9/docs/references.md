# Bibliography

:::{tip}

Download this bibliography as BibTeX {download}`here </bibliography.bib>`.

:::

```{bibliography} /bibliography.bib
---
all:
---
```
