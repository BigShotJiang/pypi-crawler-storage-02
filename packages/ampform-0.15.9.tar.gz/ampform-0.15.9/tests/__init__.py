"""Required to set mypy options for the tests folder."""
