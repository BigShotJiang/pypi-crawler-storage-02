# Utilities, widgets, and components shared by the AiiDAlab Quantum ESPRESSO app and its plugins

This repository includes various components used by the AiiDAlab Quantum ESPRESSO app and its plugins.
