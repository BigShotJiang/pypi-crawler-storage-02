The ``p01.recipe.cdn:app`` recipe generates a script which is able to extract
content delivery resources defined by the p01.cdn meta directives from a
project to a given folder. Additional there is a minify recipe which generates
a minify script which is able to collect resources from a local project or
released python packages, minify and bundle them. And there is a glue recipe
which is able to generate sprite images. In short words, three is everything
you will need to generate and extract resources for a content delivery network.
