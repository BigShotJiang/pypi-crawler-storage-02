"""
Optimization benchmarks functions.
"""

from .cec_objective_function import CECObjectiveFunction
