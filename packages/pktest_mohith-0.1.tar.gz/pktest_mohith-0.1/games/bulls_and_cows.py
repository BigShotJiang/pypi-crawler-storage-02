# Bulls and Cows game implementation

def play_game(game_name):
    if game_name == 'bulls_and_cows':
        print('Playing Bulls and Cows!')
        # Add your game logic here
