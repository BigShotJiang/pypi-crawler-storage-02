# Core game functions

def generateNum():
    pass

def noDuplicates():
    pass

def numOfBullsCows():
    pass

def getDigits():
    pass

def guess_number():
    pass

def play_game(game_name):
    pass
