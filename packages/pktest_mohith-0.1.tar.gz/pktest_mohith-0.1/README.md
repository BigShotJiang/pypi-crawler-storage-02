# pythongames

A collection of fun Python games including Rock Paper Scissors, Bulls and Cows, and more.

## Installation

```bash
pip install pythongames
```

## Usage

```python
from games import play_game
play_game('rock')
```
