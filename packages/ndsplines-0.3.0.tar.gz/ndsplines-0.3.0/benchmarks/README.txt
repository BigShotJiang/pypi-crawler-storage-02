==========
Benchmarks
==========

Scripts for benchmarking ndsplines.
