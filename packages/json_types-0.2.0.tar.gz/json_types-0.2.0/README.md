# json_types

[![PyPI - Version](https://img.shields.io/pypi/v/json_types.svg)](https://pypi.org/project/json_types)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/json_types.svg)](https://pypi.org/project/json_types)

Type definitions and utilities for working with JSON in Python

-----

## Installation

```console
pip install json_types
```
