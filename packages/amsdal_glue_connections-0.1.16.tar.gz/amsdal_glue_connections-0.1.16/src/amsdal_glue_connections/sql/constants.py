SCHEMA_REGISTRY_TABLE = 'amsdal_schema_registry'
