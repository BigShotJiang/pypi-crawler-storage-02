## [v0.1.16](https://pypi.org/project/amsdal-glue-connections/0.1.16/) - 2025-08-06

### Added

- Elasticsearch connection
