weaviate.collections.queries.near\_image
========================================

.. automodule:: weaviate.collections.queries.near_image
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.collections.queries.near\_image.generate module
.. --------------------------------------------------------

.. .. automodule:: weaviate.collections.queries.near_image.generate
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.queries.near\_image.query module
.. -----------------------------------------------------

.. .. automodule:: weaviate.collections.queries.near_image.query
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
