weaviate.collections.batch
==========================

.. automodule:: weaviate.collections.batch
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.batch.base
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.batch.base
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.batch.batch\_wrapper
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.batch.batch_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.batch.client
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.batch.client
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.batch.collection
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.batch.collection
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.batch.grpc\_batch\_delete
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.batch.grpc_batch_delete
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.batch.grpc\_batch\_objects
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.batch.grpc_batch_objects
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.batch.rest
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.batch.rest
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
