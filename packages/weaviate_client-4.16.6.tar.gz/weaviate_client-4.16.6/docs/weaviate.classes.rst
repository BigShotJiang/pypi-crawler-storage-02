weaviate.classes
================

.. automodule:: weaviate.classes
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.aggregate
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.aggregate
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.backup
^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.backup
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.batch
^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.batch
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.config
^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.config
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.data
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.data
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.debug
^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.debug
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.generics
^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.generics
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.init
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.init
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.query
^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.query
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.rbac
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.rbac
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.classes.tenants
^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.classes.tenants
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
