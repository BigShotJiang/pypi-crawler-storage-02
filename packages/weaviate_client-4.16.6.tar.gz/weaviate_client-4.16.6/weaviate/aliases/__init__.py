from .async_ import _AliasAsync
from .sync import _Alias

__all__ = ["_AliasAsync", "_Alias"]
