TARGET_IMG_LAYERS = "target-image-layer"
ROI_ID = "ROI-ID"
SOURCE = "source"
IMAGE_AXES = "axes"
