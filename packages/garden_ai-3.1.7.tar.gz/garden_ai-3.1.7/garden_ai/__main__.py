from .app.main import app

app(prog_name="garden-ai")
