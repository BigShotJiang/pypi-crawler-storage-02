#    _____           ______  _____ 
#  / ____/    /\    |  ____ |  __ \
# | |        /  \   | |__   | |__) | Caer - Modern Computer Vision
# | |       / /\ \  |  __|  |  _  /  Languages: Python, C, C++, Cuda
# | |___   / ____ \ | |____ | | \ \  http://github.com/jasmcaus/caer
#  \_____\/_/    \_ \______ |_|  \_\

# Licensed under the MIT License <http://opensource.org/licenses/MIT>
# SPDX-License-Identifier: MIT
# Copyright (c) 2020-2025 The Caer Authors <http://github.com/jasmcaus>


# We don't want to modify the root dir in any way 
# This gets disrupted if this file is called directly
# Checks are in place:

if __name__ != "__main__":
    from .path import dirname

    __curr__ = dirname(__file__).replace("\\", "/")