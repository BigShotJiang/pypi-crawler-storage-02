vfbLib.ufo.typing.TUfoTTZoneDict
================================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoTTZoneDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoTTZoneDict.__init__
      ~TUfoTTZoneDict.clear
      ~TUfoTTZoneDict.copy
      ~TUfoTTZoneDict.fromkeys
      ~TUfoTTZoneDict.get
      ~TUfoTTZoneDict.items
      ~TUfoTTZoneDict.keys
      ~TUfoTTZoneDict.pop
      ~TUfoTTZoneDict.popitem
      ~TUfoTTZoneDict.setdefault
      ~TUfoTTZoneDict.update
      ~TUfoTTZoneDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoTTZoneDict.position
      ~TUfoTTZoneDict.top
      ~TUfoTTZoneDict.width
      ~TUfoTTZoneDict.delta
   
   