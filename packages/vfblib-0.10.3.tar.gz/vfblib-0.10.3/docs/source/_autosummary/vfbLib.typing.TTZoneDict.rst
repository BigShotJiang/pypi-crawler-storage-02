vfbLib.typing.TTZoneDict
========================

.. currentmodule:: vfbLib.typing

.. autoclass:: TTZoneDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTZoneDict.__init__
      ~TTZoneDict.clear
      ~TTZoneDict.copy
      ~TTZoneDict.fromkeys
      ~TTZoneDict.get
      ~TTZoneDict.items
      ~TTZoneDict.keys
      ~TTZoneDict.pop
      ~TTZoneDict.popitem
      ~TTZoneDict.setdefault
      ~TTZoneDict.update
      ~TTZoneDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTZoneDict.deltas
      ~TTZoneDict.name
      ~TTZoneDict.position
      ~TTZoneDict.top
      ~TTZoneDict.value
   
   