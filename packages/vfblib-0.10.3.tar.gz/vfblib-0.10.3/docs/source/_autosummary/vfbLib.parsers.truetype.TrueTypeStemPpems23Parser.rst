vfbLib.parsers.truetype.TrueTypeStemPpems23Parser
=================================================

.. currentmodule:: vfbLib.parsers.truetype

.. autoclass:: TrueTypeStemPpems23Parser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeStemPpems23Parser.__init__
      ~TrueTypeStemPpems23Parser.parse
      ~TrueTypeStemPpems23Parser.parse_hex
      ~TrueTypeStemPpems23Parser.read_double
      ~TrueTypeStemPpems23Parser.read_doubles
      ~TrueTypeStemPpems23Parser.read_int16
      ~TrueTypeStemPpems23Parser.read_int32
      ~TrueTypeStemPpems23Parser.read_int8
      ~TrueTypeStemPpems23Parser.read_str
      ~TrueTypeStemPpems23Parser.read_str_all
      ~TrueTypeStemPpems23Parser.read_str_with_len
      ~TrueTypeStemPpems23Parser.read_uint16
      ~TrueTypeStemPpems23Parser.read_uint32
      ~TrueTypeStemPpems23Parser.read_uint8
      ~TrueTypeStemPpems23Parser.read_value
   
   

   
   
   