vfbLib.compilers.truetype.TrueTypeStemPpemsCompiler
===================================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: TrueTypeStemPpemsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeStemPpemsCompiler.__init__
      ~TrueTypeStemPpemsCompiler.compile
      ~TrueTypeStemPpemsCompiler.compile_hex
      ~TrueTypeStemPpemsCompiler.merge
      ~TrueTypeStemPpemsCompiler.write_bytes
      ~TrueTypeStemPpemsCompiler.write_double
      ~TrueTypeStemPpemsCompiler.write_doubles
      ~TrueTypeStemPpemsCompiler.write_int16
      ~TrueTypeStemPpemsCompiler.write_int32
      ~TrueTypeStemPpemsCompiler.write_str
      ~TrueTypeStemPpemsCompiler.write_str_with_len
      ~TrueTypeStemPpemsCompiler.write_uint16
      ~TrueTypeStemPpemsCompiler.write_uint32
      ~TrueTypeStemPpemsCompiler.write_uint8
      ~TrueTypeStemPpemsCompiler.write_value
   
   

   
   
   