vfbLib.compilers.truetype.convert\_flags\_options\_to\_int
==========================================================

.. currentmodule:: vfbLib.compilers.truetype

.. autofunction:: convert_flags_options_to_int