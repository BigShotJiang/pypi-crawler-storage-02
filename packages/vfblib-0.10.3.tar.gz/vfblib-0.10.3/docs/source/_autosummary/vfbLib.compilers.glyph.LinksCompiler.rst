vfbLib.compilers.glyph.LinksCompiler
====================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: LinksCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LinksCompiler.__init__
      ~LinksCompiler.compile
      ~LinksCompiler.compile_hex
      ~LinksCompiler.merge
      ~LinksCompiler.write_bytes
      ~LinksCompiler.write_double
      ~LinksCompiler.write_doubles
      ~LinksCompiler.write_int16
      ~LinksCompiler.write_int32
      ~LinksCompiler.write_str
      ~LinksCompiler.write_str_with_len
      ~LinksCompiler.write_uint16
      ~LinksCompiler.write_uint32
      ~LinksCompiler.write_uint8
      ~LinksCompiler.write_value
   
   

   
   
   