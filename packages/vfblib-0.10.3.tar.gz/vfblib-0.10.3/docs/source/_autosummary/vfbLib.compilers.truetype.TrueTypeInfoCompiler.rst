vfbLib.compilers.truetype.TrueTypeInfoCompiler
==============================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: TrueTypeInfoCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeInfoCompiler.__init__
      ~TrueTypeInfoCompiler.compile
      ~TrueTypeInfoCompiler.compile_hex
      ~TrueTypeInfoCompiler.merge
      ~TrueTypeInfoCompiler.write_bytes
      ~TrueTypeInfoCompiler.write_double
      ~TrueTypeInfoCompiler.write_doubles
      ~TrueTypeInfoCompiler.write_int16
      ~TrueTypeInfoCompiler.write_int32
      ~TrueTypeInfoCompiler.write_str
      ~TrueTypeInfoCompiler.write_str_with_len
      ~TrueTypeInfoCompiler.write_uint16
      ~TrueTypeInfoCompiler.write_uint32
      ~TrueTypeInfoCompiler.write_uint8
      ~TrueTypeInfoCompiler.write_value
   
   

   
   
   