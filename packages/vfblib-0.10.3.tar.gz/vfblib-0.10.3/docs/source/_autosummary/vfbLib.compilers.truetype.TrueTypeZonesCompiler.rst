vfbLib.compilers.truetype.TrueTypeZonesCompiler
===============================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: TrueTypeZonesCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeZonesCompiler.__init__
      ~TrueTypeZonesCompiler.compile
      ~TrueTypeZonesCompiler.compile_hex
      ~TrueTypeZonesCompiler.merge
      ~TrueTypeZonesCompiler.write_bytes
      ~TrueTypeZonesCompiler.write_double
      ~TrueTypeZonesCompiler.write_doubles
      ~TrueTypeZonesCompiler.write_int16
      ~TrueTypeZonesCompiler.write_int32
      ~TrueTypeZonesCompiler.write_str
      ~TrueTypeZonesCompiler.write_str_with_len
      ~TrueTypeZonesCompiler.write_uint16
      ~TrueTypeZonesCompiler.write_uint32
      ~TrueTypeZonesCompiler.write_uint8
      ~TrueTypeZonesCompiler.write_value
   
   

   
   
   