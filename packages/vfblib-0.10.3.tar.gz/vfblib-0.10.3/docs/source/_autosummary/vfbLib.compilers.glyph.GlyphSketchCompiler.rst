vfbLib.compilers.glyph.GlyphSketchCompiler
==========================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlyphSketchCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphSketchCompiler.__init__
      ~GlyphSketchCompiler.compile
      ~GlyphSketchCompiler.compile_hex
      ~GlyphSketchCompiler.merge
      ~GlyphSketchCompiler.write_bytes
      ~GlyphSketchCompiler.write_double
      ~GlyphSketchCompiler.write_doubles
      ~GlyphSketchCompiler.write_int16
      ~GlyphSketchCompiler.write_int32
      ~GlyphSketchCompiler.write_str
      ~GlyphSketchCompiler.write_str_with_len
      ~GlyphSketchCompiler.write_uint16
      ~GlyphSketchCompiler.write_uint32
      ~GlyphSketchCompiler.write_uint8
      ~GlyphSketchCompiler.write_value
   
   

   
   
   