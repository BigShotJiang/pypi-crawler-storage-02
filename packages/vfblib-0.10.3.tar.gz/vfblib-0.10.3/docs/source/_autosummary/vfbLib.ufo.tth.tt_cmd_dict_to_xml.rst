vfbLib.ufo.tth.tt\_cmd\_dict\_to\_xml
=====================================

.. currentmodule:: vfbLib.ufo.tth

.. autofunction:: tt_cmd_dict_to_xml