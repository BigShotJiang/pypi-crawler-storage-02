vfbLib.tth.merge\_zone\_information
===================================

.. currentmodule:: vfbLib.tth

.. autofunction:: merge_zone_information