vfbLib.ufo.typing.TUfoRawStemDict
=================================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoRawStemDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoRawStemDict.__init__
      ~TUfoRawStemDict.clear
      ~TUfoRawStemDict.copy
      ~TUfoRawStemDict.fromkeys
      ~TUfoRawStemDict.get
      ~TUfoRawStemDict.items
      ~TUfoRawStemDict.keys
      ~TUfoRawStemDict.pop
      ~TUfoRawStemDict.popitem
      ~TUfoRawStemDict.setdefault
      ~TUfoRawStemDict.update
      ~TUfoRawStemDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoRawStemDict.name
      ~TUfoRawStemDict.round
      ~TUfoRawStemDict.value
   
   