vfbLib.compilers.base.OpenTypeMetricsClassFlagsCompiler
=======================================================

.. currentmodule:: vfbLib.compilers.base

.. autoclass:: OpenTypeMetricsClassFlagsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OpenTypeMetricsClassFlagsCompiler.__init__
      ~OpenTypeMetricsClassFlagsCompiler.compile
      ~OpenTypeMetricsClassFlagsCompiler.compile_hex
      ~OpenTypeMetricsClassFlagsCompiler.merge
      ~OpenTypeMetricsClassFlagsCompiler.write_bytes
      ~OpenTypeMetricsClassFlagsCompiler.write_double
      ~OpenTypeMetricsClassFlagsCompiler.write_doubles
      ~OpenTypeMetricsClassFlagsCompiler.write_int16
      ~OpenTypeMetricsClassFlagsCompiler.write_int32
      ~OpenTypeMetricsClassFlagsCompiler.write_str
      ~OpenTypeMetricsClassFlagsCompiler.write_str_with_len
      ~OpenTypeMetricsClassFlagsCompiler.write_uint16
      ~OpenTypeMetricsClassFlagsCompiler.write_uint32
      ~OpenTypeMetricsClassFlagsCompiler.write_uint8
      ~OpenTypeMetricsClassFlagsCompiler.write_value
   
   

   
   
   