vfbLib.ufo.typing.TUfoStemsDict
===============================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoStemsDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoStemsDict.__init__
      ~TUfoStemsDict.clear
      ~TUfoStemsDict.copy
      ~TUfoStemsDict.fromkeys
      ~TUfoStemsDict.get
      ~TUfoStemsDict.items
      ~TUfoStemsDict.keys
      ~TUfoStemsDict.pop
      ~TUfoStemsDict.popitem
      ~TUfoStemsDict.setdefault
      ~TUfoStemsDict.update
      ~TUfoStemsDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoStemsDict.ttStemsH
      ~TUfoStemsDict.ttStemsV
   
   