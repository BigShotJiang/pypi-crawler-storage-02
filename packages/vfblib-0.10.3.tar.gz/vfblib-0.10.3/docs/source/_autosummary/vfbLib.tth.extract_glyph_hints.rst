vfbLib.tth.extract\_glyph\_hints
================================

.. currentmodule:: vfbLib.tth

.. autofunction:: extract_glyph_hints