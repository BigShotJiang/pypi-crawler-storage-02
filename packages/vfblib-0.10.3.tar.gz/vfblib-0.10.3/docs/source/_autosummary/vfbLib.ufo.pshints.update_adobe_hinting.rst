vfbLib.ufo.pshints.update\_adobe\_hinting
=========================================

.. currentmodule:: vfbLib.ufo.pshints

.. autofunction:: update_adobe_hinting