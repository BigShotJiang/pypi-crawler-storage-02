vfbLib.compilers.base.OpenTypeKerningClassFlagsCompiler
=======================================================

.. currentmodule:: vfbLib.compilers.base

.. autoclass:: OpenTypeKerningClassFlagsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OpenTypeKerningClassFlagsCompiler.__init__
      ~OpenTypeKerningClassFlagsCompiler.compile
      ~OpenTypeKerningClassFlagsCompiler.compile_hex
      ~OpenTypeKerningClassFlagsCompiler.merge
      ~OpenTypeKerningClassFlagsCompiler.write_bytes
      ~OpenTypeKerningClassFlagsCompiler.write_double
      ~OpenTypeKerningClassFlagsCompiler.write_doubles
      ~OpenTypeKerningClassFlagsCompiler.write_int16
      ~OpenTypeKerningClassFlagsCompiler.write_int32
      ~OpenTypeKerningClassFlagsCompiler.write_str
      ~OpenTypeKerningClassFlagsCompiler.write_str_with_len
      ~OpenTypeKerningClassFlagsCompiler.write_uint16
      ~OpenTypeKerningClassFlagsCompiler.write_uint32
      ~OpenTypeKerningClassFlagsCompiler.write_uint8
      ~OpenTypeKerningClassFlagsCompiler.write_value
   
   

   
   
   