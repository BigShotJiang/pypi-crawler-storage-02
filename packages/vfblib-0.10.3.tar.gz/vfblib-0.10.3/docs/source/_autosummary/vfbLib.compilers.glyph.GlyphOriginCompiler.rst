vfbLib.compilers.glyph.GlyphOriginCompiler
==========================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlyphOriginCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphOriginCompiler.__init__
      ~GlyphOriginCompiler.compile
      ~GlyphOriginCompiler.compile_hex
      ~GlyphOriginCompiler.merge
      ~GlyphOriginCompiler.write_bytes
      ~GlyphOriginCompiler.write_double
      ~GlyphOriginCompiler.write_doubles
      ~GlyphOriginCompiler.write_int16
      ~GlyphOriginCompiler.write_int32
      ~GlyphOriginCompiler.write_str
      ~GlyphOriginCompiler.write_str_with_len
      ~GlyphOriginCompiler.write_uint16
      ~GlyphOriginCompiler.write_uint32
      ~GlyphOriginCompiler.write_uint8
      ~GlyphOriginCompiler.write_value
   
   

   
   
   