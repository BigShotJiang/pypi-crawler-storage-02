vfbLib.ufo.tth.TTGlyphHints
===========================

.. currentmodule:: vfbLib.ufo.tth

.. autoclass:: TTGlyphHints
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTGlyphHints.__init__
      ~TTGlyphHints.get_tt_glyph_hints
   
   

   
   
   