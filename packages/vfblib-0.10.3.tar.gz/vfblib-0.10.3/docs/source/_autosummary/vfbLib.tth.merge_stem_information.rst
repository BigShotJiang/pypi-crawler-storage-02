vfbLib.tth.merge\_stem\_information
===================================

.. currentmodule:: vfbLib.tth

.. autofunction:: merge_stem_information