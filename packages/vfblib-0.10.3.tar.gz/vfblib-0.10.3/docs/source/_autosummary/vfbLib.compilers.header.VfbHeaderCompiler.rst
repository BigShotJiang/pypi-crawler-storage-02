vfbLib.compilers.header.VfbHeaderCompiler
=========================================

.. currentmodule:: vfbLib.compilers.header

.. autoclass:: VfbHeaderCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbHeaderCompiler.__init__
      ~VfbHeaderCompiler.compile
      ~VfbHeaderCompiler.write_bytes
      ~VfbHeaderCompiler.write_double
      ~VfbHeaderCompiler.write_doubles
      ~VfbHeaderCompiler.write_int16
      ~VfbHeaderCompiler.write_int32
      ~VfbHeaderCompiler.write_str
      ~VfbHeaderCompiler.write_str_with_len
      ~VfbHeaderCompiler.write_uint16
      ~VfbHeaderCompiler.write_uint32
      ~VfbHeaderCompiler.write_uint8
      ~VfbHeaderCompiler.write_value
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbHeaderCompiler.encoding
   
   