vfbLib.typing.MMAnchorDict
==========================

.. currentmodule:: vfbLib.typing

.. autoclass:: MMAnchorDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MMAnchorDict.__init__
      ~MMAnchorDict.clear
      ~MMAnchorDict.copy
      ~MMAnchorDict.fromkeys
      ~MMAnchorDict.get
      ~MMAnchorDict.items
      ~MMAnchorDict.keys
      ~MMAnchorDict.pop
      ~MMAnchorDict.popitem
      ~MMAnchorDict.setdefault
      ~MMAnchorDict.update
      ~MMAnchorDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MMAnchorDict.x
      ~MMAnchorDict.y
   
   