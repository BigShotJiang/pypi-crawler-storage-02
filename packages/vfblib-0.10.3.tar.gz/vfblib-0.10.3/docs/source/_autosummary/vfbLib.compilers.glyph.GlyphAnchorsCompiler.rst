vfbLib.compilers.glyph.GlyphAnchorsCompiler
===========================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlyphAnchorsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphAnchorsCompiler.__init__
      ~GlyphAnchorsCompiler.compile
      ~GlyphAnchorsCompiler.compile_hex
      ~GlyphAnchorsCompiler.merge
      ~GlyphAnchorsCompiler.write_bytes
      ~GlyphAnchorsCompiler.write_double
      ~GlyphAnchorsCompiler.write_doubles
      ~GlyphAnchorsCompiler.write_int16
      ~GlyphAnchorsCompiler.write_int32
      ~GlyphAnchorsCompiler.write_str
      ~GlyphAnchorsCompiler.write_str_with_len
      ~GlyphAnchorsCompiler.write_uint16
      ~GlyphAnchorsCompiler.write_uint32
      ~GlyphAnchorsCompiler.write_uint8
      ~GlyphAnchorsCompiler.write_value
   
   

   
   
   