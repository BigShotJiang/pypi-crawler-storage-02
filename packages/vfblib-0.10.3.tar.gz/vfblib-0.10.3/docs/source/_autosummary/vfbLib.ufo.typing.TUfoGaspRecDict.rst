vfbLib.ufo.typing.TUfoGaspRecDict
=================================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoGaspRecDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoGaspRecDict.__init__
      ~TUfoGaspRecDict.clear
      ~TUfoGaspRecDict.copy
      ~TUfoGaspRecDict.fromkeys
      ~TUfoGaspRecDict.get
      ~TUfoGaspRecDict.items
      ~TUfoGaspRecDict.keys
      ~TUfoGaspRecDict.pop
      ~TUfoGaspRecDict.popitem
      ~TUfoGaspRecDict.setdefault
      ~TUfoGaspRecDict.update
      ~TUfoGaspRecDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoGaspRecDict.rangeMaxPPEM
      ~TUfoGaspRecDict.rangeGaspBehavior
   
   