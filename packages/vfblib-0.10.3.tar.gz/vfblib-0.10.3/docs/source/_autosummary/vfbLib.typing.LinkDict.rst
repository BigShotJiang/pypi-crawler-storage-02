vfbLib.typing.LinkDict
======================

.. currentmodule:: vfbLib.typing

.. autoclass:: LinkDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LinkDict.__init__
      ~LinkDict.clear
      ~LinkDict.copy
      ~LinkDict.fromkeys
      ~LinkDict.get
      ~LinkDict.items
      ~LinkDict.keys
      ~LinkDict.pop
      ~LinkDict.popitem
      ~LinkDict.setdefault
      ~LinkDict.update
      ~LinkDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LinkDict.x
      ~LinkDict.y
   
   