vfbLib.typing.TTZonesDict
=========================

.. currentmodule:: vfbLib.typing

.. autoclass:: TTZonesDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTZonesDict.__init__
      ~TTZonesDict.clear
      ~TTZonesDict.copy
      ~TTZonesDict.fromkeys
      ~TTZonesDict.get
      ~TTZonesDict.items
      ~TTZonesDict.keys
      ~TTZonesDict.pop
      ~TTZonesDict.popitem
      ~TTZonesDict.setdefault
      ~TTZonesDict.update
      ~TTZonesDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTZonesDict.ttZonesT
      ~TTZonesDict.ttZonesB
   
   