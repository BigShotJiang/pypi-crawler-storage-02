vfbLib.typing.GuidePropertyDict
===============================

.. currentmodule:: vfbLib.typing

.. autoclass:: GuidePropertyDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GuidePropertyDict.__init__
      ~GuidePropertyDict.clear
      ~GuidePropertyDict.copy
      ~GuidePropertyDict.fromkeys
      ~GuidePropertyDict.get
      ~GuidePropertyDict.items
      ~GuidePropertyDict.keys
      ~GuidePropertyDict.pop
      ~GuidePropertyDict.popitem
      ~GuidePropertyDict.setdefault
      ~GuidePropertyDict.update
      ~GuidePropertyDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GuidePropertyDict.color
      ~GuidePropertyDict.index
      ~GuidePropertyDict.name
   
   