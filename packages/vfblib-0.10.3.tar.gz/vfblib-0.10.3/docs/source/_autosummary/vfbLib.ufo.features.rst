vfbLib.ufo.features
===================

.. automodule:: vfbLib.ufo.features
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      rename_kern_classes_in_feature_code
   
   

   
   
   

   
   
   



