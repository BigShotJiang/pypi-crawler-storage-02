vfbLib.ufo.groups.rebuild\_kerning\_groups
==========================================

.. currentmodule:: vfbLib.ufo.groups

.. autofunction:: rebuild_kerning_groups