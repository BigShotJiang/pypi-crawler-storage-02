vfbLib.ufo.groups.build\_glyph\_to\_group\_maps
===============================================

.. currentmodule:: vfbLib.ufo.groups

.. autofunction:: build_glyph_to_group_maps