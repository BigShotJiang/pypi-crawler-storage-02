vfbLib.ufo.pshints.normalize\_hint
==================================

.. currentmodule:: vfbLib.ufo.pshints

.. autofunction:: normalize_hint