vfbLib.typing.BitmapDataDict
============================

.. currentmodule:: vfbLib.typing

.. autoclass:: BitmapDataDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BitmapDataDict.__init__
      ~BitmapDataDict.clear
      ~BitmapDataDict.copy
      ~BitmapDataDict.fromkeys
      ~BitmapDataDict.get
      ~BitmapDataDict.items
      ~BitmapDataDict.keys
      ~BitmapDataDict.pop
      ~BitmapDataDict.popitem
      ~BitmapDataDict.setdefault
      ~BitmapDataDict.update
      ~BitmapDataDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BitmapDataDict.flag
      ~BitmapDataDict.data
      ~BitmapDataDict.preview
   
   