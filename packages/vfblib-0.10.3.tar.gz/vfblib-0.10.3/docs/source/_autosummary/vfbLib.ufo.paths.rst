vfbLib.ufo.paths
================

.. automodule:: vfbLib.ufo.paths
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      UfoMasterGlyph
   
   

   
   
   



