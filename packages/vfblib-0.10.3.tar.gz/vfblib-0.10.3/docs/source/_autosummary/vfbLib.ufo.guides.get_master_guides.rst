vfbLib.ufo.guides.get\_master\_guides
=====================================

.. currentmodule:: vfbLib.ufo.guides

.. autofunction:: get_master_guides