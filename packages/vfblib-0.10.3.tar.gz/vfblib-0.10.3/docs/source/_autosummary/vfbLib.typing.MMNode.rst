vfbLib.typing.MMNode
====================

.. currentmodule:: vfbLib.typing

.. autoclass:: MMNode
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MMNode.__init__
      ~MMNode.clear
      ~MMNode.copy
      ~MMNode.fromkeys
      ~MMNode.get
      ~MMNode.items
      ~MMNode.keys
      ~MMNode.pop
      ~MMNode.popitem
      ~MMNode.setdefault
      ~MMNode.update
      ~MMNode.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MMNode.flags
      ~MMNode.points
      ~MMNode.type
   
   