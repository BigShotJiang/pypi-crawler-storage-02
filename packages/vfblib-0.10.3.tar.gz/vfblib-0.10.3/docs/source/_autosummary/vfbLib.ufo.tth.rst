vfbLib.ufo.tth
==============

.. automodule:: vfbLib.ufo.tth
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      get_xml_tth
      set_tth_lib
      transform_stem_rounds
      tt_cmd_dict_to_xml
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      TTGlyphHints
   
   

   
   
   



