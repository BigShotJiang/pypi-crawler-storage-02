vfbLib.tth.extract\_tt\_zone\_deltas
====================================

.. currentmodule:: vfbLib.tth

.. autofunction:: extract_tt_zone_deltas