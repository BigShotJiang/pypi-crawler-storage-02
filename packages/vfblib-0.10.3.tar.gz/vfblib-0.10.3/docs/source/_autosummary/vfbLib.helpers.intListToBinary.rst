vfbLib.helpers.intListToBinary
==============================

.. currentmodule:: vfbLib.helpers

.. autofunction:: intListToBinary