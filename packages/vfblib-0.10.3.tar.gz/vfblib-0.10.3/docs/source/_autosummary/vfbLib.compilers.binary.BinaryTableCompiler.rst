vfbLib.compilers.binary.BinaryTableCompiler
===========================================

.. currentmodule:: vfbLib.compilers.binary

.. autoclass:: BinaryTableCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BinaryTableCompiler.__init__
      ~BinaryTableCompiler.compile
      ~BinaryTableCompiler.compile_hex
      ~BinaryTableCompiler.merge
      ~BinaryTableCompiler.write_bytes
      ~BinaryTableCompiler.write_double
      ~BinaryTableCompiler.write_doubles
      ~BinaryTableCompiler.write_int16
      ~BinaryTableCompiler.write_int32
      ~BinaryTableCompiler.write_str
      ~BinaryTableCompiler.write_str_with_len
      ~BinaryTableCompiler.write_uint16
      ~BinaryTableCompiler.write_uint32
      ~BinaryTableCompiler.write_uint8
      ~BinaryTableCompiler.write_value
   
   

   
   
   