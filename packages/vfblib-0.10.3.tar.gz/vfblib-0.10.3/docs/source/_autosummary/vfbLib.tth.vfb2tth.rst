vfbLib.tth.vfb2tth
==================

.. currentmodule:: vfbLib.tth

.. autofunction:: vfb2tth