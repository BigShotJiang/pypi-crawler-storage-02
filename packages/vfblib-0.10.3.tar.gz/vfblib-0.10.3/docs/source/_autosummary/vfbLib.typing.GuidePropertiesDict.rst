vfbLib.typing.GuidePropertiesDict
=================================

.. currentmodule:: vfbLib.typing

.. autoclass:: GuidePropertiesDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GuidePropertiesDict.__init__
      ~GuidePropertiesDict.clear
      ~GuidePropertiesDict.copy
      ~GuidePropertiesDict.fromkeys
      ~GuidePropertiesDict.get
      ~GuidePropertiesDict.items
      ~GuidePropertiesDict.keys
      ~GuidePropertiesDict.pop
      ~GuidePropertiesDict.popitem
      ~GuidePropertiesDict.setdefault
      ~GuidePropertiesDict.update
      ~GuidePropertiesDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GuidePropertiesDict.h
      ~GuidePropertiesDict.v
   
   