vfbLib.ufo.typing.TUfoStemPPMDict
=================================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoStemPPMDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoStemPPMDict.__init__
      ~TUfoStemPPMDict.clear
      ~TUfoStemPPMDict.copy
      ~TUfoStemPPMDict.fromkeys
      ~TUfoStemPPMDict.get
      ~TUfoStemPPMDict.items
      ~TUfoStemPPMDict.keys
      ~TUfoStemPPMDict.pop
      ~TUfoStemPPMDict.popitem
      ~TUfoStemPPMDict.setdefault
      ~TUfoStemPPMDict.update
      ~TUfoStemPPMDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoStemPPMDict.stem
      ~TUfoStemPPMDict.round
   
   