vfbLib.compilers.glyph.GlobalMaskCompiler
=========================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlobalMaskCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlobalMaskCompiler.__init__
      ~GlobalMaskCompiler.compile
      ~GlobalMaskCompiler.compile_hex
      ~GlobalMaskCompiler.compile_outlines
      ~GlobalMaskCompiler.merge
      ~GlobalMaskCompiler.write_bytes
      ~GlobalMaskCompiler.write_double
      ~GlobalMaskCompiler.write_doubles
      ~GlobalMaskCompiler.write_int16
      ~GlobalMaskCompiler.write_int32
      ~GlobalMaskCompiler.write_str
      ~GlobalMaskCompiler.write_str_with_len
      ~GlobalMaskCompiler.write_uint16
      ~GlobalMaskCompiler.write_uint32
      ~GlobalMaskCompiler.write_uint8
      ~GlobalMaskCompiler.write_value
   
   

   
   
   