vfbLib.ufo.pshints.normalize\_hint\_dict
========================================

.. currentmodule:: vfbLib.ufo.pshints

.. autofunction:: normalize_hint_dict