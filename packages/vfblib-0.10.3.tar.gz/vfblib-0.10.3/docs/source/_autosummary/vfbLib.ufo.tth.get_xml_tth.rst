vfbLib.ufo.tth.get\_xml\_tth
============================

.. currentmodule:: vfbLib.ufo.tth

.. autofunction:: get_xml_tth