vfbLib.compilers.text.NameRecordsCompiler
=========================================

.. currentmodule:: vfbLib.compilers.text

.. autoclass:: NameRecordsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NameRecordsCompiler.__init__
      ~NameRecordsCompiler.compile
      ~NameRecordsCompiler.compile_hex
      ~NameRecordsCompiler.merge
      ~NameRecordsCompiler.write_bytes
      ~NameRecordsCompiler.write_double
      ~NameRecordsCompiler.write_doubles
      ~NameRecordsCompiler.write_int16
      ~NameRecordsCompiler.write_int32
      ~NameRecordsCompiler.write_str
      ~NameRecordsCompiler.write_str_with_len
      ~NameRecordsCompiler.write_uint16
      ~NameRecordsCompiler.write_uint32
      ~NameRecordsCompiler.write_uint8
      ~NameRecordsCompiler.write_value
   
   

   
   
   