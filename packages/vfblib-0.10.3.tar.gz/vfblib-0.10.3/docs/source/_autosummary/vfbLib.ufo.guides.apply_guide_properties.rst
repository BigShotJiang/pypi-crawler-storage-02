vfbLib.ufo.guides.apply\_guide\_properties
==========================================

.. currentmodule:: vfbLib.ufo.guides

.. autofunction:: apply_guide_properties