vfbLib.compilers.truetype.TrueTypeStemPpems23Compiler
=====================================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: TrueTypeStemPpems23Compiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeStemPpems23Compiler.__init__
      ~TrueTypeStemPpems23Compiler.compile
      ~TrueTypeStemPpems23Compiler.compile_hex
      ~TrueTypeStemPpems23Compiler.merge
      ~TrueTypeStemPpems23Compiler.write_bytes
      ~TrueTypeStemPpems23Compiler.write_double
      ~TrueTypeStemPpems23Compiler.write_doubles
      ~TrueTypeStemPpems23Compiler.write_int16
      ~TrueTypeStemPpems23Compiler.write_int32
      ~TrueTypeStemPpems23Compiler.write_str
      ~TrueTypeStemPpems23Compiler.write_str_with_len
      ~TrueTypeStemPpems23Compiler.write_uint16
      ~TrueTypeStemPpems23Compiler.write_uint32
      ~TrueTypeStemPpems23Compiler.write_uint8
      ~TrueTypeStemPpems23Compiler.write_value
   
   

   
   
   