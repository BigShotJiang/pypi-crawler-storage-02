vfbLib.parsers.bitmap.BaseBitmapParser
======================================

.. currentmodule:: vfbLib.parsers.bitmap

.. autoclass:: BaseBitmapParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BaseBitmapParser.__init__
      ~BaseBitmapParser.parse
      ~BaseBitmapParser.parse_hex
      ~BaseBitmapParser.read_double
      ~BaseBitmapParser.read_doubles
      ~BaseBitmapParser.read_int16
      ~BaseBitmapParser.read_int32
      ~BaseBitmapParser.read_int8
      ~BaseBitmapParser.read_str
      ~BaseBitmapParser.read_str_all
      ~BaseBitmapParser.read_str_with_len
      ~BaseBitmapParser.read_uint16
      ~BaseBitmapParser.read_uint32
      ~BaseBitmapParser.read_uint8
      ~BaseBitmapParser.read_value
   
   

   
   
   