vfbLib.parsers.glyph.GlyphUnicodeSuppParser
===========================================

.. currentmodule:: vfbLib.parsers.glyph

.. autoclass:: GlyphUnicodeSuppParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphUnicodeSuppParser.__init__
      ~GlyphUnicodeSuppParser.parse
      ~GlyphUnicodeSuppParser.parse_hex
      ~GlyphUnicodeSuppParser.read_double
      ~GlyphUnicodeSuppParser.read_doubles
      ~GlyphUnicodeSuppParser.read_int16
      ~GlyphUnicodeSuppParser.read_int32
      ~GlyphUnicodeSuppParser.read_int8
      ~GlyphUnicodeSuppParser.read_str
      ~GlyphUnicodeSuppParser.read_str_all
      ~GlyphUnicodeSuppParser.read_str_with_len
      ~GlyphUnicodeSuppParser.read_uint16
      ~GlyphUnicodeSuppParser.read_uint32
      ~GlyphUnicodeSuppParser.read_uint8
      ~GlyphUnicodeSuppParser.read_value
   
   

   
   
   