vfbLib.tth.extract\_truetype\_hinting
=====================================

.. currentmodule:: vfbLib.tth

.. autofunction:: extract_truetype_hinting