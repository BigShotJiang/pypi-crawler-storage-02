vfbLib.compilers.truetype.VdmxCompiler
======================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: VdmxCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VdmxCompiler.__init__
      ~VdmxCompiler.compile
      ~VdmxCompiler.compile_hex
      ~VdmxCompiler.merge
      ~VdmxCompiler.write_bytes
      ~VdmxCompiler.write_double
      ~VdmxCompiler.write_doubles
      ~VdmxCompiler.write_int16
      ~VdmxCompiler.write_int32
      ~VdmxCompiler.write_str
      ~VdmxCompiler.write_str_with_len
      ~VdmxCompiler.write_uint16
      ~VdmxCompiler.write_uint32
      ~VdmxCompiler.write_uint8
      ~VdmxCompiler.write_value
   
   

   
   
   