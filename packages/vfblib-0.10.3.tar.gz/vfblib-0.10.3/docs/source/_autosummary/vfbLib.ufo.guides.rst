vfbLib.ufo.guides
=================

.. automodule:: vfbLib.ufo.guides
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      apply_guide_properties
      get_master_guides
   
   

   
   
   

   
   
   



