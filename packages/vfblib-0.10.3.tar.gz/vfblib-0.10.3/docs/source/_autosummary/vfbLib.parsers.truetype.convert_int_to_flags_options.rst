vfbLib.parsers.truetype.convert\_int\_to\_flags\_options
========================================================

.. currentmodule:: vfbLib.parsers.truetype

.. autofunction:: convert_int_to_flags_options