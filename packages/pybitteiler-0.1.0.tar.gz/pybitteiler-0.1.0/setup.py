import os
import subprocess
import shutil
from setuptools import setup, find_packages, Extension
from setuptools.command.build_ext import build_ext

class CMakeBuild(build_ext):
    def run(self):
        build_dir = os.path.abspath("build")
        os.makedirs(build_dir, exist_ok=True)

        # Set compiler environment
        os.environ["CC"] = "gcc-10"
        os.environ["CXX"] = "g++-10"

        # First CMake configure (logging disabled, big endian)
        subprocess.check_call([
            "cmake", "-G", "Unix Makefiles",
            "-B", build_dir,
            "-DCMAKE_BUILD_TYPE=Debug",
            "-DBITTEILER_LOG_DISABLE=True",
            "-DBITTEILER_BYTE_ORDER_BIG_ENDIAN=True"
        ])

        # Second CMake configure (logging enabled, little endian)
        subprocess.check_call([
            "cmake", "-G", "Unix Makefiles",
            "-B", build_dir,
            "-DCMAKE_BUILD_TYPE=Debug",
            "-DBITTEILER_LOG_LEVEL=3",
            "-DBITTEILER_BYTE_ORDER_BIG_ENDIAN=False",
            "-DBITTEILER_LOG_TARGET=stderr",
            "-DPython3_FIND_STRATEGY=LOCATION"
        ])

        # Clean and build
        subprocess.check_call(["make", "clean"], cwd=build_dir)
        subprocess.check_call(["make"], cwd=build_dir)

        # Find the shared library
        for file in os.listdir(build_dir):
            if file.endswith(".so") and "bitteiler" in file:
                lib_file = file
                break
        else:
            raise RuntimeError("Shared library not found in build/")

        # Copy .so into py/pycode
        dst_path = os.path.join(os.path.abspath("py/pybitteiler"), lib_file)
        shutil.copy(os.path.join(build_dir, lib_file), dst_path)

        super().run()

setup(
    name="pybitteiler",
    version="0.1.0",
    packages=find_packages(where="py"),
    package_dir={"": "py"},
    cmdclass={"build_ext": CMakeBuild},
)
