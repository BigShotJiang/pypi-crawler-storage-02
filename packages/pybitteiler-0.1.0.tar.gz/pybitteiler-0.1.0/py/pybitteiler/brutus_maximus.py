import numpy as np
import sys
import ctypes
import bitteiler
import multiprocessing
import scipy.stats as ss
from itertools import product

def test_comp_worker(args):
    """
    Worker function to compress and decompress packets using a given profile.
    Expects a tuple of:
      (profile, packets, tail_len, head_len, surpressStatus, threadId, perPktStatus)
    Returns a tuple with:
      (success, profile, avg_compressed_length, savings, list_of_pkt_sizes, stddev, conf_int)
    """
    profile, packets, tail_len, head_len, surpressStatus, threadId, perPktStatus = args
    co_pkt_sizes = []
    cid = 0x00
    try:
        compressor = bitteiler.compressor(profile, cid)
        decompressor = bitteiler.decompressor(profile, cid)
    except Exception as e:
        print("Initialization failure:", e)
        return (False, profile, 0.0, -1.0, None, None, None)

    for l, ucPkt in enumerate(packets):
        if not surpressStatus:
            if perPktStatus and l % 100 == 0:
                print(f"Thread {threadId}: Packet {l}/{len(packets)}", end="\r")
            elif not perPktStatus and l % (max(len(packets)//10, 1)) == 0:
                print(f"Thread {threadId}: {int(l/len(packets)*100)}% processed")
        coPkt = ucPkt[:]  # copy of the packet
        try:
            retComp = compressor.compress(coPkt, head_len, tail_len)
        except Exception as e:
            raise Exception(f"Packet {l} failed compression: {e}")

        dePkt = coPkt[retComp[1]:len(coPkt)]
        coPkt = coPkt[retComp[1]:retComp[2]+retComp[1]]
        co_pkt_sizes.append(len(coPkt))
        try:
            retDecomp = decompressor.decompress(dePkt, len(dePkt), len(coPkt))
        except Exception as e:
            raise Exception(f"Packet {l} failed decompression: {e}")
        dePkt = dePkt[:retDecomp[1]]
        if len(dePkt) != len(ucPkt) - head_len:
            print(f"Thread {threadId}: Length mismatch: {len(dePkt)} vs {len(ucPkt)-head_len}")
            return (False, profile, 0.0, -1.0, None, None, None)
        for j in range(len(dePkt)):
            if ucPkt[head_len+j] != dePkt[j]:
                raise Exception(f"Thread {threadId}: Packet {l} decompressed incorrectly!")
    
    pktSzStdDev = np.std(co_pkt_sizes)
    # Using degrees-of-freedom = (n-1) for t-distribution:
    pktSzConfInt = ss.t.ppf(0.95, max(len(co_pkt_sizes)-1, 1)) * pktSzStdDev
    avg_len = np.average(co_pkt_sizes)
    savings = 1.0 - avg_len / tail_len if tail_len != 0 else 0.0
    return (True, profile, avg_len, savings, co_pkt_sizes, pktSzStdDev, pktSzConfInt)


class brutus_maximus:
    def __init__(self, threads=4, pool_size=1, fields=2,
                 fld_lens=(0, 1, 2, 3, 4), flds=('o', 'b', 'l'),
                 tail_len=100, head_len=4):
        self.threads = threads
        self.tail_len = tail_len
        self.head_len = head_len
        self.pool_size = pool_size
        self.fields = fields
        self.fld_lens = fld_lens
        self.flds = flds
        self.results = []

    def test(self, profile, df, surpressStatus=True):
        """
        Run a single compression test on the provided dataset (df) using the given profile.
        Uses a process pool (with 'threads' workers) to run the worker function.
        """
        args = (profile, df, self.tail_len, self.head_len, surpressStatus, 0, True)
        with multiprocessing.Pool(self.threads) as pool:
            result = pool.apply(test_comp_worker, (args,))
        self.results.append(result)
        return result

    def test_multiple(self, profile, df_list, surpressStatus=True):
        """
        Run compression tests concurrently over multiple datasets.
        """
        args_list = [(profile, df, self.tail_len, self.head_len, surpressStatus, idx, False)
                     for idx, df in enumerate(df_list)]
        with multiprocessing.Pool(self.threads) as pool:
            results = pool.map(test_comp_worker, args_list)
        self.results.extend(results)
        valid_results = [r for r in results if r[0]]
        if not valid_results:
            raise Exception("No tests succeeded.")
        avgCoPktLen = np.mean([r[2] for r in valid_results])
        savings = np.mean([r[3] for r in valid_results])
        return (True, profile, avgCoPktLen, savings)

    def __brute_co_pkt_dsc(self, num_fields, meta="$8c$0s$8p",
                           dscs=("%0o", "%1o", "%2o", "%3o", "%4o")):
        test_set = [dscs for _ in range(num_fields)]
        mat = np.array(np.meshgrid(*test_set)).T.reshape(-1, num_fields)
        return [meta + ''.join(k.tolist()) for k in mat]

    def __validate_and_filter_combos(self, all_dsc_combos, filter_non_zero_octets=True):
        valid_combos = []
        for combo in all_dsc_combos:
            bit_counter = 0
            omit = False
            for i in range(len(combo)):
                if combo[i] == '$':
                    if combo[i+1] == '0':
                        bit_counter += 16
                    elif combo[i+1].islower():
                        bit_counter += ord(combo[i+1]) - ord('a') + 10
                    else:
                        bit_counter += ord(combo[i+1]) - ord('0')
                elif combo[i] == '%':
                    if combo[i+2] != 'o':
                        if combo[i+1].islower():
                            bit_counter += ord(combo[i+1]) - ord('a') + 10
                        else:
                            bit_counter += ord(combo[i+1]) - ord('0')
                    elif combo[i+1] != '0' and filter_non_zero_octets:
                        omit = True
                        break
            if bit_counter % 8 == 0 and not omit:
                valid_combos.append(combo)
        return valid_combos

    def train(self, df, meta="$8c$0s$8p", profile_postfix=""):
        """
        Brute-force search for the best compression profile.
        Generates candidate profiles from descriptor combinations, evaluates them concurrently
        using a process pool, and returns the candidate with the highest savings.
        """
        # Generate candidate descriptors based on field lengths and symbols.
        mat = np.array(np.meshgrid(self.fld_lens, self.flds)).T.reshape(-1, 2)
        dscs = ['%' + ''.join(k.tolist()) for k in mat]
        all_dsc_combos = self.__brute_co_pkt_dsc(self.fields, dscs=dscs, meta=meta)
        valid_combos = self.__validate_and_filter_combos(all_dsc_combos)

        # Build candidate profiles. For pool_size==1, each candidate is just one descriptor.
        if self.pool_size == 1:
            candidate_profiles = ["|" + combo for combo in valid_combos]
        else:
            candidate_profiles = []
            for combo in product(valid_combos, repeat=self.pool_size):
                if len(set(combo)) < self.pool_size:
                    continue  # skip duplicate entries
                candidate_profiles.append("|" + "|".join(combo))
        
        # Prepare arguments for the pool
        args_list = [(profile + profile_postfix, df, self.tail_len, self.head_len, True, idx, False)
                     for idx, profile in enumerate(candidate_profiles)]
        with multiprocessing.Pool(self.threads) as pool:
            results = pool.map(test_comp_worker, args_list)
        self.results.extend(results)
        
        # Optionally, back up results to file
        with open('backup.txt', 'w') as f:
            for r in results:
                f.write(f"{r[0]},{r[1]},{r[2]},{r[3]}\n")
        
        # Choose the best candidate based on the highest savings value.
        bestR = None
        bestSv = -1.0
        for r in results:
            if r[0] and r[3] > bestSv:
                bestSv = r[3]
                bestR = r
        return bestR

    def train_pool_3(self, df, meta="$8c$0s$8p", profile_postfix=""):
        """
        Similar to train(), but specifically for a pool size of 3.
        """
        if self.pool_size != 3:
            raise Exception("Pool size must be exactly 3!")
        mat = np.array(np.meshgrid(self.fld_lens, self.flds)).T.reshape(-1, 2)
        dscs = ['%' + ''.join(k.tolist()) for k in mat]
        all_dsc_combos = self.__brute_co_pkt_dsc(self.fields, dscs=dscs, meta=meta)
        valid_combos = self.__validate_and_filter_combos(all_dsc_combos)

        candidate_profiles = []
        for combo in product(valid_combos, repeat=3):
            if len(set(combo)) < 3:
                continue
            candidate_profiles.append("|" + "|".join(combo))
        
        args_list = [(profile + profile_postfix, df, self.tail_len, self.head_len, True, idx, False)
                     for idx, profile in enumerate(candidate_profiles)]
        with multiprocessing.Pool(self.threads) as pool:
            results = pool.map(test_comp_worker, args_list)
        self.results.extend(results)
        
        bestR = None
        bestSv = -1.0
        for r in results:
            if r[0] and r[3] > bestSv:
                bestSv = r[3]
                bestR = r
        return bestR
