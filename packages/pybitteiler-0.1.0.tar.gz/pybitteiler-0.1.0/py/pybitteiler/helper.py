""" ---------------------------------------------------------------------------

 Copyright (C) bitteiler GmbH 2023 * ALL RIGHTS RESERVED

 This software is protected by the inclusion of the above copyright
 notice. This software may not be provided or otherwise made available
 to, or used by, any other person. No title to or ownership of the
 software is  hereby  transferred.
 The information contained in this document is considered the
 CONFIDENTIAL and PROPRIETARY information of bitteiler GmbH and may
 not be disclosed or discussed with anyone who is not employed by
 bitteiler GmbH, unless the individual / company
 (i) has an express need to know such information, and
 (ii) disclosure of information is subject to the terms of a duly
 executed Confidentiality and Non-Disclosure Agreement between
 bitteiler GmbH and the individual / company.

 -------------------------------------------------------------------------- """


def split(df, train_prop=0.20):
    train_sz = int(len(df)*train_prop)
    return (df[:train_sz], df[train_sz:])