""" ---------------------------------------------------------------------------

 Copyright (C) bitteiler GmbH 2023 * ALL RIGHTS RESERVED

 This software is protected by the inclusion of the above copyright
 notice. This software may not be provided or otherwise made available
 to, or used by, any other person. No title to or ownership of the
 software is  hereby  transferred.
 The information contained in this document is considered the
 CONFIDENTIAL and PROPRIETARY information of bitteiler GmbH and may
 not be disclosed or discussed with anyone who is not employed by
 bitteiler GmbH, unless the individual / company
 (i) has an express need to know such information, and
 (ii) disclosure of information is subject to the terms of a duly
 executed Confidentiality and Non-Disclosure Agreement between
 bitteiler GmbH and the individual / company.

 -------------------------------------------------------------------------- """


import numpy as np
import sys
import ctypes
import bitteiler
import multiprocessing
import scipy.stats as ss

class brutus:
    __threads = 1
    __thread_list = []
    __thread_results = []
    __tail_len = 0
    __head_len = 4
    __pool_size = 1
    __fields = 2
    __fld_lens = (0, 1, 2, 3, 4)
    __flds = ('o', 'b', 'l')
    
    def __init__(self, threads=1, pool_size=1, fields=2, fld_lens=(0, 1, 2, 3, 4), flds=('o', 'b', 'l'), tail_len=0, head_len=4):
        self.__threads = threads
        self.__tail_len = tail_len
        self.__head_len = head_len
        self.__pool_size = pool_size
        self.__fields = fields
        self.__fld_lens = fld_lens
        self.__flds = flds
    
    """
    def __check_decompression(ucPkt, dePkt):
        for j in range(0, len(dePkt)):
            if ucPkt[headLen+j] != dePkt[j]:
                raise Exception("Index " + str(j) + " failed decompression in packet " 
                    + str(i) + " (" + str(ucPkt[headLen+j]) + "!=" + str(dePkt[j]) + ")")
   """
                
    def test(self, profile, df, surpressStatus=True):      
        self.__thread_list = []
        x = brutus.__TestCompressionProcess(profile, df, tail_len=self.__tail_len, surpressStatus=surpressStatus, perPktStatus=True)
        self.__thread_list.append(x)
        x.start()

        ret = []
        for index, thread in enumerate(self.__thread_list):
            thread.join()

            if thread.exception.value == True:
                raise Exception("Exception raised in subprocess...")
            else:
                ret = (thread.success.value,
                    thread.profile.value,
                    thread.avgCoPktLen.value,
                    thread.savings.value,
                    thread.coPktLenStdDev.value,
                    thread.coPktLenConfInt.value)
                self.__thread_results.append(ret)
            thread.close()
        return ret
    
    def test_multiple(self, profile, df_list, surpressStatus=True):
        print(len(df_list))
        self.__thread_list = []
        for df in df_list:
            x = brutus.__TestCompressionProcess(profile, df, tail_len=self.__tail_len, surpressStatus=surpressStatus, threadId=len(self.__thread_list))
            self.__thread_list.append(x)
            x.start()

        ret = []
        for index, thread in enumerate(self.__thread_list):
            thread.join()

            if thread.exception.value == True:
                raise Exception("Exception raised in subprocess...")
            else:
                ret.append([thread.success.value,
                    thread.profile.value,
                    thread.avgCoPktLen.value,
                    thread.savings.value,
                    thread.coPktLenStdDev.value,
                    thread.coPktLenConfInt.value])
                self.__thread_results.append(ret)
            thread.close()

        retMean = ret[0]
        for r in range(1, len(ret)):
            if retMean[0] == False or ret[r][0]:
                retMean[0] == False    
            retMean[2] += ret[r][2]
            retMean[3] += ret[r][3]
            retMean[4] += ret[r][4]
            retMean[5] += ret[r][5]
        retMean[2] /= len(ret)
        retMean[3] /= len(ret)
        retMean[4] /= len(ret)
        retMean[5] /= len(ret)

        return retMean

    class __TestCompressionProcess(multiprocessing.Process):
        __tail_len = 0
        __head_len = 4
        __profile = None
        __packets = None
        __surpressStatus = None
        __threadId = 0
        __per_packet_status = False
        
        success = None
        profile = None
        avgCoPktLen = None
        savings = None
        exception = None
        coPktLenStdDev = None
        coPktLenConfInt = None
        
        # override the constructor
        def __init__(self,  profile, packets, tail_len, head_len=4, surpressStatus=True, threadId=0, perPktStatus=False):
            # execute the base constructor
            multiprocessing.Process.__init__(self)
            # initialize integer attribute
            self.success = multiprocessing.Value(ctypes.c_bool, False)
            self.profile = multiprocessing.Array('c', str.encode(profile))
            self.avgCoPktLen = multiprocessing.Value('f', 0.0)
            self.savings = multiprocessing.Value('f', 0.0)
            self.exception = multiprocessing.Value(ctypes.c_bool, False)
            self.coPktLenStdDev = multiprocessing.Value('f', 0.0)
            self.coPktLenConfInt = multiprocessing.Value('f', 0.0)
            
            self.__tail_len = tail_len
            self.__head_len = head_len
            self.__profile = profile
            self.__packets = packets
            self.__surpress_status = surpressStatus
            self.__thread_id = threadId
            self.__per_packet_status = perPktStatus

        # override the run function
        def run(self):
            try:
                ret = self.__test_comp(self.__profile, self.__packets, self.__surpress_status, self.__thread_id, self.__per_packet_status)
            except Exception as e:
                print(e)
                sys.stdout.flush()
                self.exception.value = True
                return
            
            self.success.value = ret[0]
            self.profile.value = str.encode(ret[1])
            self.avgCoPktLen.value = ret[2]
            self.savings.value = ret[3]
            self.coPktLenStdDev.value = ret[5]
            self.coPktLenConfInt.value = ret[6]
        
        def __test_comp(self, profile, packets, surpressStatus=True, threadId=0, perPktStatus=False):
            co_pkt_sizes = [ ]
            cid = 0x00
            c = None
            d = None
            try:
                c = bitteiler.compressor(profile, cid)
                d = bitteiler.decompressor(profile, cid)
            except Exception as e:
                print("init fail " + str(e))
                return (False, profile, 0.0, -1.0)

            for l in range(0, len(packets)):
                ucPkt = packets[l]

                if surpressStatus == False:
                    if perPktStatus == True and l % 100 == 0:
                        print("Packet " + str(l) + "/" + str(len(packets))
                            + " (" + str(int(round(l / len(packets), 2) * 100)) +"%) -> " 
                            + ("?" if len(co_pkt_sizes) == 0 else str(round(1.0 
                                    - np.average(co_pkt_sizes) / self.__tail_len, 3))), end="\r")
                    elif perPktStatus == False and l % (len(packets)//10) == 0:
                        print("#" + str(threadId) + " -> " + str(l // (len(packets)//10) * 10) + "%\n")
                coPkt = ucPkt[:]

                retComp = None
                try:
                    retComp = c.compress(coPkt, self.__head_len, self.__tail_len)
                except Exception as e:
                    raise Exception("Packet " + str(l) + " failed compression with\n"
                        + "\tucPkt: " + str(ucPkt) + "(" + str(len(ucPkt)) + ")"
                        + "\n\tProfile = " + str(profile) 
                        + "\n\tCompressor returned = " + str(retComp)
                        + "\n")
                
                dePkt = coPkt[retComp[1]:len(coPkt)]
                coPkt = coPkt[retComp[1]:retComp[2]+retComp[1]]
                co_pkt_sizes.append(len(coPkt))

                try:
                    retDecomp = d.decompress(dePkt, len(dePkt), len(coPkt))
                except Exception as e:
                    raise Exception("Packet " + str(l) + " failed decompression with\n"
                        + "\tucPkt: " + str(ucPkt) + "(" + str(len(ucPkt)) + ")"
                        + "\n\tcoPkt: " + str(coPkt) + "(" + str(len(coPkt)) + ")"
                        + "\n\tProfile = " + str(profile) 
                        + "\n\tCompressor returned = " + str(retComp)
                        + "\n\tDecompressor returned = " + str(retDecomp)
                        + "\n")

                dePkt = dePkt[:retDecomp[1]]
                if len(dePkt) != len(ucPkt)-self.__head_len:
                    print("lengths don't match " + str(len(dePkt)) + " vs. " + str(len(ucPkt)-self.__head_len))
                    return (False, profile, 0.0, -1.0)

                for j in range(0, len(dePkt)):
                    if ucPkt[self.__head_len+j] != dePkt[j]:
                        raise Exception("Packet " + str(l) + " returned wrong decompressed packet!\n"
                            + "\tucPkt: " + str(ucPkt) + "(" + str(len(ucPkt)) + ")"
                            + "\n\tcoPkt: " + str(coPkt) + "(" + str(len(coPkt)) + ")"
                            + "\n\tdePkt: " + str(dePkt) + "(" + str(len(dePkt)) + ")"
                            + "\n\tProfile = " + str(profile) 
                            + "\n\tCompressor returned = " + str(retComp)
                            + "\n\tDecompressor returned = " + str(retDecomp)
                            + "\n")

            if not surpressStatus:
                d.stats()

            pktSzStdDev = np.std(co_pkt_sizes)
            pktSzConfInt = ss.t.ppf(0.95, np.average(co_pkt_sizes))* pktSzStdDev
            return (True, profile, np.average(co_pkt_sizes), 1.0 - np.average(co_pkt_sizes) / self.__tail_len, co_pkt_sizes, pktSzStdDev, pktSzConfInt)

    def __brute_co_pkt_dsc(self, num_fields, meta="$8c$0s$8p", dscs=("%0o", "%1o", "%2o", "%3o", "%4o")):
        test_set = []
        for l in range(0, num_fields):
            test_set.append(dscs)

        mat = np.array(np.meshgrid(*test_set)).T.reshape(-1, num_fields)
        dsc_strs =[]
        for k in mat:
            dsc_strs.append(meta + ''.join(k.tolist()))
            
        return dsc_strs
    
    def __validate_and_filter_combos(self, all_dsc_combos, filter_non_zero_octets=True):
        valid_combos = []
        for k in all_dsc_combos:
            # check if octet aligned
            bitCntr = 0
            omit = False
            _0oCntr = 0
            for i in range(0, len(k)):
                # meta
                if k[i] == '$':
                    if k[i+1] == '0':
                        bitCntr += 16
                    if ord(k[i+1]) >= ord('a'):
                        bitCntr += ord(k[i+1]) - ord('a') + 10
                    else:
                        bitCntr += ord(k[i+1]) - ord('0')
                elif k[i] == '%':
                    # only for bit or lsb
                    if k[i+2] != 'o':
                        if ord(k[i+1]) >= ord('a'):
                            bitCntr += ord(k[i+1]) - ord('a') + 10
                        else:
                            bitCntr += ord(k[i+1]) - ord('0')
                    elif k[i+1] != '0' and filter_non_zero_octets == True:
                        omit = True
                        break
                    elif k[i+1] == '0':
                        _0oCntr += 1
                        #if _0oCntr > 2:
                        #    omit = True
                        #    break
                    #elif bitCntr % 8 != 0:
                    #    # octet follows not aligned bit or lsb
                    #    # REMOVE THIS ONCE PACKING IS IMPLEMENTED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    #    break

            if bitCntr % 8 == 0 and omit != True:
                valid_combos.append(k)
            #else:
            #    print(str(k) + " discarded")
            
        return valid_combos

    def train(self, df, meta="$8c$0s$8p", profile_postfix=""):
        with open('backup.txt', 'w', buffering=1) as f:
            self.__thread_results = []
            mat = np.array(np.meshgrid(self.__fld_lens, self.__flds)).T.reshape(-1, 2)
            dscs =[]
            for k in mat:
                dscs.append('%' + ''.join(k.tolist()))
            all_dsc_combos = self.__brute_co_pkt_dsc(self.__fields, dscs=dscs, meta=meta)
            
            valid_combos = self.__validate_and_filter_combos(all_dsc_combos)
            
            pool = []
            for l in range(0, self.__pool_size):
                pool.append(valid_combos)

            all_mats = np.array(np.meshgrid(*pool)).T.reshape(-1, self.__pool_size)
            alls = []
            for i in range(0, len(all_mats)):
                prof = []
                for j in range(0, self.__pool_size):
                    prof.append("|" + all_mats[i, j])
                alls.append(''.join(prof))
                
            pool = multiprocessing.Pool(self.__threads)
            for i in range(0, len(alls), self.__threads):
                print("Iteration " + str(i) + "/" + str(len(alls))
                    + " (" + str(int(round(i / len(alls), 2) * 100)) +"%)", end="\r")
                sys.stdout.flush()
                self.__thread_list = []
                for j in range(0, min(self.__threads, len(alls)-i)):
                    m = alls[i+j]
                    x = brutus.__TestCompressionProcess(m + profile_postfix, df, tail_len=self.__tail_len)
                    self.__thread_list.append(x)
                    x.start()
                    
                for index, thread in enumerate(self.__thread_list):
                    thread.join()

                    if thread.exception.value == True:
                        raise Exception("Exception raised in subprocess...")
                    else:
                        ret = (thread.success.value,
                            thread.profile.value.decode(),
                            thread.avgCoPktLen.value,
                            thread.savings.value)
                        self.__thread_results.append(ret)
                        f.write(str(ret[0]) + "," 
                                + str(ret[1]) + "," 
                                + str(ret[2]) + "," 
                                + str(ret[3]) + '\n')
                    thread.close()
                
            print("Iteration " + str(len(alls)) + "/" + str(len(alls)) 
                + " (" + str(int(round(len(alls) / len(alls), 2) * 100)) +"%)", end="\r")
                    
            bestSv = -1.0
            bestR = None
            for r in self.__thread_results:
                if r[0] == True:
                    if bestSv < r[3]:
                        bestSv = r[3]
                        bestR = r
        return bestR

    def train_pool_3(self, df, meta="$8c$0s$8p", profile_postfix=""):
        if self.__pool_size != 3:
            raise Exception("Pool size must be exactly 3!")

        self.__thread_results = []
        mat = np.array(np.meshgrid(self.__fld_lens, self.__flds)).T.reshape(-1, 2)
        dscs =[]
        for k in mat:
            dscs.append('%' + ''.join(k.tolist()))
        all_dsc_combos = self.__brute_co_pkt_dsc(self.__fields, dscs=dscs, meta=meta)
        
        valid_combos = self.__validate_and_filter_combos(all_dsc_combos)
        
        #pool = []
        #for l in range(0, self.__pool_size):
        #    pool.append(valid_combos)

        #all_mats = np.array(np.meshgrid(*pool)).T.reshape(-1, self.__pool_size - 2)
        #alls = []
        #for i in range(0, len(all_mats)):
        #    prof = []
        #    for j in range(0, self.__pool_size):
        #        prof.append("|" + all_mats[i, j])
        #    alls.append(''.join(prof))

        #print(type(valid_combos))
        #print(valid_combos)

        allCnt = len(valid_combos)**3
        for i in range(0, len(valid_combos)):
            for j in range(0, len(valid_combos)):
                thread_pool = multiprocessing.Pool(self.__threads)
                for k in range(0, len(valid_combos), self.__threads):
                        currentCnt = k + j * len(valid_combos) + i * len(valid_combos)**2
                        print("Iteration " + str(currentCnt) + "/" + str(allCnt)
                            + " (" + str(int(round((currentCnt) / allCnt, 2) * 100)) +"%)", end="\r")
                        sys.stdout.flush()

                        self.__thread_list = []
                        for l in range(0, min(self.__threads, len(valid_combos)-k)):
                            # exclude same pkt
                            if i == j or i == k or j == l:
                                continue

                            m = "|" + valid_combos[i] + "|" + valid_combos[j] + "|" + valid_combos[l]
                            x = brutus.__TestCompressionProcess(m + profile_postfix, df, tail_len=self.__tail_len)
                            self.__thread_list.append(x)
                            x.start()

                        for index, thread in enumerate(self.__thread_list):
                            thread.join()

                            if thread.exception.value == True:
                                raise Exception("Exception raised in subprocess...")
                            else:
                                ret = (thread.success.value,
                                    thread.profile.value.decode(),
                                    thread.avgCoPktLen.value,
                                    thread.savings.value)
                                self.__thread_results.append(ret)
                            thread.close()

        # last print
        print("Iteration " + str(allCnt) + "/" + str(allCnt) + " (100%)", end="\r")
                
        bestSv = -1.0
        bestR = None
        for r in self.__thread_results:
            if r[0] == True:
                if bestSv < r[3]:
                    bestSv = r[3]
                    bestR = r
                    
        return bestR
