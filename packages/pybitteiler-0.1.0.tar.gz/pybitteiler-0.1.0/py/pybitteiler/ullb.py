""" ---------------------------------------------------------------------------

 Copyright (C) bitteiler GmbH 2023 * ALL RIGHTS RESERVED

 This software is protected by the inclusion of the above copyright
 notice. This software may not be provided or otherwise made available
 to, or used by, any other person. No title to or ownership of the
 software is  hereby  transferred.
 The information contained in this document is considered the
 CONFIDENTIAL and PROPRIETARY information of bitteiler GmbH and may
 not be disclosed or discussed with anyone who is not employed by
 bitteiler GmbH, unless the individual / company
 (i) has an express need to know such information, and
 (ii) disclosure of information is subject to the terms of a duly
 executed Confidentiality and Non-Disclosure Agreement between
 bitteiler GmbH and the individual / company.

 -------------------------------------------------------------------------- """


import struct
import decimal
import numpy as np
import sklearn.metrics


class ullb256:
    __num_bytes = 8
    
    __digits = 0
    __exponent = 0
    __frac = 16
    __prev_val = 0.0
    
    def train(self, s, frac=16):
        self.__digits = 0
        self.__exponent = 0
        self.__frac = frac
        for m in s:
            n = m
            e = 0
            while not (n < 1.0 and n > -1.0):
                n /= 10.0
                e += 1
            n = round(n, self.__frac + e)
            digits = str(n)[::-1].find('.')
            if digits > self.__digits:
                self.__digits = digits
                self.__exponent = e
        #self.__num_bytes = 
        """
        m, e = np.frexp(s)
        self.__digits = 0
        self.__exponent = 0
        for i in range(0, len(m)):
            digits = str(m[i])[::-1].find('.')
            if digits > self.__digits:
                self.__digits = digits
                self.__exponent = e[i]
        """

    def get_energy_from_df(self, s, df_column):
        total = self.__num_bytes * 8
        old = [0] * 8 * self.__num_bytes
        energy = [1] * 8 * self.__num_bytes
        newUllb = self.d2ullb(s.iloc[0][df_column])
        for B in range(0, self.__num_bytes):
            new = newUllb[B]
            for b in range(0, 8):
                old[B * 8 + 7-b] = new & 0x01
                new >>= 1

        for i in range(1, len(s)):
            diff = [0] * 8 * self.__num_bytes
            newUllb = self.d2ullb(s.iloc[i][df_column])
            for B in range(0, self.__num_bytes):
                #print(dfDat.iloc[i].Temp)
                new = newUllb[B]
                for b in range(0, 8):
                    #print(str(old[B * 8 + 7-b]) + " ? " + str(new & 0x01))
                    if old[B * 8 + 7-b] != (new & 0x01):
                        diff[B * 8 + 7-b] = 1
                        energy[B * 8 + 7-b] += 1
                        total += 1
                    new >>= 1
        return [round(e / total, 2) for e in energy]
        #return energy

    def set_num_bytes(self, num_bytes):
        if num_bytes > 8:
            raise Exception("NUM_BYTES forced to a value larger then 8!")
        self.__num_bytes = num_bytes

    def set(self, digits, exponent, num_bytes=8):
        if digits <= 0:
            raise Exception("digits has to be non-zero, non-negative integer!")
        self.__digits = digits
        self.__exponent = exponent
        if num_bytes > 8:
            raise Exception("NUM_BYTES forced to a value larger then 8!")
        self.__num_bytes = num_bytes
                
    def test(self, s, hp_tresh=0.0):
        a = self.d2ullb_array(s, hp_tresh)
        b = self.ullb2d_array(a)

        return (sklearn.metrics.mean_squared_error(s, b), 
                sklearn.metrics.max_error(s, b),
                sklearn.metrics.r2_score(s, b),
                (self.__digits, self.__exponent))
    
    def d2ullb(self, num_f, hp_tresh=0.0):
        #m = num_f / 2 ** self.__exponent
        #m = num_f / np.float_power(2, self.__exponent)
        if abs(num_f - self.__prev_val) < hp_tresh:
            num_f = self.__prev_val

        m = num_f / np.float_power(10, self.__exponent)
        num_ll = int(m * 10 ** self.__digits)
        num_ull = num_ll + 2 ** (self.__num_bytes * 8) // 2
        if num_ull > 2 ** (self.__num_bytes * 8):
            msg = str(num_f) + " won't fit (" + str(2 ** (self.__num_bytes * 8)) + ")"
            raise Exception(msg)
        num_b = 0
        if self.__num_bytes > 4:
            num_b = struct.pack('>Q', num_ull)
        elif self.__num_bytes > 2:
            num_b = struct.pack('>L', num_ull)
        elif self.__num_bytes > 1:
            num_b = struct.pack('>H', num_ull)
        else:
            num_b = struct.pack('>B', num_ull)
        self.__prev_val = num_f
        return num_b

    def d2ullb_array(self, a, hp_tresh=0.0):
        ret = []
        for i in range(0, len(a)):
            ret.append(self.d2ullb(a[i], hp_tresh))
        return ret

    def ullb2d(self, num_b):
        num_ull = 0
        if self.__num_bytes > 4:
            num_ull = struct.unpack('>Q', num_b)[0]
        elif self.__num_bytes > 2:
            num_ull = struct.unpack('>L', num_b)[0]
        elif self.__num_bytes > 1:
            num_ull = struct.unpack('>H', num_b)[0]
        else:
            num_ull = struct.unpack('>B', num_b)[0]
        num_ll = num_ull - 2 ** (self.__num_bytes * 8) // 2
        #num_dec = decimal.Decimal(num_ll) / 10 ** (self.__digits)
        num_float = num_ll / 10 ** (self.__digits)
        #return float(num_dec * 2 ** self.__exponent)
        #return float(num_float * np.float_power(2, self.__exponent))
        return round(float(num_float * np.float_power(10, self.__exponent)), self.__frac)
    
    def ullb2d_array(self, b):
        ret = []
        for i in range(0, len(b)):
            ret.append(self.ullb2d(b[i]))
        return ret
    