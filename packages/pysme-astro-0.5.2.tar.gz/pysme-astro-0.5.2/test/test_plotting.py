# -*- coding: utf-8 -*-
# TODO implement plotting tests

# Just test that the import works
import pysme.gui
