"""
MCP Proxy Adapter Examples

This package contains examples and templates for using the MCP Proxy Adapter framework.
"""

__version__ = "1.0.0" 