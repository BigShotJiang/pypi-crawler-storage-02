To configure this module, you need to:

1.  Go to User and set group User or Manager Financial Risk
2.  Go to *Invoicing/Accounting \> Configuration \> Settings \>
    Accounting*
3.  In the *Customer Payments* section, fill *Maturity Margin* for
    setting the number of days to last after the due date to consider an
    invoice as unpaid.
