# sage_setup: distribution = sagemath-categories
