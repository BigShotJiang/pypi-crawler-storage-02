# User Guide

Welcome to the DiracX user guide. This page gives an overview of how use DIRAC to access compute and storage available on the grid. Before you get started it's important that you know which installation you'll be interacting with. You can find some guidance for that in the [known installations](./reference/known-installations.md).
