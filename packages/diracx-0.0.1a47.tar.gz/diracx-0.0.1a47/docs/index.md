______________________________________________________________________

title: Home
hide:

- navigation
- toc

______________________________________________________________________

<style>
html, body {
  height: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}
.md-content__inner {
  margin-top: 0 !important;
  padding-top: 0 !important;
  margin-bottom: 0 !important;
  padding-bottom: 0 !important;
}
.full-width-content {
  position: absolute;
  top: 48px; /* Hauteur de la barre d'onglets */
  bottom: 0;
  left: 0;
  right: 0;
  overflow: hidden;
}
.full-width-content iframe {
  width: 100%;
  height: 100%;
  border: none;
  display: block;
}
</style>

<div class="full-width-content">
  <iframe
    src="assets/home.html"
    style="width: 100%; height: 100%; border: none; display: block;">
  </iframe>
</div>
