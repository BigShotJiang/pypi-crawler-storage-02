### Settings

Unlike in DIRAC, DiracX separates some information from the "Configuration" (e.g. secrets).
To access this information you depend on the `SettingsClass.create` method which returns a cached instance of the given class.

TODO; add to existing settings, add new setting classes
