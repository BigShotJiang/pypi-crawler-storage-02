~~~json
{
    "memories_deleted": "{{memory_count}}"
}
~~~