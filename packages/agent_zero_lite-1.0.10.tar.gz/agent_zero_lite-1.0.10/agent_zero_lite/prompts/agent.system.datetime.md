# Current system date and time of user
- current datetime: {{date_time}}
- rely on this info always up to date
