~~~json
{
    "memory": "No memories found for specified query: {{query}}"
}
~~~