# SPDX-FileCopyrightText: Copyright (c) 2019-2025, NVIDIA CORPORATION & AFFILIATES.
# SPDX-License-Identifier: Apache-2.0

import importlib
import math
import operator
import os
import pickle
import time
import warnings
from contextlib import suppress
from functools import singledispatch
from multiprocessing import cpu_count
from typing import Optional

import click
import numpy as np
import pynvml
import toolz

import dask
import distributed  # noqa: required for dask.config.get("distributed.comm.ucx")
from dask.config import canonical_name
from dask.utils import format_bytes, parse_bytes
from distributed import wait
from distributed.comm import parse_address

try:
    from nvtx import annotate as nvtx_annotate
except ImportError:
    # If nvtx module is not installed, `annotate` yields only.
    from contextlib import contextmanager

    @contextmanager
    def nvtx_annotate(message=None, color="blue", domain=None):
        yield


def unpack_bitmask(x, mask_bits=64):
    """Unpack a list of integers containing bitmasks.

    Parameters
    ----------
    x: list of int
        A list of integers
    mask_bits: int
        An integer determining the bitwidth of ``x``

    Examples
    --------
    >>> from dask_cuda.utils import unpack_bitmaps
    >>> unpack_bitmask([1 + 2 + 8])
    [0, 1, 3]
    >>> unpack_bitmask([1 + 2 + 16])
    [0, 1, 4]
    >>> unpack_bitmask([1 + 2 + 16, 2 + 4])
    [0, 1, 4, 65, 66]
    >>> unpack_bitmask([1 + 2 + 16, 2 + 4], mask_bits=32)
    [0, 1, 4, 33, 34]
    """
    res = []

    for i, mask in enumerate(x):
        if not isinstance(mask, int):
            raise TypeError("All elements of the list `x` must be integers")

        cpu_offset = i * mask_bits

        bytestr = np.frombuffer(
            bytes(np.binary_repr(mask, width=mask_bits), "utf-8"), "u1"
        )
        mask = np.flip(bytestr - ord("0")).astype(bool)
        unpacked_mask = np.where(
            mask, np.arange(mask_bits) + cpu_offset, np.full(mask_bits, -1)
        )

        res += unpacked_mask[(unpacked_mask >= 0)].tolist()

    return res


@toolz.memoize
def get_cpu_count():
    return cpu_count()


@toolz.memoize
def get_gpu_count():
    pynvml.nvmlInit()
    return pynvml.nvmlDeviceGetCount()


def get_gpu_handle(device_id=0):
    """Get GPU handle from device index or UUID.

    Parameters
    ----------
    device_id: int or str
        The index or UUID of the device from which to obtain the handle.

    Raises
    ------
    ValueError
        If acquiring the device handle for the device specified failed.
    pynvml.NVMLError
        If any NVML error occurred while initializing.

    Examples
    --------
    >>> get_gpu_handle(device_id=0)

    >>> get_gpu_handle(device_id="GPU-9fb42d6f-7d6b-368f-f79c-3c3e784c93f6")
    """
    pynvml.nvmlInit()

    try:
        if device_id and not str(device_id).isnumeric():
            # This means device_id is UUID.
            # This works for both MIG and non-MIG device UUIDs.
            handle = pynvml.nvmlDeviceGetHandleByUUID(str.encode(device_id))
            if pynvml.nvmlDeviceIsMigDeviceHandle(handle):
                # Additionally get parent device handle
                # if the device itself is a MIG instance
                handle = pynvml.nvmlDeviceGetDeviceHandleFromMigDeviceHandle(handle)
        else:
            handle = pynvml.nvmlDeviceGetHandleByIndex(device_id)
        return handle
    except pynvml.NVMLError:
        raise ValueError(f"Invalid device index or UUID: {device_id}")


@toolz.memoize
def get_gpu_count_mig(return_uuids=False):
    """Return the number of MIG instances available

    Parameters
    ----------
    return_uuids: bool
        Returns the uuids of the MIG instances available optionally

    """
    pynvml.nvmlInit()
    uuids = []
    for index in range(get_gpu_count()):
        handle = pynvml.nvmlDeviceGetHandleByIndex(index)
        try:
            is_mig_mode = pynvml.nvmlDeviceGetMigMode(handle)[0]
        except pynvml.NVMLError:
            # if not a MIG device, i.e. a normal GPU, skip
            continue
        if is_mig_mode:
            count = pynvml.nvmlDeviceGetMaxMigDeviceCount(handle)
            miguuids = []
            for i in range(count):
                try:
                    mighandle = pynvml.nvmlDeviceGetMigDeviceHandleByIndex(
                        device=handle, index=i
                    )
                    miguuids.append(mighandle)
                    uuids.append(pynvml.nvmlDeviceGetUUID(mighandle))
                except pynvml.NVMLError:
                    pass
    if return_uuids:
        return len(uuids), uuids
    return len(uuids)


def get_cpu_affinity(device_index=None):
    """Get a list containing the CPU indices to which a GPU is directly connected.
    Use either the device index or the specified device identifier UUID.

    Parameters
    ----------
    device_index: int or str
        The index or UUID of the device from which to obtain the CPU affinity.

    Examples
    --------
    >>> from dask_cuda.utils import get_cpu_affinity
    >>> get_cpu_affinity(0)  # DGX-1 has GPUs 0-3 connected to CPUs [0-19, 20-39]
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
     40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]
    >>> get_cpu_affinity(5)  # DGX-1 has GPUs 5-7 connected to CPUs [20-39, 60-79]
    [20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
     60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79]
    >>> get_cpu_affinity(1000)  # DGX-1 has no device on index 1000
    dask_cuda/utils.py:96: UserWarning: Cannot get CPU affinity for device with index
    1000, setting default affinity
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
     20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
     40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
     60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79]
    """
    try:
        handle = get_gpu_handle(device_index)
        # Result is a list of 64-bit integers, thus ceil(get_cpu_count() / 64)
        affinity = pynvml.nvmlDeviceGetCpuAffinity(
            handle,
            math.ceil(get_cpu_count() / 64),
        )
        return unpack_bitmask(affinity)
    except (pynvml.NVMLError, ValueError):
        warnings.warn(
            "Cannot get CPU affinity for device with index %d, setting default affinity"
            % device_index
        )
        return list(range(get_cpu_count()))


def get_n_gpus():
    try:
        return len(os.environ["CUDA_VISIBLE_DEVICES"].split(","))
    except KeyError:
        return get_gpu_count()


def get_device_total_memory(device_index=0):
    """Return total memory of CUDA device with index or with device identifier UUID.

    Parameters
    ----------
    device_index: int or str
        The index or UUID of the device from which to obtain the CPU affinity.

    Returns
    -------
    The total memory of the CUDA Device in bytes, or ``None`` for devices that do not
    have a dedicated memory resource, as is usually the case for system on a chip (SoC)
    devices.
    """
    handle = get_gpu_handle(device_index)

    try:
        return pynvml.nvmlDeviceGetMemoryInfo(handle).total
    except pynvml.NVMLError_NotSupported:
        return None


def has_device_memory_resource(device_index=0):
    """Determine wheter CUDA device has dedicated memory resource.

    Certain devices have no dedicated memory resource, such as system on a chip (SoC)
    devices.

    Parameters
    ----------
    device_index: int or str
        The index or UUID of the device from which to obtain the CPU affinity.

    Returns
    -------
    Whether the device has a dedicated memory resource.
    """
    handle = get_gpu_handle(device_index)

    try:
        pynvml.nvmlDeviceGetMemoryInfo(handle).total
    except pynvml.NVMLError_NotSupported:
        return False
    else:
        return True


def get_ucx_config(
    enable_tcp_over_ucx=None,
    enable_infiniband=None,
    enable_nvlink=None,
    enable_rdmacm=None,
    protocol=None,
):
    ucx_config = dask.config.get("distributed.comm.ucx")

    # TODO: remove along with `protocol` kwarg when UCX-Py is removed, see
    # https://github.com/rapidsai/dask-cuda/issues/1517
    if protocol in ("ucx", "ucxx", "ucx-old"):
        ucx_config[canonical_name("ucx-protocol", ucx_config)] = protocol

    ucx_config[canonical_name("create-cuda-context", ucx_config)] = True
    ucx_config[canonical_name("reuse-endpoints", ucx_config)] = False

    # If any transport is explicitly disabled (`False`) by the user, others that
    # are not specified should be enabled (`True`). If transports are explicitly
    # enabled (`True`), then default (`None`) or an explicit `False` will suffice
    # in disabling others. However, if there's a mix of enable (`True`) and
    # disable (`False`), then those choices can be assumed as intended by the
    # user.
    #
    # This may be handled more gracefully in Distributed in the future.
    opts = [enable_tcp_over_ucx, enable_infiniband, enable_nvlink]
    if any(opt is False for opt in opts) and not any(opt is True for opt in opts):
        if enable_tcp_over_ucx is None:
            enable_tcp_over_ucx = True
        if enable_nvlink is None:
            enable_nvlink = True
        if enable_infiniband is None:
            enable_infiniband = True

    ucx_config[canonical_name("tcp", ucx_config)] = enable_tcp_over_ucx
    ucx_config[canonical_name("infiniband", ucx_config)] = enable_infiniband
    ucx_config[canonical_name("nvlink", ucx_config)] = enable_nvlink
    ucx_config[canonical_name("rdmacm", ucx_config)] = enable_rdmacm

    if enable_tcp_over_ucx or enable_infiniband or enable_nvlink:
        ucx_config[canonical_name("cuda-copy", ucx_config)] = True
    else:
        ucx_config[canonical_name("cuda-copy", ucx_config)] = None

    return ucx_config


def get_preload_options(
    protocol=None,
    create_cuda_context=None,
    enable_tcp_over_ucx=None,
    enable_infiniband=None,
    enable_nvlink=None,
    enable_rdmacm=None,
):
    """
    Return a dictionary with the preload and preload_argv options required to
    create CUDA context and enabling UCX communication.

    Parameters
    ----------
    protocol: None or str, default None
        If "ucx", options related to UCX (enable_tcp_over_ucx, enable_infiniband,
        enable_nvlink) are added to preload_argv.
    create_cuda_context: bool, default None
        Ensure the CUDA context gets created at initialization, generally
        needed by Dask workers.
    enable_tcp: bool, default None
        Set environment variables to enable TCP over UCX, even when InfiniBand or
        NVLink support are disabled.
    enable_infiniband: bool, default None
        Set environment variables to enable UCX InfiniBand support. Implies
        enable_tcp=True.
    enable_rdmacm: bool, default None
        Set environment variables to enable UCX RDMA connection manager support.
        Currently requires enable_infiniband=True.
    enable_nvlink: bool, default None
        Set environment variables to enable UCX NVLink support. Implies
        enable_tcp=True.

    Example
    -------
    >>> from dask_cuda.utils import get_preload_options
    >>> get_preload_options()
    {'preload': ['dask_cuda.initialize'], 'preload_argv': []}
    >>> get_preload_options(protocol="ucx",
    ...                     create_cuda_context=True,
    ...                     enable_infiniband=True)
    {'preload': ['dask_cuda.initialize'],
     'preload_argv': ['--create-cuda-context',
      '--enable-infiniband']}
    """
    preload_options = {"preload": ["dask_cuda.initialize"], "preload_argv": []}

    if create_cuda_context:
        preload_options["preload_argv"].append("--create-cuda-context")

    try:
        _get_active_ucx_implementation_name(protocol)
    except ValueError:
        pass
    else:
        initialize_ucx_argv = []
        if enable_tcp_over_ucx:
            initialize_ucx_argv.append("--enable-tcp-over-ucx")
        if enable_infiniband:
            initialize_ucx_argv.append("--enable-infiniband")
        if enable_rdmacm:
            initialize_ucx_argv.append("--enable-rdmacm")
        if enable_nvlink:
            initialize_ucx_argv.append("--enable-nvlink")

        preload_options["preload_argv"].extend(initialize_ucx_argv)

    return preload_options


def get_rmm_log_file_name(dask_worker, logging=False, log_directory=None):
    return (
        os.path.join(
            log_directory,
            "rmm_log_%s.txt"
            % (
                (
                    dask_worker.name.split("/")[-1]
                    if isinstance(dask_worker.name, str)
                    else dask_worker.name
                )
                if hasattr(dask_worker, "name")
                else "scheduler"
            ),
        )
        if logging
        else None
    )


def wait_workers(
    client, min_timeout=10, seconds_per_gpu=2, n_gpus=None, timeout_callback=None
):
    """
    Wait for workers to be available. When a timeout occurs, a callback
    is executed if specified. Generally used for tests.

    Parameters
    ----------
    client: distributed.Client
        Instance of client, used to query for number of workers connected.
    min_timeout: float
        Minimum number of seconds to wait before timeout. This value may be
        overridden by setting the ``DASK_CUDA_WAIT_WORKERS_MIN_TIMEOUT`` with
        a positive integer.
    seconds_per_gpu: float
        Seconds to wait for each GPU on the system. For example, if its
        value is 2 and there is a total of 8 GPUs (workers) being started,
        a timeout will occur after 16 seconds. Note that this value is only
        used as timeout when larger than min_timeout.
    n_gpus: None or int
        If specified, will wait for a that amount of GPUs (i.e., Dask workers)
        to come online, else waits for a total of ``get_n_gpus`` workers.
    timeout_callback: None or callable
        A callback function to be executed if a timeout occurs, ignored if
        None.

    Returns
    -------
    True if all workers were started, False if a timeout occurs.
    """
    min_timeout_env = os.environ.get("DASK_CUDA_WAIT_WORKERS_MIN_TIMEOUT", None)
    min_timeout = min_timeout if min_timeout_env is None else int(min_timeout_env)
    n_gpus = n_gpus or get_n_gpus()
    timeout = max(min_timeout, seconds_per_gpu * n_gpus)

    start = time.time()
    while True:
        if len(client.scheduler_info(n_workers=-1)["workers"]) == n_gpus:
            return True
        elif time.time() - start > timeout:
            if callable(timeout_callback):
                timeout_callback()
            return False
        else:
            time.sleep(0.1)


async def _all_to_all(client):
    """
    Trigger all to all communication between workers and scheduler
    """
    workers = list(client.scheduler_info(n_workers=-1)["workers"])
    futs = []
    for w in workers:
        bit_of_data = b"0" * 1
        data = client.map(lambda x: bit_of_data, range(1), pure=False, workers=[w])
        futs.append(data[0])

    await wait(futs)

    def f(x):
        pass

    new_futs = []
    for w in workers:
        for future in futs:
            data = client.submit(f, future, workers=[w], pure=False)
            new_futs.append(data)

    await wait(new_futs)


def all_to_all(client):
    return client.sync(_all_to_all, client=client, asynchronous=client.asynchronous)


def parse_cuda_visible_device(dev):
    """Parses a single CUDA device identifier

    A device identifier must either be an integer, a string containing an
    integer or a string containing the device's UUID, beginning with prefix
    'GPU-' or 'MIG-'.

    >>> parse_cuda_visible_device(2)
    2
    >>> parse_cuda_visible_device('2')
    2
    >>> parse_cuda_visible_device('GPU-9baca7f5-0f2f-01ac-6b05-8da14d6e9005')
    'GPU-9baca7f5-0f2f-01ac-6b05-8da14d6e9005'
    >>> parse_cuda_visible_device('Foo')
    Traceback (most recent call last):
    ...
    ValueError: Devices in CUDA_VISIBLE_DEVICES must be comma-separated integers or
    strings beginning with 'GPU-' or 'MIG-' prefixes.
    """
    try:
        return int(dev)
    except ValueError:
        if any(
            dev.startswith(prefix)
            for prefix in [
                "GPU-",
                "MIG-",
            ]
        ):
            return dev
        else:
            raise ValueError(
                "Devices in CUDA_VISIBLE_DEVICES must be comma-separated integers "
                "or strings beginning with 'GPU-' or 'MIG-' prefixes."
            )


def cuda_visible_devices(i, visible=None):
    """Cycling values for CUDA_VISIBLE_DEVICES environment variable

    Examples
    --------
    >>> cuda_visible_devices(0, range(4))
    '0,1,2,3'
    >>> cuda_visible_devices(3, range(8))
    '3,4,5,6,7,0,1,2'
    """
    if visible is None:
        try:
            visible = map(
                parse_cuda_visible_device, os.environ["CUDA_VISIBLE_DEVICES"].split(",")
            )
        except KeyError:
            visible = range(get_n_gpus())
    visible = list(visible)

    L = visible[i:] + visible[:i]
    return ",".join(map(str, L))


def nvml_device_index(i, CUDA_VISIBLE_DEVICES):
    """Get the device index for NVML addressing

    NVML expects the index of the physical device, unlike CUDA runtime which
    expects the address relative to ``CUDA_VISIBLE_DEVICES``. This function
    returns the i-th device index from the ``CUDA_VISIBLE_DEVICES``
    comma-separated string of devices or list.

    Examples
    --------
    >>> nvml_device_index(1, "0,1,2,3")
    1
    >>> nvml_device_index(1, "1,2,3,0")
    2
    >>> nvml_device_index(1, [0,1,2,3])
    1
    >>> nvml_device_index(1, [1,2,3,0])
    2
    >>> nvml_device_index(1, ["GPU-84fd49f2-48ad-50e8-9f2e-3bf0dfd47ccb",
                              "GPU-d6ac2d46-159b-5895-a854-cb745962ef0f",
                              "GPU-158153b7-51d0-5908-a67c-f406bc86be17"])
    "MIG-d6ac2d46-159b-5895-a854-cb745962ef0f"
    >>> nvml_device_index(2, ["MIG-41b3359c-e721-56e5-8009-12e5797ed514",
                              "MIG-65b79fff-6d3c-5490-a288-b31ec705f310",
                              "MIG-c6e2bae8-46d4-5a7e-9a68-c6cf1f680ba0"])
    "MIG-c6e2bae8-46d4-5a7e-9a68-c6cf1f680ba0"
    >>> nvml_device_index(1, 2)
    Traceback (most recent call last):
    ...
    ValueError: CUDA_VISIBLE_DEVICES must be `str` or `list`
    """
    if isinstance(CUDA_VISIBLE_DEVICES, str):
        ith_elem = CUDA_VISIBLE_DEVICES.split(",")[i]
        if ith_elem.isnumeric():
            return int(ith_elem)
        else:
            return ith_elem
    elif isinstance(CUDA_VISIBLE_DEVICES, list):
        return CUDA_VISIBLE_DEVICES[i]
    else:
        raise ValueError("`CUDA_VISIBLE_DEVICES` must be `str` or `list`")


def parse_device_bytes(device_bytes, device_index=0, alignment_size=1):
    """Parse bytes relative to a specific CUDA device.

    Parameters
    ----------
    device_bytes: float, int, str or None
        Can be an integer (bytes), float (fraction of total device memory), string
        (like ``"5GB"`` or ``"5000M"``), ``0`` and ``None`` are special cases
        returning ``None``.
    device_index: int or str
        The index or UUID of the device from which to obtain the total memory amount.
        Default: 0.
    alignment_size: int
        Number of bytes of alignment to use, i.e., allocation must be a multiple of
        that size. RMM pool requires 256 bytes alignment.

    Returns
    -------
    The parsed bytes value relative to the CUDA devices, or ``None`` as convenience if
    ``device_bytes`` is ``None`` or any value that would evaluate to ``0``.

    Examples
    --------
    >>> # On a 32GB CUDA device
    >>> parse_device_bytes(None)
    None
    >>> parse_device_bytes(0)
    None
    >>> parse_device_bytes(0.0)
    None
    >>> parse_device_bytes("0 MiB")
    None
    >>> parse_device_bytes(1.0)
    34089730048
    >>> parse_device_bytes(0.8)
    27271784038
    >>> parse_device_bytes(1000000000)
    1000000000
    >>> parse_device_bytes("1GB")
    1000000000
    >>> parse_device_bytes("1GB")
    1000000000
    """

    def _align(size, alignment_size):
        return size // alignment_size * alignment_size

    def parse_fractional(v):
        """Parse fractional value.

        Ensures ``int(1)`` and ``str("1")`` are not treated as fractionals, but
        ``float(1)`` is.

        Fractionals must be represented as a ``float`` within the range
        ``0.0 < v <= 1.0``.

        Parameters
        ----------
        v: int, float or str
            The value to check if fractional.

        Returns
        -------
        """
        # Check if `x` matches exactly `int(1)` or `str("1")`, and is not a `float(1)`
        is_one = lambda x: not isinstance(x, float) and (x == 1 or x == "1")

        if not is_one(v):
            with suppress(ValueError, TypeError):
                v = float(v)
                if 0.0 < v <= 1.0:
                    return v

        raise ValueError("The value is not fractional")

    # Special case for fractional limit. This comes before `0` special cases because
    # the `float` may be passed in a `str`, e.g., from `CUDAWorker`.
    try:
        fractional_device_bytes = parse_fractional(device_bytes)
    except ValueError:
        pass
    else:
        if not has_device_memory_resource():
            raise ValueError(
                "Fractional of total device memory not supported in devices without "
                "a dedicated memory resource."
            )
        return _align(
            int(get_device_total_memory(device_index) * fractional_device_bytes),
            alignment_size,
        )

    # Special cases that evaluates to `None` or `0`
    if device_bytes is None:
        return None
    elif device_bytes == 0.0:
        return None
    elif not isinstance(device_bytes, float) and parse_bytes(device_bytes) == 0:
        return None

    if isinstance(device_bytes, str):
        return _align(parse_bytes(device_bytes), alignment_size)
    else:
        return _align(int(device_bytes), alignment_size)


def parse_device_memory_limit(device_memory_limit, device_index=0, alignment_size=1):
    """Parse memory limit to be used by a CUDA device.

    Parameters
    ----------
    device_memory_limit: float, int, str or None
        Can be an integer (bytes), float (fraction of total device memory), string
        (like ``"5GB"`` or ``"5000M"``), ``"auto"``, ``0`` or ``None`` to disable
        spilling to host (i.e. allow full device memory usage). Another special value
        ``"default"`` is also available and returns the recommended Dask-CUDA's defaults
        and means 80% of the total device memory (analogous to ``0.8``), and disabled
        spilling (analogous to ``auto``/``0``/``None``) on devices without a dedicated
        memory resource, such as system on a chip (SoC) devices.
    device_index: int or str
        The index or UUID of the device from which to obtain the total memory amount.
        Default: 0.
    alignment_size: int
        Number of bytes of alignment to use, i.e., allocation must be a multiple of
        that size. RMM pool requires 256 bytes alignment.

    Returns
    -------
    The parsed memory limit in bytes, or ``None`` as convenience if
    ``device_memory_limit`` is ``None`` or any value that would evaluate to ``0``.

    Examples
    --------
    >>> # On a 32GB CUDA device
    >>> parse_device_memory_limit(None)
    None
    >>> parse_device_memory_limit(0)
    None
    >>> parse_device_memory_limit(0.0)
    None
    >>> parse_device_memory_limit("0 MiB")
    None
    >>> parse_device_memory_limit(1.0)
    34089730048
    >>> parse_device_memory_limit(0.8)
    27271784038
    >>> parse_device_memory_limit(1000000000)
    1000000000
    >>> parse_device_memory_limit("1GB")
    1000000000
    >>> parse_device_memory_limit("1GB")
    1000000000
    >>> parse_device_memory_limit("auto") == (
    ...    parse_device_memory_limit(1.0)
    ...    if has_device_memory_resource()
    ...    else None
    ... )
    True
    >>> parse_device_memory_limit("default") == (
    ...    parse_device_memory_limit(0.8)
    ...    if has_device_memory_resource()
    ...    else None
    ... )
    True
    """

    # Special cases for "auto" and "default".
    if device_memory_limit in ["auto", "default"]:
        if not has_device_memory_resource():
            return None
        if device_memory_limit == "auto":
            device_memory_limit = get_device_total_memory(device_index)
        else:
            device_memory_limit = 0.8

    return parse_device_bytes(
        device_bytes=device_memory_limit,
        device_index=device_index,
        alignment_size=alignment_size,
    )


def get_gpu_uuid(device_index=0):
    """Get GPU UUID from CUDA device index.

    Parameters
    ----------
    device_index: int or str
        The index or UUID of the device from which to obtain the UUID.

    Examples
    --------
    >>> get_gpu_uuid()
    'GPU-9baca7f5-0f2f-01ac-6b05-8da14d6e9005'

    >>> get_gpu_uuid(3)
    'GPU-9fb42d6f-7d6b-368f-f79c-3c3e784c93f6'

    >>> get_gpu_uuid("GPU-9fb42d6f-7d6b-368f-f79c-3c3e784c93f6")
    'GPU-9fb42d6f-7d6b-368f-f79c-3c3e784c93f6'
    """
    handle = get_gpu_handle(device_index)
    try:
        return pynvml.nvmlDeviceGetUUID(handle).decode("utf-8")
    except AttributeError:
        return pynvml.nvmlDeviceGetUUID(handle)


def get_worker_config(dask_worker):
    from .proxify_host_file import ProxifyHostFile

    # assume homogeneous cluster
    plugin_vals = dask_worker.plugins.values()
    ret = {}
    # device and host memory configuration
    for p in plugin_vals:
        config = {
            v: getattr(p, v)
            for v in dir(p)
            if not (v.startswith("_") or v in {"setup", "cores"})
        }
        # To send this back to the client the data will be serialised
        # which might fail, so pre-emptively check
        try:
            pickle.dumps(config)
        except TypeError:
            config = "UNKNOWN CONFIG"
        ret[f"[plugin] {type(p).__name__}"] = config

    for mem in [
        "memory_limit",
        "memory_pause_fraction",
        "memory_spill_fraction",
        "memory_target_fraction",
    ]:
        ret[mem] = getattr(dask_worker.memory_manager, mem)

    # jit unspilling set
    ret["jit-unspill"] = isinstance(dask_worker.data, ProxifyHostFile)

    # get optional device-memory-limit
    if ret["jit-unspill"]:
        ret["device-memory-limit"] = dask_worker.data.manager._device_memory_limit
    else:
        has_device = hasattr(dask_worker.data, "device_buffer")
        if has_device and hasattr(dask_worker.data.device_buffer, "n"):
            # If `n` is not an attribute, device spilling is disabled/unavailable.
            ret["device-memory-limit"] = dask_worker.data.device_buffer.n

    # using ucx ?
    scheme, loc = parse_address(dask_worker.scheduler.address)
    ret["protocol"] = scheme
    try:
        protocol = _get_active_ucx_implementation_name(scheme)
    except ValueError:
        pass
    else:
        if protocol == "ucxx":
            import ucxx

            ret["ucx-transports"] = ucxx.get_active_transports()
        elif protocol == "ucx-old":
            import ucp

            ret["ucx-transports"] = ucp.get_active_transports()

    # comm timeouts
    ret["distributed.comm.timeouts"] = dask.config.get("distributed.comm.timeouts")

    return ret


async def get_scheduler_configuration(client):
    worker_ttl = await client.run_on_scheduler(
        lambda dask_scheduler: dask_scheduler.worker_ttl
    )
    extensions = list(
        await client.run_on_scheduler(
            lambda dask_scheduler: dask_scheduler.extensions.keys()
        )
    )
    ret = {}
    ret["distributed.scheduler.worker-ttl"] = worker_ttl
    ret["active-extensions"] = extensions

    return ret


async def _get_cluster_configuration(client):
    worker_config = await client.run(get_worker_config)
    ret = await get_scheduler_configuration(client)

    # does the cluster have any workers ?
    if worker_config:
        w = list(worker_config.values())[0]
        ret.update(w)
        info = client.scheduler_info(n_workers=-1)
        workers = info.get("workers", {})
        ret["nworkers"] = len(workers)
        ret["nthreads"] = sum(w["nthreads"] for w in workers.values())

    return ret


@singledispatch
def pretty_print(obj, toplevel):
    from rich.pretty import Pretty

    return Pretty(obj)


@pretty_print.register(str)
def pretty_print_str(obj, toplevel):
    from rich.markup import escape

    return escape(obj)


@pretty_print.register(dict)
def pretty_print_dict(obj, toplevel):
    from rich.table import Table

    if not obj:
        return "No known settings"
    formatted_byte_keys = {
        "memory_limit",
        "device-memory-limit",
        "initial_pool_size",
        "maximum_pool_size",
    }
    t = Table(
        show_header=toplevel, title="Dask Cluster Configuration" if toplevel else None
    )
    t.add_column("Parameter", justify="left", style="bold bright_green")
    t.add_column("Value", justify="left", style="bold bright_green")
    for k, v in sorted(obj.items(), key=operator.itemgetter(0)):
        if k in formatted_byte_keys and v is not None:
            v = format_bytes(v)
        # need to escape tags: []
        # https://rich.readthedocs.io/en/stable/markup.html?highlight=escape#escaping
        t.add_row(pretty_print(k, False), pretty_print(v, False))
    return t


def print_cluster_config(client):
    """print current Dask cluster configuration"""
    if client.asynchronous:
        print("Printing cluster configuration works only with synchronous Dask clients")

    data = get_cluster_configuration(client)
    try:
        from rich.console import Console
    except ModuleNotFoundError as e:
        error_msg = (
            "Please install rich `python -m pip install rich` "
            "to print a table of the current Dask Cluster Configuration"
        )
        raise ModuleNotFoundError(error_msg) from e

    formatted = pretty_print(data, True)
    Console().print(formatted)


def get_cluster_configuration(client):
    data = client.sync(
        _get_cluster_configuration, client=client, asynchronous=client.asynchronous
    )
    return data


def get_rmm_device_memory_usage() -> Optional[int]:
    """Get current bytes allocated on current device through RMM

    Check the current RMM resource stack for resources such as
    ``StatisticsResourceAdaptor`` and ``TrackingResourceAdaptor``
    that can report the current allocated bytes. Returns None,
    if no such resources exist.

    Return
    ------
    nbytes: int or None
        Number of bytes allocated on device through RMM or None
    """

    def get_rmm_memory_resource_stack(mr) -> list:
        if hasattr(mr, "upstream_mr"):
            return [mr] + get_rmm_memory_resource_stack(mr.upstream_mr)
        return [mr]

    try:
        import rmm
    except ImportError:
        return None

    for mr in get_rmm_memory_resource_stack(rmm.mr.get_current_device_resource()):
        if isinstance(mr, rmm.mr.TrackingResourceAdaptor):
            return mr.get_allocated_bytes()
        if isinstance(mr, rmm.mr.StatisticsResourceAdaptor):
            return mr.allocation_counts["current_bytes"]
    return None


class CommaSeparatedChoice(click.Choice):
    def convert(self, value, param, ctx):
        values = [v.strip() for v in value.split(",")]
        for v in values:
            if v not in self.choices:
                choices_str = ", ".join(f"'{c}'" for c in self.choices)
                self.fail(f"invalid choice(s): {v}. (choices are: {choices_str})")
        return values


def _get_active_ucx_implementation_name(protocol):
    """Get the name of active UCX implementation.

    Determine what UCX implementation is being activated based on a series of
    conditions. UCXX is selected if:
    - The protocol is `"ucxx"`, or the protocol is `"ucx"` and the `distributed-ucxx`
      package is installed.
    UCX-Py is selected if:
    - The protocol is `"ucx-old"`, or the protocol is `"ucx"` and the `distributed-ucxx`
      package is not installed, in which case a `FutureWarning` is also raised.

    Parameters
    ----------
    protocol: str
        The communication protocol selected.

    Returns
    -------
    The selected implementation type, either "ucxx" or "ucx-old".

    Raises
    ------
    ValueError
        If protocol is not a valid UCX protocol.
    """
    has_ucxx = importlib.util.find_spec("distributed_ucxx") is not None

    if protocol == "ucxx" or (has_ucxx and protocol == "ucx"):
        # With https://github.com/rapidsai/rapids-dask-dependency/pull/116,
        # `protocol="ucx"` now points to UCXX (if distributed-ucxx is installed),
        # thus call the UCXX initializer.
        return "ucxx"
    elif protocol in ("ucx", "ucx-old"):
        return "ucx-old"
    else:
        raise ValueError("Protocol is neither UCXX nor UCX-Py")
