

from .dialect import  DlcDialect, dialect
from .version import VERSION