from django.contrib import admin
from .models import UserConfirmationToken

admin.site.register(UserConfirmationToken)
