---
name: Bug Report
about: Report a bug
labels: ['bug']
---

## What happened?
Describe the bug.

## How to reproduce?
Steps or command to trigger the bug.

## Error message (if any)
```
Paste error here
```
