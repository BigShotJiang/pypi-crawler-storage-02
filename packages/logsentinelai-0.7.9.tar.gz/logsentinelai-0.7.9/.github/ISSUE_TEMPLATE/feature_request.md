---
name: Feature Request
about: Suggest a new feature
labels: ['enhancement']
---

## What do you want?
Describe the feature.

## Why is it useful?
(Optional) Why do you need it?
