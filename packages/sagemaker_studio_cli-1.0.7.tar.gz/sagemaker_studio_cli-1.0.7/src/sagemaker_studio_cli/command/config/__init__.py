from sagemaker_studio_cli.command.config.global_config import (  # noqa: F401
    CONFIG_DOMAIN_ID_KEY,
    CONFIG_DZ_ENDPOINT_KEY,
    CONFIG_PROFILE_KEY,
    CONFIG_PROJECT_ID_KEY,
    CONFIG_REGION_KEY,
    GlobalConfig,
)
