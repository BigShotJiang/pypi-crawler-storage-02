## Generate a new stock snapshot

- Go to: *Inventory / Reporting / History / Stock snapshot*
- choose the date you want to re-generate stock quants
- click on Generate

## Consult stock quant for a given snapshot

- Go to: *Inventory / Reporting / History / Stock snapshot*
- select the existing snapshot to open the form view
- click on smart button to display quants at that time

## Compare stock over snapshots

- Go to: *Inventory / Reporting / History / Stock snapshot*
- In tree view select at least 2 snapshots
- Click on *Action / Compare stocks*
- You'll be redirected to the stock quant tree view for selected
  snapshots

or

- Go to: *Inventory / Reporting / History / Stock quants*
- use different filters / group and views to make your analysis
