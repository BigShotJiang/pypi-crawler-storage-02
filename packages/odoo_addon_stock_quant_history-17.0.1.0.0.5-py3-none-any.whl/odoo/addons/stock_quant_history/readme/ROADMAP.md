## Short terms

- Add a companion module stock_quant_history_account to make the glue
  between stock_quant_history and stock_account adding the stock value

## Long terms

- Add filters (by locations, by product...) while generating tight
  snapshots (not reused as based snapshot)
- add owner and package fields
