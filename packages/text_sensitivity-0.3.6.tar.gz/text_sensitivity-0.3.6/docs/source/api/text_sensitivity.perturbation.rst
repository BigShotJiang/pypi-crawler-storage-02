text\_sensitivity.perturbation 
===============================

.. automodule:: text_sensitivity.perturbation
   :members:
   :undoc-members:
   :show-inheritance:

*Submodules*:


text\_sensitivity.perturbation.base module
------------------------------------------

.. automodule:: text_sensitivity.perturbation.base
   :members:
   :undoc-members:
   :show-inheritance:

text\_sensitivity.perturbation.characters module
------------------------------------------------

.. automodule:: text_sensitivity.perturbation.characters
   :members:
   :undoc-members:
   :show-inheritance:

text\_sensitivity.perturbation.sentences module
-----------------------------------------------

.. automodule:: text_sensitivity.perturbation.sentences
   :members:
   :undoc-members:
   :show-inheritance:

text\_sensitivity.perturbation.words module
-------------------------------------------

.. automodule:: text_sensitivity.perturbation.words
   :members:
   :undoc-members:
   :show-inheritance:
