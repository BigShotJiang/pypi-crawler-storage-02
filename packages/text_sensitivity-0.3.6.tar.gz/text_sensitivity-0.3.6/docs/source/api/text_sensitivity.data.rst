text\_sensitivity.data 
=======================

.. automodule:: text_sensitivity.data
   :members:
   :undoc-members:
   :show-inheritance:

*Subpackages*:

.. toctree::
   :maxdepth: 4

   text_sensitivity.data.lists
   text_sensitivity.data.random

*Submodules*:


text\_sensitivity.data.generate module
--------------------------------------

.. automodule:: text_sensitivity.data.generate
   :members:
   :undoc-members:
   :show-inheritance:

text\_sensitivity.data.wordlist module
--------------------------------------

.. automodule:: text_sensitivity.data.wordlist
   :members:
   :undoc-members:
   :show-inheritance:
