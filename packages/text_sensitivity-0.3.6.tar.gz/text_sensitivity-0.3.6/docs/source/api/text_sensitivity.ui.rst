text\_sensitivity.ui 
=====================

.. automodule:: text_sensitivity.ui
   :members:
   :undoc-members:
   :show-inheritance:

*Submodules*:


text\_sensitivity.ui.notebook module
------------------------------------

.. automodule:: text_sensitivity.ui.notebook
   :members:
   :undoc-members:
   :show-inheritance:
