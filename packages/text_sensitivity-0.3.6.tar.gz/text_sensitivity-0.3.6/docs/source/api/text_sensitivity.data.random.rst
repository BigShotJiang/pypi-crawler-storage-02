text\_sensitivity.data.random 
==============================

.. automodule:: text_sensitivity.data.random
   :members:
   :undoc-members:
   :show-inheritance:

*Submodules*:


text\_sensitivity.data.random.entity module
-------------------------------------------

.. automodule:: text_sensitivity.data.random.entity
   :members:
   :undoc-members:
   :show-inheritance:

text\_sensitivity.data.random.string module
-------------------------------------------

.. automodule:: text_sensitivity.data.random.string
   :members:
   :undoc-members:
   :show-inheritance:
