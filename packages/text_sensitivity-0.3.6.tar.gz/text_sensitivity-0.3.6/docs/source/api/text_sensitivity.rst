text\_sensitivity 
==================

.. automodule:: text_sensitivity
   :members:
   :undoc-members:
   :show-inheritance:

*Subpackages*:

.. toctree::
   :maxdepth: 4

   text_sensitivity.data
   text_sensitivity.perturbation
   text_sensitivity.ui

*Submodules*:


text\_sensitivity.metrics module
--------------------------------

.. automodule:: text_sensitivity.metrics
   :members:
   :undoc-members:
   :show-inheritance:

text\_sensitivity.return\_types module
--------------------------------------

.. automodule:: text_sensitivity.return_types
   :members:
   :undoc-members:
   :show-inheritance:

text\_sensitivity.sensitivity module
------------------------------------

.. automodule:: text_sensitivity.sensitivity
   :members:
   :undoc-members:
   :show-inheritance:
