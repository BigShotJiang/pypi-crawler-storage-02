text\_sensitivity.data.lists 
=============================

.. automodule:: text_sensitivity.data.lists
   :members:
   :undoc-members:
   :show-inheritance:
