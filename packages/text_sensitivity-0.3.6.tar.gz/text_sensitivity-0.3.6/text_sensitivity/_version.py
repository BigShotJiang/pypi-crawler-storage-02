__version_info__ = (0, 3, 6)
__version__ = '.'.join(str(v) for v in __version_info__)
