"""All randomly generated data, and data for lookups (e.g. word lists)."""

from text_sensitivity.data.generate import from_pattern
