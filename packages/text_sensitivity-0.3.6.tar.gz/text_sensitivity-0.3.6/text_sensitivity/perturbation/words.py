"""Create word-level perturbations (`text_sensitivity.perturbation.base.Perturbation`)."""
