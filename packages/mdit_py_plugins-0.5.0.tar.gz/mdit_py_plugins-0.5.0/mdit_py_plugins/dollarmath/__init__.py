from .index import dollarmath_plugin

__all__ = ("dollarmath_plugin",)
