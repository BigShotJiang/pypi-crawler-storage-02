* Camptocamp:
  * Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
  * Thierry Ducrest <thierry.ducrest@camptocamp.com>
* BCIM:
  * Jacques-Etienne Baudoux <je@bcim.be>
* TROBZ:
  * Phuc Tran Thanh <phuc@trobz.com>
* Michael Tietz (MT Software) <mtietz@mt-software.de>
