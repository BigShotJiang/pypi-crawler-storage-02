# persisto/errors.py
class PersistoAuthError(Exception):
    pass
