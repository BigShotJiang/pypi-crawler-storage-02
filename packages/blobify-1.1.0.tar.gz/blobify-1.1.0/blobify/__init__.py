"""
Blobify - Package your entire codebase into a single text file for AI consumption
"""

from .main import __author__, __email__, __version__, main

__all__ = ["main", "__author__", "__email__", "__version__"]
