from .core import env, TelepopEnv

__all__ = ["env", "telepop_env"]
__version__ = "0.1.3"
