import sys
from os import path
sys.path.append(path.dirname(__file__))
from src.MazeCar import MazeCar

GAME_SETUP = {
    "game": MazeCar
}
