First version of the Q Space coverage visualizer

Test scripts:
bz.py                  simple BZ numeric calculations
hhl-test.py            simple use of the class without GUI
qreader.py             class for reading files
readme.txt             this file