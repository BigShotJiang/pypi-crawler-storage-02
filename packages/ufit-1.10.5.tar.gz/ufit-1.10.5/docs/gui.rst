Using the ufit GUI
==================
