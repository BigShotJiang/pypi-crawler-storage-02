# Copyright 2024 Marimo. All rights reserved.
"""Backend tools for marimo AI system."""
# from marimo._server.ai.backend_tools.sample_tool import register_sample_tool  # Uncomment to enable sample tool


def register_all_backend_tools() -> None:
    """Register all backend tools with the tool manager."""
    # register_sample_tool()  # Uncomment to enable sample tool
