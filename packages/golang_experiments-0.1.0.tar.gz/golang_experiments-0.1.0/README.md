# golang_experiments

A Python package that prints pre-written Golang code for 13 experiments.

## Installation
```bash
pip install golang_experiments
