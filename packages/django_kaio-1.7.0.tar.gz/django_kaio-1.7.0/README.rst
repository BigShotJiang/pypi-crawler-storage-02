===========
django-kaio
===========

.. image:: https://img.shields.io/pypi/v/django-kaio.svg
    :target: https://pypi.python.org/pypi/django-kaio/

Class based settings for Django projects that can be read from multiple sources.


Documentation
-------------
Visit the `documentation <http://django-kaio.readthedocs.io/en/latest/>`_ for an in-depth look at **django-kaio**.
