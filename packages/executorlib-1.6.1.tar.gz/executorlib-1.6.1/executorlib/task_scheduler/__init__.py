"""
The task schedulers are used inside executorlib to distribute Python functions for execution, the following task
schedulers are available: BlockAllocationTaskScheduler, DependencyTaskScheduler, FileTaskScheduler and OneProcessTaskScheduler.
"""
