"""Quaestor - AI-assisted development context management."""

__version__ = "0.6.0"
