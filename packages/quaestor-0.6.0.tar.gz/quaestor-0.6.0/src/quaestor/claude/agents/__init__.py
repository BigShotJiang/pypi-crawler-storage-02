"""Quaestor Agents - Markdown agent definitions for Claude's native subagent system."""

# Agent files are deployed to .claude/agents/ for Claude to discover automatically
# No Python infrastructure needed - Claude handles everything natively
