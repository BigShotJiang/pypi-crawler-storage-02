"""Claude integration for Quaestor."""
