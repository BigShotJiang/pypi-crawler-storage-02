<!-- QUAESTOR CONFIG START -->
> [!IMPORTANT]
> **Claude:** This project uses Quaestor for AI context management.
> Please read the following files in order:
> 1. `.quaestor/CONTEXT.md` - Complete AI development context and rules
> 2. `.quaestor/ARCHITECTURE.md` - System design and structure (if available)
> 3. `.quaestor/specs/active/` - Active specifications and implementation details
<!-- QUAESTOR CONFIG END -->

<!-- Your custom content below -->