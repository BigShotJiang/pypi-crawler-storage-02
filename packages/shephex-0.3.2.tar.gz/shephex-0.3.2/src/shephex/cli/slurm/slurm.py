
import rich_click as click


@click.group()
def slurm() -> None:
    """
    Slurm commands
    """ 
    ... # pragma: no cover