"""
Command line interface for shephex.
"""