import rich_click as click


@click.group(name="study")
def study_cli() -> None:
    """
    Study commands
    """
    pass