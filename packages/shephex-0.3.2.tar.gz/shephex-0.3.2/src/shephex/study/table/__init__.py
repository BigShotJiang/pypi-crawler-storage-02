from shephex.study.table.littletable_table import LittleTable

__all__ = ['LittleTable']
