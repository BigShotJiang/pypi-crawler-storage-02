=====
Usage
=====

To use the SEAMM module in a project::

    import seamm
