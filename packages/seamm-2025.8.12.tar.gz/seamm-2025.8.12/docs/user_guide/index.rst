.. _user-guide:

**********
User Guide
**********
The SEAMM package, which is the main package in the SEAMM infrastructure.

..
   The following sections cover accessing and controlling this functionality.

   .. toctree::
      :maxdepth: 2
      :titlesonly:
