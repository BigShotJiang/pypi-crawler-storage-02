"""
Media server (for dev or low-traffic instances)
"""
