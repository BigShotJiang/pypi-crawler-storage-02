"""
Core models for Backup Restore (WIP)
"""
