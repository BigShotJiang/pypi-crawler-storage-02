"""
Open edX Learning ("Learning Core").
"""

__version__ = "0.27.1"
