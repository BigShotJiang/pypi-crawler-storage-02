## Error classes for primalbedtools


class InvalidBedFileError(Exception):
    pass
