---
hide:
    - navigation
    - toc
---

<!--
 ~ SPDX-FileCopyrightText: Copyright DB InfraGO AG and the capellambse-context-diagrams contributors
 ~ SPDX-License-Identifier: Apache-2.0
 -->

Special thanks
==============

Our special thanks goes to the developers and maintainers of [<img src="https://www.eclipse.org/elk/img/elk.svg" style="height: 15px"> **Eclipse Layout Kernel™**](https://www.eclipse.org/elk/).
Here we use [elkjs](https://github.com/kieler/elkjs#readme). This extension wouldn't exist without the ELK magic.
