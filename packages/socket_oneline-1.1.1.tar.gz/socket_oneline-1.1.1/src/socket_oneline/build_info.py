class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '1.1.1'
    git_sha = '69bc242acae84557807f3c3efd3dc160367adafb'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
