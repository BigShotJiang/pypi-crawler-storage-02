# vs-transitions, a collection of functions for making transitions and reanimating static shots.

For support you can check out the [JET Discord server](https://discord.gg/XTpc6Fa9eB). <br><br>

## How to install

Install `vstransitions` with the following command:

```sh
pip install vstransitions
```

Or if you want the latest git version, install it with this command:

```sh
pip install git+https://github.com/Jaded-Encoding-Thaumaturgy/vs-transitions.git
```

<br>
