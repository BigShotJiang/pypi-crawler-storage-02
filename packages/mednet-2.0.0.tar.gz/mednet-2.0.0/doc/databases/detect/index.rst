.. SPDX-FileCopyrightText: Copyright © 2024 Idiap Research Institute <contact@idiap.ch>
..
.. SPDX-License-Identifier: GPL-3.0-or-later

.. _mednet.databases.detect:

==================
 Object Detection
==================

.. toctree::
   :maxdepth: 1

   cxr8
   jsrt
   montgomery
   shenzhen
