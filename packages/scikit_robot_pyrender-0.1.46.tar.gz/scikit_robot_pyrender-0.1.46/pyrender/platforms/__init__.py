"""Platforms for generating offscreen OpenGL contexts for rendering.

Author: Matthew Matl
"""

from .base import Platform as Platform
