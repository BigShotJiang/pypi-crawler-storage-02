### extract video frame
对视频进行分帧，使用示例：
```python
        print("用法: python script.py <video_file> [output_dir]")
        print("示例: python script.py video.mp4")
        print("示例: python script.py video.mp4 /path/to/output")
```