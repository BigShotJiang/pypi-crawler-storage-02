"""
Program domain module.

This module implements all the program-related domain objects of the OpenADR3 Client library.
"""
