"""
Event domain module.

This module implements all the event-related domain objects of the OpenADR3 Client library.
"""
