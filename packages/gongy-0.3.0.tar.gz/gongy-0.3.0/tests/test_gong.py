"""Testing for gong."""


def test_dummy() -> None:
    """Dummy test."""
