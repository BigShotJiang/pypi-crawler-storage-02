# CHANGELOG


## v0.3.0 (2025-08-13)

### Chores

- Better errors
  ([`d025914`](https://github.com/MicaelJarniac/gongy/commit/d0259148e02edebaef95f1073d4a566f1b8f6719))

### Features

- Get calls batched, get single call
  ([`759e9f9`](https://github.com/MicaelJarniac/gongy/commit/759e9f9099b25c7a245254a849fe5c51d65b335b))


## v0.2.0 (2025-08-12)

### Bug Fixes

- Rename symbols
  ([`9e3fea7`](https://github.com/MicaelJarniac/gongy/commit/9e3fea7b9e5de78c08b6d9f3d6abef153394628e))

### Features

- Rename project
  ([`992a092`](https://github.com/MicaelJarniac/gongy/commit/992a092e2dd09e8aa859df5de3e024d75b46b37a))


## v0.1.0 (2025-08-12)

### Features

- Basic functionality (untested)
  ([`72b0313`](https://github.com/MicaelJarniac/gongy/commit/72b0313f29d5eb115a5780e05f9b3b8e8d83d099))


## v0.0.0 (2025-08-12)

### Chores

- Basic project setup
  ([`c352635`](https://github.com/MicaelJarniac/gongy/commit/c352635f825011e9e7a05ad961b4540aded1292b))
