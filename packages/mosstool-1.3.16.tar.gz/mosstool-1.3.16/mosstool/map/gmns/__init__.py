"""
Convertor to https://github.com/zephyr-data-specs/GMNS
"""

from .convertor import Convertor

__all__ = ["Convertor"]
