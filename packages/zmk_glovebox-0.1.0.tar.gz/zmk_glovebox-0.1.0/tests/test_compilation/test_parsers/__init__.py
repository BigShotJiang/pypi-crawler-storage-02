"""Tests for compilation parsers."""
