"""Tests for compilation domain protocols."""
