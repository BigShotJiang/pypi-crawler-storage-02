"""Tests for compilation domain models."""
