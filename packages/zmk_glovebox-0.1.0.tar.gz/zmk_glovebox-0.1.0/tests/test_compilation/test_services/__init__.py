"""Test compilation services."""
