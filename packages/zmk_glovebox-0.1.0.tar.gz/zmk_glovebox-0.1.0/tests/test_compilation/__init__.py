"""Tests for compilation domain."""
