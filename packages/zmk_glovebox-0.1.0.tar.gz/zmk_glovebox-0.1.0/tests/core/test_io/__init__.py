"""Tests for core I/O operations."""
