"""Tests for CLI core infrastructure."""
