"""Test package for adapters."""
