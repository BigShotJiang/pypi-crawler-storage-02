"""Test package for CLI helpers."""
