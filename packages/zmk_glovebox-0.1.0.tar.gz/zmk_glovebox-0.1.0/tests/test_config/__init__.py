"""Test module for configuration."""
