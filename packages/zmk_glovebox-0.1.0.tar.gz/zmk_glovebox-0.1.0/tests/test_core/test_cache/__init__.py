"""Tests for DiskCache-based cache system."""
