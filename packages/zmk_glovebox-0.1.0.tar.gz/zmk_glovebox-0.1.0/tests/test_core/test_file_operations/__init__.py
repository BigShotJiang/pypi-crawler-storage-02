"""Tests for core file operations module."""
