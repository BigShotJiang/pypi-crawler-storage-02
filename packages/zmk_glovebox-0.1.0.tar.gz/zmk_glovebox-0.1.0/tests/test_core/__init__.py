# Core component tests
