"""Main entry point for direct module execution."""

import sys

from glovebox.cli import main


if __name__ == "__main__":
    sys.exit(main())
