"""Main entry point for CLI execution."""

import sys

from glovebox.cli.app import main


if __name__ == "__main__":
    sys.exit(main())
