# Ultralytics YOLO 🚀, AGPL-3.0 license

from .train import WorldTrainer

__all__ = ["WorldTrainer"]
