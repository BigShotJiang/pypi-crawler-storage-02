"""AI Rulez - CLI tool for managing AI assistant rules."""

__version__ = "1.4.3"  # This should be updated during release