# My Table Package

A Python package to generate and display Hex styled HTML tables from Pandas DataFrames directly in Jupyter notebooks or other IPython environments.

## Installation

You can install this package via pip:

```bash
pip install riv_hex_table # (Once published to PyPI)