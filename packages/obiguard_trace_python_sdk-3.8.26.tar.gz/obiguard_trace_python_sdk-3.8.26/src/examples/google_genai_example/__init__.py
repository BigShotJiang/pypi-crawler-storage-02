from .main import generate_content, generate_content_streaming


class GoogleGenaiRunner:
    def run(self):
        # generate_content()
        generate_content_streaming()
