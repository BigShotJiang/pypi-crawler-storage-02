from .instrumentation import DspyInstrumentation

__all__ = ["DspyInstrumentation"]
