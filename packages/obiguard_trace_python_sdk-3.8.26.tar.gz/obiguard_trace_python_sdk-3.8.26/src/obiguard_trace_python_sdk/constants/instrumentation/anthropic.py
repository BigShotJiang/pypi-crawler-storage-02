APIS = {
    "MESSAGES_CREATE": {
        "METHOD": "anthropic.messages.create",
        "ENDPOINT": "/v1/messages",
    },
    "MESSAGES_STREAM": {
        "METHOD": "anthropic.messages.stream",
        "ENDPOINT": "/v1/messages",
    },
}
