# Changelog

All notable changes to `hubdata` are documented here.

## Unreleased

## 0.1.2

### Added

- N/A

### Changed

- Small documentation updates

### Internal

- N/A

## 0.1.1

### Added

- Initial release
- Includes automatic building and publishing to [pypi.org](https://pypi.org/project/hubdata/)
- Includes documentation under **docs/source**

### Changed

- N/A

### Internal

- N/A
