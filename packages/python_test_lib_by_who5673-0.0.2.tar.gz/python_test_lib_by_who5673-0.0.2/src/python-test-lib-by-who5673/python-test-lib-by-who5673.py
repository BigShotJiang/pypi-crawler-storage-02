#from ctypes import CDLL as cdll, c_long as long
