# Python test library
Note: Do not install this library. I just make it for learning how to deal with The Rust programming language.