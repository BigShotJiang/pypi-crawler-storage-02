# Neritya Clock

🕒 A simple terminal-based Python clock that shows the current time.

## Usage

After installation:

```bash
neritya_clock
