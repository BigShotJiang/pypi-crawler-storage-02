# micromanager
CLI application to manage microservices with docker-compose
