from discord_self._vendor.discord.backoff import ExponentialBackoff

__all__ = ["ExponentialBackoff"]
