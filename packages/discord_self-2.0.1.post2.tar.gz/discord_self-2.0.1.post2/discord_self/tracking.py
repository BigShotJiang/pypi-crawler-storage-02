from discord_self._vendor.discord.tracking import ContextProperties

__all__ = ["ContextProperties"]
