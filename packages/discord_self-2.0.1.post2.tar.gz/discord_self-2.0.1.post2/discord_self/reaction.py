from discord_self._vendor.discord.reaction import Reaction

__all__ = ["Reaction"]
