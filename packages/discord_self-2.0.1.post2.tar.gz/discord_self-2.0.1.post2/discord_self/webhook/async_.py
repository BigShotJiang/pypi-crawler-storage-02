from discord_self._vendor.discord.webhook.async_ import (
    PartialWebhookChannel,
    PartialWebhookGuild,
    Webhook,
    WebhookMessage,
)

__all__ = ["PartialWebhookChannel", "PartialWebhookGuild", "Webhook", "WebhookMessage"]
