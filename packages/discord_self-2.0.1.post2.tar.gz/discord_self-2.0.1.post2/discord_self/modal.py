from discord_self._vendor.discord.modal import Modal

__all__ = ["Modal"]
