from ..SWING.StandardSWING import StandardSWING

class StandardPointAllocation(StandardSWING):
    """
    This class is a direct alias of StandardSWING for Point Allocation method.
    """
    pass
