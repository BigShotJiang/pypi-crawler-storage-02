Python library to control an AVGear HDMI Matrix - specifically a TMX44PRO AVK as but it may work for others and happy to accept pull requests or suggestions for other.

Inspiration from:
https://github.com/koolsb/pyblackbird/
