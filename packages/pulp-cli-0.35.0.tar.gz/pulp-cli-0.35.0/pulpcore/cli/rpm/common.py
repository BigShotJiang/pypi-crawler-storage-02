LEGACY_CHECKSUM_CHOICES = ("md5", "sha1", "sha224", "sha256", "sha384", "sha512")

CHECKSUM_CHOICES = ("sha256", "sha384", "sha512")
