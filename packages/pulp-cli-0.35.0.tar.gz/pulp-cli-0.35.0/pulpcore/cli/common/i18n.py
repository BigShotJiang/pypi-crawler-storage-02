from pulp_glue.common.i18n import get_translation  # noqa: F401

__all__ = ["get_translation"]
