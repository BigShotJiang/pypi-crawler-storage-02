# Authors

Contributors to pysegmenters_blingfire include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
