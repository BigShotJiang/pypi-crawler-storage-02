import enum

class SubmissionStatus(enum.Enum):
  """TODO(aip.dev/216): (-- api-linter: core::0216::synonyms=disabled --)"""
  PENDING = 0
  """TODO(aip.dev/126): (-- api-linter: core::0126::unspecified=disabled --)"""
  COMPLETE = 1
  ERROR = 2

