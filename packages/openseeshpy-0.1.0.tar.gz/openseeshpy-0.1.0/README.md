#OpenSeesHpy

**_This is an OpenSees customization optimized for performance-based analysis and design of structures _**
**_This version is provided and published by OpenSeesHouse (https://OpenSeesHouse.com)._**

**_installing by pip_**
pip install OpenSeesHpy
