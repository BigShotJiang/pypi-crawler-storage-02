from .__main__ import DTO, DTOConfig

__all__ = ["DTO", "DTOConfig"]
