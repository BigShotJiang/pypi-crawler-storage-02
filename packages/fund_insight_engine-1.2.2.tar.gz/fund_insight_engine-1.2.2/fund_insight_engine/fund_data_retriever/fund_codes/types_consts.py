

KEY_FOR_FUND_TYPE = '펀드분류'
VALUES_FOR_TYPE = ['주식혼합', '혼합자산', '채권혼합', '주식형', '변액']
