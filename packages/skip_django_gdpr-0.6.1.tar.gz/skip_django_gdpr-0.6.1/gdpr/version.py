VERSION = (0, 6, 1)


def get_version():
    return '.'.join(map(str, VERSION))
