from .default import AbstractPurpose

__all__ = (
    'AbstractPurpose'
)
