# ben-memre/ben-memre/functions.py

def greet(name):
    return f"Hello, {name}! This is a message from ben-memre."

def add_numbers(x, y):
    return x + y