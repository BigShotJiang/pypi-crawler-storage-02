raise ImportError("torchcomms can't be installed via PyPi -- see README for more details")
