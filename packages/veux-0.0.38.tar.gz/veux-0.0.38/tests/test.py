

import veux


veux.render("b.json", vert=3, displ={5: (2,)})

veux.render("c.json")

