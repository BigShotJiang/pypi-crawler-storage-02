"""Utilities and helpers for pltr."""
