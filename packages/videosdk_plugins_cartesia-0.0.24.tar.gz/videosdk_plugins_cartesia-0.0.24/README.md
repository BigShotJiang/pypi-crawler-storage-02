# VideoSDK Cartesia Plugin

Agent Framework plugin for STT and TTS services from Cartesia.

## Installation

```bash
pip install videosdk-plugins-cartesia
```