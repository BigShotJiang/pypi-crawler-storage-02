"""
GwaniCLI - A command-line interface for accessing Quranic verses and translations.
"""

__version__ = "0.2.0"
__author__ = "Hamza Danjaji"
__email__ = "bhantsi@gmail.com"
