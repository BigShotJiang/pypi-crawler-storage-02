python-aresti
=============

Asynkroninen REST-rajapintayhteystoteutus
