class BillingException(Exception):
    pass
