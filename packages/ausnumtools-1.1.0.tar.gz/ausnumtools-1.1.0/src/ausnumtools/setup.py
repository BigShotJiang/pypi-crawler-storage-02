#!/usr/bin/env python

""""""
# SPDX-FileCopyrightText: 2025 Ben Bonacci <ben at benbonaccci dot com>
# SPDX-License-Identifier: GPL-3.0-only
""""""

setuptools.setup()
