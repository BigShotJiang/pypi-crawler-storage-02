To deploy: `uv run modal deploy sgl_inference.py`
