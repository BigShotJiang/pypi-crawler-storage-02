RATES_CLASS = "NEMO_billing.rates.rates_class.DatabaseRates"
DEFAULT_MISSED_RESERVATION_FLAT = True
RATE_CURRENCY = "$"
RATE_LIST_URL = "fee_schedule"
