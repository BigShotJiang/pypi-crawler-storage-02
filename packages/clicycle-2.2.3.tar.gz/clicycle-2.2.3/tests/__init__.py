"""Tests for the Clicycle CLI framework."""
