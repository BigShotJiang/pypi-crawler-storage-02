"""
Authentication module for MCP STDIO adapter.

This module provides authentication and authorization capabilities
for MCP servers running in Azure Functions.
"""
