# fenix/config/settings.py

class Config:
    DEBUG = True
    TEMPLATE_FILE = "templates.html"
