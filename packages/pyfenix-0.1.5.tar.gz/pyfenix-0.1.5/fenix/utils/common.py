# tfenix/utils/common.py

def log(message):
    print(f"[FeniX]: {message}")
