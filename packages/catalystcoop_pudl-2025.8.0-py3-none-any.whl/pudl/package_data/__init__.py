"""Importable (dummy) package to include PUDL metadata structures."""
