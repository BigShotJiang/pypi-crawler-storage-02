"""Importable (dummy) package to enable distribution of PUDL metadata structures."""
