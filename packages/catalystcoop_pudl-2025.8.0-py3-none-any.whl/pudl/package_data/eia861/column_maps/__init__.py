"""Metadata linking semantic meaning of EIA 861 spreadsheet columns across years."""
