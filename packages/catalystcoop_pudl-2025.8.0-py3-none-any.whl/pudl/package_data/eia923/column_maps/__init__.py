"""Metadata linking semantic meaning of EIA 923 spreadsheet columns across years."""
