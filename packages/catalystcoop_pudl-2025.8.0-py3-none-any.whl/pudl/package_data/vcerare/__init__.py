"""CSV file extraction maps for VCE RARE Power Dataset."""
