"""CSV file extraction maps for EIA 757a."""
