"""Excel spreadsheet extraction maps for PHMSA gas data."""
