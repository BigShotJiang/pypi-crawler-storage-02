"""Metadata linking semantic meaning of EIA 860 spreadsheet columns across years."""
