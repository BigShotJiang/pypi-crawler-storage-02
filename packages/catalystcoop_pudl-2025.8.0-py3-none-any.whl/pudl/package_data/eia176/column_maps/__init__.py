"""Metadata linking semantic meaning of EIA 176 CSV file columns across years."""
