"""Metadata linking the semantic meaning of FERC 1 row numbers across years."""
