default_ifar_value = -1
