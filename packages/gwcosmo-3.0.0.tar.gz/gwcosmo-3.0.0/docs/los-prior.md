
Generating a line-of-sight redshift prior
=========================================

At the moment, the compatible catalogues are the GLADE 2.4 galaxy catalogue and the GLADE+ galaxy catalogue (see http://glade.elte.hu/ for details of what these catalogues contain, as well as citation instructions if you use them in an analysis).
