# mybmi
A simple BMI calculator for Python.

## Install
```bash
pip install mybmi
