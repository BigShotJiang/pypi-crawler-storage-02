from django.apps import AppConfig


class TwoStepVerificationConfig(AppConfig):
    name = 'admin_two_factor'
    verbose_name = 'two factor'
