---
name: General feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

Describe your idea in general, its use case and its benefits

**Specification and constraints**
- Add detailed specifications, constraints, options, alternatives etc.
- ...

If applicable, paste a design image supporting your proposal

```
If applicable, add proposed code snippets
```
