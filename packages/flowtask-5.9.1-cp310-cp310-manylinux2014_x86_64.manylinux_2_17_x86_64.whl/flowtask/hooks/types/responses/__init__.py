"""
Responses.

Pre-defined responses for Hooks.
"""
from .base import TriggerResponse

__all__ = ("TriggerResponse",)
