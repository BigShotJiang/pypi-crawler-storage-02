class TriggerResponse:
    """Basic Response.

    Basic Reponse dispatched by a Hook.
    """
