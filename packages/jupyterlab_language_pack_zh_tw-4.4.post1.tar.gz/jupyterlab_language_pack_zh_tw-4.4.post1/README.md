# Jupyterlab Chinese (Traditional, Taiwan) Language Pack

Chinese (Traditional, Taiwan) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-zh-TW
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-zh-TW
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
