# PINNFlow Documentation

PINNFlow is a code for regional outer core flow inversion, using Physics-Informed Neural Networks in a PyTorch framework. If you use this code, please [cite this paper](https://arxiv.org/abs/2504.02566).