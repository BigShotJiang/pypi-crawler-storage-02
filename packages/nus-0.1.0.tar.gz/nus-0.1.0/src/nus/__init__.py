"""Entry point for the nus application."""
