"""Contain the tests for the nus application."""
