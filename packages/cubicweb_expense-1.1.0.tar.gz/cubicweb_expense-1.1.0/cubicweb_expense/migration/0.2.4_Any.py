synchronize_permissions("Expense")
synchronize_permissions("ExpenseLine")
synchronize_permissions("has_lines")
