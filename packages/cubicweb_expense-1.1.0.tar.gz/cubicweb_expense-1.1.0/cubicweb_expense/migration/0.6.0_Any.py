sync_schema_props_perms("lives_at")
sync_schema_props_perms("has_lines")
