add_attribute("Refund", "payment_date")
add_attribute("Refund", "payment_mode")

add_attribute("CWUser", "ssnum")

add_package("addressbook")
