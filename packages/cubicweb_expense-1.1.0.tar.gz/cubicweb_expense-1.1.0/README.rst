This cube provides to implement `expense tracking application`_
by modeling `Expenses`, to ask for `Refund`.

.. _`expense tracking application`: http://www.cubicweb.org/project/cubicweb-fresh
