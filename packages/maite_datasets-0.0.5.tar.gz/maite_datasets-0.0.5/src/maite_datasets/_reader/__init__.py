"""
Dataset readers for common computer vision dataset formats.

This module provides standardized readers that for loading datasets
from directory structures.
"""
