# Unpage Documentation

## Running Locally

Install the Mintlify CLI:

```bash
npm i -g mint
```

Run the server:

```bash
mint dev
```

View the docs at http://localhost:3000
