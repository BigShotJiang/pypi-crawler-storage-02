import typer

tools_app = typer.Typer(
    context_settings={"help_option_names": ["-h", "--help"]},
    no_args_is_help=True,
    help="List and debug MCP tools",
)
