import typer

graph_app = typer.Typer(help="Build a knowledge graph", no_args_is_help=True)
