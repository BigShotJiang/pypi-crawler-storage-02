# V1EvaluatorView

EvaluatorView specifies the amount of information included in the Evaluator's description.   - EVALUATOR_VIEW_UNSPECIFIED: The default / unset value. The API will default to the EVALUATOR_VIEW_BRIEF.  - EVALUATOR_VIEW_BRIEF: Brief view of the Evaluator, which doesn't include the long description, only the brief one.  - EVALUATOR_VIEW_FULL: Full view of the evaluator, including brief and full description.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


