# V1DashboardStatus

 - DASHBOARD_STATUS_UNSPECIFIED: Unspecified status.  - DASHBOARD_STATUS_PROCESSING: Dashboard is being processed. At least one of the leaderboard has a processing status (but no failed status).  - DASHBOARD_STATUS_COMPLETED: Dashboard is completed successfully. All of the leaderboards are completed.  - DASHBOARD_STATUS_FAILED: Dashboard failed. At least one of the leaderboard failed.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


