# V1EvaluatorParamType

- EVALUATOR_PARAM_TYPE_BOOL: Boolean parameter type.  - EVALUATOR_PARAM_TYPE_INT: Integer parameter type.  - EVALUATOR_PARAM_TYPE_FLOAT: Float parameter type.  - EVALUATOR_PARAM_TYPE_STR: String parameter type.  - EVALUATOR_PARAM_TYPE_LIST: List parameter type.  - EVALUATOR_PARAM_TYPE_DICT: Dict parameter type.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


