{
    "name": "Runbot Odoo Module",
    "version": "1.3",
    "category": "Hidden",
    "description": "Sample Odoo runbot tester",
    "data": [],
    "demo": [],
    "assets": {},
    "installable": True,
    "auto_install": False,
    "license": "LGPL-3",
}
