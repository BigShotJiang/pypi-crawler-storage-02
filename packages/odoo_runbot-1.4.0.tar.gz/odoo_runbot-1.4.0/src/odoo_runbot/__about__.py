__version__ = "1.3.9"
__author__ = "Alexis Pasquier"
__author_email__ = "alexis.pasquier@mangono.io"
