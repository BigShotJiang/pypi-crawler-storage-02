from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M20SPlusV30


class BTMinerM20SPlusV30(M2X, M20SPlusV30):
    pass
