from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M21V10


class BTMinerM21V10(M2X, M21V10):
    pass
