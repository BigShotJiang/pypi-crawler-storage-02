from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M21SPlusV20


class BTMinerM21SPlusV20(M2X, M21SPlusV20):
    pass
