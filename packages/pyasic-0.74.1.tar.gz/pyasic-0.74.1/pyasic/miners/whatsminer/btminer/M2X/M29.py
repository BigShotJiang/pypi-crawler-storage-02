from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M29V10


class BTMinerM29V10(M2X, M29V10):
    pass
