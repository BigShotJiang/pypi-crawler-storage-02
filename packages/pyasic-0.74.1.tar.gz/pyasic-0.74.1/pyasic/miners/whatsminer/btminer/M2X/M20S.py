from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M20SV10


class BTMinerM20SV10(M2X, M20SV10):
    pass


from pyasic.miners.device.models import M20SV20


class BTMinerM20SV20(M2X, M20SV20):
    pass


from pyasic.miners.device.models import M20SV30


class BTMinerM20SV30(M2X, M20SV30):
    pass
