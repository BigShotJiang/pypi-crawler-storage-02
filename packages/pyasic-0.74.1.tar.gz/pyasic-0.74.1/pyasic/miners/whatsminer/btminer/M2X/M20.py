from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M20V10


class BTMinerM20V10(M2X, M20V10):
    pass
