from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M21SV20


class BTMinerM21SV20(M2X, M21SV20):
    pass


from pyasic.miners.device.models import M21SV60


class BTMinerM21SV60(M2X, M21SV60):
    pass


from pyasic.miners.device.models import M21SV70


class BTMinerM21SV70(M2X, M21SV70):
    pass
