from pyasic.miners.backends.espminer import ESPMiner


class LuckyMiner(ESPMiner):
    """Handler for LuckyMiner"""

    pass
