from src.mcp_server_dongjunqaq.tools import get_platform_info

print(get_platform_info())
