Triton kernels
