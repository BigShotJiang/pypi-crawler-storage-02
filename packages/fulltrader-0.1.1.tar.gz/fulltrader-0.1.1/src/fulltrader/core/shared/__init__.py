# Módulo compartilhado entre casos de uso


