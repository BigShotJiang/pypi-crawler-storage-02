"""Tests for multiple public items linter."""
