"""Test package for length checker linter."""
