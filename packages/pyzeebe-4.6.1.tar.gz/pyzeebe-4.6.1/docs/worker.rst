======
Worker
======

The page contains all information about the :py:class:`ZeebeWorker` class:


.. toctree::
   :name: worker

   Quickstart <worker_quickstart>
   Tasks <worker_tasks>
   TaskRouter <worker_taskrouter>
   Reference <worker_reference>
