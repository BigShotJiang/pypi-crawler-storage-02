from pyzeebe.errors.pyzeebe_errors import PyZeebeError


class MessageAlreadyExistsError(PyZeebeError):
    pass
