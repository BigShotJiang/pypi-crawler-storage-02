class ProcessRun:
    def __init__(self, instance_key: int, variables: dict):
        self.instance_key = instance_key
        self.variables = variables
