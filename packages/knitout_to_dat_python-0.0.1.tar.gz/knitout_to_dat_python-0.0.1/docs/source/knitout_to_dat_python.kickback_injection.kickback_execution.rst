knitout\_to\_dat\_python.kickback\_injection.kickback\_execution module
=======================================================================

.. automodule:: knitout_to_dat_python.kickback_injection.kickback_execution
   :members:
   :undoc-members:
   :show-inheritance:
