knitout\_to\_dat\_python.knitout\_to\_dat module
================================================

.. automodule:: knitout_to_dat_python.knitout_to_dat
   :members:
   :undoc-members:
   :show-inheritance:
