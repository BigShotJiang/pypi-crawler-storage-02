knitout\_to\_dat\_python package
================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   knitout_to_dat_python.dat_file_structure
   knitout_to_dat_python.kickback_injection

Submodules
----------

.. toctree::
   :maxdepth: 4

   knitout_to_dat_python.knitout_to_dat

Module contents
---------------

.. automodule:: knitout_to_dat_python
   :members:
   :undoc-members:
   :show-inheritance:
