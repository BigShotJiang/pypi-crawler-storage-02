knitout\_to\_dat\_python.dat\_file\_structure.dat\_codes.operation\_colors module
=================================================================================

.. automodule:: knitout_to_dat_python.dat_file_structure.dat_codes.operation_colors
   :members:
   :undoc-members:
   :show-inheritance:
