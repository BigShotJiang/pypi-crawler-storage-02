knitout\_to\_dat\_python.kickback\_injection.carriage\_pass\_with\_kick module
==============================================================================

.. automodule:: knitout_to_dat_python.kickback_injection.carriage_pass_with_kick
   :members:
   :undoc-members:
   :show-inheritance:
