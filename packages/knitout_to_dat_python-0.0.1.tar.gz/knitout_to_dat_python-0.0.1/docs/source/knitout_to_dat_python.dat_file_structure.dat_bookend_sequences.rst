knitout\_to\_dat\_python.dat\_file\_structure.dat\_bookend\_sequences module
============================================================================

.. automodule:: knitout_to_dat_python.dat_file_structure.dat_bookend_sequences
   :members:
   :undoc-members:
   :show-inheritance:
