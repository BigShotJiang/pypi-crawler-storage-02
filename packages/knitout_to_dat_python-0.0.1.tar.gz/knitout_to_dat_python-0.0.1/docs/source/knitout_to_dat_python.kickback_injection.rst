knitout\_to\_dat\_python.kickback\_injection package
====================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   knitout_to_dat_python.kickback_injection.carriage_pass_with_kick
   knitout_to_dat_python.kickback_injection.kickback_execution

Module contents
---------------

.. automodule:: knitout_to_dat_python.kickback_injection
   :members:
   :undoc-members:
   :show-inheritance:
