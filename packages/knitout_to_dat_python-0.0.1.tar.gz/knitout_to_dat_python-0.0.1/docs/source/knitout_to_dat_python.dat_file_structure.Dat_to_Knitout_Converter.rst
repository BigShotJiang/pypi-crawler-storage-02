knitout\_to\_dat\_python.dat\_file\_structure.Dat\_to\_Knitout\_Converter module
================================================================================

.. automodule:: knitout_to_dat_python.dat_file_structure.Dat_to_Knitout_Converter
   :members:
   :undoc-members:
   :show-inheritance:
