knitout\_to\_dat\_python.dat\_file\_structure.knitout\_to\_dat\_converter module
================================================================================

.. automodule:: knitout_to_dat_python.dat_file_structure.knitout_to_dat_converter
   :members:
   :undoc-members:
   :show-inheritance:
