## Aliyun ROS DATAWORKS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as DATAWORKS from '@alicloud/ros-cdk-dataworks';
```
