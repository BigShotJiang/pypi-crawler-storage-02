# gai-pull

gai-pull is a command-line tool to download GAI-supported models from huggingface.

### d) To download local models

```bash
uvx gai-pull llama3.1-exl2
```

---

## For Contributors

### a) To publish a new version

Make sure .pypirc is configured with your PyPI credentials.

```bash
make publish
```
