from gai.pull.gai_pull import pull

pull(model_name="llama3.1-exl2", dry_run=True)
