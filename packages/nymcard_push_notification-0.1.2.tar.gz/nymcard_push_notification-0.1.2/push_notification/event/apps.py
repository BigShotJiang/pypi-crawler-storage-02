from django.apps import AppConfig


class EventConfig(AppConfig):
    name = 'push_notification.event'
