displayer
---------

.. automodule:: rfcentral.displayer
   :members:
   :undoc-members:
   :show-inheritance:
