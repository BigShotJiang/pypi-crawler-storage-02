main
----

.. automodule:: rfcentral.main
   :members:
   :undoc-members:
   :show-inheritance:
