model
-----

.. automodule:: rfcentral.model
   :members:
   :undoc-members:
   :show-inheritance:
