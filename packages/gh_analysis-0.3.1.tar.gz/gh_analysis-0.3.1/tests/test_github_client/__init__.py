"""Tests for GitHub client package."""
