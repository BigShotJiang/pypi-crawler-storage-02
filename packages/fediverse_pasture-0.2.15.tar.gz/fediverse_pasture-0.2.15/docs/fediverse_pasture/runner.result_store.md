<!--
SPDX-FileCopyrightText: 2023 Helge

SPDX-License-Identifier: CC-BY-4.0
-->

::: fediverse_pasture.runner.result_store
    options:
        show_root_heading: true
        heading_level: 1
