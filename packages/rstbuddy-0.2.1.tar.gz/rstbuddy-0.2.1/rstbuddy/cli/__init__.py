from __future__ import annotations  # noqa: I001

from .cli import *  # noqa: F403
from .check_links import *  # noqa: F403
from .fix import *  # noqa: F403
from .summarize import *  # noqa: F403

# Import the other cli modules here, after the cli module
