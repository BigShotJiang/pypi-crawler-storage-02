from rstbuddy.cli import cli


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
