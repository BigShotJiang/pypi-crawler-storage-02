"""Qiskit-Braket exception."""


class QiskitBraketException(Exception):
    """Qiskit-Braket exception."""
