# from setuptools import setup
#
# setup(
#     name = "essopendata_theme",
#     version = "0.0.1",
#     author = "Coopdevs",
#     author_email = "info@coopdevs.org",
#     description = "CKAN ESS Opendata",
#     long_description = "Configuració CKAN de l'open data de l'ESS",
#     long_description_content_type = "text/markdown",
#     classifiers = [
#         "Programming Language :: Python :: 3",
#         "Operating System :: OS Independent",
#     ],
#     entry_points='''
#     [ckan.plugins]
#     essopendata_theme=ckanext.essopendata_theme.plugin:ESSOpendataThemePlugin
#    ''',
# )
#


from setuptools import setup
setup()