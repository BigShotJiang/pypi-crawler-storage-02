from .rule import MatchRule


__all__ = [
    "MatchRule",
]
