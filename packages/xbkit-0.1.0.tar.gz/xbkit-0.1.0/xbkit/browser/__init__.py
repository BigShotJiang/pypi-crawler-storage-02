from .client import BrowserClient


__all__ = [
    "BrowserClient",  # 浏览器客户端
]
