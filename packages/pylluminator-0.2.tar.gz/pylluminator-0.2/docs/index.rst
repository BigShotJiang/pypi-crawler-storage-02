.. include:: ../README.rst


Contents
--------

.. toctree::
   Home <self>
   tutorials
   annotations
   api
