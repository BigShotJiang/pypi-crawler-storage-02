Getting started
===============

.. toctree::
    :numbered:

    tutorials/1 - Read data and get betas.ipynb
    tutorials/2 - QC.ipynb
    tutorials/3 - Calculate DMP and DMR.ipynb
    tutorials/4 - Copy Number Variation.ipynb