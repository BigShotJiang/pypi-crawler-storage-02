

class ContentManagementPolicyError(Exception):
    """ Content Management Policy base error. """
    pass
