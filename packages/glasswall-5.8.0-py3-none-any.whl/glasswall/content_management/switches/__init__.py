

from glasswall.content_management.switches import archive, gif, jpeg, pdf, ppt, svg, sys, tiff, webp, word, xls
from glasswall.content_management.switches.switch import Switch
