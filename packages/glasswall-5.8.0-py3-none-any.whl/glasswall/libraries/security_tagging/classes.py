

class SecurityTaggingError(Exception):
    """ Base class for all SecurityTagging errors. """
    pass


class SecurityTaggingSuccess():
    """ Base class for all SecurityTagging successes. """
    pass
