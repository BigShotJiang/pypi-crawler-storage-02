

class EditorError(Exception):
    """ Base class for all Glasswall Editor errors. """
    pass


class EditorSuccess:
    """ Base class for all Glasswall Editor successes. """
    pass
