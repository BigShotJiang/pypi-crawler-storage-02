

class ArchiveManagerError(Exception):
    """ Base class for all Glasswall ArchiveManager errors. """
    pass


class ArchiveManagerSuccess:
    """ Base class for all Glasswall ArchiveManager successes. """
    pass
