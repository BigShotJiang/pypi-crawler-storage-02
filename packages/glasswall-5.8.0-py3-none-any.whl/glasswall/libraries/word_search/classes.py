

class WordSearchError(Exception):
    """ Base class for all WordSearch errors. """
    pass


class WordSearchSuccess():
    """ Base class for all WordSearch successes. """
    pass
