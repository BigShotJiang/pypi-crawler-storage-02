

class RebuildError(Exception):
    """ Base class for all Glasswall Rebuild errors. """
    pass


class RebuildSuccess:
    """ Base class for all Glasswall Rebuild successes. """
    pass
