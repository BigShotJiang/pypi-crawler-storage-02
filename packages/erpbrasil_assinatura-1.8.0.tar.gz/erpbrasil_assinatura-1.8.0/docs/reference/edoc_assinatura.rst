edoc_assinatura
===============

.. testsetup::

    from erpbrasil.assinatura import *

.. automodule:: erpbrasil.assinatura
    :members:
