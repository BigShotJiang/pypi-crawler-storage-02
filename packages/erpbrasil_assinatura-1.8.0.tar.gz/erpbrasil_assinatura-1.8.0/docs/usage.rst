=====
Usage
=====

To use erpbrasil.assinatura in a project::

	import erpbrasil.assinatura
