"""Init for ReadSam."""
from __future__ import absolute_import
from .diff_segment import *
from .methyl_segment import *
from .methyl_annotate import *
from .methyl_regions import *