2024-05-17 Version: 1.4.0
- Support API CreateLink.
- Support API QueryInfoFromMdp.
- Support API QueryLink.
- Update API PushMultiple: add param ActivityContentState.
- Update API PushMultiple: add param ActivityEvent.
- Update API PushMultiple: add param DismissalDate.
- Update API PushSimple: add param ActivityContentState.
- Update API PushSimple: add param ActivityEvent.
- Update API PushSimple: add param DismissalDate.
- Update API PushTemplate: add param ActivityContentState.
- Update API PushTemplate: add param ActivityEvent.
- Update API PushTemplate: add param DismissalDate.


2024-02-06 Version: 1.3.0
- Generated python 2020-10-28 for mPaaS.

2024-01-19 Version: 1.2.2
- Generated python 2020-10-28 for mPaaS.

2024-01-18 Version: 1.2.1
- Generated python 2020-10-28 for mPaaS.

2023-12-05 Version: 1.2.0
- Generated python 2020-10-28 for mPaaS.

2023-08-29 Version: 1.1.0
- Generated python 2020-10-28 for mPaaS.

2023-03-31 Version: 1.0.0
- Support vivo classification.

