"""asammdf tool module"""

from .version import __version__ as v__

__tool__ = "asammdf"
__tool_short__ = "amdf"
__vendor__ = "asammdf"
__version__ = v__
