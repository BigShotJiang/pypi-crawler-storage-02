Under some circumstances, Odoo fails to calculate employee overtime correctly.
Examples:
- When you enable HR contracts in your database after using attendances for some time.
- When some change in a contract's working schedule should affect the result of overtime in past attendances.
This module was developed to fix that problem.