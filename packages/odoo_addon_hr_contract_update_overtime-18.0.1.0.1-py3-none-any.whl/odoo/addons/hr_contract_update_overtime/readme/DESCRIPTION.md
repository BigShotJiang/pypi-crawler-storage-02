This module extends the functionality of Contracts and Attendances to support
recalculating Overtime accurately, even if the contracts have changed over time.