To use this module, follow the steps below:

- **To update a single contract:**
    1. Go to **Employees** > **Employees**
    2. Select an employee
    3. Click the **In Contract Since...** button
    4. Click the **⚙️ actions wheel** icon.
    5. Click **Update Overtime**

- **To update multiple contracts at once:**
    1. Go to **Employees** > **Contracts**
    2. Select the contracts you want to update
    3. Click the **⚙️ actions wheel** icon
    4. Click **Update Overtime**