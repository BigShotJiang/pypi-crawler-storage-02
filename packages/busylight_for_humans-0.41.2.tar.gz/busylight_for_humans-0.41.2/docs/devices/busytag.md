![BusyLight Project Logo][1]

## [Busy Tag][0]

### Physical Description

#### Busy Tag

### Basic Human Interface Device Info

- Vendor/Product ID Values:
  - 0x303a, 0x81df: Busy Tag
  
- I/O Interface: USB Serial read/write
- Command Length: variable

### Command Reference

See the [Busy Tag USB CDC Command Reference Guide][2] for more information.

### Device Operation

### Activating With a RGB Color

### Observations


[0]: https://busy-tag.com
[1]: ../assets/Unstacked-Logo-Light.png
[2]: https://luxafor.helpscoutdocs.com/article/47-busy-tag-usb-cdc-command-reference-guide
