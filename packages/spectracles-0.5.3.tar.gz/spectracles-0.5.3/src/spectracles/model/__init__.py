"""model - subpackage for modelling framework built on jax and equinox."""
