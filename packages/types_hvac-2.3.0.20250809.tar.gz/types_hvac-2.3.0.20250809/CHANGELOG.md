## 2.3.0.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 2.3.0.20250516 (2025-05-16)

Replace `Incomplete | None = None` in third party stubs (#14063)

## 2.3.0.20250429 (2025-04-29)

[hvac] Clarify and improve some annotations (#13886)

## 2.3.0.20240621 (2024-06-21)

Bump hvac to 2.3.* (#12168)

## 2.2.0.20240522 (2024-05-22)

[stubsabot] Bump hvac to 2.2.* (#11839)

## 2.1.0.20240514 (2024-05-14)

Complete types for hvac.v1.Client (#11886)

## 2.1.0.20240329 (2024-03-29)

Improve hvac adapter types (#11659)

## 2.1.0.20240326 (2024-03-26)

Add type stubs for hvac (#11591)

