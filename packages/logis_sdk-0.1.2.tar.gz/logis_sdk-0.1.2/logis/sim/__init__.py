__doc__ = """
仿真模块
"""


def test():
    """
    测试函数
    """
    print("This is a test function in the sim module.")
