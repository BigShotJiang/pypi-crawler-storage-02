from .huggingface import Parameter as Huggingface
from .llamaparser import Parameter as Llamaparser
from .mistralocr import Parameter as  Mistralocr