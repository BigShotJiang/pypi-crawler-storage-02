"""Test suite for ABayes library.

This package contains comprehensive tests for all ABayes functionality,
including unit tests, integration tests, and statistical validation tests.
"""
