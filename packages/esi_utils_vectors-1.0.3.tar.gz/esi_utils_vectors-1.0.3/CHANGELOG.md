# CHANGELOG

## main



## v1.0.3 / 2025-08-11
 - Add CHANGELOG.md
 - Set numpy >=1.26
 - Set python >= 3.9
 - Fix deprecation warning.
