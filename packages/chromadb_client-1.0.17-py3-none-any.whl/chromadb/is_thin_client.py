is_thin_client = True
