# vdiff

`vdiff` is a Python CLI tool to compare multiple XML files against a main XML file.

Features:
- Show differences
- Filter by labels
- Export results to Excel

