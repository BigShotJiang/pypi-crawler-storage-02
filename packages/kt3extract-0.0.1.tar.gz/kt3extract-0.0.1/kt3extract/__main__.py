"""Makes module executable by `python -m splive`."""

from kt3extract.kt3extract import main

if __name__ == "__main__":
    main()
