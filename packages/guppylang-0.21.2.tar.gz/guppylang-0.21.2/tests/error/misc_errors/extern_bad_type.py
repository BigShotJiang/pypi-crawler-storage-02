from guppylang.decorator import guppy

x = guppy._extern("x", ty="float[int]")

x.compile()
