from tests.util import compile_guppy


@compile_guppy
def f(x: "int.bar") -> None:
    return
