from tests.util import compile_guppy


@compile_guppy
def foo() -> None:
    f = len
