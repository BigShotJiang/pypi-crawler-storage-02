import enum

class SourceEnum(enum.Enum):
    douyin = "douyin"
    toutiao = "toutiao"
    weibo = "weibo"
    wechat = "wechat"
    south_weekend = "south_weekend"
