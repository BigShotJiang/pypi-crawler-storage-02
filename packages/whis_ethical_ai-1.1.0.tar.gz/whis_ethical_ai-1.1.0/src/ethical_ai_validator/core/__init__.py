"""Core module for Ethical AI Validator."""

from .validator import EthicalAIValidator

__all__ = ["EthicalAIValidator"] 