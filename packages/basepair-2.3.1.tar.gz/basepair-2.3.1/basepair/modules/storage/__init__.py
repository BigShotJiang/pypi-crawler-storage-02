"""Infra storage modules"""
from basepair.modules.storage.main import Storage
