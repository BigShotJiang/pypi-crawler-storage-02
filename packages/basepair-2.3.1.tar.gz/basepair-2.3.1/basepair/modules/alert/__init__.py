'''Alert module'''
from .alert import Alert
