'''Drivers for logger'''
from .abstract import LogAbstract
