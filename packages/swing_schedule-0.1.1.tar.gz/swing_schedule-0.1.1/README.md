# Swing Schedules Generator

Generates schedules for schools teaching partner dances.

## Install

You need `python3` and `pip` to use this tool.
```
python3 -m pip install --extra-index-url https://test.pypi.org/simple/ swing-schedule
```

## Run
```
swing-schedule -t /usr/local/lib/python*/site-packages/swing_schedule/data/teachers.csv
```
