# Open Meteo Data - API Client

Python API client for the open meteo data V1 service, provided by _Provincia autonoma di Bolzano - Informatica Alto Adige SPA_. Its legal terms can be found [here](https://data.civis.bz.it/legal). The documentation of the API is available [here](https://data.civis.bz.it/dataset/misure-meteo-e-idrografiche).
