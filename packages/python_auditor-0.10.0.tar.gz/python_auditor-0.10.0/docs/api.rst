.. _ref_api:

=================
API Documentation
=================


.. automodule:: pyauditor
   :members:
   :undoc-members:
