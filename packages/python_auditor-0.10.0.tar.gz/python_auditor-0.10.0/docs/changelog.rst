.. _ref_changelog:

.. include:: ../../CHANGELOG.md
   :parser: myst_parser.sphinx_
