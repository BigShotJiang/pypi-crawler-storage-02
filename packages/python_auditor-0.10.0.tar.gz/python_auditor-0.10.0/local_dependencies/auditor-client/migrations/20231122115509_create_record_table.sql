CREATE TABLE IF NOT EXISTS inserts (
    record      BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS updates (
    record      BLOB NOT NULL
);
