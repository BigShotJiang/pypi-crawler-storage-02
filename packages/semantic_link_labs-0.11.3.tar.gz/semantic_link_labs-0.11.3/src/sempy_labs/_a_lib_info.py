lib_name = "semanticlinklabs"
lib_version = "0.11.3"
