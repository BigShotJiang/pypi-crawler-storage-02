def hello() -> str:
    return "Hello from bao0.2!"
