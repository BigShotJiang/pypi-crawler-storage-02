from pandahub.api.settings import PandaHubAppSettings

pandahub_app_settings = PandaHubAppSettings()
