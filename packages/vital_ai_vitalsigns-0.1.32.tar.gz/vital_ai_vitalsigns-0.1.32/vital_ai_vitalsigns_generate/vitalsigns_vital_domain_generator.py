from vital_ai_vitalsigns_generate.vitalsigns_ontology_generator import VitalSignsOntologyGenerator


class VitalSignsVitalDomainGenerator(VitalSignsOntologyGenerator):
    def __init__(self):
        pass

    def generate(self, iri_to_file_map: dict):
        pass

