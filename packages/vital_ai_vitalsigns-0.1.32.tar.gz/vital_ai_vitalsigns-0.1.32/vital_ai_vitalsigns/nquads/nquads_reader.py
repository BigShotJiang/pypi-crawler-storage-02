


# TODO follow pattern of ntriples reader

class NQuadsReader:
    pass

