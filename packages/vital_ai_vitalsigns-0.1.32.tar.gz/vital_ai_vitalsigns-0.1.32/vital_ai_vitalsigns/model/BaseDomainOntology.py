class BaseDomainOntology:
    OntologyURI = ''
