from abc import ABC


class BaseService(ABC):
    pass
