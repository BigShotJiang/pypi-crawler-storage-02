
# implementation of vital service using vitalgraph
# based on TiDB deployed in kubernetes

