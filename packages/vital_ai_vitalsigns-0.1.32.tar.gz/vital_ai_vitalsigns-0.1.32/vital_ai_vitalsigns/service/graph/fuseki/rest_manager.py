

class FusekiRESTManager:
    pass

# handle fuseki rest calls



