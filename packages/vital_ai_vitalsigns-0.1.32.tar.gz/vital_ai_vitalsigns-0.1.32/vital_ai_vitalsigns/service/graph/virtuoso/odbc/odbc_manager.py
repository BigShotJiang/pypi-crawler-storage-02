
class VirtuosoODBCManager:
    pass

# handle odbc calls

