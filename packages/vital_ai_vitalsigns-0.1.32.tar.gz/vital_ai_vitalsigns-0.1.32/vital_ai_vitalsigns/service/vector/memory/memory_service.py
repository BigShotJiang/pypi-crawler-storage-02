

class VectorMemoryService:
    pass
