

class WeaviateResultElement:
    pass

