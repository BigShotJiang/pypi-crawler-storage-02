

class WeaviateUtils:
    pass

