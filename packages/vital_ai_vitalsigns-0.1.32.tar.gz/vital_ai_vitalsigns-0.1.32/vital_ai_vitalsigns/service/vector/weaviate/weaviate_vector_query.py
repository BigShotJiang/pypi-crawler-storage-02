

# use for an internal representation of the query
# result of converting metaql to graphql

class WeaviateVectorQuery:

    page_size: int
    current_index : int

    graph_ql: str


