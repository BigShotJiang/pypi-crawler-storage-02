
class WeaviateResultList:
    pass

