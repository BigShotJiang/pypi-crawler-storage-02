from typing import List
from vital_ai_vitalsigns.service.vector.vector_collection import VitalVectorCollection


class VitalVectorResult:

    collection_list: List[VitalVectorCollection]
