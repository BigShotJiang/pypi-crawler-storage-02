from rdflib import Graph

# use of owl-rl to implement a deductive Graph via underlying RDFLib Graph

class DeductiveCollectionImpl:
    def __init__(self):
        pass

