

class AbstractTypeCollection:
    pass

    # used for instantiations of individuals defined in ontologies
    # to be used as constants, especially the URI value
    # as classes extend classes, ATCs may extend the ATCs of parent classes
    # which allows accessing the parent class individuals via the child
    # class ATC

