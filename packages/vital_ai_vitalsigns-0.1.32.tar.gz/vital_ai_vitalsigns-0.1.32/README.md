# VitalSigns

## General Documentation:
[https://docs.vital.ai/vitalsigns](https://docs.vital.ai/vitalsigns)

## VitalSigns Documentation:
[https://vital-ai.gitbook.io/vitalsigns-python-documentation/](https://vital-ai.gitbook.io/vitalsigns-python-documentation/)

