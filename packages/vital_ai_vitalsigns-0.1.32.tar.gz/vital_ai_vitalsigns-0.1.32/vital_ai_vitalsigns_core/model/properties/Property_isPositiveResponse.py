from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_isPositiveResponse(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "isPositiveResponse"
    multiple_values = False
