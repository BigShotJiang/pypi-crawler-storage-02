from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasCollectionClassName(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasCollectionClassName"
    multiple_values = False
