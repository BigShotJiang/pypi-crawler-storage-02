from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasDateRetrieved(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasDateRetrieved"
    multiple_values = False
