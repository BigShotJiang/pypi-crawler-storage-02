from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasSegmentTenantID(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasSegmentTenantID"
    multiple_values = False
