from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasTransactionState(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasTransactionState"
    multiple_values = False
