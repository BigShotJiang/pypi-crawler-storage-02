from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_isSegmentGlobal(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "isSegmentGlobal"
    multiple_values = False
