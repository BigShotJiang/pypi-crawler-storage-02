from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasBackwardCompVersion(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasBackwardCompVersion"
    multiple_values = False
