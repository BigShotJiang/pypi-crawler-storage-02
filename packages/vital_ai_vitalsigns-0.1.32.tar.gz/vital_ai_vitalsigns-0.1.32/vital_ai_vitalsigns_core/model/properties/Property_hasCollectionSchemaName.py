from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasCollectionSchemaName(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasCollectionSchemaName"
    multiple_values = False
