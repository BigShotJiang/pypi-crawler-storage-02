from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasDatabase(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasDatabase"
    multiple_values = False
