from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_isReadOnly(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "isReadOnly"
    multiple_values = False
