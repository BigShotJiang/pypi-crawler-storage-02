from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasTargetAppID(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasTargetAppID"
    multiple_values = False
