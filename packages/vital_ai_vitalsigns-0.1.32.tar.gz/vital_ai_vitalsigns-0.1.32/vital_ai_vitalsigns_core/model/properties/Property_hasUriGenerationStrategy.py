from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasUriGenerationStrategy(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasUriGenerationStrategy"
    multiple_values = False
