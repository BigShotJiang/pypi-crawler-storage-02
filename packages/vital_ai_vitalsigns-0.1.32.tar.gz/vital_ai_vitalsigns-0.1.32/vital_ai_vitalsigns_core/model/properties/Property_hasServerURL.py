from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasServerURL(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasServerURL"
    multiple_values = False
