from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasSerializedRDF(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasSerializedRDF"
    multiple_values = False
