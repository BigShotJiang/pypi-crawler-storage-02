from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasAggregationType(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasAggregationType"
    multiple_values = False
