from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasOntologyIRI(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasOntologyIRI"
    multiple_values = False
