from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasName(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasName"
    multiple_values = False
