from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_isIncludesSubclasses(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "isIncludesSubclasses"
    multiple_values = False
