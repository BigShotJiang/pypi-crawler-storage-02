
from vital_ai_vitalsigns.model.BaseDomainOntology import BaseDomainOntology


class DomainOntology(BaseDomainOntology):
    OntologyURI = "http://vital.ai/ontology/vital-core"
