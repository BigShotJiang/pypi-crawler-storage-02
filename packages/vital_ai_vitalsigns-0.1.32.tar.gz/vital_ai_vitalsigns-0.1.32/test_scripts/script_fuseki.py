

def main():
    print("Test Fuseki Connection")


if __name__ == "__main__":
    main()

