# LongAI Python Library

Python client for interacting with the LongAI API.

## Installation

```bash
pip install LongAI