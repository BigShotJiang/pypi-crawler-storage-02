from .api import LongAI

request = LongAI()