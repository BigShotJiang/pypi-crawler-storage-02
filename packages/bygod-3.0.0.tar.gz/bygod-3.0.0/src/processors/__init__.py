"""
Processors package for Bible Gateway Downloader.

This package contains modules for processing Bible downloads, including
book processing, translation processing, and master file generation.
"""
