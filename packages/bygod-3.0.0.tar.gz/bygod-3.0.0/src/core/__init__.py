"""Core package for Bible Gateway Downloader."""
