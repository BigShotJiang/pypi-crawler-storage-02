"""Constants package for Bible Gateway Downloader."""
