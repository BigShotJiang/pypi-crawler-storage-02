"""
CLI package for Bible Gateway Downloader.

This package contains modules for command-line interface functionality,
including argument parsing and validation.
"""
