// Other data Polars type definitions will be moved into this crate later, for
// now it only contains the categorical mappings.

pub mod categorical;
