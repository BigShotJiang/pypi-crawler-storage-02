# polars-json

`polars-json` is an **internal sub-crate** of the [Polars](https://crates.io/crates/polars) library,
provides functionalities to handle JSON objects.

**Important Note**: This crate is **not intended for external usage**. Please refer to the main
[Polars crate](https://crates.io/crates/polars) for intended usage.
