"""Main module entry point for zero-log-parser package."""

from .cli import main

if __name__ == '__main__':
    main()