from maleo.soma.mixins.parameter import Expand as BaseExpand
from maleo.identity.enums.user_organization import ExpandableField


class Expand(BaseExpand[ExpandableField]):
    pass
