from enum import StrEnum


class ExpandableField(StrEnum):
    SYSTEM_ROLE = "system_role"
