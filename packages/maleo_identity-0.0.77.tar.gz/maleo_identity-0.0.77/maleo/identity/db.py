from maleo.soma.managers.db import create_base


MaleoIdentityBase = create_base()
