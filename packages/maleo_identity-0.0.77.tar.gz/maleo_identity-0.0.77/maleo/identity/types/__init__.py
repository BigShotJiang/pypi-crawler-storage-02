from .results import MaleoIdentityResultsTypes


class MaleoIdentityTypes:
    Results = MaleoIdentityResultsTypes
