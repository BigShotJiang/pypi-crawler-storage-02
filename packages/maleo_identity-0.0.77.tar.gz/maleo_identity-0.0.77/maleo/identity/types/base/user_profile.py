from typing import Union


IdentifierValueType = Union[int, str]
