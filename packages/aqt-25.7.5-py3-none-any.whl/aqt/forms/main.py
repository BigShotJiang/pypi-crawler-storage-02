from _aqt.forms.main_qt6 import *
