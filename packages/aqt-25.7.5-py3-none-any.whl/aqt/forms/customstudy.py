from _aqt.forms.customstudy_qt6 import *
