from _aqt.forms.getaddons_qt6 import *
