from _aqt.forms.finddupes_qt6 import *
