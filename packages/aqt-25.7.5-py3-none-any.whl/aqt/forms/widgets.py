from _aqt.forms.widgets_qt6 import *
