from _aqt.forms.emptycards_qt6 import *
