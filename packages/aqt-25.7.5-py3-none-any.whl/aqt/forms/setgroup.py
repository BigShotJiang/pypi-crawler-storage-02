from _aqt.forms.setgroup_qt6 import *
