from _aqt.forms.template_qt6 import *
