from _aqt.forms.setlang_qt6 import *
