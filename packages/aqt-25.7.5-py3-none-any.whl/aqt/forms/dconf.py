from _aqt.forms.dconf_qt6 import *
