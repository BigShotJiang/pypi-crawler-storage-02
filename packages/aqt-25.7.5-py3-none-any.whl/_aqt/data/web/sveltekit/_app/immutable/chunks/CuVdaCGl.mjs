import{T as n,S as d}from"./3W_oWfQO.mjs";function s(t,e,i){var a=n(t,e);a&&a.set&&(t[e]=i,d(()=>{t[e]=null}))}export{s as b};
