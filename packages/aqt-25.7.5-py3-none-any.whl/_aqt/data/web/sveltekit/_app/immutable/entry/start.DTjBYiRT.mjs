import{l as o,a as r}from"../chunks/qyhcBn5y.mjs";export{o as load_css,r as start};
