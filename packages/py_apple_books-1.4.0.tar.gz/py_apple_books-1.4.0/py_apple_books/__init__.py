from .api import PyAppleBooks

__all__ = ['PyAppleBooks']

__version__ = '1.4.0'
