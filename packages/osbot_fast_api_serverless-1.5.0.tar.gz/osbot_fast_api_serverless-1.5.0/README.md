# OSBot-Fast-API-Serverless
Repo for OSBot-Fast-API-Serverless

![Current Release](https://img.shields.io/badge/release-v1.5.0-blue)
