Welcome to SPARCL's documentation!
==================================

This documents the Python Client for SPARCL
(*SPectra Analysis and Retrievable Catalog Lab*)

| Last change: |today|
| Version: |version|
| Release: |release|

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   sparcl


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`

License
=======

.. mdinclude:: ../LICENSE
