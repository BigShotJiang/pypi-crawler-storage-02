sparcl package
==============


sparcl.client module
--------------------

.. automodule:: sparcl.client
   :members:
   :show-inheritance:


sparcl.exceptions module
------------------------

.. automodule:: sparcl.exceptions
   :members:
   :show-inheritance:

sparcl.Results module
---------------------

.. automodule:: sparcl.Results
   :members:
   :inherited-members:
   :show-inheritance:
