# test-mcp

A set of mathematical tools (matrix multiplication, quadratic solver, and eigenvalue/eigenvector solver) as MCP tools.
