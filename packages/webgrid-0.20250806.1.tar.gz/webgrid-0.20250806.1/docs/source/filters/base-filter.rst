Base Filters
============

.. autoclass:: webgrid.filters.Operator
    :members:

.. autoclass:: webgrid.filters.FilterBase
    :members:

.. autoclass:: webgrid.filters.OptionsFilterBase
    :members:

.. autoclass:: webgrid.filters.OptionsIntFilterBase
    :members:
