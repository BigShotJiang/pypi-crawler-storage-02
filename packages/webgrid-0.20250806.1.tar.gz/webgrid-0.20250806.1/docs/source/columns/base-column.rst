Base Column and ColumnGroup
===========================

.. autoclass:: webgrid.Column
    :members:

.. autoclass:: webgrid.ColumnGroup
    :members:
