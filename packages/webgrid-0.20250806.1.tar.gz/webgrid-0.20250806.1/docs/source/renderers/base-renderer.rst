Base Renderer
=============

.. autoclass:: webgrid.renderers.Renderer
    :members:
    :inherited-members:
