from dbt.tests.adapter.utils.test_right import BaseRight


class TestRightFabric(BaseRight):
    pass
