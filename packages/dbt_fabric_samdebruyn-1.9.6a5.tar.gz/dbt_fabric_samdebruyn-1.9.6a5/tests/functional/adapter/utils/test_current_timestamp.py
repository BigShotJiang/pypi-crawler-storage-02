from dbt.tests.adapter.utils.test_current_timestamp import (
    BaseCurrentTimestamp,
    BaseCurrentTimestampNaive,
)


class TestCurrentTimestampFabric(BaseCurrentTimestamp):
    pass


class TestCurrentTimestampNaiveFabric(BaseCurrentTimestampNaive):
    pass
