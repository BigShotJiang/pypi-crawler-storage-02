from dbt.tests.adapter.utils.test_string_literal import BaseStringLiteral


class TestStringLiteralFabric(BaseStringLiteral):
    pass
