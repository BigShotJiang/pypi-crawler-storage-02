from dbt.tests.adapter.utils.test_replace import BaseReplace


class TestReplaceFabric(BaseReplace):
    pass
