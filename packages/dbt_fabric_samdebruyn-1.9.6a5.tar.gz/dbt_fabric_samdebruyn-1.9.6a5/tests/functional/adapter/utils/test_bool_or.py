from dbt.tests.adapter.utils.test_bool_or import BaseBoolOr


class TestBoolOrFabric(BaseBoolOr):
    pass
