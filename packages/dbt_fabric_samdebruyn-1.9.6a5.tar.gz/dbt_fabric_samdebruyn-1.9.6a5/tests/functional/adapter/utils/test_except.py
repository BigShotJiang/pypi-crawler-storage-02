from dbt.tests.adapter.utils.test_except import BaseExcept


class TestExceptFabric(BaseExcept):
    pass
