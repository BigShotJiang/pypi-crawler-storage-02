from dbt.tests.adapter.utils.test_any_value import BaseAnyValue


class TestAnyValueFabric(BaseAnyValue):
    pass
