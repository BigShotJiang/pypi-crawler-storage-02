from dbt.tests.adapter.utils.test_date_spine import BaseDateSpine


class TestDateSpineFabric(BaseDateSpine):
    pass
