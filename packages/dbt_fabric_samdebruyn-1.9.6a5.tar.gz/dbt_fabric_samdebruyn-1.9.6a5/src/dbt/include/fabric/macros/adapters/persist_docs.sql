{# we don't support "persist docs" today, but we'd like to!
  https://github.com/dbt-msft/dbt-sqlserver/issues/134

 #}
