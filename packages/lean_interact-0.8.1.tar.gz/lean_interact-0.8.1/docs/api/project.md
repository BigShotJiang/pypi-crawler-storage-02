::: lean_interact.project
    options:
      heading_level: 1
      heading: "Projects"
      show_symbol_type_heading: false
      members:
        - LocalProject
        - GitProject
        - TemporaryProject
        - TempRequireProject
        - LeanRequire
