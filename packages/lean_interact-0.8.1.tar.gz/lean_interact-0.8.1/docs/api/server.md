::: lean_interact.server
    options:
      heading_level: 1
      heading: "Lean Servers"
      show_symbol_type_heading: false
      members:
        - LeanServer
        - AutoLeanServer
