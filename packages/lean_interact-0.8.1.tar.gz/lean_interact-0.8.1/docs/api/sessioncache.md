::: lean_interact.sessioncache
    options:
      heading_level: 1
      heading: "Session Cache"
      show_symbol_type_heading: false
      members:
        - PickleSessionCache
        - SessionState
        - PickleSessionState
