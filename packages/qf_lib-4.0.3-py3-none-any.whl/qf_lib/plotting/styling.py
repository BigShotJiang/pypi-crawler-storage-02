#     Copyright 2016-present CERN – European Organization for Nuclear Research
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.

def add_style_lib(lib_path: str):
    """
    Parameters
    ----------
    lib_path
        absolute path to the directory containing .mplstyle files
    """
    import matplotlib.style.core as style_core

    style_core.USER_LIBRARY_PATHS.append(lib_path)
    style_core.reload_library()
