"""Allow running the MCP server as a module with python -m codex_as_mcp"""

from .server import main

if __name__ == "__main__":
    main()