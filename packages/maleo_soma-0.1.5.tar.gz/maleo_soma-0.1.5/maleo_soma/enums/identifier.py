from enum import StrEnum


class DataIdentifier(StrEnum):
    ID = "id"
    UUID = "uuid"
