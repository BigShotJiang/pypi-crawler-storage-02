from .local_loader import LocalLoader
from .web_loader import WebLoader

__all__ = ["LocalLoader", "WebLoader"]
