"""Dana2 CLI."""

from . import main

main()
