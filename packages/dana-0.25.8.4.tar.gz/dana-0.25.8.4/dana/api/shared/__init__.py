"""Shared resources for Dana API."""
