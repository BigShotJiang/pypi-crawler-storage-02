# metaspector/_exceptions.py
# !/usr/bin/env python3


class MetaspectorError(Exception):
    """Base exception for the metaspector library."""

    pass
