"""Entry point for running MCP feet Master as a module."""

from .server import main

if __name__ == "__main__":
    main()