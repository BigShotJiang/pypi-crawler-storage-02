# src\amo_connector\__init__.py

from .pyamocrm import AMOConnector
from .structs import AMOLicense, AMOUser, LicenseStates

version = "0.1.0"