# src\amo_connector\structs.py

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


class LicenseStates:
    FirstContact = 78617178
    Negotiations = 78617182
    Deciding = 78617186
    ContractConditions = 78617190
    Closed = 142
    Canceled = 143


@dataclass
class AMOUser:
    id: int = 0
    name: str = ""
    reg_date: datetime = datetime.now()
    email: str = ""
    phone: int = 0
    comment: str = ""
    enter_point: str = ""


@dataclass
class AMOLicense:
    license_name: str
    status: int
    client: AMOUser
    amount: int = 0
    license_id: int = 0
    comment: str = ""
    license_reg_date: Optional[datetime] = None
    license_close_date: datetime = datetime.now()
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    period: Optional[datetime] = None
    pipeline_id: int = 0
