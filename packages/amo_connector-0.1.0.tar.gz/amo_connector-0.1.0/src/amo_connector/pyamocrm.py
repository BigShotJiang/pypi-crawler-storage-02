# src\amo_connector\pyamocrm.py

import requests
import datetime
from typing import Any

from src.amo_connector.structs import AMOUser, AMOLicense, LicenseStates

from src.amo_connector.time_transistors import dt_ts, ts_dt

users_list = {}

EMAIL_FIELD_ID = 1733075
PHONE_FIELD_ID = 1733073
COMMENT_FIELD_ID = 1734089
LIC_COMMENT_FIELD_ID = 1733127
START_DATE_FIELD_ID = 1751751
END_DATE_FIELD_ID = 1751757
PERIOD_FIELD_ID = 1751755


class AMOConnector:
    def __init__(
        self,
        login,
        token,
        email_field_id=None,
        phone_field_id=None,
        comment_field_id=None,
        lic_comment_field_id=None,
        start_date_field_id=None,
        end_date_field_id=None,
        period_field_id=None,
    ):
        """
        под license подразумевается лицензия, на любом из этапов
        login - логин amocrm, содержится в ссылке на лк(https://*ЛОГИН*.amocrm.ru)
        token - токен для входа в аккаунт, желательно использовать долгострочный
        email, phone, comment field ids - три основных поля для контактов, для каждого из которых есть уникальный field id. чтобы найти сделайте GET какого либо контакта, и оттуда копируйте эти id
        lic_comment, start_date, end_date, period - три кастомных поля, которые нужно создать вручную в меню сделок. Используются для лицензий, найти также, как и три поля сверху
        """

        self.login = login
        self.token = token

        self.field_ids = {
            "email_field_id": email_field_id or EMAIL_FIELD_ID,
            "phone_field_id": phone_field_id or PHONE_FIELD_ID,
            "comment_field_id": comment_field_id or COMMENT_FIELD_ID,
            "lic_comment_field_id": lic_comment_field_id or LIC_COMMENT_FIELD_ID,
            "start_date_field_id": start_date_field_id or START_DATE_FIELD_ID,
            "end_date_field_id": end_date_field_id or END_DATE_FIELD_ID,
            "period_field_id": period_field_id or PERIOD_FIELD_ID,
        }

        self.account_link = f"https://{self.login}.amocrm.ru/api/v4/contacts"
        self.license_link = f"https://{self.login}.amocrm.ru/api/v4/leads"

    def get_account(self, id: int) -> AMOUser:
        """
        по выбранному id возвращает объект запрошенного контакта
        """
        headers = {"Authorization": f"Bearer {self.token}"}
        link = f"{self.account_link}/{id}"

        response = requests.get(link, headers=headers)

        response = response.json()

        custom_fields_values = response["custom_fields_values"]

        email = ""
        phone_num = 0
        comment = ""

        for i in custom_fields_values:

            field_id = i["field_id"]

            if field_id == self.field_ids["phone_field_id"]:

                full_phone = i["values"]
                phone_num = full_phone[0]["value"]

            elif field_id == self.field_ids["email_field_id"]:
                full_email = i["values"]
                email = full_email[0]["value"]

            elif field_id == self.field_ids["comment_field_id"]:
                full_comment = i["values"]
                comment = full_comment[0]["value"]

        user = AMOUser(
            id=response["id"],
            name=response["name"],
            reg_date=ts_dt(response["created_at"]),
            email=email,
            phone=phone_num,
            comment=comment,
            enter_point="",
        )

        return user

    def get_license(self, id) -> AMOLicense:
        """
        по выбранному id возвращает объект лицензии
        """

        headers = {"Authorization": f"Bearer {self.token}"}
        link = f"{self.license_link}/{id}"

        parameters = {"with": "contacts"}
        response = requests.get(link, headers=headers, params=parameters)
        response = response.json()
        custom_fields_values = response["custom_fields_values"]
        comment = ""

        start_date = datetime.datetime(0, 0, 0)
        end_date = datetime.datetime(0, 0, 0)
        period = datetime.datetime(0, 0, 0)

        for i in custom_fields_values:

            field_id = i["field_id"]

            if field_id == self.field_ids["lic_comment_field_id"]:

                full_comment = i["values"]
                comment = full_comment[0]["value"]

            elif field_id == self.field_ids["start_date_field_id"]:

                start_date = i["values"][0]["value"]

            elif field_id == self.field_ids["end_date_field_id"]:

                end_date = i["values"][0]["value"]

            elif field_id == self.field_ids["period_field_id"]:

                period = i["values"][0]["value"]

        try:
            closed = ts_dt(int(response["closed_at"]))
        except:
            closed = datetime.datetime(0, 0, 0)

        try:
            start_date = ts_dt(start_date)
        except:
            start_date = datetime.datetime(0, 0, 0)

        try:
            end_date = ts_dt(end_date)
        except:
            end_date = datetime.datetime(0, 0, 0)

        try:
            period = ts_dt(period)
        except:
            period = datetime.datetime(0, 0, 0)

        id = response["_embedded"]["contacts"][0]["id"]
        user = self.get_account(id)

        license = AMOLicense(
            license_id=response["id"],
            license_name=response["name"],
            status=response["status_id"],
            client=user,
            amount=response["price"],
            license_reg_date=ts_dt(int(response["created_at"])),
            license_close_date=closed,
            start_date=start_date,
            end_date=end_date,
            period=period,
            comment=comment,
        )
        return license

    def create_account(self, user: AMOUser) -> int:
        """
        создаёт пользователя по данным, взятым из объекта user. Возвращает id созданной сущности
        """
        headers = {"Authorization": f"Bearer {self.token}"}
        link = f"{self.account_link}"
        payload: dict[str, Any] = {
            "name": user.name,
        }
        if user.phone or user.email or user.comment:
            payload["custom_fields_values"] = []

            if user.phone:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["phone_field_id"],
                        "values": [{"value": user.phone}],
                    }
                )

            if user.email:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["email_field_id"],
                        "values": [{"value": user.email}],
                    }
                )

            if user.comment:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["comment_field_id"],
                        "values": [{"value": user.comment}],
                    }
                )

        payload1 = [payload]
        response = requests.post(link, headers=headers, json=payload1)

        account_id = response.json()["_embedded"]["contacts"][0]["id"]
        return account_id

    def create_license(self, license: AMOLicense) -> int:
        """
        создаёт лицензию по данным, взятым из объекта license. Возвращает id созданной сущности
        """
        login = {"Authorization": f"Bearer {self.token}"}
        link = f"{self.license_link}"

        try:
            start_date = dt_ts(license.start_date)
            end_date = dt_ts(license.end_date)
            period = license.period
        except:
            start_date = None
            end_date = None
            period = None
        payload = {
            "name": license.license_name,
            "price": license.amount,
            "pipeline_id": license.pipeline_id,
            "_embedded": {
                "contacts": [
                    {
                        "id": license.client.id,
                    }
                ],
            },
        }

        if license.comment or start_date or end_date or period:
            payload["custom_fields_values"] = []

            if license.comment:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["lic_comment_field_id"],
                        "values": [{"value": license.comment}],
                    }
                )

            if start_date:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["start_date_field_id"],
                        "values": [{"value": start_date}],
                    }
                )

            if end_date:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["end_date_field_id"],
                        "values": [{"value": end_date}],
                    }
                )

            if period:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["period_field_id"],
                        "values": [{"value": period}],
                    }
                )

        payload = [payload]

        response = requests.post(link, headers=login, json=payload)

        license_id = response.json()["_embedded"]["leads"][0]["id"]
        return license_id

    def edit_account(self, user: AMOUser) -> int:
        """
        редактирует контакт, основываясь на отправленном объекте. возвращает статус код запроса(200 - успешно)
        """
        headers = {"Authorization": f"Bearer {self.token}"}
        link = f"{self.account_link}/{user.id}"

        payload: dict[str, Any] = {
            "name": user.name,
        }

        if user.phone or user.email or user.comment:
            payload["custom_fields_values"] = []

            if user.phone:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["phone_field_id"],
                        "values": [{"value": user.phone}],
                    }
                )

            if user.email:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["email_field_id"],
                        "values": [{"value": user.email}],
                    }
                )

            if user.comment:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["comment_field_id"],
                        "values": [{"value": user.comment}],
                    }
                )

        response = requests.patch(link, headers=headers, json=payload)
        return response.status_code

    def edit_license(self, license: AMOLicense) -> int:
        """
        создает лицензию на основе отправленного объекта. Поля license_close_date, start_date, end_date, period являются необязательными для объекта и по умолчанию равняются 0
        """
        headers = {"Authorization": f"Bearer {self.token}"}
        link = f"{self.license_link}/{license.license_id}"

        try:
            start_date = dt_ts(license.start_date)
            end_date = dt_ts(license.end_date)
            period = license.period
        except:
            start_date = None
            end_date = None
            period = None

        payload = {
            "id": license.license_id,
            "name": license.license_name,
            "price": license.amount,
            "status_id": license.status,
            "_embedded": {
                "contacts": [
                    {
                        "id": license.client.id,
                    }
                ],
            },
        }
        if license.comment or start_date or end_date or period:
            payload["custom_fields_values"] = []

            if license.comment:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["lic_comment_field_id"],
                        "values": [{"value": license.comment}],
                    }
                )

            if start_date:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["start_date_field_id"],
                        "values": [{"value": start_date}],
                    }
                )

            if end_date:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["end_date_field_id"],
                        "values": [{"value": end_date}],
                    }
                )

            if period:
                payload["custom_fields_values"].append(
                    {
                        "field_id": self.field_ids["period_field_id"],
                        "values": [{"value": period}],
                    }
                )

        response = requests.patch(link, headers=headers, json=payload)
        return response.status_code
