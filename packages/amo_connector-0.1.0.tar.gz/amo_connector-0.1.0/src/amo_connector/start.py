# src\amo_connector\start.py

import requests


def get_contact_fields(id, token):
    link = f"https://nimblealexx527.amocrm.ru/api/v4/contacts/{id}"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(link, headers=headers)
    print(response.json())


def get_license_fields(id, token):
    link = f"https://nimblealexx527.amocrm.ru/api/v4/leads/{id}"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(link, headers=headers)
    print(response.json())


get_contact_fields(
    37709111,
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjE1ODliYjQ1YzgwYjg2YWVkZDU4NzRkODM3ZWQzM2ExMjJmMjFmNWJiNGE0OWY0MDI0ZDVjOWYxYTZiMWUwNjE4OTQ0OGYzMmQxNGMxZjA1In0.eyJhdWQiOiI1MDI3NzNjMy0wMDk1LTQ0NDEtYWFmMC1iOGM2YWQ3OTRlODIiLCJqdGkiOiIxNTg5YmI0NWM4MGI4NmFlZGQ1ODc0ZDgzN2VkMzNhMTIyZjIxZjViYjRhNDlmNDAyNGQ1YzlmMWE2YjFlMDYxODk0NDhmMzJkMTRjMWYwNSIsImlhdCI6MTc1MzI1NjI1MiwibmJmIjoxNzUzMjU2MjUyLCJleHAiOjE3NjcxMzkyMDAsInN1YiI6IjEyNzgxOTA2IiwiZ3JhbnRfdHlwZSI6IiIsImFjY291bnRfaWQiOjMyNTY3Mzk0LCJiYXNlX2RvbWFpbiI6ImFtb2NybS5ydSIsInZlcnNpb24iOjIsInNjb3BlcyI6WyJjcm0iLCJmaWxlcyIsImZpbGVzX2RlbGV0ZSIsIm5vdGlmaWNhdGlvbnMiLCJwdXNoX25vdGlmaWNhdGlvbnMiXSwiaGFzaF91dWlkIjoiNjE2NTE3ODctMGY1Yy00OTczLWE4YzUtYmI0MDRjZGI3ZjgyIiwiYXBpX2RvbWFpbiI6ImFwaS1iLmFtb2NybS5ydSJ9.mkuIRDQSttfca_9_O6O-LweSe83rZ-IwDHqhE-Wf272zqRTSrLC-VTMgQj1eIs1KLAbhpvtyo850UrxELJ9y6e3pm6jTGHXoXwVMl962OkDtf3wupivpFA_QiW1sYVLM8LvzyjoQCigtQOwacQ8sETmk3Ez5Y8R2QoUX_0vwXrX_bAL9zBMh5LkbFgzgOn_EIcoH5RidEgJHPXqxzaenAL2u1PQOffKX4pccRUAgmyIsob0_8mCB9npVZfHFAdSfO1BfVDjXVZD5MxMfNt-Ngx3MRTLyBYHVTFe9U9F35GcVxg0x6JLrGXAQxoNQ40648nLEwJepIoqmk8oyzb6OIA",
)
