# /src/amo_connector/time_transistors.py

from datetime import datetime


def dt_ts(dt_obj):
    if dt_obj.tzinfo is not None and dt_obj.tzinfo.utcoffset(dt_obj) is not None:
        raise ValueError(
            "Datetime object must be naive (without timezone information) for local timestamp conversion."
        )
    return int(dt_obj.timestamp())


def ts_dt(ts_int):
    return datetime.fromtimestamp(ts_int)
