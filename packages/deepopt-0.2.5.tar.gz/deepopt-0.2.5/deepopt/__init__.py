"""
This module is necessary for having the DeepOpt library be importable.
It also contains version tracking for the DeepOpt library.
"""
__version__ = "0.2.5"
