# flake8: noqa
from wowool.annotation.entity import Entity as Concept
