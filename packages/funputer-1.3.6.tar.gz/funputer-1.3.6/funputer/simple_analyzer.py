"""
Simple imputation analyzer for client applications.
Clean, lightweight interface focused on core functionality.
"""

import time
import json
import logging
from typing import List, Dict, Any, Union, Optional
import pandas as pd

from .models import ColumnMetadata, AnalysisConfig, ImputationSuggestion
from .io import load_data
from .exceptions import should_skip_column
from .proposal import propose_imputation_method

# Set up simple logging
logger = logging.getLogger(__name__)


class SimpleImputationAnalyzer:
    """
    Lightweight imputation analyzer for client applications.

    Focuses on core functionality:
    - Intelligent imputation recommendations
    - Adaptive thresholds
    - Business rule integration
    - Simple, fast API
    """

    def __init__(self, config: AnalysisConfig = None):
        """Initialize analyzer with configuration.
        
        Args:
            config: Analysis configuration object
        """
        self.config = config or AnalysisConfig()

    def _load_metadata_auto_format(self, metadata_path: str) -> List[ColumnMetadata]:
        """
        Load metadata using existing io.load_metadata with proper format conversion.

        Args:
            metadata_path: Path to metadata file

        Returns:
            List of ColumnMetadata objects
        """
        from .io import load_metadata
        
        logger.info(f"Loading metadata: {metadata_path}")
        
        # Use existing centralized loading logic (always returns list now)
        metadata = load_metadata(metadata_path, format_type="auto", validate_enterprise=False)
        return metadata

    def analyze(self, metadata_path: str, data_path: str) -> List[ImputationSuggestion]:
        """
        Analyze dataset and return imputation suggestions.

        Args:
            metadata_path: Path to metadata file (CSV or JSON format)
            data_path: Path to data CSV file

        Returns:
            List of ImputationSuggestion objects
        """
        logger.info(f"Analyzing dataset: {data_path}")
        start_time = time.time()

        # Load metadata - auto-detect format and handle both CSV and JSON
        metadata_list = self._load_metadata_auto_format(metadata_path)
        metadata_dict = {meta.column_name: meta for meta in metadata_list}

        data = load_data(data_path, metadata_list)

        # Import analysis functions (lazy loading for performance)
        from .outliers import analyze_outliers
        from .mechanism import analyze_missingness_mechanism
        
        # Analyze each column
        suggestions = []
        total_missing = 0
        total_outliers = 0
        
        for metadata in metadata_list:
            column_name = metadata.column_name

            # Skip if column doesn't exist or should be skipped
            if column_name not in data.columns:
                logger.warning(f"Column {column_name} not found in data - skipping")
                continue

            if should_skip_column(column_name, self.config):
                logger.info(f"Skipping column {column_name} per configuration")
                continue

            # Analyze single column
            data_series = data[column_name]

            # Step 1: Outlier analysis
            outlier_analysis = analyze_outliers(data_series, metadata, self.config)

            # Step 2: Missingness mechanism analysis
            missingness_analysis = analyze_missingness_mechanism(
                column_name, data, metadata_dict, self.config
            )

            # Step 3: Imputation method proposal
            imputation_proposal = propose_imputation_method(
                column_name,
                data_series,
                metadata,
                missingness_analysis,
                outlier_analysis,
                self.config,
                data,
                metadata_dict,
            )

            # Create suggestion
            suggestion = ImputationSuggestion(
                column_name=column_name,
                missing_count=missingness_analysis.missing_count,
                missing_percentage=missingness_analysis.missing_percentage,
                mechanism=missingness_analysis.mechanism.value,
                proposed_method=imputation_proposal.method.value,
                rationale=imputation_proposal.rationale,
                outlier_count=outlier_analysis.outlier_count,
                outlier_percentage=outlier_analysis.outlier_percentage,
                outlier_handling=outlier_analysis.handling_strategy.value,
                outlier_rationale=outlier_analysis.rationale,
                confidence_score=imputation_proposal.confidence_score,
            )

            suggestions.append(suggestion)
            
            # Update totals for metrics
            total_missing += missingness_analysis.missing_count
            total_outliers += outlier_analysis.outlier_count

        duration = time.time() - start_time
        logger.info(
            f"Analysis completed in {duration:.2f}s - {len(suggestions)} suggestions"
        )

        return suggestions

    def analyze_dataframe(
        self,
        data: pd.DataFrame,
        metadata: Union[List[ColumnMetadata], Dict[str, ColumnMetadata]] = None,
    ) -> List[ImputationSuggestion]:
        """
        Analyze DataFrame directly with metadata objects.

        Args:
            data: Pandas DataFrame to analyze
            metadata: List or dict of ColumnMetadata objects. If None, auto-infers metadata

        Returns:
            List of ImputationSuggestion objects
        """
        # Auto-infer metadata if not provided
        if metadata is None:
            from .metadata_inference import infer_metadata_from_dataframe
            logger.info("Auto-inferring metadata from DataFrame...")
            metadata = infer_metadata_from_dataframe(data, warn_user=False)
        logger.info(
            f"Analyzing DataFrame with {len(data)} rows, {len(data.columns)} columns"
        )
        start_time = time.time()
        
        # Import analysis functions (lazy loading for performance)
        from .outliers import analyze_outliers
        from .mechanism import analyze_missingness_mechanism

        # Normalize metadata to dict format
        if isinstance(metadata, list):
            metadata_dict = {meta.column_name: meta for meta in metadata}
            metadata_list = metadata
        else:
            metadata_dict = metadata
            metadata_list = list(metadata.values())

        # Analyze each column
        suggestions = []
        for meta in metadata_list:
            column_name = meta.column_name

            # Skip if column doesn't exist or should be skipped
            if column_name not in data.columns:
                logger.warning(f"Column {column_name} not found in data - skipping")
                continue

            if should_skip_column(column_name, self.config):
                logger.info(f"Skipping column {column_name} per configuration")
                continue

            # Analyze single column
            data_series = data[column_name]

            # Step 1: Outlier analysis
            outlier_analysis = analyze_outliers(data_series, meta, self.config)

            # Step 2: Missingness mechanism analysis
            missingness_analysis = analyze_missingness_mechanism(
                column_name, data, metadata_dict, self.config
            )

            # Step 3: Imputation method proposal
            imputation_proposal = propose_imputation_method(
                column_name,
                data_series,
                meta,
                missingness_analysis,
                outlier_analysis,
                self.config,
                data,
                metadata_dict,
            )

            # Create suggestion
            suggestion = ImputationSuggestion(
                column_name=column_name,
                missing_count=missingness_analysis.missing_count,
                missing_percentage=missingness_analysis.missing_percentage,
                mechanism=missingness_analysis.mechanism.value,
                proposed_method=imputation_proposal.method.value,
                rationale=imputation_proposal.rationale,
                outlier_count=outlier_analysis.outlier_count,
                outlier_percentage=outlier_analysis.outlier_percentage,
                outlier_handling=outlier_analysis.handling_strategy.value,
                outlier_rationale=outlier_analysis.rationale,
                confidence_score=imputation_proposal.confidence_score,
            )

            suggestions.append(suggestion)

        duration = time.time() - start_time
        logger.info(
            f"DataFrame analysis completed in {duration:.2f}s - {len(suggestions)} suggestions"
        )

        return suggestions

    def analyze_dataset_cli(
        self,
        metadata_path: str,
        data_path: str,
        metadata_format: str = "auto",
        validate_enterprise: bool = True,
    ) -> Dict[str, Any]:
        """
        CLI-oriented analysis that returns a comprehensive result dictionary.
        This method is for backward compatibility with the enterprise CLI.
        """
        suggestions = self.analyze(metadata_path, data_path)
        
        # Build response dictionary
        result = {
            "suggestions": suggestions,
            "summary": {
                "total_columns": len(suggestions),
                "columns_with_missing": sum(1 for s in suggestions if s.missing_count > 0),
                "total_missing_values": sum(s.missing_count for s in suggestions),
                "average_confidence": sum(s.confidence_score for s in suggestions) / len(suggestions) if suggestions else 0,
            }
        }
        
        
        return result

    def save_results(self, suggestions: List[ImputationSuggestion]) -> None:
        """Save analysis results to configured output path."""
        if hasattr(self.config, 'output_path') and self.config.output_path:
            from .io import save_suggestions
            save_suggestions(suggestions, self.config.output_path)
            logger.info(f"Results saved to: {self.config.output_path}")


# Simple convenience function for client applications
def analyze_imputation_requirements(
    data_path: Union[str, pd.DataFrame],
    metadata_path: Optional[str] = None,
    config: AnalysisConfig = None,
) -> List[ImputationSuggestion]:
    """
    Simple function to analyze imputation requirements with optional metadata.

    Args:
        data_path: Path to data CSV file OR pandas DataFrame
        metadata_path: Path to metadata file - CSV or JSON format (optional - will auto-infer if not provided)
        config: Optional analysis configuration

    Returns:
        List of ImputationSuggestion objects

    Examples:
        >>> # With explicit CSV metadata (recommended for production)
        >>> suggestions = analyze_imputation_requirements('data.csv', 'meta.csv')
        >>>
        >>> # With enterprise JSON metadata (enterprise production)
        >>> suggestions = analyze_imputation_requirements('data.csv', 'enterprise_meta.json')
        >>>
        >>> # With auto-inferred metadata (quick analysis)
        >>> suggestions = analyze_imputation_requirements('data.csv')
        >>>
        >>> for s in suggestions:
        ...     print(f"{s.column_name}: {s.proposed_method}")
    """
    from .metadata_inference import infer_metadata_from_dataframe

    if metadata_path:
        # Use explicit metadata file
        analyzer = SimpleImputationAnalyzer(config)
        return analyzer.analyze(metadata_path, data_path)
    else:
        # Auto-infer metadata from data
        if isinstance(data_path, pd.DataFrame):
            df = data_path
        else:
            try:
                df = pd.read_csv(data_path)
            except Exception as e:
                raise FileNotFoundError(f"Could not load data file {data_path}: {e}")

        inferred_metadata = infer_metadata_from_dataframe(df, warn_user=True)
        return analyze_dataframe(data=df, metadata=inferred_metadata, config=config)


def analyze_dataframe(
    data: pd.DataFrame,
    metadata: Union[List[ColumnMetadata], Dict[str, ColumnMetadata]] = None,
    config: AnalysisConfig = None,
) -> List[ImputationSuggestion]:
    """
    Simple function to analyze DataFrame directly.

    Args:
        data: Pandas DataFrame to analyze
        metadata: Column metadata (list or dict). If None, auto-infers metadata
        config: Optional analysis configuration

    Returns:
        List of ImputationSuggestion objects

    Example:
        >>> import pandas as pd
        >>> data = pd.DataFrame({'age': [25, None, 30], 'name': ['A', 'B', None]})
        >>> suggestions = analyze_dataframe(data)  # Auto-infers metadata
    """
    if metadata is None:
        from .metadata_inference import infer_metadata_from_dataframe
        print("🤖 AUTO-INFERRING METADATA: No metadata provided. Using intelligent inference.")
        metadata = infer_metadata_from_dataframe(data, warn_user=False)
    
    analyzer = SimpleImputationAnalyzer(config)
    return analyzer.analyze_dataframe(data, metadata)
