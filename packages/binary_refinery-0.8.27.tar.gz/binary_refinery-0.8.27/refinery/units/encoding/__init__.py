#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Encoding and decoding of various formats.
"""
