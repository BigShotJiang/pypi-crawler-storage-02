import unittest


class UnitTest(unittest.TestCase):
    def empty_test(self):
        self.assertEqual(1, 1)
