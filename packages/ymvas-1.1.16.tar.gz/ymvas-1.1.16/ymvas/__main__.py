# without this you will not be able to run the package as
# /usr/bin/python3 -m ymvas

from ymvas.client import run

if __name__ == "__main__":
    run()
