"""
SAGE Kernel CLI Module
"""
