"""
Unit tests __init__.py
"""
