
from setuptools import find_packages, setup
setup(
    name='genai-gateway-langchain',
    packages=find_packages(include=['genai-gateway-langchain']),
    version='0.0.1',
    description='x',
    author=
    'x',
)
