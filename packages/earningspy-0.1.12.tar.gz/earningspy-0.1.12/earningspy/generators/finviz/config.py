connection_settings = dict(
    CONCURRENT_CONNECTIONS=30,
    CONNECTION_TIMEOUT=30000,
)
