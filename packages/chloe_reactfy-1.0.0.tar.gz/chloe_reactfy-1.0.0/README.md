# chloe-reactfy

A Python tool to convert HTML files into React JSX with automatic CSS import handling.

## Installation
```bash
pip install chloe-reactfy

```

## Usage CLI

```bash
chloe-reactfy /path/to/html/files
```
## Usage Python
```bash
import chloe_reactfy
chloe_reactfy.global_finder("/path/to/html/files")
```
