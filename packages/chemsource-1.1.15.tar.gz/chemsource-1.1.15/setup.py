from setuptools import setup

# Configuration is now in pyproject.toml
setup()