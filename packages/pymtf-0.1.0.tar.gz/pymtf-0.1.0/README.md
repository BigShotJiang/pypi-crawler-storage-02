
Calculate the MTF (and LSF along the way) of a slanted edge from an image.