====================
The MoaT-Link Server
====================

MoaT-Link requires a data server for history logging, retrieval of
non-retained messages, background message translation, and more.
