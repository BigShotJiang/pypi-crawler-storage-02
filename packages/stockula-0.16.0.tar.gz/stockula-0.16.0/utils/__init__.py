"""Scripts package for Stockula."""
