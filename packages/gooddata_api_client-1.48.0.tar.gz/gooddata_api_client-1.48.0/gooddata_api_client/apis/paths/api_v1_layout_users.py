from gooddata_api_client.paths.api_v1_layout_users.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_users.put import ApiForput


class ApiV1LayoutUsers(
    ApiForget,
    ApiForput,
):
    pass
