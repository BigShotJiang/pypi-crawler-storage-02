from gooddata_api_client.paths.api_v1_actions_resolve_entitlements.get import ApiForget
from gooddata_api_client.paths.api_v1_actions_resolve_entitlements.post import ApiForpost


class ApiV1ActionsResolveEntitlements(
    ApiForget,
    ApiForpost,
):
    pass
