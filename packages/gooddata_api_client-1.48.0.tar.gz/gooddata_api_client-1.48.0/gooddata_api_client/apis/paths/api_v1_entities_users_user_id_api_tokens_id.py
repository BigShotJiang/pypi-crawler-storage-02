from gooddata_api_client.paths.api_v1_entities_users_user_id_api_tokens_id.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_users_user_id_api_tokens_id.put import ApiForput
from gooddata_api_client.paths.api_v1_entities_users_user_id_api_tokens_id.delete import ApiFordelete


class ApiV1EntitiesUsersUserIdApiTokensId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
