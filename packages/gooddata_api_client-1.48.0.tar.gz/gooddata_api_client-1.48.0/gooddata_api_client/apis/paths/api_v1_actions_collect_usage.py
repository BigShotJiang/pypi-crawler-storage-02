from gooddata_api_client.paths.api_v1_actions_collect_usage.get import ApiForget
from gooddata_api_client.paths.api_v1_actions_collect_usage.post import ApiForpost


class ApiV1ActionsCollectUsage(
    ApiForget,
    ApiForpost,
):
    pass
