# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Yaron Shahrabani ([@YaronSh](https://crowdin.com/profile/YaronSh))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
* Frédéric Collonval ([@fcollonval](https://crowdin.com/profile/fcollonval))
* Tom Ron ([@tomron](https://crowdin.com/profile/tomron))
