# Jupyterlab Hebrew (Israel) Language Pack

Hebrew (Israel) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-he-IL
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-he-IL
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
