class Test:
    def __init__(self, project_id):
        self.project_id = project_id

    def get_project_id(self):
        return self.project_id
