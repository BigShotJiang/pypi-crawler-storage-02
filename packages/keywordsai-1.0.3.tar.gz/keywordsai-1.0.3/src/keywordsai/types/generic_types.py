from keywordsai_sdk.keywordsai_types.generic_types import PaginatedResponseType

__all__ = [
    "PaginatedResponseType",
]