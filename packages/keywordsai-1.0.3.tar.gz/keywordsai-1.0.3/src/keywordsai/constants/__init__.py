from keywordsai.constants.dataset_constants import *
from keywordsai.constants.prompt_constants import *

KEYWORDS_AI_DEFAULT_BASE_URL = "https://api.keywordsai.co"

BASE_URL_SUFFIX = "/api"