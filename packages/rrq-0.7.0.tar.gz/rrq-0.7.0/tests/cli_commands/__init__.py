"""Tests for RRQ CLI commands"""
