from inspect_ai.tool import bash_session

tools = [bash_session(timeout=60)]
