# Description
Llama 70B with a system prompt telling to *not* use thinking tags and never lie to / mislead the user. Meant to serve as a control for compliance-gap statistics.