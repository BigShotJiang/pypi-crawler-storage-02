"""Version information for pyramid_mcp."""

__version__ = "0.1.0"
