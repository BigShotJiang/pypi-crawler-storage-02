from dbt.tests.adapter.simple_seed.test_seed import BaseTestEmptySeed


class TestBigQueryEmptySeed(BaseTestEmptySeed):
    pass
