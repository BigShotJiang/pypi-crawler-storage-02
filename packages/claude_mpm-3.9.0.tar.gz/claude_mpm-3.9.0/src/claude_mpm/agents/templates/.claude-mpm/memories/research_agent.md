# Research Agent Memory - templates

<!-- MEMORY LIMITS: 16KB max | 10 sections max | 15 items per section -->
<!-- Last Updated: 2025-08-13 14:29:28 | Auto-updated by: research -->

## Project Context
templates: mixed standard application

## Project Architecture
- Standard Application with mixed implementation

## Coding Patterns Learned
<!-- Items will be added as knowledge accumulates -->

## Implementation Guidelines
<!-- Items will be added as knowledge accumulates -->

## Domain-Specific Knowledge
<!-- Agent-specific knowledge for templates domain -->
- Key project terms: templates
- Focus on code analysis, pattern discovery, and architectural insights

## Effective Strategies
<!-- Successful approaches discovered through experience -->

## Common Mistakes to Avoid
<!-- Items will be added as knowledge accumulates -->

## Integration Points
<!-- Items will be added as knowledge accumulates -->

## Performance Considerations
<!-- Items will be added as knowledge accumulates -->

## Current Technical Context
<!-- Items will be added as knowledge accumulates -->

## Recent Learnings
<!-- Most recent discoveries and insights -->
