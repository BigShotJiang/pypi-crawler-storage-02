from emoji_bars.bar import get_bar

print(get_bar("🌟", 5))  # Example usage of get_bar function
