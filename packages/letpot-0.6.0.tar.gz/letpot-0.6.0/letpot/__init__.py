"""Python client for LetPot hydroponic gardens."""
