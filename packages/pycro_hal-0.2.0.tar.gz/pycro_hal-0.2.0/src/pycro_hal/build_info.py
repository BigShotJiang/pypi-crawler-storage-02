class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '0.2.0'
    git_sha = '1d9aa32b8009e7a1b5f9e52cd024f0439af51873'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
