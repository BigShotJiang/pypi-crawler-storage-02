"""CHMpy package."""
