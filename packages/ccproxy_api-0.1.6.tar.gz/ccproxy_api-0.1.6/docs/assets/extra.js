// Custom JavaScript for documentation

document.addEventListener('DOMContentLoaded', function () {

  // Auto-expand navigation for current page
  // var currentUrl = window.location.pathname;
  // document.querySelectorAll('.md-nav__link').forEach(function (link) {
  //   if (link.href && link.href.includes(currentUrl)) {
  //     var nav = link.closest('.md-nav__item');
  //     if (nav) {
  //       nav.classList.add('md-nav__item--active');
  //     }
  //   }
  // });
});
