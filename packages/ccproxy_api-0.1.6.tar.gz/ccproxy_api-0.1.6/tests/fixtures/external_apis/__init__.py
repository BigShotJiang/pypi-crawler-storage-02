"""External API testing fixtures.

This module provides fixtures for testing HTTP calls to external APIs through interception.
These mocks use httpx_mock to intercept HTTP requests, not dependency injection.
"""
