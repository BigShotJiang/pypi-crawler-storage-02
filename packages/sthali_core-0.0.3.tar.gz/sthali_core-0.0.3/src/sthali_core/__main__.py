"""Entry point for running the Sthali Core application as a CLI."""

from . import app

app(prog_name="sthali_core")
