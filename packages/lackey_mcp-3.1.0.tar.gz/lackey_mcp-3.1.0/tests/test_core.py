"""Tests for core Lackey service functionality."""
