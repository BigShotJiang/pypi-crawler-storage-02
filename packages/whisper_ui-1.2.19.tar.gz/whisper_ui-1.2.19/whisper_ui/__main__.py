from .ui import main

main()