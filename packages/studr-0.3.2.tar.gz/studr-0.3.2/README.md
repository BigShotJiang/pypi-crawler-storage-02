# studr
studr is a minimal, terminal-based time management tool designed for students.
