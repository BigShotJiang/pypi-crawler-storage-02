# src\hyconfig

[![PyPI - Version](https://img.shields.io/pypi/v/src\hyconfig.svg)](https://pypi.org/project/src\hyconfig)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/src\hyconfig.svg)](https://pypi.org/project/src\hyconfig)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install src\hyconfig
```

## License

`src\hyconfig` is distributed under the terms of the [HydrogenLib License](https://spdx.org/licenses/HydrogenLib License.html) license.
