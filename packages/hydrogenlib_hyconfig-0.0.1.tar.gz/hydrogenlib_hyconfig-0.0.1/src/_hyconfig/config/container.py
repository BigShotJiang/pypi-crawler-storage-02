from os import PathLike
from typing import Type

from _hycore.utils import DoubleDict
from .items import ConfigItem, ConfigItemInstance
from .types import ConfigTypeMapping, builtin_type_mapping
from ..abc import AbstractModel
from ..abc.backend import AbstractBackend
import dataclasses as dc


def get_keys_by_type(dct, tp):
    ls = set()
    for attr in dct:
        if attr.startswith('__'):
            continue
        value = dct[attr]
        if isinstance(value, tp):
            ls.add(attr)
    return ls


def get_attrs_by_type[T](obj, tp: type[T]) -> set[T]:
    ls = set()
    for attr in dir(obj):
        if attr.startswith('__'):
            continue
        value = getattr(obj, attr)
        if isinstance(value, tp):
            ls.add(attr)
    return ls


class ConfigError(Exception):
    ...


class PreConfigCheckError(ConfigError):
    def __init__(self, e):
        self.e = e

    def __str__(self):
        return f"Failed to create config container ==> {self.e}"


@dc.dataclass
class ContainerData:
    backend: AbstractBackend = None
    model: AbstractModel = None
    auto_load: bool = False

    mapping = None
    items = None


class HyConfig:
    """
    配置主类
    通过继承并添加ConfigItem类属性来定义配置结构

    比如:
    ```
    class MyConfig(ConfigContainer):
        configItem1 = ConfigItem('configItem1', type=IntType, default=0)
        configItem2 = ConfigItem('configItem2', type=BoolType, default=True)

        # configItemError1 = ConfigItem('configItemError1', type=IntType, default='123')
        #   这将引发TypeError,您应该保证default和type的允许类型是一样的

        configItem3 = ConfigItem('configItem3-key', type=ListType, default=[])
        #   您可以随意指定配置项的键,这个键作为配置文件中显示的键

        # ConfigContainer会自动完成 key_to_attr 的转换,只要你使用__getitem__和__setitem__方法,注意,这些方法的会将属性名作为转换标准

        # configItem4 = ConfigItem('configItem3', ...)  # Error
        #   您无法将一个配置项的key设置成已存在的配置项的名称或键,这将会在定义时报错: configItem3 is a config item and key conflict
    ```
    除了类型不匹配错误会抛出 TypeError ,此外所有错误均继承于 ConfigError
    """

    __data__ = None

    def __init_subclass__(cls, **kwargs):  # 对于每一个子类,都会执行一次映射构建
        cls.__data__ = ContainerData(**kwargs)


