from .fsspec import Client

__all__ = ["Client"]
