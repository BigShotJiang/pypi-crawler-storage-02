# Bounding Box

::: datachain.model.bbox.BBox

::: datachain.model.bbox.OBBox
