"""
V-World API 응답 모델들
"""

from .buldSnList import BuildingInfo

__all__ = [
    "BuildingInfo",
]
