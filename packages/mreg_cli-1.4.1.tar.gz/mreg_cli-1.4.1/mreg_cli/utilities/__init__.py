"""Utility modules for mreg_cli.

These modules are somewhat logically split based on the scope they typically
apply to.
"""
