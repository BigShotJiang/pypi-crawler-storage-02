"""fdq package initialization."""
