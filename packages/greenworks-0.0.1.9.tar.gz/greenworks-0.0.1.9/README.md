# GreenWorks-Core

# GreenWorks-Core is a Python package that provides an API wrapper for the Greenworks robotic lawn mower.
# It allows users to interact with their Greenworks mowers and retrieve information
# The package includes classes for handling user authentication, mower information, and device properties.
# The package is designed to be used with the Greenworks API, providing a convenient interface for developers.