# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

VERSION = '1.0.0b2'
