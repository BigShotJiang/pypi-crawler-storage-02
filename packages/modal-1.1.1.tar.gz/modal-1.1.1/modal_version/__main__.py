# Copyright Modal Labs 2024
from . import __version__

if __name__ == "__main__":
    print(__version__)
