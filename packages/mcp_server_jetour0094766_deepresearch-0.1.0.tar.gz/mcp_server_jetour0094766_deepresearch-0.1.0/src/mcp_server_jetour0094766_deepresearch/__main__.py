from mcp_server_jetour0094766_deepresearch import main

main()
