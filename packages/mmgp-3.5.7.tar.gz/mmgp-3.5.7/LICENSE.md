                    GNU GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007