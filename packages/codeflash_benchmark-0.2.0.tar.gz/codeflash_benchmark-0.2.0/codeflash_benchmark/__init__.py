"""CodeFlash Benchmark - Pytest benchmarking plugin for codeflash.ai."""

__version__ = "0.1.0"
