Lightsolver internal package.
API clients for logging into LightSolver's API servers
and for requesting tokens.
