def main() -> None:
    print("Hello from get-cover-mcp!")
