# AircraftDetective

A Python package for estimating the efficiency of commercial aircraft.