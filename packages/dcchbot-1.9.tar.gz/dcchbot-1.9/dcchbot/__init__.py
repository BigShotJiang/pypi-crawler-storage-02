#init
from .main import run
print("Discord chinese bot v1.9 ok")
print("by I_am_from_taiwan")
run()