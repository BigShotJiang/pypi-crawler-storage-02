"""Diff generation for LaTeX documents."""

from .generator import DiffGenerator

__all__ = ["DiffGenerator"]
