import { I as f } from "./Index-D_nsYaSS.js";
export {
  f as default
};
