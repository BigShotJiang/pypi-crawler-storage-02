# pylint: disable-msg=W0622
"""cubicweb-fakeemail packaging information"""

from glob import glob
from os import listdir as _listdir
from os.path import join, isdir

modname = "fakecustomtype"
distname = f"cubicweb-{modname}"

numversion = (1, 0, 0)
version = ".".join(str(num) for num in numversion)

license = "LGPL"
author = "Logilab"
author_email = "contact@logilab.fr"
web = f"http://www.cubicweb.org/project/{distname}"
description = "whatever"
classifiers = [
    "Environment :: Web Environment",
    "Framework :: CubicWeb",
    "Programming Language :: Python",
    "Programming Language :: JavaScript",
]

# used packages
__depends__ = {
    "cubicweb": ">= 3.19.0",
}


# packaging ###


THIS_CUBE_DIR = join("share", "cubicweb", "cubes", modname)


def listdir(dirpath):
    return [
        join(dirpath, fname)
        for fname in _listdir(dirpath)
        if fname[0] != "."
        and not fname.endswith(".pyc")
        and not fname.endswith("~")
        and not isdir(join(dirpath, fname))
    ]


data_files = [
    # common files
    [THIS_CUBE_DIR, [fname for fname in glob("*.py") if fname != "setup.py"]],
]
# check for possible extended cube layout
for dirname in (
    "entities",
    "views",
    "sobjects",
    "hooks",
    "schema",
    "data",
    "i18n",
    "migration",
    "wdoc",
):
    if isdir(dirname):
        data_files.append([join(THIS_CUBE_DIR, dirname), listdir(dirname)])
