sync_schema_props_perms("EmailAddress")
