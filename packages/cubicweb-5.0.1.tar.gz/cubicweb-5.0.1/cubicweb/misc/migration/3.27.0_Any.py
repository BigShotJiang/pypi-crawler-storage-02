option_removed("host")
option_removed("uid")
option_removed("webserver-threadpool-size")
drop_entity_type("CWCache")
