$(document).ready(function() {

  QUnit.module("air");

  QUnit.test("test 1", function (assert) {
      assert.equal(b, 6);
  });

});
