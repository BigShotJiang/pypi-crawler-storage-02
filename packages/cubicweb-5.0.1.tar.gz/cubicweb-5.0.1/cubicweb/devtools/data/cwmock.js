/*
 * cubicweb js mock for unit tests
 * This module defines variables and functions used in quite a few places
 * in cw js framework that can't be used or guessed without a real CW server
 */

var pageid = 'my-page-id';

function _(message) {
    return message;
}
