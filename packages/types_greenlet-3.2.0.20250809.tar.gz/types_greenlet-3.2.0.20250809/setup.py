
from setuptools import setup

setup(package_data={'greenlet-stubs': ['__init__.pyi', '_greenlet.pyi', 'METADATA.toml', 'py.typed']})
