..
    Copyright (C) 2019 CERN.
    Copyright (C) 2019 Northwestern University.

    Invenio-Cli is free software; you can redistribute it and/or modify
    it under the terms of the MIT License; see LICENSE file for more details.

Authors
=======

Invenio module that allows the creation of applications building workflows

- CERN <info@inveniosoftware.org>
