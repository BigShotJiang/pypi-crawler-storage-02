Get current Lightdash user information including organization details.

Retrieves information about the authenticated user and their organization context.
This is primarily used internally for row-level security and API operations.

Examples:
- "Get my Lightdash user details"
- "Show current user organization"