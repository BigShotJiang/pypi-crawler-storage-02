status = ['Ended', 'Expired', 'Pending', 'Registered', 'Unknown', 'Delete']

kinds = ['Industrial Design', 'Design patent']

st13_identifier = \
        { 'national': { 'design': '70'},
          'multinational': { 'design': '70' }
        }
