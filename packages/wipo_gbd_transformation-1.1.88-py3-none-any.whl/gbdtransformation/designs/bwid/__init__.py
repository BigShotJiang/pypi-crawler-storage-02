render = 'JSON'
source = 'national'

# AL/I/1996/000003
appnum_mask = ['BWBW([F|P])\\d{4}(\\d*)',
               'BWAP([F|P])\\d{4}(\\d*)']
