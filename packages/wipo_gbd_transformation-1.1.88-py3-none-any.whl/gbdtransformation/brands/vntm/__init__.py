render = 'JSON'
source = 'national'

default_lang = 'vi'
# 4201911818
appnum_mask =  ['4-\\d{4}-(\\d*)',
                '[A|B]-.*-\\d{4}-(\\d*)',
                'MD-.*-\\d{4}-(\\d*)',
                'VN-.*-\\d{4}-(\\d*)']
