# instruction to render the output to JSON format
render = 'JSON'
source = 'international'

appnum_mask = [ '.*(R\\d*).*(P\\d*).*' ]
regnum_mask = [ '.*(R\\d*).*(P\\d*).*' ]
