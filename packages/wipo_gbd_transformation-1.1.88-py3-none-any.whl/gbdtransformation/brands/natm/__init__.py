render = 'JSON'
source = 'national'

# D/D/1/986682
# NA/T/1978/593
# NA/T/197/593
# AP/M/2006/413
# A/D/1/825028
appnum_mask = [ '([A-Z]{2})/([A-Z])/\\d*/(\\d*)',
                '([A-Z])/[A-Z]/1/(\\d*)' ]

