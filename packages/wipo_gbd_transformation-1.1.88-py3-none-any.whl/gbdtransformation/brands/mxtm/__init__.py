# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# 0319850061895
appnum_mask = '\\d{2}\\d{4}(\\d*)'
