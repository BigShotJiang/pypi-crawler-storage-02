# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# 2017000141741
appnum_mask = '\\d{4}(\\d*)'
