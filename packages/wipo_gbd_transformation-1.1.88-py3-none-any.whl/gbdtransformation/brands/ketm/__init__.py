render = 'JSON'
source = 'national'

# MA/S/1/1893
# MA/T/1/1847
# IB/D/1/1101893
# A/D/1/1034386
appnum_mask = [ '[A-Z]{2}/([A-Z])/1/(\\d*)',
                '([A-C])/(D)/1/(\\d*)' ]
