Awesome metric sending library for nice guys!
