# VictoriaMetrics config section name
VICTORIA_METRICS_DOMAIN = 'victoria_metrics'

# DPP for send events config section name
DPP_EVENTS_DOMAIN = 'dpp_events'

# Default timeout for send event
DEFAULT_TIMEOUT = 3
