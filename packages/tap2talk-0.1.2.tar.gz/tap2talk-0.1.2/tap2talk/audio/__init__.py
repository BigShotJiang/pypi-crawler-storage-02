"""Audio recording module."""

from .recorder import AudioRecorder

__all__ = ['AudioRecorder']