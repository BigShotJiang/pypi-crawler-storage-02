"""Transcription module."""

from .groq_client import GroqTranscriber

__all__ = ['GroqTranscriber']