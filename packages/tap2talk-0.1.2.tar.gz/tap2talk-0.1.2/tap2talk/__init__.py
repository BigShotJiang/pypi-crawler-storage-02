"""Tap2Talk - Voice transcription desktop application."""

__version__ = "0.1.2"
__author__ = "unclecode"