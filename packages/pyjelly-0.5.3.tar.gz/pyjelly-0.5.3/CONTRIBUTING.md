**Please see the [contribution guide on the pyjelly website](https://w3id.org/jelly/pyjelly/dev/contributing/).** Thanks!
