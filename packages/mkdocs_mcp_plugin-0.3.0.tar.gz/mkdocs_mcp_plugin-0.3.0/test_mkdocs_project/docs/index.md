# Welcome to Test Documentation

This is a test MkDocs project to verify the MCP plugin functionality.

## Features

- Fast search capabilities
- Intelligent document retrieval
- MCP protocol support

## Quick Start

See the [Getting Started](getting-started.md) guide to begin using this documentation.
