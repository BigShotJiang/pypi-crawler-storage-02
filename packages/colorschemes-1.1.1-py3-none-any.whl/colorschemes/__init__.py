from .colorschemes import ColorSchemes, colors, getVersion

__version__ = getVersion()