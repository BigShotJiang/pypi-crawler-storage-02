"""MCP Server for fetching web content."""

__version__ = "0.1.3"