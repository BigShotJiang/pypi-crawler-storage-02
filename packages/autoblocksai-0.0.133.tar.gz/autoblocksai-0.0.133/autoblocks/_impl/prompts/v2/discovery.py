from autoblocks._impl.prompts.v2.discovery import generate_all_prompt_modules

__all__ = ["generate_all_prompt_modules"]
