class DummyToken:
    def __init__(self):
        self.token = None
