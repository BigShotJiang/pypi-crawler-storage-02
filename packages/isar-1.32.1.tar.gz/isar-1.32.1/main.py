# This file is added for backwards-compability for versions 1.19.2 and older.
# It can be removed in the next minor bump (1.20.0)

from isar.script import start

if __name__ == "__main__":
    start()
