from enum import Enum


class BatteryState(Enum):
    Normal = "Normal"
    Charging = "Charging"
