from .fractal import fractal

__all__ = ("fractal",)
