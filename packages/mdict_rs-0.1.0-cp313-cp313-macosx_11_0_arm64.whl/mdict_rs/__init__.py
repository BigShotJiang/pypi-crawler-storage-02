from .mdict_rs import *

__doc__ = mdict_rs.__doc__
if hasattr(mdict_rs, "__all__"):
    __all__ = mdict_rs.__all__