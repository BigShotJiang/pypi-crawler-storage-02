from openfisca_tunisia import TunisiaTaxBenefitSystem


# Initialize a tax_benefit_system
tax_benefit_system = TunisiaTaxBenefitSystem()
