'''Revenus catégoriels.'''
