"""
TN-NT Templates init
"""

__version__ = "3.10.0"
__title__ = "Terra Nanotech Alliance Auth Template Overrides"
