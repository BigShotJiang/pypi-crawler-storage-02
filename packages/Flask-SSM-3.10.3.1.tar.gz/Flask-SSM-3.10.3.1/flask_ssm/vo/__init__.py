# -*- coding: utf-8 -*-
from flask_ssm.vo.common import CommonResult
