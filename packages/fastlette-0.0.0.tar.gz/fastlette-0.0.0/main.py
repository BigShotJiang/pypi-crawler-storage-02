def main():
    print("Hello from fastlette!")


if __name__ == "__main__":
    main()
