from helper import *


@TestInstance
def test_condition():
    x = EUDLightBool()
    # FIXME: test late-phase error
    # with expect_eperror():
    #     SetVariables(x, EUDNot(x), SetTo)
