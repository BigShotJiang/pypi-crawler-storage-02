//
// Created by phu54321 on 2018-01-26.
//

#ifndef EPSCRIPT_TRACEUTILS_H
#define EPSCRIPT_TRACEUTILS_H

#include "../tokenizer/tokenizer.h"
#include <ostream>
void writeTraceInfo(std::ostream& os, Token* tok);

#endif //EPSCRIPT_TRACEUTILS_H
