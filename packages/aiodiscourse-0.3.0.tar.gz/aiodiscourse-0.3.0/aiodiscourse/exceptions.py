class DiscourseAPIError(Exception):
    pass
