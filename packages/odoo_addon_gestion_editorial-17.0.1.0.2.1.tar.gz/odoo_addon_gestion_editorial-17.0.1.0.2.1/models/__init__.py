# Do not edit the order of the imports;
# it's relevant for dependencies between them
from . import ddaa_authorship_conditions
from . import authorship_product
from . import res_partner_editorial
from . import res_company_editorial
from . import res_config_settings_editorial
from . import stock_location_editorial
from . import product_editorial
from . import liquidacion_editorial
from . import sale_order_editorial
from . import stock_picking_editorial
from . import purchase_order_editorial
from . import product_pricelist_editorial
from . import pos_order_editorial
from . import stock_move_editorial
from . import stock_route_editorial
