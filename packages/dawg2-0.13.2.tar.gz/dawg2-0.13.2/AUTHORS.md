# Authors & Contributors

- Mikhail Korobov \<kmike84@gmail.com\>
- Dan Blanchard
- Jakub Wilk
- Alex Moiseenko
- [Matt Hickford](https://github.com/matt-hickford)
- [Ikuya Yamada](https://github.com/ikuyamada)
- [bt2901](https://github.com/bt2901)
- [insolor](https://github.com/insolor)
- [gmossessian](https://github.com/gmossessian)

This module uses [dawgdic](https://code.google.com/p/dawgdic/) C++
library by Susumu Yata & contributors.

base64 decoder is a modified version of
[libb64](http://libb64.sourceforge.net/) (original author is Chris
Venter).
