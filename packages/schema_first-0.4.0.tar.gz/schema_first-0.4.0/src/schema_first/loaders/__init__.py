from .yaml_loader import load_from_yaml

__all__ = ['load_from_yaml']
