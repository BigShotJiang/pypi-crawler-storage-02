# MADSci Experiment Manager

TODO

## Experiment Campaigns

TODO

## Experiment Designs

TODO

## Experiment Runs

TODO

## Experiment Status

TODO

## Usage

### Experiment Manager

TODO

### Experiment Client

TODO

### Experiment Application

TODO
