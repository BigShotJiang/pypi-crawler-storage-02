knitout\_interpreter.knitout\_operations.needle\_instructions module
====================================================================

.. automodule:: knitout_interpreter.knitout_operations.needle_instructions
   :members:
   :undoc-members:
   :show-inheritance:
