qh3
===

|pypi-pyversions| |pypi-stats|

.. |pypi-pyversions| image:: https://img.shields.io/pypi/pyversions/qh3.svg
    :target: https://pypi.python.org/pypi/qh3
    :alt: Supported Interpreters

.. |pypi-stats| image:: https://img.shields.io/pypi/dm/qh3
   :target: https://pypistats.org/packages/qh3
   :alt: PyPI - Downloads

What is ``qh3``?
----------------

``qh3`` is a maintained fork of the ``aioquic`` library.

It is lighter, faster, and more adapted to a broader audience as this package has no external dependency
and does not rely on mainstream OpenSSL.

While it is a compatible fork, it is not a drop-in replacement since the first major. See the CHANGELOG for details.

``qh3`` is a library for the QUIC network protocol in Python. It features
a minimal TLS 1.3 implementation, a QUIC stack, and an HTTP/3 stack.

QUIC was standardized in `RFC 9000`_ and HTTP/3 in `RFC 9114`_.
``qh3`` follow the standardized version of QUIC and HTTP/3.

QUIC stack conforming with `RFC 9000`_ (QUIC v1) and `RFC 9369`_ (QUIC v2)

To learn more about ``qh3`` please `read the documentation`_.

``qh3`` stands for **Q** UIC . **H** TTP/ **3**.

Our primary goal with this fork is mainly about the client aspect, while the
server side code is maintained, we do not have enough time to add feature to it at the moment.

PR are welcomed for any improvement (server or client).

Why should I use ``qh3``?
-----------------------------

``qh3`` has been designed to be embedded into Python client and server
libraries wishing to support QUIC and/or HTTP/3. The goal is to provide a
common codebase for Python libraries in the hope of avoiding duplicated effort.

Both the QUIC and the HTTP/3 APIs follow the "bring your own I/O" pattern,
leaving actual I/O operations to the API user. This approach has a number of
advantages including making the code testable and allowing integration with
different concurrency models.

This library is the lowest level you can find for handling QUIC and HTTP/3. Here are higher libraries:

- mid-way: `urllib3.future`_
- highest and easiest: `niquests`_ (Recommended!)

Features
--------

- QUIC stack conforming with `RFC 9000`_
- HTTP/3 stack conforming with `RFC 9114`_
- minimal TLS 1.3 implementation conforming with `RFC 8446`_
- IPv4 and IPv6 support
- connection migration and NAT rebinding
- logging TLS traffic secrets
- logging QUIC events in QLOG format
- HTTP/3 server push support
- Post-Quantum (KEM) Key-Exchange (NIST FIPS 203 ML-KEM-768)
- OCSP Stapling (Client Only)

Requirements
------------

``qh3`` requires Python and PyPy 3.7 or greater.

Running the examples
--------------------

`qh3` comes with a number of examples illustrating various QUIC use cases.

You can browse these examples here: https://github.com/jawah/qh3/tree/main/examples

License
-------

``qh3`` is released under the `BSD license`_.

.. _read the documentation: https://qh3.readthedocs.io/en/latest/
.. _BSD license: https://qh3.readthedocs.io/en/latest/license.html
.. _RFC 8446: https://datatracker.ietf.org/doc/html/rfc8446
.. _RFC 9000: https://datatracker.ietf.org/doc/html/rfc9000
.. _RFC 9114: https://datatracker.ietf.org/doc/html/rfc9114
.. _RFC 9369: https://datatracker.ietf.org/doc/html/rfc9369
.. _niquests: https://github.com/jawah/niquests
.. _urllib3.future: https://github.com/jawah/urllib3.future
