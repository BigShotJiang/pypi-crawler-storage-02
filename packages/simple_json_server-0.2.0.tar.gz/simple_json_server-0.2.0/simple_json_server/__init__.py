from .simple_json_server import main

__all__ = ["main"]