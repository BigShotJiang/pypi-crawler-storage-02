This module allows you to restrict teams and categories for each customer.
