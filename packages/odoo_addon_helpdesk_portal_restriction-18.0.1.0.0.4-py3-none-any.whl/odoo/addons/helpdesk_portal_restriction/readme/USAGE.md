Go to the partner and select the teams and categories for which can open ticket
