/* global angular */
(function () {
  'use strict';

  angular.module('blocks.router', ['ui.router']);
})();
