class SkAcrylic:
    def __init__(self, parent):
        self.parent = parent
