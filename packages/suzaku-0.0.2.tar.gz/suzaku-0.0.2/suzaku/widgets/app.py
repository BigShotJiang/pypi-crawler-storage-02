from ..base.appbase import SkAppBase


class SkApp(SkAppBase):

    def __init__(self, *args, **kwargs):
        """: SkApp, inherited from SkAppBase"""
        super().__init__(*args, **kwargs)
