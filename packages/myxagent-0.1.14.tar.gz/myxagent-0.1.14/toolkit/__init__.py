from .tools import char_count

TOOLKIT_REGISTRY = {
    "char_count": char_count
}