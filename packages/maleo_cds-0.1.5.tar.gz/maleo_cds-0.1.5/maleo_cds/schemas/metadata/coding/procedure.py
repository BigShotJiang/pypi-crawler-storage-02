from maleo_soma.mixins.timestamp import Duration


class GenerateSuggestionMetadataSchema(Duration):
    pass
