# This file is a part of the `allegro` package. Please see LICENSE and README at the root for information on using it.
# Allegro package version file
# See Python packaging guide
# https://packaging.python.org/guides/single-sourcing-package-version/

__version__ = "0.7.1"
