# Command API reference

-----

::: dda.cli.base.dynamic_command

::: dda.cli.base.dynamic_group

::: dda.cli.base.DynamicCommand
    options:
      merge_init_into_class: true
      members: []

::: dda.cli.base.DynamicGroup
    options:
      merge_init_into_class: true
      members: []
