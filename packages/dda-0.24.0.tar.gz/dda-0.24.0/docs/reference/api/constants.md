# Constants reference

-----

::: dda.config.constants
    options:
      show_root_heading: false
      show_root_toc_entry: false
