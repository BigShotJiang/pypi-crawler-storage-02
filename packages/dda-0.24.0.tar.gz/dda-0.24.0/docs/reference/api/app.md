# Application reference

-----

::: dda.cli.application.Application
    options:
      inherited_members: true
      members:
      - abort
      - config
      - subprocess
      - http
      - tools
      - telemetry
      - last_error
      - display
      - display_critical
      - display_error
      - display_warning
      - display_info
      - display_success
      - display_waiting
      - display_debug
      - display_header
      - display_table
      - display_syntax
      - display_markdown
      - status
      - prompt
      - confirm
