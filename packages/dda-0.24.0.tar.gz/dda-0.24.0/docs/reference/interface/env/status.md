# Environment status

-----

::: dda.env.models.EnvironmentStatus

::: dda.env.models.EnvironmentState
