"""Pure user code without Flow imports."""


def add_and_scale(a: int, b: int, scale: int = 1) -> int:
    return (a + b) * scale
