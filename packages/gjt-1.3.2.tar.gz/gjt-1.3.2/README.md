# Green Jasmine Tea - gjt
## Biblioteka pomocnicza do łączenia i komunikowania się z websocketem Goodgame Empire

### Aktualne funkcje to:
fakescanning - skanuje mape co dany czas

keep-alive - nazwa mówi sama za siebie

configmaker - dla configów botów

getserver - aby uzyskać cross-server compatibility ta funkcja daje uri websocketu jak i nazwe EmpireEx_xyz

ggs_login - login z generatorem ReCaptcha v2
