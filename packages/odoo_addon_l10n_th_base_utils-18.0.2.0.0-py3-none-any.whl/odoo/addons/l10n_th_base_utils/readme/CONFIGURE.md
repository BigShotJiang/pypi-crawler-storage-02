To configure the Thai font, go to Settings > General Settings > Business Documents > Configure Document Layout,
then select the desired font and click Save.
