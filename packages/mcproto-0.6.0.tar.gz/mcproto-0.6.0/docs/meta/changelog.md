# Changelog

!!! danger ""

    Major and minor releases also include the changes specified in prior development releases.

!!! tip

    Feel free to skip the **Internal Changes** category if you aren't a contributor / core developer of mcproto.

```python exec="yes"
--8<-- "docs/scripts/gen_changelog.py"
```

--8<-- "CHANGELOG.md"
