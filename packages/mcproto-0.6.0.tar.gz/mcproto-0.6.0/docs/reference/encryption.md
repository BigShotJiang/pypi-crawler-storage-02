# Encryption utilities

The following components are used for encryption related interacions (generally needed during the communication with
the server, after an encryption request during the login process)

::: mcproto.encryption
