# Authentication

::: mcproto.auth.account

::: mcproto.auth.yggdrasil

::: mcproto.auth.msa

::: mcproto.auth.microsoft.oauth

::: mcproto.auth.microsoft.xbox
