# Protocol documentation

This is the documentation for components related to interactions with the minecraft protocol and connection establishing.

::: mcproto.protocol.base_io

::: mcproto.buffer.Buffer
    options:
        show_root_heading: true
        show_root_toc_entry: true

::: mcproto.connection
