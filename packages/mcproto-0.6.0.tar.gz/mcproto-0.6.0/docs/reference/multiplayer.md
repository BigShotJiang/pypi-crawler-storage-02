# Multiplayer utilities

The following components are used for various multiplayer interacions (generally needed during the server joining process).

::: mcproto.multiplayer
