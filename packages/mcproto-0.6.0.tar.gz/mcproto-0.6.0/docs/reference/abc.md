# Abstract Base Classes

::: mcproto.utils.abc.Serializable
    options:
        show_root_heading: true
        show_root_toc_entry: true
