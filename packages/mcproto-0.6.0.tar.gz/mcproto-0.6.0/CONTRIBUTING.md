# Contributing Guidelines

You can find our contributing guidelines and instructions on setting up the project in our documentation:
[here](https://py-mine.github.io/mcproto/latest/contributing/guides/)
