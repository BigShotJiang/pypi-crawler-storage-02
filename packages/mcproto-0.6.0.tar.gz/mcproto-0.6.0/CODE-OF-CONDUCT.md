You can find our Code of Conduct in the project's documentation
[here](https://py-mine.github.io/mcproto/latest/meta/code-of-conduct/)
