# Changelog fragments

This folder holds fragments of the changelog to be used in the next release, when the final changelog will be
generated.

To learn more about changelog fragments, see our
[documentation](https://py-mine.github.io/mcproto/latest/contributing/guides/changelog/)
