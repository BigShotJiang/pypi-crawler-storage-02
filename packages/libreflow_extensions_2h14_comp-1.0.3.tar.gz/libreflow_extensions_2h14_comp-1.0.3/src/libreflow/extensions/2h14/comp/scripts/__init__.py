import kabaret.app.resources as resources

resources.add_folder("scripts", __file__)