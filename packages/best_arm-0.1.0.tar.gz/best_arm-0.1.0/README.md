# multi-arm

A modular multi-armed bandit framework (best-arm identification focused).

## Install
```bash
pip install multi-arm
