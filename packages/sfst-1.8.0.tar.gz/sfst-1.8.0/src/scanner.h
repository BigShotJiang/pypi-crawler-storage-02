/*******************************************************************/
/*                                                                 */
/*  FILE     scanner.h                                             */
/*  MODULE   scanner                                               */
/*  PROGRAM  SFST                                                  */
/*  AUTHOR   Helmut Schmid, IMS, University of Stuttgart           */
/*                                                                 */
/*******************************************************************/

extern char *FileName;
extern bool UTF8;
extern bool Verbose;
