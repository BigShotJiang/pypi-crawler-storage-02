"""
Core Fluidize Logic
"""
