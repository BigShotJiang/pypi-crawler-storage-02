"""Core module unit tests."""
