# fluidize-python

[![Release](https://img.shields.io/github/v/release/Fluidize-Inc/fluidize-python)](https://img.shields.io/github/v/release/Fluidize-Inc/fluidize-python)
[![Build status](https://img.shields.io/github/actions/workflow/status/Fluidize-Inc/fluidize-python/main.yml?branch=main)](https://github.com/Fluidize-Inc/fluidize-python/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/Fluidize-Inc/fluidize-python)](https://img.shields.io/github/commit-activity/m/Fluidize-Inc/fluidize-python)
[![License](https://img.shields.io/github/license/Fluidize-Inc/fluidize-python)](https://img.shields.io/github/license/Fluidize-Inc/fluidize-python)

Python package for automatic generation of scientific computing software pipelines.
