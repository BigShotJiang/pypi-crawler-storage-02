============
Installation
============

To install `roman_photoz`, follow these steps:

1. Clone the repository:

    .. code-block:: bash

        git clone https://github.com/yourusername/roman_photoz.git

2. Navigate to the project directory:

    .. code-block:: bash

        cd roman_photoz

3. Install the required dependencies:

    .. code-block:: bash

        pip install -r requirements.txt
