"""Regression test framework for the Roman Photoz pipeline."""
