# Regression Test Framework

`roman_photoz` uses the same test framework as `romancal`. Therefore, for detailed information about it, please refer to the `romancal`'s official documentation [here](https://github.com/spacetelescope/romancal?tab=readme-ov-file#regression-tests)

## Extending

To add support for comparing specific file formats, add methods to the `RegtestData` class.
