from .roman_catalog_process import main

if __name__ == "__main__":
    main()
