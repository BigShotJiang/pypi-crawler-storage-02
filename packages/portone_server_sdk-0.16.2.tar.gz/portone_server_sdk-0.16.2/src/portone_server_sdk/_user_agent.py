USER_AGENT = "v0.16.2-dirty"

__all__ = ["USER_AGENT"]
