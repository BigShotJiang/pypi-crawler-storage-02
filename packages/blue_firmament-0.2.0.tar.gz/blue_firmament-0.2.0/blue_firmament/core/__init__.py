"""Core Module of BlueFirmament
"""

__all__ = [
    "BlueFirmamentApp"
]


from .app import BlueFirmamentApp