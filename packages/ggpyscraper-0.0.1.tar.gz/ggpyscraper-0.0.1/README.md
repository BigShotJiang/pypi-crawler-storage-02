# ggpyscraper
Similar to the sports-dataverse, an open source project looking to provide easy to use python functions to get esports data from liquipedia