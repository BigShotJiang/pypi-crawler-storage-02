"""Authentication and configuration tests."""
