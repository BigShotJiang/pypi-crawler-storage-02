from distutils.core import setup 

setup(
        name='mengjia',
        version='0.1.4',
        description='A apikey generate method, the apikey will expire when current data  over input date',
        author='zqk',
        author_email='xx',
        packages=['mengjia']
)
