#
#
#


class SecretsException(Exception):
    pass
