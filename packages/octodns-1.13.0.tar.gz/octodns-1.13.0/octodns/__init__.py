'OctoDNS: DNS as code - Tools for managing DNS across multiple providers'

# TODO: remove __VERSION__ w/2.x
__version__ = __VERSION__ = '1.13.0'
