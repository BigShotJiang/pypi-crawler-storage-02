"""Version information for PyStow."""

__all__ = [
    "VERSION",
]

VERSION = "0.7.5"
