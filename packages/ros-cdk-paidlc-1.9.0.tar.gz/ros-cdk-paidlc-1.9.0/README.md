## Aliyun ROS PAIDLC Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as PAIDLC from '@alicloud/ros-cdk-paidlc';
```
