# -*- coding:utf-8 -*-

name = "krux"
__version__ = '0.0.35'