"""
Common Library Version Report Application
"""

from . import version_msg


if __name__ == '__main__':
    print(version_msg())
