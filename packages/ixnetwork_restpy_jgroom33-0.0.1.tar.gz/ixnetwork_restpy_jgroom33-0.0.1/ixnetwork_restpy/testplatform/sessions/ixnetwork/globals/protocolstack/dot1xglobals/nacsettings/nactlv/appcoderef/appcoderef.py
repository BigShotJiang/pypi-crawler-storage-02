
import sys
from ixnetwork_restpy.base import Base
from ixnetwork_restpy.files import Files

if sys.version_info >= (3, 5):
    from typing import List, Any, Union


class AppCodeRef(Base):
    """TLV Application Code
    The AppCodeRef class encapsulates a required appCodeRef resource which will be retrieved from the server every time the property is accessed.
    """

    __slots__ = ()
    _SDM_NAME = "appCodeRef"
    _SDM_ATT_MAP = {
        "Name": "name",
        "ObjectId": "objectId",
        "Value": "value",
    }
    _SDM_ENUM_MAP = {}

    def __init__(self, parent, list_op=False):
        super(AppCodeRef, self).__init__(parent, list_op)

    @property
    def Name(self):
        # type: () -> str
        """
        Returns
        -------
        - str: AppCode Name.
        """
        return self._get_attribute(self._SDM_ATT_MAP["Name"])

    @Name.setter
    def Name(self, value):
        # type: (str) -> None
        self._set_attribute(self._SDM_ATT_MAP["Name"], value)

    @property
    def ObjectId(self):
        # type: () -> str
        """
        Returns
        -------
        - str: Unique identifier for this object
        """
        return self._get_attribute(self._SDM_ATT_MAP["ObjectId"])

    @property
    def Value(self):
        # type: () -> int
        """
        Returns
        -------
        - number: AppCode ID.
        """
        return self._get_attribute(self._SDM_ATT_MAP["Value"])

    @Value.setter
    def Value(self, value):
        # type: (int) -> None
        self._set_attribute(self._SDM_ATT_MAP["Value"], value)

    def update(self, Name=None, Value=None):
        # type: (str, int) -> AppCodeRef
        """Updates appCodeRef resource on the server.

        Args
        ----
        - Name (str): AppCode Name.
        - Value (number): AppCode ID.

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._update(self._map_locals(self._SDM_ATT_MAP, locals()))

    def find(self, Name=None, ObjectId=None, Value=None):
        # type: (str, str, int) -> AppCodeRef
        """Finds and retrieves appCodeRef resources from the server.

        All named parameters are evaluated on the server using regex. The named parameters can be used to selectively retrieve appCodeRef resources from the server.
        To retrieve an exact match ensure the parameter value starts with ^ and ends with $
        By default the find method takes no parameters and will retrieve all appCodeRef resources from the server.

        Args
        ----
        - Name (str): AppCode Name.
        - ObjectId (str): Unique identifier for this object
        - Value (number): AppCode ID.

        Returns
        -------
        - self: This instance with matching appCodeRef resources retrieved from the server available through an iterator or index

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._select(self._map_locals(self._SDM_ATT_MAP, locals()))

    def read(self, href):
        """Retrieves a single instance of appCodeRef data from the server.

        Args
        ----
        - href (str): An href to the instance to be retrieved

        Returns
        -------
        - self: This instance with the appCodeRef resources from the server available through an iterator or index

        Raises
        ------
        - NotFoundError: The requested resource does not exist on the server
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._read(href)
