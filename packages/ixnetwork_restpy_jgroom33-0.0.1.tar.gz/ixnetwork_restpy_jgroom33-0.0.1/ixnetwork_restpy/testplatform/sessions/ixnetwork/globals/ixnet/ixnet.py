
import sys
from ixnetwork_restpy.base import Base
from ixnetwork_restpy.files import Files

if sys.version_info >= (3, 5):
    from typing import List, Any, Union


class Ixnet(Base):
    """Tracks remote clients connected using the ixNet API Service over websockets.
    The Ixnet class encapsulates a required ixnet resource which will be retrieved from the server every time the property is accessed.
    """

    __slots__ = ()
    _SDM_NAME = "ixnet"
    _SDM_ATT_MAP = {
        "ConnectedClients": "connectedClients",
        "IsActive": "isActive",
    }
    _SDM_ENUM_MAP = {}

    def __init__(self, parent, list_op=False):
        super(Ixnet, self).__init__(parent, list_op)

    @property
    def ConnectedClients(self):
        # type: () -> List[str]
        """
        Returns
        -------
        - list(str): Returns the remote address and remote port for each of the currently connected ixNet clients.
        """
        return self._get_attribute(self._SDM_ATT_MAP["ConnectedClients"])

    @property
    def IsActive(self):
        # type: () -> bool
        """
        Returns
        -------
        - bool: Returns true if any remote clients are connected, false if no remote clients are connected.
        """
        return self._get_attribute(self._SDM_ATT_MAP["IsActive"])

    def find(self, ConnectedClients=None, IsActive=None):
        # type: (List[str], bool) -> Ixnet
        """Finds and retrieves ixnet resources from the server.

        All named parameters are evaluated on the server using regex. The named parameters can be used to selectively retrieve ixnet resources from the server.
        To retrieve an exact match ensure the parameter value starts with ^ and ends with $
        By default the find method takes no parameters and will retrieve all ixnet resources from the server.

        Args
        ----
        - ConnectedClients (list(str)): Returns the remote address and remote port for each of the currently connected ixNet clients.
        - IsActive (bool): Returns true if any remote clients are connected, false if no remote clients are connected.

        Returns
        -------
        - self: This instance with matching ixnet resources retrieved from the server available through an iterator or index

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._select(self._map_locals(self._SDM_ATT_MAP, locals()))

    def read(self, href):
        """Retrieves a single instance of ixnet data from the server.

        Args
        ----
        - href (str): An href to the instance to be retrieved

        Returns
        -------
        - self: This instance with the ixnet resources from the server available through an iterator or index

        Raises
        ------
        - NotFoundError: The requested resource does not exist on the server
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._read(href)
