
import sys
from ixnetwork_restpy.base import Base
from ixnetwork_restpy.files import Files

if sys.version_info >= (3, 5):
    from typing import List, Any, Union


class IpGlobals(Base):
    """Global settings for IP plugin.
    The IpGlobals class encapsulates a list of ipGlobals resources that are managed by the user.
    A list of resources can be retrieved from the server using the IpGlobals.find() method.
    The list can be managed by using the IpGlobals.add() and IpGlobals.remove() methods.
    """

    __slots__ = ()
    _SDM_NAME = "ipGlobals"
    _SDM_ATT_MAP = {
        "EnableGatewayArp": "enableGatewayArp",
        "GatewayArpRequestRate": "gatewayArpRequestRate",
        "MaxOutstandingGatewayArpRequests": "maxOutstandingGatewayArpRequests",
        "ObjectId": "objectId",
        "SendOneArpFromEachInterface": "sendOneArpFromEachInterface",
    }
    _SDM_ENUM_MAP = {}

    def __init__(self, parent, list_op=False):
        super(IpGlobals, self).__init__(parent, list_op)

    @property
    def EnableGatewayArp(self):
        # type: () -> bool
        """
        Returns
        -------
        - bool: When enabled, every IP address will ARP the specified gateway.
        """
        return self._get_attribute(self._SDM_ATT_MAP["EnableGatewayArp"])

    @EnableGatewayArp.setter
    def EnableGatewayArp(self, value):
        # type: (bool) -> None
        self._set_attribute(self._SDM_ATT_MAP["EnableGatewayArp"], value)

    @property
    def GatewayArpRequestRate(self):
        # type: () -> int
        """
        Returns
        -------
        - number: Maximum ARP request rate
        """
        return self._get_attribute(self._SDM_ATT_MAP["GatewayArpRequestRate"])

    @GatewayArpRequestRate.setter
    def GatewayArpRequestRate(self, value):
        # type: (int) -> None
        self._set_attribute(self._SDM_ATT_MAP["GatewayArpRequestRate"], value)

    @property
    def MaxOutstandingGatewayArpRequests(self):
        # type: () -> int
        """
        Returns
        -------
        - number: Threshold at which the plugin begins throttling back the number of new ARP requests sent out.
        """
        return self._get_attribute(
            self._SDM_ATT_MAP["MaxOutstandingGatewayArpRequests"]
        )

    @MaxOutstandingGatewayArpRequests.setter
    def MaxOutstandingGatewayArpRequests(self, value):
        # type: (int) -> None
        self._set_attribute(
            self._SDM_ATT_MAP["MaxOutstandingGatewayArpRequests"], value
        )

    @property
    def ObjectId(self):
        # type: () -> str
        """
        Returns
        -------
        - str: Unique identifier for this object
        """
        return self._get_attribute(self._SDM_ATT_MAP["ObjectId"])

    @property
    def SendOneArpFromEachInterface(self):
        # type: () -> bool
        """
        Returns
        -------
        - bool: When set, each interface will send one ARP request.
        """
        return self._get_attribute(self._SDM_ATT_MAP["SendOneArpFromEachInterface"])

    @SendOneArpFromEachInterface.setter
    def SendOneArpFromEachInterface(self, value):
        # type: (bool) -> None
        self._set_attribute(self._SDM_ATT_MAP["SendOneArpFromEachInterface"], value)

    def update(
        self,
        EnableGatewayArp=None,
        GatewayArpRequestRate=None,
        MaxOutstandingGatewayArpRequests=None,
        SendOneArpFromEachInterface=None,
    ):
        # type: (bool, int, int, bool) -> IpGlobals
        """Updates ipGlobals resource on the server.

        Args
        ----
        - EnableGatewayArp (bool): When enabled, every IP address will ARP the specified gateway.
        - GatewayArpRequestRate (number): Maximum ARP request rate
        - MaxOutstandingGatewayArpRequests (number): Threshold at which the plugin begins throttling back the number of new ARP requests sent out.
        - SendOneArpFromEachInterface (bool): When set, each interface will send one ARP request.

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._update(self._map_locals(self._SDM_ATT_MAP, locals()))

    def add(
        self,
        EnableGatewayArp=None,
        GatewayArpRequestRate=None,
        MaxOutstandingGatewayArpRequests=None,
        SendOneArpFromEachInterface=None,
    ):
        # type: (bool, int, int, bool) -> IpGlobals
        """Adds a new ipGlobals resource on the server and adds it to the container.

        Args
        ----
        - EnableGatewayArp (bool): When enabled, every IP address will ARP the specified gateway.
        - GatewayArpRequestRate (number): Maximum ARP request rate
        - MaxOutstandingGatewayArpRequests (number): Threshold at which the plugin begins throttling back the number of new ARP requests sent out.
        - SendOneArpFromEachInterface (bool): When set, each interface will send one ARP request.

        Returns
        -------
        - self: This instance with all currently retrieved ipGlobals resources using find and the newly added ipGlobals resources available through an iterator or index

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._create(self._map_locals(self._SDM_ATT_MAP, locals()))

    def remove(self):
        """Deletes all the contained ipGlobals resources in this instance from the server.

        Raises
        ------
        - NotFoundError: The requested resource does not exist on the server
        - ServerError: The server has encountered an uncategorized error condition
        """
        self._delete()

    def find(
        self,
        EnableGatewayArp=None,
        GatewayArpRequestRate=None,
        MaxOutstandingGatewayArpRequests=None,
        ObjectId=None,
        SendOneArpFromEachInterface=None,
    ):
        # type: (bool, int, int, str, bool) -> IpGlobals
        """Finds and retrieves ipGlobals resources from the server.

        All named parameters are evaluated on the server using regex. The named parameters can be used to selectively retrieve ipGlobals resources from the server.
        To retrieve an exact match ensure the parameter value starts with ^ and ends with $
        By default the find method takes no parameters and will retrieve all ipGlobals resources from the server.

        Args
        ----
        - EnableGatewayArp (bool): When enabled, every IP address will ARP the specified gateway.
        - GatewayArpRequestRate (number): Maximum ARP request rate
        - MaxOutstandingGatewayArpRequests (number): Threshold at which the plugin begins throttling back the number of new ARP requests sent out.
        - ObjectId (str): Unique identifier for this object
        - SendOneArpFromEachInterface (bool): When set, each interface will send one ARP request.

        Returns
        -------
        - self: This instance with matching ipGlobals resources retrieved from the server available through an iterator or index

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._select(self._map_locals(self._SDM_ATT_MAP, locals()))

    def read(self, href):
        """Retrieves a single instance of ipGlobals data from the server.

        Args
        ----
        - href (str): An href to the instance to be retrieved

        Returns
        -------
        - self: This instance with the ipGlobals resources from the server available through an iterator or index

        Raises
        ------
        - NotFoundError: The requested resource does not exist on the server
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._read(href)
