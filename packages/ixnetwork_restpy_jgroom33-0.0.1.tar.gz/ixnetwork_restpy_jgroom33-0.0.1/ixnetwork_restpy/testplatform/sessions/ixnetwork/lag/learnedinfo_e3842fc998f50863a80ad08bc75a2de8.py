
import sys
from ixnetwork_restpy.base import Base
from ixnetwork_restpy.files import Files

if sys.version_info >= (3, 5):
    from typing import List, Any, Union


class LearnedInfo(Base):
    """The main learned information node that contains tables of learned information.
    The LearnedInfo class encapsulates a list of learnedInfo resources that are managed by the system.
    A list of resources can be retrieved from the server using the LearnedInfo.find() method.
    """

    __slots__ = ()
    _SDM_NAME = "learnedInfo"
    _SDM_ATT_MAP = {
        "Id__": "__id__",
        "Columns": "columns",
        "State": "state",
        "Type": "type",
        "Values": "values",
    }
    _SDM_ENUM_MAP = {}

    def __init__(self, parent, list_op=False):
        super(LearnedInfo, self).__init__(parent, list_op)

    @property
    def Col(self):
        """DEPRECATED
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.lag.col_667991bd02f140c2b2287de796fe1846.Col): An instance of the Col class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.lag.col_667991bd02f140c2b2287de796fe1846 import (
            Col,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("Col", None) is not None:
                return self._properties.get("Col")
        return Col(self)

    @property
    def Table(self):
        """
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.lag.table_5db82318b9a3adae08e0db1b40a3ca80.Table): An instance of the Table class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.lag.table_5db82318b9a3adae08e0db1b40a3ca80 import (
            Table,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("Table", None) is not None:
                return self._properties.get("Table")
        return Table(self)

    @property
    def Id__(self):
        # type: () -> List[str]
        """
        Returns
        -------
        - list(str): A unique id for the learned information table
        """
        return self._get_attribute(self._SDM_ATT_MAP["Id__"])

    @property
    def Columns(self):
        # type: () -> List[str]
        """DEPRECATED
        Returns
        -------
        - list(str): The list of columns in the learned information table
        """
        return self._get_attribute(self._SDM_ATT_MAP["Columns"])

    @property
    def State(self):
        # type: () -> str
        """
        Returns
        -------
        - str: The state of the learned information query
        """
        return self._get_attribute(self._SDM_ATT_MAP["State"])

    @property
    def Type(self):
        # type: () -> str
        """DEPRECATED
        Returns
        -------
        - str: The type of learned information
        """
        return self._get_attribute(self._SDM_ATT_MAP["Type"])

    @property
    def Values(self):
        """DEPRECATED
        Returns
        -------
        - list(list[str]): A list of rows of learned information values
        """
        return self._get_attribute(self._SDM_ATT_MAP["Values"])

    def add(self):
        """Adds a new learnedInfo resource on the json, only valid with batch add utility

        Returns
        -------
        - self: This instance with all currently retrieved learnedInfo resources using find and the newly added learnedInfo resources available through an iterator or index

        Raises
        ------
        - Exception: if this function is not being used with config assistance
        """
        return self._add_xpath(self._map_locals(self._SDM_ATT_MAP, locals()))

    def find(self, Id__=None, Columns=None, State=None, Type=None, Values=None):
        """Finds and retrieves learnedInfo resources from the server.

        All named parameters are evaluated on the server using regex. The named parameters can be used to selectively retrieve learnedInfo resources from the server.
        To retrieve an exact match ensure the parameter value starts with ^ and ends with $
        By default the find method takes no parameters and will retrieve all learnedInfo resources from the server.

        Args
        ----
        - Id__ (list(str)): A unique id for the learned information table
        - Columns (list(str)): The list of columns in the learned information table
        - State (str): The state of the learned information query
        - Type (str): The type of learned information
        - Values (list(list[str])): A list of rows of learned information values

        Returns
        -------
        - self: This instance with matching learnedInfo resources retrieved from the server available through an iterator or index

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._select(self._map_locals(self._SDM_ATT_MAP, locals()))

    def read(self, href):
        """Retrieves a single instance of learnedInfo data from the server.

        Args
        ----
        - href (str): An href to the instance to be retrieved

        Returns
        -------
        - self: This instance with the learnedInfo resources from the server available through an iterator or index

        Raises
        ------
        - NotFoundError: The requested resource does not exist on the server
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._read(href)
