---
name: Feature request
about: Suggest an idea for this project
title: "[Feature request]: "
labels: enhancement
assignees: SilenceX12138

---

**Describe the solution you'd like**

- [ ] **Objective**
       1. 

- [ ] **Input**
       1. 

- [ ] **Output**
       1. 

**Additional context**

*
