"""SignWordnet dataset."""

from .sign_wordnet import SignWordnet
