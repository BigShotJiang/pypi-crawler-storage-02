"""ChicagoFSWild dataset."""

from .chicago_fs_wild import ChicagoFSWild
