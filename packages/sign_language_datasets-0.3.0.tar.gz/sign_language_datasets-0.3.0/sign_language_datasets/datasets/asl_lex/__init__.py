"""asl_lex dataset."""

from .asl_lex import AslLex
