"""sign2mint dataset."""

from .dicta_sign import DictaSign
