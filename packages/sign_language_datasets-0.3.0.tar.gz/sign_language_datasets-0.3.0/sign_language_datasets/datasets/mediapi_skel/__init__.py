"""mediapi_skel dataset."""

from .mediapi_skel import MediapiSkel
