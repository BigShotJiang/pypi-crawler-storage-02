"""asl-signs dataset."""

from .asl_signs import ASLSigns
