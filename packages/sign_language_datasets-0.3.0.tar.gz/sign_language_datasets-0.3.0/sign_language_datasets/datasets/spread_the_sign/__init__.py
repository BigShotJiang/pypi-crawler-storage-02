"""asl-signs dataset."""

from .spread_the_sign import SpreadTheSign
