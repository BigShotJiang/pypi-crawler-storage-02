"""sign2mint dataset."""

from .sign2mint import Sign2MINT
