"""aslg_pc12 dataset."""

from .aslg_pc12 import AslgPc12
