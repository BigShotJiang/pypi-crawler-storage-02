"""SignBank dataset."""

from .signbank import SignBank
