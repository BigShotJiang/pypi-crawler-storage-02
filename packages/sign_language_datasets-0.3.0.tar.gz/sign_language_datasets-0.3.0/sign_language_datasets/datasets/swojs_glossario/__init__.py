"""swojs_glossario dataset."""

from .swojs_glossario import SwojsGlossario
