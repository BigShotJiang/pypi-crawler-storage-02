# Scratchpad

## Code architecture


