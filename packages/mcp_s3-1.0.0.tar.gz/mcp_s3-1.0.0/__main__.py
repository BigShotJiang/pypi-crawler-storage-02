#!/usr/bin/env python3
"""
MCP S3 File Uploader - Module entry point
"""

from mcp_s3 import main

if __name__ == "__main__":
    main()
