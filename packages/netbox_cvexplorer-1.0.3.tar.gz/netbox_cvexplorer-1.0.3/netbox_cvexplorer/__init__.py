from .plugin import CVExplorerConfig as config
