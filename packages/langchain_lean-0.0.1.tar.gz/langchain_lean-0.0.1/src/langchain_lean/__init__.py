"""Main entry point for the langchain_lean package."""

__version__ = "0.0.1"

from .core import hello_langchain_lean
