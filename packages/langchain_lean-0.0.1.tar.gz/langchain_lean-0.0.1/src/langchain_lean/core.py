def hello_langchain_lean():
    """
    Prints a message indicating that the library is under development.
    """
    print("La librería langchain_lean está en proceso de desarrollo.")
