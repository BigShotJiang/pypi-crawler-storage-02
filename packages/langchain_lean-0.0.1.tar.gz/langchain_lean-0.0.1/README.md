# langchain_lean

A lean, lightweight version of LangChain.

## Installation

```bash
pip install langchain_lean
```

## Usage

```python
# Add usage examples here
```
