# /e2w/__init__.py

from .e2w import ExportToWord

__all__ = [
    "ExportToWord",
]