# API文档生成MCP工具 v1.0 发布说明

## 简介

API文档生成MCP工具是一个专为Cursor设计的自动化API文档生成工具。该工具能够自动编排整个API文档生成工作流，从分析项目结构到最终生成完整的Markdown格式API文档，大大减少了人工编写API文档的工作量。

## 主要功能

- **自动化工作流编排** - 从项目分析到文档生成的完整自动化流程
- **多语言支持** - 支持Java、Python、Node.js、Go等多种项目类型
- **智能项目分析** - 自动识别API路由、控制器、认证拦截器和过滤器
- **详细文档生成** - 生成包含完整API信息的Markdown文档
- **文档完整性检查** - 自动检查并补充遗漏的API信息

## 安装指南

### 环境要求

- Python 3.8 或更高版本
- pip 包管理器

### 安装步骤

1. 克隆或下载项目代码：
   ```bash
   git clone <项目地址>
   cd api-doc-mcp-server
   ```

2. 安装依赖：
   ```bash
   pip install -r requirements.txt
   ```

3. 运行MCP服务器：
   ```bash
   python main.py
   ```

4. 在Cursor中配置MCP工具连接：
   - 打开Cursor设置
   - 找到MCP工具配置
   - 添加新的MCP工具，配置地址为：`http://localhost:8000`

## 使用方法

1. 确保MCP服务器正在运行
2. 在Cursor中打开需要生成API文档的项目
3. 启动"API文档生成工具"工作流
4. 工具将自动分析项目结构并指导Cursor完成文档生成

## 版本信息

- 版本号：v1.0
- 发布日期：2025-08-09
- 兼容性：与Cursor最新版本兼容

## 更新日志

### v1.0 (2025-08-09)

- 实现完整的API文档生成工作流
- 支持多种项目类型（Java, Python, Node.js, Go）
- 集成到Cursor中实现自动化操作
- 生成Markdown格式的API文档
- 内存管理优化，避免脏数据积累
- 完善的文档和使用说明

## 已知问题

- 文档生成质量依赖于代码注释和结构清晰度
- 当前仅支持Markdown格式输出

## 技术支持

如在使用过程中遇到问题，请：
1. 检查README.md中的使用说明
2. 查看GitHub Issues页面是否有类似问题
3. 创建新的Issue详细描述遇到的问题