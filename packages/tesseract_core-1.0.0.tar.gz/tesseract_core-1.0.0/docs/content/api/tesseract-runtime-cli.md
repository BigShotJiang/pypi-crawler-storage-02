# `tesseract-runtime` command line application

This is the command line interface of the Tesseract runtime that is bundled with each Tesseract container.


```{eval-rst}
.. click:: tesseract_core.runtime.app_cli:tesseract_runtime_cli
   :prog: tesseract-runtime
   :nested: full
```
