# `tesseract` command line application

```{eval-rst}
.. click:: tesseract_core.sdk.cli:typer_click_object
   :prog: tesseract
   :nested: full
```
