# HelloWorld

## Context
This is a basic Hello World Tesseract. See [getting-started]
for more details on this Tesseract.

## Example Tesseract (`examples/helloworld`)

```{literalinclude} ../../../../examples/helloworld/tesseract_api.py
:language: python
```
