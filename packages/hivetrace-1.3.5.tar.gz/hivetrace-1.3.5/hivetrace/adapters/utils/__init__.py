"""
Utility module initialization.
"""

from hivetrace.adapters.utils.logging import process_agent_params

__all__ = ["process_agent_params"]
