# Authors

Contributors to pyprocessors_iptc_mapper include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
