# `@alicloud/ros-cdk-cxapi`

> TODO: description

## Usage

```
const rosCxapi = require('@alicloud/ros-cdk-cxapi');

// TODO: DEMONSTRATE API
```
