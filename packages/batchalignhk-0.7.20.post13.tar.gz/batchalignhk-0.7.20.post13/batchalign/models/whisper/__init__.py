from .infer_asr import WhisperASRModel
from .infer_fa import WhisperFAModel
