# ElevenLabs Realtime plugin
# This package exposes the RealtimeModel entrypoint under livekit.plugins.elevenlabs.realtime

from .realtime_model import RealtimeModel

__all__ = ["RealtimeModel"]
