"""Session management tests."""
