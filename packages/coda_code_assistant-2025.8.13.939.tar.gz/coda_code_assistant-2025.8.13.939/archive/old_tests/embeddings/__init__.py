"""Tests for embedding providers."""
