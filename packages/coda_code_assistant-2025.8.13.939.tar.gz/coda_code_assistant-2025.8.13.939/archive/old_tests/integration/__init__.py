"""Integration tests for external dependencies and services."""
