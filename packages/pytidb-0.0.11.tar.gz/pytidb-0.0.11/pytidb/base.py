from sqlmodel.main import default_registry

Base = default_registry.generate_base()
