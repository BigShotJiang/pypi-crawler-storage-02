## Aliyun ROS POLARDBX Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as POLARDBX from '@alicloud/ros-cdk-polardbx';
```
