# cache-middleware

Adds cache capabilities to Starlette/Fastapi projects

## What is cache-middleware

## Installation

Using pip:

```bash
pip install cache-middleware
```

## How to use it
