from kirin.ir import Dialect

dialect = Dialect(name="grid")
