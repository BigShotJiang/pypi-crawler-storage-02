# pylint: disable=wrong-or-nonexistent-copyright-notice
import cirq_aqt


def test_version():
    assert cirq_aqt.__version__ == "1.6.0"
