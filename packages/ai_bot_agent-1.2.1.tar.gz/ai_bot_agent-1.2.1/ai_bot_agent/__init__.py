"""
AI Bot Agent - Intelligent command line assistant
"""

__version__ = "1.2.1"
__author__ = "Thien Nguyen"
__email__ = "thien.nguyen@check24.de" 