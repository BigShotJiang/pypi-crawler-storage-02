from example.app.main import MainApplication

if __name__ == "__main__":
    app = MainApplication()
    app.main_loop()