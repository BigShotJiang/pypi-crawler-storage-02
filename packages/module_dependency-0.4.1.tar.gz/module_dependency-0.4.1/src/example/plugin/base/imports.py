import example.plugin.base.number.providers.fake
import example.plugin.base.string.providers.fake