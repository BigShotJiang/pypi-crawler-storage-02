## 16.0.1.2.0 (2023-12-11)

**Features**

- Credit notes have been added to the e-mail summary that are sent to
  the customer. They are marked in a different colour.

  Furthermore, the button toggle to allow to send a reminder with
  unreconciled payments has been removed. The warning remains.
  ([\#226](https://github.com/OCA/credit-control/issues/226))
