default_app_config = "aiwaf.apps.AiwafConfig"

__version__ = "0.1.9.0.5"

# Note: Middleware classes are available from aiwaf.middleware
# Import them only when needed to avoid circular imports during Django app loading
