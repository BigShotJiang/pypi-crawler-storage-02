__version__ = "0.1.0"

# Convenience re-export: allow importing the FastAPI app as endpoint_pulse.app.app
# (the actual app is defined in endpoint_pulse.app)
