from distutils.core import setup

setup(
    name='wk_agent_tools',
    version='0.0.0.dev1755192865153',
    py_modules=["module"],
)