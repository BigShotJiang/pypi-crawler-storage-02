## Requirements

- Python 3.8+
- Pydantic for the data parts.
- obonet for the parsing part.

## Installation

```
pip install pyimporters-obo
```
