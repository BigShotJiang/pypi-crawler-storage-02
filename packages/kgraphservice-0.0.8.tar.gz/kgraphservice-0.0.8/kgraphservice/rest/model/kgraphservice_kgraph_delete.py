from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceKGraphDelete(KGraphServiceOp):

    graph_uri: str

