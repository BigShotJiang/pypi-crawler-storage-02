from typing_extensions import TypedDict


class KGraphServiceOp(TypedDict):

    kgraphservice_class: str

