from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceInteractionStats(KGraphServiceOp):

    graph_uri: str

