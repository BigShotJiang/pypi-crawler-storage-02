
from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceKGraphGet(KGraphServiceOp):

    graph_uri: str
