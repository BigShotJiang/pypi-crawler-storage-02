
from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceFrameStats(KGraphServiceOp):

    graph_uri: str

