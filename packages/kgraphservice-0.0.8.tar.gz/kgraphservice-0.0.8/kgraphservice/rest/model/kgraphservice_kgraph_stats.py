from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceKGraphStats(KGraphServiceOp):

    graph_uri: str

