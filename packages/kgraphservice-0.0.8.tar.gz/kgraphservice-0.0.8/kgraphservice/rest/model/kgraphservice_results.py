from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceResults(KGraphServiceOp):

    results_dict: dict
