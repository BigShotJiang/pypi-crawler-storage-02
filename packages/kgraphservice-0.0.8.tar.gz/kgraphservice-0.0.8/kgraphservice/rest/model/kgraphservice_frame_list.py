from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceFrameList(KGraphServiceOp):

    graph_uri: str


