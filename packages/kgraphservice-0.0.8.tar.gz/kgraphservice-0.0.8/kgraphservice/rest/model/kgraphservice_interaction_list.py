
from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceInteractionList(KGraphServiceOp):

    graph_uri: str

