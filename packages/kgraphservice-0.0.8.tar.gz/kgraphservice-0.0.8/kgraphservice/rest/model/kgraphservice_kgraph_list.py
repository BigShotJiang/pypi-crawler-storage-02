
from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceKGraphList(KGraphServiceOp):
    pass
