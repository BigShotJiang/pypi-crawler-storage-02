
from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceKGraphPurge(KGraphServiceOp):

    graph_uri: str


