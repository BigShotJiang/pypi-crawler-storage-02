from kgraphservice.rest.model.kgraphservice_op import KGraphServiceOp


class KGraphServiceKGraphCreate(KGraphServiceOp):

    graph_uri: str

