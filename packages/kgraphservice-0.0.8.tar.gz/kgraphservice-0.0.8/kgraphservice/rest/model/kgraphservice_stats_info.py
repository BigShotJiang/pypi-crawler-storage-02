from typing_extensions import TypedDict


class KGraphServiceStatsInfo(TypedDict):
    pass


# kgraph
# frame
# interaction
