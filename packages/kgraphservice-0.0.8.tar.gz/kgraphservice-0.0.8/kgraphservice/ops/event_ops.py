
class EventOps:

    @classmethod
    def insert_event(cls):
        pass

    # handle case of inserting event in between two other events
    # add new successor edges
    # delete original successor edge



