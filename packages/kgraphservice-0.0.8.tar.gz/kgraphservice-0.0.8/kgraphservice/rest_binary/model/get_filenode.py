from typing import TypedDict


class GetFileNode(TypedDict):

    kgraphservice_binary_class: str
    account_uri: str
    file_node_uri: str

