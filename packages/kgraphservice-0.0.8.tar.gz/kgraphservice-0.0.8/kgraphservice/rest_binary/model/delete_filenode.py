from typing import TypedDict


class DeleteFileNode(TypedDict):

    kgraphservice_binary_class: str
    account_uri: str
    file_node_uri: str

