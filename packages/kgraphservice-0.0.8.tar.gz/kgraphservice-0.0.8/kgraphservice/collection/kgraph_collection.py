from vital_ai_vitalsigns.collection.graph_collection import GraphCollection


class KGraphCollection(GraphCollection):
    pass
