

class KGraphServiceUtils:
    pass


# support functions for the kgraphservice command
