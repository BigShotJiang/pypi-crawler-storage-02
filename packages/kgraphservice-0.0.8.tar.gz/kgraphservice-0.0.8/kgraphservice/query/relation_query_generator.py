

class RelationQueryGenerator:
    pass


