

class EventQueryGenerator:
    pass

