
class InteractionInfo:
    pass

