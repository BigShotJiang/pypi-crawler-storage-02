
class FrameInfo:
    pass

