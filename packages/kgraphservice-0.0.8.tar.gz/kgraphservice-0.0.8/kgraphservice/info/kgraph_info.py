
class KGraphInfo:
    pass

