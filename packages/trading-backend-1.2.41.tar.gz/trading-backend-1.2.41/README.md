# trading-backend [1.2.41](https://github.com/Drakkar-Software/trading-backend/tree/master/CHANGELOG.md)
[![PyPI](https://img.shields.io/pypi/v/trading-backend.svg)](https://pypi.python.org/pypi/trading-backend/)
[![Downloads](https://pepy.tech/badge/trading-backend/month)](https://pepy.tech/project/trading-backend)
[![Github-Action-CI](https://github.com/Drakkar-Software/trading-backend/workflows/trading-backend-CI/badge.svg)](https://github.com/Drakkar-Software/trading-backend/actions)

- Install trading-backend from pip : 

``` {.sourceCode .bash}
$ python3 -m pip install trading-backend
```
