"""
Model Sentinel GUI Module.

This module provides a web-based graphical user interface for the Model Sentinel
verification functionality using Gradio.
"""
