import json
from typing import OrderedDict
from unittest.mock import ANY, patch

import pytest

from bigquery_views_manager.view_list import ViewConfig, ViewListConfig
import bigquery_views_manager.materialize_views as materialize_views_module
from bigquery_views_manager.materialize_views import (
    MaterializeViewListResult,
    MaterializeViewResult,
    get_select_all_from_query,
    get_view_dependencies_json,
    materialize_view,
    materialize_views,
    materialize_views_if_necessary
)
from bigquery_views_manager.materialize_views_typing import DatasetViewDataTypedDict

PROJECT_1 = "project1"
SOURCE_DATASET_1 = "dataset1"
DESTINATION_DATASET_1 = "dataset2"

VIEW_1 = "view1"
VIEW_2 = "view2"

TABLE_1 = "table1"

VIEW_QUERY_1 = "SELECT * FROM `project1.dataset1.table1`"


@pytest.fixture(name="bigquery", autouse=True)
def _bigquery():
    with patch.object(materialize_views_module, "bigquery") as mock:
        yield mock


@pytest.fixture(name="QueryJobConfig")
def _query_job_config():
    with patch.object(materialize_views_module, "QueryJobConfig") as mock:
        yield mock


class TestGetSelectAllFromQuery:
    def test_should_substitute_values(self):
        assert (get_select_all_from_query(
            VIEW_1, project=PROJECT_1, dataset=SOURCE_DATASET_1)) == (
                f"SELECT * FROM `{PROJECT_1}.{SOURCE_DATASET_1}.{VIEW_1}`")


# pylint: disable=invalid-name
class TestMaterializeView:
    def test_should_call_query(self, bq_client, QueryJobConfig):
        materialize_view(
            bq_client,
            source_view_name=VIEW_1,
            destination_table_name=TABLE_1,
            project=PROJECT_1,
            source_dataset=SOURCE_DATASET_1,
            destination_dataset=DESTINATION_DATASET_1,
        )
        bq_client.query.assert_called_with(
            get_select_all_from_query(VIEW_1, project=PROJECT_1, dataset=SOURCE_DATASET_1),
            job_config=QueryJobConfig.return_value,
        )

    def test_should_set_write_disposition_on_job_config(
        self,
        bq_client,
        bigquery,
        QueryJobConfig
    ):
        materialize_view(
            bq_client,
            source_view_name=VIEW_1,
            destination_table_name=TABLE_1,
            project=PROJECT_1,
            source_dataset=SOURCE_DATASET_1,
            destination_dataset=DESTINATION_DATASET_1,
        )
        assert (QueryJobConfig.return_value.write_disposition ==
                bigquery.WriteDisposition.WRITE_TRUNCATE)

    def test_should_call_result_on_query_job(self, bq_client):
        materialize_view(
            bq_client,
            source_view_name=VIEW_1,
            destination_table_name=TABLE_1,
            project=PROJECT_1,
            source_dataset=SOURCE_DATASET_1,
            destination_dataset=DESTINATION_DATASET_1,
        )
        bq_client.query.return_value.result.assert_called()

    def test_should_return_results(self, bq_client):
        return_value = materialize_view(
            bq_client,
            source_view_name=VIEW_1,
            destination_table_name=TABLE_1,
            project=PROJECT_1,
            source_dataset=SOURCE_DATASET_1,
            destination_dataset=DESTINATION_DATASET_1,
        )
        query_job = bq_client.query.return_value
        bq_result = query_job.result.return_value
        assert return_value
        assert return_value.duration is not None
        assert return_value.total_rows == bq_result.total_rows
        assert return_value.total_bytes_processed == query_job.total_bytes_processed
        assert return_value.cache_hit == query_job.cache_hit
        assert return_value.slot_millis == query_job.slot_millis
        assert return_value.total_bytes_billed == return_value.total_bytes_billed
        assert return_value.source_dataset == SOURCE_DATASET_1
        assert return_value.source_view_name == VIEW_1
        assert return_value.destination_dataset == DESTINATION_DATASET_1
        assert return_value.destination_table_name == TABLE_1


class TestMaterializeViews:
    def test_should_return_empty_list_when_there_is_no_view_to_materialize(self, bq_client):
        return_value = materialize_views(
            client=bq_client,
            materialized_view_dict=OrderedDict[str, DatasetViewDataTypedDict](),
            source_view_dict=OrderedDict[str, DatasetViewDataTypedDict](),
            project=PROJECT_1
        )
        assert return_value == MaterializeViewListResult(result_list=[])
        assert not return_value

    def test_should_return_result(self, bq_client):
        destination_dataset_view_dict: DatasetViewDataTypedDict = {
            'dataset_name': DESTINATION_DATASET_1,
            'table_name': TABLE_1
        }
        source_dataset_view_dict: DatasetViewDataTypedDict = {
            'dataset_name': SOURCE_DATASET_1,
            'table_name': VIEW_1
        }
        materialized_view_dict = OrderedDict[str, DatasetViewDataTypedDict]({
            'view_template_file_name_1': destination_dataset_view_dict
        })
        source_view_dict = OrderedDict[str, DatasetViewDataTypedDict]({
            'view_template_file_name_1': source_dataset_view_dict
        })
        return_value = materialize_views(
            client=bq_client,
            materialized_view_dict=materialized_view_dict,
            source_view_dict=source_view_dict,
            project=PROJECT_1
        )
        assert return_value == MaterializeViewListResult(
            result_list=[MaterializeViewResult(
                source_dataset=SOURCE_DATASET_1,
                source_view_name=VIEW_1,
                destination_dataset=DESTINATION_DATASET_1,
                destination_table_name=TABLE_1,
                total_bytes_processed=ANY,
                total_rows=ANY,
                duration=ANY,
                cache_hit=ANY,
                slot_millis=ANY,
                total_bytes_billed=ANY
            )]
        )


class Test_get_view_dependencies_json:
    def test_should_format_view_dependencies_with_set_as_list(self):
        assert json.loads(get_view_dependencies_json({
            'view_1': {'table_1', 'table_2'}
        })) == {
            'view_1': ['table_1', 'table_2']
        }


class TestMaterializeViewsIfNecessary:
    def test_should_return_empty_list_when_there_is_no_views(self, bq_client):
        return_value = materialize_views_if_necessary(
            client=bq_client,
            project=PROJECT_1,
            dataset='dataset_1',
            view_list_config=ViewListConfig([])
        )
        assert return_value == MaterializeViewListResult(result_list=[])
        assert not return_value

    def test_should_return_empty_list_when_there_is_no_view_to_materialize(self, bq_client):
        return_value = materialize_views_if_necessary(
            client=bq_client,
            project=PROJECT_1,
            dataset='dataset_1',
            view_list_config=ViewListConfig([
                ViewConfig(
                    view_name=VIEW_1,
                    materialize=False
                )
            ])
        )
        assert return_value == MaterializeViewListResult(result_list=[])
        assert not return_value

    def test_should_return_result(self, bq_client):
        return_value = materialize_views_if_necessary(
            client=bq_client,
            project=PROJECT_1,
            dataset=SOURCE_DATASET_1,
            view_list_config=ViewListConfig([
                ViewConfig(
                    view_name=VIEW_1,
                    materialize_as=f'{DESTINATION_DATASET_1}.{TABLE_1}'
                )
            ])
        )
        assert return_value == MaterializeViewListResult(
            result_list=[MaterializeViewResult(
                source_dataset=SOURCE_DATASET_1,
                source_view_name=VIEW_1,
                destination_dataset=DESTINATION_DATASET_1,
                destination_table_name=TABLE_1,
                total_bytes_processed=ANY,
                total_rows=ANY,
                duration=ANY,
                cache_hit=ANY,
                slot_millis=ANY,
                total_bytes_billed=ANY
            )]
        )

    def test_should_only_materialize_selected_views(self, bq_client):
        return_value = materialize_views_if_necessary(
            client=bq_client,
            project=PROJECT_1,
            dataset='dataset_1',
            view_list_config=ViewListConfig([
                ViewConfig(
                    view_name=VIEW_1,
                    materialize=True
                ),
                ViewConfig(
                    view_name=VIEW_2,
                    materialize=True
                )
            ]),
            selected_view_names=[VIEW_1]
        )
        assert len(return_value.result_list) == 1
        assert return_value.result_list[0].source_view_name == VIEW_1
