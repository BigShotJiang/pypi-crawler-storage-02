""".. include:: ./doc.md"""  # noqa: D415

from .api import extract_features_from_audios  # noqa: F401
