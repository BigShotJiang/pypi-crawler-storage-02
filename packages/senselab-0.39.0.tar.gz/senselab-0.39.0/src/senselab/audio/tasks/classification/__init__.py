""".. include:: ./doc.md"""  # noqa: D415

from .api import classify_audios  # noqa: F401
