from bafser import UserBase


class User(UserBase):
    pass
