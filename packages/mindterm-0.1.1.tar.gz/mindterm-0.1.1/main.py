def main():
    print("Hello from mindterm!")


if __name__ == "__main__":
    main()
