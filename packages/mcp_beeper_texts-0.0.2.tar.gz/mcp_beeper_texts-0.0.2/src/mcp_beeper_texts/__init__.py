"""MCP Beeper Texts server package."""

from mcp_beeper_texts.server import main, mcp

__all__ = ["mcp", "main"]
