__version__ = "0.0.39"  # pragma: no cover
