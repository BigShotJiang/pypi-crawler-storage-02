"""Tests for application layer components."""
