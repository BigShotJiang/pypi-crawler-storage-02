from rag_colls.core.base.retrievers.base_retriever_provider import BaseRetrieverProvider


class BaseBM25RetrieverProvider(BaseRetrieverProvider): ...
