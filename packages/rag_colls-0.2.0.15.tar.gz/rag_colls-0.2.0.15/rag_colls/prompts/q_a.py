Q_A_PROMPT = """Given the following context, answer the question.
=============
Context:

{context}

=============

Question: {question}
"""
