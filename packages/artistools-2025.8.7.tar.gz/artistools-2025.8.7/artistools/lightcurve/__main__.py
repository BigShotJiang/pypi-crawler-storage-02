from artistools.lightcurve import plotlightcurve


def main() -> None:
    plotlightcurve.main()


if __name__ == "__main__":
    main()
