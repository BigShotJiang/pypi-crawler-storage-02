# xlgcid

XunLei GCID hash algorithm, inspired from https://binux.blog/2012/03/hash_algorithm_of_xunlei/.

## Usage

``` python
from xlgcid import get_file_gcid_digest

print(get_file_gcid_digest('a.txt').hex())
```
