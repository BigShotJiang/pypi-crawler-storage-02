"""Respona MCP Server - MCP server for Respona Dashboard API integration."""

__version__ = "1.0.2" 