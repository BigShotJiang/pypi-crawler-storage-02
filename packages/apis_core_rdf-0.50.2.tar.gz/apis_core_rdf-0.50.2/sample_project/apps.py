from django.apps import AppConfig


class SampleProjectConfig(AppConfig):
    name = "sample_project"
    default_auto_field = "django.db.models.BigAutoField"
