Simply open a storable matrix product, enable the option to display the product's
stock, and the stock will appear for each variant in the cart addition wizard.
