name = {"zh": "MOSS模块", "en": "MOSSModule","rawname": "moss"}
version = "0.1.0"