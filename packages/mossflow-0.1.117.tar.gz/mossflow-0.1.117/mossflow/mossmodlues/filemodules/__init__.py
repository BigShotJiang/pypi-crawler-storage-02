from . import Graphics_OpenFileModule
name = {"zh": "文件操作", "en": "FileOperation","rawname": "fileprocess"}
version = "0.1.0"