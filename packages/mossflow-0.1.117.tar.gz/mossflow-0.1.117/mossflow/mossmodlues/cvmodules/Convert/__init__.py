from . import Graphics_ConvertColorModule
name = {"zh": "转换", "en": "Convert","rawname": "Cvt"}
version = "0.1.0"