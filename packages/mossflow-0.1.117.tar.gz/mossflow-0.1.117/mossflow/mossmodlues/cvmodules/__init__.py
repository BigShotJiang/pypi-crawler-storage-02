name = {"zh": "图像处理", "en": "CV","rawname": "cv"}
version = "0.1.0"