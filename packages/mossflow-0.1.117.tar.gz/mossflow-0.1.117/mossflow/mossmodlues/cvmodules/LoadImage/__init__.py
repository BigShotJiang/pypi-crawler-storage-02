from . import Graphics_RGBImageModule,Graphics_TiffModule
name = {"zh": "加载", "en": "LoadImg","rawname": "loadimg"}
version = "0.1.0"