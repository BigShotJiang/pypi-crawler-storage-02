"""
SAGE Core Module
================

核心框架模块，提供基础的数据流和任务管理功能。
"""

# 版本信息
__version__ = "1.0.0"
__author__ = "IntelliStream Team"

# 公开的API
__all__ = [
    # 将由子模块填充
]
