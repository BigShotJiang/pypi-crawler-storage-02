"""Wyoming server for piper."""

from importlib.metadata import version

__version__ = version("wyoming_piper")

__all__ = ["__version__"]
