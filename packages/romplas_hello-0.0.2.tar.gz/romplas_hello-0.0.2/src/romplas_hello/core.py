def say_hello(): return "Hello from ROMPLAS!" 
