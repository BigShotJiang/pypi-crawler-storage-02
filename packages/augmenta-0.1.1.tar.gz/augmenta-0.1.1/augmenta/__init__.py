"""Augmenta - Web research and data augmentation package."""

from .agent import AugmentaAgent

__all__ = ['AugmentaAgent']
