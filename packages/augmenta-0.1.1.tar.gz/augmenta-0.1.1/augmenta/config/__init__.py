"""Configuration management module for Augmenta."""
from .get_credentials import CredentialsManager

__all__ = ['CredentialsManager']