class OnInit:
    async def on_startup(self):
        pass
