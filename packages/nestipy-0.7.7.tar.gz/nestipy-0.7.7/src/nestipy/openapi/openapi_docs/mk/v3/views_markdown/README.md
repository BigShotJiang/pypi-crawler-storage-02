# Views for plain Markdown

This folder contains views to generate output suitable for plain Markdown.
