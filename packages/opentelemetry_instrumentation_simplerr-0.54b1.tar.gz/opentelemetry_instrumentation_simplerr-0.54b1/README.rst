OpenTelemetry Simplerr Tracing
==============================

.. |pypi| image:: https://badge.fury.io/py/opentelemetry-instrumentation-simplerr.svg
   :target: https://pypi.org/project/opentelemetry-instrumentation-simplerr/

|pypi|

This library builds on the OpenTelemetry WSGI middleware to track web requests
in Simplerr applications.

Installation
------------

To install, run:

::

    pip install opentelemetry-instrumentation-simplerr
