_instruments = ("simplerr >= 0.18.2.dev3",)

_supports_metrics = True