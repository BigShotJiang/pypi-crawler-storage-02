# ModelBridge v0.1

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**100% Honest Documentation** - Multi-provider LLM gateway with intelligent routing and production-grade cost management. Every feature documented here actually exists and works.

## Installation

```bash
pip install modelbridge
```

## What's Actually in v0.1

### ✅ Production-Ready Cost Management
- **Real-time Cost Tracking**: Track every request with detailed breakdowns
- **Budget Management**: Set monthly, daily, and per-request budgets with alerts  
- **Smart Cost Optimization**: AI-powered model selection for cost savings
- **Analytics & Reporting**: Usage stats and cost analysis

### ✅ Intelligent Routing
- **Task Analysis**: Automatically detects task types and routes accordingly
- **Smart Model Selection**: Balances quality, speed, and cost
- **Automatic Fallback**: Seamless provider switching on failure

### ✅ Multi-Provider Support
- **OpenAI**: GPT-5, GPT-5-mini, GPT-5-nano, GPT-4.1 family, o3/o4 models
- **Anthropic**: Claude Opus 4.1, Claude 3.5 Sonnet series
- **Google**: Gemini 2.5 Pro, Flash, Flash-Lite, 1.5 series
- **Groq**: Llama 3.3, Mixtral, ultra-fast inference

## Quick Start

```python
import asyncio
from modelbridge import ModelBridge

async def main():
    # Initialize with API keys from environment variables
    bridge = ModelBridge()
    await bridge.initialize()
    
    # Set up cost management
    bridge.set_monthly_budget(50.0)  # $50 monthly budget
    bridge.enable_cost_optimization("balanced")
    
    # Generate text with intelligent routing
    response = await bridge.generate_text(
        prompt="Explain recursion",
        optimize_for="quality"  # or "speed", "cost"
    )
    
    print(response.content)
    print(f"Cost: ${response.cost:.4f} using {response.model_id}")

asyncio.run(main())
```

## Configuration

### Environment Variables

```bash
# At least one API key required
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
export GOOGLE_API_KEY="..."
export GROQ_API_KEY="gsk_..."
```

## Model Aliases (Smart Routing)

Pre-configured routing strategies that work:

```python
# Quality-first routing
response = await bridge.generate_text(prompt="...", model="best")
# Routes: gpt-5 → claude-opus-4-1 → gpt-4.1

# Speed-optimized routing  
response = await bridge.generate_text(prompt="...", model="fastest")
# Routes: mixtral-8x7b → llama-3.3-70b → gpt-5-nano

# Cost-optimized routing
response = await bridge.generate_text(prompt="...", model="cheapest")
# Routes: gpt-5-nano → llama-3.1-8b → gemini-2.5-flash-lite

# Balanced routing
response = await bridge.generate_text(prompt="...", model="balanced")
# Routes: gpt-5-mini → claude-3-5-sonnet → llama-3.3-70b
```

## Cost Management API

### Budget Management (Works)

```python
# Set budgets
bridge.set_monthly_budget(100.0)
bridge.set_daily_budget(10.0)
bridge.set_request_budget(0.01)

# Check budget status
budget_status = bridge.get_budget_status()
for budget in budget_status:
    print(f"{budget['name']}: {budget['usage_percentage']:.1f}% used")

# Enable automatic cost optimization
bridge.enable_cost_optimization("balanced")  # aggressive, balanced, conservative
```

### Usage Statistics (Works)

```python
# Get cost usage stats
stats = bridge.get_cost_usage_stats("month")
print(f"Total cost: ${stats['total_cost']:.2f}")
print(f"Average per request: ${stats['average_cost_per_request']:.4f}")
print(f"Total requests: {stats['total_requests']}")

# Get detailed cost report
report = bridge.get_cost_report("week")
print(f"Period: {report['period']}")
print(f"Total cost: ${report['total_cost']:.2f}")
for rec in report.get('recommendations', []):
    print(f"💡 {rec}")

# Get optimization recommendations
recommendations = bridge.get_optimization_recommendations()
print(f"Potential monthly savings: ${recommendations.get('potential_savings', 0):.2f}")
```

### System Status (Works)

```python
# Get comprehensive system status
status = bridge.get_system_status()
print(f"Providers: {status['providers']}")
print(f"Cost management enabled: {status.get('cost_management', {}).get('enabled', False)}")

# Health check all providers
health = await bridge.health_check()
print(f"Overall status: {health['status']}")
for provider, info in health['providers'].items():
    print(f"{provider}: {info['status']}")
```

## Structured Output (Works)

```python
schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"},
        "skills": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["name", "age"]
}

response = await bridge.generate_structured_output(
    prompt="Extract person info: John Doe, 30 years old, knows Python and JS",
    schema=schema,
    model="gpt-5"
)

import json
data = json.loads(response.content)
# {"name": "John Doe", "age": 30, "skills": ["Python", "JavaScript"]}
```

## Advanced Features That Work

### Cost-Aware Request Limits

```python
# Set maximum cost per request
response = await bridge.generate_text(
    prompt="Complex analysis task",
    max_cost=0.01,  # Will automatically downgrade to cheaper model if needed
    optimize_for="quality"
)

# Check if cost optimization was applied
if hasattr(response, 'metadata') and response.metadata:
    cost_opt = response.metadata.get('_cost_optimization', {})
    if cost_opt:
        print(f"Optimized: {cost_opt['original_model']} → {response.model_id}")
        print(f"Saved: ${cost_opt['cost_savings']:.4f}")
```

### Performance Monitoring (Works)

```python
# Get performance statistics
stats = bridge.get_performance_stats()
for model, metrics in stats.items():
    print(f"{model}:")
    print(f"  Response time: {metrics['avg_response_time']:.2f}s")
    print(f"  Success rate: {metrics['success_rate']:.2%}")
    print(f"  Average cost: ${metrics['avg_cost']:.4f}")
```

## What's NOT Included (Honest List)

❌ **Cache Integration** - Cache classes exist but not integrated with main bridge
❌ **Rate Limiting** - Rate limiter classes exist but not integrated with main bridge  
❌ **Direct Provider Breakdown** - Must access via `bridge.cost_manager.get_provider_breakdown()`
❌ **Direct Cost Trends** - Must access via `bridge.cost_manager.get_cost_trends()`
❌ **Request Deduplication** - Planned but not implemented

## Error Handling

```python
response = await bridge.generate_text(
    prompt="Your prompt",
    model="gpt-5"
)

if response.error:
    print(f"Error: {response.error}")
    # Automatic fallback already attempted
else:
    print(f"Success: {response.content}")
    print(f"Provider: {response.provider_name}")
    print(f"Cost: ${response.cost:.4f}")
```

## Testing

```bash
# Run test suite
python -m pytest tests/

# Test specific components
python -m pytest tests/test_providers.py
python -m pytest tests/test_cost_tracker.py
```

## Architecture

```
ModelBridge (Main Gateway)
├── Intelligent Router (task analysis, provider ranking)
├── Cost Manager (tracking, budgets, optimization, analytics)
├── Task Analyzer (automatic task classification)
├── Providers (OpenAI, Anthropic, Google, Groq)
└── Performance Tracking (response times, success rates)
```

## License

MIT License - see [LICENSE](LICENSE) file for details.

---

**This README documents only features that actually exist and work in v0.1.0. No feature is listed unless it has been tested and verified.**