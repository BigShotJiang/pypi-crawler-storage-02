"""Some useful generic types."""
from typing import TypeVar

__all__ = ["ReturnType"]

ReturnType = TypeVar("ReturnType")
