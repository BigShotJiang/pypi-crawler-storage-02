# Core functionality tests
