"""Invokes dynamicio cli."""
from dynamicio.cli import run

run()
