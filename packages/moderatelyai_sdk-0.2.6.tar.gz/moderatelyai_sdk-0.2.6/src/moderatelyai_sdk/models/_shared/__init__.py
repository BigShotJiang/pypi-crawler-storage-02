"""Shared business logic utilities for both sync and async models."""
