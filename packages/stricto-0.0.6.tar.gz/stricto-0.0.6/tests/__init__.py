"""
all imports
"""

from .test_dict import TestDict
from .test_bool import TestBool
from .test_error import TestError
from .test_float import TestFloat
from .test_int import TestInt
from .test_in import TestIn
from .test_string import TestString
from .test_list import TestList
from .test_tuple import TestTuple
from .test_diff import TestDiff
from .test_view import TestView
from .test_extend import TestExtend
from .test_rights import TestRights
from .test_date import TestDate
