def bar(arg):
    temp_dict = {"hamster": "herring", "ministry": "quest", "silly": "knight", "spam": "duck"}
    return temp_dict.get(arg, "parrot")
