## dequantor
install it via pip/pip3
```
pip install dequantor
```

note:
- attempt: leveraging gguf-connector's dequant engine for more gguf file type support
- code base from diffusers (huggingface)