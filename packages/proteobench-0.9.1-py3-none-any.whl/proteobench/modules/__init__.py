"""
This subpackage contains the proteobench benchmarking modules organized by
type of benchmarking type.
"""
