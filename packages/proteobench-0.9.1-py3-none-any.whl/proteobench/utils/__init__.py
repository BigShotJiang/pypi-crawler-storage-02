"""
Utils module for ProteoBench.
"""
