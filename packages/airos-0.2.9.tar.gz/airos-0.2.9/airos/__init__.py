"""Ubiquity AirOS python module."""
