__title__ = 'XMind2Jira'
__description__ = 'XMind2Jira 基于Python实现， Xmind 文件转jira 用例'
__keywords__ = 'xmind2jira, testcase, xmind, 思维导图, XMind思维导图',
__url__ = 'https://github.com/Allenzzz/x2case'
__author__ = 'Zeno'
__author_email__ = 'z_ok@me.com'
__version__ = '1.1.0'
__license__ = 'MIT'
