from .chompjs import parse_js_object, parse_js_objects

__all__ = ["parse_js_object", "parse_js_objects"]