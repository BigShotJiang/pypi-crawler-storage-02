
from setuptools import setup

setup(package_data={'bleach-stubs': ['__init__.pyi', 'callbacks.pyi', 'css_sanitizer.pyi', 'html5lib_shim.pyi', 'linkifier.pyi', 'parse_shim.pyi', 'sanitizer.pyi', 'METADATA.toml', 'py.typed']})
