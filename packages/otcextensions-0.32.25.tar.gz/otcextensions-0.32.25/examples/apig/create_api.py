#!/usr/bin/env python3
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
"""
Create API
"""
import openstack

openstack.enable_logging(True)
conn = openstack.connect(cloud='otc')
attrs = {
    "group_id": "group_id",
    "name": "test_api_001",
    "auth_type": "IAM",
    "backend_type": "HTTP",
    "req_protocol": "HTTP",
    "req_uri": "/test/http",
    "remark": "Mock backend API",
    "type": 2,
    "req_method": "GET",
    "result_normal_sample": "Example success response",
    "result_failure_sample": "Example failure response",
    "tags": ["httpApi"],
    "backend_api": {
        "req_protocol": "HTTP",
        "req_method": "GET",
        "req_uri": "/test/benchmark",
        "timeout": 5000,
        "retry_count": "-1",
        "url_domain": "192.168.189.156:12346"
    },
}
created = conn.apig.create_api(
    gateway="gateway_id",
    **attrs
)
