otcextensions.sdk.dcs.v1.instance
=================================

.. automodule:: otcextensions.sdk.dms.v1.instance

The DMS Instance Class
----------------------

The ``Instance`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dms.v1.instance.Instance
   :members:
