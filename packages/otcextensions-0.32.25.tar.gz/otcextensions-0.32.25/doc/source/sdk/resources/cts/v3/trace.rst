otcextensions.sdk.ctsv3.v3.trace
================================

.. automodule:: otcextensions.sdk.ctsv3.v3.trace

The CTS Trace Class
-----------------------

The ``Trace`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ctsv3.v3.trace.Trace
   :members:
