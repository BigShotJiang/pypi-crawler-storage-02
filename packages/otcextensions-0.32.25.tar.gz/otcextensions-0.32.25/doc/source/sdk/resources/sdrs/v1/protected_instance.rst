otcextensions.sdk.sdrs.v1.protected_instance.ProtectedInstance
==============================================================

.. automodule:: otcextensions.sdk.sdrs.v1.protected_instance

The SDRS Protected instance Class
---------------------------------

The ``ProtectedInstance`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.protected_instance.ProtectedInstance
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.protected_instance.Attachment
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.protected_instance.Metadata
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.protected_instance.TagSpec
   :members:
