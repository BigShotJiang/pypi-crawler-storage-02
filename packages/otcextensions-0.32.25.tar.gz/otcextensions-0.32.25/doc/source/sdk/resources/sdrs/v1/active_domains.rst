otcextensions.sdk.sdrs.v1.active_domains.ActiveDomains
======================================================

.. automodule:: otcextensions.sdk.sdrs.v1.active_domains

The SDRS Active-active domain Class
-----------------------------------

The ``ActiveDomains`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.active_domains.ActiveDomains
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.active_domains.Domains
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.active_domains.ReplicationCluster
   :members:
