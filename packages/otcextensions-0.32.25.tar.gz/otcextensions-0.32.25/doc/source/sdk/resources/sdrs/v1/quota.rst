otcextensions.sdk.sdrs.v1.quota.Quota
=====================================

.. automodule:: otcextensions.sdk.sdrs.v1.quota

The SDRS Quota Class
--------------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.quota.Quota
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.quota.ResourceType
   :members:
