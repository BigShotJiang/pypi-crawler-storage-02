otcextensions.sdk.sdrs.v1.job.Job
=================================

.. automodule:: otcextensions.sdk.sdrs.v1.job

The SDRS Job Class
------------------

The ``Job`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.job.Job
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.job.SubJob
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.job.EntitySpec
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.job.EntitySpecSub
   :members:
