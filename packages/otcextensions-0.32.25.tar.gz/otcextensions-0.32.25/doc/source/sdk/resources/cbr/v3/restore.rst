otcextensions.sdk.cbr.v3.restore
================================

.. automodule:: otcextensions.sdk.cbr.v3.restore

The CBR Restore Class
---------------------

The ``Restore`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cbr.v3.restore.Restore
   :members:

.. autoclass:: otcextensions.sdk.cbr.v3.restore.Mapping
   :members:
