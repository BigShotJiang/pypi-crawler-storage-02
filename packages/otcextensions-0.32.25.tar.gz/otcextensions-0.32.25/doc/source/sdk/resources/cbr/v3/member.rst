otcextensions.sdk.cbr.v3.member
===============================

.. automodule:: otcextensions.sdk.cbr.v3.member

The CBR Memnber Class
---------------------

The ``Member`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cbr.v3.member.Member
   :members:
