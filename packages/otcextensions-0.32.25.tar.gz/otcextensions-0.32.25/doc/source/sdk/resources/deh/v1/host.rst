otcextensions.sdk.deh.v1.host
=============================

.. automodule:: otcextensions.sdk.deh.v1.host

The DeH Host Class
------------------

The ``Host`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.deh.v1.host.Host
   :members:
