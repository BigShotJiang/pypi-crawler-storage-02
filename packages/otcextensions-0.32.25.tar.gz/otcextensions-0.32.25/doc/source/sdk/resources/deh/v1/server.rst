otcextensions.sdk.deh.v1.server
===============================

.. automodule:: otcextensions.sdk.deh.v1.server

The DeH Server Class
--------------------

The ``Server`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.deh.v1.server.Server
   :members:
