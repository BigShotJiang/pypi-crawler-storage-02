otcextensions.sdk.vpc.v1.peering
================================

.. automodule:: otcextensions.sdk.vpc.v1.peering

The VPC Peering Class
----------------------

The ``Peering`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpc.v1.peering.Peering
   :members:
