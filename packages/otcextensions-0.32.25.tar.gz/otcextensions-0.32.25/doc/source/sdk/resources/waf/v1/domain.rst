otcextensions.sdk.waf.v1.domain
===============================

.. automodule:: otcextensions.sdk.waf.v1.domain

The WAF Domain Class
--------------------

The ``Domain`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.waf.v1.domain.Domain
   :members:
