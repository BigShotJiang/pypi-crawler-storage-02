otcextensions.sdk.waf.v1.certificate
====================================

.. automodule:: otcextensions.sdk.waf.v1.certificate

The WAF Certificate Class
-------------------------

The ``Certificate`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.waf.v1.certificate.Certificate
   :members:
