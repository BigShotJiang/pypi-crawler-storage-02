otcextensions.sdk.dcs.v1.service_specification
==============================================

.. automodule:: otcextensions.sdk.dcs.v1.service_specification

The DCS Service Specification Class
-----------------------------------

The ``ServiceSpecification`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.service_specification.ServiceSpecification
   :members:
