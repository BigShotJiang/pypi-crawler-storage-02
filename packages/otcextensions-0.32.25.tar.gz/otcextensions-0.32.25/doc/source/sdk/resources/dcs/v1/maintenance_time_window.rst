otcextensions.sdk.dcs.v1.maintenance_time_window
================================================

.. automodule:: otcextensions.sdk.dcs.v1.maintenance_time_window

The DCS Maintenance Time Window Class
-------------------------------------

The ``MaintenanceTimeWindow`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.maintenance_time_window.MaintenanceTimeWindow
   :members:
