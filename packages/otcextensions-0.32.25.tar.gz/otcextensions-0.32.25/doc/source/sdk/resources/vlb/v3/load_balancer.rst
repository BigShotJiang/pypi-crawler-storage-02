otcextensions.sdk.vlb.v3.load_balancer
======================================

.. automodule:: otcextensions.sdk.vlb.v3.load_balancer

The LoadBalancer Class
-----------------------

The ``LoadBalancer`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.load_balancer.LoadBalancer
   :members:
