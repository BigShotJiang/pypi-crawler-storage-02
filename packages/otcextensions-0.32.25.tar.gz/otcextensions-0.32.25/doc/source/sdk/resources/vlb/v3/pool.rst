otcextensions.sdk.vlb.v3.pool
=================================

.. automodule:: otcextensions.sdk.vlb.v3.pool

The Pool Class
------------------

The ``Pool`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.pool.Pool
   :members:
