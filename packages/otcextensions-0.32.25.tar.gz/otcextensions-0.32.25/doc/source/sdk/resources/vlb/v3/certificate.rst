otcextensions.sdk.vlb.v3.certificate
====================================

.. automodule:: otcextensions.sdk.vlb.v3.certificate

The Certificate Class
---------------------

The ``Certificate`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.certificate.Certificate
   :members:
