otcextensions.sdk.kms.v1.key
============================

.. automodule:: otcextensions.sdk.kms.v1.key

The KMS CMK Class
-----------------

The ``Key`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.kms.v1.key.Key
   :members:
