otcextensions.sdk.dns.v2.recordset
==================================

.. automodule:: otcextensions.sdk.dns.v2.recordset

The DNS Recordset Class
-----------------------

The ``recordset`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dns.v2.recordset.Recordset
   :members:
