openstack.identity.v3.endpoint
==============================

.. automodule:: openstack.identity.v3.endpoint

The Endpoint Class
------------------

The ``Endpoint`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.endpoint.Endpoint
   :members:
