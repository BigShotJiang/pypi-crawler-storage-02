otcextensions.sdk.identity.v3.agency_role
=========================================

.. automodule:: otcextensions.sdk.identity.v3.agency_role

The AgencyRole Class
--------------------

The ``AgencyRole`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: otcextensions.sdk.identity.v3.agency_role.AgencyRole
   :members:
