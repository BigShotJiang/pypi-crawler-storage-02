SWR Resources
=============

SWR v2
^^^^^^

.. toctree::
   :maxdepth: 1

   v2/organization
   v2/repository
   v2/domain
