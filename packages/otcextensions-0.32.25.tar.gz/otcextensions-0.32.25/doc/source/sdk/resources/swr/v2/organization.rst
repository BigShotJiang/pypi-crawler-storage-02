otcextensions.sdk.swr.v2.organization
=====================================

.. automodule:: otcextensions.sdk.swr.v2.organization

The Organization Class
----------------------

The ``Organization`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.swr.v2.organization.Organization
   :members:

The Organization Permission Class
---------------------------------

The ``Permission`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.swr.v2.organization.Permission
   :members:
