otcextensions.sdk.apig.v2.throttling_policy
===========================================

.. automodule:: otcextensions.sdk.apig.v2.throttling_policy

The ThrottlingPolicy Class
--------------------------

The ``ThrottlingPolicy`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.throttling_policy.ThrottlingPolicy
   :members:
