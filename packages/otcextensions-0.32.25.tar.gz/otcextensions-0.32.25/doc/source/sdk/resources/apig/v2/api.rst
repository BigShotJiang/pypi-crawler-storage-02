otcextensions.sdk.apig.v2.api
========================================

.. automodule:: otcextensions.sdk.apig.v2.api

The Api Class
------------------------

The ``Api`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api.Api
   :members:
