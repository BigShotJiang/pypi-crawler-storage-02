otcextensions.sdk.apig.v2.custom_authorizer
===========================================

.. automodule:: otcextensions.sdk.apig.v2.custom_authorizer

The IdentitySpec Class
----------------------

The ``IdentitySpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.custom_authorizer.IdentitySpec
   :members:

The CustomAuthorizer Class
--------------------------

The ``CustomAuthorizer`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.custom_authorizer.CustomAuthorizer
   :members:
