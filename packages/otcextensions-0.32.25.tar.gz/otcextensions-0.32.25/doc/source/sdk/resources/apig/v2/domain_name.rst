otcextensions.sdk.apig.v2.domain_name
=====================================

.. automodule:: otcextensions.sdk.apig.v2.domain_name

The DomainName Class
--------------------

The ``DomainName`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.domain_name.DomainName
   :members:

The Certificate Class
---------------------

The ``Certificate`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.domain_name.Certificate
   :members:

The DomainDebug Class
---------------------

The ``DomainDebug`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.domain_name.DomainDebug
   :members:
