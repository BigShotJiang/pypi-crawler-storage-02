otcextensions.sdk.apig.v2.acl_api_binding
=========================================

.. automodule:: otcextensions.sdk.apig.v2.acl_api_binding

The AclApiBinding Class
-----------------------

The ``AclApiBinding`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.acl_api_binding.AclApiBinding
   :members:


The AclBindingFailure Class
---------------------------

The ``AclBindingFailure`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.acl_api_binding.AclBindingFailure
   :members:


The ApiForAcl Class
-------------------

The ``ApiForAcl`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.acl_api_binding.ApiForAcl
   :members:


The UnbindApiForAcl Class
-------------------------

The ``UnbindApiForAcl`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.acl_api_binding.UnbindApiForAcl
   :members:


The AclForApi Class
-------------------

The ``AclForApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.acl_api_binding.AclForApi
   :members:
