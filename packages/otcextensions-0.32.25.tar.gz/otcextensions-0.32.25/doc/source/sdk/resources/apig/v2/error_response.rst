otcextensions.sdk.apig.v2.error_response
========================================

.. automodule:: otcextensions.sdk.apig.v2.error_response

The ErrorResponse Class
-----------------------

The ``ErrorResponse`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.error_response.ErrorResponse
   :members:
