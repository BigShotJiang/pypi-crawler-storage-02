otcextensions.sdk.auto_scaling.v1.group
=======================================

.. automodule:: otcextensions.sdk.auto_scaling.v1.group

The AS Group Class
------------------

The ``Group`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.auto_scaling.v1.group.Group
   :members:
