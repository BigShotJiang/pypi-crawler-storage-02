otcextensions.sdk.auto_scaling.v1.quota
=======================================

.. automodule:: otcextensions.sdk.auto_scaling.v1.quota

The AS Quota Class
---------------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.auto_scaling.v1.quota.Quota
   :members:

The AS Scaling Quota Class
--------------------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.auto_scaling.v1.quota.Quota`.

.. autoclass:: otcextensions.sdk.auto_scaling.v1.quota.ScalingQuota
  :members:
