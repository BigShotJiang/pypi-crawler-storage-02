otcextensions.sdk.auto_scaling.v1.activity
==========================================

.. automodule:: otcextensions.sdk.auto_scaling.v1.activity

The AS Activity Class
---------------------

The ``Activity`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.auto_scaling.v1.activity.Activity
   :members:
