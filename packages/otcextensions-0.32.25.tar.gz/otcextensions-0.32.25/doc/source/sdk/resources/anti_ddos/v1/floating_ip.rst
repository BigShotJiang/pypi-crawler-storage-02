otcextensions.sdk.anti_ddos.v1.floating_ip
==========================================

.. automodule:: otcextensions.sdk.anti_ddos.v1.floating_ip

The Anti_DDoS FloatingIP Class
------------------------------

The ``FloatingIP`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.anti_ddos.v1.floating_ip.FloatingIP
   :members:
