otcextensions.sdk.tms.v1.predefined_tag
=======================================

.. automodule:: otcextensions.sdk.tms.v1.predefined_tag

The Predefined Tag Class
------------------------

The ``PredefinedTag`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.tms.v1.predefined_tag.PredefinedTag
   :members:
