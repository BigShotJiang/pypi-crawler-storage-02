otcextensions.sdk.nat.v2.gateway
================================

.. automodule:: otcextensions.sdk.nat.v2.gateway

The NAT Gateway Class
----------------------

The ``Gateway`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.nat.v2.gateway.Gateway
   :members:
