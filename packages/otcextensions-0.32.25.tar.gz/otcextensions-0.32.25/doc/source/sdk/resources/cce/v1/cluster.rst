otcextensions.sdk.cce.v1.cluster
================================

.. automodule:: otcextensions.sdk.cce.v1.cluster

The CCE Cluster Class
---------------------

The ``Cluster`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cce.v1.cluster.Cluster
   :members:
