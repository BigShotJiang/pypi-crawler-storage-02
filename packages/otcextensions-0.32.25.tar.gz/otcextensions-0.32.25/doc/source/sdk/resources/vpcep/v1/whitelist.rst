otcextensions.sdk.vpecp.v1.whitelist
====================================

.. automodule:: otcextensions.sdk.vpcep.v1.whitelist

The VPCEP Whitelist Class
-------------------------

The ``Whitelist`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpcep.v1.whitelist.Whitelist
   :members:
