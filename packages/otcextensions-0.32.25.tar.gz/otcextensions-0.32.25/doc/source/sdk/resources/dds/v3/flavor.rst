otcextensions.sdk.dds.v3.flavor
===================================

.. automodule:: otcextensions.sdk.dds.v3.flavor

The Flavor Class
-------------------

The ``Flavor`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dds.v3.flavor.Flavor
   :members:
