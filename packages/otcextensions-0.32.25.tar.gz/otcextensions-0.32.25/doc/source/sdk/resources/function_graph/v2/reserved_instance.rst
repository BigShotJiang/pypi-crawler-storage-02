otcextensions.sdk.function_graph.v2.reserved_instance
=====================================================

.. automodule:: otcextensions.sdk.function_graph.v2.reserved_instance

The ReservedInstance Class
--------------------------

The ``ReservedInstance`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.reserved_instance.ReservedInstance
   :members:
