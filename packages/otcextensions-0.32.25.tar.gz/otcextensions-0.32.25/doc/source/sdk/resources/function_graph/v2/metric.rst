otcextensions.sdk.function_graph.v2.metric
==========================================

.. automodule:: otcextensions.sdk.function_graph.v2.metric

The Metric Class
----------------

The ``Metric`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.metric.Metric
   :members:
