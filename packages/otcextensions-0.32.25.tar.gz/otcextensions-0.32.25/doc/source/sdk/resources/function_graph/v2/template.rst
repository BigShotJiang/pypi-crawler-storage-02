otcextensions.sdk.function_graph.v2.template
============================================

.. automodule:: otcextensions.sdk.function_graph.v2.template

The Template Class
------------------

The ``Template`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.template.Template
   :members:
