otcextensions.sdk.function_graph.v2.trigger
===========================================

.. automodule:: otcextensions.sdk.function_graph.v2.trigger

The Trigger Class
-----------------

The ``Trigger`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.trigger.Trigger
   :members:
