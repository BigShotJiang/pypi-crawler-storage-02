otcextensions.sdk.modelartsv2.v2.dataset
========================================

.. automodule:: otcextensions.sdk.modelartsv2.v2.dataset

The ModelArts Dataset Class
---------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv2.v2.dataset.Dataset
   :members:
