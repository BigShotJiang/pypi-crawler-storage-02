otcextensions.sdk.modelartsv1.v1.training_job
=============================================

.. automodule:: otcextensions.sdk.modelartsv1.v1.training_job

The AS Configuration Class
--------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv1.v1.training_job.TrainingJob
   :members:
