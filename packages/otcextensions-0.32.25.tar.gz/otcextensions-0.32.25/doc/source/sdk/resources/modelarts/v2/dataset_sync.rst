otcextensions.sdk.modelartsv2.v2.dataset_sync
=============================================

.. automodule:: otcextensions.sdk.modelartsv2.v2.dataset_sync

The ModelArts DatasetSync Class
-------------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv2.v2.dataset_sync.DatasetSync
   :members:
