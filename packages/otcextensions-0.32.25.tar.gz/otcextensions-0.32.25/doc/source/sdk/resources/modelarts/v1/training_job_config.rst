otcextensions.sdk.modelartsv1.v1.training_job_config
====================================================

.. automodule:: otcextensions.sdk.modelartsv1.v1.training_job_config

The AS Configuration Class
--------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv1.v1.training_job_config.TrainingJobConfig
   :members:
