otcextensions.sdk.modelartsv1.v1.service
========================================

.. automodule:: otcextensions.sdk.modelartsv1.v1.service

The ModelArts Service Class
---------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv1.v1.service.Service
   :members:
