otcextensions.sdk.smn.v2.message
================================

.. automodule:: otcextensions.sdk.smn.v2.message

The SMN Message Class
---------------------

The ``Message`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.smn.v2.message.Message
   :members:
