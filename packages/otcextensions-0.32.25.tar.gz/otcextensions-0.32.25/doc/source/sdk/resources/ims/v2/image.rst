otcextensions.sdk.imsv2.v2.image
=====================================

.. automodule:: otcextensions.sdk.imsv2.v2.image

The Image Class
---------------

The ``Image`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.imsv2.v2.image.Image
   :members:
