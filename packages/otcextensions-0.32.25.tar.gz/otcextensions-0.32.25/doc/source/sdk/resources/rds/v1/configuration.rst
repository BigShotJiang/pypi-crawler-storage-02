otcextensions.sdk.rds.v1.configuration
======================================

.. automodule:: otcextensions.sdk.rds.v1.configuration

The Configuration Class
-----------------------

The ``Configuration`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.rds.v1.configuration.ConfigurationGroup
   :members:
