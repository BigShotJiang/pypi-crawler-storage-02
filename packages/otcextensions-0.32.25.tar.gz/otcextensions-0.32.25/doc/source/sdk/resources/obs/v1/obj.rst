otcextensions.sdk.obs.v1.obj
============================

.. automodule:: otcextensions.sdk.obs.v1.obj

The OBS Object Class
--------------------

The ``Object`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.obs.v1.obj.Object
   :members:
