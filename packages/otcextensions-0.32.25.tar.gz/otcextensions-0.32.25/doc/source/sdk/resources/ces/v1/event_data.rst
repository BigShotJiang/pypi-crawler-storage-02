otcextensions.sdk.ces.v1.event_data
===================================

.. automodule:: otcextensions.sdk.ces.v1.event_data

The CES Event Data Class
------------------------

The ``Event Data`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ces.v1.event_data.EventData
   :members:
