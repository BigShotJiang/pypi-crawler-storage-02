otcextensions.sdk.ces.v1.quota
==============================

.. automodule:: otcextensions.sdk.ces.v1.quota

The CES Quota Class
-------------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ces.v1.quota.Quota
   :members:
