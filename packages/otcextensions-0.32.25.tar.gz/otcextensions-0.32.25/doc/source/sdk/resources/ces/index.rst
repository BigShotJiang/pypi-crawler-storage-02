CES Resources
=============

.. toctree::
   :maxdepth: 1

   v1/alarm
   v1/event_data
   v1/metric
   v1/metric_data
   v1/quota
