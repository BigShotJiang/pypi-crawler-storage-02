otcextensions.sdk.lts.v2.group
==============================

.. automodule:: otcextensions.sdk.lts.v2.group

The LTS Group Class
--------------------

The ``Group`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.lts.v2.group.Group
   :members:
