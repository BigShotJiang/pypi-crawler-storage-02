
from setuptools import setup

setup(package_data={'toposort-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
