## [0.0.1](https://github.com/ervan0707/thira/compare/v0.0.0...v0.0.1) (2025-06-25)


### Bug Fixes

* rename athira npm package to thira ([8ec3795](https://github.com/ervan0707/thira/commit/8ec379524a72b0645f914a8fcd8373f582a8b5e2))
