# Inquiry Summary

::: openaivec.task.customer_support.inquiry_summary