def main_script_test_direct_in_direct_out_env_spec(p1, env_spec):

    # process
    p2 = p1 + 100

    # return outputs
    return {"p2": env_spec}
