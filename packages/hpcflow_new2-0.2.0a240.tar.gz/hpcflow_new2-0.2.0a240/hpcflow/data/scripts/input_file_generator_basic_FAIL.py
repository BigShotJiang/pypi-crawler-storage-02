def input_file_generator_basic_FAIL(path, p1):
    # silently fail to generate the input file!
    pass
