def main_script_test_direct_in(p1):
    # process
    print(p1 + 100)
