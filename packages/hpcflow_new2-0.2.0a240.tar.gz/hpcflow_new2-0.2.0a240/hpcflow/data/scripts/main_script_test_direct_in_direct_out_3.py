def main_script_test_direct_in_direct_out_3(p3):
    # process
    p4 = p3 + 100

    # return outputs
    return {"p4": p4}
