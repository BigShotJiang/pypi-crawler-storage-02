"""
Jia Encryption Framework Version
"""

__version__ = "1.0.1"
__author__ = "夏云龙"
__email__ = "xiayunlong@example.com"
__description__ = "轻量级加密解密框架，提供RSA-AES混合加密功能"
__url__ = "https://github.com/xiayunlong/jia-encryption"
__license__ = "MIT" 