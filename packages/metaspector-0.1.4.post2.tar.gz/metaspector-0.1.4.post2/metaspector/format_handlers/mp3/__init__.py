# metaspector/format_handlers/mp3/__init__.py
# !/usr/bin/env python3
