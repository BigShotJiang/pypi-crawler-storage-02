#Change the value of NUMBER_OF_PROCESSES to obtain faster tagging process!
NUMBER_OF_PROCESSES = 2

THRESHOLD = (3, 2)