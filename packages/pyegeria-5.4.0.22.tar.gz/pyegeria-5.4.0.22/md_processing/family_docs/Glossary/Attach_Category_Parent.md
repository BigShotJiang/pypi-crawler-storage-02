# **Attach Category Parent**
>	Attaches a parent category to a child category.

## **Category Name**
>	**Input Required**: True

>	**Description**: The name of a category.

>	**Alternative Labels**: Glossary Category Name; Glossary Category; Category; Display Name


## **Parent Category**
>	**Input Required**: True

>	**Description**: The name of the parent category to attach to.

>	**Alternative Labels**: Parent Category Name;  Parent Category Names

