Prompts API
===========

.. automodule:: agentle.prompts
   :members:
   :undoc-members:
   :show-inheritance: 