#Copyright @ISmartCoder
#Updates Channel t.me/TheSmartDev

from .faker import Faker