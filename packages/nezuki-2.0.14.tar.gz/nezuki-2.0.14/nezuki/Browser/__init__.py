__version__ = "1.0.0"

from .Browser import Browser

__all__ = ['Browser']
