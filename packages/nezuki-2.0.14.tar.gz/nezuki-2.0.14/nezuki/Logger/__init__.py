__version__ = "2.0.0"

from .Logger import configure_nezuki_logger, get_nezuki_logger

__all__ = ['configure_nezuki_logger', 'get_nezuki_logger']
