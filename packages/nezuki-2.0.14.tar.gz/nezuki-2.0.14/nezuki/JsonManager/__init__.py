__version__ = "2.0.0"

from .JsonManager import JsonManager

__all__ = ['JsonManager']
