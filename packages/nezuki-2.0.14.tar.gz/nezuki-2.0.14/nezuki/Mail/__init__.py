__version__ = "2.0.0"

from .Mail import Mail

__all__ = ['Mail']
