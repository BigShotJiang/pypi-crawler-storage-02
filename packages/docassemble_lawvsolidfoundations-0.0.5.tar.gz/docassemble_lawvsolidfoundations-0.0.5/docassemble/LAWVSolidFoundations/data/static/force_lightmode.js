$( document ).ready(function() {
  document.documentElement.setAttribute('data-bs-theme', 'light');
});