"""
hq - HTML Query Tool
A tool to parse and extract data from HTML
"""

__version__ = "0.1.1"
