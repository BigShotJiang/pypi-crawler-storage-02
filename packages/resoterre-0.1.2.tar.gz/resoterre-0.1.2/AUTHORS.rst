=======
Credits
=======

Development Lead
----------------

* Blaise Gauvin St-Denis <gauvin-st-denis.blaise@ouranos.ca> `@bstdenis <https://github.com/bstdenis>`_

Co-Developers
-------------

None yet. Why not be the first?

Contributors
------------

* Trevor James Smith <smith.trevorj@ouranos.ca> `@Zeitsperre <https://github.com/Zeitsperre>`_
