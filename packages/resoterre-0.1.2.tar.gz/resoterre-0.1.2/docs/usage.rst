=====
Usage
=====

To use resoterre in a project:

.. code-block:: python

    import resoterre
