<!-- Thanks for taking the time to fill out this bug report! -->

### Description
<!-- Also tell us what you expected to happen? -->

#### Command
<!-- The command you executed, ensure to redact sensitive information -->

##### gitlabcis Version
<!-- What version of gitlabcis are you running? -->

##### GitLab Server Version
<!-- What version of GitLab server are you running? -->

##### Logs / Screenshots
<!-- Attach any relevant logs or screenshots -->

/labels ~"bug" ~"priority::4"
cc: @nmcd
