# Examples for bot-vision-suite package
