class JWTValidationError(Exception):
    """Raised when JWT validation fails."""
    pass
