THEMES = {
            "romance": [
                    "🍆💦🌹➡️🥀 Forbidden love happened.",
                    "🦐🍤🍽️🫄 Your code thought it cooked but I ate it and got indigestion so no romance here."
                    "🦶🦶🦶🦶 mmmm i'll forgive you for shitty code if you let me taste ur feetsies tootsie yum yum"
            ],
            "sad": [
                    "🪦😢☔️🖤 RIP code, your creator is too retarded to make it work",
                    "😭💔⛄️💧 In the coldest of winter, a snowman would melt looking at the dumpster fire that is your code."
                    "👉👈🥺😪 oh no pookie bear your code has an error or dear awww"
                    ],
            "danger": [
                "☢️🔥💥💀 This code is a biohazard to my sanity.",
                "💣🛠️🤡⚡ Explosive clown engineering detected, don't hit run again or this code will probably explode.",
                "⚡💻💀🧨 Voltage spike! Your code has died... again."
            ],
            "brainrot": [
                "6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀6️⃣7️⃣💀",
                "‼️fuck you ur code SUCKS UR CODE SUCKS fuck you fuck you bitch ass loser hoe god damn"
                "🌳TRALALLELO TRALALAL BRR BRR PATAPIM ITALIAN BRAINROT SHALL NEVER DIE UNTIL YOUR STUPID ASS CODE"
                "🧎‍♂️huh what code huuuuhhhhhhhhhhhhhhhh jesus christ huhhhhh"
            ]
            
            }

# not part of v0.2.10