\# Click on the QR button upper right in the navbar or access to it with
Alt + Shift + Q \# A Pop up will be opened. You can scan a QR / barcode
\# If the QR / barcode is found, you will be redirected to the record
view
