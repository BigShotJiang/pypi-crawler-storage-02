agentle.agents.a2a.message\_parts
=================================

.. automodule:: agentle.agents.a2a.message_parts

   
   .. rubric:: Classes

   .. autosummary::
   
      DataPart
      FilePart
      TextPart
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   adapters
   data_part
   file_part
   text_part
