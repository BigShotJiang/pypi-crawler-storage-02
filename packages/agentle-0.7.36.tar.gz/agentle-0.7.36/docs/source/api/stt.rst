Speech-to-Text API
=================

.. autosummary::
   :toctree: generated
   
   agentle.stt