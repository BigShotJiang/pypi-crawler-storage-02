# Changelog

## 0.2.0 (2025-08-12)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/bennorris123/python-sdk-test/compare/v0.1.0...v0.2.0)

### Features

* **api:** update via SDK Studio ([da723e2](https://github.com/bennorris123/python-sdk-test/commit/da723e2f362cbf2ba2e321df16a4b189bf235d0e))

## 0.1.0 (2025-08-12)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/bennorris123/python-sdk-test/compare/v0.0.1...v0.1.0)

### Features

* **api:** update via SDK Studio ([2d90884](https://github.com/bennorris123/python-sdk-test/commit/2d90884dd6751d45bb10b1869713e2e83b8f92bc))


### Chores

* **internal:** codegen related update ([c26a48b](https://github.com/bennorris123/python-sdk-test/commit/c26a48b09684be99a1c493fa8270c3680657f658))
* update SDK settings ([b431d67](https://github.com/bennorris123/python-sdk-test/commit/b431d67e5c264a8a7759648f09ee74dc6e328545))
* update SDK settings ([ebc487a](https://github.com/bennorris123/python-sdk-test/commit/ebc487a8ca316b0ea25866fe08489b6507f574d1))
