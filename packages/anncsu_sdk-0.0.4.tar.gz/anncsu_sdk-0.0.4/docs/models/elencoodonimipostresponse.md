# ElencoOdonimiPostResponse

Successful operation


## Fields

| Field                                                                    | Type                                                                     | Required                                                                 | Description                                                              | Example                                                                  |
| ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ |
| `res`                                                                    | *Optional[str]*                                                          | :heavy_minus_sign:                                                       | N/A                                                                      | elencoodonimi                                                            |
| `data`                                                                   | List[[models.ElencoOdonimiPostData](../models/elencoodonimipostdata.md)] | :heavy_minus_sign:                                                       | N/A                                                                      |                                                                          |