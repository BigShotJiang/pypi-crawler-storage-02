# PrognazareaGetQueryParamRequest


## Fields

| Field                              | Type                               | Required                           | Description                        | Example                            |
| ---------------------------------- | ---------------------------------- | ---------------------------------- | ---------------------------------- | ---------------------------------- |
| `prognaz`                          | *str*                              | :heavy_check_mark:                 | Progressivo nazionale dell'odonimo | 919572                             |