# PrognazaccGetPathParamRequest


## Fields

| Field                              | Type                               | Required                           | Description                        | Example                            |
| ---------------------------------- | ---------------------------------- | ---------------------------------- | ---------------------------------- | ---------------------------------- |
| `prognazacc`                       | *str*                              | :heavy_check_mark:                 | Progressivo nazionale dell'accesso | 6744962                            |