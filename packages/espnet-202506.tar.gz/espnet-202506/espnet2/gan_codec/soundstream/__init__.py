from espnet2.gan_codec.soundstream.soundstream import SoundStream  # noqa
