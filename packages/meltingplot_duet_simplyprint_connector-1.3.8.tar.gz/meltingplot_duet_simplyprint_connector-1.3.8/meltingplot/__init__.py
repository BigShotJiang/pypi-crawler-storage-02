"""Namespace package for meltingplot."""
