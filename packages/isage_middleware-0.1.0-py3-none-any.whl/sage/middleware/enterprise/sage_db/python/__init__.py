"""
Python interface for sage_db extension.
"""

from .sage_db import SageDB

__all__ = ['SageDB']
