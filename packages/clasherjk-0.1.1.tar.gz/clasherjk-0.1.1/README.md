# clasherjk

A simple Python wrapper for Clash of Clans API using JK's public proxy — **no API token needed**.

## Install
```bash
pip install clasherjk