
<additional_instructions>
{additional_instructions}
</additional_instructions> 

<title>
{title}
</title>

<document_summary>
{document_summary}
</document_summary>

<text_chunks>
{chunks}
</text_chunks>
