This module will import all the Dutch banks with their name and BIC code
to ease the input of bank accounts. The module contains the newest bank
data (23.07.2020) Data Source:
<https://www.betaalvereniging.nl/betalingsverkeer/giraal-betalingsverkeer/bic-sepa-transacties/>
