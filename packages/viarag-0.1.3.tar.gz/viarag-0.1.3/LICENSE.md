GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007

Copyright (C) 2025 ViaVeri Technologies Corp

For more information visit https://viarag.ai or email info@viaveri.co

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

...

(You can find the full text here: https://www.gnu.org/licenses/gpl-3.0.txt)
