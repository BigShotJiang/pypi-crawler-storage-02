class DomainMismatchWarning(UserWarning):
    pass


class TooLargeSamplePortionWarning(UserWarning):
    pass
