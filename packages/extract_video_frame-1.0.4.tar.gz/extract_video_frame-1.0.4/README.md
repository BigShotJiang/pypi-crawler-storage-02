### extract video frame
一个简单的工具，用于从视频中提取帧并按照毫秒时间戳保存为图像文件。

---
### 使用示例
对视频进行分帧，使用示例：
```python
from extract_video_frame import extract
    print("示例: extract_video(video.mp4")
    print("示例: extract_video(video.mp4,/path/to/output)")
```