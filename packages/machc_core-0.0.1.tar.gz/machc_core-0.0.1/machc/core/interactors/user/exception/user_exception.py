class UserException(Exception):
    """
    Custom exception for user_service operations (e.g., authentication failures).
    """
    pass