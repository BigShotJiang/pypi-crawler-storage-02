"""Pricing module configuration package."""

from .loader import load_config, get_config_value

__all__ = ['load_config', 'get_config_value']