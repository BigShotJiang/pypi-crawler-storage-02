"""Tests for the Gentoo Build Publisher CLI"""
