"""Main entry point for Gentoo Build Publisher CLI"""

import sys

from gbpcli import main

sys.exit(main())
