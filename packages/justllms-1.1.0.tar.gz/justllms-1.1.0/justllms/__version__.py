"""Version information for JustLLMs."""

__version__ = "1.1.0"
