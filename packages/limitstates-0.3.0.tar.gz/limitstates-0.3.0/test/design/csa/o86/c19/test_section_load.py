"""
Tests if sections load properly for CSA o86
"""

