CSA o86-2019
============

Limitstates currently contains code for working with glulam and CLT.
Objects also exist for representing fire portection, and burning sections according to Annex B of csa o86.

#. :doc:`design-csa-o86-19-glulam`
#. :doc:`design-csa-o86-19-clt`
#. :doc:`design-csa-o86-19-fire`

.. toctree::
   :maxdepth: 6
   :hidden:
   
   design-csa-o86-19-glulam.rst
   design-csa-o86-19-clt.rst
   design-csa-o86-19-fire.rst



