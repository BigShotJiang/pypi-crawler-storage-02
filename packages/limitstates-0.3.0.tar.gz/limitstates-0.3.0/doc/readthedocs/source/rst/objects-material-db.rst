Material Databases
==================

The following mat databases are part of limitstates:
 - :download:`csa clt, prg320_2019 <matDB/csa/clt/prg320_2019.csv>`.
 - :download:`csa glulam, csa_o86_2019 <matDB/csa/glulam/csa_o86_2019.csv>`.
