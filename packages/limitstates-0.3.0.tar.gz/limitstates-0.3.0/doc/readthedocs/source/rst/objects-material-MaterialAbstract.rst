Abstract Material Baseclass
===========================

.. autoclass:: limitstates.objects.material.mat.MaterialAbstract
   :members:
   :undoc-members:
   :show-inheritance: