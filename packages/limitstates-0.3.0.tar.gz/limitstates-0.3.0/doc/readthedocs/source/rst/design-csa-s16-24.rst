CSA S16-24
==========

#. :doc:`design-csa-s16-24-bending`


.. toctree::
   :maxdepth: 3
   :hidden:
   
   design-csa-s16-24-objects.rst
   design-csa-s16-24-bending.rst
   design-csa-s16-24-shear.rst
   design-csa-s16-24-compression.rst
   design-csa-s16-24-interaction.rst



