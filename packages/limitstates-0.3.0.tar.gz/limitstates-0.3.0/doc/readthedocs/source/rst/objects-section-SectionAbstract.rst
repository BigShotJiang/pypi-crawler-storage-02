Abstract Section
================

 
.. autoclass:: limitstates.objects.section.section.SectionAbstract
   :members:
   :undoc-members:
   :show-inheritance: