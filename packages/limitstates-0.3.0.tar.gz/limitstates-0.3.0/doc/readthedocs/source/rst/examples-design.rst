.. _examples-design:

Examples: Design
================

These examples show how to use design libraries.

#. :doc:`examples-design-special-object-propreties`
#. :doc:`examples-design-csa`


.. toctree::
   :maxdepth: 2
   :hidden:

   examples-design-special-object-propreties.rst   
   examples-design-csa.rst

