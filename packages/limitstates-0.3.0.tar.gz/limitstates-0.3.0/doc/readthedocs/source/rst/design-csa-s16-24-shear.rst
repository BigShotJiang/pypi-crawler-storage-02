CSA S16-24 - Steel Design - Shear
=================================


The following equations are used to determin shear of multispan beams.

.. currentmodule:: limitstates


.. automodule:: limitstates.design.csa.s16.c24.beamColumn
	:members: checkFsBeam   
