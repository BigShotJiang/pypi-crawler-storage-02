How to manually update:

run the command:
sphinx-build -M html source build 