"""
Contains functions for managing sections specific to CSAo86-19
"""

