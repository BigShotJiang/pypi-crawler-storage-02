"""
These classes represent links between objects, for example, load passing
between a panel and beam; load passing through a column 
"""



class Relationship:
    pass

    def __init__(self):
        pass
    
    
    
class DesignSystem:
    """
    represents a common design system
    """

    