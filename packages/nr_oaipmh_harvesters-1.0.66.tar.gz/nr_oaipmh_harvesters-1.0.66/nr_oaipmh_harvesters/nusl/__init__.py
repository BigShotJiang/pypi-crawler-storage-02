from .transformer import NUSLTransformer

nusl_transformer = {"class": NUSLTransformer, "params": {}}
