from nr_oaipmh_harvesters.nusl import NUSLTransformer

DATASTREAMS_TRANSFORMERS = {
    "nusl": NUSLTransformer,
}
