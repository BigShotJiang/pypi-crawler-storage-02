import os

configDirectory: str = os.environ.get("RPS_CLIENT_CONFIG_DIR", os.getcwd())