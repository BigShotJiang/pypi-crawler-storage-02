from ..types.py_object import PyObject


class List(PyObject, list):
    pass
