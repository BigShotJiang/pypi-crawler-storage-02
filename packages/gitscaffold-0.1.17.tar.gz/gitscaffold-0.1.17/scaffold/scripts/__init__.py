"""Vendored scripts for gitscaffold CLI commands."""
__all__ = []