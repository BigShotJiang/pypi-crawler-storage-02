# -*- coding: utf-8 -*-
################################################################################
# immlib/test/types/test_core.py

from .test_core import TestTypesCore
