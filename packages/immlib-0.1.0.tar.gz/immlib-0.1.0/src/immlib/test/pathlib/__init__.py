# -*- coding: utf-8 -*-
################################################################################
# pimms/test/pathlib/__init__.py

"""Test module for the pimms.pathlib submodule."""

# Import tests
from .test_core import TestPathlibCore
from .test_osf  import TestPathlibOSF


