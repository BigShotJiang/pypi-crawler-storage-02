# -*- coding: utf-8 -*-
################################################################################
# immlib/test/doc/__init__.py


from .test_core import TestDocCore as TestDoc
