# -*- coding: utf-8 -*-
################################################################################
# immlib/test/workflow/__init__.py
#
# Tests of the immlib.workflow module.


from .test_core     import TestWorkflowCore
from .test_plantype import TestWorkflowPlanType
