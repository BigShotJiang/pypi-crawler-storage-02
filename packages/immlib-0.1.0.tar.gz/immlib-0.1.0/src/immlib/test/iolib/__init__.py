# -*- coding: utf-8 -*-
################################################################################
# pimms/test/iolib/__init__.py

"""Tests fot pimms.iolib."""

from .test_core import TestIOLibCore
