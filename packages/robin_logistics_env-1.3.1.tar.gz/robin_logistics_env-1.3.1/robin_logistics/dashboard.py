"""Dashboard interface for the Robin Logistics Environment."""

import os
import tempfile
import subprocess
from typing import Dict
import streamlit as st

from .core.simulation_engine import SimulationEngine
from .core.visualizer import visualize_solution


def create_dashboard(env, solver_function=None):
    """Create and launch the interactive dashboard with scenario selection."""
    import pickle
    import tempfile
    import json
    
    env_data = {
        'current_scenario': env._current_scenario,
        'scenario_info': env.get_scenario_info() if env._current_scenario else None
    }
    
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.json') as env_file:
        json.dump(env_data, env_file)
        env_path = env_file.name
    
    solver_path = None
    if solver_function:
        try:
            import dill
            with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.pkl') as solver_file:
                dill.dump(solver_function, solver_file)
                solver_path = solver_file.name
        except ImportError:
            solver_path = "unsupported"
    
    dashboard_code = _generate_dashboard_code(env_path, solver_path)
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(dashboard_code)
        temp_file = f.name
    
    try:
        subprocess.run(['streamlit', 'run', temp_file], check=True)
        
    finally:
        cleanup_paths = [temp_file, env_path]
        if solver_path and solver_path != "unsupported":
            cleanup_paths.append(solver_path)
        for path in cleanup_paths:
            if os.path.exists(path):
                os.unlink(path)


def _generate_dashboard_code(env_path: str, solver_path: str = None) -> str:
    """Generate the Streamlit dashboard code."""
    return """
import streamlit as st
import pandas as pd
import os
import pickle
from robin_logistics.core.simulation_engine import SimulationEngine
from robin_logistics.core.visualizer import visualize_solution


def load_env_and_solver():
    env_path = "{}"
    solver_path = "{}"
    
    try:
        from robin_logistics import LogisticsEnvironment
        env = LogisticsEnvironment()
        
        if env_path.endswith('.json'):
            import json
            with open(env_path, 'r') as f:
                env_data = json.load(f)
                if env_data.get('current_scenario'):
                    env.load_scenario(env_data['current_scenario'])
        
        solver_function = None
        if solver_path and solver_path not in ["None", "unsupported"]:
            try:
                import dill
                with open(solver_path, 'rb') as f:
                    solver_function = dill.load(f)
            except:
                solver_function = None
        
        return env, solver_function
    except Exception as e:
        st.error(f"Error loading data: {{e}}")
        return None, None


def display_problem_details(env):
    \"\"\"Display comprehensive problem instance details\"\"\"
    st.header("📋 Problem Instance Details")
    
    st.subheader("🏬 Warehouses & Fleet")
    wh_data = []
    for wh in env.warehouses.values():
        fleet_info = {{}}
        for vehicle in wh.vehicles:
            vtype = vehicle.type
            if vtype not in fleet_info:
                fleet_info[vtype] = 0
            fleet_info[vtype] += 1
        
        fleet_str = ", ".join([f"{{count}}x {{vtype}}" for vtype, count in fleet_info.items()])
        wh_data.append({{
            'Warehouse ID': wh.id,
            'Location Node': wh.location.id,
            'Coordinates': f"({{wh.location.lat:.4f}}, {{wh.location.lon:.4f}})",
            'Fleet Composition': fleet_str,
            'Total Vehicles': len(wh.vehicles)
        }})
    
    if wh_data:
        st.dataframe(pd.DataFrame(wh_data), use_container_width=True)
    
    st.subheader("📦 SKU Specifications")
    sku_data = []
    for sku in env.skus.values():
        sku_data.append({{
            'SKU ID': sku.id,
            'Weight (kg)': sku.weight,
            'Volume (m³)': sku.volume,
            'Density (kg/m³)': round(sku.weight / sku.volume, 2) if sku.volume > 0 else 'N/A'
        }})
    
    if sku_data:
        st.dataframe(pd.DataFrame(sku_data), use_container_width=True)
    
    st.subheader("📊 Inventory Summary")
    
    total_stock_items = sum(sum(wh.inventory.values()) for wh in env.warehouses.values())
    total_stock_weight = sum(qty * sku.weight for wh in env.warehouses.values() for sku, qty in wh.inventory.items())
    unique_skus = len(set(sku for wh in env.warehouses.values() for sku in wh.inventory.keys()))
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Items in Stock", f"{{total_stock_items:,}}")
    with col2:
        st.metric("Total Weight", f"{{total_stock_weight:,.1f}} kg")
    with col3:
        st.metric("Unique SKUs", unique_skus)
    
    st.subheader("🛒 Orders Summary")
    
    total_orders = len(env.orders)
    total_items_demanded = sum(sum(order.requested_items.values()) for order in env.orders.values())
    avg_items_per_order = total_items_demanded / total_orders if total_orders > 0 else 0
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Orders", total_orders)
    with col2:
        st.metric("Total Items Demanded", f"{{total_items_demanded:,}}")
    with col3:
        st.metric("Avg Items per Order", f"{{avg_items_per_order:.1f}}")


def display_inventory_management(env, solution):
    \"\"\"Comprehensive inventory management dashboard\"\"\"
    st.header("📦 Inventory Management Dashboard")
    
    st.subheader("📉 Inventory Usage & Deductions")
    
    required_items = {{}}
    for order in env.orders.values():
        for sku, qty in order.requested_items.items():
            if sku not in required_items:
                required_items[sku] = 0
            required_items[sku] += qty
    
    used_items = {{}}
    for vehicle_id, route in solution.get("routes", {{}}).items():
        orders_on_route = [o for o in env.orders.values() if o.destination.id in route]
        for order in orders_on_route:
            for sku, qty in order.requested_items.items():
                if sku not in used_items:
                    used_items[sku] = 0
                used_items[sku] += qty
    
    usage_data = []
    for wh in env.warehouses.values():
        for sku, initial_qty in wh.inventory.items():
            required = required_items.get(sku, 0)
            used = used_items.get(sku, 0)
            remaining = initial_qty - used
            
            usage_data.append({{
                'Warehouse': wh.id,
                'SKU': sku.id,
                'Initial Stock': initial_qty,
                'Required Total': required,
                'Used in Solution': used,
                'Remaining Stock': remaining,
                'Utilization %': f"{{(used / initial_qty * 100):.1f}}%" if initial_qty > 0 else "0.0%",
                'Status': '🟢 Sufficient' if remaining >= 0 else '🔴 Shortage'
            }})
    
    if usage_data:
        usage_df = pd.DataFrame(usage_data)
        st.dataframe(usage_df, use_container_width=True)


def display_vehicle_status(env, solution, final_state, logs):
    \"\"\"Display detailed vehicle attributes and status\"\"\"
    st.header("🚛 Vehicle Fleet Status")
    
    all_vehicles = env.get_all_vehicles()
    vehicle_data = []
    
    for vehicle in all_vehicles:
        is_used = vehicle.id in solution.get("routes", {{}})
        route = solution.get("routes", {{}}).get(vehicle.id, [])
        
        route_distance = 0
        route_cost = 0
        orders_served = 0
        orders_on_route = []
        
        if is_used and route:
            for i in range(len(route) - 1):
                route_distance += env.get_distance(route[i], route[i+1])
            
            route_cost = vehicle.fixed_cost + (route_distance * vehicle.cost_per_km)
            orders_on_route = [o for o in env.orders.values() if o.destination.id in route]
            orders_served = len(orders_on_route)
        
        weight_utilization = 0
        volume_utilization = 0
        distance_utilization = 0
        
        if is_used:
            total_weight = 0
            total_volume = 0
            
            for order in orders_on_route:
                for sku, qty in order.requested_items.items():
                    total_weight += sku.weight * qty
                    total_volume += sku.volume * qty
            
            weight_utilization = (total_weight / vehicle.capacity_weight) * 100 if vehicle.capacity_weight > 0 else 0
            volume_utilization = (total_volume / vehicle.capacity_volume) * 100 if vehicle.capacity_volume > 0 else 0
            distance_utilization = (route_distance / vehicle.max_distance) * 100 if vehicle.max_distance > 0 else 0
        
        vehicle_data.append({{
            'Vehicle ID': vehicle.id,
            'Type': vehicle.type,
            'Home Warehouse': vehicle.home_warehouse_id,
            'Status': '🟢 Active' if is_used else '⚪ Idle',
            'Capacity Weight (kg)': vehicle.capacity_weight,
            'Capacity Volume (m³)': vehicle.capacity_volume,
            'Max Distance (km)': vehicle.max_distance,
            'Fixed Cost': f"${{vehicle.fixed_cost}}",
            'Cost/km': f"${{vehicle.cost_per_km}}",
            'Route Distance (km)': f"{{route_distance:.2f}}" if is_used else "0.00",
            'Total Cost': f"${{route_cost:.2f}}" if is_used else "$0.00",
            'Orders Served': orders_served,
            'Weight Util %': f"{{weight_utilization:.1f}}%" if is_used else "0.0%",
            'Volume Util %': f"{{volume_utilization:.1f}}%" if is_used else "0.0%",
            'Distance Util %': f"{{distance_utilization:.1f}}%" if is_used else "0.0%"
        }})
    
    if vehicle_data:
        vehicles_df = pd.DataFrame(vehicle_data)
        st.dataframe(vehicles_df, use_container_width=True)


def main():
    \"\"\"Main dashboard application with scenario selection.\"\"\"
    st.set_page_config(page_title="Robin Logistics Dashboard", page_icon="🚚", layout="wide")
    st.title("🚚 Robin Logistics Optimization Dashboard")
    
    env, solver_function = load_env_and_solver()
    if not env:
        return
    
    if 'current_scenario' not in st.session_state:
        st.session_state.current_scenario = None
        st.session_state.results = None
    
    st.sidebar.header("🎯 Scenario Selection")
    
    scenarios = env.get_available_scenarios()
    scenario_names = {{key: f"{{info['name']}} ({{info['num_orders']}} orders)" 
                     for key, info in scenarios.items()}}
    
    selected_scenario = st.sidebar.selectbox(
        "Choose Challenge Level:",
        options=list(scenarios.keys()),
        format_func=lambda x: scenario_names[x],
        index=1 if 'intermediate' in scenarios else 0
    )
    
    if st.sidebar.button("Load Scenario", type="primary"):
        try:
            scenario_info = env.load_scenario(selected_scenario)
            st.session_state.current_scenario = selected_scenario
            st.session_state.results = None
            st.sidebar.success(f"✅ Loaded: {{scenario_info['name']}}")
        except Exception as e:
            st.sidebar.error(f"❌ Error loading scenario: {{e}}")
    
    if st.session_state.current_scenario:
        scenario_info = env.get_scenario_info()
        
        st.sidebar.markdown("### 📊 Current Scenario")
        st.sidebar.markdown(f"**{{scenario_info['name']}}**")
        st.sidebar.markdown(f"{{scenario_info['description']}}")
        st.sidebar.markdown(f"Orders: {{scenario_info['num_orders']}}")
        
        col1, col2 = st.sidebar.columns(2)
        with col1:
            st.markdown("**Weight Ratio:**")
            for sku, ratio in scenario_info['weight_ratio'].items():
                st.markdown(f"{{sku}}: {{ratio:.0%}}")
        with col2:
            st.markdown("**Distance Ratio:**")
            for dist, ratio in scenario_info['distance_ratio'].items():
                st.markdown(f"{{dist.title()}}: {{ratio:.0%}}")
        
        if solver_function and st.sidebar.button("🚀 Run Optimization", type="secondary"):
            with st.spinner("Running optimization..."):
                try:
                    results = env.run_optimization(solver_function)
                    st.session_state.results = results
                    if results['is_valid']:
                        st.sidebar.success(f"✅ Solution found! Cost: ${{results['cost']:.2f}}")
                    else:
                        st.sidebar.error(f"❌ Invalid solution: {{results['error_message']}}")
                except Exception as e:
                    st.sidebar.error(f"❌ Optimization failed: {{e}}")
        
        if st.session_state.results:
            results = st.session_state.results
            solution = results['solution']
            
            st.header("📈 Solution Results")
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Cost", f"${{results['cost']:.2f}}")
            with col2:
                st.metric("Vehicles Used", results['vehicles_used'])
            with col3:
                st.metric("Orders Delivered", f"{{results['orders_fulfilled']}}/{{env.num_orders}}")
            with col4:
                st.metric("Scenario", results.get('scenario', 'Unknown'))
            
            if results['is_valid']:
                st.success("✅ Solution is valid!")
                
                env_internal = env._env
                sim_engine = SimulationEngine(env_internal, solution)
                final_state, logs = sim_engine.run_simulation()
                
                map_tab, problem_tab, vehicles_tab, analysis_tab = st.tabs([
                    "🗺️ Interactive Map", 
                    "📋 Problem Details", 
                    "🚛 Vehicle Status", 
                    "📊 Journey Analysis"
                ])
                
                with map_tab:
                    st.subheader("Interactive Route Map")
                    map_file = "temp_map.html"
                    visualize_solution(env_internal, solution, map_file)
                    
                    if os.path.exists(map_file):
                        with open(map_file, 'r', encoding='utf-8') as f:
                            st.components.v1.html(f.read(), height=600, scrolling=True)
                
                with problem_tab:
                    display_problem_details(env_internal)
                
                with vehicles_tab:
                    display_vehicle_status(env_internal, solution, final_state, logs)
                
                with analysis_tab:
                    st.header("📊 Step-by-Step Journey Analysis")
                    if not logs:
                        st.info("No routes were generated to analyze.")
                    else:
                        vehicle_choice = st.selectbox("Select a Vehicle to Analyze:", options=list(logs.keys()))
                        if vehicle_choice and vehicle_choice in logs:
                            st.subheader(f"🔍 Analysis: {{vehicle_choice}}")
                            for i, log_entry in enumerate(logs[vehicle_choice]):
                                with st.expander(f"Step {{i+1}}: {{log_entry[:50]}}...", expanded=False):
                                    st.markdown(log_entry)
            else:
                st.error(f"❌ Solution is invalid: {{results['error_message']}}")
        
        else:
            st.info("🎯 Select a scenario and run optimization to see results!")
            
            st.header("📋 Scenario Preview")
            display_problem_details(env._env if env._env else None)
    
    else:
        st.info("🎯 Please select and load a scenario to begin!")


if __name__ == "__main__":
    main()
""".format(env_path, solver_path or "None")