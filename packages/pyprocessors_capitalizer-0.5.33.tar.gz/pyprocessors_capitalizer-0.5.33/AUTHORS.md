# Authors

Contributors to pyprocessors_capitalizer include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
