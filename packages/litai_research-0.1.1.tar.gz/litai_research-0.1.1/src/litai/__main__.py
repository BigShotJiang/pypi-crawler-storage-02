"""Entry point for running LitAI as a module."""

from litai.cli import main

if __name__ == "__main__":
    main()
