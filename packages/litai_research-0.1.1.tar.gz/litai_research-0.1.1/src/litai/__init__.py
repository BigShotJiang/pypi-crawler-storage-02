"""LitAI - AI-powered academic paper synthesis tool."""

__version__ = "0.1.0"
