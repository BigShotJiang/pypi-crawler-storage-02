"""
Placeholder package for predicat-tools.
"""
__all__ = []
__version__ = "0.0.0a1"
