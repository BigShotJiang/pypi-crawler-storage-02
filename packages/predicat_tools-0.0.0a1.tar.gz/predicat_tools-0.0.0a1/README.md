# predicat-tools

Reserved package name for the Predicat open source project.

This is a placeholder release to secure the name on PyPI.
Full release coming soon.

- Project: https://predicat.ai
- GitHub: https://github.com/predicatai/predicat-tools
