Defina a **Politica de Faturamento de Compras**, se a Fatura deverá ser criada a partir do **Pedido de Compra/purchase.order** ou da **Ordem de Recebimento/stock.picking** 
isso pode ser feito em:

**Definições > Usuários e Empresas > Empresas**
Selecione a Empresa, aba **Fiscal** e depois na aba **Compras**

ou

**Compras > Configuração > Definições**
Na seção **Faturamento**
