# pg2ch

### Convert PostgreSQL DDL to ClickHouse DDL and Toolkits
