# CFCli
A cli tool for codeforces
