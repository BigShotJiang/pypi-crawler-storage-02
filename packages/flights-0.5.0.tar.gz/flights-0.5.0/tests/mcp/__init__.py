"""Tests for MCP server functionality."""
