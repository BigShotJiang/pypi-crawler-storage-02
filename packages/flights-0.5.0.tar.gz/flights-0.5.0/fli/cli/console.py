"""Console module for the CLI."""

from rich.console import Console

console = Console()
