"""CLI module for the fli package."""

from fli.cli.main import cli

__all__ = ["cli"]
