Mojo module [🡭](https://github.com/mlange-42/modo/blob/main/test/src/pkg/submod.mojo)

# `submod`

## Aliases

- `ModuleAlias = Int`

## Structs

- [`Struct`](Struct-.md): [`Struct`](Struct-.md), [`ModuleAlias`](_index.md#aliases).

