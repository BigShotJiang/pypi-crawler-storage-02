# Modo slides

Local preview:

```
reveal-md slides.md -w --% --static-dirs=.nojekyll,img
```
