# Modo's assets

Sub-directories contain files that are embedded in the binaries.

See folder [templates](templates) for template files that can be used for customization with the `--templates` flag.
