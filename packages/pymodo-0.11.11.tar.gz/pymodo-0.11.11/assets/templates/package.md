Mojo package{{template "source_link" .}}

# `{{.Name}}`

{{template "summary" . -}}
{{template "description" . -}}
{{template "aliases" . -}}
{{template "structs" . -}}
{{template "traits" . -}}
{{template "functions" . -}}
{{template "modules" . -}}
{{template "packages" . -}}