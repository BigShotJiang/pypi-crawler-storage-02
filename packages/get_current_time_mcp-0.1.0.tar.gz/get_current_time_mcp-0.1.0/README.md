# Example Get Current Time MCP Server

This is a MCP server in Python that provides a `get_current_time` tool.

## Installation
```bash
pip install get-current-time-mcp
