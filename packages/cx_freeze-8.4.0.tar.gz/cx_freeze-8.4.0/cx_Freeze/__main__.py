"""cx_Freeze command line tool (enable python -m cx_Freeze syntax)."""

from __future__ import annotations

import cx_Freeze.cli

if __name__ == "__main__":
    cx_Freeze.cli.main()
