# Firebase Experimentation Manager

Firebase Experimentation Manager provides functionality to manage communication of conditions and observations between AutoRA and an experiment on Firebase.

