"""Top-level package for tstgispypkg."""

__author__ = """Jingze Liu"""
__email__ = "jingze899@gmail.com"
__version__ = "0.0.1"
