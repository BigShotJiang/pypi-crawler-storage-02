# Usage

To use tstgispypkg in a project:

```
import tstgispypkg
```
