"""
Tests for CodeDocGen.

Unit tests and integration tests for the CodeDocGen package.
""" 