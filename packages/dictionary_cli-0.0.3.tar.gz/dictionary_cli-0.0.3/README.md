# Dictionary
Python CLI Dictionary using [Free Dictionary API](https://dictionaryapi.dev/)

## Installation
```bash
python3 -m pip install dictionary-cli
```

## Usage
```bash
dictionary
```

## AI 
AI was used to help me understand the API response for synonyms. 
