from .mageia import Mageia

Client = Mageia
