mod sink;

pub use sink::DeltaDataSink;
