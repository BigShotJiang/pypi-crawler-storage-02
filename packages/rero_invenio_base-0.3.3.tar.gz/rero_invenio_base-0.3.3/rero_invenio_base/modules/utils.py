# RERO Invenio Base
# Copyright (C) 2023 RERO.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

"""Generic utils functions."""

from itertools import islice


def chunk(iterable, size):
    """Split a list of value into a list of chunks.

    :param iterable: an iterator or list to be splitted
    :param size: integer - the chunk size
    :return: an iterator on the chunks

    Example:
        list(chunk([1, 2, 3, 4, 5], 2)) == [(1, 2), (3, 4), (5, )]
    """
    it = iter(iterable)
    while chunk := tuple(islice(it, size)):
        yield chunk
