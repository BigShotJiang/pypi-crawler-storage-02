..
    RERO Invenio Base
    Copyright (C) 2022 RERO.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.

===================
 RERO Invenio Base
===================

.. image:: https://github.com/rero/rero-invenio-base/actions/workflows/continuous-integration-test.yml/badge.svg
        :target: https://github.com/rero/rero-invenio-base/actions/workflows/continuous-integration-test.yml

.. image:: https://img.shields.io/github/tag/rero/rero-invenio-base.svg
        :target: https://github.com/rero/rero-invenio-base/releases

.. image:: https://img.shields.io/pypi/dm/rero-invenio-base.svg
        :target: https://pypi.python.org/pypi/rero-invenio-base

.. image:: https://img.shields.io/github/license/rero/rero-invenio-base.svg
        :target: https://github.com/rero/rero-invenio-base/blob/master/LICENSE

Generic backend libraries for RERO Invenio instances.

Further documentation is available on
https://rero-invenio-base.readthedocs.io/
