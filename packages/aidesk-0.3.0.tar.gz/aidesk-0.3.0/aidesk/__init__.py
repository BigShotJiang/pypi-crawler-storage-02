"""
aidesk - A simple web service with file operations and instance management
"""

__version__ = "0.2.a"
__author__ = "levin"
__license__ = "MIT"
