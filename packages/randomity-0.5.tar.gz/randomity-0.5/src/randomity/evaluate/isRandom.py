def isRandom(sequence):
    """
    Returns a boolean based on if a sequence is scored higher than a threshold for the randomness score.
    """
    # TODO