"""Entry point for the Rosbridge MCP Server."""

from .server import main

if __name__ == "__main__":
    main()
