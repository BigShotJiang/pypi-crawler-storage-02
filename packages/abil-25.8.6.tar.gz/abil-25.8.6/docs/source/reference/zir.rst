Zero Inflated Regressor
=======================

.. autoclass:: abil.zir.ZeroInflatedRegressor
   :members:
   :exclude-members: set_score_request, set_fit_request
