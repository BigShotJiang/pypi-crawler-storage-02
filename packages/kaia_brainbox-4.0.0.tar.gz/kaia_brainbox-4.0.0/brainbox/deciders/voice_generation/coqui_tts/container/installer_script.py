from tts_loader import load_tts
import sys

if __name__ == '__main__':
    load_tts(sys.argv[1])