from .open_tts import OpenTTS
from .coqui_tts import CoquiTTS
from .tortoise_tts import TortoiseTTS
from .openvoice import OpenVoice
from .piper import Piper
from .piper_training import PiperTraining
from .zonos import Zonos