from dataclasses import dataclass

@dataclass
class WhisperXSettings:
    pass