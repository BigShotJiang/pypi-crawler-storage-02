from dataclasses import dataclass

@dataclass
class KohyaSSSettings:
    port: int = 11012
