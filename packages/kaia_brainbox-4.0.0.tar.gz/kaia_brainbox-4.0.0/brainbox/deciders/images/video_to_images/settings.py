from dataclasses import dataclass

@dataclass
class VideoToImagesSettings:
    pass