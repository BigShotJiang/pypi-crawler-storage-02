from brainbox.deciders.images.video_to_images.controller import VideoToImagesController

if __name__ == '__main__':
    controller = VideoToImagesController()
    controller.install()
    controller.self_test()




