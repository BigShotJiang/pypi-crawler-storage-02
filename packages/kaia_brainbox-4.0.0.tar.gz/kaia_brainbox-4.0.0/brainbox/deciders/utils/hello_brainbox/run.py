from brainbox.deciders import HelloBrainBox

if __name__ == '__main__':
    controller = HelloBrainBox.Controller()
    controller.install()
    controller.self_test()
    #controller.run_notebook()

