from dataclasses import dataclass

@dataclass
class BoilerplateOnDemandSettings:
    pass