class Logger:
    def report_progress(self, progress: float):
        pass

    def log(self, s):
        print(s)


