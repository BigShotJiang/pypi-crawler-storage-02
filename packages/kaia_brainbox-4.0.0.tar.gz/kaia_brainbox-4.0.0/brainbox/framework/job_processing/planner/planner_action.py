from ..core import ICoreAction

class IPlannerAction(ICoreAction):
    pass