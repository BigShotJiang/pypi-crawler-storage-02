from typing import *
from dataclasses import dataclass

@dataclass
class SourceFileAttachment:
    method_or_type: Any