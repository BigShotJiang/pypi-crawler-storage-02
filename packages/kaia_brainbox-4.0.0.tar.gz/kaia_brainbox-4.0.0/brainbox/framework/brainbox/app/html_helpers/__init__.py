from .batch_page import create_batch_page
from .main_page import create_main_page
from .operator_log_page import create_operator_log_page