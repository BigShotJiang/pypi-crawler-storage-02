<p align="center">
  <img src="https://raw.githubusercontent.com/pyload/pyload/main/media/logo.png" alt="pyLoad" height="100" />
</p>

## Credits

### Team

- Alex Kilp [himbrr](https://github.com/kilale) <himbrr@himbrr.ws>
- Christian Rakow [RaNaN](https://github.com/RaNaN) <Mast3rRaNaN@hotmail.de>
- Jonas Engelhardt [Jonn3y](https://github.com/Jonn3y)
- Marius Kittelmann [mkaay](https://github.com/mkaay) <mkaay@mkaay.de>
- Martin Hronek [Velociraptor85](https://github.com/Velociraptor85) <hrspam@gmail.com>
- Nitzo [GammaC0de](https://github.com/GammaC0de) <nitzo2001@yahoo.com>
- Paul Spooren [spoob](https://github.com/aparcar) <mail@aparcar.org>
- Stefano Codari [stickell](https://github.com/stickell) <l.stickell@yahoo.it>
- Walter Purcaro [vuolter](https://github.com/vuolter) <vuolter@gmail.com>
- sebnapi

### Maintainers

- Nitzo [GammaC0de](https://github.com/GammaC0de)

### Developers

- Nitzo [GammaC0de](https://github.com/GammaC0de)
- Walter Purcaro [vuolter](https://github.com/vuolter)

### Collaborators

- Jonas Engelhardt [Jonn3y](https://github.com/Jonn3y)
- Martin Hronek [Velociraptor85](https://github.com/Velociraptor85)

### Contributors

The list of developers who have kindly contributed to the pyLoad project is constantly updated.

You can found it here: <https://github.com/pyload/pyload/graphs/contributors>.

### Community

There are so many users that helped in these last years, testing code, reporting issues,
opening topics to share tips and advices or fixing troubles or just to discuss about the project...

**The pyLoad team can be only forever thankful to all of you for your persistence!**

This has kept the project alive until today and we hope it will continue in the time to come.

<br />
<br />

_A special thanks to **RaNaN**, **sebnapi** and **spoob** who started this journey so long ago!_

<br />

---

###### © 2008-2025 pyLoad team
