# obafgkm
interactive tool to plot representative spectra for stars of different spectral types and metallicities!
