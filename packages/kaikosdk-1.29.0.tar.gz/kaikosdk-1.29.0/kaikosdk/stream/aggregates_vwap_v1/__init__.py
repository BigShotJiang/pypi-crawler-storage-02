name='aggregates_vwap_v1'
