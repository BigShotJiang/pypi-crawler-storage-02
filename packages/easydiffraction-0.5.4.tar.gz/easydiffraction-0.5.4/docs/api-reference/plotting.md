::: easydiffraction.plotting
