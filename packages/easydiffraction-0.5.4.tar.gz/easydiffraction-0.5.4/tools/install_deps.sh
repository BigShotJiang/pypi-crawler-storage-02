echo "\033[0;33m:::::: Install Python dependencies\033[0m"
pip install mkdocs mkdocs-material 'mkdocs-autorefs<1.3.0' mkdocs-jupyter mkdocs-plugin-inline-svg mkdocs-markdownextradata-plugin mkdocstrings-python pyyaml
