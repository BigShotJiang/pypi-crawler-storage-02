echo "\033[0;33m:::::: Build docs (http://127.0.0.1:8000)\033[0m"
export JUPYTER_PLATFORM_DIRS=1
export PYTHONPATH=$(pwd)/src:$PYTHONPATH
mkdocs serve
