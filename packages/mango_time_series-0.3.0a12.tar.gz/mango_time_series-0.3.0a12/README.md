# Mango Time Series

A comprehensive Python library for time series analysis, forecasting, and feature engineering built on top of the Mango framework.
