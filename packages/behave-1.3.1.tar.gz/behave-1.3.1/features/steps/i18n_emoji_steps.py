# -*- coding: UTF-8 -*-
# NEEDED-BY: features/i18n_emoji.feature

from __future__ import absolute_import, print_function
from behave import given


@given(u'🎸')
def step_impl(context):
    """Step implementation example with emoji(s)."""
    pass

