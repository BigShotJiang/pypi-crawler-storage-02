"""
Provides active-tag functionality for common use cases.
"""
