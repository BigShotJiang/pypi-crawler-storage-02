#ifndef MINIEXACT_GIT_H
#define MINIEXACT_GIT_H

#ifdef __cplusplus
extern "C" {
#endif

extern const char* miniexact_git_commit_hash;
extern const char* miniexact_git_tag;

#ifdef __cplusplus
}
#endif

#endif
