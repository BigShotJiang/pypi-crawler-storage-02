#ifndef MINIEXACT_ALGORITHM_X_H
#define MINIEXACT_ALGORITHM_X_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct miniexact_algorithm miniexact_algorithm;

void
miniexact_algorithm_x_set(miniexact_algorithm* a);

#ifdef __cplusplus
}
#endif

#endif
