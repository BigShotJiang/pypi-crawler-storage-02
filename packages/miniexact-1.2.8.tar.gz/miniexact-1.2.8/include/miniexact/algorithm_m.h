#ifndef MINIEXACT_ALGORITHM_M_H
#define MINIEXACT_ALGORITHM_M_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct miniexact_algorithm miniexact_algorithm;

void
miniexact_algorithm_m_set(miniexact_algorithm* a);

#ifdef __cplusplus
}
#endif

#endif
