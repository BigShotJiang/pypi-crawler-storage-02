Soma Pieces
===========

Courtesy of Simone Atzwanger.
