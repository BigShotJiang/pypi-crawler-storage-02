Example 270
===========

Courtesy of Sonja Gurtner
