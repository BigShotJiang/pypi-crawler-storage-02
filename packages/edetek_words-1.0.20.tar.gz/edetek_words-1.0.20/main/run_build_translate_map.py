# !/usr/bin/python3
# -*- coding:utf-8 -*-
"""
@Author: xiaodong.li
@Time: 8/8/2025 11:03 AM
@Description: Description
@File: run_build_translate_map.py.py
"""
from edetek_words.core.build_translate_map import build_translate_map

if __name__ == '__main__':
    build_translate_map()
