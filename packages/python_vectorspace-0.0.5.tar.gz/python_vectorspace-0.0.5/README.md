# vectorspace

## Run

```bash
pipx run python-vectorspace
```

## Development

```bash
uv run vectorspace
```

or

```bash
uv pip install -e .
```

and then

```bash
vectorspace
```

## API docs

```
http://localhost:8000/docs
```
