{True: 'foo', False: 'oof', 'another': 'bar', None: "nothin'"}
