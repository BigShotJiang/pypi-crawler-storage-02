# -*- coding: utf-8 -*-
# __init__.py

# Import necessary modules or packages here

# Define the package version
__version__ = "0.1.0"

# Initialize package-level variables or configurations if needed
# config_variable = "value"

# You can also include package-level docstring
"""
nmdc_api_utilities package

This package provides tools for working with NMDC notebooks.
"""

# Add any other initialization code here
