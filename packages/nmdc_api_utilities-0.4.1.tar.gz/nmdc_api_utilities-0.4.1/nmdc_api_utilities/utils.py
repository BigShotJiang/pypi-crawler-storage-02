# -*- coding: utf-8 -*-
from nmdc_api_utilities.collection_search import CollectionSearch
import requests
from nmdc_api_utilities.nmdc_search import NMDCSearch
import logging

logger = logging.getLogger(__name__)


class Utils:
    def __init__(self):
        pass
