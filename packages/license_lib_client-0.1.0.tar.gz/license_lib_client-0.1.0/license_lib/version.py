"""Version information for the license library."""

__version__ = "1.0.0"
