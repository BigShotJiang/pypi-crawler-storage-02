//! Utilities for decoding data from various sources into both array data and metadata (e.g. schema inference)
pub mod deserialize;
pub mod inference;
