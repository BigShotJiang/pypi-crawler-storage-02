"""
Configuration package for PrecisionDoc.
"""
