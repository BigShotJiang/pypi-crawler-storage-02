import pytest
import time

# 3 passing tests
def test_pass_one():
    time.sleep(0.1)
    assert 1 == 1
