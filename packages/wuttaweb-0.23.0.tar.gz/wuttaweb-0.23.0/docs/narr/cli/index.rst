
==============
 Command Line
==============

There isn't much to the command line for WuttaWeb, but here it is.

For more general info about CLI see
:doc:`wuttjamaican:narr/cli/index`.

.. toctree::
   :maxdepth: 2

   builtin
