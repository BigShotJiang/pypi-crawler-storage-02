
``wuttaweb.views.common``
=========================

.. automodule:: wuttaweb.views.common
   :members:
