
``wuttaweb.views.essential``
============================

.. automodule:: wuttaweb.views.essential
   :members:
