
``wuttaweb.views.upgrades``
===========================

.. automodule:: wuttaweb.views.upgrades
   :members:
