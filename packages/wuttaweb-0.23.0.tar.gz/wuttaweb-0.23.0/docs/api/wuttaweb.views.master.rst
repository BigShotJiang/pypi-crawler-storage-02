
``wuttaweb.views.master``
=========================

.. automodule:: wuttaweb.views.master
   :members:
