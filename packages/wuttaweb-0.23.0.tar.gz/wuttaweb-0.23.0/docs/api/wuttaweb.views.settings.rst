
``wuttaweb.views.settings``
===========================

.. automodule:: wuttaweb.views.settings
   :members:
