
``wuttaweb.static``
===================

.. automodule:: wuttaweb.static
   :members:
