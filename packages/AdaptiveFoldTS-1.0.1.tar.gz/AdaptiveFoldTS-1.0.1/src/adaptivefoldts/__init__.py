from .core import AdaptiveFoldTS

__all__ = ['AdaptiveFoldTS']
