# Solana/Private Key, Public Key and Address/Address

Hey there, fellow tech enthusiast! I've told you this before, but let me reiterate it one more time - a Solana address is actually the base58 representation of its public key……

However, I couldn't resist explaining this point again. After all, this is basic knowledge that every serious tech person should know.

One day, if you find yourself in a situation where you're embarrassed about not knowing this and say something like "I learned Solana from reading such trash blog articles", beware! If the author of those articles finds out, they might not be amused.

That's why I created this section, disguised as a technical article, and included it in the directory list.

Remember this point, so next time you see strange letters and numbers, don't forget that they're also public keys and addresses.
