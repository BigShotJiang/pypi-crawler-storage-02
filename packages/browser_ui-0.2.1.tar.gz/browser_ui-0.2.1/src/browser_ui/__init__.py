from .BrowserUI import BrowserUI
from .utils import EventType