from .server import VERSION

__version__ = VERSION