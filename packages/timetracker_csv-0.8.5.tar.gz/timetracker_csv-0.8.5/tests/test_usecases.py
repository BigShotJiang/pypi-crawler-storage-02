#!/usr/bin/env python3
"""Test Timetracker use cases"""

#from os import environ
#from datetime import timedelta
#from timeit import default_timer
#from timetracker.consts import DIRTRK
#from timetracker.cli import Cli

# pylint: disable=fixme


def test_usecases():
    """Test Timetracker use cases"""
    # pylint: disable=line-too-long
    # make clobber

    # trk
    # Run `trk init` to initialize time-tracking for the project in

    # trk
    # Run `trk init` to initialize time-tracking for the project in

    # trk init
    # Initialized timetracker directory:

    # trk init
    # Trk repository already initialized:

    # trk start
    # Timetracker started Wed 03:21 PM: 2025-02-05 15:21:36.452917 for project 'timetracker' ID=username

    # trk start
    # Do `trk stop -m "task description"` to stop tracking this time unit

    # trk stop
    # usage: timetracker stop [-h] -m MESSAGE [--activity ACTIVITY] [-t [TAGS ...]]
    # timetracker stop: error: the following arguments are required: -m/--message

    # trk stop -m 'test stopped'
    # Timer stopped; Elapsed H:M:S=0:00:19.531226 appended to timetracker_timetracker_username.csv


if __name__ == '__main__':
    test_usecases()
