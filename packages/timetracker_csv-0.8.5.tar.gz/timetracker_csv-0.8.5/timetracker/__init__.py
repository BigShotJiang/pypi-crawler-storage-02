"""Lightweight command-line timetracker which stores data in csv files"""

__copyright__ = 'Copyright (C) 2025-present, DV Klopfenstein, PhD. All rights reserved'
__author__ = 'DV Klopfenstein, PhD'
__version__ = '0.8.5'

# Copyright (C) 2025-present, DV Klopfenstein, PhD. All rights reserved
