"""Configuration package for timetracking"""
