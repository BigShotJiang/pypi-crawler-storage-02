"""CLI interface for MCP Commander."""

from mcpcommander.cli.main import main

__all__ = ["main"]
