z3c\.celery\.layer
==================

.. automodule:: z3c.celery.layer

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      EagerLayer
      EndToEndLayer
   
   

   
   
   