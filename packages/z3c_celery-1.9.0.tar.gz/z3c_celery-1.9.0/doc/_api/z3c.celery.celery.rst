z3c\.celery\.celery
===================

.. automodule:: z3c.celery.celery

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_principal
      login_principal
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      TransactionAwareTask
   
   

   
   
   .. rubric:: Exceptions

   .. autosummary::
   
      Abort
      HandleAfterAbort
      Retry
   
   