==========
z3c.celery
==========

Integration of Celery 4 with Zope 3.

This package is compatible with Python version 2.7, 3.6 and 3.7.

:Online documentation:
    http://z3ccelery.rtfd.io/

:PyPI page:
    https://pypi.org/project/z3c.celery/

:Issues:
    https://github.com/ZeitOnline/z3c.celery/issues

:Source code:
    https://github.com/ZeitOnline/z3c.celery

:Current change log:
    https://raw.githubusercontent.com/ZeitOnline/z3c.celery/master/CHANGES.rst
