"""Package data for python-lucide.

This package may contain the pre-built Lucide icons database if installed
with the 'db' extra using pip install "lucide[db]".
"""
