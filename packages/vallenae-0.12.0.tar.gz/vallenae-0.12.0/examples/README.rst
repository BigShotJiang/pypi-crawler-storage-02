Examples
========

A collection of examples how to read and analyse Acoustic Emission data.
