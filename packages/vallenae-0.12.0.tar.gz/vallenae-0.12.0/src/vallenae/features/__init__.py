"""
Features
========

Acoustic Emission
-----------------

.. autosummary::
    :toctree: features

    peak_amplitude
    peak_amplitude_index
    is_above_threshold
    first_threshold_crossing
    last_threshold_crossing
    duration
    rise_time
    energy
    signal_strength
    counts
    rms

Conversion
----------

.. autosummary::
    :toctree: features

    amplitude_to_db
    db_to_amplitude
"""

# flake8: noqa

from .acoustic_emission import *
from .conversion import *

__all__ = [_ for _ in dir() if not _.startswith("_")]
