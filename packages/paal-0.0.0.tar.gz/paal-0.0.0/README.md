it's like graal but for python. just kidding, it's empty.
