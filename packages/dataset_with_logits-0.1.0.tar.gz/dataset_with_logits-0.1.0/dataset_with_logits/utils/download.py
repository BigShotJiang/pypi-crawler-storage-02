"""
Download utilities for prediction files from GitHub repository with Git LFS.
"""

import os
import urllib.request
import urllib.parse
from typing import Dict, List, Optional


# GitHub repository configuration
GITHUB_REPO = "ViGeng/predictions-on-datasets"
GITHUB_RAW_BASE = f"https://github.com/{GITHUB_REPO}/raw/main"

# Available datasets and models
AVAILABLE_DATASETS = {
    'imagenet1k': {
        'resnet18': 'ResNet-18 (11.7M parameters)',
        'resnet50': 'ResNet-50 (25.6M parameters)', 
        'resnet101': 'ResNet-101 (44.5M parameters)',
        'resnet152': 'ResNet-152 (60.2M parameters)',
        'vit_b_16': 'Vision Transformer Base (86M parameters)',
        'vit_l_16': 'Vision Transformer Large (304M parameters)',
        'mobilenet_v3_small': 'MobileNet V3 Small (2.5M parameters)',
        'mobilenet_v3_large': 'MobileNet V3 Large (5.5M parameters)',
    },
    'cifar10': {
        'resnet18': 'ResNet-18 for CIFAR-10',
        'vit_b_16': 'Vision Transformer Base for CIFAR-10',
    },
    'cifar100': {
        'resnet50': 'ResNet-50 for CIFAR-100',
    }
}


def get_cache_dir() -> str:
    """Get the default cache directory for downloaded files."""
    home_dir = os.path.expanduser("~")
    cache_dir = os.path.join(home_dir, ".cache", "dataset_with_logits")
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir


def list_available_models(dataset: Optional[str] = None) -> Dict[str, Dict[str, str]]:
    """
    List all available prediction models.
    
    Args:
        dataset: If specified, return models only for this dataset.
        
    Returns:
        Dictionary mapping dataset names to available models.
    """
    if dataset is None:
        return AVAILABLE_DATASETS
    elif dataset in AVAILABLE_DATASETS:
        return {dataset: AVAILABLE_DATASETS[dataset]}
    else:
        available = list(AVAILABLE_DATASETS.keys())
        raise ValueError(f"Dataset '{dataset}' not available. Available: {available}")


def construct_filename(dataset: str, model: str, version: str = "v0.1.0") -> str:
    """
    Construct the filename for prediction files.
    
    Args:
        dataset: Dataset name (e.g., 'imagenet1k', 'cifar10').
        model: Model name (e.g., 'resnet18', 'vit_l_16').
        version: Version string (e.g., 'v0.1.0').
        
    Returns:
        Filename following the pattern: {model}-{dataset}-{version}.csv
    """
    return f"{model}-{dataset}-{version}.csv"


def construct_github_url(dataset: str, model: str, version: str = "v0.1.0") -> str:
    """
    Construct the GitHub raw URL for downloading prediction files.
    
    Args:
        dataset: Dataset name.
        model: Model name.
        version: Version string.
        
    Returns:
        Full URL to the prediction file on GitHub.
    """
    filename = construct_filename(dataset, model, version)
    return f"{GITHUB_RAW_BASE}/dataset_processing/predictions/{dataset}/{filename}"


def download_predictions(
    dataset: str,
    model: str,
    version: str = "latest",
    cache_dir: Optional[str] = None,
    force_download: bool = False
) -> str:
    """
    Download prediction file from GitHub repository with Git LFS support.
    
    Args:
        dataset: Dataset name (e.g., 'imagenet1k', 'cifar10').
        model: Model name (e.g., 'resnet18', 'vit_l_16').
        version: Version to download ('latest' or specific version like 'v0.1.0').
        cache_dir: Directory to save the file. If None, uses default cache dir.
        force_download: Whether to re-download even if file exists locally.
        
    Returns:
        Path to the downloaded file.
        
    Raises:
        ValueError: If dataset/model combination is not available.
        RuntimeError: If download fails.
    """
    # Validate inputs
    if dataset not in AVAILABLE_DATASETS:
        available = list(AVAILABLE_DATASETS.keys())
        raise ValueError(f"Dataset '{dataset}' not available. Available: {available}")
    
    if model not in AVAILABLE_DATASETS[dataset]:
        available = list(AVAILABLE_DATASETS[dataset].keys())
        raise ValueError(f"Model '{model}' not available for {dataset}. Available: {available}")
    
    # Handle version
    if version == "latest":
        version = "v0.1.0"  # Default to latest stable version
    
    # Set up paths
    if cache_dir is None:
        cache_dir = get_cache_dir()
    
    filename = construct_filename(dataset, model, version)
    local_path = os.path.join(cache_dir, filename)
    
    # Check if file already exists and we don't want to force download
    if os.path.exists(local_path) and not force_download:
        print(f"Using cached predictions: {local_path}")
        return local_path
    
    # Download the file
    url = construct_github_url(dataset, model, version)
    print(f"Downloading {filename}...")
    print(f"From: {url}")
    
    try:
        # Create directory if it doesn't exist
        os.makedirs(cache_dir, exist_ok=True)
        
        # Download with progress (for large files)
        def show_progress(block_num, block_size, total_size):
            if total_size > 0:
                percent = min(100, (block_num * block_size * 100) // total_size)
                print(f"\rProgress: {percent}%", end="", flush=True)
        
        urllib.request.urlretrieve(url, local_path, reporthook=show_progress)
        print(f"\nDownloaded to: {local_path}")
        
        return local_path
        
    except Exception as e:
        # Clean up partial download
        if os.path.exists(local_path):
            os.remove(local_path)
        
        raise RuntimeError(
            f"Failed to download {filename} from GitHub. "
            f"Error: {str(e)}. "
            f"Please check if the file exists at: {url}"
        )


def check_file_exists_on_github(dataset: str, model: str, version: str = "v0.1.0") -> bool:
    """
    Check if a prediction file exists on GitHub without downloading it.
    
    Args:
        dataset: Dataset name.
        model: Model name.  
        version: Version string.
        
    Returns:
        True if file exists, False otherwise.
    """
    url = construct_github_url(dataset, model, version)
    
    try:
        request = urllib.request.Request(url, method='HEAD')
        urllib.request.urlopen(request)
        return True
    except:
        return False


def clear_cache(cache_dir: Optional[str] = None) -> None:
    """
    Clear the downloaded predictions cache.
    
    Args:
        cache_dir: Cache directory to clear. If None, clears default cache dir.
    """
    if cache_dir is None:
        cache_dir = get_cache_dir()
    
    if os.path.exists(cache_dir):
        import shutil
        shutil.rmtree(cache_dir)
        print(f"Cache cleared: {cache_dir}")
    else:
        print("Cache directory doesn't exist.")
