# -*- coding: utf-8 -*-

from .home_secret import hs
