"""Actions defined in fabricatio-translate."""
