"""Workflows defined in fabricatio-translate."""
