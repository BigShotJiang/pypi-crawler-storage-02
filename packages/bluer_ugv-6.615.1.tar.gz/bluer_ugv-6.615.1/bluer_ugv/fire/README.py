from bluer_objects.README.items import ImageItems

assets2 = "https://github.com/kamangir/assets2/blob/main/bluer-fire"

items = ImageItems({})
