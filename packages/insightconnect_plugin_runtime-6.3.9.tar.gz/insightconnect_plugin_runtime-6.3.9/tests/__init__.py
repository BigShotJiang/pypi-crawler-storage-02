import sys
import os

# For python 2
sys.path.append(os.path.realpath(os.path.dirname(__file__) + "/.."))
