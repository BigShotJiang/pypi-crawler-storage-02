# -*- coding: utf-8 -*-
from .step import Step


class Action(Step):
    """
    Represents a Komand Action.
    """

    pass
