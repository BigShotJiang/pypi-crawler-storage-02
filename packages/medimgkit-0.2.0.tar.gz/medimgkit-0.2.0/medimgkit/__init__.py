"""Medical Image Utils - Utilities for working with medical images."""
import importlib.metadata

__version__ = importlib.metadata.version(__name__)

