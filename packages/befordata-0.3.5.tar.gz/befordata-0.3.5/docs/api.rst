API Reference
=============

.. automodule:: befordata


.. toctree::
   :maxdepth: 1

   beforrecord
   beforepochs
   module_tools
   module_csv

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`