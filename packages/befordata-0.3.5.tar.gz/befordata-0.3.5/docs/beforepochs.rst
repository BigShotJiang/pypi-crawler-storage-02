
BeForEpochs
==========

.. autoclass:: befordata.BeForEpochs
   :members:
   :member-order: bysource

