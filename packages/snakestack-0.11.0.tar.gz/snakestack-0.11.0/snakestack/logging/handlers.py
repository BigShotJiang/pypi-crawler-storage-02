HANDLERS = {
    "console": {
        "class": "logging.StreamHandler",
        "formatter": "default",
    }
}
