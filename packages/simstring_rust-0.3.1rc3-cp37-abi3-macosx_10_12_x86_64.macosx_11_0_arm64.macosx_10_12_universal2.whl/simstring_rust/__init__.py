from .simstring_rust import *

__doc__ = simstring_rust.__doc__
if hasattr(simstring_rust, "__all__"):
    __all__ = simstring_rust.__all__