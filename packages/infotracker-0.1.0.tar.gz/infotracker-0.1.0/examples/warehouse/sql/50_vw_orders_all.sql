CREATE VIEW dbo.vw_orders_all AS
SELECT *
FROM dbo.Orders; 