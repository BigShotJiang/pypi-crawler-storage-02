CREATE VIEW dbo.vw_products_all AS
SELECT *
FROM dbo.Products; 