# --------------------
## holds references to common values and objects
class svc:  # pylint: disable=invalid-name,too-few-public-methods
    ## whether logging is verbose or not
    verbose = True
    ## reference to the logger
    log = None
