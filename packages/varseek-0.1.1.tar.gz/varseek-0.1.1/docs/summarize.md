🔝💯
Input table
| Parameter                                                           | File type                               | Required?           | Default Path                                                                  | Description             |
|----------------------------------------------------------------|--------------------------------------|------------------------|-------------------------------------------------------------------------|--------------------------|
| adata                                                                   | .h5ad                                   | True                    | N/A                                                                                | ...                           |


Output table
| Parameter                     | File type         | Flag                      | Default Path                                         | Description           |
|--------------------------------|--------------------|-------------------------|----------------------------------------------------|-------------------------|
| out                                | directory         | N/A                        | "."                                                         | ...                          |
| stats_file                  	   | .txt                  | N/A                        | <out>/varseek_summarize_stats.txt	  | ...                          |
| specific_stats_folder    | directory         | N/A                        | <out>/specific_stats	                          | ...                          |
| plots_folder                  | directory         | N/A                        | <out>/plots											  | ...                          | 