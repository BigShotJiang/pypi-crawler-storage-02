"""varseek package main import."""

from .main import main

main()
