from hivemind_worker import worker_node
worker_node.run_worker_node()
