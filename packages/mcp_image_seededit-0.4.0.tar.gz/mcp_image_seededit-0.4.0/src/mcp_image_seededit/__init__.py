"""MCP Image SeedEdit Server

一个基于火山引擎视觉能力的MCP服务器，提供图像指令编辑和人物写真生成功能。
"""

__version__ = "0.4.0"
__author__ = "fengjinchao"
__email__ = "your-email@example.com"

from .main import *