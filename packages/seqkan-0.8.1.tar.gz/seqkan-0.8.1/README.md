# seqKAN

This paper proposes seqKAN, a KAN architecture for sequence
processing.

All files under src/kan/ are taken from https://github.com/KindXiaoming/pykan/releases/tag/v0.2.8.