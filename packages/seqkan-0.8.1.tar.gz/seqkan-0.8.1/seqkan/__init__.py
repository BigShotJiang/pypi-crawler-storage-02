from .kan import KAN
from .model import seqKAN, seqKAN_wide
from .train import train
