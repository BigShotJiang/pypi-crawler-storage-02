"""Version information for cloudburst-fargate package"""

__version__ = "1.0.1"
__version_info__ = tuple(int(i) for i in __version__.split("."))