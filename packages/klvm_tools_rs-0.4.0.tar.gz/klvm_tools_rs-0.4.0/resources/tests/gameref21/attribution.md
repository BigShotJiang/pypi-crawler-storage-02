# Attribution

Source files from https://github.com/bramcohen/chik-gaming

Collected here as a standard compiler regression test
