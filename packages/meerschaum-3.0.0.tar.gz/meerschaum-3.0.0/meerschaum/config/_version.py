"""
Specify the Meerschaum release version.
"""

__version__ = "3.0.0"
