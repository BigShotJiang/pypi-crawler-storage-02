mammos-units
============

``mammos-units`` provides functionality to work with quantities (numbers with
units) based on astropy.units. The :quickstart: introduces the most important
concepts. Other notebooks provide more in-depth information.

.. toctree::
   :maxdepth: 1

   quickstart
   example
