__title__ = "Django Inscode"
__version__ = "0.1"
