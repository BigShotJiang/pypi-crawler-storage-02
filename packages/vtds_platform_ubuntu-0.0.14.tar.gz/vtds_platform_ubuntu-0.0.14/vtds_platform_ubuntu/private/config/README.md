# Ubuntu Platform Layer Base Configuration

Base configuration supplied by the Ubuntu Platform Layer implementation

