from robot_image.screen_shot import Screenshot

if __name__ == "__main__":
    screenshot = Screenshot()
