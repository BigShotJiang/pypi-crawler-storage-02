"""Top-level package for temp_interpolation."""

__author__ = """Ishwar Nalawade"""
__email__ = "ishwarn93@gmail.com"
__version__ = "0.1.0"

from .temp_interpolation import *
