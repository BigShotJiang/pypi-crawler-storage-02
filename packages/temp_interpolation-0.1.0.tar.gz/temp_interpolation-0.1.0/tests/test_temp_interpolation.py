#!/usr/bin/env python

"""Tests for `temp_interpolation` package."""


import unittest

from temp_interpolation import temp_interpolation


class TestTemp_interpolation(unittest.TestCase):
    """Tests for `temp_interpolation` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
