# foliummap module

::: temp_interpolation.foliummap