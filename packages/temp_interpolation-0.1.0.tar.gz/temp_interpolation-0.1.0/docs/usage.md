# Usage

To use temp_interpolation in a project:

```
import temp_interpolation
```
