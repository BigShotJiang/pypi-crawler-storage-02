{
  "name": "FarsTail",
  "version": "1.0.0",
  "task": "Textual-Entailment",
  "splits": ["train", "test", "val"],
  "description": "source: https://github.com/dml-qom/FarsTail",
  "size" : {"train": 7266, "test": 1564, "val": 1537},
  "filenames": ["Train-word.csv", "Test-word.csv", "Val-word.csv"]
}
