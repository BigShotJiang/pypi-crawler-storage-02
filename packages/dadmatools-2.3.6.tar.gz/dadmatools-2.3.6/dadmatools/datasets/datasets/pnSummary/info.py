{
  "name": "PnSummary",
  "version": "1.0.0",
  "task": "Summarization",
  "splits": ["train", "test", "dev"],
  "description": "source: https://github.com/hooshvare/pn-summary",
  "size" : {"train": 13179, "dev": 1469, "test":5503},
  "filenames": ["pn_summary/train.csv", "pn_summary/test.csv", "pn_summary/dev.csv"]
}
