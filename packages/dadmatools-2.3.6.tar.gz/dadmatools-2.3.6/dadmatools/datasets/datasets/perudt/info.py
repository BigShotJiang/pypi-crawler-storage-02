{
  "name": "PerUDT",
  "version": "1.0.0",
  "task": "Treebank",
  "splits": ["train", "test", "dev"],
  "description": "The Persian Universal Dependency Treebank (PerUDT) is the result of automatic coversion of Persian Dependency Treebank (PerDT) with extensive manual corrections",
  "size": {"train": 26196, "test":  1455, "dev":  1456},
  "filenames": ["fa_perdt-ud-train.conllu", "fa_perdt-ud-dev.conllu", "fa_perdt-ud-test.conllu"]
}

