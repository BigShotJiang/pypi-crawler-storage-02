{
  "name": "Peyma",
  "version": "1.0.0",
  "task": "NER",
  "splits": [],
  "description": "source: http://nsurl.org/2019-2/tasks/task-7-named-entity-recognition-ner-for-farsi/",
  "size" : 10016,
  "filenames": ["peyma/600K", "peyma/300K" ]
}
