{
  "name": "PersianNer",
  "version": "1.0.0",
  "task": "NER",
  "splits": [],
  "description": "source: https://github.com/Text-Mining/Persian-NER",
  "size" : 976599,
  "filenames": ["Persian-NER-part1.txt", "Persian-NER-part2.txt", "Persian-NER-part3.txt", "Persian-NER-part4.txt", "Persian-NER-part5.txt"]
}
