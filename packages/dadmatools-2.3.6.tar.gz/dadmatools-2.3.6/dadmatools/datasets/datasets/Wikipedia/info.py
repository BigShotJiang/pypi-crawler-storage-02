{
  "name": "WikipediaCorpus",
  "version": "20211201",
  "task": "Corpus",
  "description": "fawiki dump progress on 20211201 / All pages, current versions only.",
  "size": 2184117,
  "filenames": ["cleaned_wiki.txt"]
}
