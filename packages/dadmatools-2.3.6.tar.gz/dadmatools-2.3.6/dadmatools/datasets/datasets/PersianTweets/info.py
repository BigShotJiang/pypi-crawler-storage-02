{
  "name": "PersianTweets",
  "version": "2020",
  "task": "Corpus",
  "splits": [],
  "description": "LSCP: Enhanced Large Scale Colloquial Persian Language Understanding <br>\nLearn more about this study at https://iasbs.ac.ir/~ansari/lscp/",
  "size": 20665964,
  "filenames": ["lscp-0.5-fa-normalized.txt"]
}
