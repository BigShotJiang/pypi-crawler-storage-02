{
  "name": "TEP",
  "version": "1.0.0",
  "task": "Translation",
  "splits": [],
  "description": "TEP: Tehran English-Persian parallel corpus",
  "size" : 612086,
  "filenames": ["TEP.en-fa.en", "TEP.en-fa.fa"]
}
