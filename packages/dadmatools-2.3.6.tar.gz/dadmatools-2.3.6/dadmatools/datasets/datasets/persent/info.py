{
  "name": "PerSent",
  "version": "1.0.0",
  "task": "SA",
  "splits": [],
  "description": "persent lexicon",
  "size": 1490,
  "filenames": ["PerSent.xlsx"]
}
