{
    "fasttext-commoncrawl-bin": {"filename":"cc.fa.300.bin", "url": "https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.fa.300.bin.gz", "format":"bin" ,"algorithm":"fasttext", "desc": "", "corpus": "CommonCrawl", "dim": 300},
    "fasttext-commoncrawl-vec": {"filename":"cc.fa.300.vec", "url": "https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.fa.300.vec.gz","format":"vec", "algorithm": "fasttext", "desc": "", "corpus": "CommonCrawl", "dim": 300},
    "word2vec-conll": { "filename":"model.bin", "url": "http://vectors.nlpl.eu/repository/20/61.zip", "algorithm": "word2vec", "format":"bin", "desc": "Word2Vec Continuous Skipgram", "corpus": "Persian CoNLL17 corpus", "dim": 100},
    "glove-wiki": { "filename":"vectors.txt", "url": "https://raw.githubusercontent.com/Text-Mining/Persian-Wikipedia-Corpus/master/models/glove/vectors.zip", "algorithm": "glove", "format":"txt",  "desc": "source: https://github.com/Text-Mining", "corpus": "wikipedia", "dim": 50}
}