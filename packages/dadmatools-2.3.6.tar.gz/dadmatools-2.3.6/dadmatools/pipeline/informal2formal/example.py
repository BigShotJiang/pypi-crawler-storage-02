from dadmatools.informal2formal import Informal2Formal 
translator = Informal2Formal()

print(translator.translate('اینو اگه خواستین میتونین تست کنین واسه تبدیل'))