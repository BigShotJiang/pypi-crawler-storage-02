from setuptools import setup

setup(
    name='co_automation',
    version='0.1.22',
    description='A Python package to create servicenow change order',
    url='',
    author='',
    author_email='',
    license='BSD 2-clause',
    packages=['co_automation'],
    install_requires=[],
    classifiers=[
    ],
)