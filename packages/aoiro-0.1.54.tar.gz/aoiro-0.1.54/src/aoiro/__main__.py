"""Make the CLI runnable using python -m aoiro."""

from .cli import app

app()
