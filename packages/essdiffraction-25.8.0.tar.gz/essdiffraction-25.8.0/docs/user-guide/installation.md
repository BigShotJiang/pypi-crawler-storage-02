# Installation

To install ESSdiffraction and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install essdiffraction
```
````
````{tab-item} conda
```sh
conda install -c conda-forge -c scipp essdiffraction
```
````
`````
