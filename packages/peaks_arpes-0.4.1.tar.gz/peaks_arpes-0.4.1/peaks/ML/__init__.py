"""Functions that utilise machine learning techniques for analysis."""
