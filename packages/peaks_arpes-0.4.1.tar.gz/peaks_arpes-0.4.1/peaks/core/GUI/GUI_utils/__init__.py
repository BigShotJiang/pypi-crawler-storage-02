"""General utility functions used to generate pyqt GUIs."""
