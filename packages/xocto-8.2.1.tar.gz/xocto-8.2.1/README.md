# xocto - utilities for Python services

Proven utilities used on Python services at Kraken Technologies. This library
works with Python 3.9 and above.

CI status:

[![CircleCI](https://circleci.com/gh/octoenergy/xocto/tree/main.svg?style=svg)](https://circleci.com/gh/octoenergy/xocto/tree/main)

Docs status:

[![Documentation Status](https://readthedocs.org/projects/xocto/badge/?version=latest)](https://xocto.readthedocs.io/en/latest/?badge=latest)

- PyPI detail page: <https://pypi.python.org/pypi/xocto>
- Documentation: <https://xocto.readthedocs.io/>
