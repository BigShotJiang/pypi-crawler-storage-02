DATA_TYPES = [
    "Integer",
    "Float",
    "String",
    "Timestamp",
    "Boolean"
]
