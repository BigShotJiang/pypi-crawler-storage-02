import importlib.metadata
# set the version attribute to one can do print(prodimopy.__version__)
__version__=importlib.metadata.version("prodimopy")
