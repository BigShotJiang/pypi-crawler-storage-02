"""
Constants
"""

DEFAULT_CONN_ID = "wherobots_default"
PACKAGE_NAME = "airflow-providers-wherobots"
