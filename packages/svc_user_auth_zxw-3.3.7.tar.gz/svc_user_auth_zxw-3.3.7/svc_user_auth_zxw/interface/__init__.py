"""
# File       : __init__.py
# Time       ：2024/12/19
# Author     ：xuewei zhang
# Email      ：shuiheyangguang@gmail.com
# version    ：python 3.12
# Description：接口层，用于处理业务逻辑
""" 