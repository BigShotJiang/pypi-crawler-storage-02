"""
# File       : func_获取邀请码.py
# Time       ：2025/7/3 13:12
# Author     ：xuewei zhang
# Email      ：shuiheyangguang@gmail.com
# version    ：python 3.12
# Description：
"""
from svc_user_auth_zxw.tools.func_用户id加密 import user_id_to_invite_code

