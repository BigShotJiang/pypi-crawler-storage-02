Each test folder contains the output from a bader run I considered successful.
These can be recreated by running the bader class than writing to file with bader.write_results_summary()
