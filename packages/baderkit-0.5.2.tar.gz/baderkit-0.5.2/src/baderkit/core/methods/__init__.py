# -*- coding: utf-8 -*-

method_names = [
    "ongrid",
    "neargrid",
    "weight",
]
