"""Module contains loggers for different parts of the app"""

from boosty_downloader.src.infrastructure.loggers.base import RichLogger

downloader_logger = RichLogger('Boosty_Downloader')
