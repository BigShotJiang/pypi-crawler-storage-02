"""All constants for endpoints."""

BOOSTY_DEFAULT_BASE_URL = 'https://api.boosty.to/v1/'
