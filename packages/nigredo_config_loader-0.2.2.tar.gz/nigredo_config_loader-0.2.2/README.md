# Nigredo Config Loader

A simple parser for a custom configuration file format that supports data types, lists, and dictionaries.

## Install

```bash
pip install nigredo-config-loader