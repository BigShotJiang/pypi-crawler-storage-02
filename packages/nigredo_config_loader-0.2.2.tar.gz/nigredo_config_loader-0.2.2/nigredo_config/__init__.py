from .loader import load, get, items, get_template

__version__ = "0.2.2"
__author__ = "stavrmoris"