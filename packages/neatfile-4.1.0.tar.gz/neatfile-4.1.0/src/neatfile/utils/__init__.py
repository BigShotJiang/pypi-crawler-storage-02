"""Utility functions for the neatfile package."""

from .nlp import nlp

__all__ = ["nlp"]
