"""
Tests for Pipecat Tools library.
""" 