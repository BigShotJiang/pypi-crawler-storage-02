# HTML to Inky

This example requires `firefox-esr`, install with:

```
sudo apt install firefox-esr
```

Then run:

```
./html.sh hello-world.html
```

