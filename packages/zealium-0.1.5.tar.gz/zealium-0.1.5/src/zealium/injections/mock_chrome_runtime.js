(function() {
    window.chrome = {
        runtime: {}
    };
})();