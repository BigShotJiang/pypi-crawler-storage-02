"""
Test package for StatClean
""" 