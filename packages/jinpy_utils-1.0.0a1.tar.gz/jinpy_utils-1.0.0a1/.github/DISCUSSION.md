# Discussions

Use GitHub Discussions for Q&A, design proposals, and general ideas.

- Start here: https://github.com/jinto-ag/jinpy-utils/discussions
- For bugs and actionable tasks, please open an Issue instead.

Guidelines:
- Be respectful and constructive.
- Provide context and examples.
- Avoid sharing sensitive information.
