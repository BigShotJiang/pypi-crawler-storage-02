# CHANGELOG

<!-- version list -->

## v0.0.0-alpha.1 (2025-08-12)

- Initial Release

## v0.0.0-alpha.5 (2025-08-12)

### Continuous Integration

- Run CI on pushes to main for release gating
  ([`39b99e6`](https://github.com/jinto-ag/jinpy-utils/commit/39b99e67d60a881347e47b0c1f78a9be5f360106))


## v0.0.0-alpha.4 (2025-08-12)

### Continuous Integration

- **publish**: Publish on tag push or release event; ensure full history and tag checkout for
  hatch-vcs
  ([`8c46df1`](https://github.com/jinto-ag/jinpy-utils/commit/8c46df112f6a6315f99202fe95b8fa56da9c6ba0))


## v0.0.0-alpha.3 (2025-08-12)

### Chores

- **rename**: Use 'jinpy-utils' name consistently across repo
  ([`c461ca3`](https://github.com/jinto-ag/jinpy-utils/commit/c461ca3fabb8211bc8f7fa1664edea23d97ea84e))


## v0.0.0-alpha.2 (2025-08-12)

### Documentation

- Rename references to jinpy-utils package/repo name
  ([`926b829`](https://github.com/jinto-ag/jpy-utils/commit/926b8299f7dc69511fe19ade09276f2e9ada3ba5))


## v0.0.0-alpha.1 (2025-08-12)

- Initial Release

## v1.0.0 (2025-08-12)

- Initial Release
