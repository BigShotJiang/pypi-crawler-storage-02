"""A simple, interactive zoo habitat viewer using ASCII art."""
