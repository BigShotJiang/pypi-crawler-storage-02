"""A command-line tool for calculating loan payments."""
