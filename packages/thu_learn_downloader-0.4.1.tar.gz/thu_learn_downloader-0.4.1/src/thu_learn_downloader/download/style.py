from rich.style import Style

DOCUMENT: Style = Style(color="cyan")
HOMEWORK: Style = Style(color="magenta")
