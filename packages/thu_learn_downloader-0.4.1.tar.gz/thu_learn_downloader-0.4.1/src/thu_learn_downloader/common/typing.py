def cast(typ, val):
    assert isinstance(val, typ)
    return val
