# utilities/__init__.py

from .ffmap import run_ffmap
from .groconv import run_groconv

# Now you can do
# from gmx_ffconv.utilities import run_ffmap, run_groconv