# Datahub Airflow Plugin

See [the DataHub Airflow docs](https://docs.datahub.com/docs/lineage/airflow) for details.

## Developing

See the [developing docs](../../metadata-ingestion/developing.md).
