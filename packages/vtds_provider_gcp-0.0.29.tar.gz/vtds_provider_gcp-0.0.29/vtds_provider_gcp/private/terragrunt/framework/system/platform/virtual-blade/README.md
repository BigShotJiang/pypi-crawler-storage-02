# Virtual Blade Classes

This directory is a placeholder for the Virtual Blade classes defined
by the configuration and constructed by the GCP implementation of the
vTDS Provider layer. In GCP Virtual Blades are constructed from GCP VM
Instances and these VM instances are built from GCP instance
templates. Each Virtual Blade class provides the deployment
instructions for the instances and instance templates used to
construct the virtual blades in that class.
