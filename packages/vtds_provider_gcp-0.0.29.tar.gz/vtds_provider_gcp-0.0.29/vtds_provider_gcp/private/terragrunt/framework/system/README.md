# vTDS System Resources

In GCP a vTDS system consists of a GCS project, a set of VPCs (networks)
carrying either external network connectivity or the Blade Interconnect
networks, and a platform definition which establishes Virtual Blades
(GCP instances)  and subnets implementing Blade Interconnect and
External Connection networks.
