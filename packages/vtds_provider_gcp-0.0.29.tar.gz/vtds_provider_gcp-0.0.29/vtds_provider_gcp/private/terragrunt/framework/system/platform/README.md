# vTDS Platform Resources

This directory is a placeholder for the deployment data tree for the
primary vTDS platform resources. The sub-directories here further
sub-divide the resources into their specific kinds within the vTDS
architecture (Virtual Blade, Blade Interconect, and so forth) by
sub-directory. The provider implementation constructs deployments for
each class of a given resource type in the appropriate sub-directory.
