# LlamaIndex Embeddings Integration: Ollama
