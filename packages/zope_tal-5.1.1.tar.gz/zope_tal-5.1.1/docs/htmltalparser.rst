============================
 Parsing and Compiling HTML
============================

.. automodule:: zope.tal.htmltalparser
