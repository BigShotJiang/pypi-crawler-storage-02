====================
 Common Definitions
====================

.. automodule:: zope.tal.taldefs
