# User Guide

## Installation
Aiaccel supports 3.10 and later. You can install aiaccel by:
```bash
python -m pip install aiaccel
```

## Contents
```{toctree}
:maxdepth: 1
torch
hpo
config
```
