# Example of Training a PyTorch Model on ABCI 3.0

## Getting started
```bash
qsub -P [group_name] resnet50/train.sh
```

```bash
qsub -P [group_name] resnet50_ddp/train.sh
```

## Detailed Descriptions
Detailed descriptions are available on the [aiaccel document](https://aistairc.github.io/aiaccel/user_guide/torch.html)