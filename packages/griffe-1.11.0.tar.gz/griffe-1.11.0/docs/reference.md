# Reference

Our reference pages contain comprehensive information on various aspects of Griffe, such as its Command Line Interface (CLI), its Application Programming Interface (API), or its docstring parsers.

- [Command Line Interface](reference/cli.md)
- [Application Programming Interface](reference/api.md)
- [Docstring parsers](reference/docstrings.md)
