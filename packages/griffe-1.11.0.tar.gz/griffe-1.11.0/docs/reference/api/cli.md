# CLI entrypoints

## **Main API**

::: griffe.main

::: griffe.check

::: griffe.dump

## **Advanced API**

::: griffe.get_parser
