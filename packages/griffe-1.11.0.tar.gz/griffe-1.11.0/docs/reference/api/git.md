# Git utilities

::: griffe.assert_git_repo

::: griffe.get_latest_tag

::: griffe.get_repo_root

::: griffe.tmp_worktree
