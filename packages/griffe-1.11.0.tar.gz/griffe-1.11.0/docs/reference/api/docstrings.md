# Docstrings

Docstrings are [parsed](docstrings/parsers.md) and the extracted information is structured in [models](docstrings/models.md).
