from umlio._version import __version__
