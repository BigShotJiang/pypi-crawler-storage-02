Este módulo estende o módulo sale do Odoo para adaptá-lo as necessidades
brasileira, com este módulo você tem dados fiscal para faturamento e
geração dos documentos fiscais (NF-e, NFS-e, CF-e, NFC-e e etc.),
cálculo dos impostos e contribuições brasileiros (municipais, estaduais
e federal).
