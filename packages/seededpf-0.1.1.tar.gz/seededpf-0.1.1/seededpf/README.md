# Seeded Poisson Factorization

Source code for the Seeded Poisson factorization (SPF) topic model.

