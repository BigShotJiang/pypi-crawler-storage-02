"""
This protected module provides a place for classes that need to be
shared between different modules but will trigger circular import errors.
"""