from .pipeline_parts._image_pipeline_batch import ImagePipelineBatch
from .pipeline_parts._image_pipeline_core import ImagePipelineCore


class ImagePipeline(ImagePipelineCore):
    pass
