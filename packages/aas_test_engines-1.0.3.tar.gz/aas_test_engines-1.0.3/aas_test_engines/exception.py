class AasTestToolsException(Exception):
    pass


class InvalidFilterException(AasTestToolsException):
    pass
