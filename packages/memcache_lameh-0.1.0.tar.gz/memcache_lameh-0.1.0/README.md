# Memcache Lameh

A package for emcache caching operations.

## Installation

### Poetry (recommended)

```bash
poetry add memcache-lameh
```

### Pip

```bash
pip install memcache-lameh
```