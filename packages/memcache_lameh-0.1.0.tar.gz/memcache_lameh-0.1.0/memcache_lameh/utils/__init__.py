from .logger import logger
from .lib import is_gzipped

__all__ = ["logger", "is_gzipped"]