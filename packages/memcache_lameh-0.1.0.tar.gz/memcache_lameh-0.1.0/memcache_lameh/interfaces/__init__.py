from .emcache_client_interface import EmcacheClientInterface

__all__ = ["EmcacheClientInterface"]
