# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["TestcaseCreateParams", "Item"]


class TestcaseCreateParams(TypedDict, total=False):
    items: Required[Iterable[Item]]
    """Testcases to create (max 100)."""


class Item(TypedDict, total=False):
    json_data: Required[Annotated[Dict[str, object], PropertyInfo(alias="jsonData")]]
    """The JSON data of the Testcase, which is validated against the Testset's schema."""
