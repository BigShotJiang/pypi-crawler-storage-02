"""Display the page body."""

from reflex.components.el import elements


class Body(elements.Body):
    """A body component."""
