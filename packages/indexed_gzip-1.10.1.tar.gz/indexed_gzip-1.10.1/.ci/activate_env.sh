#!/usr/bin/env bash

set -e

envdir="$1"

source "$envdir"/bin/activate || source "$envdir"/Scripts/activate
