"""Command-line interface package for dir2text.

This package provides the command-line functionality for dir2text, allowing
users to generate tree representations and file contents from directories.
"""
