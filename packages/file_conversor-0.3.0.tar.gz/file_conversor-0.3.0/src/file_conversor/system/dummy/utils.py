# src\file_conversor\system\dummy\utils.py

def is_admin() -> bool:
    """True if app running with admin priviledges, False otherwise."""
    return False


def reload_user_path():
    """Reload user PATH in current process."""
    # dummy method
    pass
