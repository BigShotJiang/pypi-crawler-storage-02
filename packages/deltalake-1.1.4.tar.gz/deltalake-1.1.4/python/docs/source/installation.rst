Installation
====================================

Using Pip
---------
.. code-block:: bash

   pip install deltalake


NOTE: official binary wheels are linked against openssl statically for remote
objection store communication. Please file Github issue to request for critical
openssl upgrade.
