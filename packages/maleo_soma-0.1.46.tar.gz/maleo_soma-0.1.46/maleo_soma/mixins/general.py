from enum import StrEnum
from pydantic import BaseModel, Field
from typing import Generic, TypeVar, Union
from maleo_soma.enums.error import Error
from maleo_soma.enums.sort import SortOrder as SortOrderEnum
from maleo_soma.types.base import OptionalAny, OptionalBoolean, OptionalInteger


class ErrorType(BaseModel):
    type: Error = Field(..., description="Error type")


class StatusCode(BaseModel):
    status_code: int = Field(..., description="Status code")


class SortOrder(BaseModel):
    order: SortOrderEnum = Field(..., description="Sort order.")


SuccessT = TypeVar("SuccessT", bound=bool)


class GenericSuccess(BaseModel, Generic[SuccessT]):
    success: SuccessT = Field(..., description="Success")


class Success(BaseModel):
    success: bool = Field(..., description="Success")


CodeT = TypeVar("CodeT", bound=Union[str, StrEnum])


class Code(BaseModel, Generic[CodeT]):
    code: CodeT = Field(..., description="Code")


class Message(BaseModel):
    message: str = Field(..., description="Message")


class Description(BaseModel):
    description: str = Field(..., description="Description")


class Descriptor(Description, Message, Code[CodeT], Generic[CodeT]):
    pass


class Order(BaseModel):
    order: OptionalInteger = Field(..., description="Order")


class Key(BaseModel):
    key: str = Field(..., description="Key")


class Name(BaseModel):
    name: str = Field(..., description="Name")


class IsDefault(BaseModel):
    is_default: OptionalBoolean = Field(None, description="Whether is default")


class IsRoot(BaseModel):
    is_root: OptionalBoolean = Field(None, description="Whether is root")


class IsParent(BaseModel):
    is_parent: OptionalBoolean = Field(None, description="Whether is parent")


class IsChild(BaseModel):
    is_child: OptionalBoolean = Field(None, description="Whether is child")


class IsLeaf(BaseModel):
    is_leaf: OptionalBoolean = Field(None, description="Whether is leaf")


class OptionalOther(BaseModel):
    other: OptionalAny = Field(None, description="Other. (Optional)")


class OrganizationId(BaseModel):
    organization_id: int = Field(..., ge=1, description="Organization's ID")


class OptionalOrganizationId(BaseModel):
    organization_id: OptionalInteger = Field(
        None, ge=1, description="Organization's ID. (Optional)"
    )


class UserId(BaseModel):
    user_id: int = Field(..., ge=1, description="User's ID")


class OptionalUserId(BaseModel):
    user_id: OptionalInteger = Field(None, ge=1, description="User's ID. (Optional)")


class Age(BaseModel):
    age: int = Field(..., ge=1, description="Age")


class OptionalAge(BaseModel):
    age: OptionalInteger = Field(None, ge=1, description="Age")
