"""Semantic analysis module."""
