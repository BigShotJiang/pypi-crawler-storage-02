# ArxLang

Arx is multi-purpose compiler that aims to provide arrow datatypes as native
datatypes.

For now, it is strongly based on the Kaleidoscope compiler with a just few
changes.</p>

<br/>
## Arx Enhancement Proposals

Any change to the language (syntax) should be done using a Enhancement Proposal
via [arx-proposals](https://github.com/arxlang/arx-proposals) repository.
