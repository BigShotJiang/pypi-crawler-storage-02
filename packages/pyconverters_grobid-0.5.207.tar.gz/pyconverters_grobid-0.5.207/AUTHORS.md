# Authors

Contributors to pyconverters_grobid include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
