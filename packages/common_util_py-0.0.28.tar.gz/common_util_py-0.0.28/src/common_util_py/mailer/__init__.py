from .gmail import send_text as gmail_send_text
from .gmail import send_html as gmail_send_html
from .mailer import send_text as mail_send_text
from .mailer import send_html as mail_send_html
from .email import is_valid as is_email_address_valid