"""
Runtime will load the XBlock class from here.
"""
from .apps import LTIConsumerApp
from .lti_xblock import LtiConsumerXBlock

__version__ = '9.14.2'
