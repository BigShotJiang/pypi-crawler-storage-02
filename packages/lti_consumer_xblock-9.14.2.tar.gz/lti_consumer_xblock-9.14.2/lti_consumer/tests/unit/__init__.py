"""
Module containing unit tests for xblock-lti-consumer
"""
