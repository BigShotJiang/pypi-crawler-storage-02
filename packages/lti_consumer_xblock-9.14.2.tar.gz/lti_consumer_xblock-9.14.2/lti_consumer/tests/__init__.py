"""
Module containing tests for xblock-lti-consumer
"""
