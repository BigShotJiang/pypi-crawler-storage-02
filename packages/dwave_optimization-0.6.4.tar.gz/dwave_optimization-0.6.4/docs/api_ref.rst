.. _optimization_api_ref:

=============
API Reference
=============

.. toctree::
    :maxdepth: 2

    models
    generators
    math
    symbols
