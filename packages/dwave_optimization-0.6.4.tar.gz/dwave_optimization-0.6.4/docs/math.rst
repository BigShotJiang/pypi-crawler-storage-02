.. _optimization_math:

======================
Mathematical Functions
======================

.. currentmodule:: dwave.optimization

.. automodule:: dwave.optimization.mathematical
    :members:
