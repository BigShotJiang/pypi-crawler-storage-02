python3 -m unittest discover -b -f
python3 validation.py
python3 compare_C_and_Python_core.py 30
python3 test_integration_speed.py

