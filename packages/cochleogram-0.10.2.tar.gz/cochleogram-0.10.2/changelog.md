# 0.8.1

- Add ability to mark IHCs as supernumerary using ctrl + right-click.

# 0.7.4

- Fix bug in scrolling through z-slices when using up/down arrow keys when
  z-slice thickness is not constrained.
