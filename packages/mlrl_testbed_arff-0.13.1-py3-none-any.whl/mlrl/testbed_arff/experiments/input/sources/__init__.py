"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to read input data from ARFF files.
"""
from mlrl.testbed_arff.experiments.input.sources.source_arff import ArffFileSource
