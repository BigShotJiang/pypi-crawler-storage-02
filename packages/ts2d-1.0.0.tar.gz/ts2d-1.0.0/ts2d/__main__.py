if __name__ == '__main__':
    from ts2d.main import ts2d_entry_point
    ts2d_entry_point()