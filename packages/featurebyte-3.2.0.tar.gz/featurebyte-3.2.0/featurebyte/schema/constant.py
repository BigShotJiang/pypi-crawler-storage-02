"""
List of constants used in the featurebyte schema
"""

MAX_BATCH_FEATURE_ITEM_COUNT = 500
