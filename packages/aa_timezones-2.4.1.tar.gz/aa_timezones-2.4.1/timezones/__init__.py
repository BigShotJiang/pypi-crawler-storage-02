"""
Application init
"""

# Django
from django.utils.translation import gettext_lazy as _

__version__ = "2.4.1"
__title__ = _("Time Zones")
