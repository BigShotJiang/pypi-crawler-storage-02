import django.dispatch

event_logged = django.dispatch.Signal()
