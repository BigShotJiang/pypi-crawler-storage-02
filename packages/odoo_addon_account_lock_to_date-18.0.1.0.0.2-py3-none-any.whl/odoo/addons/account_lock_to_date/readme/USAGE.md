To set a new lock to dates, go to *Invoicing / Accounting / Actions /
Update accounting lock to dates*.

A user without an Adviser group will not be able to post or update
posted journal entries on the date "Lock To Date for Non-Advisers" or
after.

A user that has an Adviser group will not be able to post or update
posted journal entries on the date "Lock To Date" or after.
