__extension_version__ = "0.5.1"
__extension_name__ = "pytket-azure"
