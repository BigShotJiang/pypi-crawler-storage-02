2025-06-06 Version: 2.4.0
- Support API CreateToolset.
- Support API DeleteToolset.
- Support API GetToolset.
- Support API ListToolsets.
- Support API UpdateToolset.


2025-04-01 Version: 2.3.1
- Generated python 2023-07-14 for Devs.

2025-04-01 Version: 2.3.0
- Support API ActivateConnection.
- Support API DeleteConnection.
- Support API FetchConnectionCredential.
- Support API ListConnections.


2025-04-01 Version: 2.2.0
- Support API CreateArtifact.
- Support API DeleteArtifact.
- Support API FetchArtifactDownloadUrl.
- Support API FetchArtifactTempBucketToken.
- Support API GetArtifact.
- Support API GetServiceDeployment.
- Support API ListServiceDeployments.
- Support API PreviewEnvironment.
- Support API PutArtifact.
- Support API RenderServicesByTemplate.


2025-03-31 Version: 2.1.0
- Support API DeployEnvironment.
- Support API GetEnvironmentDeployment.


2025-03-28 Version: 2.0.0
- Delete API ActivateConnection.
- Delete API CreateConnection.
- Delete API CreatePipelineTemplate.
- Delete API CreatePipelineTrigger.
- Delete API CreatePipelineTriggerEvent.
- Delete API CreateRepository.
- Delete API CreateTaskTemplate.
- Delete API DeleteConnection.
- Delete API DeletePipelineTemplate.
- Delete API DeletePipelineTrigger.
- Delete API DeletePipelineTriggerEvent.
- Delete API DeleteRepository.
- Delete API DeleteTaskTemplate.
- Delete API FetchConnectionCredential.
- Delete API FetchRepositoryCheckout.
- Delete API GetConnection.
- Delete API GetPipelineTemplate.
- Delete API GetPipelineTrigger.
- Delete API GetPipelineTriggerEvent.
- Delete API GetTaskTemplate.
- Delete API ListConnections.
- Delete API ListPipelineTemplates.
- Delete API ListPipelineTriggerEvents.
- Delete API ListPipelineTriggers.
- Delete API ListRepositories.
- Delete API ListTaskTemplates.
- Delete API PutEnvironment.
- Delete API PutPipelineTemplate.
- Delete API PutPipelineTrigger.
- Delete API PutProject.
- Delete API PutTaskTemplate.
- Delete API RefreshConnection.
- Delete API UpdatePipelineTrigger.
- Update API CreateEnvironment: add request parameters projectName.
- Update API CreateEnvironment: delete request parameters project.
- Update API DeleteEnvironment: add request parameters projectName.
- Update API DeleteEnvironment: delete request parameters project.
- Update API DeleteProject: delete response parameters Body.
- Update API GetEnvironment: add request parameters projectName.
- Update API GetEnvironment: delete request parameters project.
- Update API ListEnvironments: add request parameters projectName.
- Update API ListEnvironments: delete request parameters project.
- Update API UpdateEnvironment: add request parameters projectName.
- Update API UpdateEnvironment: delete request parameters project.
- Update API UpdateProject: delete request parameters force.


2024-05-24 Version: 1.0.0
- Generated python 2023-07-14 for Devs.

