
def join(l: list, n: int, sep: str):
    return "\n".join([sep.join(l[i:i+n]) for i in range(0, len(l), n)])


