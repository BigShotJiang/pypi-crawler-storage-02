from django.apps import AppConfig


class GenericNotificationsConfig(AppConfig):
    name = "generic_notifications"
    verbose_name = "Generic Notifications"
