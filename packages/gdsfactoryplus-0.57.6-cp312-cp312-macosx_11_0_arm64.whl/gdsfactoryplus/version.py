"""Simply the GDSFactory+ version."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.57.6"
