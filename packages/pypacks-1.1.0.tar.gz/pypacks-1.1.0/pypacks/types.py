class PyPackType:
    JAVA = "java"
    BEDROCK = "bedrock"