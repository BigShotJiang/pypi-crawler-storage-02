interface
=========

.. automodule:: fabrictestbed_extensions.fablib.interface
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.interface.Interface
   :members:
   :special-members: __str__
