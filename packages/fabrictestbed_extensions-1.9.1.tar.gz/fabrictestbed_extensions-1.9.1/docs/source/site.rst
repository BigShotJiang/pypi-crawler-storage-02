site
====

.. automodule:: fabrictestbed_extensions.fablib.site
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.site.Site
   :members:
   :special-members: __str__

.. autoclass:: fabrictestbed_extensions.fablib.site.Switch
   :members:
   :special-members: __str__

.. autoclass:: fabrictestbed_extensions.fablib.site.Host
   :members:
   :special-members: __str__