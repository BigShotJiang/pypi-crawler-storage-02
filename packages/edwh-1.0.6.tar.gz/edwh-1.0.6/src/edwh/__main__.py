from .cli import program

if __name__ == "__main__":
    program.run()
