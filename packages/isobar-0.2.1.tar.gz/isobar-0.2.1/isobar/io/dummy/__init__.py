from .output import DummyOutputDevice

__all__ = ["DummyOutputDevice"]