from .receiver import NetworkGlobalsReceiver
from .sender import NetworkGlobalsSender