from .note_effect import NoteEffect, NoteEffectEcho, NoteEffectTranspose, NoteEffectScale

from .note_effect import NoteEffectEcho as fxecho
from .note_effect import NoteEffectTranspose as fxtranspose
from .note_effect import NoteEffectScale as fxscale