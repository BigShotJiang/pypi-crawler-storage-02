from __future__ import annotations  # noqa: D100

from meltano.cli import main

main()
