"""Bundled yaml files."""

from __future__ import annotations

import importlib.resources

root = importlib.resources.files(__package__)
