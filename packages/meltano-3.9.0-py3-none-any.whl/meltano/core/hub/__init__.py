"""Clients and APIs for interacting with Meltano Hub."""

from __future__ import annotations

from meltano.core.hub.client import MeltanoHubService

__all__ = ["MeltanoHubService"]
