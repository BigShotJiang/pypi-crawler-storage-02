"""SQL migration utilities."""

from __future__ import annotations
