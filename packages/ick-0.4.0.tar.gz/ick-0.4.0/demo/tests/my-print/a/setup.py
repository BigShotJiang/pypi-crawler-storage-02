print("x")
foo_print("y")
# print("z")
