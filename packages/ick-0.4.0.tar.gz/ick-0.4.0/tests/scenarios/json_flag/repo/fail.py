import sys

sys.tracebacklimit = 0  ##traceback must not show for testing

assert False
