from bafser import OperationsBase


class Operations(OperationsBase):
    pass
