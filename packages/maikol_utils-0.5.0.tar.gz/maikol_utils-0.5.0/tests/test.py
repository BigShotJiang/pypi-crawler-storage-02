from maikol_utils.file_utils import list_dir_files

print(list_dir_files("."))
print(list_dir_files(".", nat_sorting=False))
