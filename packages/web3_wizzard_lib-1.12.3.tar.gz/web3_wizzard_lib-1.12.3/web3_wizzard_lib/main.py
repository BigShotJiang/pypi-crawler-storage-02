from web3_wizzard_lib.launcher import launch

if __name__ == '__main__':
    launch()