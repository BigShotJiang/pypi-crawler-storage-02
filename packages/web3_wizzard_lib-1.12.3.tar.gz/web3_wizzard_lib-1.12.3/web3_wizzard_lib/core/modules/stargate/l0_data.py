l0_chain_ids = {
    'ARBITRUM': 110,
    'OPTIMISM': 111,
    'ZKSYNC': 165,
    'ARBITRUM_NOVA': 175,
    'LINEA': 183,
    'BASE': 184,
    'SCROLL': 214,
    'POLYGON': 109
}
