from setuptools import setup, find_packages

setup(
    name="firetrack_py_lib",  # Replace with unique name
    version="0.1.0",
    description="A simple greeting package",
    author="Your Name",
    author_email="you@example.com",
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
)
