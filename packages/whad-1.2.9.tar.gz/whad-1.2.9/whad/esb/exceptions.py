"""Enhanced ShockBurst domain exceptions
"""

class InvalidESBAddressException(Exception):
    """Invalid ESB address used
    """
