class ZDOObject:
    """
    Defines a ZDO Object.
    """
    def __init__(self, zdo):
        # Keep a reference on the ZDO manager.
        self.zdo = zdo
