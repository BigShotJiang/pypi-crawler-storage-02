from whad.zigbee.stack.apl.zcl.clusters.onoff import OnOffClient, OnOffServer
