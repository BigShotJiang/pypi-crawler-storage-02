from django.apps import AppConfig


class KanteConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "kante"
