# Ghidra-Jupyter

A Jupyter kernel (notebook & QtConsole) plugin for Ghidra.

Currently supporting [Kotlin-Jupyter](https://github.com/Kotlin/kotlin-jupyter).

For info and installation see the [github repo](https://github.com/GhidraJupyter/ghidra-jupyter-kotlin). 