echo "\033[0;33m:::::: Clean up after building documentation\033[0m"
rm -rf site/
rm -rf docs/assets/
rm -rf includes/
rm -rf overrides/
rm -rf docs/examples/
rm -rf node_modules/
rm mkdocs.yml
rm package-lock.json
rm package.json
