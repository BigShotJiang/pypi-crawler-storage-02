# API Reference

::: yatta.models
    options:
      show_source: false
