# API Reference

::: yatta.exceptions
    options:
      show_source: false
