# API Reference

::: yatta.client
    options:
      show_source: false
