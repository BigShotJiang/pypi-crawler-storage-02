# Project Name
A library with fast, computational math assets (mostly for personal use).