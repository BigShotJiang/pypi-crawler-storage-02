"""Configuration data for 10Duke API and OAuth interactions."""

from .tenduke_config import TendukeConfig

__all__ = ["TendukeConfig"]
