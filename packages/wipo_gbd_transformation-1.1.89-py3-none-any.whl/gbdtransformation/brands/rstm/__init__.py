render = 'JSON'
source = 'national'

# 201302148
appnum_mask = '\\d{4}(\\d*)'
