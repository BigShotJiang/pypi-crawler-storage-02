render = 'JSON'
source = 'national'

# M/1421805
# 11858
appnum_mask = [ '(M)/(\\d*)',
                '(\\d*)' ]
