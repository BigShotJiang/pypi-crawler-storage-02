render = 'JSON'
source = 'national'

# SD/T/1/037277
appnum_mask = 'SD/T/1/(\\d*)'
