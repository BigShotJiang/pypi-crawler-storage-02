render = 'JSON'
source = 'national'

# WS/M/1481897
# WS/T/1897
appnum_mask = 'WS/(M|T)/(\\d*[A-B]?)'
