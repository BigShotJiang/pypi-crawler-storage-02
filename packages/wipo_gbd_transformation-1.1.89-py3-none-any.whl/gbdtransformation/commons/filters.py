from gbdtransformation.common.filters import *

ignore_namespace = ['http://www.euipo.europa.eu/EUTM/EUTM_Download']
