## Requirements

- Python 3.6+
- Pydantic for the data parts.

## Installation

```
pip install pyimporters-skos-rf
```
