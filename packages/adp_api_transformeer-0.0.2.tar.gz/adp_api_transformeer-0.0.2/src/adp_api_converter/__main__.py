from . import convert_api_spec

if __name__ == "__main__":
    convert_api_spec()