# Netpicker Netbox plugin

## Installation

The plugin is available as a Python package in [pypi](https://pypi.org/project/slurpit_netbox/) and 
can be installed with pip (in the context of the netbox virtual/env):  

```
pip install --no-cache-dir netpicker-netbox-plugin
```
To enable and setup the plugin, run 
```
python -m netpicker.setup
```
Restart NetBox.
