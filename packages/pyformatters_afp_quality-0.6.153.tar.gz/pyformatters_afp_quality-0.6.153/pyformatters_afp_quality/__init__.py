"""Sherpa AFP Quality formatter"""
__version__ = "0.6.153"
