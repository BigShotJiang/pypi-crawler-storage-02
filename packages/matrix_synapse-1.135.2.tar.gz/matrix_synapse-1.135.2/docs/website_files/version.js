window.SYNAPSE_VERSION = "latest";
