from df_config.manage import manage

manage()
