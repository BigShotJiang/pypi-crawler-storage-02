"""Ramifice - Set of mixins for Models and Fields."""

__all__ = ("JsonMixin",)

from ramifice.utils.mixins.json_converter import JsonMixin
