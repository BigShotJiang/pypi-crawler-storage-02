from .assets import FileAssets

__all__ = [
    "FileAssets",
]
