"""Self subcommands package."""
