# dagster-ge

The docs for `dagster-ge` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-ge).
