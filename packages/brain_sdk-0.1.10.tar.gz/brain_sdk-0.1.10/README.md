# Brain SDK

A Python SDK for authorized users.

## Installation

```bash
pip install brain_sdk
```

## Usage

For authorized users only. Contact support for documentation.
