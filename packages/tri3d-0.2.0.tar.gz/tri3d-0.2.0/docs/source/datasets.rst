.. currentmodule:: tri3d.datasets

tri3d.datasets
==============

Datasets
--------

.. autosummary::
   :toctree: generated/
   :template: base.rst

   Box
   NuScenes
   Once
   SemanticKITTI
   Waymo
   ZODFrames
