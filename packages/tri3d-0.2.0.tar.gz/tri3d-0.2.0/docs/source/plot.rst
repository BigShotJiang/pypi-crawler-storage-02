tri3d.plot
==========

.. automodule:: tri3d.plot
   :members:
