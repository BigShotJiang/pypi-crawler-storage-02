// C++ flavor of the C extension.
// Reuse the whole C source code using an #include, but the file has ".cpp"
// extension to use a C++ builder.
#include "test_pythoncapi_compat_cext.c"
