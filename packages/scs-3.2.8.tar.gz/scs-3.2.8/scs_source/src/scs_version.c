#ifdef __cplusplus
extern "C" {
#endif

#include "glbopts.h"

const char *scs_version(void) {
  return SCS_VERSION;
}

#ifdef __cplusplus
}
#endif
