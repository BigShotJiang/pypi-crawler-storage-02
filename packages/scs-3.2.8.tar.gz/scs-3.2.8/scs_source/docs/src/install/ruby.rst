.. _ruby_install:

Ruby
====

See instructions `here <https://github.com/ankane/scs-ruby>`_.

