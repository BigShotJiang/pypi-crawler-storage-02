.. _r_install:

R
=

Since the **R** interface is available on **CRAN**, the package can
be installed by running the following code in **R**.

.. code:: r

    install.packages("scs")
