.. _ruby_interface:

Ruby
====

See documentation `here <https://github.com/ankane/scs-ruby>`_.

