.. _julia_interface:

Julia
=====

The recommended way to use `SCS.jl <https://github.com/jump-dev/SCS.jl>`_ is via
`Convex.jl <https://github.com/jump-dev/Convex.jl>`_ or
`JuMP <https://github.com/jump-dev/JuMP.jl>`_. 

Read the `SCS.jl README <https://github.com/jump-dev/SCS.jl>`_ for more details.
