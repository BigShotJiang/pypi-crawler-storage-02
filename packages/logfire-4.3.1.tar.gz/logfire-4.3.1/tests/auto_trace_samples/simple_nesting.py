def func1():
    return func2()


def func2():
    return func3()


def func3():
    return func4()


def func4():
    return 42
