"""Data package for idor_finder resources (wordlists, payloads)."""


