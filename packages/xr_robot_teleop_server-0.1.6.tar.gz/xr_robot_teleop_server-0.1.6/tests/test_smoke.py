import xr_robot_teleop_server


def test_import():
    """A simple smoke test that checks if the package can be imported."""
    assert xr_robot_teleop_server is not None
