_This project is currently in beta and may be subject to breaking changes._

# 🍙 PimpMyRice

[📄 Documentation](https://pimpmyrice.vercel.app/docs) ║ [📦 Starter Modules](https://pimpmyrice.vercel.app/modules) ║ [💬 Discord](https://discord.gg/TDrSB2wk6c)

[![showcase_video](video_thumbnail.png)](https://www.youtube.com/watch?v=Z0MnaKWo25U)
