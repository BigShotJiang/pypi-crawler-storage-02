from . import test_product_variant_configurator
from . import test_product_configurator_attribute
from . import test_product_pricelist
from . import test_product_variants
