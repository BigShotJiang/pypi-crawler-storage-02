(after installing sale_management application)

To configure the creation of the variants behaviour, you need to:

1.  Go to `Sales > Configuration > Settings`, and select "Variants (Sell
    variants of a product using attributes (size, color, etc.))" on
    "Product Catalog" section.
2.  Go to `Sales > Products > Products`, and select a product.
3.  On the Attributes & Variants tab edit the value of the field
    `Variant Creation`.
4.  If you want to stop the automatic creation of the variant, and have
    the same behaviour for all the products in the same category, go to
    `Inventory > Configuration > Product Categories`, select the
    category and check the checkbox
    `Don't create variants automatically`.
