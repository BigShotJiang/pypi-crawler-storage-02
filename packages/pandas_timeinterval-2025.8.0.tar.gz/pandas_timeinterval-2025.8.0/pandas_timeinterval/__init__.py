from pandas_timeinterval.intervals import Intervals, Interval

__all__ = ["Intervals", "Interval"]

__version__ = "2025.8.0"
