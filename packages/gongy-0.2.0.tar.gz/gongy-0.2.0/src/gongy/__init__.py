"""Unofficial Gong Python SDK."""

from __future__ import annotations

__all__: tuple[str, ...] = ("Gongy",)

from gongy.api import Gongy
