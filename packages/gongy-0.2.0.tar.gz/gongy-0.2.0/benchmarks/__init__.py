"""Benchmarking for gong."""
