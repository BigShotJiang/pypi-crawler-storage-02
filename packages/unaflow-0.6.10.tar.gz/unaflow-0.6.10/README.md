# Unaflow
Helper classes and functions for [Apache Airflow](https://github.com/apache/airflow)

## Features
- Classes for creating eventdriven DAGs

## Install
- pip install unaflow