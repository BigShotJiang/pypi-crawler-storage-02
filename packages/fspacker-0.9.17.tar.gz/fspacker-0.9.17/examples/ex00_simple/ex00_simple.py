def main():
    print("Hello from ex00-simple!")


if __name__ == "__main__":
    main()
