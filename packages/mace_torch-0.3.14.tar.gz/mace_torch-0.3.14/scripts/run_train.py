## Wrapper for mace.cli.run_train.main ##

from mace.cli.run_train import main

if __name__ == "__main__":
    main()
