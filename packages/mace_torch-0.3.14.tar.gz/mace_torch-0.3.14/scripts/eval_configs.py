## Wrapper for mace.cli.eval_configs.main ##

from mace.cli.eval_configs import main

if __name__ == "__main__":
    main()
