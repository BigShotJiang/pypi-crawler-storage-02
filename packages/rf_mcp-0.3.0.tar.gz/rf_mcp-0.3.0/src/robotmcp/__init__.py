"""Robot Framework MCP Server - Natural Language Test Automation Bridge."""

__version__ = "0.1.0"