# __main__.py

from . import main

main()