# Temporals

The goal of this library is to provide a minimalistic, out-of-the-box utility on top of the Python's 
`datetime` in regards to working with time and date, or both, periods.

:warning: Version 1.0.0 was just released with support provided for wallclock and absolute time periods, I'm in the process
of updating the documentation to reflect the massive overhaul of the library. Consider the current documentation outdated.