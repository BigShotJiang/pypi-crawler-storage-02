from .main import basic


class VertexAIRunner:
    def run(self):
        basic()
