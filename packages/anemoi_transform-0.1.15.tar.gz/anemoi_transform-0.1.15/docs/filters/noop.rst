######
 noop
######

The ``noop`` filter is for debugging purposes. It returns its input
unchanged.
