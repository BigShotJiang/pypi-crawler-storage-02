#######
 empty
#######

The ``empty`` filter is for debugging purposes. It always returns an
empty list of fields.
