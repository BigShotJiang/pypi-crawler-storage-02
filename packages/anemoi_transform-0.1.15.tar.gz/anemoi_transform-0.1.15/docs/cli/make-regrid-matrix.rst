make-regrid-matrix
------------------

.. argparse::
    :module: anemoi.transform.__main__
    :func: create_parser
    :prog: anemoi-transform
    :path: make-regrid-matrix
