get-grid
--------


.. argparse::
    :module: anemoi.transform.__main__
    :func: create_parser
    :prog: anemoi-transform
    :path: get-grid
