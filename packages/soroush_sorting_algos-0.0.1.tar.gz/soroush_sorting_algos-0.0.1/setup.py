from setuptools import setup

setup(
    name="soroush_sorting_algos",
    version="0.0.1",
    description="Sorting Algorithms",
    author="Soroush",
    author_email="sorooshjaberi@gmail.com",
    packages=["sorting_algos"],
)
