# megania

Librería ligera (sin dependencias) con tensores básicos, tokenizer, un transformer simplificado y la IA **Megan**.
Versión inicial 0.1.0 — pensada para experimentos y aprendizaje.

Instalación local / empaquetado:
- `pip install -U setuptools==80.9.0 wheel`
- `python -m build`  (opcional: instala package `build`)
