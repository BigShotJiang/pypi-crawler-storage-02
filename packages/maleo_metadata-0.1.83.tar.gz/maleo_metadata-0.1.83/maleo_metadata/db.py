from maleo_soma.managers.db import create_base


MaleoMetadataBase = create_base()
