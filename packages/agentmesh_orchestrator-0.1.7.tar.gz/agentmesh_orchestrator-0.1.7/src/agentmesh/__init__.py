"""AutoGen Agent-to-Agent Communication System

A production-grade multi-agent communication platform built on Microsoft AutoGen.
"""

__version__ = "0.1.0"
__author__ = "Development Team"
__email__ = "dev@autogen-a2a.com"
