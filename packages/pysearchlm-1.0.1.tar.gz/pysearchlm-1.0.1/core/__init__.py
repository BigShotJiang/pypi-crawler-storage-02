# Core modülü

