"""Interactive periodic table displaying general MBE/XPS element-specific information."""
