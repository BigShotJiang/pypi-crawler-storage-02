"""Functions used to generate graphical user interfaces to view data stored in DataArray format."""

from .disp import disp as disp
