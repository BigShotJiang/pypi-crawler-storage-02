"""Utility functions used throughout the peaks package."""
