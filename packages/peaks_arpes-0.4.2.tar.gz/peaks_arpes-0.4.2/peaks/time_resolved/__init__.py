"""Functions used for time-resolved spectroscopy data."""

from peaks.time_resolved.accessors import TRAccessors as TRAccessors
