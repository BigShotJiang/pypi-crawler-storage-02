This module adds an address on location so it can be used on purchases.
