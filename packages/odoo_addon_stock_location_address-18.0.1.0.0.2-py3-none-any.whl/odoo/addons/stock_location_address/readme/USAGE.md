To use this module you have to activate storage locations, going to
Configuration \> settings \> and activate Storage Locations. then, Go to
'Inventory \> Settings \> Locations' and select an address for the
location. If no address is selected, parent address will be used.
