agentle.agents.a2a.message\_parts.adapters.agent\_part\_to\_generation\_part\_adapter
=====================================================================================

.. automodule:: agentle.agents.a2a.message_parts.adapters.agent_part_to_generation_part_adapter

   
   .. rubric:: Classes

   .. autosummary::
   
      Adapter
      AgentPartToGenerationPartAdapter
      DataPart
      FilePart
      GenerationFilePart
      GenerationTextPart
      TextPart
   