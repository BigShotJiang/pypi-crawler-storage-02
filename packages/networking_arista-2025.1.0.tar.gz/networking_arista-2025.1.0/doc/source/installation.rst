============
Installation
============

At the command line::

    $ pip install networking-arista

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-arista
    $ pip install networking-arista
