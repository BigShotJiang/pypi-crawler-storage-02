""" Package containing several graph algorithms """
