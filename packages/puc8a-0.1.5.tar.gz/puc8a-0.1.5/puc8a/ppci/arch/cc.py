""" Calling conventions """


class CallingConvention:
    def __init__(self, name):
        self.name = name
