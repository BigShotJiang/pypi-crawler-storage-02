""" The cpu module defines cpu's and their properties """
