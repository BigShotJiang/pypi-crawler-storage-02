"""EggAI CLI module for creating new applications."""
