export default {
  template: `
    <div>
      <h2 class="title">Dashboard</h2>
      <p>Welcome to the Telescope Dashboard. Use the sidebar to navigate.</p>
    </div>
  `
};