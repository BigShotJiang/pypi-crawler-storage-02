"""
JSON Tools RS - High-performance JSON manipulation library

This package provides Python bindings for the JSON Tools RS library,
offering high-performance JSON flattening and unflattening with SIMD-accelerated parsing.

The main entry point is the JSONTools class, which provides a unified builder pattern API
for all JSON manipulation operations with advanced collision handling and filtering.

Perfect Type Matching - Input type = Output type:
    - str input → str output (JSON string)
    - dict input → dict output (Python dictionary)
    - list[str] input → list[str] output (list of JSON strings)
    - list[dict] input → list[dict] output (list of Python dictionaries)
    - Mixed lists preserve original types

Basic Usage:
    >>> import json_tools_rs
    >>>
    >>> # Basic flattening
    >>> tools = json_tools_rs.JSONTools().flatten()
    >>> result = tools.execute({"user": {"name": "John", "age": 30}})
    >>> print(result)  # {'user.name': 'John', 'user.age': 30} (dict)
    >>>
    >>> # Basic unflattening
    >>> tools = json_tools_rs.JSONTools().unflatten()
    >>> result = tools.execute({"user.name": "John", "user.age": 30})
    >>> print(result)  # {'user': {'name': 'John', 'age': 30}} (dict)

Advanced Features:
    >>> # Collision handling with filtering
    >>> tools = (json_tools_rs.JSONTools()
    ...     .flatten()
    ...     .separator("::")
    ...     .remove_empty_strings(True)
    ...     .remove_nulls(True)
    ...     .key_replacement("regex:(User|Admin)_", "")
    ...     .handle_key_collision(True))
    >>>
    >>> data = {"User_name": "John", "Admin_name": "", "Guest_name": "Bob"}
    >>> result = tools.execute(data)
    >>> print(result)  # {"name": ["John", "Bob"], "guest_name": "Bob"}
    >>>
    >>> # Collision avoidance strategy
    >>> tools = (json_tools_rs.JSONTools()
    ...     .flatten()
    ...     .key_replacement("regex:(User|Admin)_", "")
    ...     .avoid_key_collision(True))
    >>>
    >>> result = tools.execute({"User_name": "John", "Admin_name": "Jane"})
    >>> print(result)  # {"name.0": "John", "name.1": "Jane"}

Batch Processing:
    >>> # Perfect type preservation in batch processing
    >>> tools = json_tools_rs.JSONTools().flatten()
    >>> str_results = tools.execute(['{"a": 1}', '{"b": 2}'])
    >>> print(str_results)  # ['{"a": 1}', '{"b": 2}'] (list of strings)
    >>>
    >>> dict_results = tools.execute([{"a": {"b": 1}}, {"c": {"d": 2}}])
    >>> print(dict_results)  # [{'a.b': 1}, {'c.d': 2}] (list of dicts)
"""

from .json_tools_rs import JSONTools, JsonToolsError, JsonOutput

__version__ = "0.2.0"
__author__ = "JSON Tools RS Contributors"

__all__ = [
    "JSONTools",
    "JsonOutput",
    "JsonToolsError",
]
