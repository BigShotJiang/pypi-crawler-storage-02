"""
A supply-chain "firewall" for preventing the installation of vulnerable or malicious `pip` and `npm` packages.
"""

__version__ = "2.2.0"
