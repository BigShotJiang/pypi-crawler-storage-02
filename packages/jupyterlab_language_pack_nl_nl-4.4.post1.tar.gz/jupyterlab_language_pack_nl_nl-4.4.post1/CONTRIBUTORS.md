# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Brent Huisman ([@brenthuisman](https://crowdin.com/profile/brenthuisman))
* Jan Genoe ([@JanGenoe](https://crowdin.com/profile/JanGenoe))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
* Koen Van Noten ([@koenvannoten](https://crowdin.com/profile/koenvannoten))
* Wouter Saelens ([@zouter](https://crowdin.com/profile/zouter))
* ba-tno ([@ba-tno](https://crowdin.com/profile/ba-tno))
* Jasper Schelling ([@Jasper2-0](https://crowdin.com/profile/Jasper2-0))
