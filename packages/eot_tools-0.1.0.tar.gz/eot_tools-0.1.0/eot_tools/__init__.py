from eot_tools.eot import EOTFile  # noqa: F401
