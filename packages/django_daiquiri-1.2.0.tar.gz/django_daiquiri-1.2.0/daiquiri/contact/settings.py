ANNOUNCEMENT_MESSAGE_FILTER = 'daiquiri.contact.filters.DefaultMessageFilter'
