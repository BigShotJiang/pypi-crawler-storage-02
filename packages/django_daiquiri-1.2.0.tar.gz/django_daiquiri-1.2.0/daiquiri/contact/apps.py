from django.apps import AppConfig


class ContactConfig(AppConfig):
    name = 'daiquiri.contact'
    label = 'daiquiri_contact'
    verbose_name = 'Contact'
