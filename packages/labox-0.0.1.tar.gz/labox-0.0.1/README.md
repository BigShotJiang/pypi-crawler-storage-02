# Labox

[![PyPI - Version](https://img.shields.io/pypi/v/labox.svg)](https://pypi.org/project/labox)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A storage framework for heterogeneous data in Python.
