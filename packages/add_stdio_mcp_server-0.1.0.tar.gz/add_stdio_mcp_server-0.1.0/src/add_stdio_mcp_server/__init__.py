def main() -> None:
    print("Hello from add-stdio-mcp-server!")
