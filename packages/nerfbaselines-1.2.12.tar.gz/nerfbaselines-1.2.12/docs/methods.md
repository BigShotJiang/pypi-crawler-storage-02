# Methods
```{nerfbaselines}
:names-regex: ^methods/[^:]*$
```

