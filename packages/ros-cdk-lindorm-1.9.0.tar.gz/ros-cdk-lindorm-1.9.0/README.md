## Aliyun ROS LINDORM Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as LINDORM from '@alicloud/ros-cdk-lindorm';
```
