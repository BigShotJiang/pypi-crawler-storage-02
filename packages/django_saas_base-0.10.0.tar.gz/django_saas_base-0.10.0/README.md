# Django SaaS (Base)

The foundation for building a SaaS product with Django.

## Install

```
pip install django-saas-base
```

Then add it into your Django project `settings.py`:

```python
INSTALLED_APPS = [
    # ...
    "saas_base",
]
```
