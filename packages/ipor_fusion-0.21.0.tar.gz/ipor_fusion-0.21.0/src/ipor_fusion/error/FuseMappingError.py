class FuseMappingError(Exception):
    pass
