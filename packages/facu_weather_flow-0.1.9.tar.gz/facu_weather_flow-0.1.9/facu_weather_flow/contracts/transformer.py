from abc import ABC, abstractmethod


class trasform(ABC):
    @abstractmethod
    def trasform_data(self):
        pass
