"""A2A Integration for EggAI."""

from .config import A2AConfig
from .plugin import A2APlugin

__all__ = ["A2AConfig", "A2APlugin"]
