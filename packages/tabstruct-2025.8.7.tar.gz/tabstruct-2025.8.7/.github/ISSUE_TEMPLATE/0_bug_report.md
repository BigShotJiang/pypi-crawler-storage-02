---
name: Bug report
about: Create a report to help us improve
title: "[Bug]: "
labels: bug
assignees: SilenceX12138

---

**Describe the problem you encounter**

- [ ] **Problem**
       1. 

- [ ] **Steps To Reproduce**
       1. 

- [ ] **Expected behaviour**
       1. 

**Additional context**

*
