# THIS FILE WAS GENERATED AUTOMATICALLY BY JSONTODPG. DO NOT EDIT.
#--------------COMPONENTS--------------[202]

_2d_histogram_series = "_2d_histogram_series"
_3d_slider = "_3d_slider"
activated_handler = "activated_handler"
active_handler = "active_handler"
alias = "alias"
area_series = "area_series"
axis_tag = "axis_tag"
bar_group_series = "bar_group_series"
bar_series = "bar_series"
bool_value = "bool_value"
button = "button"
candle_series = "candle_series"
char_remap = "char_remap"
checkbox = "checkbox"
child = "child"
child_window = "child_window"
clicked_handler = "clicked_handler"
clipper = "clipper"
collapsing_header = "collapsing_header"
color_button = "color_button"
color_edit = "color_edit"
color_picker = "color_picker"
color_value = "color_value"
colormap = "colormap"
colormap_button = "colormap_button"
colormap_registry = "colormap_registry"
colormap_scale = "colormap_scale"
colormap_slider = "colormap_slider"
combo = "combo"
context = "context"
custom_series = "custom_series"
date_picker = "date_picker"
deactivated_after_edit_handler = "deactivated_after_edit_handler"
deactivated_handler = "deactivated_handler"
digital_series = "digital_series"
double4_value = "double4_value"
double_value = "double_value"
drag_double = "drag_double"
drag_doublex = "drag_doublex"
drag_float = "drag_float"
drag_floatx = "drag_floatx"
drag_int = "drag_int"
drag_intx = "drag_intx"
drag_line = "drag_line"
drag_payload = "drag_payload"
drag_point = "drag_point"
drag_rect = "drag_rect"
draw_arrow = "draw_arrow"
draw_bezier_cubic = "draw_bezier_cubic"
draw_bezier_quadratic = "draw_bezier_quadratic"
draw_circle = "draw_circle"
draw_ellipse = "draw_ellipse"
draw_image = "draw_image"
draw_image_quad = "draw_image_quad"
draw_layer = "draw_layer"
draw_line = "draw_line"
draw_node = "draw_node"
draw_polygon = "draw_polygon"
draw_polyline = "draw_polyline"
draw_quad = "draw_quad"
draw_rectangle = "draw_rectangle"
draw_text = "draw_text"
draw_triangle = "draw_triangle"
drawlist = "drawlist"
dummy = "dummy"
dynamic_texture = "dynamic_texture"
edited_handler = "edited_handler"
error_series = "error_series"
file_dialog = "file_dialog"
file_extension = "file_extension"
filter_set = "filter_set"
float4_value = "float4_value"
float_value = "float_value"
float_vect_value = "float_vect_value"
focus_handler = "focus_handler"
font = "font"
font_chars = "font_chars"
font_range = "font_range"
font_range_hint = "font_range_hint"
font_registry = "font_registry"
fps_matrix = "fps_matrix"
get_drawing_mouse_pos = "get_drawing_mouse_pos"
group = "group"
handler_registry = "handler_registry"
heat_series = "heat_series"
histogram_series = "histogram_series"
hline_series = "hline_series"
hover_handler = "hover_handler"
image = "image"
image_button = "image_button"
image_series = "image_series"
inf_line_series = "inf_line_series"
input_double = "input_double"
input_doublex = "input_doublex"
input_float = "input_float"
input_floatx = "input_floatx"
input_int = "input_int"
input_intx = "input_intx"
input_text = "input_text"
int4_value = "int4_value"
int_value = "int_value"
item_activated_handler = "item_activated_handler"
item_active_handler = "item_active_handler"
item_clicked_handler = "item_clicked_handler"
item_deactivated_after_edit_handler = "item_deactivated_after_edit_handler"
item_deactivated_handler = "item_deactivated_handler"
item_double_clicked_handler = "item_double_clicked_handler"
item_edited_handler = "item_edited_handler"
item_focus_handler = "item_focus_handler"
item_handler_registry = "item_handler_registry"
item_hover_handler = "item_hover_handler"
item_resize_handler = "item_resize_handler"
item_toggled_open_handler = "item_toggled_open_handler"
item_visible_handler = "item_visible_handler"
key_down_handler = "key_down_handler"
key_press_handler = "key_press_handler"
key_release_handler = "key_release_handler"
knob_float = "knob_float"
line_series = "line_series"
listbox = "listbox"
load_image = "load_image"
load_init_file = "load_init_file"
loading_indicator = "loading_indicator"
lookat_matrix = "lookat_matrix"
menu = "menu"
menu_bar = "menu_bar"
menu_item = "menu_item"
mouse_click_handler = "mouse_click_handler"
mouse_double_click_handler = "mouse_double_click_handler"
mouse_down_handler = "mouse_down_handler"
mouse_drag_handler = "mouse_drag_handler"
mouse_move_handler = "mouse_move_handler"
mouse_release_handler = "mouse_release_handler"
mouse_wheel_handler = "mouse_wheel_handler"
node = "node"
node_attribute = "node_attribute"
node_editor = "node_editor"
node_link = "node_link"
orthographic_matrix = "orthographic_matrix"
perspective_matrix = "perspective_matrix"
pie_series = "pie_series"
plot = "plot"
plot_annotation = "plot_annotation"
plot_axis = "plot_axis"
plot_legend = "plot_legend"
progress_bar = "progress_bar"
radio_button = "radio_button"
raw_texture = "raw_texture"
resize_handler = "resize_handler"
rotation_matrix = "rotation_matrix"
same_line = "same_line"
scale_matrix = "scale_matrix"
scatter_series = "scatter_series"
selectable = "selectable"
separator = "separator"
series_value = "series_value"
set_item_payload_type = "set_item_payload_type"
shade_series = "shade_series"
simple_plot = "simple_plot"
slider_double = "slider_double"
slider_doublex = "slider_doublex"
slider_float = "slider_float"
slider_floatx = "slider_floatx"
slider_int = "slider_int"
slider_intx = "slider_intx"
spacer = "spacer"
spacing = "spacing"
stage = "stage"
staging_container = "staging_container"
stair_series = "stair_series"
static_texture = "static_texture"
stem_series = "stem_series"
string_value = "string_value"
subplots = "subplots"
tab = "tab"
tab_bar = "tab_bar"
tab_button = "tab_button"
table = "table"
table_cell = "table_cell"
table_column = "table_column"
table_next_column = "table_next_column"
table_row = "table_row"
template_registry = "template_registry"
text = "text"
text_point = "text_point"
texture_registry = "texture_registry"
theme = "theme"
theme_color = "theme_color"
theme_component = "theme_component"
theme_style = "theme_style"
time_picker = "time_picker"
toggled_open_handler = "toggled_open_handler"
tooltip = "tooltip"
translation_matrix = "translation_matrix"
tree_node = "tree_node"
value_registry = "value_registry"
viewport = "viewport"
viewport_drawlist = "viewport_drawlist"
viewport_menu_bar = "viewport_menu_bar"
visible_handler = "visible_handler"
vline_series = "vline_series"
window = "window"

#--------------FUNCTIONS--------------[24]

add_async_function = "add_async_function"
add_monitor = "add_monitor"
add_threaded_task = "add_threaded_task"
component_exists = "component_exists"
delete_all = "delete_all"
delete_element = "delete_element"
find_texture_registry = "find_texture_registry"
get = "get"
get_label_text = "get_label_text"
get_state = "get_state"
get_value = "get_value"
hide = "hide"
image_from_data_source = "image_from_data_source"
image_from_file = "image_from_file"
list_to_sublists = "list_to_sublists"
put = "put"
remove_monitor = "remove_monitor"
run_all_tests = "run_all_tests"
set_value = "set_value"
show = "show"
spawn = "spawn"
store_contains = "store_contains"
test_spawn_nested = "test_spawn_nested"
test_spawn_simple = "test_spawn_simple"

#--------------PARAMETERS--------------[415]

_format = "_format"
alias = "alias"
alpha_bar = "alpha_bar"
alpha_preview = "alpha_preview"
always_auto_resize = "always_auto_resize"
always_on_top = "always_on_top"
always_overwrite = "always_overwrite"
always_use_window_padding = "always_use_window_padding"
angle = "angle"
angled_header = "angled_header"
arrow = "arrow"
aspect = "aspect"
attr_1 = "attr_1"
attr_2 = "attr_2"
attribute_type = "attribute_type"
auto_fit = "auto_fit"
auto_resize_x = "auto_resize_x"
auto_resize_y = "auto_resize_y"
auto_rounding = "auto_rounding"
auto_select_all = "auto_select_all"
autosize = "autosize"
autosize_x = "autosize_x"
autosize_y = "autosize_y"
axis = "axis"
background_color = "background_color"
bar_scale = "bar_scale"
bear_color = "bear_color"
before = "before"
bins = "bins"
border = "border"
border_color = "border_color"
borders_innerH = "borders_innerH"
borders_innerV = "borders_innerV"
borders_outerH = "borders_outerH"
borders_outerV = "borders_outerV"
bottom = "bottom"
bounds_max = "bounds_max"
bounds_min = "bounds_min"
box_select_button = "box_select_button"
box_select_cancel_button = "box_select_cancel_button"
box_select_mod = "box_select_mod"
bull_color = "bull_color"
bullet = "bullet"
button = "button"
callback = "callback"
cancel_callback = "cancel_callback"
category = "category"
center = "center"
channel_count = "channel_count"
chars = "chars"
check = "check"
circle_count = "circle_count"
clamped = "clamped"
clear_color = "clear_color"
clipper = "clipper"
closable = "closable"
closed = "closed"
closes = "closes"
col_major = "col_major"
collapsed = "collapsed"
color = "color"
colormap = "colormap"
colors = "colors"
cols = "cols"
column_major = "column_major"
column_ratios = "column_ratios"
columns = "columns"
context_menu_button = "context_menu_button"
context_menu_in_body = "context_menu_in_body"
contribute_to_bounds = "contribute_to_bounds"
corner_colors = "corner_colors"
crosshairs = "crosshairs"
ctrl_enter_for_new_line = "ctrl_enter_for_new_line"
cull_mode = "cull_mode"
cumulative = "cumulative"
custom_text = "custom_text"
dates = "dates"
decimal = "decimal"
decorated = "decorated"
default_filename = "default_filename"
default_hide = "default_hide"
default_open = "default_open"
default_path = "default_path"
default_sort = "default_sort"
default_value = "default_value"
delay = "delay"
delay_search = "delay_search"
delayed = "delayed"
delink_callback = "delink_callback"
density = "density"
depth_clipping = "depth_clipping"
direction = "direction"
directory_selector = "directory_selector"
disable_close = "disable_close"
disable_popup_close = "disable_popup_close"
display_hex = "display_hex"
display_hsv = "display_hsv"
display_mode = "display_mode"
display_rgb = "display_rgb"
display_type = "display_type"
drag_callback = "drag_callback"
drag_data = "drag_data"
draggable = "draggable"
drop_callback = "drop_callback"
drop_data = "drop_data"
enabled = "enabled"
enabled_state = "enabled_state"
equal_aspects = "equal_aspects"
escape_clears_all = "escape_clears_all"
extension = "extension"
eye = "eye"
file = "file"
file_count = "file_count"
fill = "fill"
filter_key = "filter_key"
first_char = "first_char"
fit_button = "fit_button"
fit_width = "fit_width"
flattened_navigation = "flattened_navigation"
foreground_grid = "foreground_grid"
fov = "fov"
frame_style = "frame_style"
freeze_columns = "freeze_columns"
freeze_rows = "freeze_rows"
front = "front"
gamma = "gamma"
gamma_scale_factor = "gamma_scale_factor"
group_size = "group_size"
group_width = "group_width"
header_row = "header_row"
height = "height"
height_mode = "height_mode"
hexadecimal = "hexadecimal"
hide_on_activity = "hide_on_activity"
hideable = "hideable"
highs = "highs"
hint = "hint"
histogram = "histogram"
horizontal = "horizontal"
horizontal_mod = "horizontal_mod"
horizontal_scrollbar = "horizontal_scrollbar"
horizontal_spacing = "horizontal_spacing"
hour24 = "hour24"
ignore_hidden = "ignore_hidden"
indent = "indent"
indent_disable = "indent_disable"
indent_enable = "indent_enable"
init_width_or_weight = "init_width_or_weight"
inner_width = "inner_width"
input_mode = "input_mode"
invert = "invert"
item = "item"
item_type = "item_type"
items = "items"
key = "key"
kwds = "kwds"
label = "label"
label_ids = "label_ids"
labels = "labels"
large_icon = "large_icon"
last_char = "last_char"
leading = "leading"
leaf = "leaf"
left = "left"
level = "level"
link_all_x = "link_all_x"
link_all_y = "link_all_y"
link_columns = "link_columns"
link_rows = "link_rows"
location = "location"
lock_max = "lock_max"
lock_min = "lock_min"
loop = "loop"
lows = "lows"
max_clamped = "max_clamped"
max_height = "max_height"
max_query_rects = "max_query_rects"
max_range = "max_range"
max_scale = "max_scale"
max_size = "max_size"
max_value = "max_value"
max_width = "max_width"
max_x = "max_x"
max_y = "max_y"
max_z = "max_z"
menubar = "menubar"
min_clamped = "min_clamped"
min_height = "min_height"
min_query_rects = "min_query_rects"
min_range = "min_range"
min_scale = "min_scale"
min_size = "min_size"
min_value = "min_value"
min_width = "min_width"
min_x = "min_x"
min_y = "min_y"
min_z = "min_z"
minimap = "minimap"
minimap_location = "minimap_location"
mirror = "mirror"
modal = "modal"
multicolor = "multicolor"
multiline = "multiline"
negative = "negative"
no_align = "no_align"
no_alpha = "no_alpha"
no_arrow_button = "no_arrow_button"
no_background = "no_background"
no_border = "no_border"
no_box_select = "no_box_select"
no_bring_to_front_on_focus = "no_bring_to_front_on_focus"
no_buttons = "no_buttons"
no_clip = "no_clip"
no_close = "no_close"
no_collapse = "no_collapse"
no_cursor = "no_cursor"
no_drag_drop = "no_drag_drop"
no_fit = "no_fit"
no_focus_on_appearing = "no_focus_on_appearing"
no_frame = "no_frame"
no_gridlines = "no_gridlines"
no_header_label = "no_header_label"
no_header_width = "no_header_width"
no_hide = "no_hide"
no_highlight = "no_highlight"
no_highlight_axis = "no_highlight_axis"
no_highlight_item = "no_highlight_item"
no_horizontal_scroll = "no_horizontal_scroll"
no_host_extendX = "no_host_extendX"
no_host_extendY = "no_host_extendY"
no_initial_fit = "no_initial_fit"
no_input = "no_input"
no_inputs = "no_inputs"
no_keep_columns_visible = "no_keep_columns_visible"
no_label = "no_label"
no_menus = "no_menus"
no_mouse_pos = "no_mouse_pos"
no_move = "no_move"
no_open_over_existing_popup = "no_open_over_existing_popup"
no_options = "no_options"
no_pad_innerX = "no_pad_innerX"
no_pad_outerX = "no_pad_outerX"
no_picker = "no_picker"
no_preview = "no_preview"
no_reorder = "no_reorder"
no_resize = "no_resize"
no_saved_settings = "no_saved_settings"
no_scroll_with_mouse = "no_scroll_with_mouse"
no_scrollbar = "no_scrollbar"
no_side_preview = "no_side_preview"
no_side_switch = "no_side_switch"
no_small_preview = "no_small_preview"
no_sort = "no_sort"
no_sort_ascending = "no_sort_ascending"
no_sort_descending = "no_sort_descending"
no_spaces = "no_spaces"
no_tick_labels = "no_tick_labels"
no_tick_marks = "no_tick_marks"
no_title = "no_title"
no_title_bar = "no_title_bar"
no_tooltip = "no_tooltip"
no_undo_redo = "no_undo_redo"
normalize = "normalize"
num_items = "num_items"
offset = "offset"
on_close = "on_close"
on_enter = "on_enter"
open_on_arrow = "open_on_arrow"
open_on_double_click = "open_on_double_click"
opens = "opens"
opposite = "opposite"
order_mode = "order_mode"
outliers = "outliers"
outside = "outside"
overlay = "overlay"
override_mod = "override_mod"
p1 = "p1"
p2 = "p2"
p3 = "p3"
p4 = "p4"
pad_outerX = "pad_outerX"
pan_button = "pan_button"
pan_mod = "pan_mod"
pan_stretch = "pan_stretch"
parent = "parent"
password = "password"
payload_type = "payload_type"
perspective_divide = "perspective_divide"
picker_mode = "picker_mode"
pitch = "pitch"
pixel_snapH = "pixel_snapH"
pmax = "pmax"
pmin = "pmin"
points = "points"
policy = "policy"
popup = "popup"
popup_align_left = "popup_align_left"
pos = "pos"
positive = "positive"
pre_step = "pre_step"
precise_widths = "precise_widths"
prefer_sort_ascending = "prefer_sort_ascending"
prefer_sort_descending = "prefer_sort_descending"
qualitative = "qualitative"
query = "query"
query_color = "query_color"
query_toggle_mod = "query_toggle_mod"
radius = "radius"
range_fit = "range_fit"
readonly = "readonly"
reorderable = "reorderable"
repeat = "repeat"
resizable = "resizable"
resizable_x = "resizable_x"
resizable_y = "resizable_y"
reverse_dir = "reverse_dir"
right = "right"
rounding = "rounding"
row_background = "row_background"
row_ratios = "row_ratios"
rows = "rows"
scale = "scale"
scale_max = "scale_max"
scale_min = "scale_min"
scales = "scales"
scientific = "scientific"
scrollX = "scrollX"
scrollY = "scrollY"
secondary_color = "secondary_color"
segments = "segments"
selectable = "selectable"
shaded = "shaded"
shape = "shape"
share_series = "share_series"
shift = "shift"
shortcut = "shortcut"
show = "show"
show_label = "show_label"
size = "size"
skip_nan = "skip_nan"
small = "small"
small_icon = "small_icon"
sort = "sort"
sort_multi = "sort_multi"
sort_tristate = "sort_tristate"
sortable = "sortable"
source = "source"
span_columns = "span_columns"
span_full_width = "span_full_width"
span_text_width = "span_text_width"
speed = "speed"
stacked = "stacked"
step = "step"
step_fast = "step_fast"
style = "style"
tab_input = "tab_input"
tag = "tag"
target = "target"
text = "text"
texture_tag = "texture_tag"
thickness = "thickness"
threshold = "threshold"
tick_format = "tick_format"
time_unit = "time_unit"
tint_color = "tint_color"
title = "title"
tooltip = "tooltip"
top = "top"
track_offset = "track_offset"
tracked = "tracked"
trailing = "trailing"
translation = "translation"
unsaved_document = "unsaved_document"
up = "up"
uppercase = "uppercase"
use_24hour_clock = "use_24hour_clock"
use_ISO8601 = "use_ISO8601"
use_internal_label = "use_internal_label"
use_local_time = "use_local_time"
user_data = "user_data"
uv1 = "uv1"
uv2 = "uv2"
uv3 = "uv3"
uv4 = "uv4"
uv_max = "uv_max"
uv_min = "uv_min"
value = "value"
values = "values"
vertical = "vertical"
vertical_mod = "vertical_mod"
vsync = "vsync"
weight = "weight"
width = "width"
width_fixed = "width_fixed"
width_stretch = "width_stretch"
wrap = "wrap"
x = "x"
x_pos = "x_pos"
xbins = "xbins"
xmax_range = "xmax_range"
xmin_range = "xmin_range"
xoffset = "xoffset"
y = "y"
y1 = "y1"
y2 = "y2"
y3 = "y3"
y_pos = "y_pos"
yaw = "yaw"
ybins = "ybins"
ymax_range = "ymax_range"
ymin_range = "ymin_range"
zFar = "zFar"
zNear = "zNear"
zoom_mod = "zoom_mod"
zoom_rate = "zoom_rate"

component_parameter_relations = {   '_2d_histogram_series': [   'x',
                                'y',
                                'label',
                                'user_data',
                                'use_internal_label',
                                'tag',
                                'parent',
                                'before',
                                'source',
                                'show',
                                'xbins',
                                'ybins',
                                'xmin_range',
                                'xmax_range',
                                'ymin_range',
                                'ymax_range',
                                'density',
                                'outliers',
                                'col_major'],
    '_3d_slider': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'height',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'default_value',
                      'max_x',
                      'max_y',
                      'max_z',
                      'min_x',
                      'min_y',
                      'min_z',
                      'scale'],
    'activated_handler': [],
    'active_handler': [],
    'alias': ['alias', 'item'],
    'area_series': [   'x',
                       'y',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'parent',
                       'before',
                       'source',
                       'show',
                       'fill',
                       'contribute_to_bounds'],
    'axis_tag': [   'label',
                    'user_data',
                    'use_internal_label',
                    'tag',
                    'parent',
                    'before',
                    'source',
                    'show',
                    'default_value',
                    'color',
                    'auto_rounding'],
    'bar_group_series': [   'values',
                            'label_ids',
                            'group_size',
                            'label',
                            'user_data',
                            'use_internal_label',
                            'tag',
                            'parent',
                            'before',
                            'source',
                            'show',
                            'group_width',
                            'shift',
                            'horizontal',
                            'stacked'],
    'bar_series': [   'x',
                      'y',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent',
                      'before',
                      'source',
                      'show',
                      'weight',
                      'horizontal'],
    'bool_value': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'source',
                      'default_value',
                      'parent'],
    'button': [   'label',
                  'user_data',
                  'use_internal_label',
                  'tag',
                  'width',
                  'height',
                  'indent',
                  'parent',
                  'before',
                  'payload_type',
                  'callback',
                  'drag_callback',
                  'drop_callback',
                  'show',
                  'enabled',
                  'pos',
                  'filter_key',
                  'tracked',
                  'track_offset',
                  'small',
                  'arrow',
                  'direction',
                  'repeat'],
    'candle_series': [   'dates',
                         'opens',
                         'closes',
                         'lows',
                         'highs',
                         'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'parent',
                         'before',
                         'source',
                         'show',
                         'bull_color',
                         'bear_color',
                         'weight',
                         'tooltip',
                         'time_unit'],
    'char_remap': [   'source',
                      'target',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent'],
    'checkbox': [   'label',
                    'user_data',
                    'use_internal_label',
                    'tag',
                    'indent',
                    'parent',
                    'before',
                    'source',
                    'payload_type',
                    'callback',
                    'drag_callback',
                    'drop_callback',
                    'show',
                    'enabled',
                    'pos',
                    'filter_key',
                    'tracked',
                    'track_offset',
                    'default_value'],
    'child': [],
    'child_window': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'height',
                        'indent',
                        'parent',
                        'before',
                        'payload_type',
                        'drop_callback',
                        'show',
                        'pos',
                        'filter_key',
                        'delay_search',
                        'tracked',
                        'track_offset',
                        'border',
                        'autosize_x',
                        'autosize_y',
                        'no_scrollbar',
                        'horizontal_scrollbar',
                        'menubar',
                        'no_scroll_with_mouse',
                        'flattened_navigation',
                        'always_use_window_padding',
                        'resizable_x',
                        'resizable_y',
                        'always_auto_resize',
                        'frame_style',
                        'auto_resize_x',
                        'auto_resize_y'],
    'clicked_handler': [],
    'clipper': [   'label',
                   'user_data',
                   'use_internal_label',
                   'tag',
                   'width',
                   'indent',
                   'parent',
                   'before',
                   'show',
                   'delay_search'],
    'collapsing_header': [   'label',
                             'user_data',
                             'use_internal_label',
                             'tag',
                             'indent',
                             'parent',
                             'before',
                             'payload_type',
                             'drag_callback',
                             'drop_callback',
                             'show',
                             'pos',
                             'filter_key',
                             'delay_search',
                             'tracked',
                             'track_offset',
                             'closable',
                             'default_open',
                             'open_on_double_click',
                             'open_on_arrow',
                             'leaf',
                             'bullet'],
    'color_button': [   'default_value',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'height',
                        'indent',
                        'parent',
                        'before',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'no_alpha',
                        'no_border',
                        'no_drag_drop'],
    'color_edit': [   'default_value',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'height',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'enabled',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'no_alpha',
                      'no_picker',
                      'no_options',
                      'no_small_preview',
                      'no_inputs',
                      'no_tooltip',
                      'no_label',
                      'no_drag_drop',
                      'alpha_bar',
                      'alpha_preview',
                      'display_mode',
                      'display_type',
                      'input_mode'],
    'color_picker': [   'default_value',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'height',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'no_alpha',
                        'no_side_preview',
                        'no_small_preview',
                        'no_inputs',
                        'no_tooltip',
                        'no_label',
                        'alpha_bar',
                        'display_rgb',
                        'display_hsv',
                        'display_hex',
                        'picker_mode',
                        'alpha_preview',
                        'display_type',
                        'input_mode'],
    'color_value': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'source',
                       'default_value',
                       'parent'],
    'colormap': [   'colors',
                    'qualitative',
                    'label',
                    'user_data',
                    'use_internal_label',
                    'tag',
                    'show',
                    'parent'],
    'colormap_button': [   'default_value',
                           'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'width',
                           'height',
                           'indent',
                           'parent',
                           'before',
                           'payload_type',
                           'callback',
                           'drag_callback',
                           'drop_callback',
                           'show',
                           'enabled',
                           'pos',
                           'filter_key',
                           'tracked',
                           'track_offset'],
    'colormap_registry': [   'label',
                             'user_data',
                             'use_internal_label',
                             'tag',
                             'show'],
    'colormap_scale': [   'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'width',
                          'height',
                          'indent',
                          'parent',
                          'before',
                          'source',
                          'payload_type',
                          'drop_callback',
                          'show',
                          'pos',
                          'colormap',
                          'min_scale',
                          'max_scale',
                          '_format',
                          'reverse_dir',
                          'mirror'],
    'colormap_slider': [   'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'width',
                           'height',
                           'indent',
                           'parent',
                           'before',
                           'payload_type',
                           'callback',
                           'drop_callback',
                           'show',
                           'pos',
                           'filter_key',
                           'tracked',
                           'track_offset',
                           'default_value'],
    'combo': [   'items',
                 'label',
                 'user_data',
                 'use_internal_label',
                 'tag',
                 'width',
                 'indent',
                 'parent',
                 'before',
                 'source',
                 'payload_type',
                 'callback',
                 'drag_callback',
                 'drop_callback',
                 'show',
                 'enabled',
                 'pos',
                 'filter_key',
                 'tracked',
                 'track_offset',
                 'default_value',
                 'popup_align_left',
                 'no_arrow_button',
                 'no_preview',
                 'fit_width',
                 'height_mode'],
    'context': [],
    'custom_series': [   'x',
                         'y',
                         'channel_count',
                         'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'parent',
                         'before',
                         'source',
                         'callback',
                         'show',
                         'y1',
                         'y2',
                         'y3',
                         'tooltip',
                         'no_fit'],
    'date_picker': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'indent',
                       'parent',
                       'before',
                       'payload_type',
                       'callback',
                       'drag_callback',
                       'drop_callback',
                       'show',
                       'pos',
                       'filter_key',
                       'tracked',
                       'track_offset',
                       'default_value',
                       'level'],
    'deactivated_after_edit_handler': [],
    'deactivated_handler': [],
    'digital_series': [   'x',
                          'y',
                          'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'parent',
                          'before',
                          'source',
                          'show'],
    'double4_value': [   'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'source',
                         'default_value',
                         'parent'],
    'double_value': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'source',
                        'default_value',
                        'parent'],
    'drag_double': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'width',
                       'indent',
                       'parent',
                       'before',
                       'source',
                       'payload_type',
                       'callback',
                       'drag_callback',
                       'drop_callback',
                       'show',
                       'enabled',
                       'pos',
                       'filter_key',
                       'tracked',
                       'track_offset',
                       'default_value',
                       '_format',
                       'speed',
                       'min_value',
                       'max_value',
                       'no_input',
                       'clamped'],
    'drag_doublex': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'default_value',
                        'size',
                        '_format',
                        'speed',
                        'min_value',
                        'max_value',
                        'no_input',
                        'clamped'],
    'drag_float': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'enabled',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'default_value',
                      '_format',
                      'speed',
                      'min_value',
                      'max_value',
                      'no_input',
                      'clamped'],
    'drag_floatx': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'width',
                       'indent',
                       'parent',
                       'before',
                       'source',
                       'payload_type',
                       'callback',
                       'drag_callback',
                       'drop_callback',
                       'show',
                       'enabled',
                       'pos',
                       'filter_key',
                       'tracked',
                       'track_offset',
                       'default_value',
                       'size',
                       '_format',
                       'speed',
                       'min_value',
                       'max_value',
                       'no_input',
                       'clamped'],
    'drag_int': [   'label',
                    'user_data',
                    'use_internal_label',
                    'tag',
                    'width',
                    'indent',
                    'parent',
                    'before',
                    'source',
                    'payload_type',
                    'callback',
                    'drag_callback',
                    'drop_callback',
                    'show',
                    'enabled',
                    'pos',
                    'filter_key',
                    'tracked',
                    'track_offset',
                    'default_value',
                    '_format',
                    'speed',
                    'min_value',
                    'max_value',
                    'no_input',
                    'clamped'],
    'drag_intx': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'width',
                     'indent',
                     'parent',
                     'before',
                     'source',
                     'payload_type',
                     'callback',
                     'drag_callback',
                     'drop_callback',
                     'show',
                     'enabled',
                     'pos',
                     'filter_key',
                     'tracked',
                     'track_offset',
                     'default_value',
                     'size',
                     '_format',
                     'speed',
                     'min_value',
                     'max_value',
                     'no_input',
                     'clamped'],
    'drag_line': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'parent',
                     'before',
                     'source',
                     'callback',
                     'show',
                     'default_value',
                     'color',
                     'thickness',
                     'show_label',
                     'vertical',
                     'delayed',
                     'no_cursor',
                     'no_fit',
                     'no_inputs'],
    'drag_payload': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'parent',
                        'show',
                        'drag_data',
                        'drop_data',
                        'payload_type'],
    'drag_point': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent',
                      'before',
                      'source',
                      'callback',
                      'show',
                      'default_value',
                      'color',
                      'thickness',
                      'show_label',
                      'offset',
                      'clamped',
                      'delayed',
                      'no_cursor',
                      'no_fit',
                      'no_inputs'],
    'drag_rect': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'parent',
                     'before',
                     'source',
                     'callback',
                     'show',
                     'default_value',
                     'color',
                     'delayed',
                     'no_cursor',
                     'no_fit',
                     'no_inputs'],
    'draw_arrow': [   'p1',
                      'p2',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent',
                      'before',
                      'show',
                      'color',
                      'thickness',
                      'size'],
    'draw_bezier_cubic': [   'p1',
                             'p2',
                             'p3',
                             'p4',
                             'label',
                             'user_data',
                             'use_internal_label',
                             'tag',
                             'parent',
                             'before',
                             'show',
                             'color',
                             'thickness',
                             'segments'],
    'draw_bezier_quadratic': [   'p1',
                                 'p2',
                                 'p3',
                                 'label',
                                 'user_data',
                                 'use_internal_label',
                                 'tag',
                                 'parent',
                                 'before',
                                 'show',
                                 'color',
                                 'thickness',
                                 'segments'],
    'draw_circle': [   'center',
                       'radius',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'parent',
                       'before',
                       'show',
                       'color',
                       'fill',
                       'thickness',
                       'segments'],
    'draw_ellipse': [   'pmin',
                        'pmax',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'parent',
                        'before',
                        'show',
                        'color',
                        'fill',
                        'thickness',
                        'segments'],
    'draw_image': [   'texture_tag',
                      'pmin',
                      'pmax',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent',
                      'before',
                      'show',
                      'uv_min',
                      'uv_max',
                      'color'],
    'draw_image_quad': [   'texture_tag',
                           'p1',
                           'p2',
                           'p3',
                           'p4',
                           'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'parent',
                           'before',
                           'show',
                           'uv1',
                           'uv2',
                           'uv3',
                           'uv4',
                           'color'],
    'draw_layer': ['kwds'],
    'draw_line': [   'p1',
                     'p2',
                     'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'parent',
                     'before',
                     'show',
                     'color',
                     'thickness'],
    'draw_node': ['kwds'],
    'draw_polygon': [   'points',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'parent',
                        'before',
                        'show',
                        'color',
                        'fill',
                        'thickness'],
    'draw_polyline': [   'points',
                         'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'parent',
                         'before',
                         'show',
                         'closed',
                         'color',
                         'thickness'],
    'draw_quad': [   'p1',
                     'p2',
                     'p3',
                     'p4',
                     'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'parent',
                     'before',
                     'show',
                     'color',
                     'fill',
                     'thickness'],
    'draw_rectangle': [   'pmin',
                          'pmax',
                          'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'parent',
                          'before',
                          'show',
                          'color',
                          'fill',
                          'multicolor',
                          'rounding',
                          'thickness',
                          'corner_colors'],
    'draw_text': [   'pos',
                     'text',
                     'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'parent',
                     'before',
                     'show',
                     'color',
                     'size'],
    'draw_triangle': [   'p1',
                         'p2',
                         'p3',
                         'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'parent',
                         'before',
                         'show',
                         'color',
                         'fill',
                         'thickness'],
    'drawlist': ['kwds'],
    'dummy': [],
    'dynamic_texture': [   'width',
                           'height',
                           'default_value',
                           'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'parent'],
    'edited_handler': [],
    'error_series': [   'x',
                        'y',
                        'negative',
                        'positive',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'parent',
                        'before',
                        'source',
                        'show',
                        'contribute_to_bounds',
                        'horizontal'],
    'file_dialog': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'width',
                       'height',
                       'callback',
                       'show',
                       'default_path',
                       'default_filename',
                       'file_count',
                       'modal',
                       'directory_selector',
                       'min_size',
                       'max_size',
                       'cancel_callback'],
    'file_extension': [   'extension',
                          'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'width',
                          'height',
                          'parent',
                          'before',
                          'custom_text',
                          'color'],
    'filter_set': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'indent',
                      'parent',
                      'before',
                      'show',
                      'delay_search'],
    'float4_value': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'source',
                        'default_value',
                        'parent'],
    'float_value': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'source',
                       'default_value',
                       'parent'],
    'float_vect_value': [   'label',
                            'user_data',
                            'use_internal_label',
                            'tag',
                            'source',
                            'default_value',
                            'parent'],
    'focus_handler': [],
    'font': [   'file',
                'size',
                'label',
                'user_data',
                'use_internal_label',
                'tag',
                'pixel_snapH',
                'parent'],
    'font_chars': [   'chars',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent'],
    'font_range': [   'first_char',
                      'last_char',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent'],
    'font_range_hint': [   'hint',
                           'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'parent'],
    'font_registry': [   'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'show'],
    'fps_matrix': ['eye', 'pitch', 'yaw'],
    'get_drawing_mouse_pos': [],
    'group': [   'label',
                 'user_data',
                 'use_internal_label',
                 'tag',
                 'width',
                 'height',
                 'indent',
                 'parent',
                 'before',
                 'payload_type',
                 'drag_callback',
                 'drop_callback',
                 'show',
                 'enabled',
                 'pos',
                 'filter_key',
                 'delay_search',
                 'tracked',
                 'track_offset',
                 'horizontal',
                 'horizontal_spacing',
                 'xoffset'],
    'handler_registry': [   'label',
                            'user_data',
                            'use_internal_label',
                            'tag',
                            'show'],
    'heat_series': [   'x',
                       'rows',
                       'cols',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'parent',
                       'before',
                       'source',
                       'show',
                       'scale_min',
                       'scale_max',
                       'bounds_min',
                       'bounds_max',
                       '_format',
                       'contribute_to_bounds',
                       'col_major'],
    'histogram_series': [   'x',
                            'label',
                            'user_data',
                            'use_internal_label',
                            'tag',
                            'parent',
                            'before',
                            'source',
                            'show',
                            'bins',
                            'bar_scale',
                            'min_range',
                            'max_range',
                            'cumulative',
                            'density',
                            'outliers',
                            'horizontal',
                            'contribute_to_bounds'],
    'hline_series': [],
    'hover_handler': [],
    'image': [   'texture_tag',
                 'label',
                 'user_data',
                 'use_internal_label',
                 'tag',
                 'width',
                 'height',
                 'indent',
                 'parent',
                 'before',
                 'source',
                 'payload_type',
                 'drag_callback',
                 'drop_callback',
                 'show',
                 'pos',
                 'filter_key',
                 'tracked',
                 'track_offset',
                 'tint_color',
                 'border_color',
                 'uv_min',
                 'uv_max'],
    'image_button': [   'texture_tag',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'height',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'tint_color',
                        'background_color',
                        'uv_min',
                        'uv_max'],
    'image_series': [   'texture_tag',
                        'bounds_min',
                        'bounds_max',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'parent',
                        'before',
                        'source',
                        'show',
                        'uv_min',
                        'uv_max',
                        'tint_color'],
    'inf_line_series': [   'x',
                           'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'parent',
                           'before',
                           'source',
                           'show',
                           'horizontal'],
    'input_double': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'default_value',
                        '_format',
                        'min_value',
                        'max_value',
                        'step',
                        'step_fast',
                        'min_clamped',
                        'max_clamped',
                        'on_enter',
                        'readonly'],
    'input_doublex': [   'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'width',
                         'indent',
                         'parent',
                         'before',
                         'source',
                         'payload_type',
                         'callback',
                         'drag_callback',
                         'drop_callback',
                         'show',
                         'enabled',
                         'pos',
                         'filter_key',
                         'tracked',
                         'track_offset',
                         'default_value',
                         '_format',
                         'min_value',
                         'max_value',
                         'size',
                         'min_clamped',
                         'max_clamped',
                         'on_enter',
                         'readonly'],
    'input_float': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'width',
                       'indent',
                       'parent',
                       'before',
                       'source',
                       'payload_type',
                       'callback',
                       'drag_callback',
                       'drop_callback',
                       'show',
                       'enabled',
                       'pos',
                       'filter_key',
                       'tracked',
                       'track_offset',
                       'default_value',
                       '_format',
                       'min_value',
                       'max_value',
                       'step',
                       'step_fast',
                       'min_clamped',
                       'max_clamped',
                       'on_enter',
                       'readonly'],
    'input_floatx': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'default_value',
                        '_format',
                        'min_value',
                        'max_value',
                        'size',
                        'min_clamped',
                        'max_clamped',
                        'on_enter',
                        'readonly'],
    'input_int': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'width',
                     'indent',
                     'parent',
                     'before',
                     'source',
                     'payload_type',
                     'callback',
                     'drag_callback',
                     'drop_callback',
                     'show',
                     'enabled',
                     'pos',
                     'filter_key',
                     'tracked',
                     'track_offset',
                     'default_value',
                     'min_value',
                     'max_value',
                     'step',
                     'step_fast',
                     'min_clamped',
                     'max_clamped',
                     'on_enter',
                     'readonly'],
    'input_intx': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'enabled',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'default_value',
                      'min_value',
                      'max_value',
                      'size',
                      'min_clamped',
                      'max_clamped',
                      'on_enter',
                      'readonly'],
    'input_text': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'height',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'enabled',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'default_value',
                      'hint',
                      'multiline',
                      'no_spaces',
                      'uppercase',
                      'tab_input',
                      'decimal',
                      'hexadecimal',
                      'readonly',
                      'password',
                      'scientific',
                      'on_enter',
                      'auto_select_all',
                      'ctrl_enter_for_new_line',
                      'no_horizontal_scroll',
                      'always_overwrite',
                      'no_undo_redo',
                      'escape_clears_all'],
    'int4_value': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'source',
                      'default_value',
                      'parent'],
    'int_value': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'source',
                     'default_value',
                     'parent'],
    'item_activated_handler': [   'label',
                                  'user_data',
                                  'use_internal_label',
                                  'tag',
                                  'parent',
                                  'callback',
                                  'show'],
    'item_active_handler': [   'label',
                               'user_data',
                               'use_internal_label',
                               'tag',
                               'parent',
                               'callback',
                               'show'],
    'item_clicked_handler': [   'button',
                                'label',
                                'user_data',
                                'use_internal_label',
                                'tag',
                                'parent',
                                'callback',
                                'show'],
    'item_deactivated_after_edit_handler': [   'label',
                                               'user_data',
                                               'use_internal_label',
                                               'tag',
                                               'parent',
                                               'callback',
                                               'show'],
    'item_deactivated_handler': [   'label',
                                    'user_data',
                                    'use_internal_label',
                                    'tag',
                                    'parent',
                                    'callback',
                                    'show'],
    'item_double_clicked_handler': [   'button',
                                       'label',
                                       'user_data',
                                       'use_internal_label',
                                       'tag',
                                       'parent',
                                       'callback',
                                       'show'],
    'item_edited_handler': [   'label',
                               'user_data',
                               'use_internal_label',
                               'tag',
                               'parent',
                               'callback',
                               'show'],
    'item_focus_handler': [   'label',
                              'user_data',
                              'use_internal_label',
                              'tag',
                              'parent',
                              'callback',
                              'show'],
    'item_handler_registry': [   'label',
                                 'user_data',
                                 'use_internal_label',
                                 'tag',
                                 'show'],
    'item_hover_handler': [   'label',
                              'user_data',
                              'use_internal_label',
                              'tag',
                              'parent',
                              'callback',
                              'show'],
    'item_resize_handler': [   'label',
                               'user_data',
                               'use_internal_label',
                               'tag',
                               'parent',
                               'callback',
                               'show'],
    'item_toggled_open_handler': [   'label',
                                     'user_data',
                                     'use_internal_label',
                                     'tag',
                                     'parent',
                                     'callback',
                                     'show'],
    'item_visible_handler': [   'label',
                                'user_data',
                                'use_internal_label',
                                'tag',
                                'parent',
                                'callback',
                                'show'],
    'key_down_handler': [   'key',
                            'label',
                            'user_data',
                            'use_internal_label',
                            'tag',
                            'callback',
                            'show',
                            'parent'],
    'key_press_handler': [   'key',
                             'label',
                             'user_data',
                             'use_internal_label',
                             'tag',
                             'callback',
                             'show',
                             'parent'],
    'key_release_handler': [   'key',
                               'label',
                               'user_data',
                               'use_internal_label',
                               'tag',
                               'callback',
                               'show',
                               'parent'],
    'knob_float': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'height',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'enabled',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'default_value',
                      'min_value',
                      'max_value'],
    'line_series': [   'x',
                       'y',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'parent',
                       'before',
                       'source',
                       'show',
                       'segments',
                       'loop',
                       'skip_nan',
                       'no_clip',
                       'shaded'],
    'listbox': [   'items',
                   'label',
                   'user_data',
                   'use_internal_label',
                   'tag',
                   'width',
                   'indent',
                   'parent',
                   'before',
                   'source',
                   'payload_type',
                   'callback',
                   'drag_callback',
                   'drop_callback',
                   'show',
                   'enabled',
                   'pos',
                   'filter_key',
                   'tracked',
                   'track_offset',
                   'default_value',
                   'num_items'],
    'load_image': ['file', 'gamma', 'gamma_scale_factor'],
    'load_init_file': [],
    'loading_indicator': [   'label',
                             'user_data',
                             'use_internal_label',
                             'tag',
                             'width',
                             'height',
                             'indent',
                             'parent',
                             'before',
                             'payload_type',
                             'drop_callback',
                             'show',
                             'pos',
                             'style',
                             'circle_count',
                             'speed',
                             'radius',
                             'thickness',
                             'color',
                             'secondary_color'],
    'lookat_matrix': ['eye', 'target', 'up'],
    'menu': [   'label',
                'user_data',
                'use_internal_label',
                'tag',
                'indent',
                'parent',
                'before',
                'payload_type',
                'drop_callback',
                'show',
                'enabled',
                'filter_key',
                'delay_search',
                'tracked',
                'track_offset'],
    'menu_bar': [   'label',
                    'user_data',
                    'use_internal_label',
                    'tag',
                    'indent',
                    'parent',
                    'show',
                    'delay_search'],
    'menu_item': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'indent',
                     'parent',
                     'before',
                     'payload_type',
                     'callback',
                     'drop_callback',
                     'show',
                     'enabled',
                     'filter_key',
                     'tracked',
                     'track_offset',
                     'default_value',
                     'shortcut',
                     'check'],
    'mouse_click_handler': [   'button',
                               'label',
                               'user_data',
                               'use_internal_label',
                               'tag',
                               'callback',
                               'show',
                               'parent'],
    'mouse_double_click_handler': [   'button',
                                      'label',
                                      'user_data',
                                      'use_internal_label',
                                      'tag',
                                      'callback',
                                      'show',
                                      'parent'],
    'mouse_down_handler': [   'button',
                              'label',
                              'user_data',
                              'use_internal_label',
                              'tag',
                              'callback',
                              'show',
                              'parent'],
    'mouse_drag_handler': [   'button',
                              'threshold',
                              'label',
                              'user_data',
                              'use_internal_label',
                              'tag',
                              'callback',
                              'show',
                              'parent'],
    'mouse_move_handler': [   'label',
                              'user_data',
                              'use_internal_label',
                              'tag',
                              'callback',
                              'show',
                              'parent'],
    'mouse_release_handler': [   'button',
                                 'label',
                                 'user_data',
                                 'use_internal_label',
                                 'tag',
                                 'callback',
                                 'show',
                                 'parent'],
    'mouse_wheel_handler': [   'label',
                               'user_data',
                               'use_internal_label',
                               'tag',
                               'callback',
                               'show',
                               'parent'],
    'node': [   'label',
                'user_data',
                'use_internal_label',
                'tag',
                'parent',
                'before',
                'payload_type',
                'drag_callback',
                'drop_callback',
                'show',
                'pos',
                'filter_key',
                'delay_search',
                'tracked',
                'track_offset',
                'draggable'],
    'node_attribute': [   'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'indent',
                          'parent',
                          'before',
                          'show',
                          'filter_key',
                          'tracked',
                          'track_offset',
                          'attribute_type',
                          'shape',
                          'category'],
    'node_editor': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'width',
                       'height',
                       'parent',
                       'before',
                       'callback',
                       'show',
                       'filter_key',
                       'delay_search',
                       'tracked',
                       'track_offset',
                       'delink_callback',
                       'menubar',
                       'minimap',
                       'minimap_location'],
    'node_link': [   'attr_1',
                     'attr_2',
                     'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'parent',
                     'show'],
    'orthographic_matrix': ['left', 'right', 'bottom', 'top', 'zNear', 'zFar'],
    'perspective_matrix': ['fov', 'aspect', 'zNear', 'zFar'],
    'pie_series': [   'x',
                      'y',
                      'radius',
                      'values',
                      'labels',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent',
                      'before',
                      'source',
                      'show',
                      '_format',
                      'angle',
                      'normalize',
                      'ignore_hidden'],
    'plot': [   'label',
                'user_data',
                'use_internal_label',
                'tag',
                'width',
                'height',
                'indent',
                'parent',
                'before',
                'payload_type',
                'callback',
                'drag_callback',
                'drop_callback',
                'show',
                'pos',
                'filter_key',
                'delay_search',
                'tracked',
                'track_offset',
                'no_title',
                'no_menus',
                'no_box_select',
                'no_mouse_pos',
                'query',
                'query_color',
                'min_query_rects',
                'max_query_rects',
                'crosshairs',
                'equal_aspects',
                'no_inputs',
                'no_frame',
                'use_local_time',
                'use_ISO8601',
                'use_24hour_clock',
                'pan_button',
                'pan_mod',
                'context_menu_button',
                'fit_button',
                'box_select_button',
                'box_select_mod',
                'box_select_cancel_button',
                'query_toggle_mod',
                'horizontal_mod',
                'vertical_mod',
                'override_mod',
                'zoom_mod',
                'zoom_rate'],
    'plot_annotation': [   'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'parent',
                           'before',
                           'source',
                           'show',
                           'default_value',
                           'offset',
                           'color',
                           'clamped'],
    'plot_axis': [   'axis',
                     'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'parent',
                     'payload_type',
                     'drop_callback',
                     'show',
                     'no_label',
                     'no_gridlines',
                     'no_tick_marks',
                     'no_tick_labels',
                     'no_initial_fit',
                     'no_menus',
                     'no_side_switch',
                     'no_highlight',
                     'opposite',
                     'foreground_grid',
                     'tick_format',
                     'scale',
                     'invert',
                     'auto_fit',
                     'range_fit',
                     'pan_stretch',
                     'lock_min',
                     'lock_max'],
    'plot_legend': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'parent',
                       'payload_type',
                       'drop_callback',
                       'show',
                       'location',
                       'horizontal',
                       'sort',
                       'outside',
                       'no_highlight_item',
                       'no_highlight_axis',
                       'no_menus',
                       'no_buttons'],
    'progress_bar': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'height',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'overlay',
                        'default_value'],
    'radio_button': [   'items',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'default_value',
                        'horizontal'],
    'raw_texture': [   'width',
                       'height',
                       'default_value',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       '_format',
                       'parent'],
    'resize_handler': [],
    'rotation_matrix': ['angle', 'axis'],
    'same_line': [],
    'scale_matrix': ['scales'],
    'scatter_series': [   'x',
                          'y',
                          'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'parent',
                          'before',
                          'source',
                          'show',
                          'no_clip'],
    'selectable': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'height',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'enabled',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'default_value',
                      'span_columns',
                      'disable_popup_close'],
    'separator': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'indent',
                     'parent',
                     'before',
                     'show',
                     'pos'],
    'series_value': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'source',
                        'default_value',
                        'parent'],
    'set_item_payload_type': ['item', 'payload_type'],
    'shade_series': [   'x',
                        'y1',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'parent',
                        'before',
                        'source',
                        'show',
                        'y2'],
    'simple_plot': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'width',
                       'height',
                       'indent',
                       'parent',
                       'before',
                       'source',
                       'payload_type',
                       'drag_callback',
                       'drop_callback',
                       'show',
                       'filter_key',
                       'tracked',
                       'track_offset',
                       'default_value',
                       'overlay',
                       'histogram',
                       'autosize',
                       'min_scale',
                       'max_scale'],
    'slider_double': [   'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'width',
                         'height',
                         'indent',
                         'parent',
                         'before',
                         'source',
                         'payload_type',
                         'callback',
                         'drag_callback',
                         'drop_callback',
                         'show',
                         'enabled',
                         'pos',
                         'filter_key',
                         'tracked',
                         'track_offset',
                         'default_value',
                         'vertical',
                         'no_input',
                         'clamped',
                         'min_value',
                         'max_value',
                         '_format'],
    'slider_doublex': [   'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'width',
                          'indent',
                          'parent',
                          'before',
                          'source',
                          'payload_type',
                          'callback',
                          'drag_callback',
                          'drop_callback',
                          'show',
                          'enabled',
                          'pos',
                          'filter_key',
                          'tracked',
                          'track_offset',
                          'default_value',
                          'size',
                          'no_input',
                          'clamped',
                          'min_value',
                          'max_value',
                          '_format'],
    'slider_float': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'height',
                        'indent',
                        'parent',
                        'before',
                        'source',
                        'payload_type',
                        'callback',
                        'drag_callback',
                        'drop_callback',
                        'show',
                        'enabled',
                        'pos',
                        'filter_key',
                        'tracked',
                        'track_offset',
                        'default_value',
                        'vertical',
                        'no_input',
                        'clamped',
                        'min_value',
                        'max_value',
                        '_format'],
    'slider_floatx': [   'label',
                         'user_data',
                         'use_internal_label',
                         'tag',
                         'width',
                         'indent',
                         'parent',
                         'before',
                         'source',
                         'payload_type',
                         'callback',
                         'drag_callback',
                         'drop_callback',
                         'show',
                         'enabled',
                         'pos',
                         'filter_key',
                         'tracked',
                         'track_offset',
                         'default_value',
                         'size',
                         'no_input',
                         'clamped',
                         'min_value',
                         'max_value',
                         '_format'],
    'slider_int': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'width',
                      'height',
                      'indent',
                      'parent',
                      'before',
                      'source',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'enabled',
                      'pos',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'default_value',
                      'vertical',
                      'no_input',
                      'clamped',
                      'min_value',
                      'max_value',
                      '_format'],
    'slider_intx': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'width',
                       'indent',
                       'parent',
                       'before',
                       'source',
                       'payload_type',
                       'callback',
                       'drag_callback',
                       'drop_callback',
                       'show',
                       'enabled',
                       'pos',
                       'filter_key',
                       'tracked',
                       'track_offset',
                       'default_value',
                       'size',
                       'no_input',
                       'clamped',
                       'min_value',
                       'max_value',
                       '_format'],
    'spacer': [   'label',
                  'user_data',
                  'use_internal_label',
                  'tag',
                  'width',
                  'height',
                  'indent',
                  'parent',
                  'before',
                  'show',
                  'pos'],
    'spacing': [],
    'stage': ['label', 'user_data', 'use_internal_label', 'tag'],
    'staging_container': [],
    'stair_series': [   'x',
                        'y',
                        'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'parent',
                        'before',
                        'source',
                        'show',
                        'pre_step',
                        'shaded'],
    'static_texture': [   'width',
                          'height',
                          'default_value',
                          'label',
                          'user_data',
                          'use_internal_label',
                          'tag',
                          'parent'],
    'stem_series': [   'x',
                       'y',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'indent',
                       'parent',
                       'before',
                       'source',
                       'show',
                       'horizontal'],
    'string_value': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'source',
                        'default_value',
                        'parent'],
    'subplots': [   'rows',
                    'columns',
                    'label',
                    'user_data',
                    'use_internal_label',
                    'tag',
                    'width',
                    'height',
                    'indent',
                    'parent',
                    'before',
                    'callback',
                    'show',
                    'pos',
                    'filter_key',
                    'delay_search',
                    'tracked',
                    'track_offset',
                    'row_ratios',
                    'column_ratios',
                    'no_title',
                    'no_menus',
                    'no_resize',
                    'no_align',
                    'share_series',
                    'link_rows',
                    'link_columns',
                    'link_all_x',
                    'link_all_y',
                    'column_major'],
    'tab': [   'label',
               'user_data',
               'use_internal_label',
               'tag',
               'indent',
               'parent',
               'before',
               'payload_type',
               'drop_callback',
               'show',
               'filter_key',
               'delay_search',
               'tracked',
               'track_offset',
               'closable',
               'no_tooltip',
               'order_mode'],
    'tab_bar': [   'label',
                   'user_data',
                   'use_internal_label',
                   'tag',
                   'indent',
                   'parent',
                   'before',
                   'callback',
                   'show',
                   'pos',
                   'filter_key',
                   'delay_search',
                   'tracked',
                   'track_offset',
                   'reorderable'],
    'tab_button': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'indent',
                      'parent',
                      'before',
                      'payload_type',
                      'callback',
                      'drag_callback',
                      'drop_callback',
                      'show',
                      'filter_key',
                      'tracked',
                      'track_offset',
                      'no_reorder',
                      'leading',
                      'trailing',
                      'no_tooltip'],
    'table': [   'label',
                 'user_data',
                 'use_internal_label',
                 'tag',
                 'width',
                 'height',
                 'indent',
                 'parent',
                 'before',
                 'source',
                 'callback',
                 'show',
                 'pos',
                 'filter_key',
                 'delay_search',
                 'header_row',
                 'clipper',
                 'inner_width',
                 'policy',
                 'freeze_rows',
                 'freeze_columns',
                 'sort_multi',
                 'sort_tristate',
                 'resizable',
                 'reorderable',
                 'hideable',
                 'sortable',
                 'context_menu_in_body',
                 'row_background',
                 'borders_innerH',
                 'borders_outerH',
                 'borders_innerV',
                 'borders_outerV',
                 'no_host_extendX',
                 'no_host_extendY',
                 'no_keep_columns_visible',
                 'precise_widths',
                 'no_clip',
                 'pad_outerX',
                 'no_pad_outerX',
                 'no_pad_innerX',
                 'scrollX',
                 'scrollY',
                 'no_saved_settings'],
    'table_cell': [   'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'height',
                      'parent',
                      'before',
                      'show',
                      'filter_key'],
    'table_column': [   'label',
                        'user_data',
                        'use_internal_label',
                        'tag',
                        'width',
                        'parent',
                        'before',
                        'show',
                        'enabled',
                        'init_width_or_weight',
                        'default_hide',
                        'default_sort',
                        'width_stretch',
                        'width_fixed',
                        'no_resize',
                        'no_reorder',
                        'no_hide',
                        'no_clip',
                        'no_sort',
                        'no_sort_ascending',
                        'no_sort_descending',
                        'no_header_width',
                        'prefer_sort_ascending',
                        'prefer_sort_descending',
                        'indent_enable',
                        'indent_disable',
                        'angled_header',
                        'no_header_label'],
    'table_next_column': [],
    'table_row': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'height',
                     'parent',
                     'before',
                     'show',
                     'filter_key'],
    'template_registry': ['label', 'user_data', 'use_internal_label', 'tag'],
    'text': [   'default_value',
                'label',
                'user_data',
                'use_internal_label',
                'tag',
                'indent',
                'parent',
                'before',
                'source',
                'payload_type',
                'drag_callback',
                'drop_callback',
                'show',
                'pos',
                'filter_key',
                'tracked',
                'track_offset',
                'wrap',
                'bullet',
                'color',
                'show_label'],
    'text_point': [   'x',
                      'y',
                      'label',
                      'user_data',
                      'use_internal_label',
                      'tag',
                      'parent',
                      'before',
                      'source',
                      'show',
                      'offset',
                      'vertical'],
    'texture_registry': [   'label',
                            'user_data',
                            'use_internal_label',
                            'tag',
                            'show'],
    'theme': ['label', 'user_data', 'use_internal_label', 'tag'],
    'theme_color': [   'target',
                       'value',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'parent',
                       'category'],
    'theme_component': [   'item_type',
                           'label',
                           'user_data',
                           'use_internal_label',
                           'tag',
                           'parent',
                           'before',
                           'enabled_state'],
    'theme_style': [   'target',
                       'x',
                       'y',
                       'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'parent',
                       'category'],
    'time_picker': [   'label',
                       'user_data',
                       'use_internal_label',
                       'tag',
                       'indent',
                       'parent',
                       'before',
                       'payload_type',
                       'callback',
                       'drag_callback',
                       'drop_callback',
                       'show',
                       'pos',
                       'filter_key',
                       'tracked',
                       'track_offset',
                       'default_value',
                       'hour24'],
    'toggled_open_handler': [],
    'tooltip': [   'parent',
                   'label',
                   'user_data',
                   'use_internal_label',
                   'tag',
                   'show',
                   'delay',
                   'hide_on_activity'],
    'translation_matrix': ['translation'],
    'tree_node': [   'label',
                     'user_data',
                     'use_internal_label',
                     'tag',
                     'indent',
                     'parent',
                     'before',
                     'payload_type',
                     'drag_callback',
                     'drop_callback',
                     'show',
                     'pos',
                     'filter_key',
                     'delay_search',
                     'tracked',
                     'track_offset',
                     'default_open',
                     'open_on_double_click',
                     'open_on_arrow',
                     'leaf',
                     'bullet',
                     'selectable',
                     'span_text_width',
                     'span_full_width'],
    'value_registry': ['label', 'user_data', 'use_internal_label', 'tag'],
    'viewport': [   'title',
                    'small_icon',
                    'large_icon',
                    'width',
                    'height',
                    'x_pos',
                    'y_pos',
                    'min_width',
                    'max_width',
                    'min_height',
                    'max_height',
                    'resizable',
                    'vsync',
                    'always_on_top',
                    'decorated',
                    'clear_color',
                    'disable_close'],
    'viewport_drawlist': ['kwds'],
    'viewport_menu_bar': [   'label',
                             'user_data',
                             'use_internal_label',
                             'tag',
                             'indent',
                             'parent',
                             'show',
                             'delay_search'],
    'visible_handler': [],
    'vline_series': [],
    'window': [   'label',
                  'user_data',
                  'use_internal_label',
                  'tag',
                  'width',
                  'height',
                  'indent',
                  'show',
                  'pos',
                  'delay_search',
                  'min_size',
                  'max_size',
                  'menubar',
                  'collapsed',
                  'autosize',
                  'no_resize',
                  'unsaved_document',
                  'no_title_bar',
                  'no_move',
                  'no_scrollbar',
                  'no_collapse',
                  'horizontal_scrollbar',
                  'no_focus_on_appearing',
                  'no_bring_to_front_on_focus',
                  'no_close',
                  'no_background',
                  'modal',
                  'popup',
                  'no_saved_settings',
                  'no_open_over_existing_popup',
                  'no_scroll_with_mouse',
                  'on_close']}

__all__ = ['_2d_histogram_series', '_3d_slider', 'activated_handler', 'active_handler', 'alias', 'area_series', 'axis_tag', 'bar_group_series', 'bar_series', 'bool_value', 'button', 'candle_series', 'char_remap', 'checkbox', 'child', 'child_window', 'clicked_handler', 'clipper', 'collapsing_header', 'color_button', 'color_edit', 'color_picker', 'color_value', 'colormap', 'colormap_button', 'colormap_registry', 'colormap_scale', 'colormap_slider', 'combo', 'context', 'custom_series', 'date_picker', 'deactivated_after_edit_handler', 'deactivated_handler', 'digital_series', 'double4_value', 'double_value', 'drag_double', 'drag_doublex', 'drag_float', 'drag_floatx', 'drag_int', 'drag_intx', 'drag_line', 'drag_payload', 'drag_point', 'drag_rect', 'draw_arrow', 'draw_bezier_cubic', 'draw_bezier_quadratic', 'draw_circle', 'draw_ellipse', 'draw_image', 'draw_image_quad', 'draw_layer', 'draw_line', 'draw_node', 'draw_polygon', 'draw_polyline', 'draw_quad', 'draw_rectangle', 'draw_text', 'draw_triangle', 'drawlist', 'dummy', 'dynamic_texture', 'edited_handler', 'error_series', 'file_dialog', 'file_extension', 'filter_set', 'float4_value', 'float_value', 'float_vect_value', 'focus_handler', 'font', 'font_chars', 'font_range', 'font_range_hint', 'font_registry', 'fps_matrix', 'get_drawing_mouse_pos', 'group', 'handler_registry', 'heat_series', 'histogram_series', 'hline_series', 'hover_handler', 'image', 'image_button', 'image_series', 'inf_line_series', 'input_double', 'input_doublex', 'input_float', 'input_floatx', 'input_int', 'input_intx', 'input_text', 'int4_value', 'int_value', 'item_activated_handler', 'item_active_handler', 'item_clicked_handler', 'item_deactivated_after_edit_handler', 'item_deactivated_handler', 'item_double_clicked_handler', 'item_edited_handler', 'item_focus_handler', 'item_handler_registry', 'item_hover_handler', 'item_resize_handler', 'item_toggled_open_handler', 'item_visible_handler', 'key_down_handler', 'key_press_handler', 'key_release_handler', 'knob_float', 'line_series', 'listbox', 'load_image', 'load_init_file', 'loading_indicator', 'lookat_matrix', 'menu', 'menu_bar', 'menu_item', 'mouse_click_handler', 'mouse_double_click_handler', 'mouse_down_handler', 'mouse_drag_handler', 'mouse_move_handler', 'mouse_release_handler', 'mouse_wheel_handler', 'node', 'node_attribute', 'node_editor', 'node_link', 'orthographic_matrix', 'perspective_matrix', 'pie_series', 'plot', 'plot_annotation', 'plot_axis', 'plot_legend', 'progress_bar', 'radio_button', 'raw_texture', 'resize_handler', 'rotation_matrix', 'same_line', 'scale_matrix', 'scatter_series', 'selectable', 'separator', 'series_value', 'set_item_payload_type', 'shade_series', 'simple_plot', 'slider_double', 'slider_doublex', 'slider_float', 'slider_floatx', 'slider_int', 'slider_intx', 'spacer', 'spacing', 'stage', 'staging_container', 'stair_series', 'static_texture', 'stem_series', 'string_value', 'subplots', 'tab', 'tab_bar', 'tab_button', 'table', 'table_cell', 'table_column', 'table_next_column', 'table_row', 'template_registry', 'text', 'text_point', 'texture_registry', 'theme', 'theme_color', 'theme_component', 'theme_style', 'time_picker', 'toggled_open_handler', 'tooltip', 'translation_matrix', 'tree_node', 'value_registry', 'viewport', 'viewport_drawlist', 'viewport_menu_bar', 'visible_handler', 'vline_series', 'window', 'add_async_function', 'add_monitor', 'add_threaded_task', 'component_exists', 'delete_all', 'delete_element', 'find_texture_registry', 'get', 'get_label_text', 'get_state', 'get_value', 'hide', 'image_from_data_source', 'image_from_file', 'list_to_sublists', 'put', 'remove_monitor', 'run_all_tests', 'set_value', 'show', 'spawn', 'store_contains', 'test_spawn_nested', 'test_spawn_simple', '_format', 'alias', 'alpha_bar', 'alpha_preview', 'always_auto_resize', 'always_on_top', 'always_overwrite', 'always_use_window_padding', 'angle', 'angled_header', 'arrow', 'aspect', 'attr_1', 'attr_2', 'attribute_type', 'auto_fit', 'auto_resize_x', 'auto_resize_y', 'auto_rounding', 'auto_select_all', 'autosize', 'autosize_x', 'autosize_y', 'axis', 'background_color', 'bar_scale', 'bear_color', 'before', 'bins', 'border', 'border_color', 'borders_innerH', 'borders_innerV', 'borders_outerH', 'borders_outerV', 'bottom', 'bounds_max', 'bounds_min', 'box_select_button', 'box_select_cancel_button', 'box_select_mod', 'bull_color', 'bullet', 'button', 'callback', 'cancel_callback', 'category', 'center', 'channel_count', 'chars', 'check', 'circle_count', 'clamped', 'clear_color', 'clipper', 'closable', 'closed', 'closes', 'col_major', 'collapsed', 'color', 'colormap', 'colors', 'cols', 'column_major', 'column_ratios', 'columns', 'context_menu_button', 'context_menu_in_body', 'contribute_to_bounds', 'corner_colors', 'crosshairs', 'ctrl_enter_for_new_line', 'cull_mode', 'cumulative', 'custom_text', 'dates', 'decimal', 'decorated', 'default_filename', 'default_hide', 'default_open', 'default_path', 'default_sort', 'default_value', 'delay', 'delay_search', 'delayed', 'delink_callback', 'density', 'depth_clipping', 'direction', 'directory_selector', 'disable_close', 'disable_popup_close', 'display_hex', 'display_hsv', 'display_mode', 'display_rgb', 'display_type', 'drag_callback', 'drag_data', 'draggable', 'drop_callback', 'drop_data', 'enabled', 'enabled_state', 'equal_aspects', 'escape_clears_all', 'extension', 'eye', 'file', 'file_count', 'fill', 'filter_key', 'first_char', 'fit_button', 'fit_width', 'flattened_navigation', 'foreground_grid', 'fov', 'frame_style', 'freeze_columns', 'freeze_rows', 'front', 'gamma', 'gamma_scale_factor', 'group_size', 'group_width', 'header_row', 'height', 'height_mode', 'hexadecimal', 'hide_on_activity', 'hideable', 'highs', 'hint', 'histogram', 'horizontal', 'horizontal_mod', 'horizontal_scrollbar', 'horizontal_spacing', 'hour24', 'ignore_hidden', 'indent', 'indent_disable', 'indent_enable', 'init_width_or_weight', 'inner_width', 'input_mode', 'invert', 'item', 'item_type', 'items', 'key', 'kwds', 'label', 'label_ids', 'labels', 'large_icon', 'last_char', 'leading', 'leaf', 'left', 'level', 'link_all_x', 'link_all_y', 'link_columns', 'link_rows', 'location', 'lock_max', 'lock_min', 'loop', 'lows', 'max_clamped', 'max_height', 'max_query_rects', 'max_range', 'max_scale', 'max_size', 'max_value', 'max_width', 'max_x', 'max_y', 'max_z', 'menubar', 'min_clamped', 'min_height', 'min_query_rects', 'min_range', 'min_scale', 'min_size', 'min_value', 'min_width', 'min_x', 'min_y', 'min_z', 'minimap', 'minimap_location', 'mirror', 'modal', 'multicolor', 'multiline', 'negative', 'no_align', 'no_alpha', 'no_arrow_button', 'no_background', 'no_border', 'no_box_select', 'no_bring_to_front_on_focus', 'no_buttons', 'no_clip', 'no_close', 'no_collapse', 'no_cursor', 'no_drag_drop', 'no_fit', 'no_focus_on_appearing', 'no_frame', 'no_gridlines', 'no_header_label', 'no_header_width', 'no_hide', 'no_highlight', 'no_highlight_axis', 'no_highlight_item', 'no_horizontal_scroll', 'no_host_extendX', 'no_host_extendY', 'no_initial_fit', 'no_input', 'no_inputs', 'no_keep_columns_visible', 'no_label', 'no_menus', 'no_mouse_pos', 'no_move', 'no_open_over_existing_popup', 'no_options', 'no_pad_innerX', 'no_pad_outerX', 'no_picker', 'no_preview', 'no_reorder', 'no_resize', 'no_saved_settings', 'no_scroll_with_mouse', 'no_scrollbar', 'no_side_preview', 'no_side_switch', 'no_small_preview', 'no_sort', 'no_sort_ascending', 'no_sort_descending', 'no_spaces', 'no_tick_labels', 'no_tick_marks', 'no_title', 'no_title_bar', 'no_tooltip', 'no_undo_redo', 'normalize', 'num_items', 'offset', 'on_close', 'on_enter', 'open_on_arrow', 'open_on_double_click', 'opens', 'opposite', 'order_mode', 'outliers', 'outside', 'overlay', 'override_mod', 'p1', 'p2', 'p3', 'p4', 'pad_outerX', 'pan_button', 'pan_mod', 'pan_stretch', 'parent', 'password', 'payload_type', 'perspective_divide', 'picker_mode', 'pitch', 'pixel_snapH', 'pmax', 'pmin', 'points', 'policy', 'popup', 'popup_align_left', 'pos', 'positive', 'pre_step', 'precise_widths', 'prefer_sort_ascending', 'prefer_sort_descending', 'qualitative', 'query', 'query_color', 'query_toggle_mod', 'radius', 'range_fit', 'readonly', 'reorderable', 'repeat', 'resizable', 'resizable_x', 'resizable_y', 'reverse_dir', 'right', 'rounding', 'row_background', 'row_ratios', 'rows', 'scale', 'scale_max', 'scale_min', 'scales', 'scientific', 'scrollX', 'scrollY', 'secondary_color', 'segments', 'selectable', 'shaded', 'shape', 'share_series', 'shift', 'shortcut', 'show', 'show_label', 'size', 'skip_nan', 'small', 'small_icon', 'sort', 'sort_multi', 'sort_tristate', 'sortable', 'source', 'span_columns', 'span_full_width', 'span_text_width', 'speed', 'stacked', 'step', 'step_fast', 'style', 'tab_input', 'tag', 'target', 'text', 'texture_tag', 'thickness', 'threshold', 'tick_format', 'time_unit', 'tint_color', 'title', 'tooltip', 'top', 'track_offset', 'tracked', 'trailing', 'translation', 'unsaved_document', 'up', 'uppercase', 'use_24hour_clock', 'use_ISO8601', 'use_internal_label', 'use_local_time', 'user_data', 'uv1', 'uv2', 'uv3', 'uv4', 'uv_max', 'uv_min', 'value', 'values', 'vertical', 'vertical_mod', 'vsync', 'weight', 'width', 'width_fixed', 'width_stretch', 'wrap', 'x', 'x_pos', 'xbins', 'xmax_range', 'xmin_range', 'xoffset', 'y', 'y1', 'y2', 'y3', 'y_pos', 'yaw', 'ybins', 'ymax_range', 'ymin_range', 'zFar', 'zNear', 'zoom_mod', 'zoom_rate']