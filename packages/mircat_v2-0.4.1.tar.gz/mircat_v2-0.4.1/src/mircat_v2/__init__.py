from mircat_v2.main import main
