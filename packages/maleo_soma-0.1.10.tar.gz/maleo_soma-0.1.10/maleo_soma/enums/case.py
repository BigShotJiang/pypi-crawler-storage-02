from enum import StrEnum


class Case(StrEnum):
    CAMEL = "camel"
    PASCAL = "pascal"
    SNAKE = "snake"
