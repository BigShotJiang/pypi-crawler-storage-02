Claude Code supports the following tools for commands and agents:
Bash, Glob, Grep, LS, Read, Edit, MultiEdit, Write, WebFetch, WebSearch, Task

**Task Tool Usage**: The Task tool enables agent coordination and delegation. Use according to your specific agent workflow requirements and coordination protocols.