from django.apps import AppConfig

class NominopolitanConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nominopolitan"
    verbose_name = "Neapolitan"
