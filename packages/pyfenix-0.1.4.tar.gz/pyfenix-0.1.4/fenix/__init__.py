# Fenix/fenix/__init__.py
from fenix.core.app import App
from fenix.core.server import run_server

__version__ = "1.0.0"


__all__ = ["App", "run_server"]
