import math

PI = math.pi
E = math.e
