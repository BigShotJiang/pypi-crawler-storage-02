.. automodule:: pydsm.NTFdesign.legacy
