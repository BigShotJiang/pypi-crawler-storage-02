.. automodule:: pydsm.iso226
