.. automodule:: pydsm.NTFdesign.helpers
