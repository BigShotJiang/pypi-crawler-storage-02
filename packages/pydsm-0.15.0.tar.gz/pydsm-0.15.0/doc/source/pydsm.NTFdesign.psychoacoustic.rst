.. automodule:: pydsm.NTFdesign.psychoacoustic
