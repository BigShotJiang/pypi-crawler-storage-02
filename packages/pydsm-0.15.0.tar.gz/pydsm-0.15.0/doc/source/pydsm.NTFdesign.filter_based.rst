.. automodule:: pydsm.NTFdesign.filter_based
