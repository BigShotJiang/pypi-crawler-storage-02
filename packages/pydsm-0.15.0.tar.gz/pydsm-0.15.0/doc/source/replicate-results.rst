How to replicate the results in some recent scientific papers
-------------------------------------------------------------

PyDSM has already been used as a demonstrator for the the concepts in
some scientific papers.

Here, it is shown how to reproduce the results in

.. toctree::
   :maxdepth: 2

   replicate-icecs-2013
   replicate-tcas2-2013
   replicate-tcas1-2013
   replicate-icecs-2012
