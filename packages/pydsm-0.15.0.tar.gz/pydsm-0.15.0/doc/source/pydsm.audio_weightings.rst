.. automodule:: pydsm.audio_weightings
