.. automodule:: pydsm.NTFdesign.merit_factors
