<template>
  <div style="padding: 20px; text-align: center;">
    <h1>Hello Vue!</h1>
    <p>Your Vue app is running successfully.</p>
  </div>
</template>

<script>
export default {
  name: 'Home'
}
</script>
