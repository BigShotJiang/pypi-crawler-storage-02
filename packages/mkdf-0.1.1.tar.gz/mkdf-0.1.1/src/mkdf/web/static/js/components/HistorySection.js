const HistorySection = {
    template: `
        <div class="tab-content">
            <h2>History</h2>
            <p>Recent projects will appear here.</p>
        </div>
    `
};
