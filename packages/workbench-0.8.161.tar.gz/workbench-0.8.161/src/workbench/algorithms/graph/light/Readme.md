# Graph: Light
These algorithms will be based on [NetworkX](https://networkx.org/) + [Pandas](https://pandas.pydata.org/) 