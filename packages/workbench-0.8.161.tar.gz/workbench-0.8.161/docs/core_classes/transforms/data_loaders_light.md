# DataLoaders Light
!!! tip inline end "API Classes"
    For most users the [API Classes](../../api_classes/overview.md) will provide all the general functionality to create a full AWS ML Pipeline

These DataLoader Classes are intended to load smaller dataset into AWS. If you have large data please see [DataLoaders Heavy](data_loaders_heavy.md)

::: workbench.core.transforms.data_loaders.light