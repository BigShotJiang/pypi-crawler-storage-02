"""
A collection of "main" subroutine to start various command-line tools.
"""
