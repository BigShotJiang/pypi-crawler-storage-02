from pyappleinternal.lib.generate_lib import generate_lib
generate_lib()