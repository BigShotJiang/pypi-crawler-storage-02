"""
Defines text constant variables - including for line endings.

[Documentation](http://docs.mrseanryan.cornsnake.s3-website-eu-west-1.amazonaws.com/cornsnake/util_text.html)
"""

LINE_END = "\n"
