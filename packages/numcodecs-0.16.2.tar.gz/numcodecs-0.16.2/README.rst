Numcodecs
=========

Numcodecs is a Python package providing buffer compression and transformation
codecs for use in data storage and communication applications.

.. image:: https://readthedocs.org/projects/numcodecs/badge/?version=latest
    :target: https://numcodecs.readthedocs.io/en/latest/?badge=latest

.. image:: https://github.com/zarr-developers/numcodecs/workflows/Linux%20CI/badge.svg?branch=main
    :target: https://github.com/zarr-developers/numcodecs/actions?query=workflow%3A%22Linux+CI%22

.. image:: https://github.com/zarr-developers/numcodecs/workflows/OSX%20CI/badge.svg?branch=main
    :target: https://github.com/zarr-developers/numcodecs/actions?query=workflow%3A%22OSX+CI%22

.. image:: https://github.com/zarr-developers/numcodecs/workflows/Wheels/badge.svg?branch=main
    :target: https://github.com/zarr-developers/numcodecs/actions?query=workflow%3AWheels

.. image:: https://codecov.io/gh/zarr-developers/numcodecs/branch/main/graph/badge.svg
    :target: https://codecov.io/gh/zarr-developers/numcodecs
