API reference
=============

.. toctree::
    :maxdepth: 2

    compression/index
    filter/index
    other/index
    checksum32
    abc
    registry
    zarr3