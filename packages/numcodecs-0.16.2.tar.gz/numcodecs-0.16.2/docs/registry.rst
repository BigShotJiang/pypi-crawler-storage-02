Codec registry
==============
.. automodule:: numcodecs.registry

.. autofunction:: get_codec
.. autofunction:: register_codec
