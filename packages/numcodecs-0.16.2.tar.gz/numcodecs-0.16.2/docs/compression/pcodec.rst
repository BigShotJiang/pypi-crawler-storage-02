PCodec
======

.. automodule:: numcodecs.pcodec

.. autoclass:: PCodec

    .. autoattribute:: codec_id
    .. automethod:: encode
    .. automethod:: decode
