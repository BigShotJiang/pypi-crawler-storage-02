BZ2
===
.. automodule:: numcodecs.bz2

.. autoclass:: BZ2

    .. autoattribute:: codec_id
    .. automethod:: encode
    .. automethod:: decode
    .. automethod:: get_config
    .. automethod:: from_config
