GZip
====
.. automodule:: numcodecs.gzip

.. autoclass:: GZip

    .. autoattribute:: codec_id
    .. automethod:: encode
    .. automethod:: decode
    .. automethod:: get_config
    .. automethod:: from_config
