Zlib
====
.. automodule:: numcodecs.zlib

.. autoclass:: Zlib

    .. autoattribute:: codec_id
    .. automethod:: encode
    .. automethod:: decode
    .. automethod:: get_config
    .. automethod:: from_config
