"""Environment implementations for mini-SWE-agent."""
