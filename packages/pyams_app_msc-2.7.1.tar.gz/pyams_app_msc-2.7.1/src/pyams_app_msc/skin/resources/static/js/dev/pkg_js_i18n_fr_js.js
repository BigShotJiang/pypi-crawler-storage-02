"use strict";
(self["webpackChunkpyams_app_msc"] = self["webpackChunkpyams_app_msc"] || []).push([["pkg_js_i18n_fr_js"],{

/***/ "./pkg/js/i18n/fr.js":
/*!***************************!*\
  !*** ./pkg/js/i18n/fr.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var fr = {
  BTN_CLOSE: "Fermer",
  SUCCESS: "Opération effectuée",
  ERROR_OCCURRED: "Une erreur s'est produite !",
  ERRORS_OCCURRED: "Des erreurs se sont produites !"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fr);

/***/ })

}]);
//# sourceMappingURL=pkg_js_i18n_fr_js.js.map