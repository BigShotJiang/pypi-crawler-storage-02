from fastapi import FastAPI, HTTPException, Query, APIRouter, Body, Depends

crawl_api_router = APIRouter()
