0.1
-----
- first versioned release

1.0
-----
- includes polystr

1.1.1
-----
- New setup