
from setuptools import setup

setup(package_data={'uwsgidecorators-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed'], 'uwsgi-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
