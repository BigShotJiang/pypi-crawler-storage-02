from .template_lib import Library, add_library_to_environment
