"""
Constants
"""

# AA Memberaudit Doctrine Checker
from madc import __title__, __version__

APP_NAME = "aa-memberaudit-dc"

GITHUB_URL = f"https://github.com/geuthur/{APP_NAME}"
USER_AGENT = f"{__title__}/{__version__} (+{GITHUB_URL})"
