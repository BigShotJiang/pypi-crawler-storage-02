"""Admin models"""

# Django
from django.utils.translation import gettext_lazy as _
