upoqa package
=============

UPOQA Solver
------------

.. automodule:: upoqa
   :members:
   :undoc-members:
   :show-inheritance:

UPOQA Utils
-----------

.. toctree::
   :maxdepth: 4

   upoqa.utils
