2025-06-09 Version: 1.2.1
- Update API GetSymbolicFiles: add request parameters BuildId.


2025-04-02 Version: 1.2.0
- Support API GetSymbolicFiles.
- Support API RequestUploadToken.
- Support API SubmitSymbolic.


2025-02-25 Version: 1.1.0
- Support API GetErrors.
- Support API GetIssue.
- Support API GetIssues.


2025-02-25 Version: 1.0.0
- Support API GetError.


