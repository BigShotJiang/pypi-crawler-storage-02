# from .base import EventSink
# from backend.memory_store import event_store

# class MemorySink(EventSink):

#     def handle_event(self, event_type, data):
#         event_store.append({"type": event_type, "data": data})