from pathlib import Path


def default_model_dir() -> Path:
    return Path(__file__).parent
