from Orbaplaw.WaveFunction import MultiWaveFunction
MultiWaveFunction=MultiWaveFunction.MultiWaveFunction

from Orbaplaw.WaveFunction import QeWaveFunction
QeWaveFunction=QeWaveFunction.QeWaveFunction

from Orbaplaw.WaveFunction import Cube
Cube=Cube.Cube
