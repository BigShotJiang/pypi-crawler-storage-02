__version__ = "1.0.0"
__author__ = "AmirhosseinPython"
__email__ = "amirhossinpython03@gmail.com"
__license__ = "MIT"
