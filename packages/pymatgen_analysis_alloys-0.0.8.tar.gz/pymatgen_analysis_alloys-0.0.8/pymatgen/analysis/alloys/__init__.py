"""
This module defines classes useful for representation of alloy systems and is
intended for semiconductor alloys specifically.
"""
