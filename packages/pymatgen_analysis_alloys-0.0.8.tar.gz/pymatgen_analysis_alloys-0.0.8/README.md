pymatgen-analysis-alloys
========================

`pymatgen-analysis-alloys` is an add-on package for [pymatgen](https://pymatgen.org) intended to contain useful classes
for describing alloy systems and analyzing data relevant to these systems. It currently contains the base classes and
plotting functionality described in [this paper](https://arxiv.org/abs/2206.10715).
