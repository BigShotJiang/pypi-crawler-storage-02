## نصب
```bash
pip install jafrt
```

## استفاده
from jafrt import hello, add, multiply

print(hello("علی"))
print(add(5, 3))
print(multiply(2, 4))

## خروجی
سلام علی! از کتابخانۀ jafrt خوش آمدید.