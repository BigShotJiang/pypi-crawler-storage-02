C     ---------------------------------------
C
C     Control include for implicit
C      implicit none
C       EXTERNAL INTEGER zdssVersion
        INTEGER zdssVersion
C
C     ---------------------------------------

