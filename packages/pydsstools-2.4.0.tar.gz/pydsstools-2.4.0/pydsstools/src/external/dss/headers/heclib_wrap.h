extern "C" {
#include "heclib.h"
}
