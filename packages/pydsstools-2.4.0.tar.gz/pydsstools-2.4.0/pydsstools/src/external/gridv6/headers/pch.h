#pragma once
#include<fstream>
#include<string>
#include<iterator>
#include <climits>
#include <cstring>
#include <iostream>     // std::cout
#include <sstream>      // std::stringstream, std::stringbuf
#include <iomanip> // setprecision
#include <vector>
#include <algorithm>
#include <cmath>
