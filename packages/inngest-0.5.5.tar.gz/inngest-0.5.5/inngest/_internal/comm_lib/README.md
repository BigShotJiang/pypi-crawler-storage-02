The `comm_lib` library contains the framework-agnostic, HTTP-aware communication layer. It's responsible for high-level handling of each request kind:

- Execution
- Inspection
- Synchronization (a.k.a. registration)
