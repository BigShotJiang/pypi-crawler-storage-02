This is a library that contains models and constants that conform to the expectations of an Inngest Server.
