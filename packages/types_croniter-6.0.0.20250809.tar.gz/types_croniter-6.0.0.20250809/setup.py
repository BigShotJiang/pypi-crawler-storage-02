
from setuptools import setup

setup(package_data={'croniter-stubs': ['__init__.pyi', 'croniter.pyi', 'METADATA.toml', 'py.typed']})
