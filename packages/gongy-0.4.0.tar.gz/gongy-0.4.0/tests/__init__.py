"""Testing for gong."""
