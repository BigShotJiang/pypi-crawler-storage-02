# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Module for custom model configuration classes."""
