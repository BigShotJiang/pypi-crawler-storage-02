# -*- coding: utf-8 -*-
from .bk_aidev import BKAidevApi
from .utils import bulk_fetch

__all__ = ["BKAidevApi", "bulk_fetch"]
