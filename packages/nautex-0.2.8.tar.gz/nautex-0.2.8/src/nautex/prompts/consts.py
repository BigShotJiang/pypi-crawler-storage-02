

CMD_NAUTEX_SETUP = 'uvx nautex setup'
