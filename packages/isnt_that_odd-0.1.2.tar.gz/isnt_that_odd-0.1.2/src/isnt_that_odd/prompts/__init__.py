"""Prompts package for the isn't that odd library."""
