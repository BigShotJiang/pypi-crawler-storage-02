from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
        ("netbox_branch_review", "0002_add_description"),
        ("netbox_branch_review", "0002_repair_ticket_column"),
    ]

    operations = []
