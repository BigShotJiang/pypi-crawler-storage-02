document.getElementById("demo-text").addEventListener("click", (e) => {
  loadDemo();
  e.preventDefault();
});
