#!/usr/bin/env python3



import time

time.sleep(5)

x = 0
for i in range(10000000):
    x += 1
print("done")
