import time
import numpy as np


def main():
    # t0 = time.time()
    x = np.array(range(10**7))
    # t1 = time.time()
    # print(t1 - t0)
    # t2 = time.time()
    y = np.array(np.random.uniform(0, 100, size=(10**8)))
    # t3 = time.time()
    # print(t3 - t2)


main()
