This directory contains examples of code before and after
incorporating Scalene's proposed optimizations.