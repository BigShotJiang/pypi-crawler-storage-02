from .fake_user import FakeUser

__all__ = ["FakeUser"]
