class FileDataLoadError(Exception):
    pass
