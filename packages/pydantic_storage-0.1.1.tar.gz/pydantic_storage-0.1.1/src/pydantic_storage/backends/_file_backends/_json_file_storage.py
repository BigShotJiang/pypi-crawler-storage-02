class JsonFileStorage:
    """A backend for storing data in JSON files."""

    ...
