from enum import StrEnum


class Cardinality(StrEnum):
    SINGLE = "single"
    MULTIPLE = "multiple"
