# 初始化子模組 'quote' 位於大模組 'trade'
