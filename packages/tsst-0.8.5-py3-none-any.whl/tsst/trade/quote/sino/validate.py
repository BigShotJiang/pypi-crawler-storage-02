from tsst.trade.quote.base_validate import BaseQuote, BaseBackfilling

class SinoQuoteValidate(BaseQuote):
    """
    永豐報價模組的驗證類別
    """

class SinoBackfilling(BaseBackfilling):
    """
    永豐報價模組的回補類別
    """