from tsst.trade.quote.base_validate import BaseQuote, BaseBackfilling

class CapitalQuoteValidate(BaseQuote):
    """
    群益報價模組的驗證類別
    """

class CapitalBackfilling(BaseBackfilling):
    """
    群益報價模組的回補類別
    """