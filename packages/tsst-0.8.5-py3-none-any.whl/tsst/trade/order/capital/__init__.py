# 初始化券商模組 'capital' 位於子模組 'order'
