from dotenv import load_dotenv

load_dotenv()

class Base:
    """
        Tsst 基底類別
    """
    def __init__(self, **kwargs):
        pass