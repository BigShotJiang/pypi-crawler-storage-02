import random

TIPS = [
    "Use strong, unique passwords for every account.",
    "Enable two-factor authentication wherever possible.",
    "Beware of phishing emails and suspicious links.",
    "Keep your software and operating system updated.",
    "Avoid using public Wi-Fi for sensitive tasks.",
    "Back up your data regularly.",
    "Don’t share sensitive info over unsecured websites.",
    "Use a password manager to store your credentials.",
    "Log out of accounts on shared devices.",
    "Keep your antivirus and firewall enabled."
]

def get_random_tip():
    return random.choice(TIPS)
