from .tips import get_random_tip

def show_tip():
    tip = get_random_tip()
    print(f"🔐 Cyber Tip: {tip}")
