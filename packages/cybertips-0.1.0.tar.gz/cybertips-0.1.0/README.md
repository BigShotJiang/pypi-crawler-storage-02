# CyberTips 🛡️

A lightweight Python package that displays a random cybersecurity tip every time you run it.

## 📦 Installation

```bash
pip install cybertips
