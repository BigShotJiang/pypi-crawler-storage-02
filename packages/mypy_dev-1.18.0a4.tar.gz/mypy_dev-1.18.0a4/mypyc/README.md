mypyc: Mypy to Python C Extension Compiler
==========================================

For the mypyc README, refer to the [mypyc repository](https://github.com/mypyc/mypyc). The mypyc
repository also contains the mypyc issue tracker. All mypyc code lives
here in the mypy repository.

Source code for the mypyc user documentation lives under
[mypyc/doc](./doc).

Mypyc welcomes new contributors! Refer to our
[developer documentation](./doc/dev-intro.md) for more information.
