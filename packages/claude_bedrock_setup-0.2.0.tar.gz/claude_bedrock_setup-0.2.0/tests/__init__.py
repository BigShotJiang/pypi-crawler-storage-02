# Test package for claude-bedrock-setup CLI
