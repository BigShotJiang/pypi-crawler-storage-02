"""Version information for claude-setup package."""

__version__ = "0.2.0"
