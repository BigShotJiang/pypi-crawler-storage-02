"""
Project Provisioner CLI

Uma ferramenta CLI para provisionar automaticamente novos projetos de dados
no Azure DevOps e Databricks com integração completa ao Azure CLI.
"""

__version__ = "0.3.0"
__author__ = "Jose Amaro"
__email__ = "jose.amarodev@gmail.com"
