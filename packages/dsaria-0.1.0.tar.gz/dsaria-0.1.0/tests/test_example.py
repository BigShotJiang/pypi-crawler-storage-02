from dsaria.example import add_two

def test_add_two():
    assert add_two(2, 3) == 5
    assert add_two(1,2) == 3