# Copyright (C) 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Director package."""

from openfl.experimental.workflow.component.director.director import Director
