from nepal_municipalities import NepalMunicipality

district = NepalMunicipality.all_municipalities("Kaski")
print(district)
