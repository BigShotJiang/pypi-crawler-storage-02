"""Main entry point for pysentry when run as a module."""

from . import main

if __name__ == "__main__":
    main()