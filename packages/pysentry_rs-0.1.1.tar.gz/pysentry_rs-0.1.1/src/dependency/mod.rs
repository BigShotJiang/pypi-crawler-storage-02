//! Dependency analysis module

pub use scanner::{DependencyScanner, DependencyStats};

pub mod scanner;
