"""Auto-generated file, do not edit by hand. 66 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_66 = [NumberFormat(pattern='(\\d{4})(\\d{4})', format='\\1 \\2', leading_digits_pattern=['2'])]
