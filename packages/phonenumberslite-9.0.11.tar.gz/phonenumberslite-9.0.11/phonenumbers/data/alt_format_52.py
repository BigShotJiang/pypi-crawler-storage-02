"""Auto-generated file, do not edit by hand. 52 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_52 = [NumberFormat(pattern='(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4 \\5', leading_digits_pattern=['33|5[56]|81']), NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['[24679]|3[0-2457-9]|5[089]|8[02-46-9]'])]
