This README contains the full documentation for your integration.

You auto-generate this README file from your integration YML file using the `demisto-sdk generate-docs` command.

For more information see the [integration documentation](https://xsoar.pan.dev/docs/integrations/integration-docs).
