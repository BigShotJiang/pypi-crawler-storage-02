"""
Errors module.

Provides meaningful error messages for exceptions.

Since:
  2024/02/06

Authors:
  - Breno H. Pelegrin S. <breno.pelegrin@usp.br>
"""