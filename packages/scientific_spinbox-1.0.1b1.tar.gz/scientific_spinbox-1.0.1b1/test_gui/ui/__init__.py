"""
UI files for the testing GUI of ScientificSpinBox.

Authors:
    - Breno H. Pelegrin da S. <breno.pelegrin@usp.br>
"""