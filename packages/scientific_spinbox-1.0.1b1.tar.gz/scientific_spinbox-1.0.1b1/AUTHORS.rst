Authors
=======

Maintainer(s)
-------------

These people were/are maintainers of this project.

- 2023-current - `Breno H. Pelegrin da S. <breno.pelegrin@usp.br>`_
- 2023-current - `Daniel C. Pizetta <daniel.pizetta@alumni.usp.br>`_
- 2018-2020 - `Eduardo R. Falvo <dudu.falvo@gmail.com>`_

Contributor(s)
--------------

These people contributed to bug fixes, improvements, and new features.

- Year-Year - Name - contribution.
- 2023-current - `Breno H. Pelegrin da S. <breno.pelegrin@usp.br>`_ - All development since 2023
- 2018-2020 - `Eduardo R. Falvo <dudu.falvo@gmail.com>`_ - Initial development of the project
