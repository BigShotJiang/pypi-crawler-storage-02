"""Contains common ARPES analysis routines."""
