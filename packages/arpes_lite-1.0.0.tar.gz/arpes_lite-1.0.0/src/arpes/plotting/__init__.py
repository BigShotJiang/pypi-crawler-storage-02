"""Standard plotting routines and utility code for ARPES analyses."""
