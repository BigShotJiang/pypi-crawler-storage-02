import { Store } from 'pullstate';

export const initialState = {};

export const ExtensionStore = new Store(initialState);