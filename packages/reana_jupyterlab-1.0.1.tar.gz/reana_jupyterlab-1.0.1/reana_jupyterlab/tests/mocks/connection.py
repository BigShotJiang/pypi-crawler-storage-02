MOCK_SERVER = "https://mock-reana/"
MOCK_TOKEN = 'mock_token'