"""XLIFF MCP Server - Process XLIFF translation files via Model Context Protocol"""

__version__ = "0.1.0"