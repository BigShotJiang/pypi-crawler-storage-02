"""Tests for RoboSystems SDK Extensions"""
