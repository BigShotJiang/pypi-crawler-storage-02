from python_mommy import mommy


if __name__ == "__main__":
    mommy()
