import time

print("running meow.py")
time.sleep(0)dfsadfas