"""
Setup script for WeatherLink v2 API Python Library
"""

from setuptools import setup

# Minimal setup for legacy compatibility
# Main configuration is in pyproject.toml
setup()
