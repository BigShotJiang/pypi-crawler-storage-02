.. FSEconomy for Python documentation master file, created by
   sphinx-quickstart on Sun Oct 29 21:32:02 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

FSEconomy for Python
====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   guide/index
   api/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
