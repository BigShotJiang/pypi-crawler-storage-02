User Guide
==========

This part of the documentation provides a practical guide for using `fseconomy`,
demonstrating how to access the different parts of the API.

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    setup
    data