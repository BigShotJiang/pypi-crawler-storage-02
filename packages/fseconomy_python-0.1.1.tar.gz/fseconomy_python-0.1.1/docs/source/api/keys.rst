.. _keys:

Key Management Functions
========================

.. module:: fseconomy

.. autofunction:: fseconomy.set_user_key
.. autofunction:: fseconomy.set_access_key
.. autofunction:: fseconomy.set_service_key