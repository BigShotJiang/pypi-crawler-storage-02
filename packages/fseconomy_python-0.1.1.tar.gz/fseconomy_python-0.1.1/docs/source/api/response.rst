.. _response:

Server Response
===============

.. module:: fseconomy.response

.. autoclass:: Response
   :members:
   :undoc-members:
