# -*- coding: utf-8 -*-
"""
current_controller_sdk：电流控制器串口通信SDK
"""
from .core import CurrentControllerSDK

__version__ = "1.0.0"
__author__ = "hxp"
__all__ = ["CurrentControllerSDK"]  # 公开接口