from pathlib import Path

PKG_PATH = Path(__file__).parent.parent

WIDGETS_DIR = PKG_PATH / "_widgets"
