# This information is located in its own file so that it can be loaded
# without importing the main package when its dependencies are not installed.
# See: https://packaging.python.org/guides/single-sourcing-package-version

__author__ = "Tek Kshetri"
__email__ = "iamtekson@gmail.com"
__version__ = "2.10.0"
