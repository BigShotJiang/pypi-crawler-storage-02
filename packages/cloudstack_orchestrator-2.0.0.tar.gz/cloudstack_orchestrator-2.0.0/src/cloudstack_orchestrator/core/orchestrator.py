"""Core orchestrator for CloudStack platform setup and management."""

import os
import subprocess
from typing import Dict, List, Optional, Any
from pathlib import Path
import yaml

from kubernetes import client, config as k8s_config
from kubernetes.client.rest import ApiException
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from .config import Config
from .secrets import SecretsManager
from ..providers.github import GitHubProvider


class Orchestrator:
    """Core orchestrator that handles platform setup and management."""
    
    def _get_github_token(self) -> Optional[str]:
        """Get GitHub token from multiple sources (config, env, gh CLI)."""
        # 1. Try to get from config
        if self.config.github and self.config.github.token:
            return self.config.github.token
        
        # 2. Try to get from environment
        github_token = os.getenv("GITHUB_TOKEN")
        if github_token:
            return github_token
        
        # 3. Try to get from gh CLI
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
        
        return None
    
    def __init__(self, config: Config, console: Optional[Console] = None):
        self.config = config
        self.console = console or Console()
        self.secrets_manager = SecretsManager(config)
        self.github_provider = GitHubProvider(config.github.token) if config.github.token else None
        
        # Initialize Kubernetes client
        try:
            k8s_config.load_kube_config()
            self.k8s_api = client.CoreV1Api()
            self.k8s_apps_api = client.AppsV1Api()
        except Exception as e:
            self.console.print(f"[red]⚠️ Warning: Could not load Kubernetes config: {e}[/red]")
            self.k8s_api = None
            self.k8s_apps_api = None
    
    async def setup(self) -> Dict[str, Any]:
        """Run the complete setup process."""
        results = {}
        
        # Show setup info
        if self.config.is_local:
            self.console.print("[dim]→ Auto-generating secure passwords for local setup[/dim]")
        else:
            self.console.print(f"[dim]→ Storing secrets in AWS Secrets Manager ({self.config.region})[/dim]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
            transient=True  # This makes the progress bar disappear after completion
        ) as progress:
            # Validate prerequisites
            task = progress.add_task("Validating prerequisites...", total=None)
            prereq_result = await self.validate_prerequisites()
            if not prereq_result["valid"]:
                raise RuntimeError(f"Prerequisites validation failed: {prereq_result['errors']}")
            progress.update(task, completed=True)
            results["prerequisites"] = prereq_result
            
            # Ensure secrets
            task = progress.add_task("Managing secrets...", total=None)
            secrets = await self.secrets_manager.ensure_all_secrets()
            progress.update(task, completed=True)
            results["secrets"] = {"count": len(secrets), "created": True}
            
            # Create namespaces
            task = progress.add_task("Creating namespaces...", total=None)
            namespaces = await self.create_namespaces()
            progress.update(task, completed=True)
            results["namespaces"] = namespaces
            
            # Create Kubernetes secrets
            task = progress.add_task("Creating Kubernetes secrets...", total=None)
            k8s_secrets = await self.create_kubernetes_secrets()
            progress.update(task, completed=True)
            results["kubernetes_secrets"] = k8s_secrets
            
            # Configure ArgoCD repository access if GitHub token provided
            if self.config.github.token:
                task = progress.add_task("Configuring ArgoCD repository access...", total=None)
                repo_config = await self.configure_argocd_repo()
                progress.update(task, completed=True)
                results["argocd_repo"] = repo_config
            
            # Install Istio
            task = progress.add_task("Installing Istio service mesh...", total=None)
            istio_result = await self.install_istio()
            progress.update(task, completed=True)
            results["istio"] = istio_result
            
            # Install ArgoCD
            task = progress.add_task("Installing ArgoCD...", total=None)
            argocd_result = await self.install_argocd()
            progress.update(task, completed=True)
            results["argocd"] = argocd_result
            
            # Deploy platform
            task = progress.add_task("Deploying platform...", total=None)
            platform_result = await self.deploy_platform()
            progress.update(task, completed=True)
            results["platform"] = platform_result
            
            # Configure local development access (Docker Desktop)
            if self.config.is_local:
                task = progress.add_task("Configuring local development access...", total=None)
                local_access = await self.configure_local_access()
                progress.update(task, completed=True)
                results["local_access"] = local_access
        
        return results
    
    async def validate_prerequisites(self) -> Dict[str, Any]:
        """Validate that all prerequisites are met."""
        errors = []
        warnings = []
        
        # Check kubectl
        if not self._command_exists("kubectl"):
            errors.append("kubectl not found in PATH")
        
        # Check helm
        if not self._command_exists("helm"):
            errors.append("helm not found in PATH")
        
        # Check Kubernetes connection
        if self.k8s_api:
            try:
                self.k8s_api.list_namespace()
            except Exception as e:
                errors.append(f"Cannot connect to Kubernetes cluster: {e}")
        else:
            errors.append("Kubernetes client not initialized")
        
        # Check GitHub token if provided
        if self.github_provider:
            try:
                await self.github_provider.validate_token()
            except Exception as e:
                warnings.append(f"GitHub token validation failed: {e}")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
    
    async def create_namespaces(self) -> List[str]:
        """Create required namespaces."""
        namespaces = [
            "argocd",
            "platform",
            "istio-system",
            "keycloak",
            "auth",
            "cert-manager"
        ]
        
        created = []
        for ns in namespaces:
            try:
                self.k8s_api.create_namespace(
                    client.V1Namespace(
                        metadata=client.V1ObjectMeta(name=ns)
                    )
                )
                created.append(ns)
            except ApiException as e:
                if e.status == 409:  # Already exists
                    pass
                else:
                    raise
        
        return created
    
    async def create_kubernetes_secrets(self) -> Dict[str, bool]:
        """Create Kubernetes secrets from secrets manager."""
        k8s_secrets = await self.secrets_manager.export_kubernetes_secrets()
        results = {}
        
        for secret_name, secret_config in k8s_secrets.items():
            namespace = secret_config["namespace"]
            data = secret_config["data"]
            
            # Convert to base64
            import base64
            encoded_data = {
                k: base64.b64encode(v.encode()).decode()
                for k, v in data.items()
            }
            
            try:
                self.k8s_api.create_namespaced_secret(
                    namespace=namespace,
                    body=client.V1Secret(
                        metadata=client.V1ObjectMeta(name=secret_name),
                        type="Opaque",
                        data=encoded_data
                    )
                )
                results[f"{namespace}/{secret_name}"] = True
            except ApiException as e:
                if e.status == 409:  # Already exists
                    # Update it
                    self.k8s_api.patch_namespaced_secret(
                        name=secret_name,
                        namespace=namespace,
                        body=client.V1Secret(
                            data=encoded_data
                        )
                    )
                    results[f"{namespace}/{secret_name}"] = True
                else:
                    results[f"{namespace}/{secret_name}"] = False
        
        return results
    
    async def install_istio(self) -> Dict[str, Any]:
        """Install Istio service mesh."""
        # Add Istio Helm repo
        subprocess.run(["helm", "repo", "add", "istio", "https://istio-release.storage.googleapis.com/charts"], check=True)
        subprocess.run(["helm", "repo", "update"], check=True)
        
        # Install Istio base (CRDs)
        subprocess.run([
            "helm", "upgrade", "--install", "istio-base",
            "istio/base",
            "--namespace", "istio-system",
            "--create-namespace",
            "--version", "1.26.3",
            "--wait"
        ], check=True)
        
        # Install Istiod (control plane)
        istio_values = {
            "pilot": {
                "autoscaleEnabled": False,
                "resources": {
                    "requests": {
                        "cpu": "100m",
                        "memory": "128Mi"
                    }
                }
            }
        }
        
        # Write values to temp file
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(istio_values, f)
            values_file = f.name
        
        try:
            subprocess.run([
                "helm", "upgrade", "--install", "istiod",
                "istio/istiod",
                "--namespace", "istio-system",
                "--version", "1.26.3",
                "-f", values_file,
                "--wait"
            ], check=True)
            
            # Optionally install ingress gateway for local development
            if self.config.is_local:
                gateway_values = {
                    "service": {
                        "type": "NodePort",
                        "ports": [
                            {"port": 80, "targetPort": 8080, "nodePort": 30090, "name": "http2"},
                            {"port": 443, "targetPort": 8443, "nodePort": 30443, "name": "https"}
                        ]
                    },
                    "resources": {
                        "requests": {
                            "cpu": "100m",
                            "memory": "128Mi"
                        }
                    }
                }
                
                with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                    yaml.dump(gateway_values, f)
                    gateway_values_file = f.name
                
                try:
                    subprocess.run([
                        "helm", "upgrade", "--install", "istio-ingressgateway",
                        "istio/gateway",
                        "--namespace", "istio-system",
                        "--version", "1.26.3",
                        "-f", gateway_values_file,
                        "--wait"
                    ], check=True)
                finally:
                    Path(gateway_values_file).unlink()
            
            return {
                "installed": True,
                "namespace": "istio-system",
                "version": "1.26.3"
            }
        finally:
            Path(values_file).unlink()
    
    async def install_argocd(self) -> Dict[str, Any]:
        """Install ArgoCD using Helm."""
        # Add Helm repo
        subprocess.run(["helm", "repo", "add", "argo", "https://argoproj.github.io/argo-helm"], check=True)
        subprocess.run(["helm", "repo", "update"], check=True)
        
        # Install ArgoCD
        # Get ArgoCD ports from environment or use defaults
        argocd_http_port = int(os.getenv("CSO_ARGOCD_HTTP_PORT", "30080"))
        argocd_https_port = int(os.getenv("CSO_ARGOCD_HTTPS_PORT", "30444"))  # Avoid conflict with Istio's 30443
        
        helm_values = {
            "server": {
                "service": {
                    "type": "NodePort" if self.config.is_local else "LoadBalancer",
                    "nodePortHttp": argocd_http_port if self.config.is_local else None,
                    "nodePortHttps": argocd_https_port if self.config.is_local else None
                },
                "extraArgs": ["--insecure"]
            }
        }
        
        # Write values to temp file
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(helm_values, f)
            values_file = f.name
        
        try:
            # Get ArgoCD version from environment or use latest stable
            argocd_version = os.getenv("CSO_ARGOCD_VERSION", "8.2.5")
            
            subprocess.run([
                "helm", "upgrade", "--install", "argocd",
                "argo/argo-cd",
                "--namespace", "argocd",
                "--version", argocd_version,
                "-f", values_file,
                "--wait"
            ], check=True)
            
            # Get admin password
            result = subprocess.run([
                "kubectl", "-n", "argocd", "get", "secret",
                "argocd-initial-admin-secret",
                "-o", "jsonpath={.data.password}"
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                import base64
                password = base64.b64decode(result.stdout).decode()
            else:
                password = None
            
            return {
                "installed": True,
                "admin_password": password,
                "url": f"http://localhost:{argocd_http_port}" if self.config.is_local else f"https://argocd.{self.config.domain}"
            }
        finally:
            Path(values_file).unlink()
    
    async def deploy_platform(self) -> Dict[str, Any]:
        """Deploy the CloudStack platform via ArgoCD."""
        # First, ensure platform Helm templates exist to disable default deployment
        await self._ensure_platform_templates()
        
        # Get GitHub token from multiple sources
        github_token = self._get_github_token()
        if github_token:
            self.console.print("[green]✓[/green] GitHub token found")
        
        # Only create repository secret if we have a token
        if github_token:
            repo_secret = {
                "apiVersion": "v1",
                "kind": "Secret",
                "metadata": {
                    "name": "cloudstack-orchestrator-repo",
                    "namespace": "argocd",
                    "labels": {
                        "argocd.argoproj.io/secret-type": "repository"
                    }
                },
                "stringData": {
                    "type": "git",
                    "url": "https://github.com/killerapp/cloudstack-orchestrator.git",
                    "username": "not-used",  # GitHub token auth doesn't use username
                    "password": github_token
                }
            }
            
            # Apply repository secret
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                yaml.dump(repo_secret, f)
                repo_file = f.name
            
            try:
                subprocess.run(["kubectl", "apply", "-f", repo_file], check=True)
                self.console.print("[green]✓[/green] Repository secret configured")
            finally:
                Path(repo_file).unlink()
        else:
            self.console.print("[yellow]⚠[/yellow] No GitHub token found - repository may be inaccessible if private")
            self.console.print("  Configure with: [cyan]cso auth --github-org killerapp[/cyan]")
            self.console.print("  Or: [cyan]gh auth login[/cyan]")
        
        # Create platform application
        platform_app = {
            "apiVersion": "argoproj.io/v1alpha1",
            "kind": "Application",
            "metadata": {
                "name": "cloudstack-platform",
                "namespace": "argocd"
            },
            "spec": {
                "project": "default",
                "source": {
                    "repoURL": "https://github.com/killerapp/cloudstack-orchestrator",
                    "targetRevision": "main",
                    "path": "platform",
                    "helm": {
                        "valueFiles": [
                            "values.yaml",
                            "values-local.yaml" if self.config.is_local else "values-production.yaml"
                        ]
                    }
                },
                "destination": {
                    "server": "https://kubernetes.default.svc",
                    "namespace": "platform"
                },
                "syncPolicy": {
                    "automated": {
                        "prune": False,
                        "selfHeal": False
                    },
                    "syncOptions": [
                        "CreateNamespace=true",
                        "ServerSideApply=true"
                    ]
                }
            }
        }
        
        # Apply platform application
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(platform_app, f)
            app_file = f.name
        
        try:
            subprocess.run(["kubectl", "apply", "-f", app_file], check=True)
            return {"deployed": True, "application": "cloudstack-platform"}
        finally:
            Path(app_file).unlink()
    
    async def configure_argocd_helm_repos(self) -> Dict[str, Any]:
        """Configure ArgoCD Helm repositories for platform dependencies."""
        # Standard Helm repositories needed by the platform
        repositories = [
            {"name": "bitnami", "url": "https://charts.bitnami.com/bitnami"},
            {"name": "oauth2-proxy", "url": "https://oauth2-proxy.github.io/manifests"},
            {"name": "jetstack", "url": "https://charts.jetstack.io"},
            {"name": "prometheus-community", "url": "https://prometheus-community.github.io/helm-charts"},
            {"name": "cloudnative-pg", "url": "https://cloudnative-pg.github.io/charts"},
            {"name": "argoproj", "url": "https://argoproj.github.io/argo-helm"},
            {"name": "istio", "url": "https://istio-release.storage.googleapis.com/charts"}
        ]
        
        created_repos = []
        
        for repo in repositories:
            repo_secret = {
                "apiVersion": "v1",
                "kind": "Secret",
                "metadata": {
                    "name": f"{repo['name']}-repo",
                    "namespace": "argocd",
                    "labels": {
                        "argocd.argoproj.io/secret-type": "repository"
                    }
                },
                "stringData": {
                    "type": "helm",
                    "name": repo['name'],
                    "url": repo['url']
                }
            }
            
            # Apply repository secret
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                yaml.dump(repo_secret, f)
                repo_file = f.name
            
            try:
                result = subprocess.run(
                    ["kubectl", "apply", "-f", repo_file], 
                    capture_output=True, 
                    text=True
                )
                if result.returncode == 0:
                    created_repos.append(repo['name'])
                    self.console.print(f"[green]✓[/green] Configured {repo['name']} repository")
                else:
                    self.console.print(f"[yellow]⚠[/yellow] Failed to configure {repo['name']}: {result.stderr}")
            finally:
                Path(repo_file).unlink()
        
        # Restart repo server if any repos were added
        if created_repos:
            self.console.print("[cyan]Restarting ArgoCD repo server...[/cyan]")
            result = subprocess.run([
                "kubectl", "rollout", "restart", 
                "deployment", "argocd-repo-server", 
                "-n", "argocd"
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                self.console.print("[green]✓[/green] ArgoCD repo server restarted")
            
        return {
            "configured_repositories": created_repos,
            "total_repositories": len(repositories)
        }

    async def configure_argocd_repo(self) -> Dict[str, bool]:
        """Configure ArgoCD repository access with GitHub credentials."""
        # First check if ArgoCD namespace exists
        try:
            self.k8s_api.read_namespace(name="argocd")
        except ApiException as e:
            if e.status == 404:
                return {
                    "created": False, 
                    "updated": False, 
                    "error": "ArgoCD is not installed. Run 'cso setup' first."
                }
            raise
        
        # Get GitHub token from multiple sources
        github_token = self._get_github_token()
        if not github_token:
            return {
                "created": False,
                "updated": False,
                "error": "No GitHub token found. Run 'gh auth login' or set GITHUB_TOKEN environment variable."
            }
        
        repo_url = f"https://github.com/{self.config.github.org}/cloudstack-orchestrator.git"
        secret_name = "cloudstack-orchestrator-repo"
        
        # Create repository secret with proper ArgoCD labels
        secret_data = {
            "type": "git",
            "url": repo_url,
            "username": "not-used",  # GitHub token auth doesn't use username
            "password": github_token
        }
        
        # Convert to base64
        import base64
        encoded_data = {
            k: base64.b64encode(v.encode()).decode()
            for k, v in secret_data.items()
        }
        
        try:
            # Check if secret exists
            try:
                existing = self.k8s_api.read_namespaced_secret(
                    name=secret_name,
                    namespace="argocd"
                )
                # Update existing secret
                existing.data = encoded_data
                self.k8s_api.patch_namespaced_secret(
                    name=secret_name,
                    namespace="argocd",
                    body=existing
                )
                return {"created": False, "updated": True, "url": repo_url}
            except ApiException as e:
                if e.status == 404:
                    # Create new secret
                    secret = client.V1Secret(
                        metadata=client.V1ObjectMeta(
                            name=secret_name,
                            namespace="argocd",
                            labels={
                                "argocd.argoproj.io/secret-type": "repository"
                            }
                        ),
                        type="Opaque",
                        data=encoded_data
                    )
                    self.k8s_api.create_namespaced_secret(
                        namespace="argocd",
                        body=secret
                    )
                    return {"created": True, "updated": False, "url": repo_url}
                else:
                    raise
        except Exception as e:
            self.console.print(f"[yellow]Warning: Could not configure ArgoCD repository: {e}[/yellow]")
            return {"created": False, "updated": False, "error": str(e)}
    
    def _command_exists(self, command: str) -> bool:
        """Check if a command exists in PATH."""
        import shutil
        return shutil.which(command) is not None
    
    async def _ensure_platform_templates(self):
        """Ensure platform Helm templates exist to disable default deployment."""
        templates_dir = Path("platform/templates")
        
        # Check if we're in the right directory
        if not Path("platform/Chart.yaml").exists():
            self.console.print("[yellow]Warning: Not in cloudstack-orchestrator root directory[/yellow]")
            return
            
        # Create templates directory if it doesn't exist
        templates_dir.mkdir(exist_ok=True)
        
        # Create _helpers.tpl if it doesn't exist
        helpers_file = templates_dir / "_helpers.tpl"
        if not helpers_file.exists():
            helpers_content = '''{{/*
Expand the name of the chart.
*/}}
{{- define "cloudstack-orchestrator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cloudstack-orchestrator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cloudstack-orchestrator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloudstack-orchestrator.labels" -}}
helm.sh/chart: {{ include "cloudstack-orchestrator.chart" . }}
{{ include "cloudstack-orchestrator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloudstack-orchestrator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cloudstack-orchestrator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}'''
            helpers_file.write_text(helpers_content)
        
        # Create deployment.yaml to disable default deployment
        deployment_file = templates_dir / "deployment.yaml"
        if not deployment_file.exists():
            deployment_content = '''# Disable the default deployment - CloudStack Orchestrator is a platform
# composed of multiple services (ArgoCD, Keycloak, Istio, etc.) not a single app
{{- if .Values.deployment.enabled }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "cloudstack-orchestrator.fullname" . }}
  labels:
    {{- include "cloudstack-orchestrator.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      {{- include "cloudstack-orchestrator.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      labels:
        {{- include "cloudstack-orchestrator.selectorLabels" . | nindent 8 }}
    spec:
      containers:
      - name: {{ .Chart.Name }}
        image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
        imagePullPolicy: {{ .Values.image.pullPolicy }}
        ports:
        - name: http
          containerPort: 8080
          protocol: TCP
{{- end }}'''
            deployment_file.write_text(deployment_content)
        
        # Create service.yaml
        service_file = templates_dir / "service.yaml"
        if not service_file.exists():
            service_content = '''# Disable the default service - CloudStack Orchestrator services are provided
# by the individual components (ArgoCD, Keycloak, Istio, etc.)
{{- if .Values.deployment.enabled }}
apiVersion: v1
kind: Service
metadata:
  name: {{ include "cloudstack-orchestrator.fullname" . }}
  labels:
    {{- include "cloudstack-orchestrator.labels" . | nindent 4 }}
spec:
  type: {{ .Values.service.type }}
  ports:
    - port: {{ .Values.service.port }}
      targetPort: http
      protocol: TCP
      name: http
  selector:
    {{- include "cloudstack-orchestrator.selectorLabels" . | nindent 4 }}
{{- end }}'''
            service_file.write_text(service_content)
        
        # Create hpa.yaml
        hpa_file = templates_dir / "hpa.yaml"
        if not hpa_file.exists():
            hpa_content = '''# Disable the default HPA - CloudStack Orchestrator components manage their own scaling
{{- if and .Values.deployment.enabled .Values.autoscaling.enabled }}
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ include "cloudstack-orchestrator.fullname" . }}
  labels:
    {{- include "cloudstack-orchestrator.labels" . | nindent 4 }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {{ include "cloudstack-orchestrator.fullname" . }}
  minReplicas: {{ .Values.autoscaling.minReplicas }}
  maxReplicas: {{ .Values.autoscaling.maxReplicas }}
  metrics:
    {{- if .Values.autoscaling.targetCPUUtilizationPercentage }}
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: {{ .Values.autoscaling.targetCPUUtilizationPercentage }}
    {{- end }}
    {{- if .Values.autoscaling.targetMemoryUtilizationPercentage }}
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: {{ .Values.autoscaling.targetMemoryUtilizationPercentage }}
    {{- end }}
{{- end }}'''
            hpa_file.write_text(hpa_content)
        
        # Update values.yaml to disable deployment
        values_file = Path("platform/values.yaml")
        if values_file.exists():
            values_content = values_file.read_text()
            if "deployment:" not in values_content:
                # Add deployment config at the beginning after the header comments
                lines = values_content.split('\n')
                insert_idx = 0
                for i, line in enumerate(lines):
                    if line.strip() and not line.strip().startswith('#'):
                        insert_idx = i
                        break
                
                deployment_config = '''# Disable default deployment - CSO is a platform, not a single app
deployment:
  enabled: false

# Default values that would normally configure the deployment
image:
  repository: nginx
  pullPolicy: IfNotPresent
  tag: ""

replicaCount: 1

service:
  type: ClusterIP
  port: 80

autoscaling:
  enabled: false
  minReplicas: 1
  maxReplicas: 100
  targetCPUUtilizationPercentage: 80

'''
                lines.insert(insert_idx, deployment_config)
                values_file.write_text('\n'.join(lines))
    
    async def get_status(self) -> Dict[str, Any]:
        """Get current platform status."""
        status = {
            "config": self.config.to_dict(),
            "kubernetes": {"connected": False, "context": None, "cluster": None},
            "argocd": {"installed": False},
            "platform": {"deployed": False},
            "github": {"connected": False},
            "argocd_apps": {}
        }
        
        # Get current kubectl context
        try:
            result = subprocess.run(
                ["kubectl", "config", "current-context"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                status["kubernetes"]["context"] = result.stdout.strip()
                
            # Get cluster info
            result = subprocess.run(
                ["kubectl", "config", "view", "--minify", "-o", "jsonpath={.clusters[0].name}"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                status["kubernetes"]["cluster"] = result.stdout.strip()
        except:
            pass
        
        # Check Kubernetes connection
        if self.k8s_api:
            try:
                self.k8s_api.list_namespace()
                status["kubernetes"]["connected"] = True
            except:
                pass
        
        # Check ArgoCD
        try:
            result = subprocess.run([
                "kubectl", "get", "deployment",
                "argocd-server", "-n", "argocd"
            ], capture_output=True)
            if result.returncode == 0:
                status["argocd"]["installed"] = True
                
                # Get ArgoCD admin password
                try:
                    result = subprocess.run([
                        "kubectl", "-n", "argocd", "get", "secret",
                        "argocd-initial-admin-secret", "-o",
                        "jsonpath={.data.password}"
                    ], capture_output=True, text=True)
                    if result.returncode == 0 and result.stdout:
                        import base64
                        password = base64.b64decode(result.stdout).decode()
                        status["argocd"]["admin_password"] = password
                except:
                    pass
        except:
            pass
        
        # Check GitHub repository connection
        try:
            result = subprocess.run([
                "kubectl", "get", "secret", "github-repo-creds",
                "-n", "argocd", "-o", "jsonpath={.metadata.name}"
            ], capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip() == "github-repo-creds":
                status["github"]["connected"] = True
        except:
            pass
        
        # Check ArgoCD applications
        if status["argocd"]["installed"]:
            try:
                result = subprocess.run([
                    "kubectl", "get", "applications", "-n", "argocd",
                    "-o", "jsonpath={range .items[*]}{.metadata.name}{'|'}{.status.sync.status}{'|'}{.status.health.status}{'\\n'}{end}"
                ], capture_output=True, text=True)
                
                if result.returncode == 0 and result.stdout:
                    for line in result.stdout.strip().split('\n'):
                        if line:
                            parts = line.split('|')
                            if len(parts) >= 3:
                                app_name = parts[0]
                                status["argocd_apps"][app_name] = {
                                    "sync": parts[1],
                                    "health": parts[2]
                                }
            except:
                pass
        
        # Check platform application
        try:
            result = subprocess.run([
                "kubectl", "get", "application",
                "cloudstack-platform", "-n", "argocd"
            ], capture_output=True)
            if result.returncode == 0:
                status["platform"]["deployed"] = True
                
                # Get Keycloak admin password if platform is deployed
                try:
                    result = subprocess.run([
                        "kubectl", "-n", "platform", "get", "secret",
                        "keycloak-admin-creds", "-o",
                        "jsonpath={.data.admin-password}"
                    ], capture_output=True, text=True)
                    if result.returncode == 0 and result.stdout:
                        import base64
                        password = base64.b64decode(result.stdout).decode()
                        status["keycloak"] = {
                            "installed": True,
                            "admin_password": password
                        }
                    elif result.returncode != 0:
                        # Secret doesn't exist yet or platform namespace missing
                        status["keycloak"] = {
                            "installed": False,
                            "error": "Secret not found"
                        }
                except Exception as e:
                    status["keycloak"] = {
                        "installed": False,
                        "error": str(e)
                    }
        except:
            pass
        
        return status
    
    async def configure_local_access(self) -> Dict[str, bool]:
        """Configure LoadBalancer services for local Docker Desktop access."""
        services = []
        
        # Define LoadBalancer services for local development
        lb_services = [
            {
                "name": "argocd-server-local",
                "namespace": "argocd",
                "selector": {"app.kubernetes.io/name": "argocd-server"},
                "port": 30080,
                "targetPort": 8080,
                "description": "ArgoCD UI"
            },
            {
                "name": "keycloak-local",
                "namespace": "platform",
                "selector": {
                    "app.kubernetes.io/component": "keycloak",
                    "app.kubernetes.io/instance": "cloudstack-platform",
                    "app.kubernetes.io/name": "keycloak"
                },
                "port": 30081,
                "targetPort": 8080,
                "description": "Keycloak Admin"
            },
            {
                "name": "oauth2-proxy-local",
                "namespace": "auth",
                "selector": {"app": "oauth2-proxy"},
                "port": 30082,
                "targetPort": 4180,
                "description": "OAuth2 Proxy (Platform Entry)"
            },
            {
                "name": "voicefuse-local",
                "namespace": "voicefuse",
                "selector": {"app": "voicefuse"},
                "port": 30083,
                "targetPort": 8080,
                "description": "VoiceFuse UI"
            },
            {
                "name": "langfuse-local",
                "namespace": "langfuse",
                "selector": {"app": "langfuse"},
                "port": 30084,
                "targetPort": 3000,
                "description": "Langfuse UI"
            }
        ]
        
        for svc in lb_services:
            try:
                # Check if namespace exists first
                try:
                    self.k8s_api.read_namespace(name=svc["namespace"])
                except ApiException as e:
                    if e.status == 404:
                        # Skip if namespace doesn't exist yet
                        continue
                
                # Create LoadBalancer service
                service = client.V1Service(
                    metadata=client.V1ObjectMeta(
                        name=svc["name"],
                        namespace=svc["namespace"],
                        labels={
                            "app.kubernetes.io/managed-by": "cso",
                            "cso.platform/service-type": "local-access"
                        }
                    ),
                    spec=client.V1ServiceSpec(
                        type="LoadBalancer",
                        selector=svc["selector"],
                        ports=[
                            client.V1ServicePort(
                                name="http",
                                port=svc["port"],
                                target_port=svc["targetPort"],
                                protocol="TCP"
                            )
                        ]
                    )
                )
                
                try:
                    self.k8s_api.create_namespaced_service(
                        namespace=svc["namespace"],
                        body=service
                    )
                    services.append({
                        "name": svc["name"],
                        "port": svc["port"],
                        "description": svc["description"],
                        "created": True
                    })
                except ApiException as e:
                    if e.status == 409:  # Already exists
                        # Update existing service
                        self.k8s_api.patch_namespaced_service(
                            name=svc["name"],
                            namespace=svc["namespace"],
                            body=service
                        )
                        services.append({
                            "name": svc["name"],
                            "port": svc["port"],
                            "description": svc["description"],
                            "updated": True
                        })
                    else:
                        self.console.print(f"[yellow]Warning: Could not create service {svc['name']}: {e}[/yellow]")
                        
            except Exception as e:
                self.console.print(f"[yellow]Warning: Error with service {svc['name']}: {e}[/yellow]")
        
        return {"services": services}
    
    async def teardown(self) -> Dict[str, Any]:
        """Teardown the CloudStack Orchestrator platform."""
        results = {
            "success": True,
            "deleted": {
                "helm_releases": [],
                "applications": [],
                "namespaces": [],
                "crds": []
            }
        }
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
            transient=True  # This makes the progress bar disappear after completion
        ) as progress:
            # Delete Helm releases first
            task = progress.add_task("Deleting Helm releases...", total=None)
            try:
                # Get all Helm releases across all namespaces
                result = subprocess.run(
                    ["helm", "list", "-A", "-o", "json"],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0 and result.stdout:
                    import json
                    releases = json.loads(result.stdout)
                    
                    # Uninstall each release
                    for release in releases:
                        # Skip releases not managed by CSO based on configurable labels
                        if release.get("namespace") in ["kube-system", "kube-public", "kube-node-lease", "default", "local-path-storage"]:
                            continue
                            
                        try:
                            uninstall_result = subprocess.run(
                                ["helm", "uninstall", release["name"], "-n", release["namespace"]],
                                capture_output=True,
                                text=True
                            )
                            if uninstall_result.returncode == 0:
                                results["deleted"]["helm_releases"].append(f"{release['name']} in {release['namespace']}")
                        except Exception as e:
                            self.console.print(f"[yellow]Warning: Could not uninstall {release['name']}: {e}[/yellow]")
                progress.update(task, completed=True)
            except Exception as e:
                self.console.print(f"[yellow]Warning: Could not list Helm releases: {e}[/yellow]")
            
            # Delete ArgoCD applications first
            task = progress.add_task("Deleting ArgoCD applications...", total=None)
            try:
                result = subprocess.run(
                    ["kubectl", "delete", "applications", "--all", "-n", "argocd", "--ignore-not-found=true"],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0 and result.stdout:
                    # Parse deleted applications
                    for line in result.stdout.strip().split('\n'):
                        if 'deleted' in line:
                            app_name = line.split('"')[1] if '"' in line else line.split()[0]
                            results["deleted"]["applications"].append(app_name)
                progress.update(task, completed=True)
            except Exception as e:
                self.console.print(f"[yellow]Warning: Could not delete applications: {e}[/yellow]")
            
            # Delete namespaces dynamically based on labels
            task = progress.add_task("Deleting namespaces...", total=None)
            
            # Get namespaces with CSO labels or created by CSO
            cso_namespace_labels = os.getenv("CSO_NAMESPACE_LABELS", "app.kubernetes.io/part-of=cloudstack-orchestrator,managed-by=cso").split(",")
            
            namespaces_to_delete = set()
            
            # Get namespaces by labels
            for label in cso_namespace_labels:
                try:
                    result = subprocess.run(
                        ["kubectl", "get", "namespaces", "-l", label, "-o", "name"],
                        capture_output=True,
                        text=True
                    )
                    if result.returncode == 0 and result.stdout:
                        for ns in result.stdout.strip().split('\n'):
                            if ns:
                                namespaces_to_delete.add(ns.replace("namespace/", ""))
                except Exception as e:
                    self.console.print(f"[yellow]Warning: Could not get namespaces with label {label}: {e}[/yellow]")
            
            # Also include known CSO namespaces from environment or defaults
            default_namespaces = os.getenv("CSO_NAMESPACES", "argocd,istio-system,istio-ingress,keycloak,auth,cert-manager,monitoring,platform").split(",")
            namespaces_to_delete.update(default_namespaces)
            
            # Get all module namespaces (they typically have module label)
            try:
                result = subprocess.run(
                    ["kubectl", "get", "namespaces", "-l", "module", "-o", "name"],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0 and result.stdout:
                    for ns in result.stdout.strip().split('\n'):
                        if ns:
                            namespaces_to_delete.add(ns.replace("namespace/", ""))
            except Exception as e:
                self.console.print(f"[yellow]Warning: Could not get module namespaces: {e}[/yellow]")
            
            # Start all namespace deletions in parallel
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                def delete_namespace(ns):
                    try:
                        result = subprocess.run(
                            ["kubectl", "delete", "namespace", ns, "--ignore-not-found=true"],
                            capture_output=True,
                            text=True
                        )
                        if result.returncode == 0 and 'deleted' in result.stdout:
                            return ns, True
                        return ns, False
                    except Exception as e:
                        self.console.print(f"[yellow]Warning: Could not delete namespace {ns}: {e}[/yellow]")
                        return ns, False
                
                # Submit all deletions
                futures = {executor.submit(delete_namespace, ns): ns for ns in namespaces_to_delete}
                
                # Collect results as they complete
                for future in concurrent.futures.as_completed(futures):
                    ns, success = future.result()
                    if success:
                        results["deleted"]["namespaces"].append(ns)
            
            progress.update(task, completed=True)
            
            # Delete CRDs in parallel
            task = progress.add_task("Deleting Custom Resource Definitions...", total=None)
            crd_labels = [
                "app.kubernetes.io/part-of=argocd",
                "app=istio",
                "app.kubernetes.io/name=cert-manager"
            ]
            
            # Delete CRDs in parallel
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
                def delete_crds_by_label(label):
                    try:
                        result = subprocess.run(
                            ["kubectl", "delete", "crd", "-l", label, "--ignore-not-found=true"],
                            capture_output=True,
                            text=True
                        )
                        deleted_crds = []
                        if result.returncode == 0 and result.stdout:
                            # Parse deleted CRDs
                            for line in result.stdout.strip().split('\n'):
                                if 'deleted' in line:
                                    crd_name = line.split('"')[1] if '"' in line else line.split()[0]
                                    deleted_crds.append(crd_name)
                        return deleted_crds
                    except Exception as e:
                        self.console.print(f"[yellow]Warning: Could not delete CRDs with label {label}: {e}[/yellow]")
                        return []
                
                # Submit all CRD deletions
                futures = [executor.submit(delete_crds_by_label, label) for label in crd_labels]
                
                # Collect results
                for future in concurrent.futures.as_completed(futures):
                    deleted_crds = future.result()
                    results["deleted"]["crds"].extend(deleted_crds)
            
            progress.update(task, completed=True)
        
        # Summary
        self.console.print(f"\n[dim]Deleted {len(results['deleted']['helm_releases'])} Helm releases[/dim]")
        self.console.print(f"[dim]Deleted {len(results['deleted']['applications'])} applications[/dim]")
        self.console.print(f"[dim]Deleted {len(results['deleted']['namespaces'])} namespaces[/dim]")
        self.console.print(f"[dim]Deleted {len(results['deleted']['crds'])} CRDs[/dim]")
        
        return results