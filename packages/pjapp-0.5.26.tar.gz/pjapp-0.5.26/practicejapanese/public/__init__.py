# This file makes the public directory a Python package for resource access
