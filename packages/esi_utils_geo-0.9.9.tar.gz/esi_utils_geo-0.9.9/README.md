# esi-utils-geo

 Utility library for dealing with GeoNames cities and compass direction calculations.

## Installation

`pip install esi-utils-geo`