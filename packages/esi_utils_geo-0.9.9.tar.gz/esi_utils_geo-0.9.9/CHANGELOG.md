## v0.9.9 / 2024-11-20
 - Update to use any numpy version

## 0.9.8 / 2024-11-20
 - Unknown

## 0.9.7 / 2024-11-20
 - Allow numpy >= 1.26
 - Replacing use of urlopen with requests to guard against issues with self-signed SSL certificates.
 - Spelling package name correctly in manifest file

## 0.9.6 / 2023-10-20
 - Making sure data is included in package

## 0.9.5 / 2023-09-20
 - Starting to track changes in this log.
 - Adding support for cities file format from simplemaps.json
