# BibleCharacters

A Python package to list and get details about Bible characters.

## Installation

```bash
pip install biblecharacters
