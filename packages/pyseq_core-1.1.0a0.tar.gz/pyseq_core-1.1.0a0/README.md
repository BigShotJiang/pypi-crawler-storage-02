# pyseq_core
Core functions and base classes for pyseq
