# Errors/Exist
- [English](README.md)
- [简体中文](README.zh-CN.md)

**目录**
- [FileExistError, 3001](#fileexisterror)
- [VarExistError, 3002](#varexisterror)


## FileExistError

## VarExistError
