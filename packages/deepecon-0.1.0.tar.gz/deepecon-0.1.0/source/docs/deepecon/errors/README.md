# Errors
**Catalog**
- [NotFoundError](not_found/README.md)
