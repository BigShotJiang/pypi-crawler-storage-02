# -*- coding: utf-8 -*-

"""
    sphinxcontrib
    ~~~~~~~~~~~~~

    This package is a namespace package that contains all extensions
    distributed in the ``sphinx-contrib`` distribution.
"""

__import__('pkg_resources').declare_namespace(__name__)
