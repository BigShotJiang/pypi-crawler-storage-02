class ValidationError(Exception):
    pass


class DatabaseError(Exception):
    pass


class UnknownError(Exception):
    pass
