See `SCAN` for `ZSCAN` documentation.
