This command returns the reference count of the stored at `<key>`.

@return

@integer-reply

The number of references.