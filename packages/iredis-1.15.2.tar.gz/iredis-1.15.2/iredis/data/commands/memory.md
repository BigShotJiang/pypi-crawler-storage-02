This is a container command for memory introspection and management commands.

To see the list of available commands you can call `MEMORY HELP`.
