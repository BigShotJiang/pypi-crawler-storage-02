Returns @integer-reply of number of total commands in this Redis server.

@return

@integer-reply: number of commands returned by `COMMAND`

@examples

```cli
COMMAND COUNT
```
