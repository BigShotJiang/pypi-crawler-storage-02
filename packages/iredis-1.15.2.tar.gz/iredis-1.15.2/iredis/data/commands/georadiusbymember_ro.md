Read-only variant of the `GEORADIUSBYMEMBER` command.

This command is identical to the `GEORADIUSBYMEMBER` command, except that it doesn't support the optional `STORE` and `STOREDIST` parameters.
