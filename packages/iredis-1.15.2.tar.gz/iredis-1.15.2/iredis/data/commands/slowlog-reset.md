This command resets the slow log, clearing all entries in it.

Once deleted the information is lost forever.

@reply

@simple-string-reply: `OK`
