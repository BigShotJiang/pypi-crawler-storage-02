The `DEBUG` command is an internal command.
It is meant to be used for developing and testing Redis.