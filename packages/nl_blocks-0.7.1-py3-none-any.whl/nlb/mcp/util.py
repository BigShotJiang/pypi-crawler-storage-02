import pathlib

# Keep file edits in this sandbox
SANDBOX_DIR = pathlib.Path.home() / '.cache' / 'nlb' / 'mcp'
