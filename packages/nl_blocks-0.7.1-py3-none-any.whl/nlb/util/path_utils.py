import pathlib

REPO_ROOT = pathlib.Path(__file__).parents[2].resolve()
