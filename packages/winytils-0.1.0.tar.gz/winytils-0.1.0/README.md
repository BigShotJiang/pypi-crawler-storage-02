# Python set of utils for Windows OS

My set of custom windows utils that I'm going to use in my projects

## Install

```bash
pip install winytils
```

## Dependencies

win11toast depends on winrt modules


