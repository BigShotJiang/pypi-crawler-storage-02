"""
To execute every module directly - remove relative imports "."
"""

from . import workstation_events
from . import privileges
from . import guiwin
from . import workstation
from . import win11toast
from . import windowshello


__version__ = "0.1.0"
