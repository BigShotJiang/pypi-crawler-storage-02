"""cursor_credits package."""
__version__ = "0.2.0"

def hello() -> str:
    """Return a greeting message."""
    return f"Hello from cursor_credits version {__version__}!"
