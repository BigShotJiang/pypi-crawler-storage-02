##############################################
etree: Tools for accessing the ElementTree API
##############################################

.. currentmodule:: fontTools.misc.etree

Note also that :mod:`etree` supports some :doc:`optional </optional>`
external libraries.


.. automodule:: fontTools.misc.etree
   :members:
   :undoc-members:
