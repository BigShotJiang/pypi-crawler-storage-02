######################################################
fixedTools: Tools for working with fixed-point numbers
######################################################

.. currentmodule:: fontTools.misc.fixedTools

.. automodule:: fontTools.misc.fixedTools
   :members:
   :undoc-members:
