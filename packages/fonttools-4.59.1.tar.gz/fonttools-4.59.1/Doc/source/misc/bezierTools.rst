####################################################
bezierTools: Routines for working with Bezier curves
####################################################

.. currentmodule:: fontTools.misc.bezierTools

.. automodule:: fontTools.misc.bezierTools
   :members:
   :undoc-members:
