###################################################################
filenames: Implementation of UFO's User-Name-to-File-Name algorithm
###################################################################

.. currentmodule:: fontTools.misc.filenames

.. automodule:: fontTools.misc.filenames
   :members: userNameToFileName
   :undoc-members:
