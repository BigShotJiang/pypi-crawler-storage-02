###########################################
encodingTools: Tools for OpenType encodings
###########################################

.. currentmodule:: fontTools.misc.encodingTools

.. automodule:: fontTools.misc.encodingTools
   :members:
   :undoc-members:
