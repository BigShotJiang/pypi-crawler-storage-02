##################################################
sstruct: Tools for working with Python struct data
##################################################

.. currentmodule:: fontTools.misc.sstruct

.. automodule:: fontTools.misc.sstruct
   :members:
   :undoc-members:
