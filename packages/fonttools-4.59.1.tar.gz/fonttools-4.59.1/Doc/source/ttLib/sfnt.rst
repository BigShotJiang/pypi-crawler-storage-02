#########################################
sfnt: Read and write the SFNT file format
#########################################

.. automodule:: fontTools.ttLib.sfnt
   :members:
   :undoc-members:
