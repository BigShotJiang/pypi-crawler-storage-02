##########################################
macUtils: Access fonts in Mac file formats
##########################################

.. automodule:: fontTools.ttLib.macUtils
   :members:
   :undoc-members:
