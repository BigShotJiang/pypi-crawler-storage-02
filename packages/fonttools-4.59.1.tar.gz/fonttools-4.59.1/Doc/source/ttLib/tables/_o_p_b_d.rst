``opbd``: Optical Bounds Table
------------------------------

The ``opbd`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._o_p_b_d
   :members:
   :undoc-members:

