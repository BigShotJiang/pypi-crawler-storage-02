``CBLC``: Color Bitmap Location table
-------------------------------------

The ``CBLC`` table is an OpenType table.

This ``CBLC`` table converter module depends on the
:mod:`.BitmapGlyphMetrics` module, which it shares with the ``EBDT``,
``EBLC``, and ``CBDT`` converters.

.. automodule:: fontTools.ttLib.tables.C_B_L_C_
   :members:
   :undoc-members:

