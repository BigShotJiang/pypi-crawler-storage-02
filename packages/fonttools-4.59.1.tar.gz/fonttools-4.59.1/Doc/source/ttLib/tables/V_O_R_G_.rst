``VORG``: Vertical Origin table
-------------------------------

The ``VORG`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.V_O_R_G_
   :members:
   :undoc-members:

