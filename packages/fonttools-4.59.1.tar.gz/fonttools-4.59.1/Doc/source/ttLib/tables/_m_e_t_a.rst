``meta``: Metadata table
------------------------

The ``meta`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._m_e_t_a
   :members:
   :undoc-members:

