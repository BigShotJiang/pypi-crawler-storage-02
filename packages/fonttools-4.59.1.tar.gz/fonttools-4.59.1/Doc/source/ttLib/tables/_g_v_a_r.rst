``gvar``:  Glyph Variations table
---------------------------------

The ``gvar`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._g_v_a_r
   :members:
   :undoc-members:


TupleVariation
^^^^^^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.TupleVariation
   :members:
   :undoc-members:
