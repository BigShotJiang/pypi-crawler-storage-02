``cmap``: Character to Glyph Index Mapping table
------------------------------------------------

The ``cmap`` table is an OpenType table.

.. autoclass:: fontTools.ttLib.tables._c_m_a_p.table__c_m_a_p

.. autoclass:: fontTools.ttLib.tables._c_m_a_p.CmapSubtable
