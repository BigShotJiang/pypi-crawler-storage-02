``gasp``: Grid-fitting and Scan-conversion Procedure table
----------------------------------------------------------

The ``gasp`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._g_a_s_p
   :members:
   :undoc-members:

