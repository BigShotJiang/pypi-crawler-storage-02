``VDMX``: Vertical Device Metrics table
---------------------------------------

The ``VDMX`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.V_D_M_X_
   :members:
   :undoc-members:
