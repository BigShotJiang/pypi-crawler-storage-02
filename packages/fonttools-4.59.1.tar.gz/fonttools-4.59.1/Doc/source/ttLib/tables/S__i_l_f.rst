``Silf``: Graphite Rules table
------------------------------

The ``Silf`` table is a Graphite table.

.. automodule:: fontTools.ttLib.tables.S__i_l_f
   :members:
   :undoc-members:
