``CPAL``: Color Palette table
-----------------------------

The ``CPAL`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.C_P_A_L_
   :members:
   :undoc-members:

