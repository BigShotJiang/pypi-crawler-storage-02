##############################################################
specializer: T2CharString operator specializer and generalizer
##############################################################

.. rubric:: Overview:
   :heading-level: 3

.. automodule:: fontTools.cffLib.specializer
   :inherited-members:
   :members:
   :undoc-members:


    .. rubric:: Module members:
       :heading-level: 3
    		  
