##############################
CFF2ToCFF: convert CFF2 to CFF
##############################

.. automodule:: fontTools.cffLib.CFF2ToCFF
   :inherited-members:
   :members:
   :undoc-members:


