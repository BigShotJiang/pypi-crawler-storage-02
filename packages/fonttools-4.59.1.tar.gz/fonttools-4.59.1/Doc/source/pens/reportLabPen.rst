############
reportLabPen
############

    Note also that :mod:`reportLabPen` supports some :doc:`optional </optional>`
    external libraries.


.. automodule:: fontTools.pens.reportLabPen
   :members:
   :undoc-members:
