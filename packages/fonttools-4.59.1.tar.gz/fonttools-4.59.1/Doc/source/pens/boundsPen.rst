#########
boundsPen
#########

.. automodule:: fontTools.pens.boundsPen
   :members:
   :undoc-members:
