#####
qtPen
#####

    Note also that :mod:`qtPen` supports some :doc:`optional </optional>`
    external libraries.


.. automodule:: fontTools.pens.qtPen
   :members:
   :undoc-members:
