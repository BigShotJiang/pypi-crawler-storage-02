#####
wxPen
#####

.. automodule:: fontTools.pens.wxPen
   :members:
   :undoc-members:
