##########
svgPathPen
##########

.. automodule:: fontTools.pens.svgPathPen
   :members:
   :undoc-members:
