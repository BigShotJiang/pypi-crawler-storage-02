######
Blocks
######

.. currentmodule:: fontTools.unicodedata.Blocks

.. automodule:: fontTools.unicodedata.Blocks
   :members:
   :undoc-members:

.. data:: fontTools.unicodedata.Blocks.RANGES

.. data:: fontTools.unicodedata.Blocks.VALUES

