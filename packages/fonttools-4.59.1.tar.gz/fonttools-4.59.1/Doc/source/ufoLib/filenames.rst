##########################################################################
filenames: Functions to convert between file names and user-facing strings
##########################################################################

.. automodule:: fontTools.ufoLib.filenames
   :members:
   :undoc-members:
