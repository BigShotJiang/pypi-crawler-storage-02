#########
instancer
#########

.. automodule:: fontTools.varLib.instancer
   :members:
   :undoc-members:
