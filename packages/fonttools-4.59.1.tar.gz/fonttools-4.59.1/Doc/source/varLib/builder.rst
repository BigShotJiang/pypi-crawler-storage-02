#######
builder
#######

.. automodule:: fontTools.varLib.builder
   :members:
   :undoc-members:
