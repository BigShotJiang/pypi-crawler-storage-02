"""The wavetrain tabpfn model module."""
