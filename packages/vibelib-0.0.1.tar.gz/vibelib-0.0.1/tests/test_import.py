def test_can_import():
    import vibelib  # noqa: F401
