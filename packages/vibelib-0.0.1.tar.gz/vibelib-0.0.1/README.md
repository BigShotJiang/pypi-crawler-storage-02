# vibelib

A funny library that routes everyday functions through ChatGPT. For example, `vibesort()` sends an array to ChatGPT and asks it to return a sorted array — because why not.

This is an initial placeholder release to reserve the project name. Functionality will be added in subsequent versions.