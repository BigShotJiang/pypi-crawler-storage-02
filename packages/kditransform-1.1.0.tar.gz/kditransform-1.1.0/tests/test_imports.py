def test_import_packages():
    """Test that importing our package works."""
    import kditransform
    from kditransform import KDITransformer
    from kditransform import KDIDiscretizer
    from kditransform import SimpleKDIDiscretizer
