# lvmcam

![Versions](https://img.shields.io/badge/python->3.8-blue)
[![Lint](https://github.com/sdss/lvmcam/actions/workflows/lint.yml/badge.svg)](https://github.com/sdss/lvmcam/actions/workflows/lint.yml)
[![Documentation Status](https://readthedocs.org/projects/sdss-lvmcam/badge/?version=latest)](https://sdss-lvmcam.readthedocs.io/en/latest/?badge=latest)
<!-- [![codecov](https://codecov.io/gh/sdss/lvmcam/branch/main/graph/badge.svg)](https://codecov.io/gh/sdss/lvmcam) -->

Auto-guider (AG) camera control actor.
