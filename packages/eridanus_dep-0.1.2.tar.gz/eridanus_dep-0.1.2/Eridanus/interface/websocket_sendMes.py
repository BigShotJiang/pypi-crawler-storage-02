#没必要搞这个，都写在wsadapter里面得了
class WebSocketSendMes:
    pass