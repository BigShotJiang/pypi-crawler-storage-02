﻿edaflow.analyze\_categorical\_columns
=====================================

.. currentmodule:: edaflow

.. autofunction:: analyze_categorical_columns