 odlm update --query '{"source_date": {">": "2024-01-01", "<": "2025-06-28"}, "user_id.name": {"ilike": "$pat"}}' --user-id 1 --closer-id 1 --open-user-id 1 --status "in_progress"

