




e=` odlm leads --date-from 2024-01-01 --date-to 2025-05-24 --exact-user "$1" --count 2>e`

echo -e "$1\t$e"
