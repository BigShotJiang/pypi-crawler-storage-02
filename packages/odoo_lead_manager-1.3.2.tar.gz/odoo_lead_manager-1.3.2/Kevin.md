
#Add dropback to kevin,anthony and pat

0-30 days, remove sales

drop dncs > 30 days and has no activity -> back to pat adler


# Add default level to 220 leads per person

# Important: Kevin's remove sales before distribution
Find all opportunities
Merge with leads using partner_id??
any opportunity 
