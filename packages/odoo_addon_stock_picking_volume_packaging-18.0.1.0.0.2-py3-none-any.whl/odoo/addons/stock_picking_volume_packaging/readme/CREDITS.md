The development of this module has been financially supported by:

  - ACSONE SA/NV
  - Alcyon Benelux
  - Camptocamp
