  - Laurent Mignon \<<laurent.mignon@acsone.eu>\> (<http://acsone.eu>)
  - Guewen Baconnier \<<guewen.baconnier@camptocamp.eu>)
    (<http://www.camptocamp.com>)
  - Murtaza Mithaiwala \<<murtaza.m.serpentcs@gmail.com>/>
