This modules makes sense only if you manage the volume information on
your product packaging definitions. If you don't, you can ignore this
module.
