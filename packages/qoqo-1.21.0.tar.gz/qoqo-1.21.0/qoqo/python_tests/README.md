# Python tests

Simple python tests using `pytest` to determine succescull pip install.