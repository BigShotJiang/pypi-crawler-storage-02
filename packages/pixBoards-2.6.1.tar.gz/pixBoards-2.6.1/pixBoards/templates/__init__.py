import os

templates_folder_path = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "templates"
)
