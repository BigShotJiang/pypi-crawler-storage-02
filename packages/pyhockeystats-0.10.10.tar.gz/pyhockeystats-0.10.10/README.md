[![Stand With Ukraine](https://raw.githubusercontent.com/vshymanskyy/StandWithUkraine/main/banner2-direct.svg)](https://stand-with-ukraine.pp.ua)

# Neo-Hockey-Test
Just a test script dealing with hockey games and stats. 

[![Coverage Status](https://coveralls.io/repos/github/GameMaker2k/Neo-Hockey-Test/badge.svg?branch=master)](https://coveralls.io/github/GameMaker2k/Neo-Hockey-Test?branch=master)
