Backtesting Concepts
=====================

Backtesting strategies is an important tool when developing systematic trading strategies.

There are a number of different approaches to backtesting, but the most popular is the
concept of walk forward testing :cite:`joubert2024enhanced`.

