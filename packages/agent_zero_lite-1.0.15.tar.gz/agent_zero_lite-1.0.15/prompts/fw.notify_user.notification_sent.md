The notification has been sent to the user.
