set -ex

rm -rf examples/spider/checkpoints
rm -rf examples/calc_x/checkpoints
rm -rf verl
