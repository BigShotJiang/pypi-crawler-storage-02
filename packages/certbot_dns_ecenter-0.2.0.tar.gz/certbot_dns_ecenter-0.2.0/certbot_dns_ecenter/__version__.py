"""Version module."""
VERSION = '0.2.0'
