.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Contents:

   CHANGELOG
   reference/pyprocessors_standoff2inline
