# python-Sigilyph
The TTS Text Frontend for the use of own
