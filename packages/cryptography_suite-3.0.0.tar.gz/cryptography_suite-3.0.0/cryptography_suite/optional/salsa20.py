from __future__ import annotations

DEPRECATED_MSG = (
    "This function is deprecated and will be removed in v4.0.0. For reference/education only. DO NOT USE IN PRODUCTION."
)

raise RuntimeError(DEPRECATED_MSG)
