A simple HTML document with a title and one each of h1 and h2 headings.

Note: The title does not get rendered into the markdown but should be available as metadata on the document.