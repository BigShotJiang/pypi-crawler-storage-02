A simple HTML document with a title and a heading.

Note: The title does not get rendered into the markdown but should be available as metadata on the document.