 : 0 - 10648: # How to contribute elastic-crawler  The `elastic-
   : 1 - 625: # How to contribute elastic-crawler  The `elastic-
   : 2 - 1029: - Reporting issues - Getting help Types of contrib
   : 3 - 437: ## Types of contribution  ### Enhancements  Enhanc
   : 4 - 2646: ## Contribution Checklist  ### Acceptance criteria
     : 5 - 407: ## Contribution Checklist  ### Acceptance criteria
     : 6 - 546: ### Correct code/file organization  Any contributi
       : 7 - 546: ### Correct code/file organization  Any contributi
     : 8 - 753: ### Log verbosity  Logging is important to get ins
       : 9 - 753: ### Log verbosity  Logging is important to get ins
     : 10 - 407: ### Linting  Code style is important in shared cod
       : 11 - 407: ### Linting  Code style is important in shared cod
     : 12 - 525: ### Testing  Tests not only verify and demonstrate
       : 13 - 525: ### Testing  Tests not only verify and demonstrate
   : 14 - 3451: ## Pull Request Etiquette  *this is copied and ada
     : 15 - 113: ## Pull Request Etiquette  *this is copied and ada
     : 16 - 721: ### Why do we use a Pull Request workflow?  PRs ar
       : 17 - 721: ### Why do we use a Pull Request workflow?  PRs ar
     : 18 - 2613: ### What constitutes a good PR?  A good quality PR
       : 19 - 805: ### What constitutes a good PR?  A good quality PR
       : 20 - 712: #### Ensure there is a solid title and summary  PR
         : 21 - 712: #### Ensure there is a solid title and summary  PR
       : 22 - 292: #### Be explicit about the PR status  If your PR i
         : 23 - 292: #### Be explicit about the PR status  If your PR i
       : 24 - 244: #### Keep your branch up-to-date  Unless there is 
       : 25 - 552: #### Keep it small  Try to only fix one issue or a
         : 26 - 552: #### Keep it small  Try to only fix one issue or a
   : 27 - 2450: ## Reviewing Pull Requests  It's a reviewers respo
     : 28 - 273: ## Reviewing Pull Requests  It's a reviewers respo
     : 29 - 815: ### Keep the flow going  Pull Requests are the fun
       : 30 - 815: ### Keep the flow going  Pull Requests are the fun
     : 31 - 753: ### We are all reviewers  To make sure PRs flow th
       : 32 - 753: ### We are all reviewers  To make sure PRs flow th
     : 33 - 603: ### Don't add to the PR as a reviewer  It's someti
       : 34 - 603: ### Don't add to the PR as a reviewer  It's someti