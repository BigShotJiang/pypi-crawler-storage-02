 : 0 - 7847: # Firestore Demo¶  This guide shows you how to dir
   : 1 - 953: # Firestore Demo  This guide shows you how to dire
   : 2 - 720: ``` import logging import sys  logging.basicConfig
   : 3 - 375: from llama_index.core import SimpleDirectoryReader
   : 4 - 5792: #### Download Data¶  In [ ]:  ``` !mkdir -p 'data/