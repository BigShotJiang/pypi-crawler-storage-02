 : 0 - 920: # PyCharm  While pydantic will work well with any 
   : 1 - 9: # PyCharm
   : 2 - 311: While pydantic will work well with any IDE out of 
   : 3 - 53: The plugin currently supports the following featur
   : 4 - 394: - For pydantic.BaseModel.__init__ : For pydantic.B
   : 5 - 80: More information can be found on the official plug
   : 6 - 25: Thanks for your feedback!
   : 7 - 25: Thanks for your feedback!
   : 8 - 9: Made with