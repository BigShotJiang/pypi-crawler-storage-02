 : 0 - 1713: # Queues  Pydantic is quite helpful for validating
   : 1 - 8: # Queues
   : 2 - 167: Pydantic is quite helpful for validating data that
   : 3 - 1534: ## Redis queue¶  Redis is a popular in-memory data
     : 4 - 14: ## Redis queue
     : 5 - 50: Redis is a popular in-memory data structure store.
     : 6 - 106: In order to run this example locally, you'll first
     : 7 - 159: Here's a simple example of how you can use Pydanti
     : 8 - 1131: ``` import redis  from pydantic import BaseModel, 
     : 9 - 25: Thanks for your feedback!
     : 10 - 25: Thanks for your feedback!
     : 11 - 9: Made with