 : 0 - 5664: # Metrics  A measurement captured at runtime.  A m
   : 1 - 9: # Metrics
   : 2 - 34: A measurement captured at runtime.
   : 3 - 245: A metric is a measurement of a service captured at
   : 4 - 336: Application and request metrics are important indi
   : 5 - 133: To understand how metrics in OpenTelemetry works, 
   : 6 - 431: ## Meter Provider  A Meter Provider (sometimes cal
   : 7 - 137: ## Meter  A Meter creates metric instruments, capt
   : 8 - 221: ## Metric Exporter  Metric Exporters send metric d
   : 9 - 1740: ## Metric Instruments  In OpenTelemetry measuremen
     : 10 - 21: ## Metric Instruments
     : 11 - 100: In OpenTelemetry measurements are captured by metr
     : 12 - 56: - Name - Kind - Unit (optional) - Description (opt
     : 13 - 145: The name, unit, and description are chosen by the 
     : 14 - 44: The instrument kind is one of the following:
     : 15 - 1230: - Counter: A value that accumulates over time – yo
     : 16 - 132: For more on synchronous and asynchronous instrumen
   : 17 - 1234: ## Aggregation  In addition to the metric instrume
     : 18 - 14: ## Aggregation
     : 19 - 572: In addition to the metric instruments, the concept
     : 20 - 248: Unlike request tracing, which is intended to captu
     : 21 - 394: - Reporting the total number of bytes read by a se
   : 22 - 261: ## Views  A view provides SDK users with the flexi
   : 23 - 606: ## Language Support  Metrics are a stable signal i
     : 24 - 19: ## Language Support
     : 25 - 168: Metrics are a stable signal in the OpenTelemetry s
     : 26 - 415: | Language      | Metrics     | |---------------|-
   : 27 - 94: ## Specification  To learn more about metrics in O
   : 28 - 157: ## Feedback  Was this page helpful?  Thank you. Yo