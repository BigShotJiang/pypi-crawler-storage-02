 : 0 - 26433: # ES|QL aggregation functions  The STATS command s
   : 1 - 288: # ES|QL aggregation functions  The STATS command s
   : 2 - 788: ## AVG  Syntax  Parameters  - number     - Express
     : 3 - 788: ## AVG  Syntax  Parameters  - number     - Express
   : 4 - 2347: ## COUNT  Syntax  Parameters  - field     - Expres
     : 5 - 932: ## COUNT  Syntax  Parameters  - field     - Expres
     : 6 - 837: |   count:long | languages:integer   | |----------
     : 7 - 574: To count the same stream of data based on two diff
   : 8 - 5110: ## COUNT_DISTINCT  Syntax  Parameters  - field    
     : 9 - 427: ## COUNT_DISTINCT  Syntax  Parameters  - field    
     : 10 - 1763: | field      | precision     | result   | |-------
     : 11 - 971: Examples  ``` FROM hosts | STATS COUNT_DISTINCT(ip
     : 12 - 1943: ### Counts are approximate  Computing exact counts
       : 13 - 916: ### Counts are approximate  Computing exact counts
       : 14 - 1025: For all 3 thresholds, counts have been accurate up
   : 15 - 986: ## MAX  Syntax  Parameters  - field  Description  
     : 16 - 986: ## MAX  Syntax  Parameters  - field  Description  
   : 17 - 1222: ## MEDIAN  Syntax  Parameters  - number     - Expr
     : 18 - 1001: ## MEDIAN  Syntax  Parameters  - number     - Expr
     : 19 - 219: |   median_max_salary_change:double | |-----------
   : 20 - 1649: ## MEDIAN_ABSOLUTE_DEVIATION  Syntax  Parameters  
     : 21 - 1046: ## MEDIAN_ABSOLUTE_DEVIATION  Syntax  Parameters  
     : 22 - 601: The expression can use inline functions. For examp
   : 23 - 986: ## MIN  Syntax  Parameters  - field  Description  
     : 24 - 986: ## MIN  Syntax  Parameters  - field  Description  
   : 25 - 3314: ## PERCENTILE  Syntax  Parameters  - number - perc
     : 26 - 998: ## PERCENTILE  Syntax  Parameters  - number - perc
     : 27 - 425: The expression can use inline functions. For examp
     : 28 - 1887: ### PERCENTILE is (usually) approximate  There are
       : 29 - 742: ### PERCENTILE is (usually) approximate  There are
       : 30 - 711: - Accuracy is proportional to q(1-q). This means t
       : 31 - 430: It shows how precision is better for extreme perce
   : 32 - 611: ## ST_CENTROID_AGG  Elastic Stack				 Technical Pr
     : 33 - 611: ## ST_CENTROID_AGG  Elastic Stack				 Technical Pr
   : 34 - 842: ## ST_EXTENT_AGG  Elastic Stack				 Technical Prev
     : 35 - 842: ## ST_EXTENT_AGG  Elastic Stack				 Technical Prev
   : 36 - 791: ## STD_DEV  Syntax  Parameters  - number  Descript
     : 37 - 791: ## STD_DEV  Syntax  Parameters  - number  Descript
   : 38 - 724: ## SUM  Syntax  Parameters  - number  Description 
     : 39 - 724: ## SUM  Syntax  Parameters  - number  Description 
   : 40 - 991: ## TOP  Syntax  Parameters  - field     - The fiel
     : 41 - 991: ## TOP  Syntax  Parameters  - field     - The fiel
   : 42 - 4701: ## VALUES  Elastic Stack				 Technical Preview    
     : 43 - 1070: ## VALUES  Elastic Stack				 Technical Preview    
     : 44 - 3301: | first_name:keyword                              
     : 45 - 326: Use TOP if you need to keep repeated values.  This
   : 46 - 1053: ## WEIGHTED_AVG  Syntax  Parameters  - number     
     : 47 - 1053: ## WEIGHTED_AVG  Syntax  Parameters  - number     