# A document with an h1 heading

Some text under the first h1 heading

## A document with an h2 heading

Some text under the first h2 heading