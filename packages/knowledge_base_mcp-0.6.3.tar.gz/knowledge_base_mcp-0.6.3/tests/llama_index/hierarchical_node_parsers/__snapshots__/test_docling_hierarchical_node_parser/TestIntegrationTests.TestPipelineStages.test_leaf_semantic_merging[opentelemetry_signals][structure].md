 : 0 - 5664: # Metrics  A measurement captured at runtime.  A m
   : 1 - 765: # Metrics  A measurement captured at runtime.  A m
   : 2 - 793: ## Meter Provider  A Meter Provider (sometimes cal
   : 3 - 1740: ## Metric Instruments  In OpenTelemetry measuremen
     : 4 - 374: ## Metric Instruments  In OpenTelemetry measuremen
     : 5 - 1230: - Counter: A value that accumulates over time – yo
     : 6 - 132: For more on synchronous and asynchronous instrumen
   : 7 - 1234: ## Aggregation  In addition to the metric instrume
     : 8 - 838: ## Aggregation  In addition to the metric instrume
     : 9 - 394: - Reporting the total number of bytes read by a se
   : 10 - 516: ## Views  A view provides SDK users with the flexi
   : 11 - 606: ## Language Support  Metrics are a stable signal i
     : 12 - 606: ## Language Support  Metrics are a stable signal i