# sage_setup: distribution = sagemath-repl

from .display_manager import get_display_manager
from .pretty_print import pretty_print
