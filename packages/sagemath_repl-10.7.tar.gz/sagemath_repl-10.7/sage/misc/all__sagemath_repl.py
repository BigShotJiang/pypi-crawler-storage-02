# sage_setup: distribution = sagemath-repl
from sage.misc.sage_eval import sage_eval, sageobj

from sage.misc.sage_input import sage_input
