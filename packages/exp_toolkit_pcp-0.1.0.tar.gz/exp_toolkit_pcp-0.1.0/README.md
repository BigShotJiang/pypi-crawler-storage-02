# exp_tool

A Python package for experimental data processing and reporting, including:
- Error propagation with significant figure handling
- LaTeX-ready result formatting

## Installation

```bash
pip install exp_tool
