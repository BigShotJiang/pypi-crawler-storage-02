"""A pytest plugin for managing libiio contexts."""

__version__ = "0.0.22"
