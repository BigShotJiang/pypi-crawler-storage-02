# chatbot_ai/apps.py
from django.apps import AppConfig

class ChatbotAIConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatbot_ai'