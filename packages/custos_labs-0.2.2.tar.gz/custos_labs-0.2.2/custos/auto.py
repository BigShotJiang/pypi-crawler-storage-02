# custos/auto.py


"""
No-op auto-instrumentation.
Intentionally left blank to avoid hooking external model SDKs.
"""
def auto_instrument(*args, **kwargs):
    return
