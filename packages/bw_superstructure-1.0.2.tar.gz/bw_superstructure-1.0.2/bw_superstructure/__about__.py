# SPDX-FileCopyrightText: 2023-present DLR <Carina.Harpprecht@dlr.de>
#
# SPDX-License-Identifier: LGPL-3.0
__version__ = "1.0.2"
