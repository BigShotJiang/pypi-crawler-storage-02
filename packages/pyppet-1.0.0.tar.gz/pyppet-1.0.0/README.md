# pyppet
pyppet is a robot model format that uses Python instead of XML for better type checking, logic, scripting, and parsing.
