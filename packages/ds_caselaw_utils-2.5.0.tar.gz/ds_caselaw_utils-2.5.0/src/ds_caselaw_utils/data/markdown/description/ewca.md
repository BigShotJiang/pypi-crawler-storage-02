The Court of Appeal is the second most senior court for cases in England and Wales. It is second only to the UK Supreme Court. It is split into two Divisions: Civil and Criminal.
