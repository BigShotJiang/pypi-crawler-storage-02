This court is part of the High Court. It assesses costs of civil litigation from various courts and tribunals including Court of Appeal, the High Court Chancery, Family and King’s Bench divisions, Court of Protection, and the County Court in London. It also handles disputes relating to solicitors’ charges.

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about [the Senior Courts Costs Office on the Judiciary website](https://www.judiciary.uk/courts-and-tribunals/high-court/the-senior-courts-costs-office/){target="\_blank"}.
