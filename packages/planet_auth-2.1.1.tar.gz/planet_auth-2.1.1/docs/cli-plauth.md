# CLI Reference

{% raw %}
::: mkdocs-click
    :module: planet_auth_utils.commands.cli.main
    :command: cmd_plauth
    :prog_name: plauth
    :depth: 1
{% endraw %}
