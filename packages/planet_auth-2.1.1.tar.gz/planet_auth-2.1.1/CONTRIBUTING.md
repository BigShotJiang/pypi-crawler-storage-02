This project is currently run as a child project of the
[Planet SDK for Python](https://developers.planet.com/docs/pythonclient/)
([on github](https://github.com/planetlabs/planet-client-python)).
Please refer to that project for submitting issues and general discussion.
