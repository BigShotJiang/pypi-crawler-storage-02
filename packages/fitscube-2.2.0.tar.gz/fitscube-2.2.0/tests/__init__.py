"""Tests for fitscube."""
