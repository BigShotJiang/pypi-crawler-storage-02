##
# File to mark this a python package
#
# Copyright (c) Microsoft Corporation
#
# SPDX-License-Identifier: BSD-2-Clause-Patent
##
"""This package contains different EDK2 file generators for capsules."""
