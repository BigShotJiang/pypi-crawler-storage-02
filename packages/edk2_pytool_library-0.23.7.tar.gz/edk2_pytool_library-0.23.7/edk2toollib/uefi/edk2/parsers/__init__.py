##
# File to mark this a python package
#
# Copyright (c) Microsoft Corporation
#
# SPDX-License-Identifier: BSD-2-Clause-Patent
##
"""This package contains parsers for variable EDK2 files and objects."""
