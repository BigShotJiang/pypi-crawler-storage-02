"""NMDC MCP package for querying NMDC API."""
