#! /usr/bin/env bash

function code() {
    /Applications/Visual\ Studio\ Code.app/Contents/Resources/app/bin/code "$@"
}
