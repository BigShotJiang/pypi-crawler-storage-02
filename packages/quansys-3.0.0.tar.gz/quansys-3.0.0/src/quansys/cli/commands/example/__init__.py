# Expose the command function for import by main.py
from .cmd import example

__all__ = ["example"]