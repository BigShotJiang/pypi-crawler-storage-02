# Expose the command function for import by main.py
from .cmd import submit

__all__ = ["submit"]