# Expose the command function for import by main.py
from .cmd import run

__all__ = ["run"]