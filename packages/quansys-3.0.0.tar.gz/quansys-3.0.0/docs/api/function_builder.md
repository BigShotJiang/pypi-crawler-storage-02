# FunctionBuilder

Call a user-defined Python function to build or modify the HFSS model.

This builder is highly flexible and useful for dynamic setups.

::: quansys.workflow.builder.function_builder.FunctionBuilder