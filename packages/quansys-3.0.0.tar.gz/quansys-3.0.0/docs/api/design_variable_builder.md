# DesignVariableBuilder

Set project-level design variables in an HFSS simulation model.

This builder applies design parameters to the active project before analysis,
enabling full parametric sweeps.

::: quansys.workflow.builder.design_variable_builder.DesignVariableBuilder