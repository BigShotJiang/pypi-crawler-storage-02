# execute_workflow

The main automation function that utilized a [WorkflowConfig](workflow_config.md)
to run a sequence of phases based on its parameters. 

::: quansys.workflow.execute_workflow