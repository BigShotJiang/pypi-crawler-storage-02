# Junction Configuration

This object defines the metadata required to simulate a Josephson junction 
in an HFSS-based quantum simulation.

::: quansys.simulation.quantum_epr.structures.ConfigJunction