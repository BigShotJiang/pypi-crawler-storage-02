# PyaedtFileParameters

Launch and manage an AEDT (HFSS) session based on file and license settings.

This model is used during every stage of the workflow where HFSS access is required.
It provides a context-managed interface to automatically open and clean up HFSS projects.

::: quansys.workflow.session_handler.config.PyaedtFileParameters