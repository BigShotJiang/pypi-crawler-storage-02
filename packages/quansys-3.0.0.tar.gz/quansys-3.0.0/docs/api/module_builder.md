# ModuleBuilder

Import and run a Python module as a builder.

Use this to integrate reusable external scripts that define the model logic.
Helpful for sharing build logic across multiple projects.

::: quansys.workflow.builder.module_builder.ModuleBuilder