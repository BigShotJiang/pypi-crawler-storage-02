# PrepareFolderConfig

Configuration options for the folder preparation phase of a simulation run.

This model defines whether to copy the source AEDT file and what to name it in each simulation folder.

::: quansys.workflow.prepare.PrepareFolderConfig