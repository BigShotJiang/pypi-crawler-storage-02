from setuptools import setup

# Minimal setup.py for compatibility
# All configuration is in pyproject.toml
setup()