def main():
    print("Hello from codex-as-mcp!")


if __name__ == "__main__":
    main()
