from ._results import read_sesam_results

__all__ = ["read_sesam_results"]
