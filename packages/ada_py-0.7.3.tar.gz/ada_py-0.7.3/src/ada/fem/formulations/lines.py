class BeamTheory:
    TIMOSHENKO = "timoshenko"
    EULER_BERNOULLI = "euler_bernoulli"
