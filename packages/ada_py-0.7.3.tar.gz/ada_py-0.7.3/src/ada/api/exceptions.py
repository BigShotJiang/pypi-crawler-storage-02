class NoGeomPassedToShapeError(Exception):
    pass


class NameIsNoneError(Exception):
    pass


class DuplicateNodes(Exception):
    pass
