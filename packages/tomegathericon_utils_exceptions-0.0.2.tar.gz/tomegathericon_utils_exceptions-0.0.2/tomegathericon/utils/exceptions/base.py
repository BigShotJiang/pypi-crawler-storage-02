class DefaultValueError(ValueError):
    pass
class DefaultRuntimeError(RuntimeError):
    pass
class DefaultKeyError(KeyError):
    pass
