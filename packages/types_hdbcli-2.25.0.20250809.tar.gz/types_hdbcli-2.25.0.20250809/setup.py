
from setuptools import setup

setup(package_data={'hdbcli-stubs': ['__init__.pyi', 'dbapi.pyi', 'resultrow.pyi', 'METADATA.toml', 'py.typed']})
