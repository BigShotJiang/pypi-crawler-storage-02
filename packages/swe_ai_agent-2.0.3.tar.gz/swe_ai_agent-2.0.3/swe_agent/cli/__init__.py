"""
CLI module for the SWE Agent system.
"""

from .interface import SWEInterface

__all__ = ["SWEInterface"]
