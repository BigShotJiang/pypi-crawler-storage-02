# rust_packer
serializer and deserializer for tensors in Rust
