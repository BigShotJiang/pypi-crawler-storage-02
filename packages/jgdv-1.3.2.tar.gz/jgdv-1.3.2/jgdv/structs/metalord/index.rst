.. -*- mode: ReST -*-

.. _label:

========
Metalord
========

.. contents:: Contents
   :local:


This serves as a utility to simplify metaclass creation.
