"""
A module for errors beyond the stdlib errors.

"""
