"""

"""

from .colour import ColourFormatter, StripColourFormatter
