"""
jgdv._abstract is where I put protocols and things that aren't meant to be used,
but implemented.

"""
