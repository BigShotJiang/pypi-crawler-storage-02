from typing import NewType

ChunkKey = NewType("ChunkKey", str)  # a string of the form '1.0.1' etc.
