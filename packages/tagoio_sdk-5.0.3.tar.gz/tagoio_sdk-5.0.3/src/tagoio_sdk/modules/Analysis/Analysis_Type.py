AnalysisEnvironment = dict[str, str]
