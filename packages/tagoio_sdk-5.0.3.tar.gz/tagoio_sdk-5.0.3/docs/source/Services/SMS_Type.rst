**SMS Type**
===================


.. _SMSData:

SMSData
-------

    **Attributes:**

        | **to**: str
        | Number to send SMS, Example: +5599999999999

        | **message**: str
        | Message to be send

