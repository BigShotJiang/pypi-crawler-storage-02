**Integration Network**
=======================

Manage integration network in the account

============
listNetwork
============
Get list of networks

    **Parameters:**

        | **queryObj**: :ref:`Query`
        | Network Query


======
info
======

Gets information about the network

    **Parameters:**

        | **networkID**: GenericID: str
        | Network identification

.. toctree::

    IntegrationNetwork_Type
