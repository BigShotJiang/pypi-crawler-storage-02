# Authors

Contributors to pyprocessors_standoff2inline include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
