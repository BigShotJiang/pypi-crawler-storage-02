"""
Módulo Azure OpenAI para extração de dados
"""

from .AzureOpenAIService import AzureOpenAIService

__all__ = ['AzureOpenAIService'] 