"""Errors."""


class VerificationError(Exception):
    """Verification errors are raised when the verification of a Timestamp fails."""

    pass
