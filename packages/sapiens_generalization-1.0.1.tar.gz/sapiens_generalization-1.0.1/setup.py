# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_generalization'
version = '1.0.1'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    url='https://github.com/sapiens-technology/SapiensGeneralization',
    license='Proprietary Software'
)
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
