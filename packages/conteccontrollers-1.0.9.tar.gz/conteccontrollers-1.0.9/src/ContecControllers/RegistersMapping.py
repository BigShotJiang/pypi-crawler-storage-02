class RegistersMapping:
    ActivationsState = 26
    FirstBlindsOpeningRequest = 70
