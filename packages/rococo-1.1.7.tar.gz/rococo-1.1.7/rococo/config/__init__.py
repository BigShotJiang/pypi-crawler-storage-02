"""
Config class that allows to load from a .toml file, and/or use a .env file.
"""
from .config import BaseConfig
