"""This module contains the labels."""

WAKE = 0
LIGHT = 1
DEEP = 2
REM = 3

NO_EVENT = 0
APNEA = 1
HYPOPNEA = 2

NO_EVENT = 0
SNORE = 1
