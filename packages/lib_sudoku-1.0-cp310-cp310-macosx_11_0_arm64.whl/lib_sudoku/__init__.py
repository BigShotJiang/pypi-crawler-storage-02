from .lib_sudoku import *

__doc__ = lib_sudoku.__doc__
if hasattr(lib_sudoku, "__all__"):
    __all__ = lib_sudoku.__all__