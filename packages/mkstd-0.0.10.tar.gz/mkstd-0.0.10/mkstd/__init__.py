"""mkstd: the standard maker."""
__version__ = "0.0.10"


from .standards import *
from .types import *
