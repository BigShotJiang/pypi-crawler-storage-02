"""Support for additional data types."""
from .array import get_array_type
from .path import Path
