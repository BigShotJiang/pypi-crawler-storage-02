


def welcome(name):
    print(f'Hi, {name}! Good Morning!')