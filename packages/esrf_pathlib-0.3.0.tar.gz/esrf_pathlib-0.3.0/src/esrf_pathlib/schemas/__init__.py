from ._utils import detect_schema  # noqa F401
