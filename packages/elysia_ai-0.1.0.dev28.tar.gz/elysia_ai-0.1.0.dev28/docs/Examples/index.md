
1. [Basic Linear Regression](data_analysis.md) - creating a custom Elysia tool to perform a basic least squares regression on items retrieved from the `query` tool.

More examples coming soon!