#ifndef LOOKUP_H
#define LOOKUP_H

#include <string.h>

struct _LOOKUP {
    const char *name;
    int value;
};

#endif // LOOKUP_H
