
[Read the Docs](https://talbotknighton.github.io/trendify/)

[View on PyPi](https://pypi.org/project/trendify/)

[View on GitHub](https://github.com/TalbotKnighton/trendify)