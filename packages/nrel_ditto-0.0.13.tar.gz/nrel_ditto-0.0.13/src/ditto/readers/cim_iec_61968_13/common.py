from gdm.distribution.enums import Phase

phase_mapper = {"A": Phase.A, "B": Phase.B, "C": Phase.C}
