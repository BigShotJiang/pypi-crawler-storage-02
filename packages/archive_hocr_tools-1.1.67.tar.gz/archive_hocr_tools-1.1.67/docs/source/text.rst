.. _text:

Reading text from hOCR
======================


.. automodule:: hocr.text
    :members:

