# Internal implementation modules - not part of public API
