from kioto.sync import impl

# Re-export the Mutex class from the implementation
Mutex = impl.Mutex
