from pkg.executable import engine

if __name__ == "__main__":
    engine.main()
