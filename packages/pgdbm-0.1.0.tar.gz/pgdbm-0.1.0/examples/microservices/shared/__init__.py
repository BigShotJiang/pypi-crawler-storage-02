# Shared components for microservices
