# Copyright (c) 2025 Juan Reyero
# Licensed under the MIT License

"""Version information for pgdbm."""

__version__ = "0.1.0"
__author__ = "Juan Reyero"
__author_email__ = "juan@juanreyero.com"
__license__ = "MIT"
