import sys

import pymatching


def cli_argv():
    pymatching.cli(command_line_args=sys.argv[1:])
