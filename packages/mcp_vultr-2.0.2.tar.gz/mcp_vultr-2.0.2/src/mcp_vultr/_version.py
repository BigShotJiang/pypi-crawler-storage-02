"""Version information for mcp-vultr package."""

__version__ = "2.0.0"
__version_info__ = tuple(int(i) for i in __version__.split(".") if i.isdigit())
