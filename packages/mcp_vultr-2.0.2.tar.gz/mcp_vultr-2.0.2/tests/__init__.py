"""Tests for mcp_vultr package."""
