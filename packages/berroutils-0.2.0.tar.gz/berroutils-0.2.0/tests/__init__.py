from pathlib import Path

TEST_ROOT = Path(__file__).parent

TEST_DATA = TEST_ROOT / 'data'
