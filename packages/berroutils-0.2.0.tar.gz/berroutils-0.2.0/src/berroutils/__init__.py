from pathlib import Path

SRC_ROOT = Path(__file__).parent

