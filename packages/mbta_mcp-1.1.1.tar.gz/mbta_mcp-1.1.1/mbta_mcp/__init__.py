"""MBTA MCP Server - MCP server for MBTA V3 API."""

__version__ = "0.1.0"
