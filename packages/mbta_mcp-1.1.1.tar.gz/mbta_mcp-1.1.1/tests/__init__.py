"""Tests package for MBTA MCP."""
