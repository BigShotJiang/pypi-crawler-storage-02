DnaLib
=======

**DnaLib** is a Python library for fast development of Data Engineering ETL using spark.