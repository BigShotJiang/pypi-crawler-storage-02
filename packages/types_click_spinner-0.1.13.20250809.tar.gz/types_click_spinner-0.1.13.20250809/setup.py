
from setuptools import setup

setup(package_data={'click_spinner-stubs': ['__init__.pyi', '_version.pyi', 'METADATA.toml', 'py.typed']})
