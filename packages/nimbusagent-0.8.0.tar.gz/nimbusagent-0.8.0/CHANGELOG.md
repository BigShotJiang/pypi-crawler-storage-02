# Changelog

## v0.8.0
* Update from Python 3.10 -> 3.12
* Bump dependencies
* Minor typing updates

## v0.7.4

* AgentMemory: Enforce max_tokens, max_messages, add mandatory token_encoding paramater
* Add support for Docker
* Bump dependency package versions
