# Data structure of Airalogy Protocol

本文件夹下的文档详述了Airalogy Protocol相关的数据结构。
