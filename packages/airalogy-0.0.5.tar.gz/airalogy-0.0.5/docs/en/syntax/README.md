# Syntax of the Airalogy Protocol

This folder contains detailed documentation of the syntax rules for Airalogy Protocols.
