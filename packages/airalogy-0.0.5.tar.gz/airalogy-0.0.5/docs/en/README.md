# Airalogy Documentation (EN)

This folder contains the English documentation for the `airalogy` package, which provides a universal framework for standardized data digitization.
