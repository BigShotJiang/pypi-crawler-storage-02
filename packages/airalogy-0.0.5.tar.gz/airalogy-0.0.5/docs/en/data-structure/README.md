# Data Structure of the Airalogy Protocol

The documents in this folder provide a detailed description of the data structures that underpin the Airalogy Protocol.
