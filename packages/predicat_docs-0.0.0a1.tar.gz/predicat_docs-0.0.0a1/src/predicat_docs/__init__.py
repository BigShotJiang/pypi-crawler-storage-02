"""
Placeholder package for predicat-docs.
"""
__all__ = []
__version__ = "0.0.0a1"
