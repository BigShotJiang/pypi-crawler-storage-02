# markitdown-office-extension
A markitdown plugin use to customize markdownif. Supports docx, pptx, xlsx, epub, and html file formats.
