from markitdown.converters._markdownify import _CustomMarkdownify

class MarkdownConverter(_CustomMarkdownify):
    pass