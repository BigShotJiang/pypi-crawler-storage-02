# agentine

Short description of the project.

## Installation

```bash
pip install agentine
```

## Usage

```python
import agentine
```
