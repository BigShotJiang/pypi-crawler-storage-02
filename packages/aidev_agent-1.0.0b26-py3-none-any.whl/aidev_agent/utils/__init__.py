class Empty(object):
    """Empty 对象，用于指示值未初始化或不存在"""
