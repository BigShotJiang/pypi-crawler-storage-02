This module allows to record usages of maintenante equipments by
employees, with their dates, states and comments.
