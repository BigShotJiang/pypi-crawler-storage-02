This directory contains package resources to be installed with the cylc.flow
library. If new files are added, please update `cylc/flow/resources.py`.
