"""
version
"""

__version__ = "25.6.5"
__solver_version__ = "release-25.6"
