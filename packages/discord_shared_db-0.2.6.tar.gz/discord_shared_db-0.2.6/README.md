This is a python package that provides models and database functions for discord bots.


How to update the database 


alembic revision --autogenerate -m "Message"

alembic upgrade head
