from syncloudlib.application.storage import init_storage


def test_import():
    assert True