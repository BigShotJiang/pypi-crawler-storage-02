from syncloudlib.application.urls import get_app_url


def test_import():
    assert True