# fastkafka\services\__init__.py
