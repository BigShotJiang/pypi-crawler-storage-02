# Benchmarks

## Cold installation

<img width="809" height="373" alt="image" src="https://github.com/user-attachments/assets/054ff758-fb53-4beb-8bf8-8ac1a19db527" />

Disk usage after installation:

<img width="490" height="170" alt="image" src="https://github.com/user-attachments/assets/72702412-d7ad-45c8-a337-d36235b8e09e" />
