"""Core functionality for git-mcp."""
