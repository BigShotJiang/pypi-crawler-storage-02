from libpyfoscamcgi.foscamcgi import FoscamCamera

