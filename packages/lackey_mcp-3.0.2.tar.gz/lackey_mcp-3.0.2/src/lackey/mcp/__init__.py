"""MCP server implementation for Lackey task management."""

from .server import LackeyMCPServer

__all__ = ["LackeyMCPServer"]
