"""Operator Event class."""

import dataclasses
import enum

from safari_sdk.protos import operator_event_pb2
from safari_sdk.protos.ui import robotics_ui_pb2


ui_color = robotics_ui_pb2.Color
_UI_COLOR_WHITE = ui_color(red=1.0, green=1.0, blue=1.0, alpha=1.0)
_UI_COLOR_GREEN = ui_color(red=0.0, green=1.0, blue=0.0, alpha=1.0)
_UI_COLOR_RED = ui_color(red=1.0, green=0.0, blue=0.0, alpha=1.0)
_UI_COLOR_PURPLE = ui_color(red=0.8, green=0.0, blue=0.8, alpha=1.0)
_UI_COLOR_YELLOW = ui_color(red=1.0, green=1.0, blue=0.0, alpha=1.0)


# LINT.IfChange
class WorkcellStatus(enum.Enum):
  ERGO_BREAK = 'Ergo Break'
  IN_OPERATION = 'In Operation'
  OTHER_BREAK = 'Other Break'
  TASK_SETUP_CHANGE = 'Start & End of Shift Setup'
  BROKEN_WORKCELL = 'Broken Workcell'
  TROUBLESHOOTING_TESTING = 'Support/Troubleshooting'
  RESERVED_CELL = 'Reserved/Testing'
  EVAL_POLICY_TROUBLESHOOTING = 'Eval/Policy Troubleshooting'
  TASK_FEASIBILITY = 'Task Feasibility'
  AVAILABLE = 'Available'
# LINT.ThenChange(//depot/google3/robotics/orca/backend/api/proto/orca_api.proto)


class UIEvent(enum.Enum):
  LOGIN = 'login'
  LOGOUT = 'logout'
  OTHER_EVENT = 'other event'
  RESET_FEEDBACK = 'reset feedback'


@dataclasses.dataclass
class OperatorEventProperties:
  event_proto_enum: operator_event_pb2.OperatorEventType
  background_color: ui_color
  ui_process_list: list[str]
  logout_status: WorkcellStatus = WorkcellStatus.AVAILABLE

ergo_break = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_BREAK_ERGO,
    background_color=_UI_COLOR_WHITE,
    logout_status=WorkcellStatus.AVAILABLE,
    ui_process_list=[],
)
in_operation = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_IN_OPERATION,
    background_color=_UI_COLOR_GREEN,
    logout_status=WorkcellStatus.AVAILABLE,
    ui_process_list=['episode_timer'],
)
other_break = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_BREAK_OTHER,
    background_color=_UI_COLOR_WHITE,
    logout_status=WorkcellStatus.AVAILABLE,
    ui_process_list=[],
)
task_setup_change = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_PREPARE_SHIFT,
    background_color=_UI_COLOR_WHITE,
    logout_status=WorkcellStatus.AVAILABLE,
    ui_process_list=[],
)
broken_workcell = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_WORKCELL_BROKEN,
    background_color=_UI_COLOR_RED,
    logout_status=WorkcellStatus.BROKEN_WORKCELL,
    ui_process_list=['check_error_recovery'],
)
troubleshooting_testing = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_TROUBLESHOOTING_TESTING,
    background_color=_UI_COLOR_RED,
    logout_status=WorkcellStatus.TROUBLESHOOTING_TESTING,
    ui_process_list=[],
)
reserved_cell = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_RESERVED_CELL,
    background_color=_UI_COLOR_YELLOW,
    logout_status=WorkcellStatus.RESERVED_CELL,
    ui_process_list=[],
)
available = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_LOGOUT,
    background_color=_UI_COLOR_WHITE,
    logout_status=WorkcellStatus.AVAILABLE,
    ui_process_list=[],
)
login = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_LOGIN,
    background_color=_UI_COLOR_WHITE,
    ui_process_list=['start_login_timer'],
)
logout = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_LOGOUT,
    background_color=_UI_COLOR_WHITE,
    ui_process_list=['stop_login_timer'],
)
other_event = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_OTHER,
    background_color=_UI_COLOR_WHITE,
    ui_process_list=[],
)
reset_feedback = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_RESET_FEEDBACK,
    background_color=_UI_COLOR_WHITE,
    ui_process_list=[],
)
eval_policy_troubleshooting = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_EVAL_POLICY_TROUBLESHOOTING,
    background_color=_UI_COLOR_PURPLE,
    ui_process_list=[],
)
task_feasibility = OperatorEventProperties(
    event_proto_enum=operator_event_pb2.OPERATOR_EVENT_TYPE_TASK_FEASIBILITY,
    background_color=_UI_COLOR_GREEN,
    ui_process_list=[],
)

workcell_status_event_dict: dict[str, OperatorEventProperties] = {
    WorkcellStatus.ERGO_BREAK.value: ergo_break,
    WorkcellStatus.IN_OPERATION.value: in_operation,
    WorkcellStatus.OTHER_BREAK.value: other_break,
    WorkcellStatus.TASK_SETUP_CHANGE.value: task_setup_change,
    WorkcellStatus.BROKEN_WORKCELL.value: broken_workcell,
    WorkcellStatus.TROUBLESHOOTING_TESTING.value: troubleshooting_testing,
    WorkcellStatus.RESERVED_CELL.value: reserved_cell,
    WorkcellStatus.AVAILABLE.value: available,
    WorkcellStatus.EVAL_POLICY_TROUBLESHOOTING.value: (
        eval_policy_troubleshooting
    ),
    WorkcellStatus.TASK_FEASIBILITY.value: task_feasibility,
}

workcell_shortcut_dict: dict[str, str] = {
    'e': WorkcellStatus.ERGO_BREAK.value,
    'i': WorkcellStatus.IN_OPERATION.value,
    'o': WorkcellStatus.OTHER_BREAK.value,
    's': WorkcellStatus.TASK_SETUP_CHANGE.value,
    'k': WorkcellStatus.BROKEN_WORKCELL.value,
    't': WorkcellStatus.TROUBLESHOOTING_TESTING.value,
    'r': WorkcellStatus.RESERVED_CELL.value,
    'v': WorkcellStatus.AVAILABLE.value,
    'l': WorkcellStatus.EVAL_POLICY_TROUBLESHOOTING.value,
    'f': WorkcellStatus.TASK_FEASIBILITY.value,
}

ui_event_dict: dict[str, OperatorEventProperties] = {
    UIEvent.LOGIN.value: login,
    UIEvent.LOGOUT.value: logout,
    UIEvent.OTHER_EVENT.value: other_event,
    UIEvent.RESET_FEEDBACK.value: reset_feedback,
}
