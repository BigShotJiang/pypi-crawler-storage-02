# BLE characteristic UUIDs (Nordic UART Service)
_RX_UUID = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"  # Device receives commands
_TX_UUID = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"  # Device transmits notifications