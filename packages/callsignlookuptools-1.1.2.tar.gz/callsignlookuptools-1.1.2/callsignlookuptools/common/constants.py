"""
constants for callsignlookuptools
---
Copyright 2021-2023 classabbyamp, 0x5c
Released under the terms of the BSD 3-Clause license.
"""


from ..__info__ import __project__, __version__


DEFAULT_USERAGENT = f"python-{__project__}-v{__version__}"
