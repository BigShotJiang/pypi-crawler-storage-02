def hello_world(saludo):
    print(saludo)
