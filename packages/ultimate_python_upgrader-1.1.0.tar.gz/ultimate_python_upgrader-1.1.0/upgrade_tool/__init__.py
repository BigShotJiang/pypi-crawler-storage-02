"""
Ultimate Python Upgrader (`py-upgrade`)

An intelligent, feature-rich CLI tool to manage and upgrade Python packages.
"""