BLUESKY = "bsky"
MASTODON = "mstdn"

DEFAULT_BLUESKY_AGENT = "https://bsky.social"
DEFAULT_MASTODON_INSTANCE = "https://mastodon.social"
