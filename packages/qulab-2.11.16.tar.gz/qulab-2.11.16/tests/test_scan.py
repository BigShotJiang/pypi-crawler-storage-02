def test():
    assert 1 == 1
