from sqlalchemy.orm import declarative_base
from sqlalchemy.orm.session import Session

Base = declarative_base()
