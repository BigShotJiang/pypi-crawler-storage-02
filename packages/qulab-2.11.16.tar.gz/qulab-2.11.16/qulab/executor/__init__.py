from loguru import logger

from .schedule import maintain, run

# logger.configure(handlers=[])
