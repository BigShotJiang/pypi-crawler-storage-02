# relalational-search
A search algorithm that aims to search beyond the keywords.
