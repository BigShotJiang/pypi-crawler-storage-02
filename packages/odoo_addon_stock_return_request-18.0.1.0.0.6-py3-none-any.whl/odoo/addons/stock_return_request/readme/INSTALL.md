The installation of this module entails the computation of the new
stock.move field qty_returnable to store it in the DB, wich can be a
heavy task depending on the amount of moves.
