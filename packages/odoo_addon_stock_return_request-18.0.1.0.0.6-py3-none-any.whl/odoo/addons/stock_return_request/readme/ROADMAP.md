- Products are returned in the default product UoM. Further
  implementation should be done to allow to use UoM convertions.
