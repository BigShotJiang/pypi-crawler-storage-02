Filtrations
-----------

.. toctree::
   :maxdepth: 2

   rips
   lower-star

.. alpha-shapes


