#include <dionysus/omni-field-persistence.h>

using PyOmniFieldPersistence = dionysus::OmniFieldPersistence<>;

