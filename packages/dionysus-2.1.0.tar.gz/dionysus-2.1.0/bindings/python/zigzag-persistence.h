#include <dionysus/zigzag-persistence.h>

#include "field.h"

using PyZigzagPersistence = dionysus::ZigzagPersistence<PyZpField, int>;
