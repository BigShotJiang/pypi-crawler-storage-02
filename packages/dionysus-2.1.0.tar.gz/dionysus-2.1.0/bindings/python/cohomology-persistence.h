#include <dionysus/cohomology-persistence.h>
#include <dionysus/pair-recorder.h>

#include "field.h"

using PyCohomologyPersistence = dionysus::PairChainRecorder<dionysus::CohomologyPersistence<PyZpField>>;
