#ifndef DIONYSUS_FORMAT_H
#define DIONYSUS_FORMAT_H

#define FMT_HEADER_ONLY

#include "format/format.h"

#endif
