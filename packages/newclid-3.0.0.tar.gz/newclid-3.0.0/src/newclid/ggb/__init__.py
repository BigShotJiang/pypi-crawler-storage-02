"""Building problem setup from a Geogebra export."""
