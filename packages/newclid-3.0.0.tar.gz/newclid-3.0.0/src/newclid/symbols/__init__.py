"""Define symbols used in the proof state."""
