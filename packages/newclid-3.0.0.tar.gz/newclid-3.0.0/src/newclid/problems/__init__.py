"""Storage of JGEX problems instances from different sources."""

from newclid.problems.imo import ALL_IMO_PROBLEMS

ALL_PROBLEMS = ALL_IMO_PROBLEMS
