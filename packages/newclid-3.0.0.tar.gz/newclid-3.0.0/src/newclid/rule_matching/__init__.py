"""Implement different strategies to match applicable rules to points on the current proof state."""
