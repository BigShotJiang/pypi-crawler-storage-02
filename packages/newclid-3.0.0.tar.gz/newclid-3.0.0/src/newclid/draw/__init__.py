"""Supackage for drawing figures and animations from Newclid."""
