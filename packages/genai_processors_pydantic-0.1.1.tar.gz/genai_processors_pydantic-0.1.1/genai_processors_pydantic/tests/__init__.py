"""Tests for genai_processors_pydantic."""
