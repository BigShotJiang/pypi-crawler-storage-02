# Changelog

## 0.22.1 (2025-08-13)

Full Changelog: [v0.22.0...v0.22.1](https://github.com/hyperspell/python-sdk/compare/v0.22.0...v0.22.1)

### Features

* **api:** api update ([d2c231b](https://github.com/hyperspell/python-sdk/commit/d2c231b07652d05a03e545078b17da80d425a072))
* **api:** api update ([ac37961](https://github.com/hyperspell/python-sdk/commit/ac3796155df478f984b59d18b81e0ab8a0b20a36))


### Chores

* **internal:** update comment in script ([3f74f9d](https://github.com/hyperspell/python-sdk/commit/3f74f9ded72572e20d6839d14c34713d75c83d4c))
* update @stainless-api/prism-cli to v5.15.0 ([37e8a3f](https://github.com/hyperspell/python-sdk/commit/37e8a3f52aff75d78adc6ba7a0a51107cc9e0fe1))

## 0.22.0 (2025-08-06)

Full Changelog: [v0.21.0...v0.22.0](https://github.com/hyperspell/python-sdk/compare/v0.21.0...v0.22.0)

### Features

* **api:** api update ([853645f](https://github.com/hyperspell/python-sdk/commit/853645f31184d6be577afe6ef7e872bca5198b3c))
* **api:** api update ([e6c05cd](https://github.com/hyperspell/python-sdk/commit/e6c05cd496db6e9df09da720bd74e6c2f0f853b7))
* **api:** update via SDK Studio ([5d3bc9c](https://github.com/hyperspell/python-sdk/commit/5d3bc9c68523ff572bb27e8d77e24a2819f6e6be))
* **api:** update via SDK Studio ([37def01](https://github.com/hyperspell/python-sdk/commit/37def01e5290efee8228c0e81f6ef2c9e7fb2b0b))


### Chores

* **internal:** fix ruff target version ([9454556](https://github.com/hyperspell/python-sdk/commit/945455659b4896b89be368476adeb8c062e8d520))

## 0.21.0 (2025-08-05)

Full Changelog: [v0.20.0...v0.21.0](https://github.com/hyperspell/python-sdk/compare/v0.20.0...v0.21.0)

### Features

* **api:** api update ([ec5f973](https://github.com/hyperspell/python-sdk/commit/ec5f97338107ae64be0e174dda3ec4dda5903918))

## 0.20.0 (2025-08-01)

Full Changelog: [v0.19.0...v0.20.0](https://github.com/hyperspell/python-sdk/compare/v0.19.0...v0.20.0)

### Features

* **api:** api update ([6b411be](https://github.com/hyperspell/python-sdk/commit/6b411be3d85dbc3106741cfbfa08454ce443b173))
* **api:** api update ([0789efa](https://github.com/hyperspell/python-sdk/commit/0789efa8c1e2762ce8bf5329a7411dba886709dd))
* **api:** update via SDK Studio ([fd10b3b](https://github.com/hyperspell/python-sdk/commit/fd10b3b4b26774c5fcd033481712fda2cb77cc80))
* **api:** update via SDK Studio ([a92de5a](https://github.com/hyperspell/python-sdk/commit/a92de5a8dbc7c6b516b58d159840657c356cf423))
* **client:** support file upload requests ([98a9c26](https://github.com/hyperspell/python-sdk/commit/98a9c26c10636926fb05844b3494707e5d64babf))


### Bug Fixes

* **parsing:** ignore empty metadata ([01e34f8](https://github.com/hyperspell/python-sdk/commit/01e34f8e8697e5380884a0d93dd6b2d248f578d0))
* **parsing:** parse extra field types ([167331c](https://github.com/hyperspell/python-sdk/commit/167331c90f0001fa4165d2cafa185c6017383dad))


### Chores

* **project:** add settings file for vscode ([f597f95](https://github.com/hyperspell/python-sdk/commit/f597f9542a2572674dfc0a97fd94950cee114edf))

## 0.19.0 (2025-07-18)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/hyperspell/python-sdk/compare/v0.18.0...v0.19.0)

### Features

* **api:** api update ([e4edf05](https://github.com/hyperspell/python-sdk/commit/e4edf05d2e2700fef1e70250204aee103ac54686))
* **api:** api update ([7248ff5](https://github.com/hyperspell/python-sdk/commit/7248ff5db8bbc8708f8dfe8afb78d519401ee7f2))
* **api:** update via SDK Studio ([20bf1bb](https://github.com/hyperspell/python-sdk/commit/20bf1bbf36b4b5aa984cd6f405eb98fb6a743dba))
* **api:** update via SDK Studio ([21036b0](https://github.com/hyperspell/python-sdk/commit/21036b0a3b626fa41925b58b24616484158b9361))
* **api:** update via SDK Studio ([bf294db](https://github.com/hyperspell/python-sdk/commit/bf294db204ddb25338ab2370d78d6c378c78686a))
* clean up environment call outs ([e99844e](https://github.com/hyperspell/python-sdk/commit/e99844ee29928beeed51cd47d53e3ababe33e608))
* **client:** add support for aiohttp ([c0845dc](https://github.com/hyperspell/python-sdk/commit/c0845dc8133eb74e72f18651e9da53102609d833))


### Bug Fixes

* **ci:** correct conditional ([980b910](https://github.com/hyperspell/python-sdk/commit/980b910eaa78cf84de10c0521e4ed2f142689ae0))
* **ci:** release-doctor — report correct token name ([6ddb78b](https://github.com/hyperspell/python-sdk/commit/6ddb78b355f8e36a85fcfaf1592618bae5c67473))
* **client:** don't send Content-Type header on GET requests ([f7a04b5](https://github.com/hyperspell/python-sdk/commit/f7a04b5a47aa9a6fc338498a34db4074824c198e))
* **parsing:** correctly handle nested discriminated unions ([f4e309d](https://github.com/hyperspell/python-sdk/commit/f4e309d6a8d85f5aa0cb3fee3e41bf9c6487b5b1))


### Chores

* **ci:** change upload type ([c01d519](https://github.com/hyperspell/python-sdk/commit/c01d519131a2c4620c9454c4e634c2e39053b00c))
* **ci:** only run for pushes and fork pull requests ([991d685](https://github.com/hyperspell/python-sdk/commit/991d6859286e86aa022eb83aab8ecc6e337798f4))
* **internal:** bump pinned h11 dep ([1ce5781](https://github.com/hyperspell/python-sdk/commit/1ce57814e1d392b0c6a51b75c1dd92550f9399c3))
* **internal:** codegen related update ([f7cd6c7](https://github.com/hyperspell/python-sdk/commit/f7cd6c7b1feafef059ecdf6be0bb9adbd5f28929))
* **package:** mark python 3.13 as supported ([b04d1e6](https://github.com/hyperspell/python-sdk/commit/b04d1e6c7d2dbd8852963ee8f08596ed332e04ec))
* **readme:** fix version rendering on pypi ([a109225](https://github.com/hyperspell/python-sdk/commit/a1092259c98715d17ce95259420baf3c3d325db8))
* **tests:** skip some failing tests on the latest python versions ([9eebf62](https://github.com/hyperspell/python-sdk/commit/9eebf628b254b4f463ea7b899dcef53af5362228))

## 0.18.0 (2025-06-19)

Full Changelog: [v0.16.0...v0.18.0](https://github.com/hyperspell/python-sdk/compare/v0.16.0...v0.18.0)

### Features

* **api:** api update ([8316353](https://github.com/hyperspell/python-sdk/commit/83163535a6b7319bd8cc73239d50bcee3d5210bc))
* **api:** api update ([bdbe8e1](https://github.com/hyperspell/python-sdk/commit/bdbe8e18368b930262871391533f887557942b3a))
* **api:** api update ([3334f14](https://github.com/hyperspell/python-sdk/commit/3334f14582bda6ec78c9b479317c8d818b1c1227))
* **api:** api update ([b6ad9f4](https://github.com/hyperspell/python-sdk/commit/b6ad9f43113a8cbf23580027c37ecaf95cb37cb3))
* **api:** api update ([74e46e9](https://github.com/hyperspell/python-sdk/commit/74e46e9fc6e453ec408fc2641f8e3526df13927e))
* **api:** api update ([bccb2cc](https://github.com/hyperspell/python-sdk/commit/bccb2cc8cac69ba61476aa224a753b5c88f14eca))
* **api:** api update ([c05d86e](https://github.com/hyperspell/python-sdk/commit/c05d86eac76104c1a6b312663dd6b973070b51ce))
* **api:** api update ([b20e5b5](https://github.com/hyperspell/python-sdk/commit/b20e5b5bf8b894faf515d9ca770d757078d265d9))
* **api:** api update ([68a23b5](https://github.com/hyperspell/python-sdk/commit/68a23b559af192e808a96ec6627e66cd822dc6f3))
* **api:** api update ([8c94bf0](https://github.com/hyperspell/python-sdk/commit/8c94bf04366d1fb7d20c273f8f3bb0885e909371))
* **api:** api update ([98ba9ee](https://github.com/hyperspell/python-sdk/commit/98ba9eea46e52fc115349f02fb38b34bf6c0a2a5))
* **api:** api update ([7f9a7d6](https://github.com/hyperspell/python-sdk/commit/7f9a7d6d36ada54deb77797ca5df94c3aff3b03a))
* **api:** api update ([00ba4b4](https://github.com/hyperspell/python-sdk/commit/00ba4b401237d149089aa7cef3a5e8b394e86e91))
* **api:** api update ([cd17269](https://github.com/hyperspell/python-sdk/commit/cd17269808efe9af49416acb84ae6e1eaa4ef1c4))
* **api:** api update ([78195d4](https://github.com/hyperspell/python-sdk/commit/78195d43929013ad14e6a079b2c63c2f90fb8377))
* **api:** api update ([#12](https://github.com/hyperspell/python-sdk/issues/12)) ([14c9569](https://github.com/hyperspell/python-sdk/commit/14c95692111450a03e18b65b9fe84b76b1439741))
* **api:** api update ([#16](https://github.com/hyperspell/python-sdk/issues/16)) ([90ab745](https://github.com/hyperspell/python-sdk/commit/90ab745ece042d2a54a55fec5167db3bfa007618))
* **api:** api update ([#21](https://github.com/hyperspell/python-sdk/issues/21)) ([1b33d5e](https://github.com/hyperspell/python-sdk/commit/1b33d5e6cad083d1f6bfea037ddf79aeb558875b))
* **api:** api update ([#23](https://github.com/hyperspell/python-sdk/issues/23)) ([83dcd1d](https://github.com/hyperspell/python-sdk/commit/83dcd1d6bdd291e299330d532e974ab4e534c06d))
* **api:** api update ([#25](https://github.com/hyperspell/python-sdk/issues/25)) ([26170a5](https://github.com/hyperspell/python-sdk/commit/26170a5f86b9ed0dcbdd6cc01708a3a1a8a161b7))
* **api:** api update ([#28](https://github.com/hyperspell/python-sdk/issues/28)) ([72667ce](https://github.com/hyperspell/python-sdk/commit/72667cec5a0c172460551b0cce48aa667e88b99a))
* **api:** api update ([#29](https://github.com/hyperspell/python-sdk/issues/29)) ([e2312ba](https://github.com/hyperspell/python-sdk/commit/e2312bac25802f12f99f762d1e8e0cd7693dcf23))
* **api:** api update ([#30](https://github.com/hyperspell/python-sdk/issues/30)) ([08bae2f](https://github.com/hyperspell/python-sdk/commit/08bae2f240c913ffae8a6594877f4c78789f20f0))
* **api:** api update ([#31](https://github.com/hyperspell/python-sdk/issues/31)) ([a245e70](https://github.com/hyperspell/python-sdk/commit/a245e70aea6c76a5bdf45685ccb02edf271ab25b))
* **api:** api update ([#38](https://github.com/hyperspell/python-sdk/issues/38)) ([fd5a6d5](https://github.com/hyperspell/python-sdk/commit/fd5a6d5ba2b090d5cea1e70bf73d1674209c5907))
* **api:** api update ([#39](https://github.com/hyperspell/python-sdk/issues/39)) ([5aaf7cd](https://github.com/hyperspell/python-sdk/commit/5aaf7cd7208f1fef5edfeab8324ad6e977fae517))
* **api:** api update ([#4](https://github.com/hyperspell/python-sdk/issues/4)) ([b44636b](https://github.com/hyperspell/python-sdk/commit/b44636b513256d732590494a99dc0eb1b688df13))
* **api:** api update ([#43](https://github.com/hyperspell/python-sdk/issues/43)) ([7c8ccc6](https://github.com/hyperspell/python-sdk/commit/7c8ccc641b0f75f99dbd7a2992c15e03a39143c9))
* **api:** api update ([#44](https://github.com/hyperspell/python-sdk/issues/44)) ([693304c](https://github.com/hyperspell/python-sdk/commit/693304cef80f58fbda0eb78368a2047830f77c50))
* **api:** api update ([#48](https://github.com/hyperspell/python-sdk/issues/48)) ([5a8674d](https://github.com/hyperspell/python-sdk/commit/5a8674d60ac79e1a0e2784bd63aafa2a59727357))
* **api:** api update ([#49](https://github.com/hyperspell/python-sdk/issues/49)) ([2c1476c](https://github.com/hyperspell/python-sdk/commit/2c1476cdb81b093fa1729b830822be93f3709527))
* **api:** api update ([#5](https://github.com/hyperspell/python-sdk/issues/5)) ([3fc9775](https://github.com/hyperspell/python-sdk/commit/3fc97752048e4259b2f0a71358231315fb11cf23))
* **api:** api update ([#7](https://github.com/hyperspell/python-sdk/issues/7)) ([4c43cb7](https://github.com/hyperspell/python-sdk/commit/4c43cb7d7dc11fbe157b9ebb513d753b7210eef4))
* **api:** api update ([#71](https://github.com/hyperspell/python-sdk/issues/71)) ([5e4a65e](https://github.com/hyperspell/python-sdk/commit/5e4a65e73caf6914b2aa6a847709fb6b490af0f1))
* **api:** api update ([#77](https://github.com/hyperspell/python-sdk/issues/77)) ([5df0fc9](https://github.com/hyperspell/python-sdk/commit/5df0fc974b9990b3f00aec8e41822d418f0410ed))
* **api:** api update ([#79](https://github.com/hyperspell/python-sdk/issues/79)) ([4bbaa8b](https://github.com/hyperspell/python-sdk/commit/4bbaa8b5ee05ad8794f838cbba09244639598f1f))
* **api:** api update ([#8](https://github.com/hyperspell/python-sdk/issues/8)) ([bbe535f](https://github.com/hyperspell/python-sdk/commit/bbe535f81cefa788f07e6298345bbc1b18b07684))
* **api:** api update ([#81](https://github.com/hyperspell/python-sdk/issues/81)) ([816ced9](https://github.com/hyperspell/python-sdk/commit/816ced9a28f9f7d29488c54916f5166c53905a7b))
* **api:** api update ([#82](https://github.com/hyperspell/python-sdk/issues/82)) ([2a12261](https://github.com/hyperspell/python-sdk/commit/2a12261f52ef6c38863f54c46007b31cb888b45e))
* **api:** api update ([#83](https://github.com/hyperspell/python-sdk/issues/83)) ([e349d69](https://github.com/hyperspell/python-sdk/commit/e349d6919cf8bc3276b5da7e8aa3cfa8d4e23a67))
* **api:** api update ([#86](https://github.com/hyperspell/python-sdk/issues/86)) ([9cfa06b](https://github.com/hyperspell/python-sdk/commit/9cfa06b7c4bfab15f9b2e973b767dc02c9961877))
* **api:** update via SDK Studio ([3e2a9c8](https://github.com/hyperspell/python-sdk/commit/3e2a9c86135e8d972cebf8a6e79a1d07c44efc1b))
* **api:** update via SDK Studio ([0e3d89e](https://github.com/hyperspell/python-sdk/commit/0e3d89ee7008ce4462f5370917c9f784d275c390))
* **api:** update via SDK Studio ([bff74c9](https://github.com/hyperspell/python-sdk/commit/bff74c98b5b08e45e291381753340a22c6b04c89))
* **api:** update via SDK Studio ([5512870](https://github.com/hyperspell/python-sdk/commit/55128707104ac90ebcefe72795161d98c1790e6c))
* **api:** update via SDK Studio ([f82c2b5](https://github.com/hyperspell/python-sdk/commit/f82c2b5e708cd5c3cd5d62b451b52e6916afa23c))
* **api:** update via SDK Studio ([c7b0af6](https://github.com/hyperspell/python-sdk/commit/c7b0af61e07cbef440241ec4ba74c23d3445593b))
* **api:** update via SDK Studio ([4277aee](https://github.com/hyperspell/python-sdk/commit/4277aee6c04653c5c822480e4af7188de64235d0))
* **api:** update via SDK Studio ([#32](https://github.com/hyperspell/python-sdk/issues/32)) ([f8f7ad1](https://github.com/hyperspell/python-sdk/commit/f8f7ad136e37e084d5f3b8379d8e58bb04b85f2b))
* **api:** update via SDK Studio ([#33](https://github.com/hyperspell/python-sdk/issues/33)) ([d8aad38](https://github.com/hyperspell/python-sdk/commit/d8aad387e9a44b98f8fb1e2a0564e400203649d7))
* **api:** update via SDK Studio ([#41](https://github.com/hyperspell/python-sdk/issues/41)) ([2aaad04](https://github.com/hyperspell/python-sdk/commit/2aaad04fee563cf795dd0dbbc9d15b2ee0bbac65))
* **api:** update via SDK Studio ([#67](https://github.com/hyperspell/python-sdk/issues/67)) ([52566fe](https://github.com/hyperspell/python-sdk/commit/52566fe8f84f526eb78a5949b68de52bf0414cd4))
* **api:** update via SDK Studio ([#68](https://github.com/hyperspell/python-sdk/issues/68)) ([3014583](https://github.com/hyperspell/python-sdk/commit/3014583dd53a24950206dc0b2ef7fb3be53fbf55))
* **api:** update via SDK Studio ([#69](https://github.com/hyperspell/python-sdk/issues/69)) ([01cdba5](https://github.com/hyperspell/python-sdk/commit/01cdba5e514ddefc6f0aba9bcff2c8954a3b10e5))
* **api:** update via SDK Studio ([#70](https://github.com/hyperspell/python-sdk/issues/70)) ([f5871a8](https://github.com/hyperspell/python-sdk/commit/f5871a8f77a3839d90ce67bedcf9336caafb227b))
* **api:** update via SDK Studio ([#72](https://github.com/hyperspell/python-sdk/issues/72)) ([3551d71](https://github.com/hyperspell/python-sdk/commit/3551d711e30daaeac10f0935194ba97a30eecf87))
* **client:** add follow_redirects request option ([6402278](https://github.com/hyperspell/python-sdk/commit/6402278b75ad1ebc68d15a2d56b3f630c8139633))
* **client:** allow passing `NotGiven` for body ([#53](https://github.com/hyperspell/python-sdk/issues/53)) ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **client:** send `X-Stainless-Read-Timeout` header ([#45](https://github.com/hyperspell/python-sdk/issues/45)) ([314ac6f](https://github.com/hyperspell/python-sdk/commit/314ac6fbf8b7dbd4b3eb9d5293c4bdf6d21b4f36))


### Bug Fixes

* asyncify on non-asyncio runtimes ([#51](https://github.com/hyperspell/python-sdk/issues/51)) ([9a1d74d](https://github.com/hyperspell/python-sdk/commit/9a1d74da8a683ac1ae3474d298df21e097581a8d))
* **ci:** ensure pip is always available ([#65](https://github.com/hyperspell/python-sdk/issues/65)) ([fc830b0](https://github.com/hyperspell/python-sdk/commit/fc830b067dfc5e4408c772ac2275ad34aa503f97))
* **ci:** remove publishing patch ([#66](https://github.com/hyperspell/python-sdk/issues/66)) ([ca14208](https://github.com/hyperspell/python-sdk/commit/ca142083e62f5214f3b6fdd21a32c233a6d10ced))
* **client:** correctly parse binary response | stream ([5304250](https://github.com/hyperspell/python-sdk/commit/53042509a6ee129e470ff4e57ce6ba072b294cce))
* **client:** mark some request bodies as optional ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **client:** only call .close() when needed ([#11](https://github.com/hyperspell/python-sdk/issues/11)) ([23d4683](https://github.com/hyperspell/python-sdk/commit/23d468363e7b6aa433165ca42491a0351aad4274))
* correctly handle deserialising `cls` fields ([#15](https://github.com/hyperspell/python-sdk/issues/15)) ([dff71c6](https://github.com/hyperspell/python-sdk/commit/dff71c6d918c24b7dcfa0bea38ac7bbdb510b1af))
* **package:** support direct resource imports ([d8b54e0](https://github.com/hyperspell/python-sdk/commit/d8b54e020764be85d1fd2de167deb1e825e6aceb))
* **perf:** optimize some hot paths ([5d2b562](https://github.com/hyperspell/python-sdk/commit/5d2b5623fa87e6839df8e9a76662c3461be9b19c))
* **perf:** skip traversing types for NotGiven values ([8509e29](https://github.com/hyperspell/python-sdk/commit/8509e297c4e2e480a8f1f9ede0429fa94dc3f97d))
* **pydantic v1:** more robust ModelField.annotation check ([0e19885](https://github.com/hyperspell/python-sdk/commit/0e19885e7e31d9ce9cb0499995d44898111701b5))
* **tests:** fix: tests which call HTTP endpoints directly with the example parameters ([8121bc2](https://github.com/hyperspell/python-sdk/commit/8121bc2f5c651cdd51ec83bdd55ae72685f53be7))
* **tests:** make test_get_platform less flaky ([#19](https://github.com/hyperspell/python-sdk/issues/19)) ([4886fcf](https://github.com/hyperspell/python-sdk/commit/4886fcf1b23834c6b009c888d68ce8a6b292a79e))
* **types:** handle more discriminated union shapes ([#64](https://github.com/hyperspell/python-sdk/issues/64)) ([ea3ea28](https://github.com/hyperspell/python-sdk/commit/ea3ea28c4fca79d43f3372824dffdf5603d51f27))


### Chores

* add missing isclass check ([#9](https://github.com/hyperspell/python-sdk/issues/9)) ([12f5ed5](https://github.com/hyperspell/python-sdk/commit/12f5ed56926e50d94b2462636ff8302c29fbf296))
* broadly detect json family of content-type headers ([e03af44](https://github.com/hyperspell/python-sdk/commit/e03af4450a09bd2c8d7f6f63881c1f919c512270))
* **ci:** add timeout thresholds for CI jobs ([0a03092](https://github.com/hyperspell/python-sdk/commit/0a0309297b8954f728d9877d4dbec0fd14e9e5bb))
* **ci:** enable for pull requests ([be36a2d](https://github.com/hyperspell/python-sdk/commit/be36a2d8699cc44db332a126f7de25b7ba422a94))
* **ci:** fix installation instructions ([3567715](https://github.com/hyperspell/python-sdk/commit/3567715ff2540fa63cc0feed569a98d42af731a6))
* **ci:** only use depot for staging repos ([f8b4a37](https://github.com/hyperspell/python-sdk/commit/f8b4a37b034140150bcf7fae13bcfb15a5ec1fb8))
* **ci:** upload sdks to package manager ([733ed75](https://github.com/hyperspell/python-sdk/commit/733ed759b06612d5da69c9fd241240c951ef1964))
* **client:** minor internal fixes ([c1c047d](https://github.com/hyperspell/python-sdk/commit/c1c047de9b2b73f884a6d9a41ec00e0bd9362bf7))
* **docs:** grammar improvements ([5e2a523](https://github.com/hyperspell/python-sdk/commit/5e2a523d1c080c7254e9b2f0e3bc112c0bbfbe09))
* **docs:** remove reference to rye shell ([14db0da](https://github.com/hyperspell/python-sdk/commit/14db0dac660c359e5740e04b0aebb72578cb2577))
* **docs:** remove unnecessary param examples ([00bf3e4](https://github.com/hyperspell/python-sdk/commit/00bf3e468bf63ae069648cdcb45b897a6d2f0179))
* **docs:** update client docstring ([#57](https://github.com/hyperspell/python-sdk/issues/57)) ([b93eac9](https://github.com/hyperspell/python-sdk/commit/b93eac92c1aa75241baaeba8979ec9603a538193))
* go live ([#1](https://github.com/hyperspell/python-sdk/issues/1)) ([84713c4](https://github.com/hyperspell/python-sdk/commit/84713c43b10cce946f27e116b7a621c3348a83be))
* **internal:** avoid errors for isinstance checks on proxies ([c86a164](https://github.com/hyperspell/python-sdk/commit/c86a164ba1bdecfc7db3c4d12c9753d8c99ec232))
* **internal:** avoid pytest-asyncio deprecation warning ([#20](https://github.com/hyperspell/python-sdk/issues/20)) ([65f793b](https://github.com/hyperspell/python-sdk/commit/65f793b8d9da0222494949ea590e59123825d57e))
* **internal:** base client updates ([70b2439](https://github.com/hyperspell/python-sdk/commit/70b2439ad669934605653b780d1b2b9ca6fbd0c6))
* **internal:** bummp ruff dependency ([#37](https://github.com/hyperspell/python-sdk/issues/37)) ([cef604a](https://github.com/hyperspell/python-sdk/commit/cef604afecf30df7c584bb70ce4fa61ace9d4742))
* **internal:** bump httpx dependency ([#10](https://github.com/hyperspell/python-sdk/issues/10)) ([988e555](https://github.com/hyperspell/python-sdk/commit/988e555345b3b193784e7b156d73d3d77eb7d715))
* **internal:** bump pyright version ([6730ab4](https://github.com/hyperspell/python-sdk/commit/6730ab4c5f500720ddb5d6500260cbe9e4cf0375))
* **internal:** bump rye to 0.44.0 ([#63](https://github.com/hyperspell/python-sdk/issues/63)) ([d0d34fc](https://github.com/hyperspell/python-sdk/commit/d0d34fc3b73469284cdc43bc61bbee53906acb1d))
* **internal:** change default timeout to an int ([#35](https://github.com/hyperspell/python-sdk/issues/35)) ([f192b6f](https://github.com/hyperspell/python-sdk/commit/f192b6fdf340bfeb9e1853c752df0244841ab8c9))
* **internal:** codegen related update ([059575d](https://github.com/hyperspell/python-sdk/commit/059575d505a4e37bcee381422913786e98730cc0))
* **internal:** codegen related update ([#14](https://github.com/hyperspell/python-sdk/issues/14)) ([c7e587f](https://github.com/hyperspell/python-sdk/commit/c7e587fc23d72325d491a816a68a55e01d98735b))
* **internal:** codegen related update ([#17](https://github.com/hyperspell/python-sdk/issues/17)) ([9f186e4](https://github.com/hyperspell/python-sdk/commit/9f186e44b8f1c40853cc6f932995379bf187d2a9))
* **internal:** codegen related update ([#26](https://github.com/hyperspell/python-sdk/issues/26)) ([f6008b9](https://github.com/hyperspell/python-sdk/commit/f6008b93caaecd5b28e50c84dc908d820a0f222b))
* **internal:** codegen related update ([#52](https://github.com/hyperspell/python-sdk/issues/52)) ([1663641](https://github.com/hyperspell/python-sdk/commit/166364110507a27382de3ed086da802448a40420))
* **internal:** codegen related update ([#6](https://github.com/hyperspell/python-sdk/issues/6)) ([fa47f9e](https://github.com/hyperspell/python-sdk/commit/fa47f9eb5a5677f1a88d5b3034ec900a382f3e45))
* **internal:** codegen related update ([#62](https://github.com/hyperspell/python-sdk/issues/62)) ([7d8fa4f](https://github.com/hyperspell/python-sdk/commit/7d8fa4f7989e99c2da10e7119d1f0410d38362db))
* **internal:** expand CI branch coverage ([f1427b7](https://github.com/hyperspell/python-sdk/commit/f1427b73328af89415877c97b15d65ba86fa8ca4))
* **internal:** fix devcontainers setup ([#54](https://github.com/hyperspell/python-sdk/issues/54)) ([6b255f1](https://github.com/hyperspell/python-sdk/commit/6b255f161ecc1c9113b829327fe162167bf62b9b))
* **internal:** fix list file params ([29a6f87](https://github.com/hyperspell/python-sdk/commit/29a6f87ea8686a4cd0412ae712818804d704c18d))
* **internal:** fix type traversing dictionary params ([#46](https://github.com/hyperspell/python-sdk/issues/46)) ([3b755e0](https://github.com/hyperspell/python-sdk/commit/3b755e0e12f723232830aa9398f61b8d55da5735))
* **internal:** import reformatting ([220525f](https://github.com/hyperspell/python-sdk/commit/220525fbfa4af4d0773a723c2c0dd53c05daf790))
* **internal:** minor formatting changes ([1f27a6e](https://github.com/hyperspell/python-sdk/commit/1f27a6e74e0f8f25f5944fcdddfcd1fe620255bb))
* **internal:** minor formatting changes ([#27](https://github.com/hyperspell/python-sdk/issues/27)) ([b58a9f0](https://github.com/hyperspell/python-sdk/commit/b58a9f01edc5f9918f7a29fa81f1a8a1ae93bdfa))
* **internal:** minor type handling changes ([#47](https://github.com/hyperspell/python-sdk/issues/47)) ([de1503e](https://github.com/hyperspell/python-sdk/commit/de1503e4e5feabe6267187654467ced1f171ff57))
* **internal:** properly set __pydantic_private__ ([#55](https://github.com/hyperspell/python-sdk/issues/55)) ([412ccce](https://github.com/hyperspell/python-sdk/commit/412ccce91dc434650d88bc4c41f096c06132f1de))
* **internal:** reduce CI branch coverage ([31cead5](https://github.com/hyperspell/python-sdk/commit/31cead5ba3df9609967a8f8f3f579b4c856fe649))
* **internal:** refactor retries to not use recursion ([491a541](https://github.com/hyperspell/python-sdk/commit/491a541b6285df23e3de492fb3e1cf24f2b4db37))
* **internal:** remove extra empty newlines ([#61](https://github.com/hyperspell/python-sdk/issues/61)) ([b299f2e](https://github.com/hyperspell/python-sdk/commit/b299f2e25d537d7baf139579d11826e8fdbf655d))
* **internal:** remove trailing character ([#80](https://github.com/hyperspell/python-sdk/issues/80)) ([f28f2b7](https://github.com/hyperspell/python-sdk/commit/f28f2b705e253c8cb73b67eab20ed9e5c52a8f5d))
* **internal:** remove unused http client options forwarding ([#58](https://github.com/hyperspell/python-sdk/issues/58)) ([da92b87](https://github.com/hyperspell/python-sdk/commit/da92b87db946431698648460c2fa71ffaffe3437))
* **internal:** slight transform perf improvement ([#84](https://github.com/hyperspell/python-sdk/issues/84)) ([1a6703c](https://github.com/hyperspell/python-sdk/commit/1a6703c8d4f3fe6dd8fc2111c2e3cfd0ade27377))
* **internal:** update client tests ([#50](https://github.com/hyperspell/python-sdk/issues/50)) ([f31aeaf](https://github.com/hyperspell/python-sdk/commit/f31aeaf9eaecb541fbc092b5997518efbc8a34e9))
* **internal:** update conftest.py ([0564fee](https://github.com/hyperspell/python-sdk/commit/0564fee480c8d731cf678a706bdbb2c8089436ef))
* **internal:** update models test ([757a2dd](https://github.com/hyperspell/python-sdk/commit/757a2dd42bbadf9a94d28156dcffc3a4b6ad669b))
* **internal:** update pyright settings ([442555c](https://github.com/hyperspell/python-sdk/commit/442555c5f3430e17a42dd3363359810172858e1c))
* **readme:** update badges ([c2c73f5](https://github.com/hyperspell/python-sdk/commit/c2c73f56601e3bfde70479cf74cc4f6c2ac2818b))
* slight wording improvement in README ([#85](https://github.com/hyperspell/python-sdk/issues/85)) ([4597f85](https://github.com/hyperspell/python-sdk/commit/4597f85a79b9c4f8b3f1f05744c163aa0c837b73))
* **tests:** add tests for httpx client instantiation & proxies ([366c38b](https://github.com/hyperspell/python-sdk/commit/366c38b0ef2e11c95a301fca736a52d11a9992dd))
* **tests:** run tests in parallel ([b9ca684](https://github.com/hyperspell/python-sdk/commit/b9ca68436f382e30316174bfb0007612246e1bf7))
* update SDK settings ([#3](https://github.com/hyperspell/python-sdk/issues/3)) ([7d1e0bb](https://github.com/hyperspell/python-sdk/commit/7d1e0bb9ed0d49e2831255d3be1aa3a56503d77a))
* update SDK settings ([#74](https://github.com/hyperspell/python-sdk/issues/74)) ([2097566](https://github.com/hyperspell/python-sdk/commit/2097566f6ebaa15a5ab11191d3131f79aa2ae0fb))


### Documentation

* **client:** fix httpx.Timeout documentation reference ([741b8eb](https://github.com/hyperspell/python-sdk/commit/741b8eb3a70340950e3e53dc471e5e903b4ffff8))
* fix typos ([#13](https://github.com/hyperspell/python-sdk/issues/13)) ([84bf7b5](https://github.com/hyperspell/python-sdk/commit/84bf7b55e593e35b5b68ebac64909f21d3431938))
* **raw responses:** fix duplicate `the` ([#18](https://github.com/hyperspell/python-sdk/issues/18)) ([f99b1ca](https://github.com/hyperspell/python-sdk/commit/f99b1cadaa53c54cb27082d401fe376e0ce2f618))
* remove private imports from datetime snippets ([25eb634](https://github.com/hyperspell/python-sdk/commit/25eb634de104e2acb93104bcfdea1caf7344f627))
* revise readme docs about nested params ([#59](https://github.com/hyperspell/python-sdk/issues/59)) ([26a8c1e](https://github.com/hyperspell/python-sdk/commit/26a8c1e11b1d4286dbc627db63c064dc05e901f3))
* update URLs from stainlessapi.com to stainless.com ([#56](https://github.com/hyperspell/python-sdk/issues/56)) ([fb40ed8](https://github.com/hyperspell/python-sdk/commit/fb40ed87bdd21583e133307eb6c158d55e49b432))

## 0.16.0 (2025-05-29)

Full Changelog: [v0.13.0...v0.16.0](https://github.com/hyperspell/python-sdk/compare/v0.13.0...v0.16.0)

### Features

* **api:** api update ([3334f14](https://github.com/hyperspell/python-sdk/commit/3334f14582bda6ec78c9b479317c8d818b1c1227))
* **api:** api update ([b6ad9f4](https://github.com/hyperspell/python-sdk/commit/b6ad9f43113a8cbf23580027c37ecaf95cb37cb3))
* **api:** update via SDK Studio ([bff74c9](https://github.com/hyperspell/python-sdk/commit/bff74c98b5b08e45e291381753340a22c6b04c89))

## 0.13.0 (2025-05-26)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/hyperspell/python-sdk/compare/v0.12.0...v0.13.0)

### Features

* **api:** api update ([74e46e9](https://github.com/hyperspell/python-sdk/commit/74e46e9fc6e453ec408fc2641f8e3526df13927e))
* **api:** api update ([bccb2cc](https://github.com/hyperspell/python-sdk/commit/bccb2cc8cac69ba61476aa224a753b5c88f14eca))
* **api:** api update ([c05d86e](https://github.com/hyperspell/python-sdk/commit/c05d86eac76104c1a6b312663dd6b973070b51ce))
* **api:** api update ([b20e5b5](https://github.com/hyperspell/python-sdk/commit/b20e5b5bf8b894faf515d9ca770d757078d265d9))
* **api:** update via SDK Studio ([5512870](https://github.com/hyperspell/python-sdk/commit/55128707104ac90ebcefe72795161d98c1790e6c))


### Bug Fixes

* **package:** support direct resource imports ([d8b54e0](https://github.com/hyperspell/python-sdk/commit/d8b54e020764be85d1fd2de167deb1e825e6aceb))


### Chores

* **ci:** fix installation instructions ([3567715](https://github.com/hyperspell/python-sdk/commit/3567715ff2540fa63cc0feed569a98d42af731a6))
* **ci:** upload sdks to package manager ([733ed75](https://github.com/hyperspell/python-sdk/commit/733ed759b06612d5da69c9fd241240c951ef1964))
* **docs:** grammar improvements ([5e2a523](https://github.com/hyperspell/python-sdk/commit/5e2a523d1c080c7254e9b2f0e3bc112c0bbfbe09))
* **internal:** avoid errors for isinstance checks on proxies ([c86a164](https://github.com/hyperspell/python-sdk/commit/c86a164ba1bdecfc7db3c4d12c9753d8c99ec232))

## 0.12.0 (2025-04-30)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/hyperspell/python-sdk/compare/v0.11.0...v0.12.0)

### Features

* **api:** api update ([68a23b5](https://github.com/hyperspell/python-sdk/commit/68a23b559af192e808a96ec6627e66cd822dc6f3))
* **api:** api update ([8c94bf0](https://github.com/hyperspell/python-sdk/commit/8c94bf04366d1fb7d20c273f8f3bb0885e909371))
* **api:** api update ([98ba9ee](https://github.com/hyperspell/python-sdk/commit/98ba9eea46e52fc115349f02fb38b34bf6c0a2a5))
* **api:** api update ([7f9a7d6](https://github.com/hyperspell/python-sdk/commit/7f9a7d6d36ada54deb77797ca5df94c3aff3b03a))
* **api:** api update ([00ba4b4](https://github.com/hyperspell/python-sdk/commit/00ba4b401237d149089aa7cef3a5e8b394e86e91))
* **api:** api update ([cd17269](https://github.com/hyperspell/python-sdk/commit/cd17269808efe9af49416acb84ae6e1eaa4ef1c4))
* **api:** api update ([78195d4](https://github.com/hyperspell/python-sdk/commit/78195d43929013ad14e6a079b2c63c2f90fb8377))
* **api:** api update ([#12](https://github.com/hyperspell/python-sdk/issues/12)) ([14c9569](https://github.com/hyperspell/python-sdk/commit/14c95692111450a03e18b65b9fe84b76b1439741))
* **api:** api update ([#16](https://github.com/hyperspell/python-sdk/issues/16)) ([90ab745](https://github.com/hyperspell/python-sdk/commit/90ab745ece042d2a54a55fec5167db3bfa007618))
* **api:** api update ([#21](https://github.com/hyperspell/python-sdk/issues/21)) ([1b33d5e](https://github.com/hyperspell/python-sdk/commit/1b33d5e6cad083d1f6bfea037ddf79aeb558875b))
* **api:** api update ([#23](https://github.com/hyperspell/python-sdk/issues/23)) ([83dcd1d](https://github.com/hyperspell/python-sdk/commit/83dcd1d6bdd291e299330d532e974ab4e534c06d))
* **api:** api update ([#25](https://github.com/hyperspell/python-sdk/issues/25)) ([26170a5](https://github.com/hyperspell/python-sdk/commit/26170a5f86b9ed0dcbdd6cc01708a3a1a8a161b7))
* **api:** api update ([#28](https://github.com/hyperspell/python-sdk/issues/28)) ([72667ce](https://github.com/hyperspell/python-sdk/commit/72667cec5a0c172460551b0cce48aa667e88b99a))
* **api:** api update ([#29](https://github.com/hyperspell/python-sdk/issues/29)) ([e2312ba](https://github.com/hyperspell/python-sdk/commit/e2312bac25802f12f99f762d1e8e0cd7693dcf23))
* **api:** api update ([#30](https://github.com/hyperspell/python-sdk/issues/30)) ([08bae2f](https://github.com/hyperspell/python-sdk/commit/08bae2f240c913ffae8a6594877f4c78789f20f0))
* **api:** api update ([#31](https://github.com/hyperspell/python-sdk/issues/31)) ([a245e70](https://github.com/hyperspell/python-sdk/commit/a245e70aea6c76a5bdf45685ccb02edf271ab25b))
* **api:** api update ([#38](https://github.com/hyperspell/python-sdk/issues/38)) ([fd5a6d5](https://github.com/hyperspell/python-sdk/commit/fd5a6d5ba2b090d5cea1e70bf73d1674209c5907))
* **api:** api update ([#39](https://github.com/hyperspell/python-sdk/issues/39)) ([5aaf7cd](https://github.com/hyperspell/python-sdk/commit/5aaf7cd7208f1fef5edfeab8324ad6e977fae517))
* **api:** api update ([#4](https://github.com/hyperspell/python-sdk/issues/4)) ([b44636b](https://github.com/hyperspell/python-sdk/commit/b44636b513256d732590494a99dc0eb1b688df13))
* **api:** api update ([#43](https://github.com/hyperspell/python-sdk/issues/43)) ([7c8ccc6](https://github.com/hyperspell/python-sdk/commit/7c8ccc641b0f75f99dbd7a2992c15e03a39143c9))
* **api:** api update ([#44](https://github.com/hyperspell/python-sdk/issues/44)) ([693304c](https://github.com/hyperspell/python-sdk/commit/693304cef80f58fbda0eb78368a2047830f77c50))
* **api:** api update ([#48](https://github.com/hyperspell/python-sdk/issues/48)) ([5a8674d](https://github.com/hyperspell/python-sdk/commit/5a8674d60ac79e1a0e2784bd63aafa2a59727357))
* **api:** api update ([#49](https://github.com/hyperspell/python-sdk/issues/49)) ([2c1476c](https://github.com/hyperspell/python-sdk/commit/2c1476cdb81b093fa1729b830822be93f3709527))
* **api:** api update ([#5](https://github.com/hyperspell/python-sdk/issues/5)) ([3fc9775](https://github.com/hyperspell/python-sdk/commit/3fc97752048e4259b2f0a71358231315fb11cf23))
* **api:** api update ([#7](https://github.com/hyperspell/python-sdk/issues/7)) ([4c43cb7](https://github.com/hyperspell/python-sdk/commit/4c43cb7d7dc11fbe157b9ebb513d753b7210eef4))
* **api:** api update ([#71](https://github.com/hyperspell/python-sdk/issues/71)) ([5e4a65e](https://github.com/hyperspell/python-sdk/commit/5e4a65e73caf6914b2aa6a847709fb6b490af0f1))
* **api:** api update ([#77](https://github.com/hyperspell/python-sdk/issues/77)) ([5df0fc9](https://github.com/hyperspell/python-sdk/commit/5df0fc974b9990b3f00aec8e41822d418f0410ed))
* **api:** api update ([#79](https://github.com/hyperspell/python-sdk/issues/79)) ([4bbaa8b](https://github.com/hyperspell/python-sdk/commit/4bbaa8b5ee05ad8794f838cbba09244639598f1f))
* **api:** api update ([#8](https://github.com/hyperspell/python-sdk/issues/8)) ([bbe535f](https://github.com/hyperspell/python-sdk/commit/bbe535f81cefa788f07e6298345bbc1b18b07684))
* **api:** api update ([#81](https://github.com/hyperspell/python-sdk/issues/81)) ([816ced9](https://github.com/hyperspell/python-sdk/commit/816ced9a28f9f7d29488c54916f5166c53905a7b))
* **api:** api update ([#82](https://github.com/hyperspell/python-sdk/issues/82)) ([2a12261](https://github.com/hyperspell/python-sdk/commit/2a12261f52ef6c38863f54c46007b31cb888b45e))
* **api:** api update ([#83](https://github.com/hyperspell/python-sdk/issues/83)) ([e349d69](https://github.com/hyperspell/python-sdk/commit/e349d6919cf8bc3276b5da7e8aa3cfa8d4e23a67))
* **api:** api update ([#86](https://github.com/hyperspell/python-sdk/issues/86)) ([9cfa06b](https://github.com/hyperspell/python-sdk/commit/9cfa06b7c4bfab15f9b2e973b767dc02c9961877))
* **api:** update via SDK Studio ([f82c2b5](https://github.com/hyperspell/python-sdk/commit/f82c2b5e708cd5c3cd5d62b451b52e6916afa23c))
* **api:** update via SDK Studio ([c7b0af6](https://github.com/hyperspell/python-sdk/commit/c7b0af61e07cbef440241ec4ba74c23d3445593b))
* **api:** update via SDK Studio ([4277aee](https://github.com/hyperspell/python-sdk/commit/4277aee6c04653c5c822480e4af7188de64235d0))
* **api:** update via SDK Studio ([#32](https://github.com/hyperspell/python-sdk/issues/32)) ([f8f7ad1](https://github.com/hyperspell/python-sdk/commit/f8f7ad136e37e084d5f3b8379d8e58bb04b85f2b))
* **api:** update via SDK Studio ([#33](https://github.com/hyperspell/python-sdk/issues/33)) ([d8aad38](https://github.com/hyperspell/python-sdk/commit/d8aad387e9a44b98f8fb1e2a0564e400203649d7))
* **api:** update via SDK Studio ([#41](https://github.com/hyperspell/python-sdk/issues/41)) ([2aaad04](https://github.com/hyperspell/python-sdk/commit/2aaad04fee563cf795dd0dbbc9d15b2ee0bbac65))
* **api:** update via SDK Studio ([#67](https://github.com/hyperspell/python-sdk/issues/67)) ([52566fe](https://github.com/hyperspell/python-sdk/commit/52566fe8f84f526eb78a5949b68de52bf0414cd4))
* **api:** update via SDK Studio ([#68](https://github.com/hyperspell/python-sdk/issues/68)) ([3014583](https://github.com/hyperspell/python-sdk/commit/3014583dd53a24950206dc0b2ef7fb3be53fbf55))
* **api:** update via SDK Studio ([#69](https://github.com/hyperspell/python-sdk/issues/69)) ([01cdba5](https://github.com/hyperspell/python-sdk/commit/01cdba5e514ddefc6f0aba9bcff2c8954a3b10e5))
* **api:** update via SDK Studio ([#70](https://github.com/hyperspell/python-sdk/issues/70)) ([f5871a8](https://github.com/hyperspell/python-sdk/commit/f5871a8f77a3839d90ce67bedcf9336caafb227b))
* **api:** update via SDK Studio ([#72](https://github.com/hyperspell/python-sdk/issues/72)) ([3551d71](https://github.com/hyperspell/python-sdk/commit/3551d711e30daaeac10f0935194ba97a30eecf87))
* **client:** allow passing `NotGiven` for body ([#53](https://github.com/hyperspell/python-sdk/issues/53)) ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **client:** send `X-Stainless-Read-Timeout` header ([#45](https://github.com/hyperspell/python-sdk/issues/45)) ([314ac6f](https://github.com/hyperspell/python-sdk/commit/314ac6fbf8b7dbd4b3eb9d5293c4bdf6d21b4f36))


### Bug Fixes

* asyncify on non-asyncio runtimes ([#51](https://github.com/hyperspell/python-sdk/issues/51)) ([9a1d74d](https://github.com/hyperspell/python-sdk/commit/9a1d74da8a683ac1ae3474d298df21e097581a8d))
* **ci:** ensure pip is always available ([#65](https://github.com/hyperspell/python-sdk/issues/65)) ([fc830b0](https://github.com/hyperspell/python-sdk/commit/fc830b067dfc5e4408c772ac2275ad34aa503f97))
* **ci:** remove publishing patch ([#66](https://github.com/hyperspell/python-sdk/issues/66)) ([ca14208](https://github.com/hyperspell/python-sdk/commit/ca142083e62f5214f3b6fdd21a32c233a6d10ced))
* **client:** mark some request bodies as optional ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **client:** only call .close() when needed ([#11](https://github.com/hyperspell/python-sdk/issues/11)) ([23d4683](https://github.com/hyperspell/python-sdk/commit/23d468363e7b6aa433165ca42491a0351aad4274))
* correctly handle deserialising `cls` fields ([#15](https://github.com/hyperspell/python-sdk/issues/15)) ([dff71c6](https://github.com/hyperspell/python-sdk/commit/dff71c6d918c24b7dcfa0bea38ac7bbdb510b1af))
* **perf:** optimize some hot paths ([5d2b562](https://github.com/hyperspell/python-sdk/commit/5d2b5623fa87e6839df8e9a76662c3461be9b19c))
* **perf:** skip traversing types for NotGiven values ([8509e29](https://github.com/hyperspell/python-sdk/commit/8509e297c4e2e480a8f1f9ede0429fa94dc3f97d))
* **pydantic v1:** more robust ModelField.annotation check ([0e19885](https://github.com/hyperspell/python-sdk/commit/0e19885e7e31d9ce9cb0499995d44898111701b5))
* **tests:** make test_get_platform less flaky ([#19](https://github.com/hyperspell/python-sdk/issues/19)) ([4886fcf](https://github.com/hyperspell/python-sdk/commit/4886fcf1b23834c6b009c888d68ce8a6b292a79e))
* **types:** handle more discriminated union shapes ([#64](https://github.com/hyperspell/python-sdk/issues/64)) ([ea3ea28](https://github.com/hyperspell/python-sdk/commit/ea3ea28c4fca79d43f3372824dffdf5603d51f27))


### Chores

* add missing isclass check ([#9](https://github.com/hyperspell/python-sdk/issues/9)) ([12f5ed5](https://github.com/hyperspell/python-sdk/commit/12f5ed56926e50d94b2462636ff8302c29fbf296))
* broadly detect json family of content-type headers ([e03af44](https://github.com/hyperspell/python-sdk/commit/e03af4450a09bd2c8d7f6f63881c1f919c512270))
* **ci:** add timeout thresholds for CI jobs ([0a03092](https://github.com/hyperspell/python-sdk/commit/0a0309297b8954f728d9877d4dbec0fd14e9e5bb))
* **ci:** only use depot for staging repos ([f8b4a37](https://github.com/hyperspell/python-sdk/commit/f8b4a37b034140150bcf7fae13bcfb15a5ec1fb8))
* **client:** minor internal fixes ([c1c047d](https://github.com/hyperspell/python-sdk/commit/c1c047de9b2b73f884a6d9a41ec00e0bd9362bf7))
* **docs:** update client docstring ([#57](https://github.com/hyperspell/python-sdk/issues/57)) ([b93eac9](https://github.com/hyperspell/python-sdk/commit/b93eac92c1aa75241baaeba8979ec9603a538193))
* go live ([#1](https://github.com/hyperspell/python-sdk/issues/1)) ([84713c4](https://github.com/hyperspell/python-sdk/commit/84713c43b10cce946f27e116b7a621c3348a83be))
* **internal:** avoid pytest-asyncio deprecation warning ([#20](https://github.com/hyperspell/python-sdk/issues/20)) ([65f793b](https://github.com/hyperspell/python-sdk/commit/65f793b8d9da0222494949ea590e59123825d57e))
* **internal:** base client updates ([70b2439](https://github.com/hyperspell/python-sdk/commit/70b2439ad669934605653b780d1b2b9ca6fbd0c6))
* **internal:** bummp ruff dependency ([#37](https://github.com/hyperspell/python-sdk/issues/37)) ([cef604a](https://github.com/hyperspell/python-sdk/commit/cef604afecf30df7c584bb70ce4fa61ace9d4742))
* **internal:** bump httpx dependency ([#10](https://github.com/hyperspell/python-sdk/issues/10)) ([988e555](https://github.com/hyperspell/python-sdk/commit/988e555345b3b193784e7b156d73d3d77eb7d715))
* **internal:** bump pyright version ([6730ab4](https://github.com/hyperspell/python-sdk/commit/6730ab4c5f500720ddb5d6500260cbe9e4cf0375))
* **internal:** bump rye to 0.44.0 ([#63](https://github.com/hyperspell/python-sdk/issues/63)) ([d0d34fc](https://github.com/hyperspell/python-sdk/commit/d0d34fc3b73469284cdc43bc61bbee53906acb1d))
* **internal:** change default timeout to an int ([#35](https://github.com/hyperspell/python-sdk/issues/35)) ([f192b6f](https://github.com/hyperspell/python-sdk/commit/f192b6fdf340bfeb9e1853c752df0244841ab8c9))
* **internal:** codegen related update ([059575d](https://github.com/hyperspell/python-sdk/commit/059575d505a4e37bcee381422913786e98730cc0))
* **internal:** codegen related update ([#14](https://github.com/hyperspell/python-sdk/issues/14)) ([c7e587f](https://github.com/hyperspell/python-sdk/commit/c7e587fc23d72325d491a816a68a55e01d98735b))
* **internal:** codegen related update ([#17](https://github.com/hyperspell/python-sdk/issues/17)) ([9f186e4](https://github.com/hyperspell/python-sdk/commit/9f186e44b8f1c40853cc6f932995379bf187d2a9))
* **internal:** codegen related update ([#26](https://github.com/hyperspell/python-sdk/issues/26)) ([f6008b9](https://github.com/hyperspell/python-sdk/commit/f6008b93caaecd5b28e50c84dc908d820a0f222b))
* **internal:** codegen related update ([#52](https://github.com/hyperspell/python-sdk/issues/52)) ([1663641](https://github.com/hyperspell/python-sdk/commit/166364110507a27382de3ed086da802448a40420))
* **internal:** codegen related update ([#6](https://github.com/hyperspell/python-sdk/issues/6)) ([fa47f9e](https://github.com/hyperspell/python-sdk/commit/fa47f9eb5a5677f1a88d5b3034ec900a382f3e45))
* **internal:** codegen related update ([#62](https://github.com/hyperspell/python-sdk/issues/62)) ([7d8fa4f](https://github.com/hyperspell/python-sdk/commit/7d8fa4f7989e99c2da10e7119d1f0410d38362db))
* **internal:** expand CI branch coverage ([f1427b7](https://github.com/hyperspell/python-sdk/commit/f1427b73328af89415877c97b15d65ba86fa8ca4))
* **internal:** fix devcontainers setup ([#54](https://github.com/hyperspell/python-sdk/issues/54)) ([6b255f1](https://github.com/hyperspell/python-sdk/commit/6b255f161ecc1c9113b829327fe162167bf62b9b))
* **internal:** fix list file params ([29a6f87](https://github.com/hyperspell/python-sdk/commit/29a6f87ea8686a4cd0412ae712818804d704c18d))
* **internal:** fix type traversing dictionary params ([#46](https://github.com/hyperspell/python-sdk/issues/46)) ([3b755e0](https://github.com/hyperspell/python-sdk/commit/3b755e0e12f723232830aa9398f61b8d55da5735))
* **internal:** import reformatting ([220525f](https://github.com/hyperspell/python-sdk/commit/220525fbfa4af4d0773a723c2c0dd53c05daf790))
* **internal:** minor formatting changes ([1f27a6e](https://github.com/hyperspell/python-sdk/commit/1f27a6e74e0f8f25f5944fcdddfcd1fe620255bb))
* **internal:** minor formatting changes ([#27](https://github.com/hyperspell/python-sdk/issues/27)) ([b58a9f0](https://github.com/hyperspell/python-sdk/commit/b58a9f01edc5f9918f7a29fa81f1a8a1ae93bdfa))
* **internal:** minor type handling changes ([#47](https://github.com/hyperspell/python-sdk/issues/47)) ([de1503e](https://github.com/hyperspell/python-sdk/commit/de1503e4e5feabe6267187654467ced1f171ff57))
* **internal:** properly set __pydantic_private__ ([#55](https://github.com/hyperspell/python-sdk/issues/55)) ([412ccce](https://github.com/hyperspell/python-sdk/commit/412ccce91dc434650d88bc4c41f096c06132f1de))
* **internal:** reduce CI branch coverage ([31cead5](https://github.com/hyperspell/python-sdk/commit/31cead5ba3df9609967a8f8f3f579b4c856fe649))
* **internal:** refactor retries to not use recursion ([491a541](https://github.com/hyperspell/python-sdk/commit/491a541b6285df23e3de492fb3e1cf24f2b4db37))
* **internal:** remove extra empty newlines ([#61](https://github.com/hyperspell/python-sdk/issues/61)) ([b299f2e](https://github.com/hyperspell/python-sdk/commit/b299f2e25d537d7baf139579d11826e8fdbf655d))
* **internal:** remove trailing character ([#80](https://github.com/hyperspell/python-sdk/issues/80)) ([f28f2b7](https://github.com/hyperspell/python-sdk/commit/f28f2b705e253c8cb73b67eab20ed9e5c52a8f5d))
* **internal:** remove unused http client options forwarding ([#58](https://github.com/hyperspell/python-sdk/issues/58)) ([da92b87](https://github.com/hyperspell/python-sdk/commit/da92b87db946431698648460c2fa71ffaffe3437))
* **internal:** slight transform perf improvement ([#84](https://github.com/hyperspell/python-sdk/issues/84)) ([1a6703c](https://github.com/hyperspell/python-sdk/commit/1a6703c8d4f3fe6dd8fc2111c2e3cfd0ade27377))
* **internal:** update client tests ([#50](https://github.com/hyperspell/python-sdk/issues/50)) ([f31aeaf](https://github.com/hyperspell/python-sdk/commit/f31aeaf9eaecb541fbc092b5997518efbc8a34e9))
* **internal:** update models test ([757a2dd](https://github.com/hyperspell/python-sdk/commit/757a2dd42bbadf9a94d28156dcffc3a4b6ad669b))
* **internal:** update pyright settings ([442555c](https://github.com/hyperspell/python-sdk/commit/442555c5f3430e17a42dd3363359810172858e1c))
* slight wording improvement in README ([#85](https://github.com/hyperspell/python-sdk/issues/85)) ([4597f85](https://github.com/hyperspell/python-sdk/commit/4597f85a79b9c4f8b3f1f05744c163aa0c837b73))
* update SDK settings ([#3](https://github.com/hyperspell/python-sdk/issues/3)) ([7d1e0bb](https://github.com/hyperspell/python-sdk/commit/7d1e0bb9ed0d49e2831255d3be1aa3a56503d77a))
* update SDK settings ([#74](https://github.com/hyperspell/python-sdk/issues/74)) ([2097566](https://github.com/hyperspell/python-sdk/commit/2097566f6ebaa15a5ab11191d3131f79aa2ae0fb))


### Documentation

* fix typos ([#13](https://github.com/hyperspell/python-sdk/issues/13)) ([84bf7b5](https://github.com/hyperspell/python-sdk/commit/84bf7b55e593e35b5b68ebac64909f21d3431938))
* **raw responses:** fix duplicate `the` ([#18](https://github.com/hyperspell/python-sdk/issues/18)) ([f99b1ca](https://github.com/hyperspell/python-sdk/commit/f99b1cadaa53c54cb27082d401fe376e0ce2f618))
* remove private imports from datetime snippets ([25eb634](https://github.com/hyperspell/python-sdk/commit/25eb634de104e2acb93104bcfdea1caf7344f627))
* revise readme docs about nested params ([#59](https://github.com/hyperspell/python-sdk/issues/59)) ([26a8c1e](https://github.com/hyperspell/python-sdk/commit/26a8c1e11b1d4286dbc627db63c064dc05e901f3))
* update URLs from stainlessapi.com to stainless.com ([#56](https://github.com/hyperspell/python-sdk/issues/56)) ([fb40ed8](https://github.com/hyperspell/python-sdk/commit/fb40ed87bdd21583e133307eb6c158d55e49b432))

## 0.11.0 (2025-04-21)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/hyperspell/python-sdk/compare/v0.10.0...v0.11.0)

### Features

* **api:** update via SDK Studio ([f82c2b5](https://github.com/hyperspell/python-sdk/commit/f82c2b5e708cd5c3cd5d62b451b52e6916afa23c))
* **api:** update via SDK Studio ([c7b0af6](https://github.com/hyperspell/python-sdk/commit/c7b0af61e07cbef440241ec4ba74c23d3445593b))
* **api:** update via SDK Studio ([4277aee](https://github.com/hyperspell/python-sdk/commit/4277aee6c04653c5c822480e4af7188de64235d0))

## 0.10.0 (2025-04-19)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/hyperspell/python-sdk/compare/v0.9.0...v0.10.0)

### Features

* **api:** api update ([98ba9ee](https://github.com/hyperspell/python-sdk/commit/98ba9eea46e52fc115349f02fb38b34bf6c0a2a5))
* **api:** api update ([7f9a7d6](https://github.com/hyperspell/python-sdk/commit/7f9a7d6d36ada54deb77797ca5df94c3aff3b03a))
* **api:** api update ([00ba4b4](https://github.com/hyperspell/python-sdk/commit/00ba4b401237d149089aa7cef3a5e8b394e86e91))
* **api:** api update ([cd17269](https://github.com/hyperspell/python-sdk/commit/cd17269808efe9af49416acb84ae6e1eaa4ef1c4))
* **api:** api update ([78195d4](https://github.com/hyperspell/python-sdk/commit/78195d43929013ad14e6a079b2c63c2f90fb8377))
* **api:** api update ([#12](https://github.com/hyperspell/python-sdk/issues/12)) ([14c9569](https://github.com/hyperspell/python-sdk/commit/14c95692111450a03e18b65b9fe84b76b1439741))
* **api:** api update ([#16](https://github.com/hyperspell/python-sdk/issues/16)) ([90ab745](https://github.com/hyperspell/python-sdk/commit/90ab745ece042d2a54a55fec5167db3bfa007618))
* **api:** api update ([#21](https://github.com/hyperspell/python-sdk/issues/21)) ([1b33d5e](https://github.com/hyperspell/python-sdk/commit/1b33d5e6cad083d1f6bfea037ddf79aeb558875b))
* **api:** api update ([#23](https://github.com/hyperspell/python-sdk/issues/23)) ([83dcd1d](https://github.com/hyperspell/python-sdk/commit/83dcd1d6bdd291e299330d532e974ab4e534c06d))
* **api:** api update ([#25](https://github.com/hyperspell/python-sdk/issues/25)) ([26170a5](https://github.com/hyperspell/python-sdk/commit/26170a5f86b9ed0dcbdd6cc01708a3a1a8a161b7))
* **api:** api update ([#28](https://github.com/hyperspell/python-sdk/issues/28)) ([72667ce](https://github.com/hyperspell/python-sdk/commit/72667cec5a0c172460551b0cce48aa667e88b99a))
* **api:** api update ([#29](https://github.com/hyperspell/python-sdk/issues/29)) ([e2312ba](https://github.com/hyperspell/python-sdk/commit/e2312bac25802f12f99f762d1e8e0cd7693dcf23))
* **api:** api update ([#30](https://github.com/hyperspell/python-sdk/issues/30)) ([08bae2f](https://github.com/hyperspell/python-sdk/commit/08bae2f240c913ffae8a6594877f4c78789f20f0))
* **api:** api update ([#31](https://github.com/hyperspell/python-sdk/issues/31)) ([a245e70](https://github.com/hyperspell/python-sdk/commit/a245e70aea6c76a5bdf45685ccb02edf271ab25b))
* **api:** api update ([#38](https://github.com/hyperspell/python-sdk/issues/38)) ([fd5a6d5](https://github.com/hyperspell/python-sdk/commit/fd5a6d5ba2b090d5cea1e70bf73d1674209c5907))
* **api:** api update ([#39](https://github.com/hyperspell/python-sdk/issues/39)) ([5aaf7cd](https://github.com/hyperspell/python-sdk/commit/5aaf7cd7208f1fef5edfeab8324ad6e977fae517))
* **api:** api update ([#4](https://github.com/hyperspell/python-sdk/issues/4)) ([b44636b](https://github.com/hyperspell/python-sdk/commit/b44636b513256d732590494a99dc0eb1b688df13))
* **api:** api update ([#43](https://github.com/hyperspell/python-sdk/issues/43)) ([7c8ccc6](https://github.com/hyperspell/python-sdk/commit/7c8ccc641b0f75f99dbd7a2992c15e03a39143c9))
* **api:** api update ([#44](https://github.com/hyperspell/python-sdk/issues/44)) ([693304c](https://github.com/hyperspell/python-sdk/commit/693304cef80f58fbda0eb78368a2047830f77c50))
* **api:** api update ([#48](https://github.com/hyperspell/python-sdk/issues/48)) ([5a8674d](https://github.com/hyperspell/python-sdk/commit/5a8674d60ac79e1a0e2784bd63aafa2a59727357))
* **api:** api update ([#49](https://github.com/hyperspell/python-sdk/issues/49)) ([2c1476c](https://github.com/hyperspell/python-sdk/commit/2c1476cdb81b093fa1729b830822be93f3709527))
* **api:** api update ([#5](https://github.com/hyperspell/python-sdk/issues/5)) ([3fc9775](https://github.com/hyperspell/python-sdk/commit/3fc97752048e4259b2f0a71358231315fb11cf23))
* **api:** api update ([#7](https://github.com/hyperspell/python-sdk/issues/7)) ([4c43cb7](https://github.com/hyperspell/python-sdk/commit/4c43cb7d7dc11fbe157b9ebb513d753b7210eef4))
* **api:** api update ([#71](https://github.com/hyperspell/python-sdk/issues/71)) ([5e4a65e](https://github.com/hyperspell/python-sdk/commit/5e4a65e73caf6914b2aa6a847709fb6b490af0f1))
* **api:** api update ([#77](https://github.com/hyperspell/python-sdk/issues/77)) ([5df0fc9](https://github.com/hyperspell/python-sdk/commit/5df0fc974b9990b3f00aec8e41822d418f0410ed))
* **api:** api update ([#79](https://github.com/hyperspell/python-sdk/issues/79)) ([4bbaa8b](https://github.com/hyperspell/python-sdk/commit/4bbaa8b5ee05ad8794f838cbba09244639598f1f))
* **api:** api update ([#8](https://github.com/hyperspell/python-sdk/issues/8)) ([bbe535f](https://github.com/hyperspell/python-sdk/commit/bbe535f81cefa788f07e6298345bbc1b18b07684))
* **api:** api update ([#81](https://github.com/hyperspell/python-sdk/issues/81)) ([816ced9](https://github.com/hyperspell/python-sdk/commit/816ced9a28f9f7d29488c54916f5166c53905a7b))
* **api:** api update ([#82](https://github.com/hyperspell/python-sdk/issues/82)) ([2a12261](https://github.com/hyperspell/python-sdk/commit/2a12261f52ef6c38863f54c46007b31cb888b45e))
* **api:** api update ([#83](https://github.com/hyperspell/python-sdk/issues/83)) ([e349d69](https://github.com/hyperspell/python-sdk/commit/e349d6919cf8bc3276b5da7e8aa3cfa8d4e23a67))
* **api:** api update ([#86](https://github.com/hyperspell/python-sdk/issues/86)) ([9cfa06b](https://github.com/hyperspell/python-sdk/commit/9cfa06b7c4bfab15f9b2e973b767dc02c9961877))
* **api:** update via SDK Studio ([#32](https://github.com/hyperspell/python-sdk/issues/32)) ([f8f7ad1](https://github.com/hyperspell/python-sdk/commit/f8f7ad136e37e084d5f3b8379d8e58bb04b85f2b))
* **api:** update via SDK Studio ([#33](https://github.com/hyperspell/python-sdk/issues/33)) ([d8aad38](https://github.com/hyperspell/python-sdk/commit/d8aad387e9a44b98f8fb1e2a0564e400203649d7))
* **api:** update via SDK Studio ([#41](https://github.com/hyperspell/python-sdk/issues/41)) ([2aaad04](https://github.com/hyperspell/python-sdk/commit/2aaad04fee563cf795dd0dbbc9d15b2ee0bbac65))
* **api:** update via SDK Studio ([#67](https://github.com/hyperspell/python-sdk/issues/67)) ([52566fe](https://github.com/hyperspell/python-sdk/commit/52566fe8f84f526eb78a5949b68de52bf0414cd4))
* **api:** update via SDK Studio ([#68](https://github.com/hyperspell/python-sdk/issues/68)) ([3014583](https://github.com/hyperspell/python-sdk/commit/3014583dd53a24950206dc0b2ef7fb3be53fbf55))
* **api:** update via SDK Studio ([#69](https://github.com/hyperspell/python-sdk/issues/69)) ([01cdba5](https://github.com/hyperspell/python-sdk/commit/01cdba5e514ddefc6f0aba9bcff2c8954a3b10e5))
* **api:** update via SDK Studio ([#70](https://github.com/hyperspell/python-sdk/issues/70)) ([f5871a8](https://github.com/hyperspell/python-sdk/commit/f5871a8f77a3839d90ce67bedcf9336caafb227b))
* **api:** update via SDK Studio ([#72](https://github.com/hyperspell/python-sdk/issues/72)) ([3551d71](https://github.com/hyperspell/python-sdk/commit/3551d711e30daaeac10f0935194ba97a30eecf87))
* **client:** allow passing `NotGiven` for body ([#53](https://github.com/hyperspell/python-sdk/issues/53)) ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **client:** send `X-Stainless-Read-Timeout` header ([#45](https://github.com/hyperspell/python-sdk/issues/45)) ([314ac6f](https://github.com/hyperspell/python-sdk/commit/314ac6fbf8b7dbd4b3eb9d5293c4bdf6d21b4f36))


### Bug Fixes

* asyncify on non-asyncio runtimes ([#51](https://github.com/hyperspell/python-sdk/issues/51)) ([9a1d74d](https://github.com/hyperspell/python-sdk/commit/9a1d74da8a683ac1ae3474d298df21e097581a8d))
* **ci:** ensure pip is always available ([#65](https://github.com/hyperspell/python-sdk/issues/65)) ([fc830b0](https://github.com/hyperspell/python-sdk/commit/fc830b067dfc5e4408c772ac2275ad34aa503f97))
* **ci:** remove publishing patch ([#66](https://github.com/hyperspell/python-sdk/issues/66)) ([ca14208](https://github.com/hyperspell/python-sdk/commit/ca142083e62f5214f3b6fdd21a32c233a6d10ced))
* **client:** mark some request bodies as optional ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **client:** only call .close() when needed ([#11](https://github.com/hyperspell/python-sdk/issues/11)) ([23d4683](https://github.com/hyperspell/python-sdk/commit/23d468363e7b6aa433165ca42491a0351aad4274))
* correctly handle deserialising `cls` fields ([#15](https://github.com/hyperspell/python-sdk/issues/15)) ([dff71c6](https://github.com/hyperspell/python-sdk/commit/dff71c6d918c24b7dcfa0bea38ac7bbdb510b1af))
* **perf:** optimize some hot paths ([5d2b562](https://github.com/hyperspell/python-sdk/commit/5d2b5623fa87e6839df8e9a76662c3461be9b19c))
* **perf:** skip traversing types for NotGiven values ([8509e29](https://github.com/hyperspell/python-sdk/commit/8509e297c4e2e480a8f1f9ede0429fa94dc3f97d))
* **tests:** make test_get_platform less flaky ([#19](https://github.com/hyperspell/python-sdk/issues/19)) ([4886fcf](https://github.com/hyperspell/python-sdk/commit/4886fcf1b23834c6b009c888d68ce8a6b292a79e))
* **types:** handle more discriminated union shapes ([#64](https://github.com/hyperspell/python-sdk/issues/64)) ([ea3ea28](https://github.com/hyperspell/python-sdk/commit/ea3ea28c4fca79d43f3372824dffdf5603d51f27))


### Chores

* add missing isclass check ([#9](https://github.com/hyperspell/python-sdk/issues/9)) ([12f5ed5](https://github.com/hyperspell/python-sdk/commit/12f5ed56926e50d94b2462636ff8302c29fbf296))
* **client:** minor internal fixes ([c1c047d](https://github.com/hyperspell/python-sdk/commit/c1c047de9b2b73f884a6d9a41ec00e0bd9362bf7))
* **docs:** update client docstring ([#57](https://github.com/hyperspell/python-sdk/issues/57)) ([b93eac9](https://github.com/hyperspell/python-sdk/commit/b93eac92c1aa75241baaeba8979ec9603a538193))
* go live ([#1](https://github.com/hyperspell/python-sdk/issues/1)) ([84713c4](https://github.com/hyperspell/python-sdk/commit/84713c43b10cce946f27e116b7a621c3348a83be))
* **internal:** avoid pytest-asyncio deprecation warning ([#20](https://github.com/hyperspell/python-sdk/issues/20)) ([65f793b](https://github.com/hyperspell/python-sdk/commit/65f793b8d9da0222494949ea590e59123825d57e))
* **internal:** base client updates ([70b2439](https://github.com/hyperspell/python-sdk/commit/70b2439ad669934605653b780d1b2b9ca6fbd0c6))
* **internal:** bummp ruff dependency ([#37](https://github.com/hyperspell/python-sdk/issues/37)) ([cef604a](https://github.com/hyperspell/python-sdk/commit/cef604afecf30df7c584bb70ce4fa61ace9d4742))
* **internal:** bump httpx dependency ([#10](https://github.com/hyperspell/python-sdk/issues/10)) ([988e555](https://github.com/hyperspell/python-sdk/commit/988e555345b3b193784e7b156d73d3d77eb7d715))
* **internal:** bump pyright version ([6730ab4](https://github.com/hyperspell/python-sdk/commit/6730ab4c5f500720ddb5d6500260cbe9e4cf0375))
* **internal:** bump rye to 0.44.0 ([#63](https://github.com/hyperspell/python-sdk/issues/63)) ([d0d34fc](https://github.com/hyperspell/python-sdk/commit/d0d34fc3b73469284cdc43bc61bbee53906acb1d))
* **internal:** change default timeout to an int ([#35](https://github.com/hyperspell/python-sdk/issues/35)) ([f192b6f](https://github.com/hyperspell/python-sdk/commit/f192b6fdf340bfeb9e1853c752df0244841ab8c9))
* **internal:** codegen related update ([#14](https://github.com/hyperspell/python-sdk/issues/14)) ([c7e587f](https://github.com/hyperspell/python-sdk/commit/c7e587fc23d72325d491a816a68a55e01d98735b))
* **internal:** codegen related update ([#17](https://github.com/hyperspell/python-sdk/issues/17)) ([9f186e4](https://github.com/hyperspell/python-sdk/commit/9f186e44b8f1c40853cc6f932995379bf187d2a9))
* **internal:** codegen related update ([#26](https://github.com/hyperspell/python-sdk/issues/26)) ([f6008b9](https://github.com/hyperspell/python-sdk/commit/f6008b93caaecd5b28e50c84dc908d820a0f222b))
* **internal:** codegen related update ([#52](https://github.com/hyperspell/python-sdk/issues/52)) ([1663641](https://github.com/hyperspell/python-sdk/commit/166364110507a27382de3ed086da802448a40420))
* **internal:** codegen related update ([#6](https://github.com/hyperspell/python-sdk/issues/6)) ([fa47f9e](https://github.com/hyperspell/python-sdk/commit/fa47f9eb5a5677f1a88d5b3034ec900a382f3e45))
* **internal:** codegen related update ([#62](https://github.com/hyperspell/python-sdk/issues/62)) ([7d8fa4f](https://github.com/hyperspell/python-sdk/commit/7d8fa4f7989e99c2da10e7119d1f0410d38362db))
* **internal:** expand CI branch coverage ([f1427b7](https://github.com/hyperspell/python-sdk/commit/f1427b73328af89415877c97b15d65ba86fa8ca4))
* **internal:** fix devcontainers setup ([#54](https://github.com/hyperspell/python-sdk/issues/54)) ([6b255f1](https://github.com/hyperspell/python-sdk/commit/6b255f161ecc1c9113b829327fe162167bf62b9b))
* **internal:** fix type traversing dictionary params ([#46](https://github.com/hyperspell/python-sdk/issues/46)) ([3b755e0](https://github.com/hyperspell/python-sdk/commit/3b755e0e12f723232830aa9398f61b8d55da5735))
* **internal:** minor formatting changes ([#27](https://github.com/hyperspell/python-sdk/issues/27)) ([b58a9f0](https://github.com/hyperspell/python-sdk/commit/b58a9f01edc5f9918f7a29fa81f1a8a1ae93bdfa))
* **internal:** minor type handling changes ([#47](https://github.com/hyperspell/python-sdk/issues/47)) ([de1503e](https://github.com/hyperspell/python-sdk/commit/de1503e4e5feabe6267187654467ced1f171ff57))
* **internal:** properly set __pydantic_private__ ([#55](https://github.com/hyperspell/python-sdk/issues/55)) ([412ccce](https://github.com/hyperspell/python-sdk/commit/412ccce91dc434650d88bc4c41f096c06132f1de))
* **internal:** reduce CI branch coverage ([31cead5](https://github.com/hyperspell/python-sdk/commit/31cead5ba3df9609967a8f8f3f579b4c856fe649))
* **internal:** remove extra empty newlines ([#61](https://github.com/hyperspell/python-sdk/issues/61)) ([b299f2e](https://github.com/hyperspell/python-sdk/commit/b299f2e25d537d7baf139579d11826e8fdbf655d))
* **internal:** remove trailing character ([#80](https://github.com/hyperspell/python-sdk/issues/80)) ([f28f2b7](https://github.com/hyperspell/python-sdk/commit/f28f2b705e253c8cb73b67eab20ed9e5c52a8f5d))
* **internal:** remove unused http client options forwarding ([#58](https://github.com/hyperspell/python-sdk/issues/58)) ([da92b87](https://github.com/hyperspell/python-sdk/commit/da92b87db946431698648460c2fa71ffaffe3437))
* **internal:** slight transform perf improvement ([#84](https://github.com/hyperspell/python-sdk/issues/84)) ([1a6703c](https://github.com/hyperspell/python-sdk/commit/1a6703c8d4f3fe6dd8fc2111c2e3cfd0ade27377))
* **internal:** update client tests ([#50](https://github.com/hyperspell/python-sdk/issues/50)) ([f31aeaf](https://github.com/hyperspell/python-sdk/commit/f31aeaf9eaecb541fbc092b5997518efbc8a34e9))
* **internal:** update models test ([757a2dd](https://github.com/hyperspell/python-sdk/commit/757a2dd42bbadf9a94d28156dcffc3a4b6ad669b))
* **internal:** update pyright settings ([442555c](https://github.com/hyperspell/python-sdk/commit/442555c5f3430e17a42dd3363359810172858e1c))
* slight wording improvement in README ([#85](https://github.com/hyperspell/python-sdk/issues/85)) ([4597f85](https://github.com/hyperspell/python-sdk/commit/4597f85a79b9c4f8b3f1f05744c163aa0c837b73))
* update SDK settings ([#3](https://github.com/hyperspell/python-sdk/issues/3)) ([7d1e0bb](https://github.com/hyperspell/python-sdk/commit/7d1e0bb9ed0d49e2831255d3be1aa3a56503d77a))
* update SDK settings ([#74](https://github.com/hyperspell/python-sdk/issues/74)) ([2097566](https://github.com/hyperspell/python-sdk/commit/2097566f6ebaa15a5ab11191d3131f79aa2ae0fb))


### Documentation

* fix typos ([#13](https://github.com/hyperspell/python-sdk/issues/13)) ([84bf7b5](https://github.com/hyperspell/python-sdk/commit/84bf7b55e593e35b5b68ebac64909f21d3431938))
* **raw responses:** fix duplicate `the` ([#18](https://github.com/hyperspell/python-sdk/issues/18)) ([f99b1ca](https://github.com/hyperspell/python-sdk/commit/f99b1cadaa53c54cb27082d401fe376e0ce2f618))
* remove private imports from datetime snippets ([25eb634](https://github.com/hyperspell/python-sdk/commit/25eb634de104e2acb93104bcfdea1caf7344f627))
* revise readme docs about nested params ([#59](https://github.com/hyperspell/python-sdk/issues/59)) ([26a8c1e](https://github.com/hyperspell/python-sdk/commit/26a8c1e11b1d4286dbc627db63c064dc05e901f3))
* update URLs from stainlessapi.com to stainless.com ([#56](https://github.com/hyperspell/python-sdk/issues/56)) ([fb40ed8](https://github.com/hyperspell/python-sdk/commit/fb40ed87bdd21583e133307eb6c158d55e49b432))

## 0.9.0 (2025-04-10)

Full Changelog: [v0.8.2...v0.9.0](https://github.com/hyperspell/python-sdk/compare/v0.8.2...v0.9.0)

### Features

* **api:** api update ([cd17269](https://github.com/hyperspell/python-sdk/commit/cd17269808efe9af49416acb84ae6e1eaa4ef1c4))
* **api:** api update ([#77](https://github.com/hyperspell/python-sdk/issues/77)) ([5df0fc9](https://github.com/hyperspell/python-sdk/commit/5df0fc974b9990b3f00aec8e41822d418f0410ed))
* **api:** api update ([#79](https://github.com/hyperspell/python-sdk/issues/79)) ([4bbaa8b](https://github.com/hyperspell/python-sdk/commit/4bbaa8b5ee05ad8794f838cbba09244639598f1f))
* **api:** api update ([#81](https://github.com/hyperspell/python-sdk/issues/81)) ([816ced9](https://github.com/hyperspell/python-sdk/commit/816ced9a28f9f7d29488c54916f5166c53905a7b))
* **api:** api update ([#82](https://github.com/hyperspell/python-sdk/issues/82)) ([2a12261](https://github.com/hyperspell/python-sdk/commit/2a12261f52ef6c38863f54c46007b31cb888b45e))
* **api:** api update ([#83](https://github.com/hyperspell/python-sdk/issues/83)) ([e349d69](https://github.com/hyperspell/python-sdk/commit/e349d6919cf8bc3276b5da7e8aa3cfa8d4e23a67))
* **api:** api update ([#86](https://github.com/hyperspell/python-sdk/issues/86)) ([9cfa06b](https://github.com/hyperspell/python-sdk/commit/9cfa06b7c4bfab15f9b2e973b767dc02c9961877))


### Chores

* **internal:** expand CI branch coverage ([f1427b7](https://github.com/hyperspell/python-sdk/commit/f1427b73328af89415877c97b15d65ba86fa8ca4))
* **internal:** reduce CI branch coverage ([31cead5](https://github.com/hyperspell/python-sdk/commit/31cead5ba3df9609967a8f8f3f579b4c856fe649))
* **internal:** remove trailing character ([#80](https://github.com/hyperspell/python-sdk/issues/80)) ([f28f2b7](https://github.com/hyperspell/python-sdk/commit/f28f2b705e253c8cb73b67eab20ed9e5c52a8f5d))
* **internal:** slight transform perf improvement ([#84](https://github.com/hyperspell/python-sdk/issues/84)) ([1a6703c](https://github.com/hyperspell/python-sdk/commit/1a6703c8d4f3fe6dd8fc2111c2e3cfd0ade27377))
* slight wording improvement in README ([#85](https://github.com/hyperspell/python-sdk/issues/85)) ([4597f85](https://github.com/hyperspell/python-sdk/commit/4597f85a79b9c4f8b3f1f05744c163aa0c837b73))

## 0.8.2 (2025-03-26)

Full Changelog: [v0.8.1...v0.8.2](https://github.com/hyperspell/python-sdk/compare/v0.8.1...v0.8.2)

### Chores

* update SDK settings ([#74](https://github.com/hyperspell/python-sdk/issues/74)) ([2097566](https://github.com/hyperspell/python-sdk/commit/2097566f6ebaa15a5ab11191d3131f79aa2ae0fb))

## 0.8.1 (2025-03-25)

Full Changelog: [v0.5.3...v0.8.1](https://github.com/hyperspell/python-sdk/compare/v0.5.3...v0.8.1)

### Features

* **api:** api update ([78195d4](https://github.com/hyperspell/python-sdk/commit/78195d43929013ad14e6a079b2c63c2f90fb8377))
* **api:** api update ([#43](https://github.com/hyperspell/python-sdk/issues/43)) ([7c8ccc6](https://github.com/hyperspell/python-sdk/commit/7c8ccc641b0f75f99dbd7a2992c15e03a39143c9))
* **api:** api update ([#44](https://github.com/hyperspell/python-sdk/issues/44)) ([693304c](https://github.com/hyperspell/python-sdk/commit/693304cef80f58fbda0eb78368a2047830f77c50))
* **api:** api update ([#48](https://github.com/hyperspell/python-sdk/issues/48)) ([5a8674d](https://github.com/hyperspell/python-sdk/commit/5a8674d60ac79e1a0e2784bd63aafa2a59727357))
* **api:** api update ([#49](https://github.com/hyperspell/python-sdk/issues/49)) ([2c1476c](https://github.com/hyperspell/python-sdk/commit/2c1476cdb81b093fa1729b830822be93f3709527))
* **api:** api update ([#71](https://github.com/hyperspell/python-sdk/issues/71)) ([5e4a65e](https://github.com/hyperspell/python-sdk/commit/5e4a65e73caf6914b2aa6a847709fb6b490af0f1))
* **api:** update via SDK Studio ([#41](https://github.com/hyperspell/python-sdk/issues/41)) ([2aaad04](https://github.com/hyperspell/python-sdk/commit/2aaad04fee563cf795dd0dbbc9d15b2ee0bbac65))
* **api:** update via SDK Studio ([#67](https://github.com/hyperspell/python-sdk/issues/67)) ([52566fe](https://github.com/hyperspell/python-sdk/commit/52566fe8f84f526eb78a5949b68de52bf0414cd4))
* **api:** update via SDK Studio ([#68](https://github.com/hyperspell/python-sdk/issues/68)) ([3014583](https://github.com/hyperspell/python-sdk/commit/3014583dd53a24950206dc0b2ef7fb3be53fbf55))
* **api:** update via SDK Studio ([#69](https://github.com/hyperspell/python-sdk/issues/69)) ([01cdba5](https://github.com/hyperspell/python-sdk/commit/01cdba5e514ddefc6f0aba9bcff2c8954a3b10e5))
* **api:** update via SDK Studio ([#70](https://github.com/hyperspell/python-sdk/issues/70)) ([f5871a8](https://github.com/hyperspell/python-sdk/commit/f5871a8f77a3839d90ce67bedcf9336caafb227b))
* **api:** update via SDK Studio ([#72](https://github.com/hyperspell/python-sdk/issues/72)) ([3551d71](https://github.com/hyperspell/python-sdk/commit/3551d711e30daaeac10f0935194ba97a30eecf87))
* **client:** allow passing `NotGiven` for body ([#53](https://github.com/hyperspell/python-sdk/issues/53)) ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **client:** send `X-Stainless-Read-Timeout` header ([#45](https://github.com/hyperspell/python-sdk/issues/45)) ([314ac6f](https://github.com/hyperspell/python-sdk/commit/314ac6fbf8b7dbd4b3eb9d5293c4bdf6d21b4f36))


### Bug Fixes

* asyncify on non-asyncio runtimes ([#51](https://github.com/hyperspell/python-sdk/issues/51)) ([9a1d74d](https://github.com/hyperspell/python-sdk/commit/9a1d74da8a683ac1ae3474d298df21e097581a8d))
* **ci:** ensure pip is always available ([#65](https://github.com/hyperspell/python-sdk/issues/65)) ([fc830b0](https://github.com/hyperspell/python-sdk/commit/fc830b067dfc5e4408c772ac2275ad34aa503f97))
* **ci:** remove publishing patch ([#66](https://github.com/hyperspell/python-sdk/issues/66)) ([ca14208](https://github.com/hyperspell/python-sdk/commit/ca142083e62f5214f3b6fdd21a32c233a6d10ced))
* **client:** mark some request bodies as optional ([25f5f65](https://github.com/hyperspell/python-sdk/commit/25f5f65fe53fc426f3901ff5c0dabf77be7b0bdc))
* **types:** handle more discriminated union shapes ([#64](https://github.com/hyperspell/python-sdk/issues/64)) ([ea3ea28](https://github.com/hyperspell/python-sdk/commit/ea3ea28c4fca79d43f3372824dffdf5603d51f27))


### Chores

* **docs:** update client docstring ([#57](https://github.com/hyperspell/python-sdk/issues/57)) ([b93eac9](https://github.com/hyperspell/python-sdk/commit/b93eac92c1aa75241baaeba8979ec9603a538193))
* **internal:** bump rye to 0.44.0 ([#63](https://github.com/hyperspell/python-sdk/issues/63)) ([d0d34fc](https://github.com/hyperspell/python-sdk/commit/d0d34fc3b73469284cdc43bc61bbee53906acb1d))
* **internal:** codegen related update ([#52](https://github.com/hyperspell/python-sdk/issues/52)) ([1663641](https://github.com/hyperspell/python-sdk/commit/166364110507a27382de3ed086da802448a40420))
* **internal:** codegen related update ([#62](https://github.com/hyperspell/python-sdk/issues/62)) ([7d8fa4f](https://github.com/hyperspell/python-sdk/commit/7d8fa4f7989e99c2da10e7119d1f0410d38362db))
* **internal:** fix devcontainers setup ([#54](https://github.com/hyperspell/python-sdk/issues/54)) ([6b255f1](https://github.com/hyperspell/python-sdk/commit/6b255f161ecc1c9113b829327fe162167bf62b9b))
* **internal:** fix type traversing dictionary params ([#46](https://github.com/hyperspell/python-sdk/issues/46)) ([3b755e0](https://github.com/hyperspell/python-sdk/commit/3b755e0e12f723232830aa9398f61b8d55da5735))
* **internal:** minor type handling changes ([#47](https://github.com/hyperspell/python-sdk/issues/47)) ([de1503e](https://github.com/hyperspell/python-sdk/commit/de1503e4e5feabe6267187654467ced1f171ff57))
* **internal:** properly set __pydantic_private__ ([#55](https://github.com/hyperspell/python-sdk/issues/55)) ([412ccce](https://github.com/hyperspell/python-sdk/commit/412ccce91dc434650d88bc4c41f096c06132f1de))
* **internal:** remove extra empty newlines ([#61](https://github.com/hyperspell/python-sdk/issues/61)) ([b299f2e](https://github.com/hyperspell/python-sdk/commit/b299f2e25d537d7baf139579d11826e8fdbf655d))
* **internal:** remove unused http client options forwarding ([#58](https://github.com/hyperspell/python-sdk/issues/58)) ([da92b87](https://github.com/hyperspell/python-sdk/commit/da92b87db946431698648460c2fa71ffaffe3437))
* **internal:** update client tests ([#50](https://github.com/hyperspell/python-sdk/issues/50)) ([f31aeaf](https://github.com/hyperspell/python-sdk/commit/f31aeaf9eaecb541fbc092b5997518efbc8a34e9))


### Documentation

* revise readme docs about nested params ([#59](https://github.com/hyperspell/python-sdk/issues/59)) ([26a8c1e](https://github.com/hyperspell/python-sdk/commit/26a8c1e11b1d4286dbc627db63c064dc05e901f3))
* update URLs from stainlessapi.com to stainless.com ([#56](https://github.com/hyperspell/python-sdk/issues/56)) ([fb40ed8](https://github.com/hyperspell/python-sdk/commit/fb40ed87bdd21583e133307eb6c158d55e49b432))

## 0.5.3 (2025-02-04)

Full Changelog: [v1.0.0...v0.5.3](https://github.com/hyperspell/python-sdk/compare/v1.0.0...v0.5.3)

### Features

* **api:** api update ([#38](https://github.com/hyperspell/python-sdk/issues/38)) ([fd5a6d5](https://github.com/hyperspell/python-sdk/commit/fd5a6d5ba2b090d5cea1e70bf73d1674209c5907))
* **api:** api update ([#39](https://github.com/hyperspell/python-sdk/issues/39)) ([5aaf7cd](https://github.com/hyperspell/python-sdk/commit/5aaf7cd7208f1fef5edfeab8324ad6e977fae517))


### Chores

* **internal:** bummp ruff dependency ([#37](https://github.com/hyperspell/python-sdk/issues/37)) ([cef604a](https://github.com/hyperspell/python-sdk/commit/cef604afecf30df7c584bb70ce4fa61ace9d4742))
* **internal:** change default timeout to an int ([#35](https://github.com/hyperspell/python-sdk/issues/35)) ([f192b6f](https://github.com/hyperspell/python-sdk/commit/f192b6fdf340bfeb9e1853c752df0244841ab8c9))

## 1.0.0 (2025-02-04)

Full Changelog: [v0.1.0-alpha.1...v1.0.0](https://github.com/hyperspell/python-sdk/compare/v0.1.0-alpha.1...v1.0.0)

### Features

* **api:** api update ([#23](https://github.com/hyperspell/python-sdk/issues/23)) ([83dcd1d](https://github.com/hyperspell/python-sdk/commit/83dcd1d6bdd291e299330d532e974ab4e534c06d))
* **api:** api update ([#25](https://github.com/hyperspell/python-sdk/issues/25)) ([26170a5](https://github.com/hyperspell/python-sdk/commit/26170a5f86b9ed0dcbdd6cc01708a3a1a8a161b7))
* **api:** api update ([#28](https://github.com/hyperspell/python-sdk/issues/28)) ([72667ce](https://github.com/hyperspell/python-sdk/commit/72667cec5a0c172460551b0cce48aa667e88b99a))
* **api:** api update ([#29](https://github.com/hyperspell/python-sdk/issues/29)) ([e2312ba](https://github.com/hyperspell/python-sdk/commit/e2312bac25802f12f99f762d1e8e0cd7693dcf23))
* **api:** api update ([#30](https://github.com/hyperspell/python-sdk/issues/30)) ([08bae2f](https://github.com/hyperspell/python-sdk/commit/08bae2f240c913ffae8a6594877f4c78789f20f0))
* **api:** api update ([#31](https://github.com/hyperspell/python-sdk/issues/31)) ([a245e70](https://github.com/hyperspell/python-sdk/commit/a245e70aea6c76a5bdf45685ccb02edf271ab25b))
* **api:** update via SDK Studio ([#32](https://github.com/hyperspell/python-sdk/issues/32)) ([f8f7ad1](https://github.com/hyperspell/python-sdk/commit/f8f7ad136e37e084d5f3b8379d8e58bb04b85f2b))
* **api:** update via SDK Studio ([#33](https://github.com/hyperspell/python-sdk/issues/33)) ([d8aad38](https://github.com/hyperspell/python-sdk/commit/d8aad387e9a44b98f8fb1e2a0564e400203649d7))


### Chores

* **internal:** codegen related update ([#26](https://github.com/hyperspell/python-sdk/issues/26)) ([f6008b9](https://github.com/hyperspell/python-sdk/commit/f6008b93caaecd5b28e50c84dc908d820a0f222b))
* **internal:** minor formatting changes ([#27](https://github.com/hyperspell/python-sdk/issues/27)) ([b58a9f0](https://github.com/hyperspell/python-sdk/commit/b58a9f01edc5f9918f7a29fa81f1a8a1ae93bdfa))

## 0.1.0-alpha.1 (2025-01-21)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/hyperspell/python-sdk/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **api:** api update ([#12](https://github.com/hyperspell/python-sdk/issues/12)) ([14c9569](https://github.com/hyperspell/python-sdk/commit/14c95692111450a03e18b65b9fe84b76b1439741))
* **api:** api update ([#16](https://github.com/hyperspell/python-sdk/issues/16)) ([90ab745](https://github.com/hyperspell/python-sdk/commit/90ab745ece042d2a54a55fec5167db3bfa007618))
* **api:** api update ([#21](https://github.com/hyperspell/python-sdk/issues/21)) ([1b33d5e](https://github.com/hyperspell/python-sdk/commit/1b33d5e6cad083d1f6bfea037ddf79aeb558875b))
* **api:** api update ([#4](https://github.com/hyperspell/python-sdk/issues/4)) ([b44636b](https://github.com/hyperspell/python-sdk/commit/b44636b513256d732590494a99dc0eb1b688df13))
* **api:** api update ([#5](https://github.com/hyperspell/python-sdk/issues/5)) ([3fc9775](https://github.com/hyperspell/python-sdk/commit/3fc97752048e4259b2f0a71358231315fb11cf23))
* **api:** api update ([#7](https://github.com/hyperspell/python-sdk/issues/7)) ([4c43cb7](https://github.com/hyperspell/python-sdk/commit/4c43cb7d7dc11fbe157b9ebb513d753b7210eef4))
* **api:** api update ([#8](https://github.com/hyperspell/python-sdk/issues/8)) ([bbe535f](https://github.com/hyperspell/python-sdk/commit/bbe535f81cefa788f07e6298345bbc1b18b07684))


### Bug Fixes

* **client:** only call .close() when needed ([#11](https://github.com/hyperspell/python-sdk/issues/11)) ([23d4683](https://github.com/hyperspell/python-sdk/commit/23d468363e7b6aa433165ca42491a0351aad4274))
* correctly handle deserialising `cls` fields ([#15](https://github.com/hyperspell/python-sdk/issues/15)) ([dff71c6](https://github.com/hyperspell/python-sdk/commit/dff71c6d918c24b7dcfa0bea38ac7bbdb510b1af))
* **tests:** make test_get_platform less flaky ([#19](https://github.com/hyperspell/python-sdk/issues/19)) ([4886fcf](https://github.com/hyperspell/python-sdk/commit/4886fcf1b23834c6b009c888d68ce8a6b292a79e))


### Chores

* add missing isclass check ([#9](https://github.com/hyperspell/python-sdk/issues/9)) ([12f5ed5](https://github.com/hyperspell/python-sdk/commit/12f5ed56926e50d94b2462636ff8302c29fbf296))
* go live ([#1](https://github.com/hyperspell/python-sdk/issues/1)) ([84713c4](https://github.com/hyperspell/python-sdk/commit/84713c43b10cce946f27e116b7a621c3348a83be))
* **internal:** avoid pytest-asyncio deprecation warning ([#20](https://github.com/hyperspell/python-sdk/issues/20)) ([65f793b](https://github.com/hyperspell/python-sdk/commit/65f793b8d9da0222494949ea590e59123825d57e))
* **internal:** bump httpx dependency ([#10](https://github.com/hyperspell/python-sdk/issues/10)) ([988e555](https://github.com/hyperspell/python-sdk/commit/988e555345b3b193784e7b156d73d3d77eb7d715))
* **internal:** codegen related update ([#14](https://github.com/hyperspell/python-sdk/issues/14)) ([c7e587f](https://github.com/hyperspell/python-sdk/commit/c7e587fc23d72325d491a816a68a55e01d98735b))
* **internal:** codegen related update ([#17](https://github.com/hyperspell/python-sdk/issues/17)) ([9f186e4](https://github.com/hyperspell/python-sdk/commit/9f186e44b8f1c40853cc6f932995379bf187d2a9))
* **internal:** codegen related update ([#6](https://github.com/hyperspell/python-sdk/issues/6)) ([fa47f9e](https://github.com/hyperspell/python-sdk/commit/fa47f9eb5a5677f1a88d5b3034ec900a382f3e45))
* update SDK settings ([#3](https://github.com/hyperspell/python-sdk/issues/3)) ([7d1e0bb](https://github.com/hyperspell/python-sdk/commit/7d1e0bb9ed0d49e2831255d3be1aa3a56503d77a))


### Documentation

* fix typos ([#13](https://github.com/hyperspell/python-sdk/issues/13)) ([84bf7b5](https://github.com/hyperspell/python-sdk/commit/84bf7b55e593e35b5b68ebac64909f21d3431938))
* **raw responses:** fix duplicate `the` ([#18](https://github.com/hyperspell/python-sdk/issues/18)) ([f99b1ca](https://github.com/hyperspell/python-sdk/commit/f99b1cadaa53c54cb27082d401fe376e0ce2f618))
