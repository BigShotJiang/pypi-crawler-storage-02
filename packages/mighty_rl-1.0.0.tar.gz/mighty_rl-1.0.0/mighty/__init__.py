import datetime

name = "Mighty"
package_name = "mighty"
author = "Aditya Mohan, Theresa Eimer"
author_email = "a.mohan@ai.uni-hannover.de"
description = "No description given"
url = "https://www.automl.org"
project_urls = {
    "Documentation": "https://automl.github.io/Mighty/main",
    "Source Code": "https://github.com/automl/mighty",
}
copyright = f"Copyright {datetime.date.today().strftime('%Y')}, AutoML"
version = "0.0.1"
