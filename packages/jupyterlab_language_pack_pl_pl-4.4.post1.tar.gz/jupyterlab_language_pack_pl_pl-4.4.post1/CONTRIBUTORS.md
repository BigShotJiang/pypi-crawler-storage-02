# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Michał Krassowski ([@krassowski](https://crowdin.com/profile/krassowski))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
* Marcin Koculak ([@mkoculak](https://crowdin.com/profile/mkoculak))
* Kacper Łukawski ([@lukawskikacper](https://crowdin.com/profile/lukawskikacper))
* Frédéric Collonval ([@fcollonval](https://crowdin.com/profile/fcollonval))
* Karolina Krassowska ([@krassowska](https://crowdin.com/profile/krassowska))
* Sebastian Wołkowicz ([@wolkowicz.sebastian](https://crowdin.com/profile/wolkowicz.sebastian))
* m-aciek ([@m-aciek](https://crowdin.com/profile/m-aciek))
