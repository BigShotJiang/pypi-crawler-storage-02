# Jupyterlab Polish (Poland) Language Pack

Polish (Poland) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-pl-PL
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-pl-PL
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
