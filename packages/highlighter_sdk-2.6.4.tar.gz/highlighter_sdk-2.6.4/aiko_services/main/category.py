#!/usr/bin/env python3
#
# To Do
# ~~~~~
# - Categories
#   - Registrar, ProcessManager, LifeCycleManager, Pipeline
#   - Hyperspace, Workspace
