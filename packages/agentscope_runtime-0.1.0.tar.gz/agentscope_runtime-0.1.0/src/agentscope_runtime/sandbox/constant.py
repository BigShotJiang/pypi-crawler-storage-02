# -*- coding: utf-8 -*-
import os

IMAGE_TAG = os.getenv("RUNTIME_SANDBOX_IMAGE_TAG", "latest")
BROWSER_SESSION_ID = "123e4567-e89b-12d3-a456-426614174000"
