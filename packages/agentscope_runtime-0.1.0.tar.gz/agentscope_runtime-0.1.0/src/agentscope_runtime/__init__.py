# -*- coding: utf-8 -*-
from .version import __version__

__all__ = ["__version__"]
