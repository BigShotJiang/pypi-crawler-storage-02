#!/usr/bin/env python3
import sys

if __name__ == '__main__':
    print(' '.join(sys.argv[1:]))
