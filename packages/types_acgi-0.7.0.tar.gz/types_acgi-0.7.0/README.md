# types-acgi

:construction: This package is currently under development :construction:

ACGI will be here very soon

## Installation

```
pip install types-acgi==0.7.0
```

## Contact

For questions or suggestions, please contact [jack.burridge@mail.com](mailto:jack.burridge@mail.com).

## License

Copyright 2025 ACGI
