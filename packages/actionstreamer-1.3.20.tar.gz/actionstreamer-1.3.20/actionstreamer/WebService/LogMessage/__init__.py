from .LogMessage import create_log_message


__all__ = ['create_log_message']
