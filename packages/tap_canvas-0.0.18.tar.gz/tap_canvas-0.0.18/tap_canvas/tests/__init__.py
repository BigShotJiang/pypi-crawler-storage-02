"""Test suite for tap-canvas."""
