'use strict';

class AppInitializationExtension {
    execute() {

    }
}