/* global app */
'use strict';
EventMap = {};