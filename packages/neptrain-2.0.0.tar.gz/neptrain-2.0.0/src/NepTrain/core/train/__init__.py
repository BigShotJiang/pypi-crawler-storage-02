#!/usr/bin/env python 
# -*- coding: utf-8 -*-
# @Time    : 2024/10/29 20:57
# @Author  : 兵
# @email    : 1747193328@qq.com
from .run import train_nep