#!/usr/bin/env python 
# -*- coding: utf-8 -*-
# @Time    : 2024/10/29 15:27
# @Author  : 兵
# @email    : 1747193328@qq.com
from .run import run_gpumd