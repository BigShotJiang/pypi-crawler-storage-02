API Reference
=============

.. automodule:: rpds
   :members:
   :undoc-members:
   :imported-members:
   :special-members: __iter__, __getitem__, __len__, __rmatmul__
