"""Streamlit pages for the web UI."""
