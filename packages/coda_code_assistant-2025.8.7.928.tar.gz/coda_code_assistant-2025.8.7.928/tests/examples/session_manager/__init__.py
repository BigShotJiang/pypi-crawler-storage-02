# Session manager example
