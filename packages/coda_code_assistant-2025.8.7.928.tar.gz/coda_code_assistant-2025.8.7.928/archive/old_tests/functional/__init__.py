"""Functional tests for end-to-end workflows."""
