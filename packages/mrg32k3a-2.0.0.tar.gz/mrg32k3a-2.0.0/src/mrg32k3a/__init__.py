def hello() -> str:
    return "Hello from mrg32k3a!"
