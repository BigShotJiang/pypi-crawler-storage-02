The rationale
===================
