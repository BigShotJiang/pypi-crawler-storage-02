.. include:: intro.rst


---------

.. toctree::
   :maxdepth: 2

   what_for
   architecture
   build_pipeline
   configure_pipeline
   runtime/arroyo
   deployment
   rust
