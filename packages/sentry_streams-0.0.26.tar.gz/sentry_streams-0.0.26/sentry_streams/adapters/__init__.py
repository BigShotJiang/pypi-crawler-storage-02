from sentry_streams.adapters.loader import load_adapter

__all__ = ["load_adapter"]
