__all__ = ["get_logger"]

from docent._log_util.logger import get_logger
