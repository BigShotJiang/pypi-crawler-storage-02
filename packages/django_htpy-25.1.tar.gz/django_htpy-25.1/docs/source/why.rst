HTML in Python?
===============

Or why ``htpy``, and so ``django-htpy``.

