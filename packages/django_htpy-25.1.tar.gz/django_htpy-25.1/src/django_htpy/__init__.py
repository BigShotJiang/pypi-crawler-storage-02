"""
django-htpy: Django specific add-ons for the htpy library.
"""

from .renderable import dtl

__all__ = [
    "dtl",
]

__version__ = "25.1"
