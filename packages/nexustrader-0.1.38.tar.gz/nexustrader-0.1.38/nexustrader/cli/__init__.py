"""
NexusTrader CLI Interface

Real-time monitoring and control interface for NexusTrader strategies.
"""

__version__ = "0.1.0"
