if __name__ == "__main__":
    from .secheaders import main
    main()
