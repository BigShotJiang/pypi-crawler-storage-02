import setuptools  # pylint: disable=import-error

setuptools.setup()
