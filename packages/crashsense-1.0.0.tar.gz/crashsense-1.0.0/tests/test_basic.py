def test_smoke():
    import crashsense

    assert hasattr(crashsense, "__version__")
