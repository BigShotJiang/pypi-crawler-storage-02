<!--
SPDX-FileCopyrightText: 2025 Florian Obersteiner / KIT
SPDX-FileContributor: Florian Obersteiner <f.obersteiner@kit.edu>

SPDX-License-Identifier: CC-BY-SA-4.0
-->

`OM_20200304_591_CPT_MUC_V01_invalid0.txt` - last line only has independent variable
`OM_20200304_591_CPT_MUC_V01_invalid1.txt` - no data
`OM_20200304_591_CPT_MUC_V01_invalid2.txt` - invalid nlhead
`OM_20200304_591_CPT_MUC_V01_invalid3.txt` - invalid ffi
`OM_20200304_591_CPT_MUC_V01_invalid4.txt` - invalid rdate
`OM_20200304_591_CPT_MUC_V01_invalid5.txt` - invalid NV
`OM_20200304_591_CPT_MUC_V01_invalid6.txt` - invalid number of VMISS elements
`OM_20200304_591_CPT_MUC_V01_invalid7.txt` - invalid number of VNAME elements
`OM_20200304_591_CPT_MUC_V01_invalid8.txt` - invalid number of nlhead
