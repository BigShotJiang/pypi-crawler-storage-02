<!--
SPDX-FileCopyrightText: 2025 Florian Obersteiner / KIT
SPDX-FileContributor: Florian Obersteiner <f.obersteiner@kit.edu>

SPDX-License-Identifier: CC-BY-SA-4.0
-->

## Licenses

The work contained in this repository is licensed under different licenses;

- source code: `LGPL-3.0-or-later`
- configuration: `CC-BY-SA-4.0`
- anything else: `CC0-1.0` (public domain)

See also SPDX license headers and files.
