from llama_index.embeddings.nvidia.base import NVIDIAEmbedding

__all__ = ["NVIDIAEmbedding"]
