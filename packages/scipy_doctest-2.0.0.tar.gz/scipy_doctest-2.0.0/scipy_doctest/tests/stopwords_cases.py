__all__ = ['func8']

def func8():
    """Handle MPL stopwords.
    >>> import matplotlib.pyplot as plt
    >>> plt.show()

    >>> plt.xlim([1, 2])
    """
