# 可以在包项目执行的子模块
MODS = ['rynet', 'rytl', 'ryo', 'rydy', 'ryfu', 'rypa', 'ryku', 'rywin']
