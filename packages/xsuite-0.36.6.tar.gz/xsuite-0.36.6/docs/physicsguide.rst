=============
Physics guide
=============

The physics models implemented in Xsuite are being documented in the guide available at the following link:

https://xsuite.github.io/xsuite/docs/physics_manual/physics_man.pdf