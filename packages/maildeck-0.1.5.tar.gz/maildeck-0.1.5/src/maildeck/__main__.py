import maildeck
import sys

sys.exit(maildeck.main())
