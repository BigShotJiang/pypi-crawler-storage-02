# blockcg
Pure python implementations of block conjugate gradient methods.
