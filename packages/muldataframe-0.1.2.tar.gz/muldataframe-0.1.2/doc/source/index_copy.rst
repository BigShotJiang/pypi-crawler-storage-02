.. muldataframe documentation master file, created by
   sphinx-quickstart on Mon Jul 22 10:04:44 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

MulDataFrame documentation
^^^^^^^^^^^^^^^^^^^^^^^^^^^

"A multi-index is just a DataFrame, period."

.. image:: https://github.com/frlender/muldataframe/raw/main/figure.png
  :width: 400
  :alt: Alternative text

Useful links: `Source Repository <https://github.com/frlender/muldataframe>`_ | `Pandas <https://pandas.pydata.org/docs/index.html>`_


.. Check out the :doc:`usage` section for further information, including how to
.. :ref:`install <installation>` the project.



.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   getting_started.rst
   api/index.rst


.. Indices and tables
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`

.. note::

   This project is under active development.