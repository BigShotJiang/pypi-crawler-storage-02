{title}
===========================================

.. toctree::
   :maxdepth: 1
   :caption: Constructor:

{constructor}


.. toctree::
   :maxdepth: 1
   :caption: Attributes:

{attributes}


.. toctree::
   :maxdepth: 1
   :caption: Indexing:

{indexing}


.. toctree::
   :maxdepth: 1
   :caption: Methods:

{methods}
