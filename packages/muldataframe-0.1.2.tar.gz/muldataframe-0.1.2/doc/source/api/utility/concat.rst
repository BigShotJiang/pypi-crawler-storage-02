concat
===========

.. autofunction:: muldataframe.concat