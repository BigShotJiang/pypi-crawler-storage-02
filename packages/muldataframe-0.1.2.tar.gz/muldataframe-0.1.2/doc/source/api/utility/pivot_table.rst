pivot_table
===========================

.. autofunction:: muldataframe.pivot_table