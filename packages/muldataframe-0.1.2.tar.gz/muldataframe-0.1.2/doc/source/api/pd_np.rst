Pandas Methods
======================================

    **Upshot:**

    - All methods of pandas.DataFrame are available to MulDataFrame.
    - Some of them may not work.
    - Only those that are rewrittened for MulDataFrame are listed in the API.

Please check :doc:`Pandas methods <../user_guide/pandas_methods>` in user guide for detailed information.

