﻿muldataframe.MulSeries
======================

.. currentmodule:: muldataframe

.. autoclass:: MulSeries

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MulSeries.__init__
      ~MulSeries.call
      ~MulSeries.copy
      ~MulSeries.drop_duplicates
      ~MulSeries.equals
      ~MulSeries.groupby
      ~MulSeries.reset_index
   
   

   
   
   