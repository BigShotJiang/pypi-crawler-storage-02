MulGroupBy
=========================

The class for the object returned by the :doc:`MulSeries.groupby <../mulseries/groupby>` or the :doc:`MulDataFrame.groupby,<../muldataframe/groupby>` method.

.. toctree::
   :maxdepth: 1
   :caption: Constructor:

   mulgroupby

.. toctree::
   :maxdepth: 1
   :caption: Attributes:

   parent
   by
   index_agg
   indexType
   groupBy

.. toctree::
   :maxdepth: 1
   :caption: Methods:

   __iter__
   call

