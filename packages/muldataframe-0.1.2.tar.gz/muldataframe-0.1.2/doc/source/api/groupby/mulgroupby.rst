MulGroupBy
=============

.. autoclass:: muldataframe.cmm.MulGroupBy
   :members: None