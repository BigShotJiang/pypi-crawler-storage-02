MulGroupBy.indexType
========================

.. autoattribute:: muldataframe.cmm.MulGroupBy.indexType
