MulGroupBy.call
===================

.. automethod:: muldataframe.cmm.MulGroupBy.call
