MulGroupBy.groupBy
======================

.. autoattribute:: muldataframe.cmm.MulGroupBy.groupBy
