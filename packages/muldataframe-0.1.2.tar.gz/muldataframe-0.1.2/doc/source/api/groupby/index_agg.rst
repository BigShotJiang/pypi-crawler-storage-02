MulGroupBy.index_agg
========================

.. autoattribute:: muldataframe.cmm.MulGroupBy.index_agg
