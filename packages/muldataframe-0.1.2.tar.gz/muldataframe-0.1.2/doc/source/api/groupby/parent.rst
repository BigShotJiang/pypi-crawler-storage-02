MulGroupBy.parent
=====================

.. autoattribute:: muldataframe.cmm.MulGroupBy.parent
