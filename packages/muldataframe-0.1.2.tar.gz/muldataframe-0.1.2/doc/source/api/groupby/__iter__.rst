MulGroupBy.__iter__
=======================

.. automethod:: muldataframe.cmm.MulGroupBy.__iter__
