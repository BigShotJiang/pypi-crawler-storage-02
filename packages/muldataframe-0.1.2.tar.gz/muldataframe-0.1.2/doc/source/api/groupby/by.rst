MulGroupBy.by
=================

.. autoattribute:: muldataframe.cmm.MulGroupBy.by
