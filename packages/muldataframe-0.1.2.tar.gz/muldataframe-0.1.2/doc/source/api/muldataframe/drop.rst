MulDataFrame.drop
===================

.. automethod:: muldataframe.MulDataFrame.drop
