MulDataFrame.columns
======================

.. autoattribute:: muldataframe.MulDataFrame.columns
