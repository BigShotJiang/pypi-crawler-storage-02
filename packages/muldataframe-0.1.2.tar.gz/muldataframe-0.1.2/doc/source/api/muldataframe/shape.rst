MulDataFrame.shape
====================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.shape

      Same as the shape of the values dataframe.
      