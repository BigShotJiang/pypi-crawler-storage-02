MulDataFrame.__iter__
=======================

.. automethod:: muldataframe.MulDataFrame.__iter__
