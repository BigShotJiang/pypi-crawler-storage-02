MulDataFrame.query
====================

.. automethod:: muldataframe.MulDataFrame.query
