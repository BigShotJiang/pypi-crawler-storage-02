MulDataFrame.primary_index
============================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.primary_index

      The primary index.
      
      Shorthand for ``MulDataFrame.index.index``.
      