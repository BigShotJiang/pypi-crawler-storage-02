MulDataFrame.pindex
=====================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.pindex

      Alias for :doc:`MulDataFrame.primary_index <primary_index>`.
      