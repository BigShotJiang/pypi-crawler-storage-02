MulDataFrame.equals
=====================

.. automethod:: muldataframe.MulDataFrame.equals
