MulDataFrame.copy
===================

.. automethod:: muldataframe.MulDataFrame.copy
