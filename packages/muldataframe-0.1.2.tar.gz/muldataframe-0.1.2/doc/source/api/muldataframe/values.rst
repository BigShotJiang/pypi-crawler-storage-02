MulDataFrame.values
=====================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.values

      The values of the values dataframe.
    
      It is not a copy.
      