MulDataFrame.mcolumns
=======================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.mcolumns

      Alias for :doc:`MulDataFrame.columns <columns>`.
      