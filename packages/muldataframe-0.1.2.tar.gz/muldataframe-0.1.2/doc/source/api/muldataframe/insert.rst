MulDataFrame.insert
=====================

.. automethod:: muldataframe.MulDataFrame.insert
