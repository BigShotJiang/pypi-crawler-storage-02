MulDataFrame.transpose
========================

.. automethod:: muldataframe.MulDataFrame.transpose
