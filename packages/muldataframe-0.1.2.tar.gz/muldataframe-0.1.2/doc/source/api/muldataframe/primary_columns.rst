MulDataFrame.primary_columns
==============================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.primary_columns

      The primary columns.
      
      Shorthand for ``MulDataFrame.columns.index``.
      