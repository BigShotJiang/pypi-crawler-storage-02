MulDataFrame.melt
===================

.. automethod:: muldataframe.MulDataFrame.melt
