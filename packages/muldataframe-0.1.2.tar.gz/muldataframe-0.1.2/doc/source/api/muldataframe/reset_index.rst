MulDataFrame.reset_index
==========================

.. automethod:: muldataframe.MulDataFrame.reset_index
