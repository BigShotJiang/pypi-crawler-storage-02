MulDataFrame.index
====================

.. autoattribute:: muldataframe.MulDataFrame.index
