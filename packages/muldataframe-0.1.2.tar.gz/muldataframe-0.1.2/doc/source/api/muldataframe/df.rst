MulDataFrame.df
=================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.df

      A deep copy of the values dataframe.
      