MulDataFrame.iterrows
=======================

.. automethod:: muldataframe.MulDataFrame.iterrows
