MulDataFrame.call
===================

.. automethod:: muldataframe.MulDataFrame.call
