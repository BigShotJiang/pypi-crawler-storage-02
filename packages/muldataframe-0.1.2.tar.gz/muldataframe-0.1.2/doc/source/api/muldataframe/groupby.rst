MulDataFrame.groupby
======================

.. automethod:: muldataframe.MulDataFrame.groupby
