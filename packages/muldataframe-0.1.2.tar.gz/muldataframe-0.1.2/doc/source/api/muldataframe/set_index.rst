MulDataFrame.set_index
========================

.. automethod:: muldataframe.MulDataFrame.set_index
