MulDataFrame.mcols
====================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.mcols

      Alias for :doc:`MulDataFrame.columns <columns>`.
      