MulDataFrame.sort_values
==========================

.. automethod:: muldataframe.MulDataFrame.sort_values
