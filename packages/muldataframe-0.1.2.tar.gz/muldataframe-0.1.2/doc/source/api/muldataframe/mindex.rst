MulDataFrame.mindex
=====================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.mindex

      Alias for :doc:`MulDataFrame.index <index>`.
      