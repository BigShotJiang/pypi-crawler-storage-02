MulDataFrame.pcolumns
=======================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.pcolumns

      Alias for :doc:`MulDataFrame.primary_columns <primary_columns>`.
      