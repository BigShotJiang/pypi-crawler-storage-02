MulDataFrame.pcols
====================

.. currentmodule:: muldataframe

.. attribute:: MulDataFrame.pcols

      Alias for :doc:`MulDataFrame.primary_columns <primary_columns>`.
      