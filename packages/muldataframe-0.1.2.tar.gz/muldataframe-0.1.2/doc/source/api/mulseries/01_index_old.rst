MulSeries.index
================

.. attribute:: muldataframe.MulSeries.values