MulSeries.__iter__
=======================

.. automethod:: muldataframe.MulSeries.__iter__
