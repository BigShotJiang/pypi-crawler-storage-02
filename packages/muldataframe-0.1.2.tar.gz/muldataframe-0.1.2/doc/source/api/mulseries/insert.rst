MulSeries.insert
=====================

.. automethod:: muldataframe.MulSeries.insert
