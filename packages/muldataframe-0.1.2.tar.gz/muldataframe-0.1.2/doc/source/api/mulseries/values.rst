MulSeries.values
=====================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.values

      The values of the values series. 
      
      It is not a copy.
      