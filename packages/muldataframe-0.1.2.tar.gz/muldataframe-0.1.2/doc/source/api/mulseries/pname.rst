MulSeries.pname
====================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.pname

      Alias for :doc:`MulSeries.primary_name <primary_name>`.
      