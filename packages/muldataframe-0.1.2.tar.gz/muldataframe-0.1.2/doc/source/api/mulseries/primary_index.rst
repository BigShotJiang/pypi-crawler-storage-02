MulSeries.primary_index
============================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.primary_index

      The primary index.
      
      Shorthand for ``MulSeries.index.index``.
      