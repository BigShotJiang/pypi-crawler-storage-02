MulSeries
=========

.. autoclass:: muldataframe.MulSeries
   :members: None