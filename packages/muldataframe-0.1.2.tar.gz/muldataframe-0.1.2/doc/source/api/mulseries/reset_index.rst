MulSeries.reset_index
==========================

.. automethod:: muldataframe.MulSeries.reset_index
