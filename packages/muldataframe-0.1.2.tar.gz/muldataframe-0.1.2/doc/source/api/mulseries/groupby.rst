MulSeries.groupby
======================

.. automethod:: muldataframe.MulSeries.groupby
