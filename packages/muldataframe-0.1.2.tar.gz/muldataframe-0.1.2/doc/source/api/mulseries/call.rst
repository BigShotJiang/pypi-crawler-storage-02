MulSeries.call
===================

.. automethod:: muldataframe.MulSeries.call
