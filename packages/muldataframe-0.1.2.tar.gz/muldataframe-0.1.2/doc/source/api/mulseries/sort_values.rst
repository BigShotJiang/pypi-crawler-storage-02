MulSeries.sort_values
==========================

.. automethod:: muldataframe.MulSeries.sort_values
