MulSeries.mname
====================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.mname

      Alias for :doc:`MulSeries.name <name>`.
      