MulSeries.primary_name
===========================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.primary_name

      The primary name.
      
      Shorthand for ``MulSeries.name.name``.
      