MulSeries.pindex
=====================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.pindex

      Alias for :doc:`MulSeries.primary_index <primary_index>`.
      