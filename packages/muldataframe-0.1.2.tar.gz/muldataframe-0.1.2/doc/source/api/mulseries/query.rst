MulSeries.query
====================

.. automethod:: muldataframe.MulSeries.query
