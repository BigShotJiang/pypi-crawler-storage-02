MulSeries.mindex
=====================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.mindex

      Alias for :doc:`MulSeries.index <index>`.
      