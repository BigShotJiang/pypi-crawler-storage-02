MulSeries.copy
===================

.. automethod:: muldataframe.MulSeries.copy
