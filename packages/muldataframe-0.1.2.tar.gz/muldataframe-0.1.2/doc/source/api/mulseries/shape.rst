MulSeries.shape
====================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.shape

      Same as the shape of the values series.
      