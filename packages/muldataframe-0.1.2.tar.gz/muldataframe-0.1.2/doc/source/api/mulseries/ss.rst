MulSeries.ss
=================

.. currentmodule:: muldataframe

.. attribute:: MulSeries.ss

      A deep copy of the values series.
      