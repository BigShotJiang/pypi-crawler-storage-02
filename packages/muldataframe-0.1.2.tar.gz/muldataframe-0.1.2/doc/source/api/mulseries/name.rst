MulSeries.name
===================

.. autoattribute:: muldataframe.MulSeries.name
