MulSeries.index
====================

.. autoattribute:: muldataframe.MulSeries.index
