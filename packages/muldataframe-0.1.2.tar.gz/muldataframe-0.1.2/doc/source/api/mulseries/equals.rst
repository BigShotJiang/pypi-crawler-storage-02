MulSeries.equals
=====================

.. automethod:: muldataframe.MulSeries.equals
