MulSeries.drop
===================

.. automethod:: muldataframe.MulSeries.drop
