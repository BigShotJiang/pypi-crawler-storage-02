API reference
================


.. toctree::
   :maxdepth: 2

   pd_np.rst
   mulseries/indices.rst
   muldataframe/indices.rst
   groupby/indices.rst
   utility/indices.rst


