Installation
===============

Install from pypi:

.. code-block:: shell

    pip install muldataframe


Install the latest dev version:

.. code-block:: shell

    pip install git+https://github.com/frlender/muldataframe.git



