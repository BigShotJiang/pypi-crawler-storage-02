# Documentation for MulDataFrame

Build doc:

```shell
bash build.sh
```

[Sphinx](https://www.sphinx-doc.org/en/master/) needs to be installed before the above command can run.

Most of the documentation in the api folder is automatically extracted from the source code.

