#
# Copyright (c) 2021 Airbyte, Inc., all rights reserved.
#


from .source import SourceAzureTable

__all__ = ["SourceAzureTable"]
