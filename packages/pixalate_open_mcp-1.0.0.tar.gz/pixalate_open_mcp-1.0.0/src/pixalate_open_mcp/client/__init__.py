from pixalate_open_mcp.client.app import main

__all__ = ["main"]
