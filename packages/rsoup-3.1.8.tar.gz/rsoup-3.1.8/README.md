# RSoup ![PyPI](https://img.shields.io/pypi/v/rsoup)

A very fast library for web scraper that handles text correctly
