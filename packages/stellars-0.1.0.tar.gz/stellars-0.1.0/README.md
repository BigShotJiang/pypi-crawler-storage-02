# stella-rs
High-performance phylogenetic analysis extensions for Cassiopeia lineage tracing, implemented in Rust with Python bindings.
