"""Tests for batch processing package."""
