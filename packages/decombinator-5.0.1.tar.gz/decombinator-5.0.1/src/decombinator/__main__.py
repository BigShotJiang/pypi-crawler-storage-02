from .pipeline import main

main()
