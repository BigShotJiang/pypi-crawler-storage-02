.. currentmodule:: osyris

*************
API Reference
*************

Core
====

.. autosummary::
   :toctree: generated

   Array
   Datagroup
   Dataset
   units
   Vector

Plotting
========

.. autosummary::
   :toctree: generated

   hist1d
   hist2d
   map
   plot
   scatter
