# SPDX-License-Identifier: BSD-3-Clause

from pint import Quantity, Unit, UnitRegistry, compat

from .. import config


class Units:
    def __init__(self):
        self._ureg = UnitRegistry(system="cgs")
        config.configure_constants(self._ureg)

    def __call__(self, arg):
        if isinstance(arg, Quantity):
            raise TypeError("Cannot create unit from a Quantity. Use `.units` instead.")
        if isinstance(arg, Unit):
            return arg
        return self._ureg(arg).units

    def define(self, *args, **kwargs):
        self._ureg.define(*args, **kwargs)


units = Units()

# Add compatibility for upcasting
compat.upcast_type_map["osyris.core.array.Array"] = None
compat.upcast_type_map["osyris.core.vector.Vector"] = None
