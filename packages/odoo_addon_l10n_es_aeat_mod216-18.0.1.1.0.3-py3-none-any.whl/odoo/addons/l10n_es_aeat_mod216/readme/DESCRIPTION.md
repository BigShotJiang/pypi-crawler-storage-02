Modelo 216 de la AEAT. IRNR. Impuesto sobre la Renta de no Residentes.
Rentas obtenidas sin mediación de establecimiento permanente.
Retenciones e ingresos a cuenta.
