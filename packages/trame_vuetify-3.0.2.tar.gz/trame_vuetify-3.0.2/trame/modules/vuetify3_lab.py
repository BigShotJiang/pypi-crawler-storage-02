from trame_vuetify.module.vue3_lab import *  # noqa F403
