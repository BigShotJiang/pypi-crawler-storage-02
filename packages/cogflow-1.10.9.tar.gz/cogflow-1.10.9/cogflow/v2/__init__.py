"""
KFP v2
"""

from kfp import v2 as kfp_v2

globals().update(vars(kfp_v2))
