"""
This package contains all the RETURNN TF layer implementations.
"""
