from snaptrade_client.paths.accounts_account_id_orders.get import ApiForget


class AccountsAccountIdOrders(
    ApiForget,
):
    pass
