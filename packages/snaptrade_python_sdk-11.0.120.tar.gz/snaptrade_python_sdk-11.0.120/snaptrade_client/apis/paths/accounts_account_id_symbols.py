from snaptrade_client.paths.accounts_account_id_symbols.post import ApiForpost


class AccountsAccountIdSymbols(
    ApiForpost,
):
    pass
