from snaptrade_client.paths.accounts_account_id_trading_cancel.post import ApiForpost


class AccountsAccountIdTradingCancel(
    ApiForpost,
):
    pass
