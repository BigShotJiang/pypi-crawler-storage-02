from snaptrade_client.paths.accounts_account_id_option_strategy_option_strategy_id_execute.post import ApiForpost


class AccountsAccountIdOptionStrategyOptionStrategyIdExecute(
    ApiForpost,
):
    pass
