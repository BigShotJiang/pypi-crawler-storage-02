from snaptrade_client.paths.accounts_account_id_trading_crypto.post import ApiForpost


class AccountsAccountIdTradingCrypto(
    ApiForpost,
):
    pass
