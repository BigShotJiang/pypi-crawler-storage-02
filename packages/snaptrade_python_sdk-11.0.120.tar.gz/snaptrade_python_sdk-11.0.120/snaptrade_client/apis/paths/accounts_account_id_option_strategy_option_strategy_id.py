from snaptrade_client.paths.accounts_account_id_option_strategy_option_strategy_id.get import ApiForget


class AccountsAccountIdOptionStrategyOptionStrategyId(
    ApiForget,
):
    pass
