from snaptrade_client.paths.snap_trade_delete_user.delete import ApiFordelete


class SnapTradeDeleteUser(
    ApiFordelete,
):
    pass
