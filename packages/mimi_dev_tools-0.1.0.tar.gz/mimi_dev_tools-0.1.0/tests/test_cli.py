"""
Tests for the CLI module.
"""

import pytest
from click.testing import CliRunner
from mimi_dev_tools.cli import main


class TestCLI:
    """Test cases for the CLI interface."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.runner = CliRunner()
    
    def test_info_command(self):
        """Test the info command."""
        result = self.runner.invoke(main, ["info"])
        assert result.exit_code == 0
        assert "Mimi Dev Tools" in result.output
    
    def test_help_command(self):
        """Test the help command."""
        result = self.runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Usage:" in result.output
    
    def test_version_command(self):
        """Test the version command."""
        result = self.runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output
    
    def test_new_project_help(self):
        """Test new-project help."""
        result = self.runner.invoke(main, ["new-project", "--help"])
        assert result.exit_code == 0
        assert "Create a new Mimi project" in result.output
    
    def test_generate_help(self):
        """Test generate help."""
        result = self.runner.invoke(main, ["generate", "--help"])
        assert result.exit_code == 0
        assert "Generate code components" in result.output
    
    def test_utils_help(self):
        """Test utils help."""
        result = self.runner.invoke(main, ["utils", "--help"])
        assert result.exit_code == 0
        assert "Development utilities" in result.output 