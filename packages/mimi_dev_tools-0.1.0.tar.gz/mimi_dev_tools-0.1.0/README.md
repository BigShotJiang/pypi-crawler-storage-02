# Mimi Dev Tools

Development tools for the Mimi framework to streamline your workflow and improve productivity.

## Features

- **Project Scaffolding**: Quickly create new Mimi projects with best practices
- **Code Generation**: Generate boilerplate code for common patterns
- **Development Utilities**: Tools to help with testing, documentation, and deployment
- **CLI Interface**: Easy-to-use command-line interface for all tools

## Installation

### From PyPI (recommended)

```bash
pip install mimi-dev-tools
```

### From source

```bash
git clone https://github.com/yourusername/mimi-dev-tools.git
cd mimi-dev-tools
pip install -e .
```

## Quick Start

After installation, you can use the `mimi-dev` command:

```bash
# Create a new Mimi project
mimi-dev new-project my-awesome-project

# Generate a new component
mimi-dev generate component MyComponent

# Run development utilities
mimi-dev utils validate-config
```

## Usage

### Creating a New Project

```bash
mimi-dev new-project my-project-name
```

This will create a new Mimi project with the following structure:

```
my-project-name/
├── src/
│   └── my_project_name/
│       ├── __init__.py
│       ├── components/
│       ├── models/
│       └── utils/
├── tests/
├── docs/
├── pyproject.toml
├── README.md
└── .gitignore
```

### Generating Components

```bash
mimi-dev generate component MyComponent
```

This generates a new component with proper structure and tests.

### Development Utilities

```bash
# Validate configuration
mimi-dev utils validate-config

# Check code quality
mimi-dev utils lint

# Run tests
mimi-dev utils test
```

## Development

### Setting up the development environment

```bash
git clone https://github.com/yourusername/mimi-dev-tools.git
cd mimi-dev-tools
pip install -e ".[dev]"
```

### Running tests

```bash
pytest
```

### Code formatting

```bash
black .
isort .
```

### Type checking

```bash
mypy mimi_dev_tools
```

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- **Documentation**: [https://mimi-dev-tools.readthedocs.io/](https://mimi-dev-tools.readthedocs.io/)
- **Issues**: [https://github.com/yourusername/mimi-dev-tools/issues](https://github.com/yourusername/mimi-dev-tools/issues)
- **Discussions**: [https://github.com/yourusername/mimi-dev-tools/discussions](https://github.com/yourusername/mimi-dev-tools/discussions)

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a list of changes and version history. 