"""
Code generators for Mimi Dev Tools.
"""

import os
import shutil
from pathlib import Path
from typing import Dict, Any, Optional
from jinja2 import Environment, FileSystemLoader, Template


class ProjectGenerator:
    """Generate new Mimi projects with templates."""
    
    def __init__(self) -> None:
        self.templates_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_dir)),
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True
        )
    
    def create_project(
        self,
        name: str,
        template: str = "basic",
        path: str = ".",
        force: bool = False
    ) -> None:
        """Create a new project with the specified template."""
        project_path = Path(path) / name
        
        if project_path.exists() and not force:
            raise FileExistsError(f"Project directory '{project_path}' already exists. Use --force to overwrite.")
        
        if project_path.exists() and force:
            shutil.rmtree(project_path)
        
        project_path.mkdir(parents=True, exist_ok=True)
        
        # Get template context
        context = self._get_project_context(name, template)
        
        # Create project structure
        self._create_project_structure(project_path, template, context)
        
        # Create files from templates
        self._create_project_files(project_path, template, context)
    
    def _get_project_context(self, name: str, template: str) -> Dict[str, Any]:
        """Get context data for project generation."""
        return {
            "project_name": name,
            "package_name": name.replace("-", "_").replace(" ", "_").lower(),
            "description": f"A Mimi project: {name}",
            "author": "Your Name",
            "email": "your.email@example.com",
            "version": "0.1.0",
            "python_version": ">=3.8",
        }
    
    def _create_project_structure(self, project_path: Path, template: str, context: Dict[str, Any]) -> None:
        """Create the basic project directory structure."""
        # Create main directories
        (project_path / "src" / context["package_name"]).mkdir(parents=True, exist_ok=True)
        (project_path / "tests").mkdir(exist_ok=True)
        (project_path / "docs").mkdir(exist_ok=True)
        (project_path / "src" / context["package_name"] / "components").mkdir(exist_ok=True)
        (project_path / "src" / context["package_name"] / "models").mkdir(exist_ok=True)
        (project_path / "src" / context["package_name"] / "utils").mkdir(exist_ok=True)
    
    def _create_project_files(self, project_path: Path, template: str, context: Dict[str, Any]) -> None:
        """Create project files from templates."""
        # Create __init__.py files
        self._create_file_from_template(
            project_path / "src" / context["package_name"] / "__init__.py",
            "package_init.py.j2",
            context
        )
        
        # Create pyproject.toml
        self._create_file_from_template(
            project_path / "pyproject.toml",
            "pyproject.toml.j2",
            context
        )
        
        # Create README.md
        self._create_file_from_template(
            project_path / "README.md",
            "README.md.j2",
            context
        )
        
        # Create .gitignore
        self._create_file_from_template(
            project_path / ".gitignore",
            "gitignore.j2",
            context
        )
    
    def _create_file_from_template(
        self,
        file_path: Path,
        template_name: str,
        context: Dict[str, Any]
    ) -> None:
        """Create a file from a Jinja2 template."""
        try:
            template = self.env.get_template(template_name)
            content = template.render(**context)
            file_path.write_text(content)
        except Exception as e:
            # If template doesn't exist, create a basic file
            if "pyproject.toml" in str(file_path):
                self._create_basic_pyproject_toml(file_path, context)
            elif "README.md" in str(file_path):
                self._create_basic_readme(file_path, context)
            elif "__init__.py" in str(file_path):
                self._create_basic_init(file_path, context)
            elif ".gitignore" in str(file_path):
                self._create_basic_gitignore(file_path)
    
    def _create_basic_pyproject_toml(self, file_path: Path, context: Dict[str, Any]) -> None:
        """Create a basic pyproject.toml file."""
        content = f'''[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{context["package_name"]}"
version = "{context["version"]}"
description = "{context["description"]}"
readme = "README.md"
license = {{file = "LICENSE"}}
authors = [
    {{name = "{context["author"]}", email = "{context["email"]}"}},
]
requires-python = "{context["python_version"]}"
dependencies = [
    "mimi",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "black>=22.0.0",
    "isort>=5.0.0",
    "flake8>=5.0.0",
]

[tool.hatch.build.targets.wheel]
packages = ["src/{context["package_name"]}"]
'''
        file_path.write_text(content)
    
    def _create_basic_readme(self, file_path: Path, context: Dict[str, Any]) -> None:
        """Create a basic README.md file."""
        content = f'''# {context["project_name"]}

{context["description"]}

## Installation

```bash
pip install -e .
```

## Usage

```python
from {context["package_name"]} import main

# Your code here
```

## Development

```bash
pip install -e ".[dev]"
pytest
```
'''
        file_path.write_text(content)
    
    def _create_basic_init(self, file_path: Path, context: Dict[str, Any]) -> None:
        """Create a basic __init__.py file."""
        content = f'''"""
{context["project_name"]} - {context["description"]}
"""

__version__ = "{context["version"]}"
__author__ = "{context["author"]}"
__email__ = "{context["email"]}"
'''
        file_path.write_text(content)
    
    def _create_basic_gitignore(self, file_path: Path) -> None:
        """Create a basic .gitignore file."""
        content = '''# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# C extensions
*.so

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# PyInstaller
*.manifest
*.spec

# Installer logs
pip-log.txt
pip-delete-this-directory.txt

# Unit test / coverage reports
htmlcov/
.tox/
.nox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.py,cover
.hypothesis/
.pytest_cache/

# Translations
*.mo
*.pot

# Django stuff:
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal

# Flask stuff:
instance/
.webassets-cache

# Scrapy stuff:
.scrapy

# Sphinx documentation
docs/_build/

# PyBuilder
target/

# Jupyter Notebook
.ipynb_checkpoints

# IPython
profile_default/
ipython_config.py

# pyenv
.python-version

# pipenv
Pipfile.lock

# PEP 582
__pypackages__/

# Celery stuff
celerybeat-schedule
celerybeat.pid

# SageMath parsed files
*.sage.py

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Spyder project settings
.spyderproject
.spyproject

# Rope project settings
.ropeproject

# mkdocs documentation
/site

# mypy
.mypy_cache/
.dmypy.json
dmypy.json

# Pyre type checker
.pyre/
'''
        file_path.write_text(content)


class ComponentGenerator:
    """Generate new components for Mimi projects."""
    
    def __init__(self) -> None:
        self.templates_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_dir)),
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True
        )
    
    def create_component(
        self,
        name: str,
        component_type: str = "basic",
        path: str = "."
    ) -> None:
        """Create a new component with the specified type."""
        component_path = Path(path) / "components" / name.lower()
        component_path.mkdir(parents=True, exist_ok=True)
        
        context = self._get_component_context(name, component_type)
        
        # Create component files
        self._create_component_files(component_path, component_type, context)
    
    def _get_component_context(self, name: str, component_type: str) -> Dict[str, Any]:
        """Get context data for component generation."""
        return {
            "component_name": name,
            "class_name": "".join(word.capitalize() for word in name.split("_")),
            "component_type": component_type,
            "description": f"A {component_type} component: {name}",
        }
    
    def _create_component_files(self, component_path: Path, component_type: str, context: Dict[str, Any]) -> None:
        """Create component files from templates."""
        # Create __init__.py
        self._create_file_from_template(
            component_path / "__init__.py",
            "component_init.py.j2",
            context
        )
        
        # Create main component file
        self._create_file_from_template(
            component_path / f"{context['component_name'].lower()}.py",
            "component.py.j2",
            context
        )
        
        # Create test file
        test_path = Path("tests") / "components" / f"test_{context['component_name'].lower()}.py"
        test_path.parent.mkdir(parents=True, exist_ok=True)
        self._create_file_from_template(
            test_path,
            "component_test.py.j2",
            context
        )
    
    def _create_file_from_template(
        self,
        file_path: Path,
        template_name: str,
        context: Dict[str, Any]
    ) -> None:
        """Create a file from a Jinja2 template."""
        try:
            template = self.env.get_template(template_name)
            content = template.render(**context)
            file_path.write_text(content)
        except Exception as e:
            # If template doesn't exist, create a basic file
            if "component.py" in template_name:
                self._create_basic_component(file_path, context)
            elif "component_init.py" in template_name:
                self._create_basic_component_init(file_path, context)
            elif "component_test.py" in template_name:
                self._create_basic_component_test(file_path, context)
    
    def _create_basic_component(self, file_path: Path, context: Dict[str, Any]) -> None:
        """Create a basic component file."""
        content = f'''"""
{context["component_name"]} - {context["description"]}
"""

from typing import Any, Dict, Optional


class {context["class_name"]}:
    """
    {context["description"]}
    """
    
    def __init__(self, **kwargs):
        """Initialize the component."""
        self.config = kwargs
    
    def setup(self) -> None:
        """Setup the component."""
        pass
    
    def run(self) -> None:
        """Run the component."""
        pass
    
    def cleanup(self) -> None:
        """Cleanup the component."""
        pass
'''
        file_path.write_text(content)
    
    def _create_basic_component_init(self, file_path: Path, context: Dict[str, Any]) -> None:
        """Create a basic component __init__.py file."""
        content = f'''"""
{context["component_name"]} component.
"""

from .{context["component_name"].lower()} import {context["class_name"]}

__all__ = ["{context["class_name"]}"]
'''
        file_path.write_text(content)
    
    def _create_basic_component_test(self, file_path: Path, context: Dict[str, Any]) -> None:
        """Create a basic component test file."""
        content = f'''"""
Tests for {context["component_name"]} component.
"""

import pytest
from components.{context["component_name"].lower()}.{context["component_name"].lower()} import {context["class_name"]}


class Test{context["class_name"]}:
    """Test cases for {context["class_name"]} component."""
    
    def test_init(self):
        """Test component initialization."""
        component = {context["class_name"]}()
        assert component is not None
    
    def test_setup(self):
        """Test component setup."""
        component = {context["class_name"]}()
        component.setup()
        # Add assertions as needed
    
    def test_run(self):
        """Test component run."""
        component = {context["class_name"]}()
        component.run()
        # Add assertions as needed
    
    def test_cleanup(self):
        """Test component cleanup."""
        component = {context["class_name"]}()
        component.cleanup()
        # Add assertions as needed
'''
        file_path.write_text(content) 