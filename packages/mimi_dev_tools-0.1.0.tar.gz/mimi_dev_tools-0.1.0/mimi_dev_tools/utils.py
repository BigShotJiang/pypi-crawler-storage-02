"""
Utility classes for Mimi Dev Tools.
"""

import subprocess
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional
import yaml
import tomllib


class ConfigValidator:
    """Validate project configuration files."""
    
    def __init__(self) -> None:
        self.supported_formats = [".toml", ".yaml", ".yml", ".json"]
    
    def validate(self, config_path: str) -> bool:
        """Validate a configuration file."""
        config_file = Path(config_path)
        
        if not config_file.exists():
            raise FileNotFoundError(f"Configuration file '{config_path}' not found.")
        
        if config_file.suffix not in self.supported_formats:
            raise ValueError(f"Unsupported configuration format: {config_file.suffix}")
        
        try:
            if config_file.suffix == ".toml":
                return self._validate_toml(config_file)
            elif config_file.suffix in [".yaml", ".yml"]:
                return self._validate_yaml(config_file)
            elif config_file.suffix == ".json":
                return self._validate_json(config_file)
        except Exception as e:
            print(f"Validation error: {e}")
            return False
        
        return True
    
    def _validate_toml(self, config_file: Path) -> bool:
        """Validate TOML configuration file."""
        try:
            with open(config_file, "rb") as f:
                tomllib.load(f)
            return True
        except Exception as e:
            print(f"TOML validation error: {e}")
            return False
    
    def _validate_yaml(self, config_file: Path) -> bool:
        """Validate YAML configuration file."""
        try:
            with open(config_file, "r") as f:
                yaml.safe_load(f)
            return True
        except Exception as e:
            print(f"YAML validation error: {e}")
            return False
    
    def _validate_json(self, config_file: Path) -> bool:
        """Validate JSON configuration file."""
        try:
            import json
            with open(config_file, "r") as f:
                json.load(f)
            return True
        except Exception as e:
            print(f"JSON validation error: {e}")
            return False


class CodeFormatter:
    """Format and lint code using various tools."""
    
    def __init__(self) -> None:
        self.tools = {
            "black": self._run_black,
            "isort": self._run_isort,
            "flake8": self._run_flake8,
        }
    
    def format(self, path: str) -> None:
        """Format code in the specified path."""
        path_obj = Path(path)
        
        if not path_obj.exists():
            raise FileNotFoundError(f"Path '{path}' not found.")
        
        # Run formatters
        self._run_black(path_obj)
        self._run_isort(path_obj)
    
    def check(self, path: str) -> List[str]:
        """Check code formatting without modifying files."""
        path_obj = Path(path)
        issues = []
        
        if not path_obj.exists():
            raise FileNotFoundError(f"Path '{path}' not found.")
        
        # Check with black
        black_issues = self._check_black(path_obj)
        issues.extend(black_issues)
        
        # Check with isort
        isort_issues = self._check_isort(path_obj)
        issues.extend(isort_issues)
        
        # Check with flake8
        flake8_issues = self._check_flake8(path_obj)
        issues.extend(flake8_issues)
        
        return issues
    
    def _run_black(self, path: Path) -> None:
        """Run black formatter."""
        try:
            subprocess.run([
                sys.executable, "-m", "black", str(path)
            ], check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as e:
            print(f"Black formatting error: {e}")
            raise
    
    def _run_isort(self, path: Path) -> None:
        """Run isort formatter."""
        try:
            subprocess.run([
                sys.executable, "-m", "isort", str(path)
            ], check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as e:
            print(f"isort formatting error: {e}")
            raise
    
    def _run_flake8(self, path: Path) -> None:
        """Run flake8 linter."""
        try:
            subprocess.run([
                sys.executable, "-m", "flake8", str(path)
            ], check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as e:
            print(f"flake8 linting error: {e}")
            raise
    
    def _check_black(self, path: Path) -> List[str]:
        """Check black formatting without modifying files."""
        issues = []
        try:
            result = subprocess.run([
                sys.executable, "-m", "black", "--check", "--diff", str(path)
            ], capture_output=True, text=True)
            
            if result.returncode != 0:
                issues.append(f"Black formatting issues found in {path}")
                if result.stdout:
                    issues.append(result.stdout)
        except subprocess.CalledProcessError:
            issues.append(f"Black check failed for {path}")
        
        return issues
    
    def _check_isort(self, path: Path) -> List[str]:
        """Check isort formatting without modifying files."""
        issues = []
        try:
            result = subprocess.run([
                sys.executable, "-m", "isort", "--check-only", "--diff", str(path)
            ], capture_output=True, text=True)
            
            if result.returncode != 0:
                issues.append(f"isort formatting issues found in {path}")
                if result.stdout:
                    issues.append(result.stdout)
        except subprocess.CalledProcessError:
            issues.append(f"isort check failed for {path}")
        
        return issues
    
    def _check_flake8(self, path: Path) -> List[str]:
        """Check flake8 linting."""
        issues = []
        try:
            result = subprocess.run([
                sys.executable, "-m", "flake8", str(path)
            ], capture_output=True, text=True)
            
            if result.returncode != 0:
                issues.append(f"flake8 linting issues found in {path}")
                if result.stdout:
                    issues.append(result.stdout)
        except subprocess.CalledProcessError:
            issues.append(f"flake8 check failed for {path}")
        
        return issues


class ProjectAnalyzer:
    """Analyze project structure and dependencies."""
    
    def __init__(self, project_path: str) -> None:
        self.project_path = Path(project_path)
        if not self.project_path.exists():
            raise FileNotFoundError(f"Project path '{project_path}' not found.")
    
    def analyze_structure(self) -> Dict[str, Any]:
        """Analyze project structure."""
        structure = {
            "root": str(self.project_path),
            "directories": [],
            "files": [],
            "python_files": [],
            "test_files": [],
            "config_files": [],
        }
        
        for item in self.project_path.rglob("*"):
            if item.is_dir():
                structure["directories"].append(str(item.relative_to(self.project_path)))
            elif item.is_file():
                structure["files"].append(str(item.relative_to(self.project_path)))
                
                if item.suffix == ".py":
                    structure["python_files"].append(str(item.relative_to(self.project_path)))
                elif "test" in item.name.lower():
                    structure["test_files"].append(str(item.relative_to(self.project_path)))
                elif item.suffix in [".toml", ".yaml", ".yml", ".json", ".cfg", ".ini"]:
                    structure["config_files"].append(str(item.relative_to(self.project_path)))
        
        return structure
    
    def analyze_dependencies(self) -> Dict[str, Any]:
        """Analyze project dependencies."""
        dependencies = {
            "runtime": [],
            "development": [],
            "optional": {},
        }
        
        # Check for pyproject.toml
        pyproject_file = self.project_path / "pyproject.toml"
        if pyproject_file.exists():
            try:
                with open(pyproject_file, "rb") as f:
                    config = tomllib.load(f)
                
                if "project" in config and "dependencies" in config["project"]:
                    dependencies["runtime"] = config["project"]["dependencies"]
                
                if "project" in config and "optional-dependencies" in config["project"]:
                    dependencies["optional"] = config["project"]["optional-dependencies"]
            except Exception as e:
                print(f"Error parsing pyproject.toml: {e}")
        
        # Check for requirements.txt
        requirements_file = self.project_path / "requirements.txt"
        if requirements_file.exists():
            try:
                with open(requirements_file, "r") as f:
                    dependencies["runtime"].extend([
                        line.strip() for line in f 
                        if line.strip() and not line.startswith("#")
                    ])
            except Exception as e:
                print(f"Error parsing requirements.txt: {e}")
        
        return dependencies
    
    def generate_report(self) -> str:
        """Generate a comprehensive project report."""
        structure = self.analyze_structure()
        dependencies = self.analyze_dependencies()
        
        report = f"""
Project Analysis Report
======================

Project Path: {structure['root']}

Structure:
----------
Directories: {len(structure['directories'])}
Files: {len(structure['files'])}
Python Files: {len(structure['python_files'])}
Test Files: {len(structure['test_files'])}
Config Files: {len(structure['config_files'])}

Dependencies:
-------------
Runtime Dependencies: {len(dependencies['runtime'])}
Optional Dependencies: {len(dependencies['optional'])}

Runtime Dependencies:
{chr(10).join(f'  - {dep}' for dep in dependencies['runtime'])}

Optional Dependencies:
{chr(10).join(f'  - {name}: {len(deps)} dependencies' for name, deps in dependencies['optional'].items())}
"""
        
        return report 