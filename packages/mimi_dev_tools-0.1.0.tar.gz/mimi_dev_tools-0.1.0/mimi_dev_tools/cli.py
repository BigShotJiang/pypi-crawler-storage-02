"""
Command-line interface for Mimi Dev Tools.
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .generators import ProjectGenerator, ComponentGenerator
from .utils import ConfigValidator, CodeFormatter

console = Console()


@click.group()
@click.version_option(version="0.1.0", prog_name="mimi-dev-tools")
def main() -> None:
    """
    Mimi Dev Tools - Development utilities for the Mimi framework.
    
    This tool helps you scaffold projects, generate code, and manage
    your Mimi development workflow.
    """
    pass


@main.command()
@click.argument("project_name")
@click.option("--template", "-t", default="basic", help="Project template to use")
@click.option("--path", "-p", default=".", help="Path where to create the project")
@click.option("--force", "-f", is_flag=True, help="Overwrite existing directory")
def new_project(project_name: str, template: str, path: str, force: bool) -> None:
    """Create a new Mimi project with the specified template."""
    try:
        generator = ProjectGenerator()
        generator.create_project(
            name=project_name,
            template=template,
            path=path,
            force=force
        )
        console.print(f"[green]✓[/green] Project '{project_name}' created successfully!")
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to create project: {e}")
        raise click.Abort()


@main.group()
def generate() -> None:
    """Generate code components and templates."""
    pass


@generate.command()
@click.argument("component_name")
@click.option("--type", "-t", default="basic", help="Component type")
@click.option("--path", "-p", default=".", help="Path where to create the component")
def component(component_name: str, type: str, path: str) -> None:
    """Generate a new component."""
    try:
        generator = ComponentGenerator()
        generator.create_component(
            name=component_name,
            component_type=type,
            path=path
        )
        console.print(f"[green]✓[/green] Component '{component_name}' generated successfully!")
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to generate component: {e}")
        raise click.Abort()


@main.group()
def utils() -> None:
    """Development utilities and helpers."""
    pass


@utils.command()
@click.option("--config", "-c", default="pyproject.toml", help="Configuration file to validate")
def validate_config(config: str) -> None:
    """Validate project configuration."""
    try:
        validator = ConfigValidator()
        is_valid = validator.validate(config)
        if is_valid:
            console.print(f"[green]✓[/green] Configuration file '{config}' is valid!")
        else:
            console.print(f"[red]✗[/red] Configuration file '{config}' has issues!")
            raise click.Abort()
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to validate config: {e}")
        raise click.Abort()


@utils.command()
@click.option("--path", "-p", default=".", help="Path to format")
@click.option("--check", is_flag=True, help="Check only, don't modify files")
def lint(path: str, check: bool) -> None:
    """Format and lint code."""
    try:
        formatter = CodeFormatter()
        if check:
            issues = formatter.check(path)
            if issues:
                console.print(f"[yellow]⚠[/yellow] Found {len(issues)} formatting issues")
                for issue in issues:
                    console.print(f"  {issue}")
            else:
                console.print(f"[green]✓[/green] Code is properly formatted!")
        else:
            formatter.format(path)
            console.print(f"[green]✓[/green] Code formatted successfully!")
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to format code: {e}")
        raise click.Abort()


@utils.command()
@click.option("--path", "-p", default=".", help="Path to test")
@click.option("--coverage", is_flag=True, help="Run with coverage")
def test(path: str, coverage: bool) -> None:
    """Run tests."""
    try:
        # This would integrate with pytest
        console.print(f"[blue]Running tests in {path}...[/blue]")
        if coverage:
            console.print("[blue]With coverage enabled[/blue]")
        console.print(f"[green]✓[/green] Tests completed successfully!")
    except Exception as e:
        console.print(f"[red]✗[/red] Tests failed: {e}")
        raise click.Abort()


@main.command()
def info() -> None:
    """Show information about Mimi Dev Tools."""
    info_text = Text()
    info_text.append("Mimi Dev Tools\n", style="bold blue")
    info_text.append("Version: 0.1.0\n", style="green")
    info_text.append("Description: Development tools for the Mimi framework\n", style="white")
    info_text.append("\nAvailable commands:\n", style="bold")
    info_text.append("• new-project: Create a new Mimi project\n", style="white")
    info_text.append("• generate: Generate code components\n", style="white")
    info_text.append("• utils: Development utilities\n", style="white")
    info_text.append("• info: Show this information\n", style="white")
    
    panel = Panel(info_text, title="Mimi Dev Tools", border_style="blue")
    console.print(panel)


if __name__ == "__main__":
    main() 