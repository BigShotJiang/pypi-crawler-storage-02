"""
Mimi Dev Tools - Development tools for the Mimi framework.

This package provides utilities for scaffolding, code generation, and development
workflows for Mimi projects.
"""

__version__ = "0.1.0"
__author__ = "mimi-dev-tools contributors"
__email__ = "your.email@example.com"

from .cli import main
from .generators import ProjectGenerator, ComponentGenerator
from .utils import ConfigValidator, CodeFormatter

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "main",
    "ProjectGenerator",
    "ComponentGenerator",
    "ConfigValidator",
    "CodeFormatter",
] 