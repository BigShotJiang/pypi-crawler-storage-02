# Jupyterlab Norwegian Bokmål (Norway) Language Pack

Norwegian Bokmål (Norway) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-no-NO
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-no-NO
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
