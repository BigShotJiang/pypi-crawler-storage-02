# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
* cofas83940 ([@cofas83940](https://crowdin.com/profile/cofas83940))
* Vidar Tonaas Fauske ([@vidartf](https://crowdin.com/profile/vidartf))
* Trygve Falch ([@trygu](https://crowdin.com/profile/trygu))
