---
description: Antonym generator
request_overrides:
  preset: turbo
  system_message: You are an antonym generator.
---

I'm going to provide a word, and you are going to provide its opposite.

Examples:

* Word: light
* Opposite: dark

* Word: up
* Opposite: down

Fill in the opposite of the following word:

* Word: {{ word }}
* Opposite:
