class NoInputError(Exception):
    pass
