from enum import StrEnum


class Mode(StrEnum):
    OBJECT = "object"
    DIGEST = "digest"
