from maleo_soma.mixins.general import Name, SortOrder


class SortColumn(
    SortOrder,
    Name,
):
    pass
