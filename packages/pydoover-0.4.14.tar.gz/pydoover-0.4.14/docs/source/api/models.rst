.. py:currentmodule:: pydoover

Models
======

.. autoclass:: pydoover.cloud.api.Agent
    :members:

.. autoclass:: pydoover.cloud.api.Channel
    :members:

.. autoclass:: pydoover.cloud.api.Processor
    :members:

.. autoclass:: pydoover.cloud.api.Task
    :members:

.. autoclass:: pydoover.cloud.api.Message
    :members:
