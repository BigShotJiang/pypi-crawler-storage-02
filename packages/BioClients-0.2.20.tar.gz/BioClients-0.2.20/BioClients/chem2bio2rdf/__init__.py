"""Client tools for Chem2Bio2RDF (PostgreSql db) and SLAP (REST API)."""

from .Utils import *

__all__ = [ "slap" ]
