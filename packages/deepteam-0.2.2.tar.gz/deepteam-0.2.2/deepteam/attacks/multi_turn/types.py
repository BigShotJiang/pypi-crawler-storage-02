from typing import Callable

CallbackType = Callable[[str], str]
