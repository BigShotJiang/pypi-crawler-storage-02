from enum import Enum


class RobustnessType(Enum):
    INPUT_OVERRELIANCE = "input overreliance"
    HIJACKING = "hijacking"
