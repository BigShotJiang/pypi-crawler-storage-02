from .types import ShellInjectionType
from .template import ShellInjectionTemplate
