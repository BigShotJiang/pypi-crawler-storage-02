from .types import SQLInjectionType
from .template import SQLInjectionTemplate
