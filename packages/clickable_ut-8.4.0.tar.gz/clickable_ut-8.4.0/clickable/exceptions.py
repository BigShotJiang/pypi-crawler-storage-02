class ClickableException(Exception):
    pass


class FileNotFoundException(ClickableException):
    pass
