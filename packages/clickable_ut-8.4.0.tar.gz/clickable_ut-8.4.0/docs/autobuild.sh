#!/bin/bash

sphinx-autobuild . _build/html/
