from ppycron.src.unix import UnixInterface

Crontab = UnixInterface
