#!/usr/bin/env python
# PYTHON_ARGCOMPLETE_OK
from xcookie.main import main


if __name__ == '__main__':
    """
    CommandLine:
        python ~/code/xcookie/xcookie/__main__.py
    """
    main()
