"""
Helpers for version control systems
"""
