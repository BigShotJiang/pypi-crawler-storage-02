# DEPRECATED, use the VCS submodule
from xcookie.vcs.gitlab import GitlabRemote  # NOQA
from xcookie.vcs.github import GithubRemote  # NOQA
