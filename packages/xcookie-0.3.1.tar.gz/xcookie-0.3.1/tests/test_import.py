def test_import():
    import xcookie