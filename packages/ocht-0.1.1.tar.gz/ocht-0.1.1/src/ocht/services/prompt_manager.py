# Business logic for prompt templates
