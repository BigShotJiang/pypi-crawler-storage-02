def create_workspace(name: str):
    """Creates the workspace directory, config & DB schema."""
    pass
