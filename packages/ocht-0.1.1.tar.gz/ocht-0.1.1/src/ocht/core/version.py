def get_version() -> str:
    """Gibt die aktuelle Paket-Version zurück.
    :rtype: str
    """
    return "0.0.1"  # später dynamisch aus pyproject.toml lesen