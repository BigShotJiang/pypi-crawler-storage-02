from toolsed import pluralize

print(pluralize(3, "cat", "cat"))  # Expected output: "cats"
