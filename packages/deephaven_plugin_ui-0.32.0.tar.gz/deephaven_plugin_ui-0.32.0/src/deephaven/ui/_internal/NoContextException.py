class NoContextException(Exception):
    pass
