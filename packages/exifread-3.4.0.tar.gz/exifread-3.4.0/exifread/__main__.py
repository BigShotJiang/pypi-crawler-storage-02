"""Main entrypoint for the module."""

from exifread.cli import main

if __name__ == "__main__":
    main()
