 <div align="center">
  <picture>
    <source
    srcset="./logos/DarkkMode.png"
    media="(prefers-color-scheme: dark)"
    width="100%" height="100%"
    />
    <img
    src="./logos/LighttMode.png"
    width="100%" height="100%"
    />
  </picture>
    
  <h3 align="center">Enhancing Rapidly Overdensities of Sources with Ease</h3>
</div>