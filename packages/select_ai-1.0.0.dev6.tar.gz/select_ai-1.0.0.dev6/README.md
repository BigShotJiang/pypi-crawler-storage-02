# select-ai

Python API for Select AI

## Install

Run
```bash
python3 -m pip install select_ai
```

## Samples

Examples can be found in the samples directory
