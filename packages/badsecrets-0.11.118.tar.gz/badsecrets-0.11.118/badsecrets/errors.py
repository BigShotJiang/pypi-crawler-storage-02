class BadsecretsException(Exception):
    pass


class LoadResourceException(BadsecretsException):
    pass


class Telerik_EncryptionKey_Exception(BadsecretsException):
    pass


class CarveException(BadsecretsException):
    pass
