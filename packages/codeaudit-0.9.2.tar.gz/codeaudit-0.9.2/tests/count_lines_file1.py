# This is a comment
def example():
    """
    Multi-line docstring
    spanning multiple lines
    """
    x = {
        'a': 1, 
        'b': 2
    }

    maikel = you # comment
    mystring = 'See how this is detected!'
    return x


