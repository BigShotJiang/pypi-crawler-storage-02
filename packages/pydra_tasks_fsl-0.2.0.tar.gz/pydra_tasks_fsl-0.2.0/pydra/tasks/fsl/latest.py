PACKAGE_VERSION = "v6"

from .v6 import *  # noqa
