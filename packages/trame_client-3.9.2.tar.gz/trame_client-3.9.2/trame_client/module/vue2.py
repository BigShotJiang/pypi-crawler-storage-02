from pathlib import Path

www = str(Path(__file__).with_name("vue2-www").resolve())
