#!/usr/bin/env python
# -*- coding: utf-8 -*-

from nuvla.job_engine.job.base import main
from nuvla.job_engine.job.executor.executor import Executor

if __name__ == '__main__':
    main(Executor)
