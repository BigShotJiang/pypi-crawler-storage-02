from __future__ import annotations

from funpayparsers.parsers.utils import parse_date_string


result = parse_date_string('5 августа, 15:13:00')

print(result)
