class MobileLibrary:
    raise DeprecationWarning('This code has been moved to Robotframework-ApplicationLibrary as of version 3.0.0, more information: https://github.com/Accruent/robotframework-zoomba/releases/tag/3.0.0')
