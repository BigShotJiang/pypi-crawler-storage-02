class InstallCommand:

    @staticmethod
    def handle():
        self.publish_config()
        self.publish_xlsx()
    
    
    def publish_config():
        print("Publishing configuration files...")

    def publish_xlsx():
        print("Publishing xlsx files...")