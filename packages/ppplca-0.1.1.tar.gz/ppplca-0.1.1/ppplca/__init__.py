
def install():
    import Commands.InstallCommand
    InstallCommand.handle()
    return
