"""Test suite for VicAlerts."""
