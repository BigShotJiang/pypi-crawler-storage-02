"""Test suite for vicalerts modules."""
