from qwak.exceptions import QwakSuggestionException


class QwakDeployNewBuildFailedException(QwakSuggestionException):
    pass
