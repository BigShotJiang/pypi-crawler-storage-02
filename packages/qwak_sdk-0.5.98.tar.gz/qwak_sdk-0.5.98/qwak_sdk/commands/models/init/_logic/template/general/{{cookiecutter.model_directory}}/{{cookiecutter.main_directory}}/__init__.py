from .model import {{cookiecutter.model_class_name}}


def load_model():
    return {{cookiecutter.model_class_name}}()
