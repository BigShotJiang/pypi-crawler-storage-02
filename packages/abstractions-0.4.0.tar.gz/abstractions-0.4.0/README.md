# Abstractions

Abstractions for programming in Python.

- [Documentation](https://arjunguha.github.io/py-abstractions/)
- Installation: `uv add abstractions`

