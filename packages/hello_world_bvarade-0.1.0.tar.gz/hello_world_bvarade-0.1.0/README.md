# hello_world_bvarade

this is the simple hello world library

## Usage

```python
from hello_world import hello
hello()
```
