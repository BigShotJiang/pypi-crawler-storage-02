from django.apps import AppConfig


class CoreConfig(AppConfig):
    name = "common.core"
    label = "common_core"
