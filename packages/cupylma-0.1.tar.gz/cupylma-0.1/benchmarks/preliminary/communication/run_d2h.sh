python benchmarks/preliminary/communication/run_d2h.py 1_000_000_000 --pin
python benchmarks/preliminary/communication/run_d2h.py 2_000_000_000 --pin
python benchmarks/preliminary/communication/run_d2h.py 4_000_000_000 --pin
python benchmarks/preliminary/communication/run_d2h.py 8_000_000_000 --pin

python benchmarks/preliminary/communication/run_d2h.py 1_000_000_000
python benchmarks/preliminary/communication/run_d2h.py 2_000_000_000
python benchmarks/preliminary/communication/run_d2h.py 4_000_000_000
python benchmarks/preliminary/communication/run_d2h.py 8_000_000_000