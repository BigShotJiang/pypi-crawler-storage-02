.. _howto-migrate-to-other-plugins:

Migrate to other plugins
========================

.. toctree::
   :maxdepth: 2

   Migrate to poetry <charm-to-poetry>
   Migrate to python <charm-to-python>
   Migrate to uv <charm-to-uv>
