.. _part:
.. _parts:

Parts
=====

Parts, powered by :external+craft-parts:ref:`craft-parts <reference>`, power the build
system that charmcraft uses.

.. toctree::
   :maxdepth: 1

   /common/craft-parts/reference/part_properties
   /common/craft-parts/reference/parts_steps
   /common/craft-parts/reference/step_execution_environment
   /common/craft-parts/explanation/filesets
   lifecycle
   ../plugins/index
