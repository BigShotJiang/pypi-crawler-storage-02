.. _data-models:

Data models
===========

.. toctree::
    :maxdepth: 2

    bases-charm
