# TODO

* Make the "only" parameter of GitLab CI jobs configurable (add a list to the configuration file). 
* Add support for generating Pylint badges: <https://stackoverflow.com/questions/43126475/pylint-badge-in-gitlab>
* Check if a Zenodo URL can be retrieved via the [Zenodo REST API](https://developers.zenodo.org/)
* Maybe add support for uploading packages to PyPI (based on release tags).
* Idem for uploading archives to Zenodo (with a generated .zenodo.json file).
