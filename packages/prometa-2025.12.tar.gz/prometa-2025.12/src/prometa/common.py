#!/usr/bin/env python3
"""
Common constants.
"""

NAME = "prometa"

ENCODING = "utf-8"
