# Autoverse CLI

The new implementation of the Autoverse CLI