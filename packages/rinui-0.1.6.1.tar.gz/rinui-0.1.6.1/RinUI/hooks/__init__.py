def get_hook_dirs():
    import os
    return [os.path.dirname(__file__)]
