from .core import *

__version__ = "0.1.6.1"
__author__ = "RinLit"
