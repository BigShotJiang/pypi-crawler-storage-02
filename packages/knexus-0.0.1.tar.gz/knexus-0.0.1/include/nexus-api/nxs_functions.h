/*
 */

#ifndef NEXUS_API_NXS_FUNCTIONS_H_
#define NEXUS_API_NXS_FUNCTIONS_H_

#include <nexus-api/nxs.h>

#define NEXUS_API_GENERATE_FUNC_ENUM
#include <nexus-api/_nxs_functions.h>
#define NEXUS_API_GENERATE_FUNC_DECL
#include <nexus-api/_nxs_functions.h>
#define NEXUS_API_GENERATE_FUNC_TYPE
#include <nexus-api/_nxs_functions.h>

#endif /* NEXUSAPI_NXS_FUNCTIONS_H_ */
