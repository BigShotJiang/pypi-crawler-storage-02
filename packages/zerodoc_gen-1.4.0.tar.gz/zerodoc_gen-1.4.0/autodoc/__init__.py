"""AutoDoc - Zero-config documentation generator with beautiful UI."""

__version__ = "1.4.0"
__author__ = "AutoDoc Team"
__license__ = "MIT"