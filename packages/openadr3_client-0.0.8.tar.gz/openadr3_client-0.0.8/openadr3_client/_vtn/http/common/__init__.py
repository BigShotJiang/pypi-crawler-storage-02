"""Implements common types and structures used in the OpenADR3 HTTP VTN communication."""
