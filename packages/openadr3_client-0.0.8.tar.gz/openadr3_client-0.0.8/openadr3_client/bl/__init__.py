"""
Business Logic (BL) module of the OpenADR3 Client.

This module provides BL specific logic and implementations for the OpenADR3 Client.
"""
