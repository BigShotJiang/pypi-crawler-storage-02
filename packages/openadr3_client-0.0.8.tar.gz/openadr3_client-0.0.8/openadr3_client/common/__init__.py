"""
Common module of the OpenADR3 library.

Contains some helpful logic used across the library which does not belong to any specific module.
"""
