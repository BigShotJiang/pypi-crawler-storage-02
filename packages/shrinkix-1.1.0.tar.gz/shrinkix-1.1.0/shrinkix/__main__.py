"""Entrypoint with `python -m shrinkix`."""

from .cli import entrypoint

if __name__ == "__main__":
    entrypoint()  # pragma: no cover
