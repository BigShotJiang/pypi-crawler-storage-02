def to_hex(value: int) -> str:
    return hex(value)
