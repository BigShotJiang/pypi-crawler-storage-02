"""
Matplotlib backend.

Render to qt from agg (anti-grain).
"""

from .. import config

import os
import ctypes
import threading
import logging
import warnings
import matplotlib

from matplotlib.transforms import Bbox
from matplotlib.figure import Figure
from matplotlib import cbook
from matplotlib._pylab_helpers import Gcf
from matplotlib.backend_bases import FigureCanvasBase, FigureManagerBase
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.backends.backend_qt5 import FigureCanvasQT
from matplotlib.backends.qt_compat import QT_API
from matplotlib import rcParams
from packaging import version

from .. import gui


if not version.parse('3.2') <= version.parse(matplotlib.__version__) < version.parse('3.12'):
    warnings.warn(
        f'Matplotlib version {matplotlib.__version__} not supported.\n'
        f'Version should be 3.2 to 3.11'
    )
        
if config.get('qapp'):
    from qtpy import QtCore, QtGui
    from ..panels.matplot import PlotPanel

    matplot_version = version.parse(matplotlib.__version__)

    if matplot_version == version.parse('3.2'):
        setDevicePixelRatio = QtGui.QImage.setDevicePixelRatio
        DEV_PIXEL_RATIO_ATTR = "_dpi_ratio"    
        
    elif matplot_version == version.parse('3.3'):
        from matplotlib.backends.qt_compat import _setDevicePixelRatioF
        setDevicePixelRatio = _setDevicePixelRatioF
        DEV_PIXEL_RATIO_ATTR = "_dpi_ratio"
        
    elif matplot_version < version.parse('3.5'):
        from matplotlib.backends.qt_compat import _setDevicePixelRatio
        setDevicePixelRatio = _setDevicePixelRatio
        DEV_PIXEL_RATIO_ATTR = "_dpi_ratio"
        
    elif matplot_version == version.parse('3.5'):
        from matplotlib.backends.qt_compat import _setDevicePixelRatio
        setDevicePixelRatio = _setDevicePixelRatio
        DEV_PIXEL_RATIO_ATTR = "_device_pixel_ratio"       
        
    else:
        setDevicePixelRatio = QtGui.QImage.setDevicePixelRatio
        DEV_PIXEL_RATIO_ATTR = "_device_pixel_ratio"    

logger = logging.getLogger(__name__)

warnings.filterwarnings("ignore", "Starting a Matplotlib GUI outside of the main thread will likely fail.")


def draw_if_interactive():
    """
    For image backends - is not required.
    For GUI backends - this should be overridden if drawing should be done in
    interactive python mode.
    """  
    if matplotlib.is_interactive(): 
        show()


def show(*, block=None):
    """
    For image backends - is not required.
    For GUI backends - show() is usually the last line of a pyplot script and
    tells the backend that it is time to draw.  In interactive mode, this
    should do nothing.
    """ 
    # manager = Gcf.get_active()
    if matplotlib.is_interactive():
        return
    
    max_open_warning = rcParams['figure.max_open_warning']
    
    all_fig_managers = Gcf.get_all_fig_managers()
    many_show_warning = config.get("matplotlib", {}).get("many_show_warning", True)
    
    for i, manager in enumerate(all_fig_managers):
        if many_show_warning and (i == max_open_warning):
            left = len(all_fig_managers) - i
            do_continue = gui.dialog.question(f'Continue for next {left} figures?')
            if not do_continue:
                break
        manager.show()


def new_figure_manager(num, *args, FigureClass=Figure, **kwargs):
    """Create a new figure manager instance."""
    # If a main-level app must be created, this (and
    # new_figure_manager_given_figure) is the usual place to do it -- see
    # backend_wx, backend_wxagg and backend_tkagg for examples.  Not all GUIs
    # require explicit instantiation of a main-level app (e.g., backend_gtk3)
    # for pylab.
    this_fig = FigureClass(*args, **kwargs)
    return new_figure_manager_given_figure(num, this_fig)


def new_figure_manager_given_figure(num, figure):
    """Create a new figure manager instance for the given figure."""
    # print(f'timer: {time.perf_counter()}')

    if not gui.valid() or gui._qapp is None:                    
        # In case of coming from other Process
        # Don't do a guicall, FigureCanvasGh2 or FigureManagerQT is not picklable!
        # Is called when a figure, line, ... is depickled from the interprocess queue
        canvas = FigureCanvasBase(figure)
        manager = FigureManagerGh2Child(canvas, num)
        
    else:
        canvas = gui.gui_call(FigureCanvasGh2, figure)    
        manager = FigureManagerGh2(canvas, num)
        
    return manager        


class FigureCanvasGh2(FigureCanvasAgg, FigureCanvasQT):

    def __init__(self, figure):
        # Must pass 'figure' as kwarg to Qt base class.
        super().__init__(figure=figure)        
            
    @property
    def dev_pixel_ratio(self):
        return getattr(self, DEV_PIXEL_RATIO_ATTR)

    def paintEvent(self, event):
        """
        Copy the image from the Agg canvas to the qt.drawable.

        In Qt, all drawing should be done locally here when a widget is
        shown onscreen.
        """
        logger.debug('calling paintEvent')
        
        if matplotlib.__version__[:3] in ['3.2', '3.3']:
            if self._update_dpi():
                # The dpi update triggered its own paintEvent.
                return
                
        self._draw_idle()  # Only does something if a draw is pending.

        # If the canvas does not have a renderer, then give up and wait for
        # FigureCanvasAgg.draw(self) to be called.
        if not hasattr(self, 'renderer'):
            return

        painter = QtGui.QPainter(self)
        try:
            # See documentation of QRect: bottom() and right() are off
            # by 1, so use left() + width() and top() + height().
            rect = event.rect()
            # scale rect dimensions using the screen dpi ratio to get
            # correct values for the Figure coordinates (rather than
            # QT5's coords)
            width = rect.width() * self.dev_pixel_ratio
            height = rect.height() * self.dev_pixel_ratio
            left, top = self.mouseEventCoords(rect.topLeft())
            # shift the "top" by the height of the image to get the
            # correct corner for our coordinate system
            bottom = top - height
            # same with the right side of the image
            right = left + width
            # create a buffer using the image bounding box
            bbox = Bbox([[left, bottom], [right, top]])

            reg: "BufferRegion" = self.copy_from_bbox(bbox)
            buf: "numpy.ndarray" = cbook._unmultiplied_rgba8888_to_premultiplied_argb32(
                memoryview(reg)
            )

            # clear the widget canvas
            painter.eraseRect(rect)

            qimage = QtGui.QImage(
                buf, buf.shape[1], buf.shape[0],
                QtGui.QImage.Format_ARGB32_Premultiplied,
            )
            setDevicePixelRatio(qimage, self.dev_pixel_ratio)
            # set origin using original QT coordinates
            origin = QtCore.QPoint(rect.left(), rect.top())
            painter.drawImage(origin, qimage)

            # Adjust the buf reference count to work around a memory
            # leak bug in QImage under PySide on Python 3.
            # See https://github.com/thocoo/gamma-desk/issues/36
            # and https://bugreports.qt.io/browse/PYSIDE-140 .
            if QT_API in ('PySide', 'PySide2'):
                ctypes.c_long.from_address(id(buf)).value = 1

            self._draw_rect_callback(painter)
        finally:
            painter.end()
            
    def draw_idle(self):
        logger.debug('calling draw_idle')
        gui.gui_call(FigureCanvasQT.draw_idle, self) 
        
    def destroy(self, *args):
        gui.gui_call(FigureCanvasQT.destroy, self, *args)                                    

    def blit(self, bbox=None):
        # docstring inherited
        # If bbox is None, blit the entire canvas. Otherwise, blit only
        # the area defined by the bbox.
        if bbox is None and self.figure:
            bbox = self.figure.bbox

        # repaint uses logical pixels, not physical pixels like the renderer.
        l, b, w, h = [int(pt / self._dpi_ratio) for pt in bbox.bounds]
        t = b + h
        self.repaint(l, self.renderer.height / self._dpi_ratio - t, w, h)

    def print_figure(self, *args, **kwargs):
        super().print_figure(*args, **kwargs)
        self.draw()


def make_and_hide_plot_panel(PanelClass, parentName=None, panid=None, floating=False,
        position =None, size=None, args=(), kwargs=None):
    kwargs = kwargs or {}
        
    panel = gui._qapp.panels.new_panel(
        PanelClass,
        parentName,
        panid,
        floating,
        position=position,
        size=size,
        args=args,
        kwargs=kwargs,
    )
    # if not matplotlib.is_interactive():
    #    panel.window().hide()
    return panel        


class FigureManagerGh2(FigureManagerBase):

    """
    Wrap everything up into a window for the pylab interface

    For non-interactive backends, the base class does all the work
    """       
    def __init__(self, canvas, num):
        super().__init__(canvas, num)
        
        if matplotlib.is_interactive():
            width, height = self.canvas.figure.get_dpi() * self.canvas.figure.get_size_inches()
            self.panel = gui.gui_call(
                make_and_hide_plot_panel,
                PlotPanel,
                'main',
                self.num,
                None,
                size=[width, height],
                args=(self.canvas,),
            )
        else:
            self.panel = None    
    
    def show(self):
        """
        For GUI backends, show the figure window and redraw.
        For non-GUI backends, raise an exception to be caught
        by :meth:`~matplotlib.figure.Figure.show`, for an
        optional warning.
        """
        if gui.valid():
            if self.panel is None:
                width, height = self.canvas.figure.get_dpi() * self.canvas.figure.get_size_inches()
                self.panel = gui.gui_call(
                    make_and_hide_plot_panel,
                    PlotPanel,
                    'main',
                    self.num,
                    None,
                    size=[width, height],
                    args=(self.canvas,),
                )
            gui.gui_call(PlotPanel.show_me, self.panel)
            gui.gui_call(PlotPanel.refresh, self.panel)
        else:        
            raise ValueError(f'gui called from unknown thread {os.getpid()}/{threading.current_thread()}')
        
    def destroy(self, *args):        
        if 'plot' in gui._qapp.panels.keys():
            if self.panel is not None:
                gui.gui_call(PlotPanel.close_panel, self.panel)
        else:
            pass


class FigureManagerGh2Child(FigureManagerBase):

    """
    Wrap everything up into a window for the pylab interface

    For non-interactive backends, the base class does all the work
    """       
    def __init__(self, canvas, num):
        super().__init__(canvas, num)
        self.panel = None
    
    def show(self):
        """
        For GUI backends, show the figure window and redraw.
        For non-GUI backends, raise an exception to be caught
        by :meth:`~matplotlib.figure.Figure.show`, for an
        optional warning.
        """
        if gui.valid():            
            gui.plot.show(self.canvas.figure)
        else:        
            raise ValueError(f'gui called from unknown thread {os.getpid()}/{threading.current_thread()}')


FigureCanvas = FigureCanvasGh2
FigureManager = FigureManagerGh2
