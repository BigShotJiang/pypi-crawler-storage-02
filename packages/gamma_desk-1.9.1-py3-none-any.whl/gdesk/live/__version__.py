from .. import __version__, __version_info__

VERSION_INFO = __version__
VERSION = __version_info__
