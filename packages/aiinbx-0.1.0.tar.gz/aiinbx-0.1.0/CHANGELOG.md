# Changelog

## 0.1.0 (2025-08-13)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/aiinbx/aiinbx-py/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([9f338c0](https://github.com/aiinbx/aiinbx-py/commit/9f338c08cf76e9482a9529c761654cdd250483ea))


### Chores

* configure new SDK language ([3cc34fc](https://github.com/aiinbx/aiinbx-py/commit/3cc34fcf8b0325986076726a774c419992b5aafa))
* update SDK settings ([9251ee7](https://github.com/aiinbx/aiinbx-py/commit/9251ee7b47185255692e59f672e6158f4af32541))
