Este módulo integra a parte fiscal do módulo `l10n_br_fiscal` com o
módulo de compra purchase do Odoo. O módulo permite o cálculo dos
impostos brasileiros já no pedido de compra e propaga a operação fiscal
até a nota fiscal de compra, deixando ela com a tributação mais correta
possível para seu financeiro (sendo que vocẽ poderia também importar o
XML da nota depois).

O relatório de compra também é estendido para apresentar os impostos
brasileiros.

Este módulo é indicado para a compra de itens com NFe's. Mas se você
quer gerenciar suas notas de entradas de acordo com o recebimento do
material, você pode também ter interesse no módulo
`l10n_br_purchase_stock` que permite isso.
