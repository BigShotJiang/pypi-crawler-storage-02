# Examples package for computer-split-screen-mcp
