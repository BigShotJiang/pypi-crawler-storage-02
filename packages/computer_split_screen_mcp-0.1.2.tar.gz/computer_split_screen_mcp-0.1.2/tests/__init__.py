# Tests package for computer-split-screen-mcp
