# TODO: Add code!


def main() -> None:
    raise SystemExit("Import and call `extract_and_save_embeddings(extractor, config)` instead.")


if __name__ == "__main__":
    main()
