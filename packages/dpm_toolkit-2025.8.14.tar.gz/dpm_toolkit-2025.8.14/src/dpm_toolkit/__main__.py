"""Entry point for the DPM Toolkit package."""

from dpm_toolkit.cli import main

if __name__ == "__main__":
    main()
