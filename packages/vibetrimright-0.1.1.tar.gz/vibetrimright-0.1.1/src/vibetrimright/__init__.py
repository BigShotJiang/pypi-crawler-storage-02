from . import ai


def vibetrimright(text: str) -> str:
    return ai.vibetrimright(text)