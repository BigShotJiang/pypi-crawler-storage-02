#pragma once

extern void solve(float* d_C, int* d_X, float* d_U, float* d_V, int n);
extern void verify_solution(float* d_C, int* d_X, float* d_U, float* d_V, int n);
