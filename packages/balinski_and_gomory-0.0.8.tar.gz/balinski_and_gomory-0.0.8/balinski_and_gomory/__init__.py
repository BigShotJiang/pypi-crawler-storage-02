from balinski_and_gomory._torch.basic_solver import solve as solve_slow
from balinski_and_gomory.hylac_shortcut.wrapper import run_lap_with_result, solve_hylac
from balinski_and_gomory._cuda.wrapper import cuda_solver
