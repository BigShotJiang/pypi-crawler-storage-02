"""Contains common functions and types that are used across modules."""
