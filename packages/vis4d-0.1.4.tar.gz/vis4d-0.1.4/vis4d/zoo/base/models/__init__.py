"""Model Zoo base models."""
