"""Model Zoo base datasets."""
