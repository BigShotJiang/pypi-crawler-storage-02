"""Mask R-CNN for SHIFT."""
