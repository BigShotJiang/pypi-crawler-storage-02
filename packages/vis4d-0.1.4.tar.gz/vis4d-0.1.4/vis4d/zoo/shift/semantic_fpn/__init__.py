"""Semantic FPN for SHIFT."""
