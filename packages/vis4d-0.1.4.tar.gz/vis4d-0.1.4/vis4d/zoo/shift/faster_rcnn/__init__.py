"""Faster R-CNN for SHIFT."""
