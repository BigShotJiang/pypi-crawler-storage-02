"""Semantic FPN for BDD100K."""
