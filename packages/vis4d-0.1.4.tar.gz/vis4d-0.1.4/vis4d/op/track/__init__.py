"""Tracking models module."""
