"""Operations on 2D bounding boxes."""
