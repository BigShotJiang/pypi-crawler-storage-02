"""Detector module."""
