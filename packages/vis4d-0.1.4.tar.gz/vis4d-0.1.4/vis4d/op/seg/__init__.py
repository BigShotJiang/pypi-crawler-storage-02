"""Segmentor module."""
