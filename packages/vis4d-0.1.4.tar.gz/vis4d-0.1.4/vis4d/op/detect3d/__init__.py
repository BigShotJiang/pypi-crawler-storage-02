"""3D detector module."""
