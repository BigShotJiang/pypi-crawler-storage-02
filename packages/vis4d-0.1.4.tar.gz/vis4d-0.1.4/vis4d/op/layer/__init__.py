"""layers op module."""
