"""Init geometry module."""
