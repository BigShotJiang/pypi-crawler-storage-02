"""3D tracking models module."""
