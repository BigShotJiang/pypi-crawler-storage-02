"""Motion operations."""
