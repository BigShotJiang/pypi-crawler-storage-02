"""Operations on 2D segmentation masks."""
