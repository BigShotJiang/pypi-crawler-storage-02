"""Contains the implementation of 2D tracking models."""
