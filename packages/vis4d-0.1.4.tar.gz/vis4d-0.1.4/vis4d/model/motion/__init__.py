"""Motion models."""
