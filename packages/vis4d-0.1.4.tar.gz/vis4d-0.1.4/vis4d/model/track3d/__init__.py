"""Contains the implementation of 3D Tracking models."""
