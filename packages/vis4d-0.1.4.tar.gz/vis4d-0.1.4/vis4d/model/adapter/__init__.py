"""Model adapters."""

from .ema import ModelEMAAdapter, ModelExpEMAAdapter

__all__ = ["ModelEMAAdapter", "ModelExpEMAAdapter"]
