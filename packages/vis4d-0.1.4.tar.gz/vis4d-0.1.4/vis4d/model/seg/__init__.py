"""Semantic segmentation models."""
