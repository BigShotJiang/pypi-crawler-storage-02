"""This module contains the model implementations of 2D detectors."""
