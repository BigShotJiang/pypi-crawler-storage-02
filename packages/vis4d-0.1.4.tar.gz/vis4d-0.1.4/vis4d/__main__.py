"""Entry point for the vis4d package."""

from .engine.run import entrypoint

entrypoint()
