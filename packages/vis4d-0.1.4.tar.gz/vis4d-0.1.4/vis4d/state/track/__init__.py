"""Memory and state for tracking algorithms."""
