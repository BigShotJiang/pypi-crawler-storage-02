"""Memory and internal states needed for models."""
