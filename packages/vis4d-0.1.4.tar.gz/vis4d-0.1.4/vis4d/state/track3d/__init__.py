"""Memory and state for 3D tracking algorithms."""
