"""Detection evaluators."""

from .detect import COCODetectEvaluator

__all__ = ["COCODetectEvaluator"]
