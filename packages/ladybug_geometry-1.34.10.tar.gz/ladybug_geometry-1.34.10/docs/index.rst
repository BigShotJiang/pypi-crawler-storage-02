Welcome to Ladybug Geometry's documentation!
============================================

.. image:: http://www.ladybug.tools/assets/img/ladybug.png

Ladybug geometry is a Python library that houses geometry objects used throughout the
Ladybug Tools core libraries.

Installation
============

``pip install -U ladybug-geometry``


.. toctree::
   :maxdepth: 3
   :caption: Contents:

.. include:: modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
