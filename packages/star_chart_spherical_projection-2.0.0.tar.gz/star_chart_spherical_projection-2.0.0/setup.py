# Python Legacy, transitioned to pyproject.toml

from setuptools import setup

setup()
