from mcp_server_wlzdgk import main

main()