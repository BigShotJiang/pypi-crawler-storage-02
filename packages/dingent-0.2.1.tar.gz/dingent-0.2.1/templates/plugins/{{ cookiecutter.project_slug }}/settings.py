from dingent.engine.plugins import ToolBaseSettings


class Settings(ToolBaseSettings):
    greeterName: str
