"""
Git-Narrate: The Repository Storyteller

A tool that analyzes a git repository and generates a human-readable story of its development.
"""

__version__ = "1.0.5"
__author__ = "Sithum Sathsara Rajapakshe | 000x"
__email__ = "SITHUMSS9122@gmail.com"