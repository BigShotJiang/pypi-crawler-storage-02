"""
Módulo de saída para geração de arquivos
"""

from .JSONGenerator import JSONGenerator

__all__ = ['JSONGenerator'] 