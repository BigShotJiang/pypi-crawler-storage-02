"""Repository for constant values in Datadoc frontend module."""

INVALID_VALUE = "Ugyldig verdi angitt!"
INVALID_DATE_ORDER = "Verdien for {contains_data_from_display_name} må være en lik eller tidligere dato som {contains_data_until_display_name}"
