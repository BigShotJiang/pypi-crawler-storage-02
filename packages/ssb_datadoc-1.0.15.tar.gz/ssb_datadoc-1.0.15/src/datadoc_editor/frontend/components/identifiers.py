SECTION_WRAPPER_ID = "section-wrapper-id"

VARIABLES_INFORMATION_ID = "variables-information"
ACCORDION_WRAPPER_ID = "accordion-wrapper"
