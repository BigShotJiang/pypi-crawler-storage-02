"""All components (UI elements) for datadoc are defined in this package.

When components use an repeated code, we should make a factory for that component, as a function in Builders.py
"""
