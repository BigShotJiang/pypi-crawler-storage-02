const language = "nb"
document.documentElement.lang = language
