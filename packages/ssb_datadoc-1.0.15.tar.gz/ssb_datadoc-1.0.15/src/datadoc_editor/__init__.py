"""Datadoc: Document datasets in Statistics Norway."""

from datadoc_editor.app import main
