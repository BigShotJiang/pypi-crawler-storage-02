"""Unit tests for the frontend.components package."""
