"""Unit tests for the frontend package."""
