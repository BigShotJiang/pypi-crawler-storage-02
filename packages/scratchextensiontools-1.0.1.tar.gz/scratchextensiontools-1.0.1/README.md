A Scratch Extension Tools.
It can help you made Scratch Extension.