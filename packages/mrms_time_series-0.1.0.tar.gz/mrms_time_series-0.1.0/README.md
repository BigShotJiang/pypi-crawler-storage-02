time series downloader
