
class GitLibException(Exception):
    """GitLibException errors."""
    pass
