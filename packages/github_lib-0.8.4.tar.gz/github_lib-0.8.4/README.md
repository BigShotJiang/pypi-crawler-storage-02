# gitlib
A Python package that extends the GitHub API for parsing links, processing diff code changes, and more.

Currently, `gitlib` is designed for GitHub interaction, but it can be extended to work with other Git services.
