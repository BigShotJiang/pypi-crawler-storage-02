# xcbm
A python module to benchmark XC functionals with PySCF and Psi4 packages on MGCDB84 Datasets.
