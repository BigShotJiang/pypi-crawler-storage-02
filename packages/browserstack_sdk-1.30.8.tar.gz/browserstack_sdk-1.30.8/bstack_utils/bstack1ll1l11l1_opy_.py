# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack1l1lll1_opy_ = 7
def bstack1ll1ll_opy_ (bstack11l1l1_opy_):
    global bstack1ll1l1_opy_
    bstack1ll1111_opy_ = ord (bstack11l1l1_opy_ [-1])
    bstack1l1l1l_opy_ = bstack11l1l1_opy_ [:-1]
    bstack11l11_opy_ = bstack1ll1111_opy_ % len (bstack1l1l1l_opy_)
    bstack1l111_opy_ = bstack1l1l1l_opy_ [:bstack11l11_opy_] + bstack1l1l1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack1l1l11l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll1l_opy_ + bstack1ll1111_opy_) % bstack1l1lll1_opy_) for bstack11ll1l_opy_, char in enumerate (bstack1l111_opy_)])
    else:
        bstack1l1l11l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll1l_opy_ + bstack1ll1111_opy_) % bstack1l1lll1_opy_) for bstack11ll1l_opy_, char in enumerate (bstack1l111_opy_)])
    return eval (bstack1l1l11l_opy_)
class bstack1l11111ll1_opy_:
    def __init__(self, handler):
        self._1llllll1lll1_opy_ = None
        self.handler = handler
        self._1llllll1ll1l_opy_ = self.bstack1llllll1llll_opy_()
        self.patch()
    def patch(self):
        self._1llllll1lll1_opy_ = self._1llllll1ll1l_opy_.execute
        self._1llllll1ll1l_opy_.execute = self.bstack1llllll1ll11_opy_()
    def bstack1llllll1ll11_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            self.handler(bstack1ll1ll_opy_ (u"ࠥࡦࡪ࡬࡯ࡳࡧࠥῥ"), driver_command, None, this, args)
            response = self._1llllll1lll1_opy_(this, driver_command, *args, **kwargs)
            self.handler(bstack1ll1ll_opy_ (u"ࠦࡦ࡬ࡴࡦࡴࠥῦ"), driver_command, response)
            return response
        return execute
    def reset(self):
        self._1llllll1ll1l_opy_.execute = self._1llllll1lll1_opy_
    @staticmethod
    def bstack1llllll1llll_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver