import enum


class env_type(enum.Enum):
    platform = False
    exe = False
