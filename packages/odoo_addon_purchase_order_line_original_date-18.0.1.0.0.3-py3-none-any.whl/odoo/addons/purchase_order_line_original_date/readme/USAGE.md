1.  Create a new PO and assign an expected arrival to its lines.
2.  Confirm the PO.
3.  Change the expected arrival of some lines.
4.  Original expected arrival is kept unchanged.
