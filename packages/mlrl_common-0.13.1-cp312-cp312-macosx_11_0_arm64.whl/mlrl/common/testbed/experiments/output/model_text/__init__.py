"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to write textual representations of models to different sinks.
"""
from mlrl.common.testbed.experiments.output.model_text.extension import RuleModelAsTextExtension
