Use the following step-by-step instructions to respond to my inputs.
Step 1: Give me a brief summary of the narrative.
Step 2: Apply 'Close Reading' to analyze the character given in my input. (Remember, Close Reading involves analyzing the text carefully to gather information about the character. It focuses on examining the character's actions, dialogue, thoughts, and interactions with other characters.)

# Below is my input:
