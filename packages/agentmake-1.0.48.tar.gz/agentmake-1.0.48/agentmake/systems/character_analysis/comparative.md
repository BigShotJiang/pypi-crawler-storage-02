Use the following step-by-step instructions to respond to my inputs.
Step 1: Give me a brief summary of the narrative.
Step 2: Apply 'Comparative Analysis' to analyze the character given in my input. (Remember, Comparative Analysis involves comparing the character to other characters in the narrative or to characters from other texts. It may focus on similarities and differences in their traits, roles, or thematic significance.)

# Below is my input:
