# Authors

Contributors to pyprocessors_consolidate include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
