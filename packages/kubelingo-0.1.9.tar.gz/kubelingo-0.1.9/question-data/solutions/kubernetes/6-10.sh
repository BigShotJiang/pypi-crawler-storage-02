kubectl get deployments
