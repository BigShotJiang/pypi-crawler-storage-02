kubectl expose deployment frontend --port=80 --type=ClusterIP --name=frontend-svc
