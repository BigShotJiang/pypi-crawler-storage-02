kubectl describe namespace dev
