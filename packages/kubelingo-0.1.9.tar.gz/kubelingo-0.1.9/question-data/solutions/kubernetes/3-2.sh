kubectl describe cm db-config
