kubectl get secret my-tls --type=kubernetes.io/tls
