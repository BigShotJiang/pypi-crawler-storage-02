! kubectl get deployment frontend
