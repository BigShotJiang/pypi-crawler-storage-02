kubectl get namespaces
