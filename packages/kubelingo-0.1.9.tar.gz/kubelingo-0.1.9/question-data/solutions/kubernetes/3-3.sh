kubectl get cm app-settings
