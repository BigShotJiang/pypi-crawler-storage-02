echo 'This question is validated by observing user runs the correct command interactively.'
