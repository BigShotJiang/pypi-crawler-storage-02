kubectl logs frontend-pod -c nginx
