kubectl replace -f configmap.yaml
