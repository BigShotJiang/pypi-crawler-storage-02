kubectl get events
