kubectl get sa
