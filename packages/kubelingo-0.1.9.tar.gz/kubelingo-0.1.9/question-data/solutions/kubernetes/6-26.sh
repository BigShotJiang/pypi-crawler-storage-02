kubectl describe configmap app-config
