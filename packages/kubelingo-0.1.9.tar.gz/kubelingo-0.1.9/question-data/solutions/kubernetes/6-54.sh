kubectl cp busybox:/tmp/data ./
