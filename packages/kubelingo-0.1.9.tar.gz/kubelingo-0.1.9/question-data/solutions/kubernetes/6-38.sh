kubectl annotate deployment frontend description=test
