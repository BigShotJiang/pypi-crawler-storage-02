kubectl delete pod busybox
