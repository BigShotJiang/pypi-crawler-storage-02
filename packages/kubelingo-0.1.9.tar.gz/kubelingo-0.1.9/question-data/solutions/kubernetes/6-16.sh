kubectl run busybox --image=busybox --restart=Never -- /bin/sh -c "sleep 3600"
