kubectl get pod nginx --show-labels | grep 'app=web,tier=frontend'
