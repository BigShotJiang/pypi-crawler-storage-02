kubectl get namespace dev
