kubectl create secret generic tls-cert --from-file=/path/to/cert.pem
