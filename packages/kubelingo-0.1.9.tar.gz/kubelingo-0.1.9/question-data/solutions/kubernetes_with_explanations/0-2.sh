alias kr='kubectl run'
