echo -n 'string' | base64
