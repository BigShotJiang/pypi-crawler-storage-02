kubectl create deployment webapp --image=nginx:1.17 --replicas=3
