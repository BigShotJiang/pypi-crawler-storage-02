alias kd='kubectl describe'
