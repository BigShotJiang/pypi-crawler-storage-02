kubectl run nginx --image=nginx --dry-run=client -o yaml > nginx.yaml
