kubectl run my-shell --rm -i --tty --image=ubuntu -- bash
