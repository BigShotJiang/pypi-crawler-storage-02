kubectl run nginx --image=nginx --env="DB_URL=postgresql://db"
