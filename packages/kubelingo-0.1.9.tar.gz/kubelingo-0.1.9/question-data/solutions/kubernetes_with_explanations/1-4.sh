kubectl get pod webapp -n development -o yaml > webapp.yaml
