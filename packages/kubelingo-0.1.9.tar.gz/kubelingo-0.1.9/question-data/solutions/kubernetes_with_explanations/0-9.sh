k get rs
