echo "source <(kubectl completion bash)" >> ~/.bashrc
