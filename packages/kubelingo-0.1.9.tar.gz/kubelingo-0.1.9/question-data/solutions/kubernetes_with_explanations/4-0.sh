kubectl create cm app-config --from-literal=APP_COLOR=blue --from-literal=APP_MODE=prod
