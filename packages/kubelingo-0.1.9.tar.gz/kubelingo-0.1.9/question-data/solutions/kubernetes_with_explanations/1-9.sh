kubectl run config-pod --image=busybox --dry-run=client -o yaml > pod.yaml # add volume and volumeMount
