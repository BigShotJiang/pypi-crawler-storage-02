class SaveDbParameterEnum:
    DEFAULT = 'default'
    SEPARATE = 'separate'

    values = {
        DEFAULT: 'БД по-умолчанию',
        SEPARATE: 'Отдельная БД',
    }
