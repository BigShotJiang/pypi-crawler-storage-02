override_settings_prefix = 'override_settings__'
replace_current_date_prefix = 'replace_current_date'
