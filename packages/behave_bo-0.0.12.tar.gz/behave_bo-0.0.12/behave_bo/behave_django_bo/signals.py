from django.dispatch import (
    Signal,
)


skip_request_check_signal = Signal()
