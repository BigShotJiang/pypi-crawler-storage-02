# XL-DURel Utils

A Python utility for tokenizing a sentence, centering a target span, truncating context if needed, and decoding back to a string.

## Installation
```bash
pip install xl-durel-utils