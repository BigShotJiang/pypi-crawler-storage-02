# Copyright (c) QuantCo 2023-2025
# SPDX-License-Identifier: BSD-3-Clause
