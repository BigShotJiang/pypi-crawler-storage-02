# Copyright (c) QuantCo 2023-2025
# SPDX-License-Identifier: BSD-3-Clause

import numpy as np

e = float(np.e)
inf = float(np.inf)
nan = float(np.nan)
pi = float(np.pi)
newaxis = None
