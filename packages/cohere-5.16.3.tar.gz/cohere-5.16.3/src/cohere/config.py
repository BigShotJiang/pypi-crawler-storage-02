embed_batch_size = 96
