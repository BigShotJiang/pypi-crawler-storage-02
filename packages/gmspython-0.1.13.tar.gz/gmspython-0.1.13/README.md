# gmsPython 
gmsPython version 0.1.x

Note: The gmsPython.gamY part of the package is almost entirely copied from the dream-tools package version 2.1.9 from PyPi.
