<p align="center">
  <a href="https://nonebot.dev/"><img src="https://nonebot.dev/logo.png" width="200" height="200" alt="nonebot"></a>
</p>

<div align="center">

# nonebot-plugin-docs

_✨ NoneBot 本地文档插件 ✨_

</div>

<p align="center">
  <a href="https://raw.githubusercontent.com/nonebot/nonebot2/master/LICENSE">
    <img src="https://img.shields.io/github/license/nonebot/nonebot2.svg" alt="license">
  </a>
  <a href="https://pypi.python.org/pypi/nonebot-plugin-docs">
    <img src="https://img.shields.io/pypi/v/nonebot-plugin-docs.svg" alt="pypi">
  </a>
  <img src="https://img.shields.io/badge/python-3.9+-blue.svg" alt="python">
</p>

## 使用方式

加载插件并启动 Bot ，在浏览器内打开 `http://host:port/website/`。

具体网址会在控制台内输出。
