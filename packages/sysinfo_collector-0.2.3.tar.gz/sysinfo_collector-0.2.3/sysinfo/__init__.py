# 系统信息获取包
from .core import get_system_info, get_cpu_info, get_memory_info

__version__ = "0.1.0"
__author__ = "yuanni"
__description__ = "一个获取电脑系统信息的Python包"