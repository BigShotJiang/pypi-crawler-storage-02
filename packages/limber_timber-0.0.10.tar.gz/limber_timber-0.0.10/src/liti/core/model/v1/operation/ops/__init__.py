""" Operation behavior

This had to be split from the data structures to avoid circular imports. ;_;
"""
