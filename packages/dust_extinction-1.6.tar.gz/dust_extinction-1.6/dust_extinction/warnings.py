class SpectralUnitsWarning(UserWarning):
    pass
