"""
Rapid evaluating Climate data
"""

import importlib.metadata

__version__ = importlib.metadata.version("climate-ref-core")
