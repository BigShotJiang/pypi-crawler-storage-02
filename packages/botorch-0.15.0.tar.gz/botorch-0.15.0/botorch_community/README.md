This directory contains methods contributed by the BoTorch community.

Each file should list the GitHub handle of its contributors, who may be asked
for help in maintaining & updating the code against future versions for BoTorch
and dependencies.
