## Overview

`ciffy` is a C program for rapidly reading `mmCIF` files into Python.

# Installation

`ciffy` is available on pip:
```
pip3 install ciffy
```
You can also clone the repo if you prefer.
