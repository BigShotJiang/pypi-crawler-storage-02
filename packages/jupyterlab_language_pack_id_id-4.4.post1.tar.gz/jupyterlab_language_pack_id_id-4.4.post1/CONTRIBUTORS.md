# Contributors

* najani ([@najani](https://crowdin.com/profile/najani))
* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Frédéric Collonval ([@fcollonval](https://crowdin.com/profile/fcollonval))
