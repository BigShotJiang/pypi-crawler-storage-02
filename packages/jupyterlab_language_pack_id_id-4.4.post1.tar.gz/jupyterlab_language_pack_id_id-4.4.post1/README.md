# Jupyterlab Indonesian (Indonesia) Language Pack

Indonesian (Indonesia) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-id-ID
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-id-ID
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
