"""Submodels to encode site-level PV data"""
