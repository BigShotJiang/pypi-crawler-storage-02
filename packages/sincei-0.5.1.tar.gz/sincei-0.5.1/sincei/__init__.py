import logging

logging.basicConfig(level=logging.INFO)
logging.getLogger("cooler").setLevel(logging.WARNING)
