
# Configuration
api_key = None

from annolab.annolab import AnnoLab
from annolab.project import Project
