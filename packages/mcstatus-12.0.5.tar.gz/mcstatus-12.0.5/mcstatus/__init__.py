from mcstatus.server import BedrockServer, JavaServer, MCServer

__all__ = [
    "BedrockServer",
    "JavaServer",
    "MCServer",
]
