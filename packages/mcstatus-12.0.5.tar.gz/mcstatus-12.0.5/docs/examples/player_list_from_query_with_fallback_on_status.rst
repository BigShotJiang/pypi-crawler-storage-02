Get player list from query, while falling back on status
========================================================

.. literalinclude:: code/player_list_from_query_with_fallback_on_status.py
