Ping many servers at once
=========================

You can ping many servers at once with mcstatus async methods, just look at

.. literalinclude:: code/ping_many_servers_at_once.py
