// Shim for extensions/core/load3d/SceneModelManager.ts
export const SceneModelManager = window.comfyAPI.SceneModelManager.SceneModelManager;
