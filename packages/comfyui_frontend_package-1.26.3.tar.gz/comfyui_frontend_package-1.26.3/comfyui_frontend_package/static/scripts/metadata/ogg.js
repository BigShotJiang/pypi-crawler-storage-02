// Shim for scripts/metadata/ogg.ts
export const getOggMetadata = window.comfyAPI.ogg.getOggMetadata;
