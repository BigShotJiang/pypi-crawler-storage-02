# blacksheep request extension.

## Installation

You can install via [pypi](https://pypi.org/project/blacksheep_client_request/)

```console
pip install -U blacksheep_client_request
```

## Usage

```python
from blacksheep_client_request import request
```
