
# THIS FILE IS GENERATED FROM SIGPROFILEREXTRACTOR SETUP.PY
short_version = '1.2.2'
version = '1.2.2'
Update = 'v1.2.2: Add mutation count and stability to 4608 plots in All_Solutions and a stop parameter'
    
    