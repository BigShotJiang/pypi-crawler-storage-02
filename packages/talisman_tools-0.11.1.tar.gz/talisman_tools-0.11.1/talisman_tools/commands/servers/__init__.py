__all__ = ('configure_server_parser',)

from .parser import configure_server_parser
