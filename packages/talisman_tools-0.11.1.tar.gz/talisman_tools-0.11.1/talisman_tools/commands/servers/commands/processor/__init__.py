__all__ = ('configure_processor_parser',)

from .parser import configure_processor_parser
