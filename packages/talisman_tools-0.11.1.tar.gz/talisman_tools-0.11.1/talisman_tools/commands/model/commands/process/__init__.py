__all__ = ('configure_process_parser',)

from .parser import configure_process_parser
