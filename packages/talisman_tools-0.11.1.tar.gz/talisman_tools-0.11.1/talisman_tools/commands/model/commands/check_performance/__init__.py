__all__ = ('configure_check_performance_parser',)

from .parser import configure_check_performance_parser
