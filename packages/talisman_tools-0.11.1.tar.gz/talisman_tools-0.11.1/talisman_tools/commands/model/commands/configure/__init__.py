__all__ = ('configure_configure_parser',)

from .parser import configure_configure_parser
