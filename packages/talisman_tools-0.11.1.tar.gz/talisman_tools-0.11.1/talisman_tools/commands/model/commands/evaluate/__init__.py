__all__ = ('configure_evaluate_parser',)

from .parser import configure_evaluate_parser
