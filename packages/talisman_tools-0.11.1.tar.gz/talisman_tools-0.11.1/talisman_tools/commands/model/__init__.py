__all__ = ('configure_model_parser',)

from .parser import configure_model_parser
