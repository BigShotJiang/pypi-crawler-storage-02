from .talisman import main

main()
