"""FastAPI Launchpad - A CLI tool to quickly scaffold FastAPI projects."""

__version__ = "0.1.0" 