"""Main entry point when running codx as a module."""

from .cli.main import app

if __name__ == "__main__":
    app()