"""Codx - A powerful code snippet manager."""

from .cli.main import app
from .main import *

__version__ = "1.0.0"

__all__ = ["app"]