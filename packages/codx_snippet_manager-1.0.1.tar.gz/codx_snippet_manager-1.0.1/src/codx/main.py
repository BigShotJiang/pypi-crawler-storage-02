"""Main entry point for codx package."""

from .cli.main import app

if __name__ == "__main__":
    app()