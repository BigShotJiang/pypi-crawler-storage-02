"""Main CLI application for codx."""

from .commands import app

if __name__ == "__main__":
    app()