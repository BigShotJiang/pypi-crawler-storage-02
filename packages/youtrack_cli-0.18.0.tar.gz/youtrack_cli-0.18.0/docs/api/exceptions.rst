Exceptions
==========

.. automodule:: youtrack_cli.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
