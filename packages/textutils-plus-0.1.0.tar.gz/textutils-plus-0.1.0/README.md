# textutils-plus

A small Python library providing simple text utilities:
- Count words
- Reverse text

## Installation
```bash
pip install textutils-plus
