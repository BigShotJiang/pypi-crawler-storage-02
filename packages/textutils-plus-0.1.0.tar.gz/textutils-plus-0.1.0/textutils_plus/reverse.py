def reverse_text(text: str) -> str:
    """Return the reversed version of the text."""
    return text[::-1]
