def word_count(text: str) -> int:
    """Return the number of words in the given text."""
    return len(text.split())
