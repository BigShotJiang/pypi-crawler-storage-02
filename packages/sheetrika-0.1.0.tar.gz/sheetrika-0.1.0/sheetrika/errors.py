class ClientInternalError(Exception):
    pass
