JotForm API Extended - Python Client


|  | Jotform API | Extended |
|---|---|---|
| User | ✔️ | ✔️ |
| Form | ✔️ | ✔️ |
| Form Questions | ✔️ | ✔️ |
| Form Properties | ✔️ | ✔️ |
| Form Submissions | ✔️ | ✔️ |
| Form Webhooks | ✔️ | ✔️ |
| Form Reports | ✔️ | ✔️ |
| Submission | ✔️ | ✔️ |
| Report | ✔️ | ✔️ |
| Folder | ✔️ | ✔️ |
| System | ✔️ | ✔️ |
| Apps | ❌ | ✔️ |
| Form Archive | ❌ | ✔️ |
| Submission Threads | ❌ | ✔️ |
| PDFs | ❌ | ✔️ |
| AI Agents | ❌ | ✔️ |
| SMTP | ❌ | ✔️ |
