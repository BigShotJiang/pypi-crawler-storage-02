"""
Module to include video handling with OpenGL.
"""
def main():
    from yta_video_opengl.tests import video_modified_stored

    video_modified_stored()


if __name__ == '__main__':
    main()