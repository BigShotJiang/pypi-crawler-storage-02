# Define the version number for the package.
__version__ = "1.0.0"
