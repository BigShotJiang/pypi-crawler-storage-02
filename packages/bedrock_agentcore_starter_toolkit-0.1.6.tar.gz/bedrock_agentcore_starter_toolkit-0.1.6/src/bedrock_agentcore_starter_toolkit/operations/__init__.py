"""BedrockAgentCore Starter Toolkit operations."""
