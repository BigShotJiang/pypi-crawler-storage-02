"""Command-line interface for srunx."""

from .main import create_main_parser, main

__all__ = ["create_main_parser", "main"]
