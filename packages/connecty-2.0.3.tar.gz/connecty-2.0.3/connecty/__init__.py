
__title__ = "connecty"
__author__ = "Znunu"
__version__ = "1.0.0"

from .gbl import GB
from .core import *
from .args import parser
