from discord.ext import commands

class Global:
    bot: commands.Bot
GB = Global()