.. include:: readme.rst

.. only: not latex

.. toctree::
   :maxdepth: 1
   :hidden:

   changelog
   setup
   auto_examples/index.rst
   api
   core_api
