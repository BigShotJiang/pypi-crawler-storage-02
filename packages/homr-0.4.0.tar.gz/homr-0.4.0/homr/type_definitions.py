from typing import Any

import numpy as np

Model = Any

NDArray = np.ndarray[Any, Any]
