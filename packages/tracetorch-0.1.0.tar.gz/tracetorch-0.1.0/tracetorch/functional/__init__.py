from ._sigmoid_inverse import sigmoid_inverse
from ._softplus_inverse import softplus_inverse
from ._sample_softmax import sample_softmax