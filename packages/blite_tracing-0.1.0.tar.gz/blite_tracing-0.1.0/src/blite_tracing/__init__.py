__version__ = "0.1.0"

from .trace import (
    start_event,
    end_event,
    event,
    reset,
    write_trace,
)
