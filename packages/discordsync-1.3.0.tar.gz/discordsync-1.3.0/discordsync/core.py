from . import d
from . import t

async def run():
    await d.main()
    await t.main()