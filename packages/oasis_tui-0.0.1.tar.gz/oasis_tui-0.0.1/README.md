# OASIS-TUI

This Python package contains the TUI for interacting with the Open Acquisition System for IEPE Sensors (OASIS).
