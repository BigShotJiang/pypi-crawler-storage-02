# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "hubmap_entity_sdk"
__version__ = "2.0.0-alpha.32"  # x-release-please-version
