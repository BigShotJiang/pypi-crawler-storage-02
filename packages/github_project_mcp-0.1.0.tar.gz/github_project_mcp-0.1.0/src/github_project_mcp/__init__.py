"""GitHub Project MCP - A Model Context Protocol server for GitHub project management"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .server import GitHubGraphQLClient

__all__ = ["GitHubGraphQLClient"]