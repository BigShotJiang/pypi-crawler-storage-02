# Project Name
A library with fast, computational math assets (mostly for personal use).
Updated regularly and uses gmpy2 for accelerated C++ computations.