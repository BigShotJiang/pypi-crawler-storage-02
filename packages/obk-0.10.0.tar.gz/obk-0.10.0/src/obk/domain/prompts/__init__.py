from .models import Prompt

__all__ = ["Prompt"]
