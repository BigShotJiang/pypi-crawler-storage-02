# intentionally empty; makes `obk.templates` a regular package for importlib.resources
