"""
Helper functions for working with the Fetch.ai uagents-core package.

All methods in this module act synchronously / blocking.
"""
