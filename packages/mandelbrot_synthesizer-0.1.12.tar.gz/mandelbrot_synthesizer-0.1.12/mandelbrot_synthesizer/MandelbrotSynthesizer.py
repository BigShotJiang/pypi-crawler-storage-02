#This is the run file
#I want to thank everyone using this application because I worked extremely hard on the development process and I had spent more than 20 hours doing so so please if you like it. consider giving it a star on the summer of making site.
from .UI import Main

def main():
    Main().run()

if __name__ == "__main__":
    main()