# additive-manufacturing
Additive Manufacturing related software modules

## Getting Started
### Installation
```bash
uv add additive-manufacturing
```

### CLI
```bash
am --help
```

### Agent
#### Claude Code
1. Install mcp server
```bash
am mcp install /path/to/your/project --claude-code
```

