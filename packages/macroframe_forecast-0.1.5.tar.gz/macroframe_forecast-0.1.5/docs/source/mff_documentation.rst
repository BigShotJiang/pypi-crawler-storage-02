Macroframework Forecasting Package API
----------------------------------

.. automodule:: macroframe_forecast.MFF
   :members:
   :member-order: groupwise
   :show-inheritance:


.. automodule:: macroframe_forecast.MFF_mixed_frequency
   :members:
   :member-order: groupwise
   :show-inheritance:


.. automodule:: macroframe_forecast.utils
   :members:
   :member-order: groupwise
   :show-inheritance:
