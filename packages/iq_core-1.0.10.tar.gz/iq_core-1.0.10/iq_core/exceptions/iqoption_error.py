class IQOptionError(Exception):
    """
    🇧🇷 Exceção base para a biblioteca IQ Option.

    🇺🇸 Base exception for IQ Option library.
    """

    pass
