"""WebSocket communication layer for IQ Option"""

from .client import WebSocketClient

__all__ = ["WebSocketClient"]
