from salute.common.models import *
