from .card_decorator import TrackedResourcesCard

CARDS = [TrackedResourcesCard]
