"""
This module contains Sinks developed and maintained by the members of Quix Streams community.
"""
