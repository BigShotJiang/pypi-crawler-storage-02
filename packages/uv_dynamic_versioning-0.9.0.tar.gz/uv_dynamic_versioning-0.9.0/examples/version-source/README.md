# Version Source Example

An example project of `uv-dynamic-versioning`'s version source.

```bash
pip install uv
uv build
```
