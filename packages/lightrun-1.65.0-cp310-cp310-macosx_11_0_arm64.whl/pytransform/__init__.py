# Pyarmor 8.4.7 (basic), 004363, 2025-08-10T18:49:43.580984
from .pyarmor_runtime import __pyarmor__
