Requirements
=================

To access the API, you will need an API Key. Contact us `here <https://predictionguard.com/get-started>`_ to get started.
