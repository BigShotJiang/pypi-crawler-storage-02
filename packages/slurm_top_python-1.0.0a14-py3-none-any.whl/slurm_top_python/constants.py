PRIVILEGED_USERS = [
    'root',
    'administrator'
]

INVALID_PROCESSES = [
	'zombie'
]

# This will be overriden by process sensor
SYSTEM_USERS = []