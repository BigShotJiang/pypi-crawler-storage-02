# ~/rslv/src/rslv/__init__.py
"""
Runtime Resolution
"""

__version__ = "0.0.0"
__author__ = "Joel Yisrael"

VERSION = tuple(map(int, __version__.split('.')))
