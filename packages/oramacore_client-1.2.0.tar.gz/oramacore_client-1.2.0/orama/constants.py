"""
Constants for Orama Python client (server-side only).
"""

# Default user ID for server environments
DEFAULT_SERVER_USER_ID = 'server-user-default'