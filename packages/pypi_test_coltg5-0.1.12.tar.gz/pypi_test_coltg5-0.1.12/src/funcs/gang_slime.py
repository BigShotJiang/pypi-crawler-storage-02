import numpy as np


def slime_u_out(x: np.int32):
    return x * 2
