"""Rich Coverage - Beautiful code coverage reporting."""

from .cli import rich_coverage_cli

__all__ = ["rich_coverage_cli"]
