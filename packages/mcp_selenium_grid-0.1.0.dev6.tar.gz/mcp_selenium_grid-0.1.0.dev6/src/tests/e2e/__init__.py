"""End-to-end tests for MCP Server."""
