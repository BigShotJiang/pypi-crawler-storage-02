from . import aeat_vat_book_map_line
from . import l10n_es_vat_book
from . import l10n_es_vat_book_line
from . import l10n_es_vat_book_line_tax
from . import l10n_es_vat_book_summary
from . import l10n_es_vat_book_tax_summary
