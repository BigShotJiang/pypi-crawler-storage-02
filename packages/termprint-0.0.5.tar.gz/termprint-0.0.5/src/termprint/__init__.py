# SPDX-FileCopyrightText: 2024-present Thorsten Hapke <thorsten.hapke@sap.com>
#
# SPDX-License-Identifier: MIT
