# SPDX-FileCopyrightText: 2024-present Thorsten Hapke <thorsten.hapke@sap.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
