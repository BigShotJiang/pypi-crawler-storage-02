# Example Summarize the CSV filer

This is a MCP server in Python that provides  `summarize_csv_file` tool.

## Installation
```bash
pip install summarize-csv-file