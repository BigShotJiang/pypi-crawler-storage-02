# main.py
from server import mcp

def run():
    mcp.run()

if __name__ == "__main__":
    run()
