2025-05-29 Version: 1.3.2
- Update API DescribeCenAttachedChildInstanceAttribute: add response parameters Body.ManagedService.
- Update API DescribeCenAttachedChildInstances: add response parameters Body.ChildInstances.$.ManagedService.
- Update API ListTransitRouterVpcAttachments: add response parameters Body.TransitRouterAttachments.$.ManagedService.


2025-04-11 Version: 1.3.1
- Update API DeleteTrafficMarkingPolicy: add request parameters Force.


2025-02-28 Version: 1.3.0
- Support API ModifyTransitRouteTableAggregation.
- Update API CreateTransitRouteTableAggregation: add param TransitRouteTableAggregationScopeList.
- Update API DescribeTransitRouteTableAggregation: update response param.


2025-01-17 Version: 1.2.3
- Update API CreateTransitRouteTableAggregation: update param TransitRouteTableAggregationScope.


2025-01-06 Version: 1.2.2
- Update API CreateTransitRouterMulticastDomain: add param Options.
- Update API ListTransitRouterMulticastDomains: update response param.
- Update API ModifyTransitRouterMulticastDomain: add param Options.


2024-11-15 Version: 1.2.1
- Update API ActiveFlowLog: update param CenId.
- Update API CreateFlowlog: add param LogFormatString.
- Update API CreateFlowlog: add param TransitRouterId.
- Update API CreateTransitRouterVpnAttachment: update param Zone.
- Update API DeactiveFlowLog: update param CenId.
- Update API DeleteFlowlog: update param CenId.
- Update API DescribeCenChildInstanceRouteEntries: update response param.
- Update API DescribeFlowlogs: add param FlowLogVersion.
- Update API DescribeFlowlogs: add param Interval.
- Update API DescribeFlowlogs: add param TransitRouterId.
- Update API ModifyFlowLogAttribute: add param Interval.
- Update API ModifyFlowLogAttribute: update param CenId.


2024-10-21 Version: 1.2.0
- Support API ModifyTrafficMatchRuleToTrafficMarkingPolicy.
- Update API CreateCenRouteMap: add param DestinationRegionIds.
- Update API CreateTransitRouterMulticastDomain: update response param.
- Update API DescribeCenRouteMaps: update response param.
- Update API ModifyCenRouteMap: add param DestinationRegionIds.


2024-09-11 Version: 1.1.7
- Update API AddTrafficMatchRuleToTrafficMarkingPolicy: update param TrafficMatchRules.
- Update API CreateTrafficMarkingPolicy: update param TrafficMatchRules.
- Update API CreateTransitRouterVpcAttachment: add param TransitRouterVPCAttachmentOptions.
- Update API DescribeGrantRulesToCen: add param EnabledIpv6.
- Update API ListGrantVSwitchesToCen: add param EnabledIpv6.
- Update API ListTrafficMarkingPolicies: update response param.
- Update API ListTransitRouterVpcAttachments: update response param.
- Update API UpdateTrafficMarkingPolicyAttribute: update param AddTrafficMatchRules.
- Update API UpdateTrafficMarkingPolicyAttribute: update param DeleteTrafficMatchRules.
- Update API UpdateTransitRouterVpcAttachmentAttribute: add param TransitRouterVPCAttachmentOptions.


2024-08-28 Version: 1.1.6
- Update API AssociateTransitRouterMulticastDomain: update param VSwitchIds.
- Update API CreateCenInterRegionTrafficQosPolicy: add param BandwidthGuaranteeMode.
- Update API CreateCenInterRegionTrafficQosPolicy: update param TrafficQosQueues.
- Update API CreateCenInterRegionTrafficQosQueue: add param Bandwidth.
- Update API DisassociateTransitRouterMulticastDomain: update param VSwitchIds.
- Update API ListCenInterRegionTrafficQosPolicies: update response param.
- Update API ListCenInterRegionTrafficQosQueues: add param EffectiveBandwidthFilter.
- Update API ListCenInterRegionTrafficQosQueues: update response param.
- Update API UpdateCenInterRegionTrafficQosQueueAttribute: add param Bandwidth.


2024-08-16 Version: 1.1.5
- Update API CreateCenInterRegionTrafficQosPolicy: update param TrafficQosQueues.
- Update API CreateCenInterRegionTrafficQosQueue: update param RemainBandwidthPercent.


2024-07-10 Version: 1.1.4
- Generated python 2017-09-12 for Cbn.

2024-06-13 Version: 1.1.3
- Update API CreateFlowlog: update response param.
- Update API DescribeFlowlogs: update response param.
- Update API ListTransitRouterVpnAttachments: update response param.


2024-05-22 Version: 1.1.2
- Update API CreateFlowlog: update response param.
- Update API DescribeFlowlogs: update response param.


2024-05-17 Version: 1.1.1
- Update API DescribeCenInterRegionBandwidthLimits: update response param.
- Update API ListTransitRouterVpcAttachments: update response param.
- Update API SetCenInterRegionBandwidthLimit: add param BandwidthType.


2024-03-25 Version: 1.1.0
- Support API CreateTransitRouterEcrAttachment.
- Support API DeleteTransitRouterEcrAttachment.
- Support API ListTransitRouterEcrAttachments.
- Support API UpdateTransitRouterEcrAttachmentAttribute.
- Update API DeleteTransitRouterVbrAttachment: update response param.


2024-02-21 Version: 1.0.40
- Update API DeleteTransitRouterVbrAttachment: update response param.


2024-01-19 Version: 1.0.39
- Generated python 2017-09-12 for Cbn.

2024-01-18 Version: 1.0.38
- Generated python 2017-09-12 for Cbn.

2023-12-15 Version: 1.0.37
- Generated python 2017-09-12 for Cbn.

2023-11-23 Version: 1.0.36
- Generated python 2017-09-12 for Cbn.

2023-10-21 Version: 1.0.35
- Generated python 2017-09-12 for Cbn.

2023-09-12 Version: 1.0.34
- Generated python 2017-09-12 for Cbn.

2023-09-08 Version: 1.0.33
- Generated python 2017-09-12 for Cbn.

2023-08-08 Version: 1.0.32
- Generated python 2017-09-12 for Cbn.

2023-08-08 Version: 1.0.31
- Generated python 2017-09-12 for Cbn.

2023-07-13 Version: 1.0.30
- Update API ListTransitRouterRouteEntries to support PathAttributes.

2023-05-23 Version: 1.0.29
- Update API DescribeGrantRulesToCen support ChildInstanceOwnerId and ChildInstanceId.

2023-04-27 Version: 1.0.28
- Update API DescribeCenAttachedChildInstanceAttribute support returning VPC Cidrs.

2023-03-17 Version: 1.0.27
- Update API CreateTransitRouteTableAggregation update request parameter TransitRouteTableAggregationScop to TransitRouteTableAggregationScope.
- Update API DescribeTransitRouteTableAggregation update response parameter Scop to Scope.

2023-03-13 Version: 1.0.26
- Update API DescribeCens support parameter resourceGroupId.
- Update API DescribeCens support parameter resourceGroupId, tag and response resourceGroupId, tags.

2023-01-13 Version: 1.0.25
- New API CreateTransitRouteTableAggregation.
- New API DeleteTransitRouteTableAggregation.
- New API DescribeTransitRouteTableAggregation.
- New API DescribeTransitRouteTableAggregationDetail.
- New API RefreshTransitRouteTableAggregation.
- Update API CreateTransitRouterRouteTable support parameter RouteTableOptions.
- Update API UpdateTransitRouterRouteTable support parameter RouteTableOptions.
- Update API ListTransitRouterRouteTables support parameter RouteTableOptions and response RegionId, RouteTableOptions.
- Update API UpdateTrafficMarkingPolicyAttribute support parameter AddTrafficMatchRules and DeleteTrafficMatchRules.
- Update API ListTransitRouters support parameter Status, Type, TransitRouterName and FeatureFilter.
- Update API DescribeFlowlogs support response TransitRouterAttachmentId and Interval.
- Update API ListTransitRouterVpcAttachments support parameter OrderType, Status and response OrderType.
- Update API ListTransitRouterRouteTableAssociations support parameter TransitRouterAttachmentResourceId, TransitRouterAttachmentResourceType and Status.
- Update API ListTransitRouterRouteTablePropagations support parameter TransitRouterAttachmentResourceId, TransitRouterAttachmentResourceType and Status.

2022-12-08 Version: 1.0.24
- Add ListCenChildInstanceRouteEntriesToAttachment support query VPC instance route to Vpc Attachment.
- Add ListTransitRouterAttachmentPropagations support query TransitRouter Propagations by Attachment Id.
- ListTransitRouterMulticastGroups: add parameter isGroupSource, isGroupMember and NetworkInterfaceIds. add response TransitRouterMulticastDomainId. 
- ListMulticastDomains: add response TransitRouterId.
- ListCenInterRegionTrafficQosPolicies: add response TransitRouterId and TransitRouterAttachmentId. 
- ListTrafficMarkingPolicies: add response TransitRouterId.
- DescribeFlowlogs: add parameter TransitRouterAttachmentId.
- DeleteTransitRouterConnectPeer: add ErrorCode.
- ListTransitRouterVpcAttachments: add parameter VpcId.
- ListTransitRouterMulticastGroups: param TransitRouterMulticastDomainId Required False.
- DeleteTransitRouterConnectAttachment: add parameter Force.
- DeleteTransitRouterVpcAttachment : add parameter Force.
- DeleteTransitRouterVpnAttachment : add parameter Force.
- DeleteTransitRouterVbrAttachment : add parameter Force.

2022-11-28 Version: 1.0.23
- Add CreateTransitRouterCidr support create TR Cidr.
- Add ModifyTransitRouterCidr support modify TR Cidr.
- Add DeleteTransitRouterCidr support delete TR Cidr.
- Add ListTransitRouterCidr support list TR Cidr.
- Add ListTransitRouterCidrAllocation support list TR Cidr allocation.
- Update CreateTransitRouter support TR Cidr list.
- Update ListTransitRouters support Cidr list.
- Update ListTransitRouterVpnAttachments response support ChargeType.
- CreateFlowlog add parameter tag.
- DescribeFlowlogs add parameter tag and add response tags.
- CreateTransitRouterMulticastDomain add parameter tag.
- ListTransitRouterMulticastDomains add parameter tag and add response tags.
- CreateTransitRouterRouteTable add parameter tag.
- ListTransitRouterRouteTables add parameter tag and add response tags.
- CreateTransitRouter add parameter tag.
- ListTransitRouters add parameter tag and add response tags.

2022-11-22 Version: 1.0.22
- Update ListTransitRouterMulticastGroups offline parameter ConnectPeerId.
- Update CreateCenBandwidthPackage offline parameter ServiceType.
- Update ModifyCenBandwidthPackageSpec offline parameter ServiceType.
- Update DescribeCenBandwidthPackages offline parameter ServiceType.

2022-11-02 Version: 1.0.21
- Update ListTransitRouterPrefixListAssociation support NextHop and NextHopType filter.
- Update ListTransitRouterPrefixListAssociation support TransitRouterRouteTableId  filter.
- Update ListTrafficMarkingPolicies no TrafficMatchRules field in response if no TrafficMarkingPolicyId in request.
- Update ListCenInterRegionTrafficQosPolicies no TrafficQosQueues field in response if no TrafficQosPolicyId in request.

2022-09-23 Version: 1.0.20
- Add new API DescribeGrantRulesToResource .
- Update DescribeGrantRulesToCen support MaxResult and nextToken .
- Update ListTransitRouterPrefixlistAssociation return TransitRouterId and TransitRouterTableId .

2022-08-26 Version: 1.0.19
- Update param NextHopType visibility for DeleteTransitRouterPrefixListAssociation .

2022-08-26 Version: 1.0.18
- Add AvailableZones for ListTransitRouterAvailableResource.

2022-04-27 Version: 1.0.17
- update to latest.

2022-04-15 Version: 1.0.16
- Support Multicast.
- RouteMap Support sub-table.

2022-03-10 Version: 1.0.15
- Modify the input parameter Action of CreateCen to be required.

2022-01-11 Version: 1.0.14
- Support  DeleteTransitRouter API.

2021-12-21 Version: 1.0.13
- Support Darabonba API.

2021-05-06 Version: 1.0.2
- Generated python 2017-09-12 for Cbn.

2021-04-23 Version: 1.0.1
- Generated python 2017-09-12 for Cbn.

2020-12-29 Version: 1.0.0
- AMP Version Change.

