from oasislmf.pytools.common.data import cdf_headers, cdf_dtype, cdf_fmt


headers = cdf_headers
dtype = cdf_dtype
fmt = cdf_fmt
cli_support = ['bintocsv']
