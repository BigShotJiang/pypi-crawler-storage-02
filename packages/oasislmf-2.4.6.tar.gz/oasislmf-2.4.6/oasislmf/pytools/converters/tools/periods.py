from oasislmf.pytools.common.data import periods_headers, periods_dtype, periods_fmt


headers = periods_headers
dtype = periods_dtype
fmt = periods_fmt
cli_support = ['bintocsv', 'csvtobin']
