from oasislmf.pytools.common.data import gul_summary_xref_headers, gul_summary_xref_dtype, gul_summary_xref_fmt


headers = gul_summary_xref_headers
dtype = gul_summary_xref_dtype
fmt = gul_summary_xref_fmt
cli_support = ['bintocsv', 'csvtobin']
