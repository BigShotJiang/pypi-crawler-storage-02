from oasislmf.pytools.aal.data import ALCT_headers, ALCT_dtype, ALCT_fmt


headers = ALCT_headers
dtype = ALCT_dtype
fmt = ALCT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
