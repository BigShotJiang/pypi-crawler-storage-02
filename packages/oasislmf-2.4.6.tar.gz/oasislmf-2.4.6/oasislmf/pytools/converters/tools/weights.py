from oasislmf.pytools.common.data import vulnerability_weight_headers, vulnerability_weight_dtype, vulnerability_weight_fmt


headers = vulnerability_weight_headers
dtype = vulnerability_weight_dtype
fmt = vulnerability_weight_fmt
cli_support = ['bintocsv', 'csvtobin']
