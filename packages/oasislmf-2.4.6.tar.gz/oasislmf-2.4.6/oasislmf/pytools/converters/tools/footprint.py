from oasislmf.pytools.common.data import footprint_event_headers, footprint_event_dtype, footprint_event_fmt


headers = footprint_event_headers
dtype = footprint_event_dtype
fmt = footprint_event_fmt
cli_support = ['bintocsv', 'csvtobin']
