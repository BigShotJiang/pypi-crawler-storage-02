from oasislmf.pytools.common.data import quantile_headers, quantile_dtype, quantile_fmt


headers = quantile_headers
dtype = quantile_dtype
fmt = quantile_fmt
cli_support = ['bintocsv', 'csvtobin']
