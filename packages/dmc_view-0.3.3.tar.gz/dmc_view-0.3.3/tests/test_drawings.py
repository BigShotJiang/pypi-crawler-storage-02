def test_draw_cardinal_points():
    assert 4 == 4
