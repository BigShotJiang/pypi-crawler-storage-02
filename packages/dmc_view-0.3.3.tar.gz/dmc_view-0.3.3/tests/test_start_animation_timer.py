def test_start_animation_timer():
    assert True
