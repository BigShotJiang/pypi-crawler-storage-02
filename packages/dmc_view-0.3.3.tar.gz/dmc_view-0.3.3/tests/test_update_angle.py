def test_update_declination():

    assert 45.55 == 45.55
