# Testing animate_declination() method from compass.py


def test_animate_declination():

    assert 1 == 1
