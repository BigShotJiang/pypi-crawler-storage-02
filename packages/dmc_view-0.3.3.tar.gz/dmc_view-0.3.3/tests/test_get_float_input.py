def test_get_float_input_with_valid_input():
    assert 42.5 == 42.5
