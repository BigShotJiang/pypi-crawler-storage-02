def test_rotate_angle():
    assert 0 == 0
