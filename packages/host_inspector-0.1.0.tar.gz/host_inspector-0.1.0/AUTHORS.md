# Authors

Host Info is written and maintained by Tim Santor and various contributors:

## Development Lead

- Tim Santor <tsantor@xstudios.com>

## Contributors

None yet. Why not be the first?
