from .base_config import Config


__all__ = ["Config"]
