def import_in_function():
    from . import func_import_target
