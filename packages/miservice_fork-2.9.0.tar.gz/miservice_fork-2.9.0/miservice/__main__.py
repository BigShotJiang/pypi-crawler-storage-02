#!/usr/bin/env python3
from miservice.cli import micli

if __name__ == "__main__":
    micli()
