URL_LOGIN = "https://magma.esdm.go.id/api/login"
URL_VALIDATE_TOKEN = "https://magma.esdm.go.id/api/status"
URL_LOGIN_STAKEHOLDER = "https://magma.esdm.go.id/api/login/stakeholder"
