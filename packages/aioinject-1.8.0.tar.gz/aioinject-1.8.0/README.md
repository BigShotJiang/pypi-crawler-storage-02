Async-first dependency injection library based on python type hints,
see [documentation](https://notypecheck.github.io/aioinject/)

## Installation
Install using pip `pip install aioinject`
