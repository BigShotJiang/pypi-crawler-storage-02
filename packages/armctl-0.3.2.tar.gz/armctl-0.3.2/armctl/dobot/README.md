# Dobot

## Documentation

> [!Note]
> Comprehensive documentation for the Dobot is limited, reflecting the incomplete state of controller support in this project. English resources may be sparse or unofficial.

- Serial Communication Guide ([Community Post](https://www.littlechip.co.nz/blog/communicating-with-the-dobot-magician-using-raw-protocol))

- Magician Pro ([Handbook](https://wiki.idiot.io/_media/dobot-magician-user-guide-v1.7.0.pdf))