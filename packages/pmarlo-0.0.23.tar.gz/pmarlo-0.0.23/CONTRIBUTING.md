1. Install Poetry & run `poetry install --with dev`.
2. Run `pre-commit install` once.
3. Make changes; all hooks should pass before pushing.
