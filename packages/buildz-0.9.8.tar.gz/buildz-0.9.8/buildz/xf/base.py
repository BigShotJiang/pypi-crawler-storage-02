
from buildz import Base, Args
# class Args(Base):
#     def size(self):
#         return len(self.args)+len(self.maps)
#     def str(self):
#         return f"<Args args={self.args}, maps={self.maps}>"
#     @property
#     def lists(self):
#         return self.args
#     @lists.setter
#     def lists(self, val):
#         self.args=val
#     @lists.deleter
#     def lists(self):
#         del self.args
#     @property
#     def dicts(self):
#         return self.maps
#     @dicts.setter
#     def dicts(self, val):
#         self.maps=val
#     @dicts.deleter
#     def dicts(self):
#         del self.maps
#     def init(self, args, maps):
#         self.args = args
#         self.maps = maps

# pass