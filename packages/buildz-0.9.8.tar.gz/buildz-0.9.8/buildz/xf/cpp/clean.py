#
from buildz import fz
fz.removes("./build")
fz.removes("./pcxf.c")
fz.removes("./pcxf.cpp")
fz.removes("./pcxf.o")