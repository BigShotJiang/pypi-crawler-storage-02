calls: [test,test]
fc: Test.test
test.fc: Test.test
test: {
    val: 123
}