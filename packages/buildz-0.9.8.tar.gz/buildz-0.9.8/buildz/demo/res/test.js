{
    /*
        这里有三行注释
        这里有三行注释
        这里有三行注释
    */
    name: 测试配置
    ###
        还是注释
        steal is note
    ###
    data: [
        (1,.2,.03,4e-4,500)
        {
            // 中文当key
            代号=嘿嘿
            age = ???
            # 字符串里有特殊符合，还是要用引号括起来
            # if special charater is contained  in string, use '' or "" to wrap string
            'a:b':"{c,d,e,f}"
            <1,int>=<0,bool>
        }
    ]
}