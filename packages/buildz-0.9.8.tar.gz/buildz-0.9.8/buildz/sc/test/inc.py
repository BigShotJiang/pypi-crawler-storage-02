#
def fc():
    print("includexxx", __name__)