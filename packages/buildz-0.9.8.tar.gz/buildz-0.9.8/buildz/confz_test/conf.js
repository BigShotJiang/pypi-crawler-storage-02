calls: [test.xtest]
test: {
    xtest: {
        fc: buildz.confz_test.test.xtest
    }
}