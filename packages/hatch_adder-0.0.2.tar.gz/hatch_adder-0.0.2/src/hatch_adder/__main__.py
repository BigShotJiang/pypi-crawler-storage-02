import sys

if __name__ == "__main__":
    from hatch_adder.cli import hatch_adder

    sys.exit(hatch_adder())
