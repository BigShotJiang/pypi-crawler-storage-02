name = "py-listener"
version = "1.1.0"
github = f"https://github.com/n1teshy/{name}"
