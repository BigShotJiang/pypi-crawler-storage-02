# Makes the package importable
"""GitGenius CLI - A tool to explain Git errors in a friendly way."""

__version__ = "0.1.0"
__author__ = "Selva Neyas U"
__license__ = "MIT"