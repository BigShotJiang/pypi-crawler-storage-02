from .msdb import DB, register_db_name, create_db, get_config_file, get_db_names, update_db_folder, delete_db

__version__ = "0.0.8"
