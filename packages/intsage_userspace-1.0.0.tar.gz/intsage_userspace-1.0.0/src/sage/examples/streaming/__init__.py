"""
SAGE Streaming Examples - 流处理示例

这个模块包含了流处理和实时数据处理的示例。
"""

# 导入所有流处理示例
# from . import kafka_query
# from . import multiple_pipeline

__all__ = []  # 根据实际示例文件更新
