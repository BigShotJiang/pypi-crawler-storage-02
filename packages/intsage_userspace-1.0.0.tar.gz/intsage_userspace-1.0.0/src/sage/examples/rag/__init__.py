"""
SAGE RAG Examples - 检索增强生成示例

这个模块包含了各种 RAG (Retrieval-Augmented Generation) 的实现示例。
"""

# 导入所有RAG示例（这里需要根据实际文件调整）
# from . import rag_simple
# from . import qa_dense_retrieval

__all__ = []  # 根据实际示例文件更新
