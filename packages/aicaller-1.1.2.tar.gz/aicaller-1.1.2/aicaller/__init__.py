# -*- coding: UTF-8 -*-
"""
Created on 15.11.24

:author:     Martin Dočekal
"""
