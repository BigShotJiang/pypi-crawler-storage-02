Algorithms
==========

The following algorithms are considered in this benchmarking report.
{% for algo_name, algo_description in algorithms.items() %}
{{ algo_name }}
   {{ algo_description }}
{% endfor %}
