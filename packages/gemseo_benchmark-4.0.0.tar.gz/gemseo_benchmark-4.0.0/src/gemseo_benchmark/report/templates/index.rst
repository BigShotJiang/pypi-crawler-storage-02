.. Benchmarking Report documentation master file, created by
   sphinx-quickstart on Mon Apr 12 16:10:25 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root ``toctree`` directive.

Benchmarking report
===================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

{% for document in documents %}   {{document}}
{% endfor %}
