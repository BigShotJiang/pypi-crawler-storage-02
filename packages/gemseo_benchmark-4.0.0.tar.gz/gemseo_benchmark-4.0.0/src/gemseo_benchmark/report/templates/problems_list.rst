Problem configurations
======================

.. toctree::
   :maxdepth: 1
   :caption: The benchmarking reference problems are listed below.

{% for problem_path in problems_paths %}   {{problem_path}}
{% endfor %}
