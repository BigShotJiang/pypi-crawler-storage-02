Results
=======

.. toctree::
   :maxdepth: 2
   :caption: The results of each group of algorithms configurations
             on each group of problem configurations.

{% for algos_toctree in documents %}   /{{ algos_toctree }}
{% endfor %}
