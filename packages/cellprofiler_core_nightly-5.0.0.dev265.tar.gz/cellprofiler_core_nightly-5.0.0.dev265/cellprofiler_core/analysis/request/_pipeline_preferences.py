from ...utilities.zmq.communicable.request import AnalysisRequest


class PipelinePreferences(AnalysisRequest):
    pass
