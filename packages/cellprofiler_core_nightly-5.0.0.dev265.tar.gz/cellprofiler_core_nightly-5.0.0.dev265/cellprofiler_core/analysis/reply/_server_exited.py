from ...utilities.zmq.communicable.reply import UpstreamExit


class ServerExited(UpstreamExit):
    pass
