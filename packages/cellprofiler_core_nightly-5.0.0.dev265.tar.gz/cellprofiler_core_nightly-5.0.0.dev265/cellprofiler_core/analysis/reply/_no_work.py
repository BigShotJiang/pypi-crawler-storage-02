from ...utilities.zmq.communicable.reply import Reply


class NoWork(Reply):
    pass
