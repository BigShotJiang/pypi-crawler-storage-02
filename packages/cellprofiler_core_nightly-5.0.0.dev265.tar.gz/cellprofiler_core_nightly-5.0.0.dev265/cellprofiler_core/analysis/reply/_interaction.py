from ...utilities.zmq.communicable.reply import Reply


class Interaction(Reply):
    pass
