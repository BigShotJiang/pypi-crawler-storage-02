class RelationshipKey:
    def __init__(self, module_number, relationship, object_name1, object_name2):
        self.module_number = module_number
        self.relationship = relationship
        self.object_name1 = object_name1
        self.object_name2 = object_name2
