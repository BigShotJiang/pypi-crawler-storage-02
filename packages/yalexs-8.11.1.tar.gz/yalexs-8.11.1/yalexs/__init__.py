"""Init file for yalexs."""

__author__ = """J. Nick Koston"""
__email__ = "nick@koston.org"
__version__ = "8.11.1"
