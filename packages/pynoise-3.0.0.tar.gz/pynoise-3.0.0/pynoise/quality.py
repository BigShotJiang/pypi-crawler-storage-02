from enum import Enum

class Quality(Enum):
    fast = 1
    std = 2
    best = 3
