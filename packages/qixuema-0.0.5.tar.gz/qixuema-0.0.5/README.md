# m-utils
utils for saving my life

```
pip install qixuema
```
