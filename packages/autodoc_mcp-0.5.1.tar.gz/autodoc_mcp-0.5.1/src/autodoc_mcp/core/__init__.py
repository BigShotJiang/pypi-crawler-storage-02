"""Core components for AutoDocs MCP Server."""
