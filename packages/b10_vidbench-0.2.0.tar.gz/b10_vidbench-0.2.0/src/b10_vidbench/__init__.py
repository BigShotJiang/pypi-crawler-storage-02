"""B10 Video Benchmark - Simple video quality analysis using VBench."""

from .analyzer import VideoAnalyzer

__version__ = "0.2.0"
__all__ = ["VideoAnalyzer"]
