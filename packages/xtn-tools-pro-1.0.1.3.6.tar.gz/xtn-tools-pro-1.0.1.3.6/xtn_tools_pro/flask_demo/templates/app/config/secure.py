#!/usr/bin/env python
# -*- coding: utf-8 -*-

DEBUG = True

SECRET_KEY = "6d9d1e582d50eb948fa9b6"

# redis
REDIS_01_URL = 'redis://:密码@ip:端口/0'
REDIS_02_URL = 'redis://:密码@ip:端口/1'

# mongo
MONGO_URI_01 = "mongodb://用户名:密码@ip:端口/库?authSource=admin"
