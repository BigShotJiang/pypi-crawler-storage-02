:icon: material/arrow-right-bottom

Basic Man-Machine Interface
===========================

.. automodule:: geocompy.geo.bmm
    :inherited-members:

    Definitions
    -----------
