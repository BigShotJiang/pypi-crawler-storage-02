# asks request extension.

## Installation

You can install via [pypi](https://pypi.org/project/asks_request/)

```console
pip install -U asks_request
```

## Usage

```python
from asks_request import request
```
