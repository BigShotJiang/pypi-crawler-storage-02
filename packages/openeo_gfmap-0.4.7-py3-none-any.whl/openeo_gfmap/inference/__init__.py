"""This module contains the base classes for inference models. The base classes
provide some common methods and attributes to be used by other inference models.
"""
