"""Definitions of the constants in the STAC collection
"""
