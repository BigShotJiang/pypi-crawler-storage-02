#ifndef CORE32_H
#define CORE32_H

int main32(int argc, char *argv[]);

#endif // CORE32_H