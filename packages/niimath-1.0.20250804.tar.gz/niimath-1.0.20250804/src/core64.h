#ifndef CR_CORE64_H
#define CR_CORE64_H

#ifdef  __cplusplus
extern "C" {
#endif

	int main64(int argc, char * argv[]);

#ifdef  __cplusplus
}
#endif

#endif //CR_CORE64_H




