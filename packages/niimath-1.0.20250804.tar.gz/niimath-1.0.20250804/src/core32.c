#undef DT32
#define DT32 //<- This should be the ONLY difference between core32 and core64!
#include "coreFLT.c"
