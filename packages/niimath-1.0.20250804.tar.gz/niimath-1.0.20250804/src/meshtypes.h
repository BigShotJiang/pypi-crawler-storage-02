#ifndef MESHIFY_TYPES_H
#define MESHIFY_TYPES_H

typedef struct {
	double x,y,z;
} vec3d;

typedef struct {
	int x,y,z;
} vec3i;

#endif /* MESHIFY_TYPES_H */