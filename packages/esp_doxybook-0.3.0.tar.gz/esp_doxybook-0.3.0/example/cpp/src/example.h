/*! \mainpage My Personal Index Page
 *
 * \section intro_sec Introduction
 *
 * This is the introduction.
 *
 * \section install_sec Installation
 *
 * \subsection step1 Step 1: Opening the box
 *
 * etc...
 */

#include "animal.h"
#include "bird.h"
#include "utils/exception.h"

/*!
 * @example hello_world.cpp
 * This is a brief description to hello world example
 * Lorem Ipsum Donor
 */
