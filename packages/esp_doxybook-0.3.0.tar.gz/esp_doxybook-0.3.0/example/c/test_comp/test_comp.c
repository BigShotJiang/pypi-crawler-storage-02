#include <stdio.h>
#include "include/test_comp1.h"

void print1(void)
{
    printf("hello world");
}

void add1(int a, int b)
{
    printf("%d", a + b);
}
