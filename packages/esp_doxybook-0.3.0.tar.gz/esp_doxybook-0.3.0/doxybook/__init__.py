"""
Convert Doxygen XML output into a single-file API reference in Markdown format.
"""

__version__ = '0.3.0'
