# Copyright (c) 2025 by Terry Greeniaus.
# All rights reserved.
from .flask_simple_tsdb import SimpleTSDB


__all__ = [
    'SimpleTSDB',
]
