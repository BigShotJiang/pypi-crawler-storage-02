# entrel
Generate simple Entity Relationship diagrams in LaTeX from TOML files.
