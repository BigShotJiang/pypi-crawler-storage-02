# chopify

"Chopify" your words.

## Installation

```bash
pip install chopify
```

## Quick Example

```python
from chopify import chopify

chopify("unc")
>> "chunc"
```
