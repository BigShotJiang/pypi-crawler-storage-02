#!/usr/bin/env python3

"""lintok: A compact, colorful linter for checking file size metrics."""

from .cli import main

if __name__ == "__main__":
    main()
