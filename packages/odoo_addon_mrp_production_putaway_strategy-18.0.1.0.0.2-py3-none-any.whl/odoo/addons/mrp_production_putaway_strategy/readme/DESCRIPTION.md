This module allows to apply putaway strategies to the products resulting
from the manufacturing orders.

The finished products will be placed in the location designated by the
putaway strategy (if they do not have another destination move), based
on the finished products location that was defined in the manufacturing
order.
