To configure a putaway strategy follow the next steps:

1.  Go to 'Inventory / Settings'. Activate the option 'Multi-Step
    Routes' and save.
2.  Go again to 'Inventory / Settings' and press 'Set Putaway Strategies
    on Locations'. Then define a putaway strategy in the location zone
    where the finished products are supposed to be placed, and indicate
    the specific sub-location/bin where the products should be placed.
