To use this module proceed as follows:

1.  Create a manufacturing order and indicate the product and the
    finished products location zone.
2.  Confirm the manufacturing order.
3.  You will notice that the finished products location has changed to
    the putaway location, and the chatter shows a message indicating
    that the putaway strategy was applied.
