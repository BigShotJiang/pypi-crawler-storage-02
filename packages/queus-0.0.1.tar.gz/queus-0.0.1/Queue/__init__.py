appname = 'queus'
version = '0.0.1'
pythons = '~=3.10'
clinton = 'Clinton Abraham'
mention = ['queue', 'queues', 'telegrams']
profile = 'https://github.com/Clinton-Abraham'

DATA03 = 'Python queue'
DATA01 = "clintonabrahamc@gmail.com"
DATA02 = ['Natural Language :: English',
          'Intended Audience :: Developers',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Programming Language :: Python :: 3.12',
          'Programming Language :: Python :: 3.13',
          'Programming Language :: Python :: 3.14',
          'Topic :: Software Development :: Libraries',
          'Topic :: Software Development :: Localization',
          'Topic :: Software Development :: User Interfaces',
          'Topic :: Software Development :: Version Control',]
