import asyncio
from ..exceptions import QueuedAlready
#======================================================================================

Queues = []

class Queue:

    async def add(uid, storage=Queues):
        if uid not in storage:
            storage.append(uid)
        else:
            raise QueuedAlready("ALREADY ADDED TO QUEUE")

#======================================================================================

    async def delete(uid, storage=Queues):
        storage.remove(uid) if uid in storage else 0

    async def position(uid, storage=Queues):
        return storage.index(uid) if uid in storage else 0

#======================================================================================

    async def queue(uid, wait=1, maximum=1, storage=Queues):
        while uid in storage:
            if storage.index(uid) + 1 > maximum:
                await asyncio.sleep(wait)
            else:
                break

#======================================================================================

    async def message(imog, text, button=None, maximum=1, storage=Queues):
        if maximum < len(storage):
            try: await imog.edit(text=text, reply_markup=button)
            except Exception: pass

#======================================================================================
