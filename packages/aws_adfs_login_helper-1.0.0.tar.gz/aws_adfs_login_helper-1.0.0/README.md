# aws-login
A python util to assist with logging into AWS via aws-adfs tool.



# Usage
## Install





# Dev Notes
python -m build 
twine upload -r testpypi dist/*