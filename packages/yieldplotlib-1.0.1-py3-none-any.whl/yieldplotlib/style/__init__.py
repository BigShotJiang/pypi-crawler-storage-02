"""Style configuration for yieldplotlib."""

__all__ = ["ypl_colors", "ypl_cycler", "ypl_cmap", "ypl_rainbow"]

from .custom_colors import ypl_cmap, ypl_colors, ypl_cycler, ypl_rainbow
