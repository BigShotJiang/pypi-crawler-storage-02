class CODEDEPLOY_TESTS:
    pass