"""API module for Automagik Hive."""
