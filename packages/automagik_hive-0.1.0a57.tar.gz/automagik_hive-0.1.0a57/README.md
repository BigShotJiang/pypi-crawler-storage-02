# Automagik Hive

Multi-agent AI framework built on Agno.

## Quick Start

```bash
uvx automagik-hive@latest --init workspace
```
