"""Test package for Automagik Hive."""
