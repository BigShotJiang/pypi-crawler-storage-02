"""Test package for pre-commit hook validation system."""
