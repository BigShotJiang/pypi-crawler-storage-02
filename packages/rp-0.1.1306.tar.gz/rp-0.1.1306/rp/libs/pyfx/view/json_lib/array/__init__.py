"""Node implementation for JSON `array` type."""
from .array_node import ArrayNode
