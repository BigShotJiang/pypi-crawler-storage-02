Installation
============

oarepo-oidc-einfra is on PyPI so all you need is:

.. code-block:: console

   $ pip install oarepo-oidc-einfra
