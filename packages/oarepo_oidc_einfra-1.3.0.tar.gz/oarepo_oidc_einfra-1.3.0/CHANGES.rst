..
    Copyright (C) 2023 CESNET.

    CESNET-OpenID-Remote is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Changes
=======

Version 0.1.0 (released TBD)

- Initial public release.
