/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('galaxy', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});
