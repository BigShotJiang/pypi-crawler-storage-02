CellValue = int | float | str | bool
