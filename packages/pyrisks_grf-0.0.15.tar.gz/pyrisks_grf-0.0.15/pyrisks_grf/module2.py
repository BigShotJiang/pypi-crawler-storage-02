def product(a,b):
    return a*b
def square(x):
    return x**2