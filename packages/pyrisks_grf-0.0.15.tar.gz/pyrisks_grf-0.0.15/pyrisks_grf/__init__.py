#from .module1 import *
#from .module2 import *
from .A_ESTRUCTURA import *
from .A_TRANSVERSAL import *

from .ML_01_VaR import global_treatment_VaR_Pan
from .ML_02_PLANO import global_treatment_Plano_Pan
from .ML_03_OPERACIONES_H_PAN import global_treatment_Operaciones_H_Pan
from .ML_04_OPERACIONES_BLOTTER import global_treatment_Operaciones_Blotter_Pan

from .MN_01_METRICAS import global_treatment_Metricas_H_Pan
from .MN_02_IRL import global_treatment_IRL_Pan
from .MN_03_INFOMERCADO import global_treatment_Infomercado_Pan