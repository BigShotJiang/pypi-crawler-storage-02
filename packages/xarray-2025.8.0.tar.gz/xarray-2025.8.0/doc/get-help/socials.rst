.. _socials:

Social Media
============

Xarray is active on several social media platforms. We use these platforms to share updates and connect with the user community.

- `Discord <https://discord.com/invite/wEKPCt4PDu>`__
- `Bluesky <https://bsky.app/profile/xarray.bsky.social>`__
- `Twitter(X) <https://x.com/xarray_dev>`__
