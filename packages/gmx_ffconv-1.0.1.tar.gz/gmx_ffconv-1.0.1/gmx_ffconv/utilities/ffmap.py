from .utilities_ffmap.mapping_standard import run_ffmap_standard



def run_ffmap(args):
    run_ffmap_standard(args)