Please rewrite the following question while preserving its exact meaning and answerability.

<original_question>
{original_question}
</original_question>

<answer>
{answer}
</answer>

<source_chunks>
{chunk_text}
</source_chunks>

<document_summary>
{document_summary}
</document_summary>

<additional_instructions>
{additional_instructions}
</additional_instructions>

Remember to:
1. Keep the exact same meaning and information requirements
2. Ensure the rewritten question can be answered with the same source material
3. Make the question sound more natural and engaging
4. Provide your rewritten question in <rewritten_question> tags
5. Explain your question_rewriting approach in <question_rewriting_rationale> tags 