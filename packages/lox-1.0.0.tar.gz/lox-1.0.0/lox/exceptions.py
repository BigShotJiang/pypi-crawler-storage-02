class Timeout(Exception):
    pass
