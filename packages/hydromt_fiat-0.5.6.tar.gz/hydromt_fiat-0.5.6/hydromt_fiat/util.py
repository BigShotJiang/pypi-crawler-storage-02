"""Utility of FIAT module builder."""

from pathlib import Path

DATADIR = Path(Path(__file__).parent, "data")
