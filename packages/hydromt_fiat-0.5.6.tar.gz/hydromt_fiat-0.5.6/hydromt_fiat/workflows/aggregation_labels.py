from hydromt_fiat.workflows.exposure_vector import ExposureVector


class AggregationLabels(ExposureVector):
    """This will be the class to generate aggregation labels for Delft-FIAT."""

    NotImplemented
