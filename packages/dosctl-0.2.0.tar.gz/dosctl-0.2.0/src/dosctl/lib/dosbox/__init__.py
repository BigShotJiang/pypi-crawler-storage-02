"""DOSBox launcher abstraction."""

from .launcher import get_dosbox_launcher

__all__ = ['get_dosbox_launcher']
