---
name: Build issue template
about: 'Create a report regarding the building process '
title: 'build: [enter a short description here]'
labels: ci
assignees: ''

---


