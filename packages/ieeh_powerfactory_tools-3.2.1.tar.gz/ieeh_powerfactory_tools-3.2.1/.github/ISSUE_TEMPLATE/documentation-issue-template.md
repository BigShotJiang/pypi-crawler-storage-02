---
name: Documentation issue template
about: Create a report regarding the documentation
title: 'docs: [enter a short description here]'
labels: documentation
assignees: ''

---


