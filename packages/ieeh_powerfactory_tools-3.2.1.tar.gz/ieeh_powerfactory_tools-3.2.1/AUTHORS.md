# Core Team

- [Sasan Jacob Rasti](https://github.com/sasanjac) (sasan_jacob.rasti@tu-dresden.de)
- [Sebastian Krahmer](https://github.com/SebastianDD) (sebastian.krahmer@tu-dresden.de)
- [Maximilian Schmidt](https://github.com/masc622) (maximilian.schmidt@tu-dresden.de)
