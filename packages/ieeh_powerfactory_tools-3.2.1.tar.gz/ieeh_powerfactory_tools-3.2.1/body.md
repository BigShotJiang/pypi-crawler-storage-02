## 3.2.1 (2025-08-04)

### Fix

- update readme and prepare new pypi release (#314)

[main 8e6cd94] bump: version 3.2.0 → 3.2.1
 6 files changed, 13 insertions(+), 7 deletions(-)

