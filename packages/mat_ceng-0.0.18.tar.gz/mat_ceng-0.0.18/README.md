# Civil_Engineering_Tools
#### Date 28-Jun-2024

### Introduction
This is under construction app collecting some useful tools for civil engineering that are needed regularly in the daily tasks for a civil engineer.

There is no intent to be a full set of tools or as a replacement for some useful commercial softwares in the civil engineering eco system (Prokon, STEPS, TEDDS, ...).

Most of the tools will be built by Python Programing language and following the American standards mostly with metric units.

### Credits
- big thanks for <a href="https://github.com/connorferster">Connor Ferster</a> for his good training, most of the work here is based on his good teaching.


#### Date 10-May-2025
use uv to manage the package