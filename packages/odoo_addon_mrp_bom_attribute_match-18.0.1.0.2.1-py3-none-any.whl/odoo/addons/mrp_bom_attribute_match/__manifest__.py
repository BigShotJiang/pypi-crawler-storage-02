{
    "name": "BOM Attribute Match",
    "version": "18.0.1.0.2",
    "category": "Manufacturing",
    "author": "Ilyas, Ooops, Odoo Community Association (OCA)",
    "summary": "Dynamic BOM component based on product attribute",
    "depends": ["mrp"],
    "license": "AGPL-3",
    "website": "https://github.com/OCA/manufacture",
    "data": [
        "views/mrp_bom_views.xml",
    ],
    "installable": True,
}
