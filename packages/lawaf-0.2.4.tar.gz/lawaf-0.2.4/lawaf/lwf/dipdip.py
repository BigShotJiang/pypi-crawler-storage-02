# to modify:

# dym_get_recip_dipole_dipole in phonopy. c. dynmat.c
# The dielectric part is at : get_dd
# It is later multiplied by the born effective charge in get_recip_dipole_dipole.
