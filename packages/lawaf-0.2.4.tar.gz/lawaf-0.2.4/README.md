# banddownfolder
[![Documentation Status](https://readthedocs.org/projects/banddownfolder/badge/?version=latest)](https://banddownfolder.readthedocs.io/en/latest/?badge=latest)
[![Build Status](https://travis-ci.com/mailhexu/banddownfolder.svg?branch=master)](https://travis-ci.com/mailhexu/banddownfolder)

LaWaF is a python package for build  electron/phonon/magnon/etc Wannier functions.


It has interface to:
 * Siesta (through sisl)
 * Anaddb (part of Abinit)
 * Phonopy

The online documentation can be found at:
https://lawaf.readthedocs.io/en/latest/index.html
