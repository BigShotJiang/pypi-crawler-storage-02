from banddownfolder.wrapper.phonopywrapper import save_ifc_and_show_phonon
import sys

save_ifc_and_show_phonon(sys.argv[1], sys.argv[2])
