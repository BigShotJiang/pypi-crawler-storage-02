
from img2table.document.image import Image
from img2table.document.pdf import PDF

__all__ = ["PDF", "Image"]
