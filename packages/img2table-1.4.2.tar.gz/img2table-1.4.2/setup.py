from setuptools import setup

setup(
    setup_requires=['pbr'],
    package_dir={'': 'src'},
    pbr=True,
)
