# Generated Input-App Package

This input-app uses coordinate node IDs of the form:

    input_app_demo_<path>  (e.g., input_app_demo_1.2.3)

Commands available at runtime:

* jump <node_id> [args_json]
* chain <node_id> <arg_map_json>
* back, menu, exit
