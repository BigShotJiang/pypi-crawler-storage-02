"""Unit tests for MCP Web Gateway."""
