# FormSpec

A Python library for form specifications.

## Installation

```bash
pip install FormSpec
```

## Usage

```python
from formspec import hello
print(hello())
```

This is currently a placeholder package. More functionality will be added soon.
