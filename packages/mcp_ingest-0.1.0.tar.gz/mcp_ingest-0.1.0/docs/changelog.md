# Changelog

## 0.1.0 — Initial release
- SDK: `describe`, `autoinstall`
- CLI: `detect`, `describe`, `register`, `pack`, `harvest-repo`
- Detectors: FastMCP + heuristics; LangChain
- Emitters: manifest/index/adapters
- Harvester: minimal jobs API & worker integration