from __future__ import annotations

from .sdk import autoinstall, describe

__all__ = ["describe", "autoinstall", "__version__"]
__version__ = "0.1.0"
