# Screenshot MCP Server 📸

A modern **Model Context Protocol (MCP) Server** for Windows Screenshots built with **.NET 10**. This server simulates **Print Screen** functionality and enables AI assistants to capture screenshots.

## ✨ Features

- 🖥️ **Multi-Monitor Support**: Capture all screens simultaneously
- 🎯 **Primary Screen**: Screenshots of main display only  
- 📊 **Screen Info**: Detailed information about all displays
- 🚀 **Print Screen Simulation**: Just like the Windows Print Screen key
- 💾 **Desktop Integration**: Screenshots saved to Desktop with timestamps
- ⚡ **State-of-the-Art**: Latest .NET 10 technology

## 🛠️ Installation

### ⚡ One-Click Install via UVX (Recommended)

Copy this URL and paste it in your browser:

```text
vscode:mcp/install?{"name":"screenshot-mcp-server","gallery":true,"command":"uvx","args":["screenshot-mcp-server"]}
```

### 🔧 Manual UVX Installation

```bash
# Install UV (if not already installed)
pip install uv

# Run Screenshot MCP Server
uvx screenshot-mcp-server
```

### 📦 Alternative: Manual Installation via Git

```bash
git clone https://github.com/metamintbtc/desktop_screenshot_mcp_server.git
cd desktop_screenshot_mcp_server
dotnet build
```

### VS Code MCP Configuration

#### Option A: Traditional mcp.json
Create `mcp.json` in your workspace or VS Code user directory:
```json
{
  "mcpServers": {
    "screenshot-mcp-server": {
      "command": "dotnet",
      "args": ["run", "--project", "H:\\Screenshot_mcp\\ScreenshotMcpServer.csproj"],
      "description": "Windows Screenshot MCP Server",
      "env": {}
    }
  }
}
```

#### Option B: VS Code Settings
Add to your VS Code settings.json:
```json
{
  "github.copilot.chat.mcp.servers": {
    "screenshot-mcp-server": {
      "command": "dotnet",
      "args": ["run", "--project", "H:\\Screenshot_mcp\\ScreenshotMcpServer.csproj"],
      "description": "Windows Screenshot Server"
    }
  }
}
```

## 🚀 Usage

### In VS Code with GitHub Copilot

Simply ask Copilot in natural language:
- *"Take a screenshot of all my screens"*
- *"Capture just the primary monitor"*  
- *"Show me information about my displays"*
- *"Simulate pressing Print Screen"*

### Available Tools

#### 📸 `TakeScreenshot`
Captures all screens (simulates Print Screen)

```text
Captures all monitors simultaneously
Saves as PNG to Desktop with timestamp
Filename: screenshot_2025-08-04_18-59-30.png
```

#### 🎯 `TakePrimaryScreenshot`  
Captures only the primary screen

```text
Captures main monitor only
Perfect for focused screenshots
Filename: primary_screenshot_2025-08-04_18-59-30.png
```

#### 📊 `GetScreenInfo`
Shows detailed information about all displays

```text
- Number of monitors
- Resolutions and positions  
- Virtual desktop size
```

#### ⌨️ `SimulatePrintScreen`
Emulates exactly the Windows Print Screen key press

## 💻 System Requirements

- **OS**: Windows 10/11 (x64)
- **.NET**: .NET 10.0 or higher
- **RAM**: Minimum 512 MB
- **Storage**: 50 MB free space

## 🔧 Development

### Build

```bash
dotnet build ScreenshotMcpServer.csproj
```

### Run  

```bash
dotnet run --project ScreenshotMcpServer.csproj
```

### Publish

```bash
dotnet publish -c Release -o ./dist
```

## 📁 Project Structure

```
screenshot-mcp-server/
├── Program.cs              # Main entry point
├── ScreenshotTool.cs      # Screenshot functionality
├── ScreenshotMcpServer.csproj # .NET project
├── package.json           # NPM configuration
├── README.md             # This file
└── bin/                  # Compiled binaries
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)  
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.

## 🔗 Links

- [Model Context Protocol](https://modelcontextprotocol.io/)
- [.NET 10 Documentation](https://docs.microsoft.com/en-us/dotnet/)
- [VS Code GitHub Copilot](https://code.visualstudio.com/docs/copilot/)

## 🆘 Support

For issues or questions:

- 🐛 Issues: [GitHub Issues](https://github.com/metamintbtc/desktop_screenshot_mcp_server/issues)
- 💬 Discussions: [GitHub Discussions](https://github.com/metamintbtc/desktop_screenshot_mcp_server/discussions)

---

**Made with ❤️ for the AI Community**
