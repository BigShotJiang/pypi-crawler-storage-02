from abc import ABC


class ConversationConstants(ABC):
    CONVERSATION_ID_HTTP_HEADER_NAME = "x-ms-conversation-id"
