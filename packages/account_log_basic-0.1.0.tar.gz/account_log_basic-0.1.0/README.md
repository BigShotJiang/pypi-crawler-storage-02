# Account_log_basic

A simple Python module for creating and logging into accounts locally.  
Perfect for learning Python basics.

## Installation
```bash
pip install Account_log_basic
