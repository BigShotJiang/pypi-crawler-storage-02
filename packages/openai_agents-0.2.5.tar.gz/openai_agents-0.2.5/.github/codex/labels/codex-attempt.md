Attempt to solve the reported issue.

If a code change is required, create a new branch, commit the fix, and open a pull request that resolves the problem.

Here is the original GitHub issue that triggered this run:

### {CODEX_ACTION_ISSUE_TITLE}

{CODEX_ACTION_ISSUE_BODY}