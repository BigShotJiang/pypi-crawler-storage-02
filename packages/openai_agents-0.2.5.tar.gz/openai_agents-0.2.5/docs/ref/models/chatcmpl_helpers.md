# `Chatcmpl Helpers`

::: agents.models.chatcmpl_helpers
