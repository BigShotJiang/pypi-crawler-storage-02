# `Exceptions`

::: agents.exceptions
