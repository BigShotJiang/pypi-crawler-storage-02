from kirin.ir import Dialect

dialect = Dialect("qourier.spec")
