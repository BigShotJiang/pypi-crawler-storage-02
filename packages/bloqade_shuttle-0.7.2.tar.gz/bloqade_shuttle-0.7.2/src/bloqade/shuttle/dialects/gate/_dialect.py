from kirin import ir

dialect = ir.Dialect("gate")
