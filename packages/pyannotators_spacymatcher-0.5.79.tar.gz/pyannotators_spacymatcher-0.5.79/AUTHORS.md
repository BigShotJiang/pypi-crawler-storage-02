# Authors

Contributors to pyannotators_spacymatcher include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
