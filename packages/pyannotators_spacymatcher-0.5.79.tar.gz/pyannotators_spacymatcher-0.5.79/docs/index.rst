.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Contents:

   CHANGELOG
   reference/pyannotators_spacymatcher
