"""
ddQuint: Digital Droplet PCR Multiplex Analysis
Version: 0.1.0
"""

__version__ = '0.1.0'
__author__ = 'Jakob Wimmer'