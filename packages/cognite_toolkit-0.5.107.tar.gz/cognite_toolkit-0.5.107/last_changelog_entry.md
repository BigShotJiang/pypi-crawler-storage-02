## cdf 

### Added

- [alpha] The command `cdf profile asset-centric` now stores the
metadata keys in spreadsheet if spreadsheet argument is given.

## templates

No changes.