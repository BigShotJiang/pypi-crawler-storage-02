# Examples

The most relevant examples to get started with ORDeC are currently found **outside** this directory, at **ordec/lib/examples/**.

The subdirectory **dev/** is for Jupyter Notebooks that support the development process of specific modules. They are for development of ORDeC, not the end user.
