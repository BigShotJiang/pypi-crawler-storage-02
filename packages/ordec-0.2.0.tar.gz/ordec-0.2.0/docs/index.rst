Welcome to ORDeC's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   webui
   ref/index
   cell_lib/index
   dev/index
   related_projects


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
