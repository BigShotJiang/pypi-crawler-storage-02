User Reference
==============

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   ordb
   cell_and_generate
   schema
   geoprim
   rational

.. _data-schema:

.. figure:: architecture.svg
   :scale: 120 %
   :alt: ORDeC architecture block diagram

   Overview of ORDeC's architecture
