from setuptools import setup , find_packages
classifiers=[
    "Development Status :: 5 - Production/Stable",
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
],
setup(
    name ='medcharafpackage',
    version='0.0.1',
    description='basic package',
    author_email='medcharaf011@gmail.com',
    license='MIT',
    # classifiers=classifiers,
    keywords='simplepackage',
    install_requires=['']    
    
    
)


