from .ManejoArchivos import *
from .texto import mayusculas
