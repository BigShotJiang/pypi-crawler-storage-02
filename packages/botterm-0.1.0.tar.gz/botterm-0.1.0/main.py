def main():
    print("Hello from botterm!")


if __name__ == "__main__":
    main()
