# jack_midi_recorder

Basic implementation of MIDI event recording / playback.
