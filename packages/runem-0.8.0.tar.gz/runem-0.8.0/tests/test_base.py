from runem.base import NAME


def test_base() -> None:
    assert NAME == "runem"
