
from setuptools import setup

setup(package_data={'flask_migrate-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
