// use fcb_core::read

// fn main() {
//     let data = vec![
//         (
//             "3DBAG",
//             (
//                 "benchmark_data/3DBAG.city.fcb",
//                 "benchmark_data/3DBAG.city.jsonl",
//                 "benchmark_data/3DBAG.city.cbor",
//                 "benchmark_data/3DBAG.city.bson",
//             ),
//         ),
//         (
//             "3DBV",
//             (
//                 "benchmark_data/3DBV.city.fcb",
//                 "benchmark_data/3DBV.city.jsonl",
//                 "benchmark_data/3DBV.city.cbor",
//                 "benchmark_data/3DBV.city.bson",
//             ),
//         ),
//     ];

//     for (name, (fcb, jsonl, cbor, bson)) in data {
//        read_fcb
//       );
//     }
// }

fn main() {
    todo!()
}
