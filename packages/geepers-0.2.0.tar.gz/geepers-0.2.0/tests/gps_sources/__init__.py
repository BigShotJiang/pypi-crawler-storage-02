"""Tests for GPS data sources package."""
