# OrbitVisualization
Code/Astro Project

Plot planets around a star and calculate change in positions with a given timestep for system properties.

![A rectangular badge, half black half purple containing the text made at Code Astro](https://img.shields.io/badge/Made%20at-Code/Astro-blueviolet.svg)
