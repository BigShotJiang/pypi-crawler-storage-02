from enum import Enum

class MemberType(Enum):
    FIELD = 1
    PROPERTY = 2