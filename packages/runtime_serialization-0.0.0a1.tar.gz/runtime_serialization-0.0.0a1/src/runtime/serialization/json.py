from runtime.serialization.core.formats.json.serializer import JsonSerializer as Serializer, serialize, deserialize

__all__ = [
    'Serializer',
    'serialize',
    'deserialize'
]