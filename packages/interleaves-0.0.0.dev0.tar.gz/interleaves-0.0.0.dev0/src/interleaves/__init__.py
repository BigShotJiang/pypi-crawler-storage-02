from interleaves.core import *
from interleaves.tests import *

if __name__ == "__main__":
    main()
