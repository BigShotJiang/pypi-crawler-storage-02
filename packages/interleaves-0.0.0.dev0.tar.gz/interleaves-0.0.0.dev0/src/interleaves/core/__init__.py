from typing import *

__all__ = ["main"]


def main(args: Optional[Iterable] = None) -> None:
    "This function prints 'Hello World!'."
    print("Hello World!")
