# Core instrumentation tests
