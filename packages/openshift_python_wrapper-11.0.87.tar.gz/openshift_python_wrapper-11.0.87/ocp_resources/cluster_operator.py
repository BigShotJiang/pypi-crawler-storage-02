from ocp_resources.resource import Resource


class ClusterOperator(Resource):
    api_group = Resource.ApiGroup.CONFIG_OPENSHIFT_IO
