## pycbsdk notebooks

Use this folder to store jupyter(lab) notebooks from the pycbsdk project.

The Python environment that you use to run Jupyter should have the `pycbsdk` python package installed. Install this package in developer mode by activating the relevant python environment in your shell/console, `cd`'ing to the `pycbsdk` folder and doing a `pip install -e .`.
