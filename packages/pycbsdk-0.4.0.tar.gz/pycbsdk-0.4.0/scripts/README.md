## Assorted Python Scripts

Please use this folder to hold miscellaneous scripts that are related to pycbsdk but shouldn't be installed with the package.

Any scripts that should go with the package can exist in the pycbsdk.examples submodule and might also deserve any entrypoint in setup.cfg.
