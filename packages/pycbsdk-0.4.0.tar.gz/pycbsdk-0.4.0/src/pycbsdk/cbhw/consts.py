from aenum import IntEnum


class CBError(IntEnum):
    NONE = 0
    UNDEFINED = 10
    NOREPLY = 20
