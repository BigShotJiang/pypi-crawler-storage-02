def p_1a():
    print("""lamia is a fucking bitch""")
