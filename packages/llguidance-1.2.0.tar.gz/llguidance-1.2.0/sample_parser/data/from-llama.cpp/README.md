These files are here just for testing and were copied from:

https://github.com/ggerganov/llama.cpp/tree/4a75d19376f2f00dbae6c266eb9c4f3001872b52/grammars

MIT License
