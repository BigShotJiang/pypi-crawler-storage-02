// Copyright (c) 2020 Robert Vaser

#ifndef SPOA_SPOA_HPP_
#define SPOA_SPOA_HPP_

#include "graph.hpp"
#include "alignment_engine.hpp"
#include "version.hpp"

#endif  // SPOA_SPOA_HPP_
