// Copyright (c) 2023 Robert Vaser

#ifndef SPOA_VERSION_HPP_
#define SPOA_VERSION_HPP_

#include <string>

namespace spoa {

std::string Version();

}  // namespace spoa

#endif  // SPOA_VERSION_HPP_
