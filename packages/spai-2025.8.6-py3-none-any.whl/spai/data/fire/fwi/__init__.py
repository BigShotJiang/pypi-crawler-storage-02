from .fwi_nasa import download_nasa_fwi, get_nasa_fwi
