"""dragonfly-doe2 properties."""
