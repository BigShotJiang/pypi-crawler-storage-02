"""
File I/O operations module.

Handles reading and writing CSV and JSON files.
"""