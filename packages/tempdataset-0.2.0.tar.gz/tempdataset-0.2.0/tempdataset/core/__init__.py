"""
Core module for TempDataset library.

Contains the main data generation engine and core utilities.
"""