#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Connected:
    def __init__(self):
        pass


class Disconnected:
    def __init__(self):
        pass


class Discovered:
    def __init__():
        pass


class Gone:
    def __init__():
        pass


class EventMessage:
    def __init__(self, msg):
        self.msg = msg
