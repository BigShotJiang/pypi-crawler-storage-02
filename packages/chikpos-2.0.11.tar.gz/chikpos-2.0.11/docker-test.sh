#!/bin/sh
docker run -it --rm chikpos:dev /app/RunTests

