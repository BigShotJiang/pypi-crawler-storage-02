#!/bin/sh
docker build -t chikpos:dev .

