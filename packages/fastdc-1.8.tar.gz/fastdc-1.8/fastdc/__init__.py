from .bot import FastBot

__all__ = ['FastBot']