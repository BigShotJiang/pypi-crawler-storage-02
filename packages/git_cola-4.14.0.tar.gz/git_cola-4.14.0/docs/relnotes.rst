========
Releases
========

Latest Release
==============

:ref:`v4.14.0 <v4.14.0>` is the latest stable release.

Development version
===================

Clone the git-cola repository to get the latest development version:

``git clone https://gitlab.com/git-cola/git-cola.git``


.. include:: ../CHANGES.rst
