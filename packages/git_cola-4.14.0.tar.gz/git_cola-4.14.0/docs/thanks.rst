Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Aaron Boxer
* Aaron Cook
* Aaron Malpas
* Aaron Wolf
* Abid Ahmad
* Adam Lesperance
* Adrien be
* Adil
* AJ Bagwell
* akontsevich
* Albert Vaca Cintora
* Aleksey Kontsevich
* Alexander Preißner
* Alex Chernetz
* Alex Gulyás
* Alexander Kozienko
* Alf Eaton
* anderben
* Andreas Schnederle-Wagner
* Andreas Sommer
* Andrej Kvasnica
* Andrew Chen
* Andrew Hemming
* Andy O'Neill
* armandg
* Arthur Coelho
* Arnaud Henry
* Audrey Yeena Toskin
* Audrius Karabanovas
* Axel Heider
* Balázs Meskó
* balping
* Barış ÇELİK
* Barry Roberts
* Bastian Müller
* Boris W
* Ben Boeckel
* Ben Cole
* Benedict Lee
* Benjamin Somers
* Benoît Nouyrigat
* Bernd K
* Bert Jacobs
* Birger Skogeng Pedersen
* Björn Ketelaars
* Bob van der Linden
* Boerje Sewing
* Brad Bell
* Bruno Cabral
* 林博仁 (Buo-ren Lin)
* cclaus
* Charles 101
* Chris Stefano
* Christian Jann
* Christoph Erhardt
* Christopher Meng
* Clément Pit--Claudel
* Constantine Grantcharov
* Daniel Dunn
* Daniel Fahlke
* Daniel Jay Haskin
* Daniel Harding
* Daniel King
* DasaniT
* Dave Cottlehuber
* Dave Thomas
* David Aguilar
* David Bold
* David Fernandez
* David LeGare
* David Martínez Martí
* David Roman
* Dawid Drozd
* Dennis Gilmore
* Demodian
* deniz1a
* Dmitriy Bogdanov
* Dmitry Kann
* Dmitry Pashkevich
* Dorian Marchal
* Doug Hoskisson
* Drugoy
* Efimov Vasily
* Eric Drechsel
* Eric Wild
* Ernst Widerberg
* Erop @EgZvor
* Erwan Bousse
* Fabio Coatti
* Fang Pengfei
* feinstaub
* Felipe Morales
* Filip Danilović
* Floris Lambrechts
* Frank Weber
* Garoe Dorta
* Geoffrey van Wyk
* Georg Limbach
* geotavros
* Gianni Lerro
* Giovanni Martins
* `Git Hackers <https://git-scm.com/about>`_
* Graham Bartlett
* green-eyed-bear
* Glen Mailer
* Guillaume de Bure
* Guo Yunhe
* Gyuris Gellért
* Harro Verton
* Hannes @kannes
* Hendrix4858
* Hoernchen
* hydrargyrum
* Igor Galarraga
* Igor Kopach
* Ilya Tumaykin
* Ingo Weinhold
* Irfan Baig
* Ismael Juma
* Iulian Udrea
* Ivar Smolin
* Jad El Kik
* Jacob Gustafson
* Jakub Klos
* João Matos
* Jan @hanksoff
* Jan Šilhan
* Jan Tumanov
* jakubklos77
* Jakub Szymański
* Jakub Wilk
* James Geiger
* Jason Newton
* Javier Rodriguez Cuevas
* Jeff Dagenais
* Jérôme Carretero
* jfessard
* JiCiT
* Jimmy M. Coleman
* Joachim Jablon
* Joachim Lusiardi
* Joel Barrios
* Johannes Löhnert
* Johann Schmitz
* Jordan Bedwell
* Josh Noe
* Josh Taylor
* Justin Lecher
* Kai Krakow
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kerrick Staley
* Kevin Kofler
* Kirit Sælensminde
* Kisaragi Hiu
* Klaas Neirinck
* K.T.dev
* Kurt McKee
* Kyle Slane
* László Böszörményi
* lcjh
* Leho Kraav
* Lev Zlotin
* Louis Rousseau
* Libor Jelinek
* Lim Ngian Xin Terry
* Liviu Cristian Mirea-Ghiban
* Luca Ottaviano
* Łukasz Wojniłowicz
* Luke Bakken
* Luke Horwell
* Maarten Nieber
* Maaaks
* Maciej Filipiak
* Mahmoud Hossam
* Mateusz Kedzior
* Matias N. Goldberg
* Maicon D. Filippsen
* Marcin Mielniczuk
* Marco Costalba
* Mariusz Jaskółka
* Markus Heidelberg
* Martin Gysel
* Martin Konecny
* Matěj Šmíd
* Matthew Levine
* Matthias Mailänder
* Max Harmathy
* Melike Kecelioglu
* Micha Rosenbaum
* Michael Geddes
* Michael Homer
* Michael Schwarz
* Michele Nalli
* Mickael Albertus
* Miguel Boekhold
* Mike Hanson
* MikHulk
* Mikołaj Milej
* Minarto Margoliono
* Mithil Poojary
* Mosaab Alzoubi
* Muhammad Bashir Al-Noimi
* nakanoi
* Nanda Lopes
* Naraesk
* Niel Buys
* Nick Todd
* Nicolas Dietrich
* Nikos Roussos
* Noel Grandin
* NotSqrt
* novebeta
* nyanpasu64
* ochristi
* Oliver Haessler
* OmegaPhil (Omega Weapon)
* Ori shalhon
* Owen Healy
* Pamela Strucker
* Paolo G. Giarrusso
* Parashurama Rhagdamaziel
* Patrick Browne
* Paul Hildebrandt
* Paul Weingardt
* Paulo Fidalgo
* Pavel Borecki
* Pavel Rehak
* Peer Sommerlund
* Peter Dave Hello
* Peter Jensen
* Peter Justin
* Peter Júnoš
* Petr Gladkikh
* Philip Stark
* Pilar Molina Lopez
* Pius Raeder
* Radek Novacek
* Radek Postołowicz
* Rafael Nascimento
* Rafael Reuber
* Raghavendra Karunanidhi
* Rainer Müller
* Ray Haleblian
* RealTehreal
* Ricardo J. Barberis
* Robbert Korving
* Robert Pollak
* Rolando Espinoza La fuente
* Rustam Safin
* Sabri Ünal
* Samsul Ma'arif
* Scott Field
* Sean Allred
* Sebastian Brass
* Sebastian Oliva
* Sergei Dyshel
* Sergey Leschina
* Shun Sakai
* Simon Peeters
* Srinivasa Nallapati
* Stan Angeloff
* Stanisław Halik
* Stefan Naewe
* Steffen Prohaska
* Stéphane Cerveau
* Stephen Groat
* Suyandi
* Sven Claussner
* Szymon Judasz
* Tamil Neram தமிழ் நேரம்
* Taylor Braun-Jones
* Thiemo van Engelen
* Thomas McKay
* Thomas Kiley
* Thomas Kluyver
* Thomas Thorne
* Tom Dobbelaere
* Tomo Dote
* Tim Brown
* Tim Gates
* Tim Schumacher
* Trevor Alexander
* Tyler Shellberg
* Ugo Riboni
* Uri Okrent
* Utku Karatas
* Ｖ字龍 (Vdragon)
* Vaibhav Sagar
* Vaiz
* vanderkoort
* Ved Vyas
* Victor Gambier
* Victor Nepveu
* Victorhck
* Ville Skyttä
* Virgil Dupras
* Vishnu Sanal
* Vitor Lobo
* v.paritskiy
* waterzch
* Wolfgang Ocker
* wm4
* WNguyen14
* wsdfhjxc
* Xie Hua Liang (xieofxie)
* yael levi
* YAMAMOTO Kenyu
* Yi EungJun
* Zauber Paracelsus
* Zeioth
* Zhang Han
* 0xflotus
