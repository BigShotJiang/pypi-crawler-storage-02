# Heap Tree

A simple heap data structure implementation in Python.

## Installation
```bash
pip install heap-tree
