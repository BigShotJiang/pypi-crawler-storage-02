from .fastsl import find_synthetic_lethal_genes

__all__ = ["find_synthetic_lethal_genes"]
