MaxDynamoSubmissionSizeSetting
==============================

.. currentmodule:: codegrade.models.max_dynamo_submission_size_setting

.. autoclass:: MaxDynamoSubmissionSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
