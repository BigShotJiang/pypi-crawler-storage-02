RubricRowBaseInputBaseAsJSON
============================

.. currentmodule:: codegrade.models.rubric_row_base_input_base_as_json

.. autoclass:: RubricRowBaseInputBaseAsJSON
   :members: header, description, items
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
