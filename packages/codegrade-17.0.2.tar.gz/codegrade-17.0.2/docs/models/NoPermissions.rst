NoPermissions
=============

.. currentmodule:: codegrade.models.no_permissions

.. autoclass:: NoPermissions
   :members: has_perms
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
