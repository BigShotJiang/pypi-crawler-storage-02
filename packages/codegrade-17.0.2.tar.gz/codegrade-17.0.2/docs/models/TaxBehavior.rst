TaxBehavior
===========

.. currentmodule:: codegrade.models.tax_behavior

.. class:: TaxBehavior

**Options**

* ``inclusive``
* ``exclusive``
* ``disabled``
