PresentPreference
=================

.. currentmodule:: codegrade.models.present_preference

.. autoclass:: PresentPreference
   :members: tag, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
