AutoTestStepResult
==================

.. currentmodule:: codegrade.models.auto_test_step_result

.. autoclass:: AutoTestStepResult
   :members: id, auto_test_step, state, achieved_points, log, started_at, attachment_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
