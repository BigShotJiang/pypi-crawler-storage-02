QuizSingleQuestionModeHideRunButtonEnabledSetting
=================================================

.. currentmodule:: codegrade.models.quiz_single_question_mode_hide_run_button_enabled_setting

.. autoclass:: QuizSingleQuestionModeHideRunButtonEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
