LoginTokenBeforeTimeSetting
===========================

.. currentmodule:: codegrade.models.login_token_before_time_setting

.. autoclass:: LoginTokenBeforeTimeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
