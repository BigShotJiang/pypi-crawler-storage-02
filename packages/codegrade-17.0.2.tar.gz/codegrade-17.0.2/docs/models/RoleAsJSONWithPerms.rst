RoleAsJSONWithPerms
===================

.. currentmodule:: codegrade.models.role_as_json_with_perms

.. autoclass:: RoleAsJSONWithPerms
   :members: perms, own, count
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
