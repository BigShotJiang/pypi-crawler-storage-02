BaseCommentBase
===============

.. currentmodule:: codegrade.models.base_comment_base

.. autoclass:: BaseCommentBase
   :members: id, work_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
