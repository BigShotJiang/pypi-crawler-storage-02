SimpleSubmissionNavigateToLatestEditorSessionSetting
====================================================

.. currentmodule:: codegrade.models.simple_submission_navigate_to_latest_editor_session_setting

.. autoclass:: SimpleSubmissionNavigateToLatestEditorSessionSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
