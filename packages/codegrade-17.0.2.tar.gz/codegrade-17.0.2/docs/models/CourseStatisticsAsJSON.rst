CourseStatisticsAsJSON
======================

.. currentmodule:: codegrade.models.course_statistics_as_json

.. autoclass:: CourseStatisticsAsJSON
   :members: active_student_amount
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
