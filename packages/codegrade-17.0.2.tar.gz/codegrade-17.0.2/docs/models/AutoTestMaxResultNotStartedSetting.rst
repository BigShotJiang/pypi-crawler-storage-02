AutoTestMaxResultNotStartedSetting
==================================

.. currentmodule:: codegrade.models.auto_test_max_result_not_started_setting

.. autoclass:: AutoTestMaxResultNotStartedSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
