LtiLockDateCopyingEnabledSetting
================================

.. currentmodule:: codegrade.models.lti_lock_date_copying_enabled_setting

.. autoclass:: LtiLockDateCopyingEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
