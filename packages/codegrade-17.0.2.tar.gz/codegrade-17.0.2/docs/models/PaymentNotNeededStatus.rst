PaymentNotNeededStatus
======================

.. currentmodule:: codegrade.models.payment_not_needed_status

.. autoclass:: PaymentNotNeededStatus
   :members: tag
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
