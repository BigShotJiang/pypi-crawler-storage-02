SsoInferGlobalStaffRoleSetting
==============================

.. currentmodule:: codegrade.models.sso_infer_global_staff_role_setting

.. autoclass:: SsoInferGlobalStaffRoleSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
