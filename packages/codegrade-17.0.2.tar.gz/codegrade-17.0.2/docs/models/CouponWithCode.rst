CouponWithCode
==============

.. currentmodule:: codegrade.models.coupon_with_code

.. autoclass:: CouponWithCode
   :members: type, code
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
