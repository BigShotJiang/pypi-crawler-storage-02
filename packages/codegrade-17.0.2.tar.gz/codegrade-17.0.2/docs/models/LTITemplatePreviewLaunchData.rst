LTITemplatePreviewLaunchData
============================

.. currentmodule:: codegrade.models.lti_template_preview_launch_data

.. autoclass:: LTITemplatePreviewLaunchData
   :members: type, template
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
