PatchUserData
=============

.. currentmodule:: codegrade.models.patch_user_data

.. autoclass:: PatchUserData
   :members: email, old_password, name, new_password, reset_email_on_lti
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
