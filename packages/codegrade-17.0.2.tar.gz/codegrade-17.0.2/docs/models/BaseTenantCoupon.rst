BaseTenantCoupon
================

.. currentmodule:: codegrade.models.base_tenant_coupon

.. autoclass:: BaseTenantCoupon
   :members: id, created_at, limit, scope, tenant_id, used_amount
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
