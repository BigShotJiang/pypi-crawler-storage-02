from .. import Layer

class Normalization(Layer):
    pass