This module allows you to change the analytical account of the unbilled timesheet when your
related task changes the account as it does with the sales order item.
