To configure this module, you need to:

1. Go to Settings > Users & Companies > Groups
2. Give your user these technical permissions:
    - Technical / Show Full Accounting Features
3. Go to Invoicing > Settings > Analytics and check Analytic Accounting