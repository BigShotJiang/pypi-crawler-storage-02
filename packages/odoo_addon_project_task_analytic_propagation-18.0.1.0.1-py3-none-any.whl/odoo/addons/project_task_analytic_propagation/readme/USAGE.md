To use this module, you need to:

1. Go to Sales > Order and select an order with a project related to it but not invoiced yet.
2. Click on task's smart button and select a task with 'Sales Order Item' set (or create a new task in other case).
3. Select any analytic account in 'Extra Info'.
4. Record some time on timesheets page.
5. Go back to your order and create an invoice.
6. Go to the previous task and record some time. Then change the analytic account.
7. In timesheet's page only not invoiced timesheets changed the analytic account.
8. To check this go to Timesheets > All Timesheets.
9. Change to list view and group by Project > Task and add custom group Project.
