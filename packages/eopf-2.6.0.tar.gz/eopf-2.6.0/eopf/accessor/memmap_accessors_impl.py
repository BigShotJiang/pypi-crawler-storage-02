#
# Copyright (C) 2025 ESA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import ctypes
from typing import Any, List, Optional, Sequence

import dask
import dask.array as da
import numpy as np
from numpy._typing import NDArray

from eopf.common.file_utils import AnyPath
from eopf.config.config import EOConfiguration
from eopf.daskconfig.dask_utils import scatter
from eopf.exceptions.errors import AccessorInvalidRequestError
from eopf.logging import EOLogging

PACKET_CACHE_SIZE_PARAM_NAME: str = "accessors__memmap__packet_cache_size"
PACKET_CACHE_SIZE_DEFAULT: int = 1024

EOConfiguration().register_requested_parameter(
    PACKET_CACHE_SIZE_PARAM_NAME,
    PACKET_CACHE_SIZE_DEFAULT,
    True,
    description="Number of packet kept in cache for dask delayed",
)


def _load_chunk(
    url: AnyPath,
    length_to_load_bytes: int,
    offset_in_file_bytes: int,
    start_byte: int,
    count_byte: int,
    sl: slice,
    shape: tuple[int],
    output_type: Any,
    packet_length_bytes: List[Any],
    mask: Optional[Any],
    shift: Optional[Any],
    dtype: Any = np.dtype("B"),
) -> Any:

    with url.open("rb") as f:
        # numpy.fromfile doesn't work with non local filehandle
        f.seek(offset_in_file_bytes)
        bytes = f.read(length_to_load_bytes)
        buffer = np.frombuffer(bytes, dtype=dtype)
    # [] operator is inclusive
    nb_packets = sl.stop - sl.start
    if len(shape) > 1:
        parameter = np.zeros(
            (nb_packets, shape[1]),
            dtype=output_type,
        )
    else:
        parameter = np.zeros(
            nb_packets,
            dtype=output_type,
        )

    offset_buffer = start_byte
    if count_byte < 0:
        for p in range(nb_packets):
            end_byte = int(packet_length_bytes[p])
            count_byte = end_byte - start_byte
            parameter[p, 0:count_byte] = buffer[offset_buffer : (offset_buffer + count_byte)]
            offset_buffer += int(packet_length_bytes[p])
    elif mask is None:
        for p in range(nb_packets):
            # fmt: off
            parameter[p,] = buffer[offset_buffer: (offset_buffer + count_byte)]
            # fmt: on
            offset_buffer += int(packet_length_bytes[p])
    elif shift is not None:
        for p in range(nb_packets):
            data = buffer[offset_buffer : (offset_buffer + count_byte)]
            parameter[p] = (int.from_bytes(data, "big") >> shift) & mask
            offset_buffer += int(packet_length_bytes[p])
    del buffer
    return parameter


class MultipleFileMemMap:
    def __init__(
        self,
        urls: Sequence[str | AnyPath],
        primary_header_length_bytes: int,
        ancillary_header_length_bytes: int,
        packet_length_start_position_bytes: int,
        packet_length_stop_position_bytes: int,
    ):
        """

        Parameters
        ----------
        urls
        primary_header_length_bytes : length in bytes of the primary header of the file
        ancillary_header_length_bytes : length in bytes of the ancillary header of the file
        packet_length_start_position_bytes : start position of the packet length information
        packet_length_stop_position_bytes : stop position of the packet length information
        """
        # packet length for writing only
        self._packet_offset_bytes: Any = None
        self._packet_length_bytes: Any = 0
        self._builtin_open = open
        # Init logger
        self._log = EOLogging().get_logger(name="eopf.accessor.memmap_accessor")
        self._loaded: bool = False
        self._to_be_saved: bool = False
        self._n_packets: int = 0
        self._n_packets_per_file: dict[AnyPath, int] = {}
        self._buffer: Any = None
        self._packet_length_per_file_bytes: dict[AnyPath, Any] = {}
        self._packet_offset_per_file_bytes: dict[AnyPath, Any] = {}
        self.urls: list[AnyPath] = [AnyPath.cast(url) for url in urls]
        self._incr_step: int = 10000
        self._ancillary_header_bytes = ancillary_header_length_bytes
        self._primary_header_bytes = primary_header_length_bytes
        self._packet_length_start_position_bytes: int = packet_length_start_position_bytes
        self._packet_length_stop_position_bytes: int = packet_length_stop_position_bytes

    def reset(self) -> None:
        self._loaded = False
        self._to_be_saved = False
        self._n_packets = 0
        self._n_packets_per_file = {}
        self._buffer = None
        self._packet_length_per_file_bytes = {}
        self._packet_offset_per_file_bytes = {}

    @property
    def loaded(self) -> bool:
        return self._loaded

    @property
    def need_save(self) -> bool:
        return self._to_be_saved

    def build_buffer(self, packet_len_bytes: Any) -> None:
        """
        Build the internal data buffer to write in case of open(mode=CREATE)

        Parameters
        ----------
        packet_len_bytes :
            length of the packets

        Returns
        None
        -------

        """
        if self._buffer is None:
            self._packet_length_bytes = packet_len_bytes + self._primary_header_bytes + self._ancillary_header_bytes + 1
            self._n_packets = packet_len_bytes.size
            self._size = np.sum(self._packet_length_bytes)
            # FIXME : how to handle back conversion with multiple files
            self._packet_offset_bytes = np.insert(np.cumsum(self._packet_length_bytes[0:-1]), 0, 0, axis=0)
            self._buffer = np.zeros(self._size, dtype="uint8")
            self._to_be_saved = True

    def load_buffer_infos(self) -> None:
        if self._loaded:
            return

        for url in self.urls:
            if not url.exists():
                raise FileNotFoundError(f"{url} not found")
            try:
                with url.open("rb") as f:
                    bytes = f.read()
                    self._buffer = np.frombuffer(bytes, np.dtype("B"))
            except IOError as e:
                raise IOError(f"Error While Opening {url}, {e}!") from e

            self._n_packets_per_file[url] = 0
            self._packet_length_per_file_bytes[url] = np.zeros(self._incr_step, dtype="uint16")
            self._packet_offset_per_file_bytes[url] = np.zeros(self._incr_step, dtype="uint64")

            k = 0
            while k < len(self._buffer):
                if self._n_packets_per_file[url] == self._packet_length_per_file_bytes[url].shape[0]:
                    self._packet_length_per_file_bytes[url].resize(
                        self._n_packets_per_file[url] + self._incr_step,
                        refcheck=False,
                    )
                    self._packet_offset_per_file_bytes[url].resize(
                        self._n_packets_per_file[url] + self._incr_step,
                        refcheck=False,
                    )
                self._packet_offset_per_file_bytes[url][self._n_packets_per_file[url]] = k
                self._packet_length_per_file_bytes[url][self._n_packets_per_file[url]] = (
                    int.from_bytes(
                        self._buffer[
                            k + self._packet_length_start_position_bytes : k + self._packet_length_stop_position_bytes
                        ],
                        "big",
                    )  # noqa
                    + self._ancillary_header_bytes
                    + self._primary_header_bytes
                    + 1  # noqa
                )
                k += int(self._packet_length_per_file_bytes[url][self._n_packets_per_file[url]])
                self._n_packets_per_file[url] += 1
                self._n_packets += 1
        # End for each url
        # Clear buffer
        self._buffer = None
        # Mark as loaded
        self._loaded = True

    def save_buffer(self) -> None:
        if self.need_save:
            try:
                # FIXME : how to handle back conversion with multiple files
                with self.urls[0].open("wb") as f:
                    self._buffer.tofile(f)
            except IOError as e:
                raise IOError(f"Error While Opening {self.urls[0]}, {e}!")

    def _parse_key(self, offset_in_bits: int, length_in_bits: int, output_type: Any) -> Any:
        if not self._loaded:
            self.load_buffer_infos()
        chunks: List[Any] = []
        chunk_delayed_loader = dask.delayed(_load_chunk)
        nb_packet_cache: int = EOConfiguration().__getattr__(PACKET_CACHE_SIZE_PARAM_NAME)
        if output_type == "var_bytearray":
            start_byte = int(offset_in_bits // 8)
            # compute max packet size for output size
            max_packet_length = 0
            for pl in self._packet_length_per_file_bytes:
                if np.max(self._packet_length_per_file_bytes[pl]) > max_packet_length:
                    max_packet_length = np.max(self._packet_length_per_file_bytes[pl])
            shape = (self._n_packets, int(max_packet_length - start_byte))
            dtype = np.uint8
            k_global: int = 0
            for url in self.urls:
                k = 0
                output_packets = int(self._n_packets_per_file[url])
                while k < output_packets:
                    nb_packet_loaded = min(nb_packet_cache, output_packets - k)
                    scattered_length = scatter(self._packet_length_per_file_bytes[url][k : k + nb_packet_loaded])
                    chunk = da.from_delayed(
                        chunk_delayed_loader(
                            url,
                            int(np.sum(self._packet_length_per_file_bytes[url][k : k + nb_packet_loaded])),
                            self._packet_offset_per_file_bytes[url][k],
                            start_byte,
                            -1,
                            slice(k, k + nb_packet_loaded),
                            shape,
                            dtype,
                            scattered_length,
                            None,
                            None,
                            dtype=np.dtype("B"),
                        ),
                        shape=(nb_packet_loaded,) + shape[1:],
                        dtype=dtype,
                    )
                    chunks.append(chunk)
                    k += nb_packet_loaded
                k_global += int(self._n_packets_per_file[url])
            return da.concatenate(chunks)

        elif output_type == "bytearray":
            start_byte = offset_in_bits // 8
            end_byte = length_in_bits // 8 + start_byte
            count_byte = end_byte - start_byte
            shape = (self._n_packets, length_in_bits // 8)
            dtype = np.uint8
            k_global = 0
            for url in self.urls:
                k = 0
                output_packets = int(self._n_packets_per_file[url])
                while k < output_packets:
                    nb_packet_loaded = min(nb_packet_cache, output_packets - k)
                    scattered_length = scatter(self._packet_length_per_file_bytes[url][k : k + nb_packet_loaded])
                    chunk = da.from_delayed(
                        chunk_delayed_loader(
                            url,
                            int(np.sum(self._packet_length_per_file_bytes[url][k : k + nb_packet_loaded])),
                            self._packet_offset_per_file_bytes[url][k],
                            start_byte,
                            count_byte,
                            slice(k, k + nb_packet_loaded),
                            shape,
                            dtype,
                            scattered_length,
                            None,
                            None,
                            dtype=np.dtype("B"),
                        ),
                        shape=(nb_packet_loaded,) + shape[1:],
                        dtype=dtype,
                    )
                    chunks.append(chunk)
                    k += nb_packet_loaded
                k_global += self._n_packets_per_file[url]
            return da.concatenate(chunks, axis=0)

        else:
            # Special case when we want a single value, we take the first file
            if output_type[:2] == "s_":
                output_type = output_type[2:]
                parameter = np.zeros(1, dtype=output_type)
                start_byte = offset_in_bits // 8
                end_byte = (offset_in_bits + length_in_bits - 1) // 8 + 1
                shift = end_byte * 8 - (offset_in_bits + length_in_bits)
                mask = np.sum(2 ** np.arange(length_in_bits))
                offset = start_byte
                count_byte = end_byte - start_byte

                with self.urls[0].open("rb") as f:
                    data = np.fromfile(f, dtype=np.dtype("B"), count=count_byte, offset=offset)
                    parameter[0] = (int.from_bytes(data, "big") >> shift) & mask
                return da.from_array(parameter)
            # General case
            output_packets = self._n_packets
            shape_one = (output_packets,)
            start_byte = offset_in_bits // 8
            end_byte = (offset_in_bits + length_in_bits - 1) // 8 + 1
            shift = end_byte * 8 - (offset_in_bits + length_in_bits)
            mask = np.sum(2 ** np.arange(length_in_bits))
            count_byte = end_byte - start_byte

            k_global = 0
            for url in self.urls:
                offset = start_byte
                with url.open("rb") as f:
                    k = 0
                    output_packets = int(self._n_packets_per_file[url])
                    while k < output_packets:
                        nb_packet_loaded = min(nb_packet_cache, output_packets - k)
                        scattered_length = scatter(self._packet_length_per_file_bytes[url][k : k + nb_packet_loaded])
                        chunk = da.from_delayed(
                            chunk_delayed_loader(
                                url,
                                int(np.sum(self._packet_length_per_file_bytes[url][k : k + nb_packet_loaded])),
                                self._packet_offset_per_file_bytes[url][k],
                                start_byte,
                                count_byte,
                                slice(k, k + nb_packet_loaded),
                                shape_one,
                                output_type,
                                scattered_length,
                                mask,
                                shift,
                                dtype=np.dtype("B"),
                            ),
                            shape=(nb_packet_loaded,),
                            dtype=output_type,
                        )
                        chunks.append(chunk)
                        k += nb_packet_loaded
                    k_global += self._n_packets_per_file[url]
            return da.concatenate(chunks, axis=0)

    def write_key(self, offset_in_bits: int, length_in_bits: int, parameter: NDArray[Any], output_type: Any) -> None:
        if self._buffer is None:
            raise IOError("Buffer is not initialized !")

        if isinstance(parameter, np.ndarray):
            if parameter.size == 0 and length_in_bits != 0:
                raise AccessorInvalidRequestError("Given data is 0 length while it should not")
        elif len(parameter) == 0 and length_in_bits != 0:
            raise AccessorInvalidRequestError("Given data is 0 length while it should not")

        if output_type == "var_bytearray":
            self._write_var_bytearray(offset_in_bits, parameter)
            return

        elif output_type == "bytearray":
            self._write_bytearray(offset_in_bits, length_in_bits, parameter)
            return

        else:
            self._write_scalar(offset_in_bits, length_in_bits, parameter, output_type)
            return

    def _write_scalar(
        self,
        offset_in_bits: int,
        length_in_bits: int,
        parameter: NDArray[Any],
        output_type: Any,
    ) -> None:
        if parameter.ndim != 1:
            raise AccessorInvalidRequestError(
                f"Data should be of ndim 1 for single element, given {parameter.ndim}",
            )
        output_packets = self._n_packets
        if output_type[:2] == "s_":
            output_packets = 1
            output_type = output_type[2:]
        start_byte = offset_in_bits // 8
        end_byte = (offset_in_bits + length_in_bits - 1) // 8 + 1
        shift = end_byte * 8 - (offset_in_bits + length_in_bits)
        count_byte = end_byte - start_byte
        if output_packets == 1:
            self._write_single_scalar(count_byte, output_type, parameter, shift, start_byte)
        else:
            for k in range(self._n_packets):
                offset_byte = int(self._packet_offset_bytes[k]) + start_byte
                if output_type == "float":
                    self._buffer[offset_byte : offset_byte + count_byte] |= np.frombuffer(  # noqa
                        int(np.frombuffer(ctypes.c_float(parameter[k]), "uint32") << shift).to_bytes(  # type: ignore # noqa
                            count_byte,
                            "big",
                        ),
                        "uint8",
                        count_byte,
                        0,
                    )
                elif output_type == "double":
                    self._buffer[offset_byte : offset_byte + count_byte] |= np.frombuffer(  # noqa
                        int(np.frombuffer(ctypes.c_double(parameter[k]), "uint64") << shift).to_bytes(  # type: ignore # noqa
                            count_byte,
                            "big",
                        ),
                        "uint8",
                        count_byte,
                        0,
                    )
                elif output_type == "uint64":
                    self._buffer[offset_byte : offset_byte + count_byte] |= np.frombuffer(  # noqa
                        int(np.frombuffer(ctypes.c_uint64(parameter[k]), "uint64") << shift).to_bytes(  # type: ignore # noqa
                            count_byte,
                            "big",
                        ),
                        "uint8",
                        count_byte,
                        0,
                    )
                else:
                    self._buffer[offset_byte : offset_byte + count_byte] |= np.frombuffer(  # noqa
                        int(parameter[k] << shift).to_bytes(count_byte, "big"),
                        "uint8",
                        count_byte,
                        0,
                    )

    def _write_single_scalar(
        self,
        count_byte: int,
        output_type: Any,
        parameter: NDArray[Any],
        shift: int,
        start_byte: int,
    ) -> None:
        if output_type == "float":
            arr_to_cast = np.frombuffer(ctypes.c_float(parameter[0]), "uint32")  # type: ignore
        elif output_type == "double":
            arr_to_cast = np.frombuffer(ctypes.c_double(parameter[0]), "uint64")  # type: ignore
            if shift:
                raise AccessorInvalidRequestError("Not possible to have shift on a unint64 type !!!")
        elif output_type == "uint64":
            arr_to_cast = np.array(np.frombuffer(ctypes.c_uint64(parameter[0]), "uint64")[0])  # type: ignore
            if shift:
                raise AccessorInvalidRequestError("Not possible to have shift on a unint64 type !!!")
        else:
            arr_to_cast = np.array(parameter[0])
        data_to_cast = arr_to_cast << shift if shift != 0 else arr_to_cast
        param = np.frombuffer(
            int(data_to_cast).to_bytes(
                count_byte,
                "big",
            ),
            "uint8",
            count_byte,
            0,
        )
        offset_byte = int(self._packet_offset_bytes[0]) + start_byte
        self._buffer[offset_byte : offset_byte + count_byte] |= param  # noqa

    def _write_bytearray(self, offset_in_bits: int, length_in_bits: int, parameter: NDArray[Any]) -> None:
        if parameter.ndim != 2:
            raise AccessorInvalidRequestError(f"Data should be of ndim 2 for bytearray, given {parameter.ndim}")
        start_byte = offset_in_bits // 8
        end_byte = length_in_bits // 8 + start_byte
        count_byte = end_byte - start_byte
        for k in range(self._n_packets):
            offset_byte = int(self._packet_offset_bytes[k]) + start_byte
            self._buffer[offset_byte : offset_byte + count_byte] = parameter[k, 0:count_byte]  # noqa

    def _write_var_bytearray(self, offset_in_bits: int, parameter: NDArray[Any]) -> None:
        if parameter.ndim != 2:
            raise AccessorInvalidRequestError(f"Data should be of ndim 2 for bytearray, given {parameter.ndim}")
        start_byte = int(offset_in_bits // 8)
        for k in range(int(self._n_packets)):
            end_byte = int(self._packet_length_bytes[k])
            offset_byte = int(self._packet_offset_bytes[k]) + start_byte
            count_byte = end_byte - start_byte
            self._buffer[offset_byte : offset_byte + count_byte] = parameter[k, 0:count_byte]  # noqa


class MemMap(MultipleFileMemMap):
    def __init__(
        self,
        url: str | AnyPath,
        primary_header_length_bytes: int,
        ancillary_header_length_bytes: int,
        packet_length_start_position_bytes: int,
        packet_length_stop_position_bytes: int,
    ):
        super().__init__(
            [AnyPath.cast(url)],
            primary_header_length_bytes,
            ancillary_header_length_bytes,
            packet_length_start_position_bytes,
            packet_length_stop_position_bytes,
        )
        if hasattr(self, "url"):
            return
        self.url: AnyPath = AnyPath.cast(url)


class FixedMemMap(MultipleFileMemMap):
    def __init__(
        self,
        url: str | AnyPath,
        fixed_packet_length_bytes: int,
    ):
        super().__init__(
            [AnyPath.cast(url)],
            0,
            0,
            0,
            0,
        )
        self._size: Optional[int] = None
        if hasattr(self, "url"):
            return
        self.url: AnyPath = AnyPath.cast(url)
        self.fixed_packet_length_bytes: int = fixed_packet_length_bytes

    def build_buffer(self, packet_number: int) -> None:
        if self._buffer is None:
            self._n_packets = packet_number
            self._size = self.fixed_packet_length_bytes * self._n_packets
            self._packet_length_bytes = np.full(
                self._n_packets,
                dtype="uint",
                fill_value=self.fixed_packet_length_bytes,
            )
            self._packet_offset_bytes = np.zeros(self._n_packets, dtype="uint")
            for i in range(self._n_packets):
                self._packet_offset_bytes[i] = i * self.fixed_packet_length_bytes
            self._buffer = np.zeros(self._size, dtype="uint8")
            self._to_be_saved = True

    def load_buffer_infos(self) -> None:
        if self._loaded:
            return

        try:
            self._size = int(self.url.info()["size"])
        except IOError as e:
            raise IOError(f"Error While Opening {self.url}, {e}!")

        if self._size % self.fixed_packet_length_bytes != 0:
            self._log.warning(
                f"Packet length doesn't match with the file size : {self._size} % "
                f"{self.fixed_packet_length_bytes} != 0 on {self.url}",
            )

        self._n_packets_per_file[self.url] = int(self._size / self.fixed_packet_length_bytes)
        self._n_packets = self._n_packets_per_file[self.url]
        if self.fixed_packet_length_bytes > np.iinfo("uint16").max:
            self._packet_length_per_file_bytes[self.url] = np.full(
                self._n_packets_per_file[self.url],
                dtype="uint16",
                fill_value=self.fixed_packet_length_bytes,
            )
        else:
            self._packet_length_per_file_bytes[self.url] = np.full(
                self._n_packets_per_file[self.url],
                dtype="uint32",
                fill_value=self.fixed_packet_length_bytes,
            )
        self._packet_offset_per_file_bytes[self.url] = np.zeros(self._n_packets_per_file[self.url], dtype="uint")
        self._packet_offset_per_file_bytes[self.url] = range(
            0,
            self._n_packets * self.fixed_packet_length_bytes,
            self.fixed_packet_length_bytes,
        )

        # End for each url
        # Clear buffer
        self._buffer = None
        # Mark as loaded
        self._loaded = True
