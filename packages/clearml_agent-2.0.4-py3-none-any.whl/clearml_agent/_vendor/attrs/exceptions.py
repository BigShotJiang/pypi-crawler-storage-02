# SPDX-License-Identifier: MIT

from ..._vendor.attr.exceptions import *  # noqa
