

class ValidationError(RuntimeError):

    pass


class FieldNotFound(RuntimeError):

    pass


class FieldNotSupported(ValueError):

    pass
