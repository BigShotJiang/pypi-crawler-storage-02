from setuptools import setup

setup(name='echo21',
version='1.1.2',
description='Exploring the Cosmos with Hydrogen Observation',
url='https://github.com/shikharmittal04/echo21/',
author='Shikhar Mittal',
author_email='shikhar.mittal4@gmail.com',
license='MIT',
packages=['echo21'],
zip_safe=False)
