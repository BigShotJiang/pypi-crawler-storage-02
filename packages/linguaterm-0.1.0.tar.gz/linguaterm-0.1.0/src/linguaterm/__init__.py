def main() -> None:
    print("Hello from linguaterm!")
