"""Unit tests for security module."""
