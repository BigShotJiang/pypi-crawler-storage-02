
from achs_mlops_quality import HelloQuality

def main():
    print("Hello from a092-ca-mlops-quality-assurance!")


if __name__ == "__main__":
    main()
    _ = HelloQuality()
