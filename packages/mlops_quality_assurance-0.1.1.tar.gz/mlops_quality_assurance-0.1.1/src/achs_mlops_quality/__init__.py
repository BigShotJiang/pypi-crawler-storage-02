

class HelloQuality:
    def __init__(self):
        print("Hello from achs mlops quality")