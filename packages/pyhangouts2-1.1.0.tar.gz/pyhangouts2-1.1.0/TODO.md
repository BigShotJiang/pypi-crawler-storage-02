# To do list for Google Chat Utils
## PyHangouts2
* ~~List all messages in a chat~~
* ~~Finalize PyHangouts2~~
## G-ChaTTY
* ~~Add ability to send messages~~
## `thechatwouldbewatching`
* ~~Make it stable~~
## Other projects
* ~~Switch to using `PyHangouts2` for the utils~~

<!--
SPDX-FileCopyrightText: 2025 NexusSfan <nexussfan@duck.com>
SPDX-License-Identifier: CC0-1.0
-->
