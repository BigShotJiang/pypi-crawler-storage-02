# Google Chat Utils
Misc. tools for Google Chat.

## Disclaimer
Google is a registered trademark.
This project is not affiliated or endorsed by Google.

<!--
SPDX-FileCopyrightText: 2025 NexusSfan <nexussfan@duck.com>
SPDX-License-Identifier: CC0-1.0
-->
