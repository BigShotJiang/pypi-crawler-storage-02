"""Common utilities and base classes for dataknobs packages."""

__version__ = "1.0.0"
