from ._version import version

__version__ = version

__all__ = ["__version__"]
