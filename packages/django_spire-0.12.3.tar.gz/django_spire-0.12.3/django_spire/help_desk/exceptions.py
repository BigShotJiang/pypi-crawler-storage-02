class TicketEventNotificationTypeNotSupportedError(TypeError):
    pass

class HelpDeskNotificationRecipientMissingEmailError(ValueError):
    pass