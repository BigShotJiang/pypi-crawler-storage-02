"""
Zscaler MCP Server Package

This package provides the Zscaler MCP server with support for ZIA, ZPA, ZDX,
and ZCC services.
"""

__version__ = "0.1.0"
