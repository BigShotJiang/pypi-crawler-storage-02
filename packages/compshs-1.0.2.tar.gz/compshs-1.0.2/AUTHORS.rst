=======
Credits
=======

The project started in the Interdisciplinary Institute of Innovation (i3) in 2025, within the Digital Technologies, Organization and Society research group.

Development Lead
----------------

* Tiphaine Viard <tiphaine.viard@telecom-paris.fr>
* Simon Delarue <simon.delarue@telecom-paris.fr>

Contributors
------------

* Simon Delarue
