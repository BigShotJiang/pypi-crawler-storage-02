# sage_setup: distribution = sagemath-fricas
# delvewheel: patch

from sage.all__sagemath_symbolics import *
