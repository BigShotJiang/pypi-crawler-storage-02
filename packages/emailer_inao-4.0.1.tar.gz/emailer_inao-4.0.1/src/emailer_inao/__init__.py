"""
Emailer-INAO: A personalized email campaign management tool.
"""

__version__ = "4.0.1"
__author__ = "INAO Team"
__description__ = "Send personalized emails to recipients with campaign management"
