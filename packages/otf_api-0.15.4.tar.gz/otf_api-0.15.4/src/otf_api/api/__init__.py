from otf_api.api.api import Otf

__all__ = ["Otf"]
