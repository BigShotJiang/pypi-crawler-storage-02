Extends Partner Financial Risk to manage stock moves.

If any limit is exceed the partner gets forbidden to transfer stock
move.
