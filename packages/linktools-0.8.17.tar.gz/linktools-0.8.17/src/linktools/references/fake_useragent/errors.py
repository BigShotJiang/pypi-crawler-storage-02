class FakeUserAgentError(Exception):
    pass


# common alias
UserAgentError = FakeUserAgentError
