from .errors import FakeUserAgentError, UserAgentError
from .fake import FakeUserAgent, UserAgent
from .settings import __version__ as VERSION
