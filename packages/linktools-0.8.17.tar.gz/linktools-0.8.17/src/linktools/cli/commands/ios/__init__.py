__command__ = "it"
__description__ = "iOS scripts"
__order__ = "\x1f300-ios"
