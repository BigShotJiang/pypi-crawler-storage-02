"""Package for instantiating internal API clients"""

from symphony.bdk.core.client.trace_id import setup_trace_id_log_record_factory

setup_trace_id_log_record_factory()
