"""Package containing modules and packages related to services (message, stream, user, etc.)"""
