"""
Module to include code that has to be removed
but has some interesting functionalities that
must be reviewed and maybe preserved in other
classes.

The modules are included here to let the main
project folder be clean and clear.
"""