"""Core package for Sweet data engineering utilities."""
