"""UI package for Sweet Textual application."""
