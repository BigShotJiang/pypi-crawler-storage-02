THEMES = {
            "romance": [
                        "🍆💦🌹➡️🥀 Forbidden love happened.",
                        "🦐🍤🍽️🫄 Your code thought it cooked but I ate it and got indigestion."
                        ],
            "sad": [
                        "🪦😢☔️🖤 RIP code, your creator is too retarded to make it work",
                        "😭💔⛄️💧 In the coldest of winter, a snowman would melt looking at the dumpster fire that is your code."
                        ],
            "danger": [
                    "☢️🔥💥💀 This code is a biohazard to my sanity.",
                    "💣🛠️🤡⚡ Explosive clown engineering detected, don't hit run again or this code will probably explode.",
                    "⚡💻💀🧨 Voltage spike! Your code has died... again."
                        ]
            }
