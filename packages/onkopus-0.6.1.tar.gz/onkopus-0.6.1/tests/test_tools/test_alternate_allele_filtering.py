import unittest

class AlternateAlleleTestCase(unittest.TestCase):

    def test_alternate_allele_filter(self):
        pass
