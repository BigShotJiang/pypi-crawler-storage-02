#from adagenes.tools import generate_keys

class DefaultFeaturesClient:
    def __init__(self, genome_version, error_logfile=None):
        self.genome_version = genome_version

    def process_data(self, biomarker_data):

        #biomarker_data = generate_keys(biomarker_data)
        #return biomarker_data
        pass
