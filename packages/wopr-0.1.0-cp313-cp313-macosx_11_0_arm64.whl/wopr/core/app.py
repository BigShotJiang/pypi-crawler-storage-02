"""
Main WOPR application class
"""

import asyncio
import re
import uuid
from types import SimpleNamespace
from typing import Callable, Dict, List, Optional, Tuple, Any

from ..log import log
from ..http.request import Request
from ..http.response import Response, JSONResponse, FileResponse, StreamResponse
from ..http.routing import RouteHandler
from ..websocket.connection import WebSocket
from ..tasks.queue import TaskQueue, TaskPriority
from ..templates.engine import TemplateEngine

# PEP 695 Type Aliases for cleaner annotations
type Handler = Callable[..., Any]
type ErrorHandler = Callable[[Request, Exception], Response]
type RouteResult = tuple[Optional[RouteHandler], dict[str, str]]
type Middleware = Callable[[Request, Callable[[Request], Any]], Response]
type MiddlewareTuple = tuple[Middleware, int]

try:
    from wopr._core import Router
    RUST_ROUTER_AVAILABLE = True
except ImportError:
    RUST_ROUTER_AVAILABLE = False

try:
    from granian.rsgi import Scope, HTTPProtocol, WebsocketProtocol
except ImportError:
    from typing import TypedDict
    # Fallback types for development without Granian
    class Scope(TypedDict, total=True):
        proto: str
        method: str
        path: str
        query_string: str
        headers: Any

    class HTTPProtocol:
        async def __call__(self): pass
        def response_str(self, status, headers, body): pass
        def response_bytes(self, status, headers, body): pass
        def response_file(self, status, headers, file): pass
        def response_stream(self, status, headers): pass
    
    class WebsocketProtocol:
        async def accept(self): pass


class WOPR:
    """Main WOPR application class"""
    
    def __init__(self, name: str = __name__):
        self.name = name
        self.logger = log
        self.routes: list[RouteHandler] = []
        self.error_handlers: dict[int, ErrorHandler] = {}
        self.before_request_handlers: list[Handler] = []
        self.after_request_handlers: list[Handler] = []
        self.middleware: list[MiddlewareTuple] = []
        self.template_context_processors: list[Callable[[], dict]] = []
        
        # Initialize components
        self.template_engine = None
        self.task_queue = TaskQueue()

        # Routing
        self.rust_router_available = RUST_ROUTER_AVAILABLE
        if self.rust_router_available:
            self.http_router = Router()
            self.websocket_router = Router()
            self.logger.info("🚀 Found wopr-core-rs, using Rust-based router for high performance.")
        else:
            self.http_router = None
            self.websocket_router = None
            self.logger.info("⚠️ wopr-core-rs not found, falling back to Python-based router.")
        
        # Default error handlers
        self.error_handlers[404] = self._default_404_handler
        self.error_handlers[500] = self._default_500_handler
    
    def init_templates(self, template_folder: str = "templates", **kwargs):
        """Initialize template engine"""
        self.template_engine = TemplateEngine(template_folder, **kwargs)
    
    def add_middleware(self, middleware: Middleware, priority: int = 0):
        """
        Add middleware to the application with an optional priority.
        Middleware with higher priority is executed first.
        """
        self.middleware.append((middleware, priority))
        # Sort middleware by priority, descending
        self.middleware.sort(key=lambda item: item[1], reverse=True)

    def route(self, path: str, methods: list[str] = None):
        """Decorator to register HTTP routes"""
        if methods is None:
            methods = ['GET']
        
        def decorator(func: Handler) -> Handler:
            handler = RouteHandler(path, func, methods)
            if self.rust_router_available:
                rust_path = re.sub(r'<([^>]+)>', r':\1', path)
                for method in methods:
                    self.http_router.insert(f"{method.upper()}{rust_path}", handler)
            else:
                self.routes.append(handler)
            return func
        return decorator

    def get(self, path: str):
        return self.route(path, ['GET'])
    
    def post(self, path: str):
        return self.route(path, ['POST'])
    
    def put(self, path: str):
        return self.route(path, ['PUT'])
    
    def delete(self, path: str):
        return self.route(path, ['DELETE'])
    
    def patch(self, path: str):
        return self.route(path, ['PATCH'])
    
    def options(self, path: str):
        return self.route(path, ['OPTIONS'])
    
    def websocket(self, path: str):
        """Decorator for WebSocket routes"""
        def decorator(func: Handler) -> Handler:
            handler = RouteHandler(path, func, [], is_websocket=True)
            if self.rust_router_available:
                rust_path = re.sub(r'<([^>]+)>', r':\1', path)
                self.websocket_router.insert(rust_path, handler)
            else:
                self.routes.append(handler)
            return func
        return decorator
    
    def task(self, name: str = None, category: str = "default"):
        """Decorator to register background task"""
        def decorator(func: Handler) -> Handler:
            task_name = name or func.__name__
            self.task_queue.register_task(task_name, category)(func)
            return func
        return decorator
    
    def before_request(self, func: Handler) -> Handler:
        """Register before request handler"""
        self.before_request_handlers.append(func)
        return func
    
    def after_request(self, func: Handler) -> Handler:
        """Register after request handler"""
        self.after_request_handlers.append(func)
        return func
    
    def context_processor(self, func: Callable[[], dict]) -> Callable[[], dict]:
        """Register template context processor"""
        self.template_context_processors.append(func)
        return func
    
    def template_filter(self, name: str = None):
        """Decorator to register template filter"""
        def decorator(func):
            if self.template_engine:
                filter_name = name or func.__name__
                self.template_engine.add_filter(filter_name, func)
            return func
        return decorator
    
    def template_global(self, name: str = None):
        """Decorator to register template global"""
        def decorator(func):
            if self.template_engine:
                global_name = name or func.__name__
                self.template_engine.add_global(global_name, func)
            return func
        return decorator
    
    def error_handler(self, status_code: int):
        """Decorator to register error handler"""
        def decorator(func: ErrorHandler) -> ErrorHandler:
            self.error_handlers[status_code] = func
            return func
        return decorator
    
    async def render_template(self, template_name: str, **context) -> Response:
        """Render template and return Response"""
        if not self.template_engine:
            raise RuntimeError("Template engine not initialized. Call init_templates() first.")
        
        # Apply context processors
        for processor in self.template_context_processors:
            if asyncio.iscoroutinefunction(processor):
                context.update(await processor() or {})
            else:
                context.update(processor() or {})
        
        html = await self.template_engine.render_template_async(template_name, **context)
        return Response(html, content_type='text/html')
    
    async def add_background_task(self, name: str, category: str = "default", 
                                 priority: TaskPriority = TaskPriority.NORMAL,
                                 max_retries: int = 0, *args, **kwargs) -> str:
        """Add background task to queue"""
        return await self.task_queue.add_task(name, category, priority, max_retries, *args, **kwargs)
    
    async def start_task_workers(self, category: str = "default", worker_count: int = 1):
        """Start background task workers"""
        await self.task_queue.start_workers(category, worker_count)
    
    def _find_route(self, path: str, method: str, is_websocket: bool = False) -> RouteResult:
        """Find matching route and extract path parameters"""
        if self.rust_router_available:
            if is_websocket:
                router = self.websocket_router
                lookup_path = path
            else:
                router = self.http_router
                lookup_path = f"{method.upper()}{path}"

            match = router.get(lookup_path)
            if match:
                handler, params = match
                return handler, params
            return None, {}

        # Fallback to original python implementation
        for route in self.routes:
            if route.is_websocket == is_websocket:
                params = route.match(path, method)
                if params is not None:
                    return route, params
        return None, {}
    
    async def _apply_middleware(self, request: Request) -> Optional[Response]:
        """Apply middleware chain"""
        async def call_next(req: Request) -> None:
            return None  # Continue to route handling
        
        handler: Callable[[Request], Any] = call_next
        
        # Build middleware chain in reverse order of priority
        # The list is already sorted, so we just need to iterate
        for middleware_func, _ in reversed(self.middleware):
            # Correctly type the `next_handler`
            def make_next_handler(mw: Middleware, next_h: Callable[[Request], Any]) -> Callable[[Request], Any]:
                async def created(req: Request) -> Any:
                    return await mw(req, next_h)
                return created
            handler = make_next_handler(middleware_func, handler)
        
        # Execute middleware chain
        return await handler(request)
    
    async def _default_404_handler(self, request: Request, error: Exception) -> Response:
        return Response(f"Not Found: {request.path}", status=404, content_type='text/plain')
    
    async def _default_500_handler(self, request: Request, error: Exception) -> Response:
        return Response(f"Internal Server Error: {str(error)}", status=500, content_type='text/plain')
    
    async def _handle_http(self, scope: Scope, protocol: HTTPProtocol):
        """Handle HTTP request"""
        request = Request(scope, protocol)
        request_id = str(uuid.uuid4())
        request.id = request_id
        request.logger = self.logger

        with self.logger.contextualize(request_id=request_id):
            request.logger = self.logger  # Re-assign contextualized logger
            original_after_request_handlers = self.after_request_handlers[:]
            try:
                # Add request ID to response headers
                async def add_request_id_header(req, res):
                    if hasattr(res, 'headers'):
                        res.headers['x-request-id'] = req.id
                    return res
                self.after_request_handlers.insert(0, add_request_id_header)

                self.logger.info(f"-> {request.method} {request.path} from {request.client_ip}")

                # Apply middleware
                middleware_response = await self._apply_middleware(request)
                if middleware_response:
                    await self._send_response(protocol, middleware_response)
                    return

                # Run before request handlers
                for handler in self.before_request_handlers:
                    result = await handler(request) if asyncio.iscoroutinefunction(handler) else handler(request)
                    if isinstance(result, Response):
                        await self._send_response(protocol, result)
                        return

                # Find route
                route, path_params = self._find_route(request.path, request.method)

                if not route:
                    response = await self.error_handlers[404](request, Exception("Not Found"))
                else:
                    if path_params:
                        response = await route.handler(request, **path_params) if asyncio.iscoroutinefunction(route.handler) else route.handler(request, **path_params)
                    else:
                        response = await route.handler(request) if asyncio.iscoroutinefunction(route.handler) else route.handler(request)

                    if not isinstance(response, (Response, FileResponse, StreamResponse)):
                        response = JSONResponse(response) if isinstance(response, (dict, list)) else Response(str(response))

                # Run after request handlers
                for handler in self.after_request_handlers:
                    response = (await handler(request, response) or response) if asyncio.iscoroutinefunction(handler) else (handler(request, response) or response)

                await self._send_response(protocol, response)

            except Exception as e:
                log.exception(f"Unhandled exception in HTTP handler for {request.path}")
                try:
                    handler = self.error_handlers.get(500, self._default_500_handler)
                    response = await handler(request, e)
                    await self._send_response(protocol, response)
                except Exception as inner_e:
                    log.exception(f"Exception in error handler for {request.path}")
                    protocol.response_str(500, [], f"Internal Server Error: {str(inner_e)}")
            finally:
                # Restore original handlers
                self.after_request_handlers = original_after_request_handlers

    async def _handle_websocket(self, scope: Scope, protocol: WebsocketProtocol):
        """Handle WebSocket connection"""
        websocket = WebSocket(scope, protocol)
        route, path_params = self._find_route(scope.path, 'WEBSOCKET', is_websocket=True)

        if not route:
            log.warning(f"No WebSocket route found for path: {scope.path}")
            # Ensure protocol has a close method before calling it.
            if hasattr(protocol, 'close'):
                await protocol.close(1001) # 1001: "Going Away"
            return

        try:
            handler_coro = route.handler(websocket, **path_params)
            await handler_coro
        except Exception as e:
            log.error(f"Error in WebSocket handler for {scope['path']}: {e}", exc_info=True)
            if hasattr(protocol, 'close'):
                await protocol.close(1011) # 1011: "Internal Error"
    
    async def _send_response(self, protocol: HTTPProtocol, response: Response):
        """Send response using RSGI protocol"""
        if isinstance(response, FileResponse):
            protocol.response_file(response.status, response.to_rsgi_headers(), response.file_path)
        elif isinstance(response, StreamResponse):
            transport = protocol.response_stream(response.status, [(k, v) for k, v in response.headers.items()])
            async for chunk in response.generator():
                if isinstance(chunk, str):
                    await transport.send_str(chunk)
                else:
                    await transport.send_bytes(chunk)
        else:
            if isinstance(response.body, str):
                protocol.response_str(response.status, response.to_rsgi_headers(), response.body)
            else:
                protocol.response_bytes(response.status, response.to_rsgi_headers(), response.body)
    
    async def __rsgi__(self, scope: Scope, protocol):
        """RSGI application entry point"""
        # If the scope is a dict (from a test client), convert it to an object
        # so the rest of the app can use consistent attribute access.
        if isinstance(scope, dict):
            # The ASGI test client scope doesn't have 'proto', so we add it.
            scope.setdefault('proto', scope.get('type', 'http'))
            scope = SimpleNamespace(**scope)

        if scope.proto == 'http':
            await self._handle_http(scope, protocol)
        elif scope.proto in ('ws', 'websocket'):
            await self._handle_websocket(scope, protocol)