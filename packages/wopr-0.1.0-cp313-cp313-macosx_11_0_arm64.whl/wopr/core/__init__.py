"""
Core application components for Tempest framework
"""

from .app import WOPR

__all__ = [
    "WOPR",
]