"""
Task queue management for Tempest framework
"""

import asyncio
import uuid
from collections import defaultdict
from datetime import datetime
from typing import Callable, Dict, List, Optional

from .models import TaskInfo, TaskStatus, TaskPriority
from .storage import TaskStorage


class TaskQueue:
    """Background task queue with DuckDB storage"""
    
    def __init__(self):
        self.queues: Dict[str, asyncio.PriorityQueue] = {}
        self.running_tasks: Dict[str, TaskInfo] = {}
        self.workers: Dict[str, List[asyncio.Task]] = {}
        self.storage = TaskStorage()
        self.shutdown_event = asyncio.Event()
        self.task_functions: Dict[str, Callable] = {}
    
    def register_task(self, name: str, category: str = "default"):
        """Decorator to register a task function"""
        def decorator(func):
            self.task_functions[name] = func
            return func
        return decorator
    
    async def add_task(self, name: str, category: str = "default", 
                      priority: TaskPriority = TaskPriority.NORMAL,
                      max_retries: int = 0, *args, **kwargs) -> str:
        """Add task to queue"""
        if name not in self.task_functions:
            raise ValueError(f"Task '{name}' not registered")
        
        task_info = TaskInfo(
            id=str(uuid.uuid4()), name=name, category=category,
            priority=priority, status=TaskStatus.PENDING,
            created_at=datetime.now(), max_retries=max_retries,
            args=args, kwargs=kwargs
        )
        
        self.storage.save_task(task_info)
        
        if category not in self.queues:
            self.queues[category] = asyncio.PriorityQueue()
        
        await self.queues[category].put((-priority.value, task_info.id, task_info))
        return task_info.id
    
    async def get_task_info(self, task_id: str) -> Optional[TaskInfo]:
        """Get task information by ID"""
        # Check running tasks first
        if task_id in self.running_tasks:
            return self.running_tasks[task_id]
        
        # Check storage
        return self.storage.get_task(task_id)
    
    async def cancel_task(self, task_id: str) -> bool:
        """Cancel a pending task"""
        task_info = await self.get_task_info(task_id)
        if not task_info:
            return False
        
        if task_info.status == TaskStatus.PENDING:
            task_info.status = TaskStatus.CANCELLED
            task_info.completed_at = datetime.now()
            self.storage.save_task(task_info)
            return True
        
        return False
    
    async def retry_task(self, task_id: str) -> bool:
        """Retry a failed task"""
        task_info = await self.get_task_info(task_id)
        if not task_info or task_info.status != TaskStatus.FAILED:
            return False
        
        # Reset task status and re-queue
        task_info.status = TaskStatus.PENDING
        task_info.started_at = None
        task_info.completed_at = None
        task_info.error = None
        task_info.progress = 0.0
        task_info.progress_message = ""
        
        self.storage.save_task(task_info)
        
        if task_info.category not in self.queues:
            self.queues[task_info.category] = asyncio.PriorityQueue()
        
        await self.queues[task_info.category].put(
            (-task_info.priority.value, task_info.id, task_info)
        )
        return True
    
    async def get_task_stats(self) -> dict:
        """Get aggregate task statistics"""
        all_tasks = self.storage.get_tasks(limit=1000)  # Get recent tasks
        
        stats = {
            "total": len(all_tasks),
            "by_status": defaultdict(int),
            "by_category": defaultdict(int),
            "running": len(self.running_tasks),
            "queued": sum(queue.qsize() for queue in self.queues.values())
        }
        
        for task in all_tasks:
            stats["by_status"][task.status.value] += 1
            stats["by_category"][task.category] += 1
        
        return dict(stats)
    
    async def start_workers(self, category: str, worker_count: int = 1):
        """Start workers for a category"""
        if category not in self.workers:
            self.workers[category] = []
        
        for i in range(worker_count):
            worker = asyncio.create_task(self._worker(category, i))
            self.workers[category].append(worker)
    
    async def shutdown(self):
        """Shutdown all workers gracefully"""
        self.shutdown_event.set()
        
        # Cancel all workers
        for workers in self.workers.values():
            for worker in workers:
                worker.cancel()
        
        # Wait for workers to finish
        for workers in self.workers.values():
            await asyncio.gather(*workers, return_exceptions=True)
    
    async def _worker(self, category: str, worker_id: int):
        """Worker coroutine to process tasks"""
        if category not in self.queues:
            self.queues[category] = asyncio.PriorityQueue()
        
        queue = self.queues[category]
        
        while not self.shutdown_event.is_set():
            try:
                try:
                    priority, task_id, task_info = await asyncio.wait_for(queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue
                
                await self._execute_task(task_info)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Worker {category}-{worker_id} error: {e}")
    
    async def _execute_task(self, task_info: TaskInfo):
        """Execute a single task"""
        task_func = self.task_functions.get(task_info.name)
        if not task_func:
            task_info.status = TaskStatus.FAILED
            task_info.error = f"Task function '{task_info.name}' not found"
            task_info.completed_at = datetime.now()
            self.storage.save_task(task_info)
            return
        
        task_info.status = TaskStatus.STARTED
        task_info.started_at = datetime.now()
        self.running_tasks[task_info.id] = task_info
        self.storage.save_task(task_info)
        
        try:
            if asyncio.iscoroutinefunction(task_func):
                result = await task_func(*task_info.args, **task_info.kwargs)
            else:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, lambda: task_func(*task_info.args, **task_info.kwargs))
            
            task_info.status = TaskStatus.SUCCESS
            task_info.result = result
            task_info.completed_at = datetime.now()
            task_info.elapsed_seconds = (task_info.completed_at - task_info.started_at).total_seconds()
            task_info.progress = 100.0
            
        except Exception as e:
            task_info.error = str(e)
            task_info.retry_count += 1
            
            if task_info.retry_count <= task_info.max_retries:
                task_info.status = TaskStatus.RETRY
                await asyncio.sleep(min(2 ** task_info.retry_count, 60))
                queue = self.queues[task_info.category]
                await queue.put((-task_info.priority.value, task_info.id, task_info))
            else:
                task_info.status = TaskStatus.FAILED
                task_info.completed_at = datetime.now()
                task_info.elapsed_seconds = (task_info.completed_at - task_info.started_at).total_seconds()
        
        finally:
            if task_info.id in self.running_tasks:
                del self.running_tasks[task_info.id]
            self.storage.save_task(task_info)