"""
Task data models for Tempest framework
"""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    STARTED = "started"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    RETRY = "retry"


class TaskPriority(Enum):
    """Task priority levels"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class TaskInfo:
    """Task information and metadata"""
    id: str
    name: str
    category: str
    priority: TaskPriority
    status: TaskStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    elapsed_seconds: float = 0.0
    result: Any = None
    error: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 0
    args: tuple = ()
    kwargs: dict = None
    progress: float = 0.0
    progress_message: str = ""
    
    def __post_init__(self):
        if self.kwargs is None:
            self.kwargs = {}
    
    @property
    def is_running(self) -> bool:
        return self.status == TaskStatus.STARTED
    
    @property
    def is_completed(self) -> bool:
        return self.status in (TaskStatus.SUCCESS, TaskStatus.FAILED, TaskStatus.CANCELLED)