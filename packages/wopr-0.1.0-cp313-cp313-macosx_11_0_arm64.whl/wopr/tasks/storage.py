"""
Task storage with DuckDB backend for Tempest framework
"""

import json
from dataclasses import asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Union

from .models import TaskInfo, TaskStatus, TaskPriority

try:
    import duckdb
    DUCKDB_AVAILABLE = True
except ImportError:
    DUCKDB_AVAILABLE = False
    duckdb = None


class TaskStorage:
    """DuckDB-based task storage with intelligent cleanup"""
    
    def __init__(self, db_path: Union[str, Path] = "tempest_tasks.duckdb"):
        if not DUCKDB_AVAILABLE:
            raise ImportError("DuckDB is required for task storage. Install: uv add duckdb")
        
        self.db_path = Path(db_path)
        self.connection = None
        self._init_database()
    
    def _init_database(self):
        """Initialize database and tables"""
        self.connection = duckdb.connect(str(self.db_path))
        
        self.connection.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id VARCHAR PRIMARY KEY,
                name VARCHAR NOT NULL,
                category VARCHAR NOT NULL,
                priority INTEGER NOT NULL,
                status VARCHAR NOT NULL,
                created_at TIMESTAMP NOT NULL,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                elapsed_seconds DOUBLE,
                result JSON,
                error TEXT,
                retry_count INTEGER DEFAULT 0,
                max_retries INTEGER DEFAULT 0,
                args JSON,
                kwargs JSON,
                progress DOUBLE DEFAULT 0.0,
                progress_message VARCHAR DEFAULT ''
            )
        """)
        
        # Create indexes for performance
        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category)",
            "CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)",
            "CREATE INDEX IF NOT EXISTS idx_tasks_created_at ON tasks(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_tasks_priority ON tasks(priority)"
        ]
        for idx in indexes:
            self.connection.execute(idx)
    
    def save_task(self, task_info: TaskInfo):
        """Save or update task information"""
        task_dict = asdict(task_info)
        
        # Convert datetime objects to ISO strings
        for key in ['created_at', 'started_at', 'completed_at']:
            if task_dict[key]:
                task_dict[key] = task_dict[key].isoformat()
        
        task_dict['priority'] = task_info.priority.value
        task_dict['status'] = task_info.status.value
        task_dict['args'] = json.dumps(task_dict['args'])
        task_dict['kwargs'] = json.dumps(task_dict['kwargs'])
        task_dict['result'] = json.dumps(task_dict['result'])
        
        self.connection.execute("""
            INSERT OR REPLACE INTO tasks VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
        """, tuple(task_dict.values()))
    
    def get_task(self, task_id: str) -> Optional[TaskInfo]:
        """Get task by ID"""
        result = self.connection.execute(
            "SELECT * FROM tasks WHERE id = ?", (task_id,)
        ).fetchone()
        
        return self._row_to_task_info(result) if result else None
    
    def get_tasks(self, 
                  category: Optional[str] = None,
                  status: Optional[TaskStatus] = None,
                  limit: int = 100,
                  offset: int = 0) -> List[TaskInfo]:
        """Get tasks with filtering"""
        query = "SELECT * FROM tasks WHERE 1=1"
        params = []
        
        if category:
            query += " AND category = ?"
            params.append(category)
        
        if status:
            query += " AND status = ?"
            params.append(status.value)
        
        query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        results = self.connection.execute(query, params).fetchall()
        return [self._row_to_task_info(row) for row in results]
    
    def cleanup_old_tasks(self, days: int = None, months: int = None, years: int = None):
        """Clean up old completed tasks"""
        if not any([days, months, years]):
            return 0
        
        cutoff_date = datetime.now()
        if days:
            cutoff_date -= timedelta(days=days)
        if months:
            cutoff_date -= timedelta(days=months * 30)
        if years:
            cutoff_date -= timedelta(days=years * 365)
        
        result = self.connection.execute("""
            DELETE FROM tasks 
            WHERE completed_at < ? 
            AND status IN ('success', 'failed', 'cancelled')
        """, (cutoff_date.isoformat(),))
        
        return result.rowcount
    
    def _row_to_task_info(self, row) -> TaskInfo:
        """Convert database row to TaskInfo"""
        return TaskInfo(
            id=row[0], name=row[1], category=row[2],
            priority=TaskPriority(row[3]), status=TaskStatus(row[4]),
            created_at=datetime.fromisoformat(row[5]),
            started_at=datetime.fromisoformat(row[6]) if row[6] else None,
            completed_at=datetime.fromisoformat(row[7]) if row[7] else None,
            elapsed_seconds=row[8] or 0.0,
            result=json.loads(row[9]) if row[9] else None,
            error=row[10], retry_count=row[11], max_retries=row[12],
            args=tuple(json.loads(row[13])) if row[13] else (),
            kwargs=json.loads(row[14]) if row[14] else {},
            progress=row[15] or 0.0, progress_message=row[16] or ""
        )