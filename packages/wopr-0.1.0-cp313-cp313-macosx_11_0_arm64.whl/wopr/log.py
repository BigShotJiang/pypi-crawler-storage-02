from loguru import logger
import sys

def setup_logging(level="INFO", sink=sys.stderr):
    """
    Set up Loguru logger.
    """
    log_format = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{extra[request_id]}</cyan> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    )
    logger.remove()
    logger.add(sink, level=level, format=log_format, enqueue=True)

    def patcher(record):
        record["extra"].setdefault("request_id", "startup")

    logger.patch(patcher)
    return logger

# Default logger
log = setup_logging()
