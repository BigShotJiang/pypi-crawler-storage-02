"""
Routing system for Tempest framework
"""

import re
from typing import Callable, Dict, List, Optional
from urllib.parse import unquote


class RouteHandler:
    """Single route handler with pattern matching"""
    
    def __init__(self, pattern: str, handler: Callable, methods: List[str], is_websocket: bool = False):
        self.pattern = pattern
        self.handler = handler
        self.methods = [m.upper() for m in methods]
        self.is_websocket = is_websocket
        self.path_params = []
        self._compile_pattern()
    
    def _compile_pattern(self):
        """Compile pattern for matching and parameter extraction"""
        param_pattern = r'<([^>]+)>'
        self.path_params = re.findall(param_pattern, self.pattern)
        regex_pattern = re.sub(param_pattern, r'([^/]+)', self.pattern)
        self.regex = re.compile(f"^{regex_pattern}$")
    
    def match(self, path: str, method: str) -> Optional[Dict[str, str]]:
        """Check if this route matches the request"""
        if self.is_websocket or method.upper() in self.methods:
            match = self.regex.match(path)
            if match:
                params = {}
                for i, param_name in enumerate(self.path_params):
                    params[param_name] = unquote(match.group(i + 1))
                return params
        return None