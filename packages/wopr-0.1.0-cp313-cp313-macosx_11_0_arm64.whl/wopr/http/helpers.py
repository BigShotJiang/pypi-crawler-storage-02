"""
HTTP helper functions for Tempest framework
"""

from pathlib import Path
from typing import Any, Awaitable, Callable, Optional, Union

from .response import JSONResponse, FileResponse, StreamResponse


def jsonify(data: Any, status: int = 200) -> JSONResponse:
    """Create a JSON response"""
    return JSONResponse(data, status)


def send_file(path: Union[str, Path], filename: Optional[str] = None) -> FileResponse:
    """Send a file as response"""
    return FileResponse(path, filename)


def stream_template(template_generator: Callable[[], Awaitable]) -> StreamResponse:
    """Stream a template response"""
    return StreamResponse(template_generator, content_type='text/html')