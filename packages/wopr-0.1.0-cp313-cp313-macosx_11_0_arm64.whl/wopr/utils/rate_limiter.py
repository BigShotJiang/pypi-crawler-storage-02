"""
Rate limiting utilities for WOPR framework
"""

import time
from collections import defaultdict, deque
from functools import wraps
from typing import Callable, Dict

from ..http.response import Response


class RateLimiter:
    """Token bucket rate limiter"""
    
    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests: Dict[str, deque] = defaultdict(deque)
    
    def is_allowed(self, identifier: str) -> bool:
        """Check if request is allowed for the given identifier"""
        now = time.time()
        window_start = now - self.window_seconds
        
        # Clean old requests
        request_times = self.requests[identifier]
        while request_times and request_times[0] < window_start:
            request_times.popleft()
        
        # Check if under limit
        if len(request_times) < self.max_requests:
            request_times.append(now)
            return True
        
        return False
    
    def get_reset_time(self, identifier: str) -> int:
        """Get timestamp when rate limit resets for identifier"""
        request_times = self.requests[identifier]
        if request_times:
            return int(request_times[0] + self.window_seconds)
        return int(time.time())


def rate_limit(max_requests: int = 100, window_seconds: int = 60, 
               key_func: Callable = None):
    """
    Decorator for rate limiting routes
    
    Args:
        max_requests: Maximum requests allowed in window
        window_seconds: Time window in seconds
        key_func: Function to extract rate limit key from request
    """
    limiter = RateLimiter(max_requests, window_seconds)
    
    def decorator(func):
        @wraps(func)
        async def wrapper(request, *args, **kwargs):
            # Default key function uses client IP
            if key_func:
                key = key_func(request)
            else:
                key = request.headers.get('x-forwarded-for', 'unknown')
            
            if not limiter.is_allowed(key):
                reset_time = limiter.get_reset_time(key)
                headers = {
                    'x-ratelimit-limit': str(max_requests),
                    'x-ratelimit-remaining': '0',
                    'x-ratelimit-reset': str(reset_time),
                    'retry-after': str(window_seconds)
                }
                return Response("Rate limit exceeded", status=429, headers=headers)
            
            # Add rate limit headers to successful responses
            remaining = max_requests - len(limiter.requests[key])
            reset_time = limiter.get_reset_time(key)
            
            response = await func(request, *args, **kwargs)
            
            if hasattr(response, 'headers'):
                response.headers.update({
                    'x-ratelimit-limit': str(max_requests),
                    'x-ratelimit-remaining': str(remaining),
                    'x-ratelimit-reset': str(reset_time)
                })
            
            return response
        
        return wrapper
    return decorator