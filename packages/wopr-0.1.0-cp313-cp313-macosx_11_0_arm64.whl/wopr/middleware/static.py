"""
Static file middleware for Tempest framework
"""

import mimetypes
import os
from pathlib import Path
from typing import Callable

from ..http.request import Request
from ..http.response import Response


class StaticFileMiddleware:
    """Middleware for serving static files"""
    
    def __init__(self, static_dir: str = "static", url_prefix: str = "/static"):
        self.static_dir = Path(static_dir)
        self.url_prefix = url_prefix.rstrip('/')
    
    async def __call__(self, request: Request, call_next: Callable) -> Response:
        """Process request and serve static files if needed"""
        if request.path.startswith(self.url_prefix):
            return await self._serve_static_file(request)
        
        return await call_next(request)
    
    async def _serve_static_file(self, request: Request) -> Response:
        """Serve a static file"""
        # Remove URL prefix to get relative path
        relative_path = request.path[len(self.url_prefix):].lstrip('/')
        
        # Security: prevent directory traversal
        if '..' in relative_path or relative_path.startswith('/'):
            return Response("Forbidden", status=403)
        
        file_path = self.static_dir / relative_path
        
        # Check if file exists and is within static directory
        try:
            file_path = file_path.resolve()
            if not str(file_path).startswith(str(self.static_dir.resolve())):
                return Response("Forbidden", status=403)
            
            if not file_path.exists() or not file_path.is_file():
                return Response("Not Found", status=404)
        except (OSError, ValueError):
            return Response("Bad Request", status=400)
        
        # Determine content type
        content_type, _ = mimetypes.guess_type(str(file_path))
        if not content_type:
            content_type = 'application/octet-stream'
        
        # Read and serve file
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
            
            headers = {
                'content-type': content_type,
                'content-length': str(len(content)),
                'cache-control': 'public, max-age=3600'  # Cache for 1 hour
            }
            
            return Response(content, headers=headers)
            
        except IOError:
            return Response("Internal Server Error", status=500)