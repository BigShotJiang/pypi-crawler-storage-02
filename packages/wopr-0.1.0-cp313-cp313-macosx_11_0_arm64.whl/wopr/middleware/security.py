"""
Security middleware for Tempest framework
"""

import hashlib
import hmac
import secrets
import time
from typing import Callable, Dict, Optional

from ..http.request import Request
from ..http.response import Response


class SecurityMiddleware:
    """Middleware for basic security features"""
    
    def __init__(self, 
                 secret_key: Optional[str] = None,
                 enable_csrf: bool = True,
                 enable_security_headers: bool = True):
        
        self.secret_key = secret_key or secrets.token_urlsafe(32)
        self.enable_csrf = enable_csrf
        self.enable_security_headers = enable_security_headers
        self.csrf_tokens: Dict[str, float] = {}  # token -> timestamp
        self.sessions: Dict[str, dict] = {}
    
    async def __call__(self, request: Request, call_next: Callable) -> Response:
        """Process request with security checks"""
        # CSRF protection for state-changing methods
        if self.enable_csrf and request.method in ['POST', 'PUT', 'DELETE', 'PATCH']:
            csrf_valid = await self._verify_csrf_token(request)
            if not csrf_valid:
                return Response("CSRF token missing or invalid", status=403)
        
        # Process request
        response = await call_next(request)
        
        # Add security headers
        if self.enable_security_headers:
            self._add_security_headers(response)
        
        return response
    
    def generate_csrf_token(self, session_id: Optional[str] = None) -> str:
        """Generate a CSRF token"""
        session_id = session_id or secrets.token_urlsafe(16)
        timestamp = str(int(time.time()))
        data = f"{session_id}:{timestamp}"
        
        signature = hmac.new(
            self.secret_key.encode(),
            data.encode(),
            hashlib.sha256
        ).hexdigest()
        
        token = f"{data}:{signature}"
        self.csrf_tokens[token] = time.time()
        
        # Clean up old tokens (older than 1 hour)
        cutoff = time.time() - 3600
        self.csrf_tokens = {
            t: ts for t, ts in self.csrf_tokens.items() 
            if ts > cutoff
        }
        
        return token
    
    async def _verify_csrf_token(self, request: Request) -> bool:
        """Verify CSRF token from request"""
        # Get token from header or form data
        token = request.headers.get('x-csrf-token')
        
        if not token:
            # Try to get from form data
            form_data = await request.get_form()
            token = form_data.get('csrf_token', [None])[0] if form_data else None
        
        if not token or token not in self.csrf_tokens:
            return False
        
        # Verify token signature
        try:
            data, signature = token.rsplit(':', 1)
            expected_signature = hmac.new(
                self.secret_key.encode(),
                data.encode(),
                hashlib.sha256
            ).hexdigest()
            
            return hmac.compare_digest(signature, expected_signature)
        except ValueError:
            return False
    
    def _add_security_headers(self, response: Response):
        """Add security headers to response"""
        headers = {
            'x-content-type-options': 'nosniff',
            'x-frame-options': 'DENY',
            'x-xss-protection': '1; mode=block',
            'strict-transport-security': 'max-age=31536000; includeSubDomains',
            'referrer-policy': 'strict-origin-when-cross-origin'
        }
        
        for key, value in headers.items():
            if key not in response.headers:
                response.headers[key] = value
    
    def create_session(self, data: dict) -> str:
        """Create a new session"""
        session_id = secrets.token_urlsafe(32)
        self.sessions[session_id] = {
            'data': data,
            'created_at': time.time(),
            'last_accessed': time.time()
        }
        return session_id
    
    def get_session(self, session_id: str) -> Optional[dict]:
        """Get session data"""
        if session_id in self.sessions:
            session = self.sessions[session_id]
            session['last_accessed'] = time.time()
            return session['data']
        return None
    
    def destroy_session(self, session_id: str) -> bool:
        """Destroy a session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False