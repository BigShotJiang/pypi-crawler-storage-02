"""
WebSocket connection handling for Tempest framework
"""

try:
    from granian.rsgi import Scope, WebsocketProtocol
except ImportError:
    # Fallback types for development without Granian
    class Scope:
        proto: str
        method: str
        path: str
        query_string: str
        headers: any
    
    class WebsocketProtocol:
        async def accept(self): pass


class WebSocket:
    """WebSocket connection wrapper"""
    
    def __init__(self, scope: Scope, protocol: WebsocketProtocol):
        self.scope = scope
        self.protocol = protocol
        self.transport = None
    
    async def accept(self):
        """Accept the WebSocket connection"""
        self.transport = await self.protocol.accept()
        return self.transport
    
    async def send_text(self, data: str):
        """Send text message"""
        if self.transport:
            await self.transport.send_str(data)
    
    async def send_bytes(self, data: bytes):
        """Send binary message"""
        if self.transport:
            await self.transport.send_bytes(data)
    
    async def receive(self):
        """Receive message from client"""
        if self.transport:
            return await self.transport.receive()
        return None