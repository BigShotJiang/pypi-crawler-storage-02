"""
Main CLI interface for Tempest framework
"""

import os
import shutil
from pathlib import Path

try:
    import click
    CLICK_AVAILABLE = True
except ImportError:
    CLICK_AVAILABLE = False
    click = None


if not CLICK_AVAILABLE:
    def cli():
        raise ImportError("Click is required for CLI tools. Install: uv add click")
else:
    @click.group()
    def cli():
        """Tempest CLI tools for project management"""
        pass
    
    @cli.command()
    @click.argument('project_name')
    @click.option('--template', default='basic', help='Project template to use')
    def init(project_name, template):
        """Initialize new Tempest project"""
        project_path = Path(project_name)
        
        if project_path.exists():
            click.echo(f"Error: Directory '{project_name}' already exists", err=True)
            return
        
        click.echo(f"Creating Tempest project: {project_name}")
        
        # Create project structure
        project_path.mkdir()
        (project_path / "app.py").write_text(_get_app_template())
        (project_path / "requirements.txt").write_text(_get_requirements_template())
        
        # Create directories
        (project_path / "templates").mkdir()
        (project_path / "static" / "css").mkdir(parents=True)
        (project_path / "static" / "js").mkdir(parents=True)
        (project_path / "static" / "images").mkdir(parents=True)
        (project_path / "tasks").mkdir()
        (project_path / "tests").mkdir()
        
        # Create template files
        (project_path / "templates" / "base.html").write_text(_get_base_template())
        (project_path / "templates" / "index.html").write_text(_get_index_template())
        
        # Create task module
        (project_path / "tasks" / "__init__.py").write_text("")
        (project_path / "tasks" / "example_tasks.py").write_text(_get_tasks_template())
        
        # Create basic CSS
        (project_path / "static" / "css" / "main.css").write_text(_get_css_template())
        
        click.echo(f"✅ Project '{project_name}' created successfully!")
        click.echo(f"📁 cd {project_name}")
        click.echo("🚀 granian --interface rsgi --reload app:app")
    
    @cli.command()
    @click.option('--categories', '-c', multiple=True, help='Task categories to run workers for')
    @click.option('--workers', '-w', default=1, help='Number of workers per category')
    def run_tasks(categories, workers):
        """Run background task workers"""
        click.echo("Starting task workers...")
        
        if not categories:
            categories = ['default']
        
        for category in categories:
            click.echo(f"Starting {workers} workers for category: {category}")
        
        click.echo("Task workers started. Press Ctrl+C to stop.")
        # Implementation would start actual workers here
    
    @cli.command()
    @click.option('--days', type=int, help='Clean tasks older than N days')
    @click.option('--months', type=int, help='Clean tasks older than N months')
    def cleanup_tasks(days, months):
        """Clean up old completed tasks"""
        if not days and not months:
            click.echo("Please specify --days or --months", err=True)
            return
        
        from ..tasks.storage import TaskStorage
        
        storage = TaskStorage()
        deleted = storage.cleanup_old_tasks(days=days, months=months)
        
        click.echo(f"✅ Cleaned up {deleted} old tasks")
    
    @cli.command()
    def version():
        """Show Tempest version"""
        from .. import __version__
        click.echo(f"Tempest v{__version__}")


def _get_app_template():
    return '''from tempest import Tempest, Request, jsonify, TaskPriority
import asyncio

app = Tempest(__name__)
app.init_templates()

# Template globals
@app.template_global('app_name')
def get_app_name():
    return "My Tempest App"

# Context processor
@app.context_processor
def inject_globals():
    return {'version': '1.0.0'}

# Background tasks
@app.task("send_email", "notifications")
async def send_email(to: str, subject: str, body: str):
    """Example background task"""
    print(f"Sending email to {to}: {subject}")
    await asyncio.sleep(2)  # Simulate work
    return {"status": "sent", "recipient": to}

# Routes
@app.get("/")
async def index(request: Request):
    return await app.render_template("index.html", 
                                    message="Welcome to Tempest!")

@app.get("/api/health")
async def health_check(request: Request):
    return jsonify({"status": "healthy", "framework": "Tempest"})

@app.post("/api/send-email")
async def queue_email(request: Request):
    data = await request.get_json()
    task_id = await app.add_background_task(
        "send_email", "notifications", TaskPriority.HIGH,
        to=data.get("to"), subject=data.get("subject"), body=data.get("body")
    )
    return jsonify({"task_id": task_id, "message": "Email queued"})

# Start task workers on app startup
async def startup():
    await app.start_task_workers("notifications", 2)

if __name__ == "__main__":
    print("Run with: granian --interface rsgi --reload app:app")
'''

def _get_requirements_template():
    return '''granian[rsgi]>=1.0.0
jinja2>=3.1.0
duckdb>=0.9.0
click>=8.0.0
'''

def _get_base_template():
    return '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}{{ app_name() }}{% endblock %}</title>
    <link href="/static/css/main.css" rel="stylesheet">
    {% block head %}{% endblock %}
</head>
<body>
    <nav class="navbar">
        <div class="nav-brand">{{ app_name() }}</div>
        <div class="nav-links">
            <a href="/">Home</a>
            <a href="/api/health">Health</a>
        </div>
    </nav>
    
    <main class="container">
        {% block content %}{% endblock %}
    </main>
    
    <footer>
        <p>&copy; 2024 {{ app_name() }} v{{ version }}</p>
    </footer>
    
    {% block scripts %}{% endblock %}
</body>
</html>
'''

def _get_index_template():
    return '''{% extends "base.html" %}

{% block title %}Home - {{ super() }}{% endblock %}

{% block content %}
<div class="hero">
    <h1>{{ message }}</h1>
    <p>Your high-performance async web application is ready!</p>
    
    <div class="features">
        <div class="feature">
            <h3>⚡ High Performance</h3>
            <p>Built on Granian's RSGI interface for maximum speed</p>
        </div>
        <div class="feature">
            <h3>🔄 Background Tasks</h3>
            <p>Intelligent task system with DuckDB storage</p>
        </div>
        <div class="feature">
            <h3>🌐 WebSocket Support</h3>
            <p>Real-time communication with room management</p>
        </div>
    </div>
    
    <div class="actions">
        <button onclick="testEmail()">Test Email Task</button>
        <button onclick="checkHealth()">Check Health</button>
    </div>
</div>

<div id="output"></div>
{% endblock %}

{% block scripts %}
<script>
async function testEmail() {
    try {
        const response = await fetch('/api/send-email', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                to: 'user@example.com',
                subject: 'Test Email',
                body: 'This is a test email from Tempest!'
            })
        });
        const data = await response.json();
        document.getElementById('output').innerHTML = 
            `<p>✅ Email queued with task ID: ${data.task_id}</p>`;
    } catch (error) {
        document.getElementById('output').innerHTML = 
            `<p>❌ Error: ${error.message}</p>`;
    }
}

async function checkHealth() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        document.getElementById('output').innerHTML = 
            `<p>✅ Health: ${data.status}</p>`;
    } catch (error) {
        document.getElementById('output').innerHTML = 
            `<p>❌ Error: ${error.message}</p>`;
    }
}
</script>
{% endblock %}
'''

def _get_css_template():
    return '''/* Tempest Default Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: #333;
    background: #f8f9fa;
}

.navbar {
    background: #2c3e50;
    color: white;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-brand {
    font-size: 1.5rem;
    font-weight: bold;
}

.nav-links a {
    color: white;
    text-decoration: none;
    margin-left: 1rem;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    transition: background 0.3s;
}

.nav-links a:hover {
    background: rgba(255, 255, 255, 0.1);
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

.hero {
    text-align: center;
    padding: 3rem 0;
}

.hero h1 {
    font-size: 3rem;
    margin-bottom: 1rem;
    color: #2c3e50;
}

.features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin: 3rem 0;
}

.feature {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.feature h3 {
    margin-bottom: 1rem;
    color: #2c3e50;
}

.actions {
    margin: 2rem 0;
}

button {
    background: #3498db;
    color: white;
    border: none;
    padding: 1rem 2rem;
    margin: 0.5rem;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1rem;
    transition: background 0.3s;
}

button:hover {
    background: #2980b9;
}

#output {
    margin-top: 2rem;
    padding: 1rem;
    background: white;
    border-radius: 4px;
    min-height: 60px;
}

footer {
    background: #2c3e50;
    color: white;
    text-align: center;
    padding: 1rem;
    margin-top: 3rem;
}
'''

def _get_tasks_template():
    return '''"""
Example background tasks for your Tempest application
"""

import asyncio
from datetime import datetime


async def process_data(data: list):
    """Process a list of data items"""
    print(f"Processing {len(data)} items at {datetime.now()}")
    
    # Simulate processing time
    await asyncio.sleep(2)
    
    return {
        "processed_count": len(data),
        "processed_at": datetime.now().isoformat()
    }


def sync_task_example(message: str):
    """Example of a synchronous task"""
    print(f"Sync task executed: {message}")
    return {"message": message, "executed_at": datetime.now().isoformat()}
'''