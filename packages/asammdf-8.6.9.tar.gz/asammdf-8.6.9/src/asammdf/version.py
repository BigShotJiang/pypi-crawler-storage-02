"""asammdf version module"""

__version__ = "8.6.9"
