# Authors

Contributors to pyannotators_spacyner include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
