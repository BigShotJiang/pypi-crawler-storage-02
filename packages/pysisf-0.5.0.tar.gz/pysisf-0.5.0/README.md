# pySISF

This repositories implements tools for running

## Installation

pySISF can be installed using `pip`:

```pip install pySISF```

## Module Documentation

Click [HERE](https://cai-lab-at-university-of-michigan.github.io/pySISF/index.html) for a link to the project documentation.

## Template Citation

This project's layout and CI are based on the great Python project template provided by [Microsoft](https://github.com/microsoft/python-package-template).