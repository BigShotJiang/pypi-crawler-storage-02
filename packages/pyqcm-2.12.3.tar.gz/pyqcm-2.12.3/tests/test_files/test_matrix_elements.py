from model_graphene_bath import model

# print(model.clus[0].cluster_model.matrix_elements('tb1'))
print('matrix elements of eb1:')
print(model.clus[0].cluster_model.matrix_elements('eb1'))
print('matrix elements of tb1:')
print(model.clus[0].cluster_model.matrix_elements('tb1'))

