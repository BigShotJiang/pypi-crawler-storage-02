PREFECT_API_URL="/api" PREFECT_SERVER_API_AUTH_STRING="admin:pwd" uv run prefect server start --background
