print('Imported sample 9')
a, b, c = range(10, 13)
