"""Error and exception definitions for fprime"""


class FprimeException(Exception):
    """Base F prime exception"""
