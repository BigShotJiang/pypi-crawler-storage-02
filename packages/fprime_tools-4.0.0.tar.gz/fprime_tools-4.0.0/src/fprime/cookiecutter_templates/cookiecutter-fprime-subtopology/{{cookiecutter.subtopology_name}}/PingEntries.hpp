#ifndef {{cookiecutter.__subtopology_name_upper}}_PINGENTRIES_HPP
#define {{cookiecutter.__subtopology_name_upper}}_PINGENTRIES_HPP

namespace PingEntries {
    // Add ping entries for your components here. For example:
    // namespace {{cookiecutter.subtopology_name}}_myComponent { enum { WARN = 3, FATAL = 5 }; }
}

#endif
