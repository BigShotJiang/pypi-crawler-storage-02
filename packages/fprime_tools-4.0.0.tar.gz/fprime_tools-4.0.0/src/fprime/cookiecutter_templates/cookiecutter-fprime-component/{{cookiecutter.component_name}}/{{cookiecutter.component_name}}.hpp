// ======================================================================
// \title  {{cookiecutter.component_name}}.hpp
// \brief  {{cookiecutter.component_short_description}} placeholder. Use fprime-util impl
// ======================================================================
