"""Claude API Proxy - A production-ready Claude API proxy server."""

__version__ = "0.2.0"
__author__ = "simpx"
__email__ = "simpxx@gmail.com"

from .main import main

__all__ = ["main"]