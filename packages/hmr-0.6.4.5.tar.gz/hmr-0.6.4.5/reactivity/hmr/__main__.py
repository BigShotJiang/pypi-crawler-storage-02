if __name__ == "__main__":
    from .core import cli

    cli()
