APIS = {
    "AGGREGATE": {
        "MODULE": "pymongo.collection",
        "METHOD": "Collection.aggregate",
        "OPERATION": "aggregate",
        "SPAN_NAME": "MongoDB Aggregate",
    },
}
