"""
Representations of search results returned from MarkLogic.
"""
