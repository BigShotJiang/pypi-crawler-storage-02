from aprsd_rich_cli_extension.cmds import (  # noqa: F401
    chat,
    listen,
)
