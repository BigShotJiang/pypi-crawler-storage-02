"""Unit test package for aprsd_rich_cli_extension."""
