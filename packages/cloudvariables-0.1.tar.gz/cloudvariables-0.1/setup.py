from setuptools import setup

setup(name='cloudvariables',
      version='0.1',
      description='Adds cloud variables that can be connected to using a token and password, requires a server',
      packages=['cloudvariables'],
      author_email='zvs.developer@gmail.com',
      zip_safe=False)
