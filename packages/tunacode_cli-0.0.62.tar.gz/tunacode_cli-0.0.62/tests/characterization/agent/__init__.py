"""Agent characterization tests package."""
