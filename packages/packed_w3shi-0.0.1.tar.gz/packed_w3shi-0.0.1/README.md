A test package that prints when installed.
