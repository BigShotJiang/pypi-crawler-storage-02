print("installed from package")
