"""
    Initializing Fyle SDK
"""

name = "fyle"
