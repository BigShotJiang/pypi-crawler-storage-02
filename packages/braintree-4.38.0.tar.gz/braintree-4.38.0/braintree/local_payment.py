import braintree
from braintree.resource import Resource

class LocalPayment(Resource):
    pass
