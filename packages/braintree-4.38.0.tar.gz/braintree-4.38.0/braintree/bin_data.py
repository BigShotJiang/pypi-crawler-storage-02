from braintree.attribute_getter import AttributeGetter

class BinData(AttributeGetter):
    pass
