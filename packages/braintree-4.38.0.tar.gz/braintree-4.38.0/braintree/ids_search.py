from braintree.search import Search

class IdsSearch:
    ids = Search.MultipleValueNodeBuilder("ids")
