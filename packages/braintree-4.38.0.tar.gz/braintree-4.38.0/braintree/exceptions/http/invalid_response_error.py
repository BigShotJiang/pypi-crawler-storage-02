from braintree.exceptions.unexpected_error import UnexpectedError

class InvalidResponseError(UnexpectedError):
    pass
