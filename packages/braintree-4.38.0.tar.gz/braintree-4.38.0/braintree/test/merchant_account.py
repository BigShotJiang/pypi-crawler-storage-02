Approve = "approve_me"

InsufficientFundsContactUs = "insufficient_funds__contact"
AccountNotAuthorizedContactUs = "account_not_authorized__contact"
BankRejectedUpdateFundingInformation = "bank_rejected__update"
BankRejectedNone = "bank_rejected__none"
