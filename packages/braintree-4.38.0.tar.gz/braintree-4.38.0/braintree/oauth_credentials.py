from braintree.resource import Resource

class OAuthCredentials(Resource):
    pass
