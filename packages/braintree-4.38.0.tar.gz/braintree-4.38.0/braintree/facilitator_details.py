from braintree.attribute_getter import AttributeGetter

class FacilitatorDetails(AttributeGetter):
    pass
