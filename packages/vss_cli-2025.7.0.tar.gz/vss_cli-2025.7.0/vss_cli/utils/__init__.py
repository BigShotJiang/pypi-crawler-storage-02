"""Utils module for the VSS-CLI."""
