"""MCP Stdio Toolbox - Universal MCP server for CLI tools."""

__version__ = "0.1.0"
