# Tests for mcp-stdio-toolbox
