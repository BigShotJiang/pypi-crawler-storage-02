class NsiBadResultError(Exception):
    pass


class NsiPkNotFoundError(Exception):
    pass


class NsiScriptTagNotFoundError(Exception):
    pass


class NsiFileNotFoundError(Exception):
    pass


class BadSubclassError(Exception):
    pass


class SkipWriteFileError(Exception):
    pass
