"""Admin configuration for the demo app."""
