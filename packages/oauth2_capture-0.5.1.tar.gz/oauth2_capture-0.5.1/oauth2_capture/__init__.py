"""OAuth2 capture package."""
