"""Migrations for the oauth2_capture app."""
