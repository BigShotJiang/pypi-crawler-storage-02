## 0.1.5 (2025-03-05)

### Fix

- **models**: changed default string for OAuthToken model

## 0.1.4 (2024-11-21)

## 0.1.3 (2024-11-21)

## 0.1.2 (2024-11-21)

## 0.1.1 (2024-11-21)

## 0.1.0 (2024-11-21)

### Feat

- **oath2_token**: added username property to help display see what username is attached

## 0.0.9 (2024-10-14)

### Fix

- **oauth2,logging**: safety checks on returned values in oauth2 flow

## 0.0.8 (2024-10-14)

### Fix

- **github,linkedin**: fix function signature for update_token
