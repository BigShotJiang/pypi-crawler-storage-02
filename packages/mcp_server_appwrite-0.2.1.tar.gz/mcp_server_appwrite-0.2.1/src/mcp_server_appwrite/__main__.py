from mcp_server_appwrite import main

if __name__ == "__main__":
    main()