1. rev(a, b)
Changing a and b between them.

2. shift_list(offset: int, list: str)
Shifting the given list to the specified offset.

3. create_number(lst: str)
Creating a single number from the given list, ignoring non-integer values.

4. sum_number(lst: str)
Calculating the sum of the numbers in the given list, ignoring non-integer values.

5. inputMas(n: int, sc='\n')
Returning an array from the given numbers. The default separator is "\n", but it can be changed using sc.

6. is_prime(n: int) -> bool
Checking if the given number n is a prime number.

7. factorial(n: int) -> int
Calculating the factorial of a non-negative integer n.

8. gcd(a: int, b: int) -> int
Finding the greatest common divisor between two numbers a and b.

9. lcm(a: int, b: int) -> int
Finding the least common multiple between two numbers a and b.

10. to_binary(n: int) -> int
Converting the given integer n to its binary representation .