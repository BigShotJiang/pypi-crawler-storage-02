from .main import *

try:
    if HIDEAD is not None:
        pass

except NameError:
    print("Hello from QuickRev community, join TG-channel t.me/fml23ix")
