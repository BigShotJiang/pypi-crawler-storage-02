add_entity_type("Training")
