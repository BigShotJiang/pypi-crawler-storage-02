drop_cube("rqlcontroller")
