# pedalboard_pluginary/scanners/__init__.py

# This file makes Python treat the `scanners` directory as a package.

# Optionally, you can import specific classes or functions here to make them
# available at the package level, e.g.:
# from .au_scanner import AUScanner
# from .vst3_scanner import VST3Scanner

# For now, it will be kept empty.
