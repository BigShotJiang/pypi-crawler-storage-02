__version__ = "1.5.0"
__author__ = "Rossen Georgiev, CFTools Software GmbH"

version_info = (1, 5, 0)
