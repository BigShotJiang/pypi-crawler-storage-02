
if __name__ == '__main__':
    from steam.versions_report import versions_report
    versions_report()
