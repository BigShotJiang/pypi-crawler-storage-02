"""Core metrics for evaluation."""
