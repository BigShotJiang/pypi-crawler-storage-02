from FinMind.schema.info import (
    FinalStats,
    TradeDetail,
    CompareMarketDetail,
    CompareMarketStats,
)
