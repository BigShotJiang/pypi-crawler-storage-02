from logging import getLogger

logger = getLogger("Learngual package")
