"""init.py."""
from .unsatfit import Fit  # noqa: F401
