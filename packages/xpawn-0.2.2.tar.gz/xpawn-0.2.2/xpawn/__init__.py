"""XPawn: A Python client for the XPawn API."""

__version__ = "0.2.2"

from .client import Client