//! Various utilities

pub mod math;
pub mod result;
pub mod error;
