This module is the base of the Field Service application in Odoo.
