import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import Errors
from files_sdk import errors

class ErrorsTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()