* Enric Tobella <etobella@creublanca.es>
* Jordi Ballester <jordi.ballester@eficent.com>
* Jaime Arroyo <jaime.arroyo@creublanca.es>
* Manuel Alejandro <buzondemam@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

    * Carlos Lopez