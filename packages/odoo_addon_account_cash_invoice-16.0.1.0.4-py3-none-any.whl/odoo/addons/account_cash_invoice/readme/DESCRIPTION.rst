This module allows to pay existing customer invoices/refunds or vendor bills/refunds
