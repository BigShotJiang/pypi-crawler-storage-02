#.  Go to *Settings* and activate the developer mode.
#.  Go to *Settings / Users & Companies / Users* and set the flag
    'Show Full Accounting Features'.
#.  Go to *Invoicing / Dashboard* from a Cash Journal.
#.  On the Additional options, Press the button **Pay Invoice** to pay a Supplier a Customer Invoice/Refund.
#.  Select the invoice type and select invoice to pay.
#.  Press **Pay invoice** on the statement. The payment will then be reconciled
    with the invoice.
