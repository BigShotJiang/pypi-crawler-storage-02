def surf():
    print("supersurf.ai")
