class DeliveryDeniedException(Exception):
    pass
