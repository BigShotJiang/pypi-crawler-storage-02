from .dlbuild_worker import DLBuildWorker

exit(DLBuildWorker().main())
