class BuildError(Exception):
    """ Represents error occured at one of build steps """
    pass
