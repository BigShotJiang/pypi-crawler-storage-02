def mayusculas(texto):
    return texto.upper()
