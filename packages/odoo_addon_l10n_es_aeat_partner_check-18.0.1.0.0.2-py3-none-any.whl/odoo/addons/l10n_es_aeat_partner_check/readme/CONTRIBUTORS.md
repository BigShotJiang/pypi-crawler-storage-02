- Ignacio Ibeas - Acysos S.L. \<<ignacio@acysos.com>\>
- Ethan Hildick - Studio73 \<<ethan@studio73.es>\>
- Aritz Olea - Landoo Sistemas de Información S.L. \<<ao@landoo.es>\>
- Miquel Alzanillas - Advanced Programming Solutions
  \<<malzanillas@apsl.net>\>
