Comprueba los datos de la empresa en el censo de la AEAT y en el recargo
de equivalencia
<https://sede.agenciatributaria.gob.es/static_files/Sede/Biblioteca/Manual/Tecnicos/WS/030_036_037/Manual_Tecnico_WS_Masivo_Calidad_Datos_Identificativos.pdf>
