# TinyTuya Module
# -*- coding: utf-8 -*-

class DecodeError(Exception):
    pass
