from galileo_core.schemas.shared.customized_scorer import CustomizedScorer


class CustomizedChainPollScorer(CustomizedScorer): ...
