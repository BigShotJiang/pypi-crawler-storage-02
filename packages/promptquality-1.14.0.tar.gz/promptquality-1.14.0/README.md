# promptquality

[![Test](https://github.com/rungalileo/promptquality/actions/workflows/ci.yaml/badge.svg)](https://github.com/rungalileo/promptquality/actions/workflows/ci.yaml) [![codecov](https://codecov.io/gh/rungalileo/promptquality/graph/badge.svg?token=PYQITJS1MV)](https://codecov.io/gh/rungalileo/promptquality) ![PyPI - Version](https://img.shields.io/pypi/v/promptquality) ![PyPI - Python Version](https://img.shields.io/pypi/pyversions/promptquality) ![PyPI - License](https://img.shields.io/pypi/l/promptquality) ![Code Style - Black](https://img.shields.io/badge/code%20style-black-000000.svg) [![Pydantic v2](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/pydantic/pydantic/main/docs/badge/v2.json)](https://pydantic.dev)

Accelerate AI System Evaluations with [Galileo Evaluate](https://www.galileo.ai/)!
