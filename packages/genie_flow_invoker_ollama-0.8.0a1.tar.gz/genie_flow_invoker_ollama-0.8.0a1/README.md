# Ollama Invokers
[![PyPI version](https://badge.fury.io/py/genie-flow-invoker-ollama.svg?icon=si%3Apython)](https://badge.fury.io/py/genie-flow-invoker-ollama)
![PyPI - Downloads](https://img.shields.io/pypi/dm/genie-flow-invoker-ollama)

This package contains Genie Flow invokers for different Ollama invocations.

## Install

`pip install genie-flow-invoker-ollama`
