# this_file: src/camtasio/cli/__init__.py
"""Camtasio command-line interface."""

from .app import CamtasioCLI, main

__all__ = ["CamtasioCLI", "main"]
