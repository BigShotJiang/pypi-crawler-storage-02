# dns-unbound-cache-reader

Read DNS cache from `unbound` DNS server.
