# baynext-cli
Baynext CLI tool to let users manage their Baynext projects and accounts from the terminal.
