#!/usr/bin/env python3

from TB2J.plot import command_line_plot_magnon_dos

command_line_plot_magnon_dos()
