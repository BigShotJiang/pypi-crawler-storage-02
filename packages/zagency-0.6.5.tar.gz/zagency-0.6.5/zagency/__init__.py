# """
# zagency - A framework for building and evaluating agents.
# """

# from zagency.core import *

# __version__ = "0.4.0"

# __all__ = [
#     # Core exports
#     "tool",
#     "Agent", 
#     "Environment",
#     "LM",
    
#     # Scorer exports
#     "Scorer",
#     "AgentScorer", 
#     "EnvironmentScorer",
#     "TraceScorer",
    
#     # Evaluation exports
#     "Evaluation",
#     "EvaluationSuite",
    
# ]