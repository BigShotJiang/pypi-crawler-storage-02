# ssp_transformation_handler
Package with utilities to handle the excel transformations matrix, transformations yaml and strategy template when running SSP model
