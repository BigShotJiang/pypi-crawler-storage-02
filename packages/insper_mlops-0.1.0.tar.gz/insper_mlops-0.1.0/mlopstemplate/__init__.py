"""MLOps Template - Ferramenta para padronizar projetos de MLOps no Insper CDIA."""

__version__ = "0.1.0"
__author__ = "Insper CDIA"
__email__ = "cdia@insper.edu.br"