"""Utilities for dascore."""
from __future__ import annotations
from .time import to_datetime64, to_timedelta64
