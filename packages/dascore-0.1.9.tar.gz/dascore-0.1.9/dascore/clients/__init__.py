"""
DAS Core module for accessing remote resources.
"""
from __future__ import annotations
