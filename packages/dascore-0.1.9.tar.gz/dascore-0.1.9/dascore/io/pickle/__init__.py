"""
A module for reading and writing pickle format.
"""
from __future__ import annotations
from .core import PickleIO
