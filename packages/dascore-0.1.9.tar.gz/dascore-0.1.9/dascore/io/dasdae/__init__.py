"""
Support for the DASDAE format.

Note
----
This is an experimental format and is subject to change.
"""
from __future__ import annotations
from .core import DASDAEV1
