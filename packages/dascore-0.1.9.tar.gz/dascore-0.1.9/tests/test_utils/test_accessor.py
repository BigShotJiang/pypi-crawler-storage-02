"""Tests for creating/registering accessors."""

from __future__ import annotations


# class TestDFSBasics:
#     """Test the basic dascore namespace functions."""
#
#     def test_namespace_exists(self, terra15_das_array):
