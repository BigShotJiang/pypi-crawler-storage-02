"""
Tests for compatibility module.
"""
