"""
Power BI module - Repository Pattern implementation
"""

from .powerbi import PowerBi

__all__ = [
    "PowerBi",
]
