# aiounifi
Asynchronous library to communicate with Unifi Controller

## Acknowledgements
* Paulus Schoutsen (balloob) creator of aiohue which most of this code repository is modeled after.