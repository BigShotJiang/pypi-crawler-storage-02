# ruff: noqa: N999
hiddenimports = ["fsspec.implementations.memory"]
