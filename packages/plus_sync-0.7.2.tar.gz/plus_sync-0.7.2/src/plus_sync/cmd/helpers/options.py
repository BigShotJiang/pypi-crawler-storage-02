global_options: dict[str, str | None] = {'config_file': None}
