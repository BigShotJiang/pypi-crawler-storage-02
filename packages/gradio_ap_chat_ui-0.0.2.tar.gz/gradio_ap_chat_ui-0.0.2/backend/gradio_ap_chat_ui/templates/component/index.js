import { I as f } from "./Index-BG2POTv1.js";
export {
  f as default
};
