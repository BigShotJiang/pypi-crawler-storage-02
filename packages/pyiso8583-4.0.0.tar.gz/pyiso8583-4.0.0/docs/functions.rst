=======================================================
Functions
=======================================================

Main Functions
--------------
.. currentmodule:: iso8583
.. autofunction:: decode
.. autofunction:: encode

Exceptions
----------
.. autoexception:: DecodeError
.. autoexception:: EncodeError

Helper Functions
----------------
.. autofunction:: pp
