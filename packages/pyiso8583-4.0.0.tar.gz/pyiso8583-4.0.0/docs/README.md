This folder contains [Sphinx][0] build script and doc sources.
While it's certainly possible to read these files as-is,
it's quite a bit nicer to look at the compiled version on readthedocs:

* [Index](https://pyiso8583.readthedocs.io)
* [Howto](https://pyiso8583.readthedocs.io/en/latest/howto.html)
* [Specifications](https://pyiso8583.readthedocs.io/en/latest/specifications.html)

[0]: https://www.sphinx-doc.org
