"""
Tests for bolt_agent_toolkit
"""
