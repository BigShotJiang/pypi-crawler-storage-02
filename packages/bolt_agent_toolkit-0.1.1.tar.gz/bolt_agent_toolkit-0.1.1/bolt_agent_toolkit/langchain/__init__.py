"""
Bolt Agent Toolkit LangChain Integration

LangChain integration for the Bolt agent toolkit.
"""

from .tool import BoltTool
from .toolkit import BoltAgentToolkit
