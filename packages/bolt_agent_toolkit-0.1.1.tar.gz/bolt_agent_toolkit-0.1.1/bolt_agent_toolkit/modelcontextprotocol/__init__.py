"""
Bolt Agent Toolkit MCP Implementation

Model Context Protocol (MCP) implementation for Bolt Agent Toolkit.
"""

from .toolkit import BoltAgentToolkit
