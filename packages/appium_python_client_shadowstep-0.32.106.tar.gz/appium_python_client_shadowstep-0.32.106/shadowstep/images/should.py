

class ImageShould:
    def __init__(
            self
    ):
        raise NotImplementedError

