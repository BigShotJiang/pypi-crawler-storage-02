from .kwargs_model import KwargsModel

__all__ = ("KwargsModel",)
