from . import (
    blueprints,
    blueprintsExtraData,
    buildings,
    gameCode,
    gameObjects,
    ingameData,
    islands,
    pygamePIL,
    research,
    shapeCodes,
    shapeOperations,
    shapeViewer,
    translations,
    utils,
    versions
)