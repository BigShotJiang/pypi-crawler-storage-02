"""
Core models for HeartMAP analysis

This module is currently empty as models are not yet implemented.
"""

from typing import List

# Models directory is empty - no model classes available
__all__: List[str] = []
