from enum import Enum


class PositionType(Enum):
    BUY = "BUY"
    SELL = "SELL"
