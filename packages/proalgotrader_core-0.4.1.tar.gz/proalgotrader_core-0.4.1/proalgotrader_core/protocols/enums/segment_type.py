from enum import Enum


class SegmentType(Enum):
    Equity = "Equity"
    Future = "Future"
    Option = "Option"
