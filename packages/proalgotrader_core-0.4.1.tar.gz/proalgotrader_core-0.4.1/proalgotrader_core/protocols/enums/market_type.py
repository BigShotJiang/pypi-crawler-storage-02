from enum import Enum


class MarketType(Enum):
    Cash = "Cash"
    Derivative = "Derivative"
