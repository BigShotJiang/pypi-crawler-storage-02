## v0.1.1rc28 (August 12, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc27...v0.1.1rc28

### Features

- add pyatlan Client to Application SDK (#642) (by @Ernest Hill in [c00d682](https://github.com/atlanhq/application-sdk/commit/c00d682))
