fn main() -> anyhow::Result<()> {
    python_proto_importer::run_cli()
}
