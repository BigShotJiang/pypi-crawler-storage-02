pathsim.utils.serialization module
====================================

.. automodule:: pathsim.utils.serialization
   :members:
   :show-inheritance:
   :undoc-members:
