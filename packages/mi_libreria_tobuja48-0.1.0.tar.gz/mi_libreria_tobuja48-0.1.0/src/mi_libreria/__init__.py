"""Mi Librería - Una librería de ejemplo para PyPI."""

__version__ = "0.1.0"
__author__ = "Tu Nombre"

from .core import saludar, calcular

__all__ = ["saludar", "calcular"]