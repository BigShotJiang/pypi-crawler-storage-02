from .codec import *
from .codec import _default_b32_alphabet, _default_b32_alphabet_alt
default_b32_alphabet = _default_b32_alphabet
default_b32_alphabet_alt = _default_b32_alphabet_alt

__version__ = "0.0.5a0"