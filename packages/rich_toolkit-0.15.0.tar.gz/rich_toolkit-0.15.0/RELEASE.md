---
release type: minor
---

This release increases the paste buffer from 32 to 4096 characters, enabling users to paste longer text into input fields.

It also adds full Windows compatibility with proper special key handling and fixes how password fields to always show asterisks.
