from aldepyde.rand.RandomProtein import *

__all__ = ['RandomProtein']

import sys
sys.stderr.write("Note that the `rand` submodule is not yet fully tested and may be unstable")