from aldepyde.biomolecule.Residue import Residue

__all__ = ['rna']

class rna(Residue):
    pass