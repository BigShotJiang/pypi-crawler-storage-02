from mcp_server_gaokao import main

main()
