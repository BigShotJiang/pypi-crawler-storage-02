"""
// Copyright (c) William Newport
// SPDX-License-Identifier: BUSL-1.1
"""

from datasurface.md import UserDSLObject


class SecurityModule(UserDSLObject):
    pass
