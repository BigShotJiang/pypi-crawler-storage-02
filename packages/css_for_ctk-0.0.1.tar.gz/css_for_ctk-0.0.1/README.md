# css_for_ctk
A library for effortless styling to CTk using the power of CSS 🌟

[![PyPI - Version](https://img.shields.io/pypi/v/css-for-ctk.svg)](https://pypi.org/project/css-for-ctk)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/css-for-ctk.svg)](https://pypi.org/project/css-for-ctk)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install css-for-ctk
```

## License

`css-for-ctk` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
