# Pigreads

```{include} ../README.md
:start-after: <!-- SPHINX-START -->
```

## Contents

```{toctree}
:maxdepth: 1

api
cli
models/index
schema
plot
internal
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
