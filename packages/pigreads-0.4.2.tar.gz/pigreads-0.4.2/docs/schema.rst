Schema
------

.. automodule:: pigreads.schema

.. automodule:: pigreads.schema.model

.. automodule:: pigreads.schema.setter

.. automodule:: pigreads.schema.basic
