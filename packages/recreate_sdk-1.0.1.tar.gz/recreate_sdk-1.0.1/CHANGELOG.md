# Changelog

## 1.0.1 (2025-08-04)

Full Changelog: [v1.0.0...v1.0.1](https://github.com/prosights/recreate-sdk-python/compare/v1.0.0...v1.0.1)

## 1.0.0 (2025-08-04)

Full Changelog: [v0.0.1-alpha.0...v1.0.0](https://github.com/prosights/recreate-sdk-python/compare/v0.0.1-alpha.0...v1.0.0)

### Chores

* update SDK settings ([f269ac2](https://github.com/prosights/recreate-sdk-python/commit/f269ac257cb9f7aa9a34781b81ba88086f5ff6df))
* update SDK settings ([6d0fbc5](https://github.com/prosights/recreate-sdk-python/commit/6d0fbc591c628d3384fb93089e1092002af86f1f))
