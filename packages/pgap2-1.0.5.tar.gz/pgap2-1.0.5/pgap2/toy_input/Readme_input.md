#input file format

PGAP2 supports input files in FASTA, GFF, and GBK formats, either flat or compressed (gzip or zip). Users can place all files in a single directory, and PGAP2 will automatically recognize them based on their prefixes.
