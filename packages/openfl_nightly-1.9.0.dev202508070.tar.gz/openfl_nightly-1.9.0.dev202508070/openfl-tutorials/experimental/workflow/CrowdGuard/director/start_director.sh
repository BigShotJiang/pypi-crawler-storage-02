#!/bin/bash
set -e

fx director start --disable-tls -c director_config.yaml