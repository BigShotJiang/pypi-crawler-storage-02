# Contributors


* Maik Budzinski <maikb@plan.aau.dk>
* Joao Filipe Dias Rodrigues <jfd@plan.aau.dk>
* Mathieu Delpierre <mathieu.delpierre@lca-net.com>
* Albert K. Osei-Owusu <AKO@plan.aau.dk>
* Philip Coenen (2.-0 LCA consultants)
* Maddalen Ayala (2.-0 LCA consultants)
