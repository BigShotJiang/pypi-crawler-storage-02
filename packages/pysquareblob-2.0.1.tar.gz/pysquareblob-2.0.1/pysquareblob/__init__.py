"""This package helps you interact with Square Cloud Blob API"""
from .client import Client
