A Python package that opens up SDSS data and enables a user to plot chosen properties of a dataset alongside each object's spectra.

Completed as a project in CodeAstro 2025 using DR17 of the MaNGA AGN Catalog (v1.0.1).
