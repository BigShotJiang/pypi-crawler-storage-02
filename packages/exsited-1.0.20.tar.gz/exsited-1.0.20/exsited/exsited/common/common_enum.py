from enum import Enum


class SortDirection(Enum):
    ASC = "asc"
    DESC = "desc"
