"""Settings and constants to be shared across pbipy."""


BASE_URL = "https://api.powerbi.com/v1.0/myorg"
