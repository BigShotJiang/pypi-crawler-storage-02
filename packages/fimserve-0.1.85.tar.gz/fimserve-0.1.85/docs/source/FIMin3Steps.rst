FIM in a 3 Steps
====================================
It takes only three steps to generate flood inundation maps using the NOAA OWP framework. First, get the HUC8 level data, get streamflow data and run the framework.
