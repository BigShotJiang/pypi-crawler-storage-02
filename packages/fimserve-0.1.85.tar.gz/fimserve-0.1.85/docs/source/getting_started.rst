Getting Started
====================================
Contains the basic information to get you started with fimserve.
