# validio-cli

This CLI is maintained by [Validio] to enable users to interact with the Validio platform.

## Installation

```sh
pip install validio-cli
```

## Usage

```sh
validio --help
```

  [Validio]: https://validio.io
