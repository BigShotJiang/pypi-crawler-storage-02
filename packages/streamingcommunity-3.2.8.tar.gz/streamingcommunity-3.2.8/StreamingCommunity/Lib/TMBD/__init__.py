# 17.09.24

from .tmdb import tmdb
from .obj_tmbd import Json_film