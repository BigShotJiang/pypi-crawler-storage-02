Basic JWST simulated data from https://www.stsci.edu/jwst/science-planning/proposal-planning-toolbox/simulated-data
