Image Pre-preparation
=====================

Astrometric Alignment
---------------------

Grism Background Subtraction
----------------------------

Reference/API
-------------

.. automodapi:: grizli.prep
    :no-inheritance-diagram:
    :skip: table_to_radec, table_to_regions, randomize_segmentation_labels, get_ukidss_catalog, get_sdss_catalog, get_twomass_catalog, get_irsa_catalog, get_gaia_radec_at_time, get_gaia_DR2_vizier_columns, get_gaia_DR2_vizier, gaia_dr2_conesearch_query, get_gaia_DR2_catalog, gen_tap_box_query, query_tap_catalog, get_hubble_source_catalog, get_nsc_catalog, get_desdr1_catalog, get_skymapper_catalog, get_panstarrs_catalog, get_radec_catalog