Basic Interaction With Spectra
==============================

Simulation
----------

