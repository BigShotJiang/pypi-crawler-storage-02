Installation instructions and basic module docstrings from Sphinx for now.

See http://grizli.readthedocs.io/.
