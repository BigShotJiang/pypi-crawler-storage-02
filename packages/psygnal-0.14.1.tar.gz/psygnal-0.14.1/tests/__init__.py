# don't love having this file here,
# but it's the only way I've found to target the tests directory
# in the mypy config in pyproject.toml
