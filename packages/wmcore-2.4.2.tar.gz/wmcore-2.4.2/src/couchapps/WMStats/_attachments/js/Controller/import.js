WMStats.Globals.importScripts([
    "js/Controller/WMStats.GenericController.js",
    "js/Controller/WMStats.ActiveRequestController.js",
    "js/Controller/WMStats.WorkloadSummaryController.js"
]);

