# Horse Race Predictor

A machine learning library to predict horse race outcomes using neural networks or regression models.

## Installation

```bash
pip install horseracepredictor
