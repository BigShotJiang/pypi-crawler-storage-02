from .configuration import configure_logger

__all__ = ("configure_logger",)
