"""Top-level package for {{ cookiecutter.project_name }}."""

__author__ = """{{ cookiecutter.username }}"""
__email__ = "{{ cookiecutter.email }}"
__version__ = "{{ cookiecutter.version }}"
__build_date__ = "2025-01-01"