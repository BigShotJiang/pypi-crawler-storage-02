{{cookiecutter.project_name}}
=================================

简介
------

{{cookiecutter.project_short_description}}

主要特性:

TODO:

-  xxx:
-  xxx:
-  xxx:

快速开始
----------

在项目中使用 ``{{ cookiecutter.project_name }}`` ::

    import {{ cookiecutter.project_slug }}

TODO:
