使用教程
=========

可以在项目代码中使用 ``{{ cookiecutter.project_name }}`` ::

    import {{ cookiecutter.project_slug }}
