"""Top-level package for cctp."""

__author__ = """gooker_young"""
__email__ = "gooker_young@qq.com"
__version__ = "1.2.4"
