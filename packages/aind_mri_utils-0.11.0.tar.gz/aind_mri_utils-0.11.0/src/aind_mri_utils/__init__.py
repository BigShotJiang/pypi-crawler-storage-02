"""Package for working with MRI experiments"""

__version__ = "0.11.0"
