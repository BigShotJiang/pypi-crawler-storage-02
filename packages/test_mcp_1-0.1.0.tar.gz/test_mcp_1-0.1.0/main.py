def main():
    print("Hello from test-mcp!")


if __name__ == "__main__":
    main()
