from pilottai.utils.logger import Logger

__all__ = [
    'Logger'
]
