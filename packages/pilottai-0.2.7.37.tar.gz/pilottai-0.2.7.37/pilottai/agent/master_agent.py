from pilottai.core.base_agent import BaseAgent

class MasterAgent(BaseAgent):
    pass
