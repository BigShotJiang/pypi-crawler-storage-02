from .pavdedutor import deduzivel, deduzivel_corrigido_total
