ipykernel.comm package
======================

Submodules
----------


.. automodule:: ipykernel.comm.comm
   :members:
   :show-inheritance:
   :undoc-members:


.. automodule:: ipykernel.comm.manager
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: ipykernel.comm
   :members:
   :show-inheritance:
   :undoc-members:
