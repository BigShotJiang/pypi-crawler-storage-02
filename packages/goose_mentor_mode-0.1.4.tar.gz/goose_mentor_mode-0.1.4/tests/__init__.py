# Tests for Mentor Mode MCP Extension
