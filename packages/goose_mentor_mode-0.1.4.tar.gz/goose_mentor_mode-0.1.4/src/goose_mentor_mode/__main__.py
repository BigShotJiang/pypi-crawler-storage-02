from goose_mentor_mode import main

main()
