// Do not remove this file even if the config is empty!
// VSCode's "Format Document" will respect this config and use the default
// settings, which is what we want. Without prettierrc, VSCode falls back to
// users settings, which could be different.

/**
 * @see https://prettier.io/docs/en/configuration.html
 * @type {import("prettier").Config}
 */
const config = {};

export default config;
