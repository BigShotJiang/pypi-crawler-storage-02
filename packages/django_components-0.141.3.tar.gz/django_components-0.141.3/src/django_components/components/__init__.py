# NOTE: Components exported here are documented in the API reference
from django_components.components.dynamic import DynamicComponent

__all__ = ["DynamicComponent"]
