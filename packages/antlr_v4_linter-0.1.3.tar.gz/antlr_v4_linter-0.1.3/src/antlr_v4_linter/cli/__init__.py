"""Command-line interface for ANTLR v4 linter."""

from .main import main

__all__ = ["main"]