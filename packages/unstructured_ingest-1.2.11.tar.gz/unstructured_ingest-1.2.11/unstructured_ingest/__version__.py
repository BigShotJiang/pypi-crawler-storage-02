__version__ = "1.2.11"  # pragma: no cover
