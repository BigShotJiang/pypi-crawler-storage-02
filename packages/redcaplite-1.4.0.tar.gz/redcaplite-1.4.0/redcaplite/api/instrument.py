def get_instruments(data):
    new_data = {
        'content': 'instrument',
        'format': 'json'
    }
    return (new_data)
