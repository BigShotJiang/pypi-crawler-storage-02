"""Backwards compatibility module."""
from splitio.client.factory import get_factory
