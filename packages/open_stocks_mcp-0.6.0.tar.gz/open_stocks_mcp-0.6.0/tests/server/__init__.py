"""Server and MCP protocol tests."""
