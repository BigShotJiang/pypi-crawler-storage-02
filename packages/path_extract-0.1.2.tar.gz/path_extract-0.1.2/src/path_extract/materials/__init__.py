import altair as alt

from path_extract.plots.helpers.theme import scape

alt.theme.enable("scape")
