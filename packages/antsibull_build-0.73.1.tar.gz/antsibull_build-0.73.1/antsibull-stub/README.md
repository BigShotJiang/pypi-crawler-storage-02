<!--
Copyright (c) Ansible Project
GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
SPDX-License-Identifier: GPL-3.0-or-later
-->

# antsibull PyPI stub package

The `antsibull` project has been renamed to `antsibull-build`.
This is an empty stub package for backwards compatibility.
The new PyPI project is located at <https://pypi.org/project/antsibull-build>.
