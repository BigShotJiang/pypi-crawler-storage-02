<!--
Copyright (c) Ansible Project
GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
SPDX-License-Identifier: GPL-3.0-or-later
-->

Changelog YAML Format
=====================

Please find the latest version of this document [in the antsibull-changelog repository](https://github.com/ansible-community/antsibull-changelog/blob/main/docs/changelog.yaml-format.md#changelog-yaml-format).
