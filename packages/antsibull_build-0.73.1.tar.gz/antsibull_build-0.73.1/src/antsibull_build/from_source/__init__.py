# Copyright (C) 2023 Maxwell G <maxwell@gtmx.me>
# SPDX-License-Identifier: GPL-3.0-or-later
# GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or
# https://www.gnu.org/licenses/gpl-3.0.txt)

"""
Clone and verify collections from source
"""

from __future__ import annotations

from .commands import verify_upstream_command

__all__ = ("verify_upstream_command",)
