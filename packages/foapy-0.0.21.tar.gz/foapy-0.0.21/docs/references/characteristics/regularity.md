# foapy.characteristics.regularity
::: foapy.characteristics.regularity
