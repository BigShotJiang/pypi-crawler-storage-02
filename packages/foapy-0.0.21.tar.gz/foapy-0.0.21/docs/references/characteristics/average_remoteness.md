# foapy.characteristics.average_remoteness
::: foapy.characteristics.average_remoteness
