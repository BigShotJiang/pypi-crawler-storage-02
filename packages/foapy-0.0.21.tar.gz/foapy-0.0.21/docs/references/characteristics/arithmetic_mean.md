# foapy.characteristics.arithmetic_mean
::: foapy.characteristics.arithmetic_mean
