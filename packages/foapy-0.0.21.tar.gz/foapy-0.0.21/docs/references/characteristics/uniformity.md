# foapy.characteristics.uniformity
::: foapy.characteristics.uniformity
