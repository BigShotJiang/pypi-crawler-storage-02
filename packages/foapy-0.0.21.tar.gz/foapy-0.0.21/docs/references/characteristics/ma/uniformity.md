# foapy.characteristics.ma.uniformity
::: foapy.characteristics.ma.uniformity
