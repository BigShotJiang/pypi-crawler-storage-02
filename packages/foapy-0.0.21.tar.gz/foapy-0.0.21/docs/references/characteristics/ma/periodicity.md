# foapy.characteristics.ma.periodicity
::: foapy.characteristics.ma.periodicity
