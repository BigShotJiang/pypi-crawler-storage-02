# foapy.characteristics.ma.identifying_information
::: foapy.characteristics.ma.identifying_information
