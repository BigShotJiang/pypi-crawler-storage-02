# foapy.characteristics.ma.arithmetic_mean
::: foapy.characteristics.ma.arithmetic_mean
