# foapy.characteristics.ma.geometric_mean
::: foapy.characteristics.ma.geometric_mean
