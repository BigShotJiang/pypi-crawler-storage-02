# foapy.characteristics.ma.average_remoteness
::: foapy.characteristics.ma.average_remoteness
