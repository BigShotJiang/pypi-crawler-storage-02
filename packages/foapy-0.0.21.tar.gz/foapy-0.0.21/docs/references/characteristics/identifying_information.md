# foapy.characteristics.identifying_information
::: foapy.characteristics.identifying_information
