# foapy.ma.intervals
::: foapy.ma.intervals
