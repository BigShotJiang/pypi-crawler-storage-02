---
hide:
  - toc
---
# foapy.exceptions.Not1DArrayException

::: foapy.exceptions.Not1DArrayException
    options:
        show_signature_annotations: false
        members_order: source
        show_docstring_examples: false
