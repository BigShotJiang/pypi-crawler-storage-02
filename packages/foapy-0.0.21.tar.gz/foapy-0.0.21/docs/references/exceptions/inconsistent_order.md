---
hide:
  - toc
---
# foapy.exceptions.InconsistentOrderException

::: foapy.exceptions.InconsistentOrderException
    options:
        show_signature_annotations: false
        members_order: source
        show_docstring_examples: false
