class Not1DArrayException(Exception):
    """
    Exception raised for errors in case the input array is not 1D.
    """

    pass
