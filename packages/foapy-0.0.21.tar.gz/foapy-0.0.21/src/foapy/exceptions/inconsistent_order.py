class InconsistentOrderException(Exception):
    """
    Exception raised for errors in case the input array is not valid order.
    """

    pass
