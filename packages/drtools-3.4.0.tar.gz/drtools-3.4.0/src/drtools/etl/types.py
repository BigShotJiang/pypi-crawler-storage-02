

from typing import Union, List, Dict


Date = str # Date in format "%Y-%m-%d"