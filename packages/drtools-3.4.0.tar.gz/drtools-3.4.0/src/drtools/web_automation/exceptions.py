

class BotDetectionError(Exception):
    pass


class BotDetectionMaxRetriesError(Exception):
    pass