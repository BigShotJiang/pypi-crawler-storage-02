"""AutoDocs MCP Server - Automatic Python package documentation context for AI assistants."""

__version__ = "0.1.0"
__author__ = "AutoDocs Team"
