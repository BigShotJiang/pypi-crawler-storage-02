"""Unit tests for AutoDocs MCP Server."""
