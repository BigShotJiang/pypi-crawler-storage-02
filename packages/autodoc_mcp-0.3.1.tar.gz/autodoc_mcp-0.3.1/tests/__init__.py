"""Tests for AutoDocs MCP Server."""
