from msca.optim.line_search.armijo import armijo_line_search

line_search_map = dict(armijo=armijo_line_search)
