from .capped_simplex import proj_capped_simplex

__all__ = ["proj_capped_simplex"]
