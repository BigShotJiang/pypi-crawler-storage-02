from msca.optim.precon.lbfgs import LBFGSPreconBuilder

precon_builder_map = dict(lbfgs=LBFGSPreconBuilder)
