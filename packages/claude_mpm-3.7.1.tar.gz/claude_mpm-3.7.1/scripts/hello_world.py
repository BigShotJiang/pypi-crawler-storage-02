#!/usr/bin/env python3
"""Simple hello world script."""

# Hello, World!

def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()