"""Cairn.info XML converter."""
__version__ = "0.5.61"
