=====
Usage
=====

To use json2xml in a project::

    import json2xml
