ResponseHeadersPagination = {
    "X-Next-Cursor": {"description": "Cursor for next page"},
    "X-Has-More": {"description": "Indicates if there are more items"},
}
