<!--- Top of README Badges (automated) --->
[![PyPI](https://img.shields.io/pypi/v/wipac-dev-actions-testbed)](https://pypi.org/project/wipac-dev-actions-testbed/) [![GitHub release (latest by date including pre-releases)](https://img.shields.io/github/v/release/WIPACrepo/wipac-dev-actions-testbed-python?include_prereleases)](https://github.com/WIPACrepo/wipac-dev-actions-testbed-python/) [![Versions](https://img.shields.io/pypi/pyversions/wipac-dev-actions-testbed.svg)](https://pypi.org/project/wipac-dev-actions-testbed) [![PyPI - License](https://img.shields.io/pypi/l/wipac-dev-actions-testbed)](https://github.com/WIPACrepo/wipac-dev-actions-testbed-python/blob/main/LICENSE) [![GitHub issues](https://img.shields.io/github/issues/WIPACrepo/wipac-dev-actions-testbed-python)](https://github.com/WIPACrepo/wipac-dev-actions-testbed-python/issues?q=is%3Aissue+sort%3Aupdated-desc+is%3Aopen) [![GitHub pull requests](https://img.shields.io/github/issues-pr/WIPACrepo/wipac-dev-actions-testbed-python)](https://github.com/WIPACrepo/wipac-dev-actions-testbed-python/pulls?q=is%3Apr+sort%3Aupdated-desc+is%3Aopen)
<!--- End of README Badges (automated) --->

# wipac-dev-actions-testbed-python

A guinea pig for testing `wipac-dev-*-action` packages and workflows -- using python
