"""Setup."""

from setuptools import setup  # type: ignore[import]  # mypy error in GH Action

setup()
