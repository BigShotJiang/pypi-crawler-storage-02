## Aliyun ROS CLOUDSSO Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as CLOUDSSO from '@alicloud/ros-cdk-cloudsso';
```
