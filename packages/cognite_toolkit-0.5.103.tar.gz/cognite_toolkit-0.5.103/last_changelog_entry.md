## cdf 

### Fixed

- [alpha] When deploying a GraphQL model, the Cognite Toolkit no longer
fails for `.graphql` schema that uses directives with multiple
components without line separation.

## templates

No changes.