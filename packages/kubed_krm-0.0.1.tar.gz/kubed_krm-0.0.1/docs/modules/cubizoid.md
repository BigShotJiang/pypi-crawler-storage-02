# Common KRM Features    

Detailed docs on the Kubed API. Read here on how to manually use the code to get the most custom of functionality. 

```{eval-rst}  
.. autofunction:: kubed.krm.common.execute
```

```{eval-rst}  
.. autofunction:: kubed.krm.common.krm_init
```

```{eval-rst}  
.. autofunction:: kubed.krm.common.load_function
```

```{eval-rst}  
.. autofunction:: kubed.krm.common.resolve
```

```{eval-rst}  
.. autofunction:: kubed.krm.common.dump
```
