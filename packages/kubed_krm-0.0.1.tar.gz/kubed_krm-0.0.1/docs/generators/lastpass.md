# LastPass Secret  

Generates a Secret kind based on a secret from extracted from LastPass cli. 