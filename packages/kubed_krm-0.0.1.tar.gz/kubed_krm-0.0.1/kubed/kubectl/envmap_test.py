import pytest

def test_envmap():
    assert 1 == 1