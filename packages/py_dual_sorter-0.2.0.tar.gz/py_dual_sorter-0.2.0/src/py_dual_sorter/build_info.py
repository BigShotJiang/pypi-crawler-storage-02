class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '0.2.0'
    git_sha = '51d58a934c0db9dad9c0cd6a854166a6c3d0e031'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
