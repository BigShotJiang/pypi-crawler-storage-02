LTS_VERSION = "1.0.0"

DEFAULT_ENDPOINT = "https://connect.getseam.com"
