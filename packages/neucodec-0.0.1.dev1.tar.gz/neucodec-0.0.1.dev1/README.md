# NeuCodec

NeuCodec is an FSQ-based audio codec for speech tokenization.