class UDPTypeException(Exception):
    pass


class UDPSendException(Exception):
    pass


class UDPReceiveException(Exception):
    pass
