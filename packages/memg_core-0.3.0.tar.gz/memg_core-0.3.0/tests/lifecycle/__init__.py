# Lifecycle tests for memg_core
