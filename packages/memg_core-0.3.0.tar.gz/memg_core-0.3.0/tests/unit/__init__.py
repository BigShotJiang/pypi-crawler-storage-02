# Unit tests for memg_core
