# API tests for memg_core
