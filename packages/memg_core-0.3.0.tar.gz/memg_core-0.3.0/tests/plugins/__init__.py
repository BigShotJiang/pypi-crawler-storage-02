# Plugin tests for memg_core
