class ScembedException(Exception):
    pass


class ModelNotTrainedError(ScembedException):
    pass
