"""Make the CLI runnable using python -m pyomie."""
from .cli import app

app(prog_name="pyomie")
