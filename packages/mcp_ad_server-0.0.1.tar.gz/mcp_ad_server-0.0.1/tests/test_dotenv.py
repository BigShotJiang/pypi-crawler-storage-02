#!/usr/bin/env python3
"""
测试.env文件加载功能
"""
import os
import sys
from pathlib import Path

# 确保可以导入项目模块
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def test_dotenv_loading():
    """测试.env文件加载功能"""
    print("开始测试.env文件加载功能")

    # 保存原始环境变量
    original_token = os.environ.get("BI_API_TOKEN")
    original_log_level = os.environ.get("LOG_LEVEL")

    # 清除环境变量
    if "BI_API_TOKEN" in os.environ:
        del os.environ["BI_API_TOKEN"]
    if "LOG_LEVEL" in os.environ:
        del os.environ["LOG_LEVEL"]

    try:
        # 创建测试.env文件
        test_env_content = """# 测试.env文件
BI_API_TOKEN=test_dotenv_token_12345
LOG_LEVEL=WARNING
"""

        project_root = Path(__file__).parent.parent
        test_env_file = project_root / ".env.test"

        with open(test_env_file, "w", encoding="utf-8") as f:
            f.write(test_env_content)

        # 创建一个修改过的config模块用于测试
        config_content = f'''"""
测试配置文件 - 加载.env文件
"""
import os
from pathlib import Path

# 加载.env文件
try:
    from dotenv import load_dotenv
    env_path = Path("{test_env_file}")
    load_dotenv(env_path)
except ImportError:
    pass

class Config:
    BI_API_TOKEN = os.getenv("BI_API_TOKEN", "")
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
'''

        # 写入临时测试配置
        test_config_file = project_root / "test_config_temp.py"
        with open(test_config_file, "w", encoding="utf-8") as f:
            f.write(config_content)

        # 导入测试配置
        import importlib.util

        spec = importlib.util.spec_from_file_location("test_config", test_config_file)
        test_config = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(test_config)

        # 验证配置加载
        assert test_config.Config.BI_API_TOKEN == "test_dotenv_token_12345"
        assert test_config.Config.LOG_LEVEL == "WARNING"

        print("✅ .env文件加载测试通过")
        print(f"   BI_API_TOKEN: {test_config.Config.BI_API_TOKEN}")
        print(f"   LOG_LEVEL: {test_config.Config.LOG_LEVEL}")

        # 测试环境变量覆盖
        os.environ["BI_API_TOKEN"] = "env_override_token"

        # 重新加载配置
        spec.loader.exec_module(test_config)

        assert test_config.Config.BI_API_TOKEN == "env_override_token"
        print("✅ 环境变量覆盖测试通过")
        print(f"   BI_API_TOKEN (覆盖): {test_config.Config.BI_API_TOKEN}")

    finally:
        # 清理测试文件
        if test_env_file.exists():
            test_env_file.unlink()
        if test_config_file.exists():
            test_config_file.unlink()

        # 恢复原始环境变量
        if original_token is not None:
            os.environ["BI_API_TOKEN"] = original_token
        elif "BI_API_TOKEN" in os.environ:
            del os.environ["BI_API_TOKEN"]

        if original_log_level is not None:
            os.environ["LOG_LEVEL"] = original_log_level
        elif "LOG_LEVEL" in os.environ:
            del os.environ["LOG_LEVEL"]


def test_current_config():
    """测试当前项目配置"""
    print("\n测试当前项目配置:")

    from mcp_ad_server import Config

    print(f"BI_API_TOKEN: {repr(Config.BI_API_TOKEN)}")
    print(f"LOG_LEVEL: {Config.LOG_LEVEL}")
    print(f"SERVER_NAME: {Config.SERVER_NAME}")
    print(f"DATA_DIR: {Config.DATA_DIR}")

    # 基本验证
    assert hasattr(Config, "BI_API_TOKEN")
    assert hasattr(Config, "LOG_LEVEL")
    assert hasattr(Config, "SERVER_NAME")
    assert Config.SERVER_NAME == "ad-analytics"

    print("✅ 当前配置测试通过")


if __name__ == "__main__":
    test_dotenv_loading()
    test_current_config()
    print("\n🎉 所有.env测试完成")
