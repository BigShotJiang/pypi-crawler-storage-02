#!/usr/bin/env python3
"""
打印目前的配置
"""
import sys

sys.path.insert(0, "src")

from mcp_ad_server import Config


def test_config():
    """打印配置"""
    print("=" * 50)
    print("打印目前的配置")
    print("=" * 50)

    # 测试基础配置
    print("\n基础配置:")
    print(f"  SERVER_NAME: {Config.SERVER_NAME}")
    print(f"  SERVER_VERSION: {Config.SERVER_VERSION}")

    # 测试API配置
    print("\nAPI配置:")
    print(f"  BI_API_BASE_URL: {Config.BI_API_BASE_URL}")
    print(f"  BI_API_VERSION: {Config.BI_API_VERSION}")
    print(f"  DEFAULT_APPID: {Config.DEFAULT_APPID}")
    print(f"  BI_API_TOKEN: {'已设置' if Config.BI_API_TOKEN else '未设置'}")

    # 测试路径配置
    print("\n路径配置:")
    print(f"  BASE_DIR: {Config.BASE_DIR}")
    print(f"  INDICATORS_DIR: {Config.INDICATORS_DIR}")
    print(f"  GROUPS_DIR: {Config.GROUPS_DIR}")
    print(f"  PROPMAP_DIR: {Config.PROPMAP_DIR}")

    # 测试限制配置
    print("\n限制配置:")
    print(f"  MAX_TIME_RANGE_DAYS: {Config.MAX_TIME_RANGE_DAYS}")
    print(f"  QUERY_TIMEOUT_SECONDS: {Config.QUERY_TIMEOUT_SECONDS}")

    # 测试支持的媒体
    print(f"\n支持的媒体渠道 (共{len(Config.SUPPORTED_MEDIA)}个):")
    for media in Config.SUPPORTED_MEDIA[:3]:
        print(f"  - {media}")
    print("  ...")

    # 测试分组维度
    print(f"\n支持的分组维度 (共{len(Config.SUPPORTED_GROUP_KEYS)}个):")
    for key, desc in list(Config.SUPPORTED_GROUP_KEYS.items())[:3]:
        print(f"  - {key}: {desc}")
    print("  ...")

    # 测试场景映射
    print(f"\n业务场景映射 (共{len(Config.SCENARIO_MAPPING)}个):")
    for scenario, group in list(Config.SCENARIO_MAPPING.items())[:3]:
        print(f"  - {scenario}: {group}")
    print("  ...")

    print("\n✅ 配置系统测试完成!")
    print("=" * 50)


if __name__ == "__main__":
    test_config()
