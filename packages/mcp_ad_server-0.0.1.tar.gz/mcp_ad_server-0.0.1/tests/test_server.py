#!/usr/bin/env python3
"""
MCP服务器测试脚本
"""
import asyncio
import json
import logging
import sys

sys.path.insert(0, "src")
from datetime import datetime, timedelta

from mcp_ad_server import AdMCPServer

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MCPServerTester:
    """MCP服务器测试类"""

    def __init__(self):
        self.server = None

    async def setup(self):
        """初始化测试环境"""
        logger.info("初始化测试环境...")
        self.server = AdMCPServer()
        await self.server.initialize()
        logger.info("测试环境初始化完成")

    async def test_indicator_manager(self):
        """测试指标管理器"""
        logger.info("=== 测试指标管理器 ===")

        # 测试获取指标统计
        stats = self.server.indicator_manager.get_indicator_stats()
        logger.info(f"指标统计: {json.dumps(stats, ensure_ascii=False, indent=2)}")

        # 测试获取单个指标
        indicator = self.server.indicator_manager.get_indicator("累计ROI")
        if indicator:
            logger.info(
                f"累计ROI指标: {json.dumps(indicator, ensure_ascii=False, indent=2)}"
            )
        else:
            logger.warning("未找到累计ROI指标")

        # 测试场景推荐
        recommended = self.server.indicator_manager.recommend_indicators_by_scenario(
            "投放启动"
        )
        logger.info(f"投放启动场景推荐指标: {recommended[:5]}...")  # 只显示前5个

        logger.info("指标管理器测试完成\n")

    async def test_propmap_manager(self):
        """测试字段映射管理器"""
        logger.info("=== 测试字段映射管理器 ===")

        # 测试映射统计
        stats = self.server.propmap_manager.get_mapping_stats()
        logger.info(f"映射统计: {json.dumps(stats, ensure_ascii=False, indent=2)}")

        # 测试字段映射
        display_name = "累计ROI"
        field_name = self.server.propmap_manager.get_field_name(
            display_name, "GetAdCountList"
        )
        logger.info(f"'{display_name}' → '{field_name}'")

        # 测试显示名称验证
        test_display_names = ["累计ROI", "消耗", "不存在的指标"]
        unsupported = self.server.propmap_manager.validate_names(
            test_display_names, "GetAdCountList"
        )
        logger.info(f"不支持的显示名称: {unsupported}")

        logger.info("字段映射管理器测试完成\n")

    async def test_api_client(self):
        """测试API客户端"""
        logger.info("=== 测试API客户端 ===")

        # 测试连接
        connection_ok = await self.server.api_client.test_connection()
        logger.info(f"API连接状态: {'正常' if connection_ok else '失败'}")

        if not connection_ok:
            logger.warning("跳过API数据查询测试（连接失败）")
            return

        # 测试查询广告数据（使用较小的时间范围和指标）
        try:
            yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            result = await self.server.api_client.get_ad_count_list(
                start_date=yesterday,
                end_date=yesterday,
                indicators=["日期", "消耗", "新增注册"][:2],  # 只用前2个指标
            )
            # Pydantic 模型访问
            data_count = (
                len(result.data.items) if result.data and result.data.items else 0
            )
            logger.info(
                f"广告数据查询成功，返回 {data_count} 条记录，code={result.code}, msg={result.msg}"
            )

        except Exception as e:
            logger.error(f"广告数据查询失败: {e}")

        logger.info("API客户端测试完成\n")

    async def test_tools(self):
        """测试MCP工具"""
        logger.info("=== 测试MCP工具 ===")

        # 测试指标推荐工具
        try:
            # 检查FastMCP对象的属性
            mcp_attrs = [
                attr for attr in dir(self.server.mcp) if not attr.startswith("__")
            ]
            logger.info(f"MCP属性: {mcp_attrs}")

            # 使用FastMCP的API
            tools = await self.server.mcp.list_tools()

            # 查找recommend_indicators工具
            recommend_tool = None
            for tool in tools:
                if tool.name == "recommend_indicators":
                    recommend_tool = tool
                    break

            if recommend_tool:
                result = await self.server.mcp.call_tool(
                    "recommend_indicators",
                    {
                        "business_scenario": "投放启动",
                        "current_indicators": ["消耗", "点击率"],
                    },
                )
                logger.info(f"指标推荐结果: {result}")
            else:
                logger.warning("未找到recommend_indicators工具")

        except Exception as e:
            logger.error(f"工具测试失败: {e}")

        logger.info("MCP工具测试完成\n")

    async def test_resources(self):
        """测试MCP资源"""
        logger.info("=== 测试MCP资源 ===")

        try:
            # 测试指标组资源
            group_resource_func = None
            # 使用FastMCP的API
            resources = await self.server.mcp.list_resources()

            # 查找groups资源
            groups_resource = None
            for resource in resources:
                if "groups" in str(resource.uri):
                    groups_resource = resource
                    break

            if groups_resource:
                result = await self.server.mcp.read_resource(groups_resource.uri)
                logger.info(f"指标组列表: {str(result)[:200]}...")  # 只显示前200字符
            else:
                logger.warning("未找到groups资源")

        except Exception as e:
            logger.error(f"资源测试失败: {e}")

        logger.info("MCP资源测试完成\n")

    async def test_prompts(self):
        """测试MCP提示（暂未实现）"""
        logger.info("=== 测试MCP提示 ===")

        try:
            # 提示功能暂未实现
            prompts = await self.server.mcp.list_prompts()
            logger.info(f"提示数量: {len(prompts)}（预期为0，因为暂未实现）")

            if len(prompts) == 0:
                logger.info("✅ 提示功能暂未实现，符合预期")
            else:
                logger.warning(f"发现 {len(prompts)} 个提示，但应该为0")

        except Exception as e:
            logger.error(f"提示测试失败: {e}")

        logger.info("MCP提示测试完成\n")

    async def run_all_tests(self):
        """运行所有测试"""
        logger.info("开始MCP服务器测试")

        try:
            await self.setup()

            await self.test_indicator_manager()
            await self.test_propmap_manager()
            await self.test_api_client()
            await self.test_tools()
            await self.test_resources()
            await self.test_prompts()

            logger.info("✅ 所有测试完成")

        except Exception as e:
            logger.error(f"❌ 测试过程中出现错误: {e}")
            raise


async def main():
    """主测试函数"""
    tester = MCPServerTester()
    await tester.run_all_tests()


if __name__ == "__main__":
    asyncio.run(main())
