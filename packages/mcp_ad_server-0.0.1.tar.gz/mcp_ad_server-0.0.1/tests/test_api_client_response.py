#!/usr/bin/env python3
"""
API客户端返回值格式测试

测试get_ad_count_list和get_material_count_list的返回值格式，
验证响应模型的结构和数据类型是否符合预期。
"""

import asyncio
import logging
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.mcp_ad_server.models.api_models import (
    GetAdCountListResponse,
    GetMaterialCountListResponse,
)
from src.mcp_ad_server.services.api_client import BiApiClient

# 设置日志
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class APIClientResponseTester:
    """API客户端响应测试器"""

    def __init__(self):
        self.client = BiApiClient()
        self.test_date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        self.basic_indicators = ["日期", "消耗", "新增注册"]

    async def test_ad_count_list_response(self):
        """测试广告数据查询响应格式"""
        logger.info("🧪 测试 get_ad_count_list 响应格式...")

        try:
            # 调用API
            response = await self.client.get_ad_count_list(
                start_date=self.test_date,
                end_date=self.test_date,
                indicators=self.basic_indicators,
                app_id="59",
            )

            # 验证响应类型
            assert isinstance(
                response, GetAdCountListResponse
            ), f"响应类型错误: {type(response)}"
            logger.info("✅ 响应类型验证通过: GetAdCountListResponse")

            # 验证基础属性
            assert hasattr(response, "code"), "缺少code属性"
            assert hasattr(response, "msg"), "缺少msg属性"
            assert hasattr(response, "data"), "缺少data属性"
            logger.info("✅ 基础属性验证通过: code, msg, data")

            # 验证响应码
            logger.info(f"📊 响应码: {response.code}")
            logger.info(f"📊 响应消息: {response.msg}")

            # 验证is_success属性
            assert hasattr(response, "is_success"), "缺少is_success属性"
            logger.info(f"📊 请求成功: {response.is_success}")

            # 验证data结构
            if response.data:
                assert hasattr(response.data, "items"), "data缺少items属性"
                assert hasattr(response.data, "total"), "data缺少total属性"
                logger.info(f"📊 数据条数: {response.data.total}")
                logger.info(f"📊 实际条数: {len(response.data.items)}")

                # 验证get_records方法
                assert hasattr(response, "get_records"), "缺少get_records方法"
                records = response.get_records()
                assert isinstance(records, list), "get_records应返回列表"
                logger.info(f"📊 记录对象数: {len(records)}")

                # 检查记录结构（如果有数据）
                if records:
                    first_record = records[0]
                    logger.info(f"📊 首条记录类型: {type(first_record)}")
                    logger.info(f"📊 首条记录属性: {dir(first_record)}")

                    # 验证基础字段
                    if hasattr(first_record, "日期"):
                        logger.info(f"📊 日期字段: {getattr(first_record, '日期', 'N/A')}")
                    if hasattr(first_record, "消耗"):
                        logger.info(f"📊 消耗字段: {getattr(first_record, '消耗', 'N/A')}")

            else:
                logger.warning("⚠️ 响应数据为空")

            return response

        except Exception as e:
            logger.error(f"❌ get_ad_count_list 测试失败: {e}")
            return None

    async def test_material_count_list_response(self):
        """测试素材数据查询响应格式"""
        logger.info("\n🧪 测试 get_material_count_list 响应格式...")

        try:
            # 调用API
            response = await self.client.get_material_count_list(
                start_date=self.test_date,
                end_date=self.test_date,
                indicators=["日期", "素材名称", "消耗"],
                app_id="59",
            )

            # 验证响应类型
            assert isinstance(
                response, GetMaterialCountListResponse
            ), f"响应类型错误: {type(response)}"
            logger.info("✅ 响应类型验证通过: GetMaterialCountListResponse")

            # 验证基础属性
            assert hasattr(response, "code"), "缺少code属性"
            assert hasattr(response, "msg"), "缺少msg属性"
            assert hasattr(response, "data"), "缺少data属性"
            logger.info("✅ 基础属性验证通过: code, msg, data")

            # 验证响应码
            logger.info(f"📊 响应码: {response.code}")
            logger.info(f"📊 响应消息: {response.msg}")

            # 验证is_success属性
            assert hasattr(response, "is_success"), "缺少is_success属性"
            logger.info(f"📊 请求成功: {response.is_success}")

            # 验证data结构
            if response.data:
                assert hasattr(response.data, "items"), "data缺少items属性"
                assert hasattr(response.data, "total"), "data缺少total属性"
                logger.info(f"📊 数据条数: {response.data.total}")
                logger.info(f"📊 实际条数: {len(response.data.items)}")

                # 验证get_records方法
                assert hasattr(response, "get_records"), "缺少get_records方法"
                records = response.get_records()
                assert isinstance(records, list), "get_records应返回列表"
                logger.info(f"📊 记录对象数: {len(records)}")

                # 检查记录结构（如果有数据）
                if records:
                    first_record = records[0]
                    logger.info(f"📊 首条记录类型: {type(first_record)}")
                    logger.info(f"📊 首条记录属性: {dir(first_record)}")

                    # 验证素材特有字段
                    if hasattr(first_record, "素材名称"):
                        logger.info(f"📊 素材名称: {getattr(first_record, '素材名称', 'N/A')}")
                    if hasattr(first_record, "日期"):
                        logger.info(f"📊 日期字段: {getattr(first_record, '日期', 'N/A')}")

            else:
                logger.warning("⚠️ 响应数据为空")

            return response

        except Exception as e:
            logger.error(f"❌ get_material_count_list 测试失败: {e}")
            return None

    async def test_client_version_info(self):
        """测试客户端版本信息"""
        logger.info("\n🧪 测试客户端版本信息...")

        try:
            # 测试类方法
            version_info = BiApiClient.get_version_info()
            logger.info(f"📊 版本信息: {version_info}")

            assert "client_version" in version_info, "缺少client_version"
            assert "api_version" in version_info, "缺少api_version"
            assert "client_name" in version_info, "缺少client_name"
            logger.info("✅ 版本信息格式验证通过")

            # 测试实例方法
            client_info = self.client.get_client_info()
            logger.info(f"📊 客户端信息: {client_info}")

            assert "base_url" in client_info, "缺少base_url"
            assert "timeout" in client_info, "缺少timeout"
            assert "has_token" in client_info, "缺少has_token"
            logger.info("✅ 客户端信息格式验证通过")

            return version_info, client_info

        except Exception as e:
            logger.error(f"❌ 版本信息测试失败: {e}")
            return None, None

    async def test_response_comparison(self):
        """对比两个API的响应结构差异"""
        logger.info("\n🧪 对比两个API响应结构...")

        try:
            # 获取两个响应
            ad_response = await self.client.get_ad_count_list(
                start_date=self.test_date,
                end_date=self.test_date,
                indicators=self.basic_indicators,
            )

            material_response = await self.client.get_material_count_list(
                start_date=self.test_date,
                end_date=self.test_date,
                indicators=["日期", "素材名称", "消耗"],
            )

            # 对比结构
            logger.info("📊 响应结构对比:")
            logger.info(f"  广告响应类型: {type(ad_response)}")
            logger.info(f"  素材响应类型: {type(material_response)}")

            # 对比数据结构
            if ad_response.data and material_response.data:
                logger.info(f"  广告数据条数: {ad_response.data.total}")
                logger.info(f"  素材数据条数: {material_response.data.total}")

                # 对比记录结构
                ad_records = ad_response.get_records()
                material_records = material_response.get_records()

                if ad_records and material_records:
                    logger.info("📊 记录字段对比:")
                    ad_fields = set(dir(ad_records[0])) if ad_records else set()
                    material_fields = (
                        set(dir(material_records[0])) if material_records else set()
                    )

                    common_fields = ad_fields & material_fields
                    ad_only = ad_fields - material_fields
                    material_only = material_fields - ad_fields

                    logger.info(f"  共同字段数: {len(common_fields)}")
                    logger.info(f"  广告独有字段数: {len(ad_only)}")
                    logger.info(f"  素材独有字段数: {len(material_only)}")

                    if material_only:
                        logger.info(f"  素材独有字段示例: {list(material_only)[:5]}")

        except Exception as e:
            logger.error(f"❌ 响应对比失败: {e}")

    async def run_all_tests(self):
        """运行所有测试"""
        logger.info("🚀 开始API客户端响应格式测试...\n")

        # 检查环境
        if not os.getenv("BI_API_TOKEN"):
            logger.error("❌ 未设置BI_API_TOKEN环境变量")
            return False

        try:
            # 1. 测试版本信息
            await self.test_client_version_info()

            # 2. 测试广告API响应
            ad_response = await self.test_ad_count_list_response()

            # 3. 测试素材API响应
            material_response = await self.test_material_count_list_response()

            # 4. 对比响应结构
            await self.test_response_comparison()

            logger.info("\n✅ 所有测试完成!")
            return True

        except Exception as e:
            logger.error(f"❌ 测试运行失败: {e}")
            return False


async def main():
    """主测试函数"""
    tester = APIClientResponseTester()
    success = await tester.run_all_tests()

    if success:
        logger.info("\n🎉 测试套件执行成功!")
        return 0
    else:
        logger.error("\n💥 测试套件执行失败!")
        return 1


if __name__ == "__main__":
    # 运行测试
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
