"""MCP广告服务器

提供广告投放数据的MCP服务接口。
"""

__version__ = "1.0.0"
__author__ = "AI Ad Team"

from .config import Config
from .main import AdMCPServer, main
from .managers import IndicatorManager, Manager, PropmapManager
from .resources import ConfigResources, IndicatorResources, MappingResources
from .services.api_client import BiApiClient
from .tools import AdQueryTool, IndicatorRecommendTool, MaterialQueryTool

__all__ = [
    "AdMCPServer",
    "main",
    "Config",
    "Manager",
    "IndicatorManager",
    "PropmapManager",
    "BiApiClient",
    "ConfigResources",
    "IndicatorResources",
    "MappingResources",
    "AdQueryTool",
    "MaterialQueryTool",
    "IndicatorRecommendTool",
]
