import pytest

from utstd.ipyrenders import print_tile
