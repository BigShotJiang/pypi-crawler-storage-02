__all__ = [
    'DOMAIN_CHANGE_HOOKS'
]

from .configuration import DOMAIN_CHANGE_HOOKS
