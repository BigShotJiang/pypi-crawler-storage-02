from uuid_utils import uuid7


def uuid() -> str:
    return str(uuid7())
