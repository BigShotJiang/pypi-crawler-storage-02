def _():
    nonlocal x
    nonlocal x, y, z
