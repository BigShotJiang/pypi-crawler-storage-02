if x:
    pass
elif y
    pass
else:
    pass
