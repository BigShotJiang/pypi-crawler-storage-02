def foo(
    first: int,
    second: int,
) -> int: ...
