import __debug__
import debug as __debug__
from x import __debug__
from x import debug as __debug__
