lambda x: *y
lambda x: *y,
lambda x: *y, z
lambda x: *y and z
