value.attr
value.attr()
value().attr
value().attr().foo
value.attr.foo
(value).attr().foo
