(expr)
(expr)()
(expr)()()()

(a and b or c)
(lambda x: x)
(x := 2)
(yield x)
(yield from x)