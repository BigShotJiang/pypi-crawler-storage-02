x: int
x: int = 1
(x): 1 + 2
x: tuple[int] | int = (1,)
x: int if True else str = 1
x: lambda x: y = 1
