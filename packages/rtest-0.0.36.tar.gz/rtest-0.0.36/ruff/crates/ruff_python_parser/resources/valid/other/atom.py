...
True
False
None

# Other atoms are tested in their respective files.
