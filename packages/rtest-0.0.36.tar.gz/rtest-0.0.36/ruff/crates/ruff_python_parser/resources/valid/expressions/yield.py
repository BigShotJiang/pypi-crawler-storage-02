yield
yield x
yield x + 1
yield x and y
yield call()
yield [1, 2]
yield {3, 4}
yield {x: 5}
yield x, y
yield (x, y)
yield x == y
yield (x := 1)
yield x, *y
yield *x,
