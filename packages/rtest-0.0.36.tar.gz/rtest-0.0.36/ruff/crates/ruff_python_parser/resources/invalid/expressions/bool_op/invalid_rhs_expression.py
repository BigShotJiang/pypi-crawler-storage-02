x and lambda y: y

x or yield y