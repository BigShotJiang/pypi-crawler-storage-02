# Missing closing parentheses 2: One element on the line, the other one on the next line
# will be considered to be part of the tuple.

(1,

x + y