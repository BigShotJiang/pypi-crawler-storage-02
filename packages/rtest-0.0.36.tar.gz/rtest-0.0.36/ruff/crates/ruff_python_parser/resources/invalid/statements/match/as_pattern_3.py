match subject:
    #     Not in the mapping start token set, so the list parsing bails
    #     v
    case {(x as y): 1}:
        pass
