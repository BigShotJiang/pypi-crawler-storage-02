# Starred expression isn't allowed in a parenthesized expression.
(*x)

# Unparenthesized named expression is allowed.
x := 1