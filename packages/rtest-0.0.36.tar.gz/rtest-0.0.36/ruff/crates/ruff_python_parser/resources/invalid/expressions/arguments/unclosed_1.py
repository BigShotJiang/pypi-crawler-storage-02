call(x

def foo():
    pass