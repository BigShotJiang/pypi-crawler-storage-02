# Missing expression, instead there's a function definition

(x :=

def foo():
    pass