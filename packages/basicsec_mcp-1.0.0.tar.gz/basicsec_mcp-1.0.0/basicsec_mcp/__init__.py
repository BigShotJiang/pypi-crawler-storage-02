"""
BasicSec MCP Server

A Model Context Protocol server that provides DNS and email security scanning capabilities
using the basicsec library.
"""

__version__ = "1.0.0"
__author__ = "Vlatko Kosturjak"
__email__ = "vlatko.kosturjak@marlink.com"