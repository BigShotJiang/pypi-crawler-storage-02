
class DropItem(Exception):
    pass
