"""Axolotl - Train and fine-tune large language models"""

import pkgutil

__path__ = pkgutil.extend_path(__path__, __name__)  # Make this a namespace package

__version__ = "0.12.1"
