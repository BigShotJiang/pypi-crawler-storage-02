"""Integration entry point for the DenseMixer plugin."""

from .plugin import DenseMixerPlugin

__all__ = ["DenseMixerPlugin"]
