"""
basic shared collator constants
"""

IGNORE_INDEX = -100
