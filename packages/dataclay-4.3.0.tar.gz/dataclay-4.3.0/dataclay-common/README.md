## Dataclay Common

Common protos for grpc
