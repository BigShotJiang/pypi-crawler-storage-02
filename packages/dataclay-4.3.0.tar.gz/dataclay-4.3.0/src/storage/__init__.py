"""High level Storage Interface for dataClay.

This package is used by PyCOMPSs, and uses dataclay.api module.
"""

__author__ = "Alex Barcelo <alex.barcelo@bsc.es>"
__copyright__ = "2015 Barcelona Supercomputing Center (BSC-CNS)"
__version__ = "0.2"
