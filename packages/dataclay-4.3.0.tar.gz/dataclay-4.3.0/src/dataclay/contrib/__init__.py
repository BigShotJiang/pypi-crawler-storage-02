MODULES_TO_REGISTER = ("collections", "splitting")
