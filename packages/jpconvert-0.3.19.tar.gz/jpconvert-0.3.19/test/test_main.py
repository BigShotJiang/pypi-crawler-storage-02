import os

import nbformat
import pytest

from jpconvert import build_pipeline, Pipeline, EmbedImages


def run(path: str, pipeline: Pipeline):
    if os.path.exists('test/'):
        os.chdir('test/')

    with open(path, 'r') as file:
        input_data = nbformat.read(file, nbformat.NO_CONVERT)

    output = pipeline.run(input_data)

    with open('output.ipynb', 'w') as file:
        nbformat.write(output, file)

    return output['cells']


def test_practice():
    cells = run('ExampleCode.ipynb',
                build_pipeline(True, False, False, False, False, False, False, False, True, True, True, False))

    # len
    assert len(cells) == 24

    # 0
    cell = cells[0]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == '# Überschrift'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 1
    cell = cells[1]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Unnötig langer Text...'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 2
    cell = cells[2]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "a = 'practice'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 3
    cell = cells[3]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'b = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 4
    cell = cells[4]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Eine leere Zelle zwischendurch:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 5
    cell = cells[5]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == ''
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 6
    cell = cells[6]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Zwischentext...'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 7
    cell = cells[7]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'd = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 8
    cell = cells[8]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'e = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 9
    cell = cells[9]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Und eine leere Zelle zum Schluss:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 10
    cell = cells[10]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == ''
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 11
    cell = cells[11]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "y = 'readonly'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 12
    cell = cells[12]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "z = 'readonly'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 13
    cell = cells[13]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Das ganze nochmal über Tags:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 14
    cell = cells[14]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "a = 'practice'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 15
    cell = cells[15]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'b = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 16
    cell = cells[16]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "y = 'readonly'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 17
    cell = cells[17]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "z = 'readonly'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 18
    cell = cells[18]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Markdown mit inline Markierung:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 19
    cell = cells[19]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text Practice'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 20
    cell = cells[20]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 21
    cell = cells[21]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Markdown mit Tags:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 22
    cell = cells[22]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text Practice'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 23
    cell = cells[23]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']


def test_solution():
    cells = run('ExampleCode.ipynb',
                build_pipeline(False, True, False, False, False, False, False, False, True, True, True, False))

    # len
    assert len(cells) == 19

    # 0
    cell = cells[0]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == '# Überschrift'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 1
    cell = cells[1]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Unnötig langer Text...'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 2
    cell = cells[2]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "a = 'solution'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 3
    cell = cells[3]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'b = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 4
    cell = cells[4]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Eine leere Zelle zwischendurch:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 5
    cell = cells[5]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == ''
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 6
    cell = cells[6]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Zwischentext...'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 7
    cell = cells[7]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'd = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 8
    cell = cells[8]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'e = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 9
    cell = cells[9]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Und eine leere Zelle zum Schluss:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 10
    cell = cells[10]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Das ganze nochmal über Tags:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 11
    cell = cells[11]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "a = 'solution'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 12
    cell = cells[12]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'b = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 13
    cell = cells[13]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Markdown mit inline Markierung:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 14
    cell = cells[14]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text Solution'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 15
    cell = cells[15]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 16
    cell = cells[16]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Markdown mit Tags:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 17
    cell = cells[17]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text Solution'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 18
    cell = cells[18]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']


def test_teaching():
    cells = run('ExampleCode.ipynb',
                build_pipeline(False, False, True, False, False, False, False, False, True, True, True, False))

    # len
    assert len(cells) == 15

    # 0
    cell = cells[0]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == '# Überschrift'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 1
    cell = cells[1]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Unnötig langer Text...'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 2
    cell = cells[2]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Eine leere Zelle zwischendurch:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 3
    cell = cells[3]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == ''
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 4
    cell = cells[4]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Zwischentext...'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 5
    cell = cells[5]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'c = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 6
    cell = cells[6]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'e = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 7
    cell = cells[7]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Und eine leere Zelle zum Schluss:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 8
    cell = cells[8]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Das ganze nochmal über Tags:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 9
    cell = cells[9]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == "a = 'teaching'"
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 10
    cell = cells[10]
    assert cell['cell_type'] == 'code'
    assert cell['source'] == 'b = a'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' not in cell['metadata'] or cell['metadata']['editable']

    # 11
    cell = cells[11]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Markdown mit inline Markierung:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 12
    cell = cells[12]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text Teaching'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 13
    cell = cells[13]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Markdown mit Tags:'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']

    # 14
    cell = cells[14]
    assert cell['cell_type'] == 'markdown'
    assert cell['source'] == 'Text Teaching'
    assert 'deletable' in cell['metadata'] and not cell['metadata']['deletable']
    assert 'editable' in cell['metadata'] and not cell['metadata']['editable']


def test_remove_without_macros():
    cells = run('ExampleCode.ipynb',
                build_pipeline(True, False, False, True, False, False, False, False, True, True, True, False))

    # len
    assert len(cells) == 14

    # 5
    cell = cells[5]
    assert cell['source'] != []

    # 8
    cell = cells[8]
    assert cell['source'] != ['e = a']


def test_remove_empty():
    cells = run('ExampleCode.ipynb',
                build_pipeline(True, False, False, False, True, False, False, False, True, True, True, False))

    # len
    assert len(cells) == 22

    # check for empty cells
    for cell in cells:
        assert len(cell['source']) > 0


def test_toc():
    cells = run('ExampleToc.ipynb',
                build_pipeline(True, False, False, False, True, False, False, False, True, True, True, False))

    # 1
    assert cells[1]['cell_type'] == 'markdown'
    assert cells[1]['source'] == ['# Inhaltsverzeichnis\n',
                                  '- [TOC Test](#TOC-Test)\n',
                                  '  - [Code](#Code)\n',
                                  '  - [Text](#Text)\n',
                                  '  - [Mix](#Mix)\n',
                                  '    - [another-heading](#another-heading)\n',
                                  '    - [heading with ÄÖÜäöüß umlauts](#heading-with-ÄÖÜäöüß-umlauts)\n',
                                  '      - [even smaller heading](#even-smaller-heading)\n',
                                  '- [Heading with `inline CODE`](#Heading-with-inline-CODE)']

    # 3
    assert cells[4]['cell_type'] == 'markdown'
    assert cells[4]['source'] == ['## Inhaltsverzeichnis\n',
                                  '- [Code](#Code)\n',
                                  '- [Text](#Text)\n',
                                  '- [Mix](#Mix)\n',
                                  '  - [another-heading](#another-heading)\n',
                                  '  - [heading with ÄÖÜäöüß umlauts](#heading-with-ÄÖÜäöüß-umlauts)\n',
                                  '    - [even smaller heading](#even-smaller-heading)']

    # 4
    assert cells[5]['cell_type'] == 'markdown'
    assert cells[5]['source'] == ['# Inhaltsverzeichnis\n',
                                  '- [TOC Test](#TOC-Test)\n',
                                  '  - [Code](#Code)\n',
                                  '  - [Text](#Text)\n',
                                  '  - [Mix](#Mix)\n',
                                  '- [Heading with `inline CODE`](#Heading-with-inline-CODE)']

    # 5
    assert cells[6]['cell_type'] == 'markdown'
    assert cells[6]['source'] == ['# Inhaltsverzeichnis\n',
                                  '- [TOC Test](#TOC-Test)\n',
                                  '  - [Code](#Code)\n',
                                  '  - [Text](#Text)\n',
                                  '  - [Mix](#Mix)\n',
                                  '- [Heading with `inline CODE`](#Heading-with-inline-CODE)']


def test_strip_lines():
    cells = run('ExampleLines.ipynb',
                build_pipeline(True, False, False, False, False, True, False, False, True, True, True, False))

    # len
    assert len(cells) == 12

    # 1
    assert cells[1]['source'] == 'this = 1\n' "my = 'code'"

    # 3
    assert cells[3]['source'] == 'this = 1\n'

    # 5
    assert cells[5]['source'] == '\n'

    # 7
    assert cells[7]['source'] == ''

    # 8
    assert cells[8]['source'] == ''

    # 10
    assert cells[10]['source'] == '\n'

    # 11
    assert cells[11]['source'] == '\n'


def test_trailing_lines():
    cells = run('ExampleLines.ipynb',
                build_pipeline(True, False, False, False, False, True, True, False, True, True, True, False))

    # len
    assert len(cells) == 12

    # 1
    assert cells[1]['source'] == 'this = 1\n' \
                                 "my = 'code'"

    # 3
    assert cells[3]['source'] == 'this = 1'

    # 5
    assert cells[5]['source'] == ''

    # 7
    assert cells[7]['source'] == ''

    # 8
    assert cells[8]['source'] == ''

    # 10
    assert cells[10]['source'] == ''

    # 11
    assert cells[11]['source'] == ''


def test_embed_image():
    cells = run('ExampleImages.ipynb',
                build_pipeline(True, False, False, False, False, False, False, True, True, True, True, False))

    # 0
    assert 'attachments' in cells[0]
    assert cells[0]['source'] == "# ExampleImages\n" \
                                 "![png description](attachment:1.png)"

    # 1
    assert 'attachments' in cells[1]
    assert cells[1]['source'] == "Test\n" \
                                 "![jpeg description](attachment:2.jpg)"

    # 2
    assert 'attachments' in cells[2]
    assert cells[2]['source'] == "![url description](attachment:3.jpg)"

    # 3
    assert 'attachments' in cells[3]
    assert cells[3]['source'] == "Inline test with ![image](attachment:4.png) from the first cell."

    # 4
    assert 'attachments' in cells[4]
    assert cells[4]['source'] == "Inline test with![image](attachment:5.png)missing spaces."

    # 5
    assert 'attachments' in cells[5]
    assert cells[5]['source'] == "Two images in the same cell\n" \
                                 "![jpeg description](attachment:6.jpg)\n" \
                                 "![jpeg description](attachment:7.png)"

    # 6
    assert 'attachments' in cells[6]
    assert cells[6]['source'] == "Same images in the same cell\n" \
                                 "![jpeg description](attachment:8.jpg)\n" \
                                 "![jpeg description](attachment:8.jpg)"

    # 7
    assert 'attachments' in cells[7]
    assert cells[7]['source'] == "Two images in one line\n" \
                                 "text ![jpeg description](attachment:10.jpg) text ![jpeg description](attachment:9.png) text"

    # 8
    png_b64, *_ = EmbedImages.base64encode('example.png')
    assert cells[8]['source'] == 'Sample image included via html tag\n' \
                                 f'<img src="data:image/png;base64,{png_b64}">'

    # 9
    jpg_b64, *_ = EmbedImages.base64encode('https://picsum.photos/id/1024/300/200')
    assert cells[9]['source'] == 'Remote image included via html tag with alt attribute\n' \
                                 f'<img alt="birb" src="data:image/jpeg;base64,{jpg_b64}">'

    # 10
    png_b64, *_ = EmbedImages.base64encode('example.png')
    assert cells[10]['source'] == 'Two img tags in one line\n' \
                                  f'<img src="data:image/png;base64,{png_b64}"><img src="data:image/png;base64,{png_b64}">'

    # 11
    assert cells[11]['source'] == 'An already attached image:\n' \
                                  '![example.png](attachment:example.png)'

    # 12
    assert 'attachments' in cells[12]
    assert cells[12]['source'] == 'svg:\n' \
                                  '![example.svg](attachment:11.svg)'

    # 13
    svg_b64, *_ = EmbedImages.base64encode('example.svg')
    assert cells[13]['source'] == 'svg via img tag:\n' \
                                  f'<img src="data:image/svg+xml;base64,{svg_b64}">'

    # 14
    assert cells[14]['source'] == 'An already attached svg:\n' \
                                  '![example.svg](attachment:example.svg)'

    # 15
    svg_b64, *_ = EmbedImages.base64encode('example_gray.png')
    assert cells[15]['source'] == 'images included as base64 string:\n' \
                                  f'![test](data:image/png;base64,{svg_b64})\n' \
                                  f'<img src="data:image/png;base64,{svg_b64}">'


def test_embedded_output():
    from jpconvert.implementations.FailIfOutputIsEmbedded import OutputEmbeddedError
    with pytest.raises(OutputEmbeddedError):
        run('ExampleWithOutput.ipynb',
            build_pipeline(False, False, False, False, False, False, False, False, False, False, True, False))


def test_remove_output():
    cells = run('ExampleWithOutput.ipynb',
                build_pipeline(False, False, False, False, False, False, False, False, False, False, False, True))

    for cell in cells:
        assert 'execution_count' not in cell or cell['execution_count'] is None
        assert 'outputs' not in cell or cell['outputs'] == []


def test_remove_raises_exception_tag():
    cells = run('ExampleRaisesException.ipynb',
                build_pipeline(True, False, False, False, False, False, False, False, False, False, False, False))

    assert cells[0]['metadata']['tags'] == []
    assert cells[0]['source'] == '# cell without tags\nvalid_code = 1'

    assert cells[1]['source'] == '# cell with tag raises-exception\ninvalid_code1'
    assert cells[1]['metadata']['tags'] == ['raises-exception']

    assert cells[2]['source'] == '# cell with tags raises-exception and jp-remove-raises-exception\ninvalid_code2'
    assert cells[2]['metadata']['tags'] == []

    assert cells[3]['source'] == '# cell with tag jp-remove-raises-exception\nvalid_code'
    assert cells[3]['metadata']['tags'] == []
