def main():
    print("Hello from ukcompanies!")


if __name__ == "__main__":
    main()
