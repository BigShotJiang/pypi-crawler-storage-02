"""Unit tests for ukcompanies SDK."""
