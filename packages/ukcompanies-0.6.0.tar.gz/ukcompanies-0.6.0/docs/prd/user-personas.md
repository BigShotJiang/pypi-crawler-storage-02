# User Personas

1. **Python Developers** – Internal tooling or API integration use.
2. **Data Engineers & Analysts** – Ingesting and analyzing Companies House data.
3. **LegalTech and RegTech Engineers** – KYB/compliance pipelines.
4. **Open Source Contributors** – SDK enhancement and usage documentation.