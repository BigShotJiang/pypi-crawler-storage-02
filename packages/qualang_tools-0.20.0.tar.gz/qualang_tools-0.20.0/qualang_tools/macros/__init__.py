from qualang_tools.macros.long_wait import long_wait

__all__ = ["long_wait"]
