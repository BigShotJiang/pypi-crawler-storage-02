from qualang_tools.analysis.discriminator import two_state_discriminator

__all__ = [
    "two_state_discriminator",
]
