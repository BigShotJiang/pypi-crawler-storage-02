from .wirer import allocate_wiring

__all__ = ["allocate_wiring"]
