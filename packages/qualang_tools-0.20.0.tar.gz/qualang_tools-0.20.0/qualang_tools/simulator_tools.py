from qualang_tools.simulator import create_simulator_controller_connections
import warnings

__all__ = [
    "create_simulator_controller_connections",
]

warnings.warn(
    "The 'create_simulator_controller_connections' function has been moved to 'qualang_tools.simulator'.", FutureWarning
)
warnings.warn(
    "The 'create_simulator_controller_connections' function has been moved to 'qualang_tools.simulator'.",
    DeprecationWarning,
)
