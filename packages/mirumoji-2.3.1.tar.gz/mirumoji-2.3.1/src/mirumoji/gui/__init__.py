"""
Contains the Mirumoji Launcher GUI implementation
"""
