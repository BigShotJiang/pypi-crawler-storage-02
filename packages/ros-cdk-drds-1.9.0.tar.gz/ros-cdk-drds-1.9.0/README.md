## Aliyun ROS DRDS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as DRDS from '@alicloud/ros-cdk-drds';
```
