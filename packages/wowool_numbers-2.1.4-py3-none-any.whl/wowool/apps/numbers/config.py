CONFIG = {
    "short_description": "The Numbers application money amount and units.",
    "long_description": "The Numbers application money amount and units. ex $10bn or twenty meters",
}
