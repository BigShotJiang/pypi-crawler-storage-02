::: seadex.SeaDexError
::: seadex.EntryNotFoundError
::: seadex.BadBackupFileError
