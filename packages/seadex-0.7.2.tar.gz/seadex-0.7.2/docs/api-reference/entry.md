::: seadex.entries
::: seadex.SeaDexEntry
