::: seadex._types.Base
::: seadex.BackupFile
::: seadex.EntryRecord
::: seadex.TorrentRecord
::: seadex.File
