"""
UI package for the Neutrophils Classifier Application

Contains PyQt5 window classes and UI-related components.
"""