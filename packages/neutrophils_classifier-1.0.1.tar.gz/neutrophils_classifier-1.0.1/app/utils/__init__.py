"""
Utilities package for the Neutrophils Classifier Application

Contains utility functions for benchmarking, imports, and other
cross-cutting concerns.
"""