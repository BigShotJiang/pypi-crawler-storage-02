"""GIS MCP Server - A Model Context Protocol server for GIS operations."""

__version__ = "0.3.0" 