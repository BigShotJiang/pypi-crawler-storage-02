from .server import run_mcp_server

def main():
    """Run the MCP server."""
    run_mcp_server()