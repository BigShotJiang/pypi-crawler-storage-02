# placeholder for arguments that are taken from defaults
USE_DEFAULT = object()
