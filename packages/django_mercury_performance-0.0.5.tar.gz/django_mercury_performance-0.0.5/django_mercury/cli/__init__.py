"""
Django Mercury CLI Module

Provides command-line interface for interactive educational testing,
following the 80-20 Human in the Loop philosophy.
"""

__all__ = ['educational', 'management']
