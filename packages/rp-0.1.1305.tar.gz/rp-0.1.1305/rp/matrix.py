#Display green rainfall of characters like outta da matrix!
#*Puts on hacker goggles*
from rp import *
pip_import('unimatrix','git+https://github.com/will8211/unimatrix.git')
import unimatrix
unimatrix.main()
