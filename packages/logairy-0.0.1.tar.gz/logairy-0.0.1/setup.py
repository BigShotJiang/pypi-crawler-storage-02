from setuptools import setup, find_packages

setup(
	name="logairy",
	version="0.0.1",
	author="Your Name",
	author_email="syntector@gmail.com",
	description="Reserved package name for future development.",
	packages=find_packages(),
	classifiers=[
		"Programming Language :: Python :: 3",
		"License :: OSI Approved :: MIT License",
		"Operating System :: OS Independent",
	],
	python_requires=">=3.6",
)
