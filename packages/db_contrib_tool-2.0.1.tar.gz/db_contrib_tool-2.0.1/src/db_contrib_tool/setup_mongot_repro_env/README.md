# `setup_mongot_repro_env`

Set up Mongot repro environment.

Downloads and installs particular Mongot versions into install directory.

Accepts `latest` and `release` versions.

If no version and no architecture are specified the latest linux_x86_64 binary will be installed.
