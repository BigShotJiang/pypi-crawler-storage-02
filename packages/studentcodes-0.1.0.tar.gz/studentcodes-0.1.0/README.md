# studentcodes

A collection of ready-to-use Python WAPs (Write-A-Programs) for students.
