
# WAP to append and find length in a list
fruits = ["Apple", "Banana", "Cherry"]
print(f"Original list: {fruits}")
print(f"Original length: {len(fruits)}")
fruits.append("Mango")
print(f"\nList after appending: {fruits}")
print(f"New length: {len(fruits)}")

# WAP to check specific character in a string using find function
my_string = "Welcome to Python programming!"
char_to_find = 'P'
position = my_string.find(char_to_find)
print(f"The character '{char_to_find}' is found at index: {position}")

# WAP to count the no. of characters in a string
my_string = "abracadabra"
char_to_count = 'a'
count = my_string.count(char_to_count)
print(f"The character '{char_to_count}' appears {count} times.")

# WAP to replace a specific character in a string
original_string = "Hello World"
new_string = original_string.replace('o', 'a')
print(f"Original String: {original_string}")
print(f"New String: {new_string}")

# WAP to access values using keys
student_info = {"name": "John Doe", "student_id": 12345}
student_name = student_info["name"]
print(f"The value for the key 'name' is: {student_name}")

# WAP to define a function
def say_hello():
    """This function prints a greeting."""
    print("Hello from a function!")
say_hello()

# WAP to define a function to add numbers with parameters
def add_numbers(num1, num2):
    """This function returns the sum of two numbers."""
    return num1 + num2
sum_result = add_numbers(15, 7)
print(f"The sum is: {sum_result}")

# WAP to define a function with default parameters
def greet(name="User"):
    print(f"Hello, {name}!")
greet()  # Uses the default value
greet("Bob")  # Uses the provided value

# WAP for anonymous function (LAMBDA)
square = lambda x: x * x
result = square(7)
print(f"The square of 7 is: {result}")

# WAP to calculate factorial of the no. given by user
def calculate_factorial(n):
    if n < 0:
        return "Not defined for negative numbers"
    elif n == 0:
        return 1
    else:
        factorial = 1
        for i in range(1, n + 1):
            factorial = factorial * i
        return factorial
num = int(input("Enter a number to find its factorial: "))
print(f"The factorial of {num} is {calculate_factorial(num)}")

# WAP to find out weather the given no is palindrome no. or not
num_str = input("Enter a number to check for palindrome: ")
if num_str == num_str[::-1]:
    print(f"The number {num_str} is a palindrome.")
else:
    print(f"The number {num_str} is not a palindrome.")

# WAP to check if the number entered by the user is odd or even
number = int(input("Enter an integer: "))
if number % 2 == 0:
    print(f"The number {number} is Even.")
else:
    print(f"The number {number} is Odd.")

# WAP to get the table of a particular variable
number = int(input("Enter a number for its multiplication table: "))
print(f"\n--- Multiplication Table for {number} ---")
for i in range(1, 11):
    print(f"{number} x {i} = {number * i}")

# WAP to check if the no.s are divisible by 10
number = int(input("Enter a number to check divisibility by 10: "))
if number % 10 == 0:
    print(f"Yes, {number} is divisible by 10.")
else:
    print(f"No, {number} is not divisible by 10.")

# WAP to try to check if the block can be excecuted
try:
    result = 10 / 0
    print(result)
except ZeroDivisionError:
    print("Error: You cannot divide by zero!")

# WAP to define a function that accepts the user's name and age and prints a welcome message.
def welcome_user(name, age):
    print(f"\nHello {name}! Being {age} years old is a great age.")
user_name = input("Please enter your name: ")
user_age = input("Please enter your age: ")
welcome_user(user_name, user_age)

# WAP to find and display the common and distinctive elements of two given sets.
set1 = {10, 20, 30, 40, 50}
set2 = {40, 50, 60, 70, 80}
common = set1.intersection(set2)
print(f"Common elements: {common}")
distinctive = set1.symmetric_difference(set2)
print(f"Distinctive elements: {distinctive}")

# WAP to read sales data from a csv file and calculate 10% commision for each row
import csv
sales_data = [
    ['TransactionID', 'Product', 'SaleAmount'],
    ['101', 'Laptop', '75000'],
    ['102', 'Mouse', '1200'],
    ['103', 'Keyboard', '2500'],
    ['104', 'Monitor', '15000']
]
with open('sales.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(sales_data)
print("Created sales.csv file.\n")
print("Sales Commissions (10%)")
try:
    with open('sales.csv', 'r') as file:
        reader = csv.reader(file)
        header = next(reader)
        for row in reader:
            transaction_id = row[0]
            sale_amount = float(row[2])
            commission = sale_amount * 0.10
            print(f"Transaction {transaction_id}: Sale = ₹{sale_amount:.2f}, Commission = ₹{commission:.2f}")
except FileNotFoundError:
    print("sales.csv not found.")
except (ValueError, IndexError):
    print("Error processing the CSV file. Check data format.")

# WAP to read employee salary data from a csv file, calculate total salary as BASIC+DA, and write the result to a new csv file
salary_data = [
    ['EmployeeID', 'Name', 'BASIC', 'DA'],
    ['E01', 'Arun', '40000', '8000'],
    ['E02', 'Bhavna', '45000', '9000'],
    ['E03', 'Chetan', '38000', '7600']
]
with open('employee_salary.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(salary_data)

input_filename = 'employee_salary.csv'
output_filename = 'total_salary.csv'

with open(input_filename, 'r') as infile, open(output_filename, 'w', newline='') as outfile:
    reader = csv.reader(infile)
    writer = csv.writer(outfile)

    header = next(reader)
    writer.writerow(header + ['TotalSalary'])

    for row in reader:
        basic = float(row[2])
        da = float(row[3])
        total_salary = basic + da
        writer.writerow(row + [total_salary])
print(f"Processed salary data and saved results to {output_filename}")

# WAP to read student marks from a CSV file - calculate total and average for each student and write the result in a new CSV file.
marks_data = [
    ['StudentID', 'Name', 'Maths', 'Science', 'English'],
    ['S001', 'Riya', '85', '92', '88'],
    ['S002', 'Sam', '78', '81', '90'],
    ['S003', 'Priya', '95', '98', '92']
]
with open('student_marks.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(marks_data)

with open('student_marks.csv', 'r') as infile, open('student_results.csv', 'w', newline='') as outfile:
    reader = csv.reader(infile)
    writer = csv.writer(outfile)

    header = next(reader)
    writer.writerow(header + ['Total', 'Average'])

    for row in reader:
        maths = int(row[2])
        science = int(row[3])
        english = int(row[4])
        total = maths + science + english
        average = total / 3
        writer.writerow(row + [total, f"{average:.2f}"])
print("Created student_results.csv with total and average marks.")

# WAP to accept key-value pairs from the user and convert them into a dictionary
my_dictionary = {}
print("Enter key-value pairs. Type 'done' as the key to finish.")
while True:
    key = input("Enter key: ")
    if key.lower() == 'done': break
    value = input(f"Enter value for '{key}': ")
    my_dictionary[key] = value
print("\n--- Final Dictionary ---")
print(my_dictionary)

# WAP to accept a word and print each vowel found in it using a for loop.
word = input("Enter a word: ")
vowels = "aeiouAEIOU"
print("Vowels found:")
for letter in word:
    if letter in vowels:
        print(letter, end=' ')
