# About PyFunceble

PyFunceble is the tool that our infrastructure use to get the status (ACTIVE, INVALID, INACTIVE) of a given domain or IPv4.

Please find more information about it there:

* http://pyfunceble.github.io
* http://pyfunceble.readthedocs.io
* https://github.com/funilrys/PyFunceble
