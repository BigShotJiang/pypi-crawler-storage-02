
R_gas_constant_si = 8.31446261815324  # J/(mol*K)
