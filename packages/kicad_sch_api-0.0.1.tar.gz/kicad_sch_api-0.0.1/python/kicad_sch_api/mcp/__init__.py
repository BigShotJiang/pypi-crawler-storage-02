"""MCP (Model Context Protocol) integration for kicad-sch-api."""

from .server import MCPInterface

__all__ = ["MCPInterface"]
