# Third Party
import pytest


def test_fake():
    assert True
