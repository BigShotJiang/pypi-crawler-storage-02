from __future__ import annotations

import hist


def test_version():
    assert hist.__version__ is not None
