from __future__ import annotations

import boost_histogram as bh

import hist


def test_bh_conversion():
    h = bh.Histogram(bh.axis.Regular(3, 2, 1, metadata={"name": "x"}))
    h.axes[0].name = "y"

    h2 = hist.Hist(h)

    assert isinstance(h2.axes[0], hist.axis.Regular)
    assert h2.axes[0].name == "y"
    assert h2.axes[0].metadata == {"name": "x"}

    h3 = bh.Histogram(h2)

    assert not isinstance(h3.axes[0], hist.axis.Regular)
    assert h2.axes[0].name == "y"
    assert h3.axes[0].metadata == {"name": "x"}


def test_bh_conversion_add_metadata():
    h = bh.Histogram(bh.axis.Regular(3, 2, 1))

    h2 = hist.Hist(h, label="abc", name="def")

    assert h2.label == "abc"
    assert h2.name == "def"
