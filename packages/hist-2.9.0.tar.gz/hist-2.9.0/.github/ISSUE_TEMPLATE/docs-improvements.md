---
name: Docs improvements
about: Describe the defects and expectations in docs
title: "[DOCS] "
labels: documentation
---

<!-- Consider opening an Discussion instead! -->

## How do you want to improve the docs

Report the typos and defects / Expect to new contents.

## Where is the typos and defects

EX. There is a typo ... in ...

## What contents do you expect

I look forward to ... in ...
