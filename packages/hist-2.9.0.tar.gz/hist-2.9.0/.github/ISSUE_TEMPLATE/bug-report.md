---
name: Bug report
about: Create a report
title: "[BUG] "
labels: unverified-bug
---

**Describe the bug**

A clear and concise description of the bug.

**Steps to reproduce**

An example that highlights the broken behaviour. Include OS and system info if relevant.
