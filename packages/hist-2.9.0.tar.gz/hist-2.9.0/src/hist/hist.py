from __future__ import annotations

import hist

from .basehist import BaseHist


class Hist(BaseHist, family=hist):
    pass
