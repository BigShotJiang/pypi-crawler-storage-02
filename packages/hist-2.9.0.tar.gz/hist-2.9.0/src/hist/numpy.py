from __future__ import annotations

from boost_histogram.numpy import histogram, histogram2d, histogramdd

__all__ = ("histogram", "histogram2d", "histogramdd")
