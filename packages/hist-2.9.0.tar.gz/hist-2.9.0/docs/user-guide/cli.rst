.. _usage-cli:

CLI
===

For compatibility with the original Hist library, we provide a CLI as well.

.. program-output:: hist --help
