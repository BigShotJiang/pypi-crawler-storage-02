```{include} ../.github/CONTRIBUTING.md
```
