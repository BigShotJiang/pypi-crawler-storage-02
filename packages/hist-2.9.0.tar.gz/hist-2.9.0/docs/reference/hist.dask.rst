hist.dask package
=================

.. automodule:: hist.dask
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 4

   hist.dask.hist
   hist.dask.namedhist
