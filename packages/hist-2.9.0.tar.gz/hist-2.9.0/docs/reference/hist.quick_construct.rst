hist.quick\_construct module
============================

.. automodule:: hist.quick_construct
   :members:
   :show-inheritance:
   :undoc-members:
