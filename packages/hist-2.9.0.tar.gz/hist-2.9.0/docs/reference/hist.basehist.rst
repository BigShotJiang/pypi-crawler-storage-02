hist.basehist module
====================

.. automodule:: hist.basehist
   :members:
   :show-inheritance:
   :undoc-members:
