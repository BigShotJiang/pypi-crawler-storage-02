hist.stack module
=================

.. automodule:: hist.stack
   :members:
   :show-inheritance:
   :undoc-members:
