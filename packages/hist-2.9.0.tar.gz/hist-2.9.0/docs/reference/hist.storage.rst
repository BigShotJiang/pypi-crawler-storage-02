hist.storage module
===================

.. automodule:: hist.storage
   :members:
   :show-inheritance:
   :undoc-members:
