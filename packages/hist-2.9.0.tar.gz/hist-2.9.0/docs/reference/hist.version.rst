hist.version module
===================

.. automodule:: hist.version
   :members:
   :show-inheritance:
   :undoc-members:
