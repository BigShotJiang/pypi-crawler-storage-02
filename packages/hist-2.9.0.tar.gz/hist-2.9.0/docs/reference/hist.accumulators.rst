hist.accumulators module
========================

.. automodule:: hist.accumulators
   :members:
   :show-inheritance:
   :undoc-members:
