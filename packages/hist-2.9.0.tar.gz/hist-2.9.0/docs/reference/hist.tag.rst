hist.tag module
===============

.. automodule:: hist.tag
   :members:
   :show-inheritance:
   :undoc-members:
   :exclude-members: Slicer
