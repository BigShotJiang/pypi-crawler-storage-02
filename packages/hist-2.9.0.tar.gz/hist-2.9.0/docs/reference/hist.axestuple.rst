hist.axestuple module
=====================

.. automodule:: hist.axestuple
   :members:
   :show-inheritance:
   :undoc-members:
