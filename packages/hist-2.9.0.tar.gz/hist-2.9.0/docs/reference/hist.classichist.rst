hist.classichist module
=======================

.. automodule:: hist.classichist
   :members:
   :show-inheritance:
   :undoc-members:
