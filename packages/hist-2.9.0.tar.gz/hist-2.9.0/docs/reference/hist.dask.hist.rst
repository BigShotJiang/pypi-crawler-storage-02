hist.dask.hist module
=====================

.. automodule:: hist.dask.hist
   :members:
   :show-inheritance:
   :undoc-members:
