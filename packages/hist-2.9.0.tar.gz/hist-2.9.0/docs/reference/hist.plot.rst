hist.plot module
================

.. automodule:: hist.plot
   :members:
   :show-inheritance:
   :undoc-members:
