hist.hist module
================

.. automodule:: hist.hist
   :members:
   :show-inheritance:
   :undoc-members:
