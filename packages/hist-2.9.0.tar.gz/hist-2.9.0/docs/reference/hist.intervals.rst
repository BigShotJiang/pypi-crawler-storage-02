hist.intervals module
=====================

.. automodule:: hist.intervals
   :members:
   :show-inheritance:
   :undoc-members:
