hist.svgutils module
====================

.. automodule:: hist.svgutils
   :members:
   :show-inheritance:
   :undoc-members:
