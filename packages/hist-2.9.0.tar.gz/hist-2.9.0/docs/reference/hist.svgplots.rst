hist.svgplots module
====================

.. automodule:: hist.svgplots
   :members:
   :show-inheritance:
   :undoc-members:
