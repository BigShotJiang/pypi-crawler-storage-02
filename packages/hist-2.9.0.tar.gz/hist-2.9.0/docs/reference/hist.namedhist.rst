hist.namedhist module
=====================

.. automodule:: hist.namedhist
   :members:
   :show-inheritance:
   :undoc-members:
