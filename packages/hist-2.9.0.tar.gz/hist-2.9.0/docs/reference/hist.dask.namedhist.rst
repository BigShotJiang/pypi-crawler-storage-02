hist.dask.namedhist module
==========================

.. automodule:: hist.dask.namedhist
   :members:
   :show-inheritance:
   :undoc-members:
