hist.numpy module
=================

.. automodule:: hist.numpy
   :members:
   :show-inheritance:
   :undoc-members:
