hist
====

.. toctree::
   :maxdepth: 4

   hist
