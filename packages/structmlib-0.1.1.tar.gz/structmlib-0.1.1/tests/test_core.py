from structmlib import example_function

def test_example_function():
    assert example_function() == "Hello from StructMLib!"
