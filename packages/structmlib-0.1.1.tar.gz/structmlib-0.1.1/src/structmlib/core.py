def example_function():
    """
    Example function for StructMLib.
    Replace with your actual ML model functions.
    """
    return "Hello from StructMLib!"
