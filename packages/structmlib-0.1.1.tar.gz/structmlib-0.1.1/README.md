# StructMLib

**StructMLib** is a Python library for developing machine learning models in structural engineering.

## Installation
```bash
pip install structmlib
