
# API Reference

## forgeevent.handlers.base
::: forgeevent.handlers.base

## forgeevent.handlers.local
::: forgeevent.handlers.local

## forgeevent.typing
::: forgeevent.typing
