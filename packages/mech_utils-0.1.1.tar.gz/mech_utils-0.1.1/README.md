# mech_utils
Personal Python utility functions.

## Install
pip install mech_utils

## Usage
```python
from mech_utils import percent_change
print(percent_change(100, 125))
