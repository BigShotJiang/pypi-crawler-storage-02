//! Read and write from and to Apache Avro

mod read;
mod read_async;
mod write;
mod write_async;
