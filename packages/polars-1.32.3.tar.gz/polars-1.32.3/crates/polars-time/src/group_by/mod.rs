#[cfg(any(feature = "dtype-date", feature = "dtype-datetime"))]
pub(crate) mod dynamic;
