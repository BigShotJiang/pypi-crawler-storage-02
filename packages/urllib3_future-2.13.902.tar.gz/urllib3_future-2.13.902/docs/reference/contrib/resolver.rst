DNS Resolver
============

.. automodule:: urllib3.contrib.resolver
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: urllib3.contrib.resolver._async
    :members:
    :undoc-members:
    :show-inheritance:
