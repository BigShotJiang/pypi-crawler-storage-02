# wexample-file

Tools to manage the state of files and directories using simple YAML configuration files.

- Project: https://github.com/wexample/python-file
- License: MIT

Install:
```bash
pip install wexample-file
```

Quick start:
```python
from wexample_file import *
# TODO: usage examples will go here
```
