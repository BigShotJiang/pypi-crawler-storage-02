from pathlib import Path
from typing import Union

PathOrString = Union[Path, str]
