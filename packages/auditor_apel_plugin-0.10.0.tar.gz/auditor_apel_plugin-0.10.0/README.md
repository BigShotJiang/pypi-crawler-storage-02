# AUDITOR-APEL-plugin

Plugin for AUDITOR to report job records to APEL

## License

Licensed under

 - BSD-2-Clause Plus Patent License ([LICENSE](https://github.com/ALU-Schumacher/AUDITOR/tree/main/plugins/apel/LICENSE))

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in the work by you shall be licensed as above, without any additional terms or conditions.