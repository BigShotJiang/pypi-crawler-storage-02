<img src="./fig3.png" width="400px"></img>

## Dex1B (wip)

## Citations

```bibtex
@inproceedings{ye2025dex1b,
    title   = {Dex1B: Learning with 1B Demonstrations for Dexterous Manipulation},
    author  = {Ye, Jianglong and Wang, Keyi and Yuan, Chengjing and Yang, Ruihan and Li, Yiquan and Zhu, Jiyue and Qin, Yuzhe and Zou, Xueyan and Wang, Xiaolong},
    booktitle = {Robotics: Science and Systems (RSS)},
    year    = {2025}
}
```

```bibtex
@misc{wu2024pointtransformerv3simpler,
    title   = {Point Transformer V3: Simpler, Faster, Stronger}, 
    author  = {Xiaoyang Wu and Li Jiang and Peng-Shuai Wang and Zhijian Liu and Xihui Liu and Yu Qiao and Wanli Ouyang and Tong He and Hengshuang Zhao},
    year    = {2024},
    eprint  = {2312.10035},
    archivePrefix = {arXiv},
    primaryClass = {cs.CV},
    url     = {https://arxiv.org/abs/2312.10035}, 
}
```
