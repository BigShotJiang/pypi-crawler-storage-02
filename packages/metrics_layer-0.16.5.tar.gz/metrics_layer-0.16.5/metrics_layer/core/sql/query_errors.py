class ParseError(Exception):
    pass


class ArgumentError(Exception):
    pass
