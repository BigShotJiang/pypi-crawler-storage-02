from chik_rs import SpendConditions

Spend = SpendConditions
