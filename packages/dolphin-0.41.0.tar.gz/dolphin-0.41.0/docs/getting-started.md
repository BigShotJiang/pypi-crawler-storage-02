--8<-- "README.md:25:100"

For a more complete tutorial, see our [notebooks](notebooks)

For help with installing locally and contributing, see the [full developer setup instructions](developer-setup.md).
