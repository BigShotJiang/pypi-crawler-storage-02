
--8<-- "CONTRIBUTING.md"
