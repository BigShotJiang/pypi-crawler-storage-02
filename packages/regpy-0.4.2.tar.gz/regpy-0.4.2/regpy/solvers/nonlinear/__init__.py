r"""Solvers for ill-posed and inverse problems that are modeled by non-linear forward operators.
    """