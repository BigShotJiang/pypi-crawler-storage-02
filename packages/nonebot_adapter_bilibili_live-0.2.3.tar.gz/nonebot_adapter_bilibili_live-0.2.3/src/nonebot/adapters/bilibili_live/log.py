from __future__ import annotations

from nonebot.utils import logger_wrapper

log = logger_wrapper("bilibili Live")
