from .interact_word_v2 import InteractWord as InteractWordV2
from .online_rank_v3 import GoldRankBroadcast as OnlineRankV3
