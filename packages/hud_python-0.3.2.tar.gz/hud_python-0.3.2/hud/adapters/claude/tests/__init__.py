# Tests for hud.adapters.claude module
