Exceptions
=========================

.. automodule:: liblistenbrainz.errors
    :members:
    :undoc-members:
    :show-inheritance:

