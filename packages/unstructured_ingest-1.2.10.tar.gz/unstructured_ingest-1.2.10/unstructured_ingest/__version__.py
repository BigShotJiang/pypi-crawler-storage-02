__version__ = "1.2.10"  # pragma: no cover
