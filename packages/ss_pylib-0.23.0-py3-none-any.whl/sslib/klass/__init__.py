from .bit_flag import BitFlag8

__all__ = ['BitFlag8']
