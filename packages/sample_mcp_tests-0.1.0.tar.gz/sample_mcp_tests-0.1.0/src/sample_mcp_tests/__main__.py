from .mcp_tools import main

if __name__ == "__main__":
    main()
    