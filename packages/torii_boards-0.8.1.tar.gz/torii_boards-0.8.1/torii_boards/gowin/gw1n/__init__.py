# SPDX-License-Identifier: BSD-2-Clause

from .tang_nano import TangNanoPlatform

__all__ = (
	'TangNanoPlatform',
)
