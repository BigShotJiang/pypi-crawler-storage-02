# SPDX-License-Identifier: BSD-2-Clause

from .de0 import DE0Platform

__all__ = (
	'DE0Platform',
)
