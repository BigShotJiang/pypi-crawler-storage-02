# SPDX-License-Identifier: BSD-2-Clause

from .rz_easyfpga_a2_2 import RZEasyFPGAA2_2Platform

__all__ = (
	'RZEasyFPGAA2_2Platform',
)
