# SPDX-License-Identifier: BSD-2-Clause

from .mercury import MercuryPlatform

__all__ = (
	'MercuryPlatform',
)
