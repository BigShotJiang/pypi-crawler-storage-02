# SPDX-License-Identifier: BSD-2-Clause

from .kcu105 import KCU105Platform

__all__ = (
	'KCU105Platform',
)
