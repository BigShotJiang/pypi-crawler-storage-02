# SPDX-License-Identifier: BSD-2-Clause

from .quickfeather import QuickfeatherPlatform

__all__ = (
	'QuickfeatherPlatform',
)
