# SPDX-License-Identifier: BSD-2-Clause

from .machxo3_sk import MachXO3SKPlatform

__all__ = (
	'MachXO3SKPlatform',
)
