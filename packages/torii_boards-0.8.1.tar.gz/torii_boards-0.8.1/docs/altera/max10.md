# MAX10 Boards

```{eval-rst}
.. autoclass:: torii_boards.altera.max10.ArrowDECAPlatform
  :members:

.. autoclass:: torii_boards.altera.max10.DE10LitePlatform
  :members:
```
