# Cyclone IV Boards

```{eval-rst}
.. autoclass:: torii_boards.altera.cyclone_iv.RZEasyFPGAA2_2Platform
  :members:
```
