# Cyclone V Boards

```{eval-rst}
.. autoclass:: torii_boards.altera.cyclone_v.Chameleon96Platform
  :members:

.. autoclass:: torii_boards.altera.cyclone_v.DE0CVPlatform
  :members:

.. autoclass:: torii_boards.altera.cyclone_v.DE1SoCPlatform
  :members:

.. autoclass:: torii_boards.altera.cyclone_v.DE10NanoPlatform
  :members:

.. autoclass:: torii_boards.altera.cyclone_v.MisterPlatform
  :members:
```
