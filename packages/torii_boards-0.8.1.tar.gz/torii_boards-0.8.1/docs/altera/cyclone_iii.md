# Cyclone III Boards

```{eval-rst}
.. autoclass:: torii_boards.altera.cyclone_iii.DE0Platform
  :members:
```
