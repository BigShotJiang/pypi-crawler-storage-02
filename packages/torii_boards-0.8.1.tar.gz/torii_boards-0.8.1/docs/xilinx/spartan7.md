# Spartan7 Boards

```{eval-rst}
.. autoclass:: torii_boards.xilinx.spartan7.ArtyS7_25Platform
  :members:

.. autoclass:: torii_boards.xilinx.spartan7.ArtyS7_50Platform
  :members:

.. autoclass:: torii_boards.xilinx.spartan7.CmodS7_Platform
  :members:
```
