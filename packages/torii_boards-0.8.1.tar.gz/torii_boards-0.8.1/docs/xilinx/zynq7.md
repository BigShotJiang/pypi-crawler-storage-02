# Zynq7000 Boards

```{eval-rst}
.. autoclass:: torii_boards.xilinx.zynq7.ArtyZ720Platform
  :members:

.. autoclass:: torii_boards.xilinx.zynq7.EBAZ4205Platform
  :members:

.. autoclass:: torii_boards.xilinx.zynq7.MicroZedZ010Platform
  :members:

.. autoclass:: torii_boards.xilinx.zynq7.MicroZedZ020Platform
  :members:

.. autoclass:: torii_boards.xilinx.zynq7.ZTurnLiteZ007SPlatform
  :members:

.. autoclass:: torii_boards.xilinx.zynq7.ZTurnLiteZ010Platform
  :members:
```
