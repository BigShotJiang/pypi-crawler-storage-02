# Kintex UltraScale Boards

```{eval-rst}
.. autoclass:: torii_boards.xilinx.kintex_us.KCU105Platform
  :members:
```
