# Kintex7 Boards

```{eval-rst}
.. autoclass:: torii_boards.xilinx.kintex7.Genesys2Platform
  :members:

.. autoclass:: torii_boards.xilinx.kintex7.KC705Platform
  :members:
```
