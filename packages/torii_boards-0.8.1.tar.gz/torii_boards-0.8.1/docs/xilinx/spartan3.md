# Spartan3 Boards

```{eval-rst}
.. autoclass:: torii_boards.xilinx.spartan3.MercuryPlatform
  :members:
```
