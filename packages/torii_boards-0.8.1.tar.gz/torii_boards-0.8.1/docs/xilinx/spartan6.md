# Spartan6 Boards

```{eval-rst}
.. autoclass:: torii_boards.xilinx.spartan6.AtlysPlatform
  :members:

.. autoclass:: torii_boards.xilinx.spartan6.NumatoMimasPlatform
  :members:

.. autoclass:: torii_boards.xilinx.spartan6.SK_XC6SLX9Platform
  :members:
```
