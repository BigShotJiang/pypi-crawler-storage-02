# Artix7 Boards

```{eval-rst}
.. autoclass:: torii_boards.xilinx.artix7.AlchitryAuPlatform
  :members:

.. autoclass:: torii_boards.xilinx.artix7.ArtyA7_35Platform
  :members:

.. autoclass:: torii_boards.xilinx.artix7.ArtyA7_100Platform
  :members:

.. autoclass:: torii_boards.xilinx.artix7.CmodA7_15Platform
  :members:

.. autoclass:: torii_boards.xilinx.artix7.CmodA7_35Platform
  :members:

.. autoclass:: torii_boards.xilinx.artix7.Mega65r3Platform
  :members:

.. autoclass:: torii_boards.xilinx.artix7.Nexys4DDRPlatform
  :members:

.. autoclass:: torii_boards.xilinx.artix7.TE0714_03_50_2IPlatform
  :members:
```
