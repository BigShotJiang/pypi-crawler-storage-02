# GW1N Boards

```{eval-rst}
.. autoclass:: torii_boards.gowin.gw1n.TangNanoPlatform
  :members:
```
