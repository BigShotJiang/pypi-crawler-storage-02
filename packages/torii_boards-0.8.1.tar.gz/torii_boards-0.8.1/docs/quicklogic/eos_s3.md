# EOS S3 Boards

```{eval-rst}
.. autoclass:: torii_boards.quicklogic.eos_s3.QuickfeatherPlatform
  :members:
```
