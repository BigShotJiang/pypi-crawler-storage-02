"""Integration tests for Baresquare SDK.

These tests require real AWS credentials and resources.
They are designed to be run locally during development, not in CI.
"""
