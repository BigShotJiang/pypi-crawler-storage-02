"""Utility functions for the Confluence tool."""
