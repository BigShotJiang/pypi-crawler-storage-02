def main():
    print("Hello from connector-builder-mcp!")


if __name__ == "__main__":
    main()
