from .dotquery import Proxy, assert_eq
