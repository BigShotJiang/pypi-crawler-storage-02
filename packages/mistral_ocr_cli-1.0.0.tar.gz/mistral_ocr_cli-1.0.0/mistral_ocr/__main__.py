"""Entry point for running mistral_ocr as a module."""

from .cli import main

if __name__ == "__main__":
    main()