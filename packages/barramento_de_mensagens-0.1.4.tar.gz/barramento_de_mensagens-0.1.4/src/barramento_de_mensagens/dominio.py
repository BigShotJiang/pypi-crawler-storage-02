from enum import Enum


class DominioBase(Enum):
    # usuario = (UsuarioRepoDominio, UsuarioRepoConsulta)
    ...
