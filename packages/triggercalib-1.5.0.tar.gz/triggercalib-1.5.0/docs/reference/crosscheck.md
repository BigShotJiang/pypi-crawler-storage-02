::: crosscheck.factorisation
    options:
        show_root_toc_entry: false

::: crosscheck.kendall_tau
    options:
        show_root_toc_entry: false