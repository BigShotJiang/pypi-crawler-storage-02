
## `objects.fitting`
::: objects.fitting
    options:
        heading_level: 3
        show_root_toc_entry: false

## `objects.plotting`
::: objects.plotting
    options:
        heading_level: 3
        show_root_toc_entry: false

## `objects.sideband`
::: objects.sideband
    options:
        heading_level: 3
        show_if_no_docstring: true
        show_root_toc_entry: false