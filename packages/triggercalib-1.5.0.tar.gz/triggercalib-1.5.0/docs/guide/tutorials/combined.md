# Combined efficiency of multiple HLT1 lines

!!! warning
    This section is a work in progress, please check back another time