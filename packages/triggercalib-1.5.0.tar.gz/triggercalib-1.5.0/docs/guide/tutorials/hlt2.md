# Calculating HLT2 efficiencies in spruced samples

!!! warning
    This section is a work in progress, please check back another time