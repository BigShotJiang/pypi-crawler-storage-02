import os

IS_TEST_ENV = os.environ.get("IS_TEST_ENV") is not None
