from pyjudilibre.pyjudilibre import JudilibreClient, __version__  # noqa
