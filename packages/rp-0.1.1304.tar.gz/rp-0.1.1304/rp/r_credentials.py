Đ_gmail_address="someemail@gmail.com"
Đ_gmail_password="somepassword"