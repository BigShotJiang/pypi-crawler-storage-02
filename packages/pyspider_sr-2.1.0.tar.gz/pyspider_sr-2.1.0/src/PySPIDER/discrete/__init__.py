# PySPIDER Discrete Package
# This file makes the discrete directory a proper Python package
