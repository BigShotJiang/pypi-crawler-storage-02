BaseCourseCoupon
================

.. currentmodule:: codegrade.models.base_course_coupon

.. autoclass:: BaseCourseCoupon
   :members: id, created_at, limit, scope, course_price, used_amount
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
