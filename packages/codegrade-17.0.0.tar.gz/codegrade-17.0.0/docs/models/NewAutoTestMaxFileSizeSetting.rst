NewAutoTestMaxFileSizeSetting
=============================

.. currentmodule:: codegrade.models.new_auto_test_max_file_size_setting

.. autoclass:: NewAutoTestMaxFileSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
