RubricRowBaseInputAsJSON
========================

.. currentmodule:: codegrade.models.rubric_row_base_input_as_json

.. autoclass:: RubricRowBaseInputAsJSON
   :members: id, type
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
