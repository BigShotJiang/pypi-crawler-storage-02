LTIVersion
==========

.. currentmodule:: codegrade.models.lti_version

.. class:: LTIVersion

**Options**

* ``v1_1``
* ``v1_3``
