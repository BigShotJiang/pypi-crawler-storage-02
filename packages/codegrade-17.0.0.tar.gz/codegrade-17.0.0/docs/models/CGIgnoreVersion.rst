CGIgnoreVersion
===============

.. currentmodule:: codegrade.models.cg_ignore_version

.. class:: CGIgnoreVersion

**Options**

* ``EmptySubmissionFilter``
* ``IgnoreFilterManager``
* ``SubmissionValidator``
