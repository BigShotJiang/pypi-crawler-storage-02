BaseLaunchData
==============

.. currentmodule:: codegrade.models.base_launch_data

.. autoclass:: BaseLaunchData
   :members: course, new_role_created, new_session, updated_email
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
