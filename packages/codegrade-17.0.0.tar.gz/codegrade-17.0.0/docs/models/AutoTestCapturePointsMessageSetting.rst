AutoTestCapturePointsMessageSetting
===================================

.. currentmodule:: codegrade.models.auto_test_capture_points_message_setting

.. autoclass:: AutoTestCapturePointsMessageSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
