PlagiarismCase
==============

.. currentmodule:: codegrade.models.plagiarism_case

.. autoclass:: PlagiarismCase
   :members: id, match_max, match_avg, can_see_details, submissions
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
