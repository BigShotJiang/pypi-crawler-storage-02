TaskResultState
===============

.. currentmodule:: codegrade.models.task_result_state

.. class:: TaskResultState

**Options**

* ``not_started``
* ``started``
* ``finished``
* ``failed``
* ``crashed``
* ``skipped``
* ``revoked``
