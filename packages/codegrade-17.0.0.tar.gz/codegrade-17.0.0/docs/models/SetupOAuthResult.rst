SetupOAuthResult
================

.. currentmodule:: codegrade.models.setup_oauth_result

.. autoclass:: SetupOAuthResult
   :members: return_url
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
