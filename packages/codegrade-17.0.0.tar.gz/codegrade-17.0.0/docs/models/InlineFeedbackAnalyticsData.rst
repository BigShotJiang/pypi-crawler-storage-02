InlineFeedbackAnalyticsData
===========================

.. currentmodule:: codegrade.models.inline_feedback_analytics_data

.. autoclass:: InlineFeedbackAnalyticsData
   :members: tag, total_amount
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
