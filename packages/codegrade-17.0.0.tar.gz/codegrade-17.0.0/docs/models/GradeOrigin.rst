GradeOrigin
===========

.. currentmodule:: codegrade.models.grade_origin

.. class:: GradeOrigin

**Options**

* ``human``
* ``auto_test``
* ``rubric_migration``
* ``auto_test_2``
