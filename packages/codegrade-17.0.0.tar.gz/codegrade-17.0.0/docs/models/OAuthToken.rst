OAuthToken
==========

.. currentmodule:: codegrade.models.oauth_token

.. autoclass:: OAuthToken
   :members: id, provider, user_id, user_info
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
