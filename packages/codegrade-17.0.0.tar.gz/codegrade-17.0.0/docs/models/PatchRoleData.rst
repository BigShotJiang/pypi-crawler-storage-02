PatchRoleData
=============

.. currentmodule:: codegrade.models.patch_role_data

.. autoclass:: PatchRoleData
   :members: permission, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
