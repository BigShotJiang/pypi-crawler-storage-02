PatchSubmitTypesAssignmentData
==============================

.. currentmodule:: codegrade.models.patch_submit_types_assignment_data

.. autoclass:: PatchSubmitTypesAssignmentData
   :members: json, template
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
