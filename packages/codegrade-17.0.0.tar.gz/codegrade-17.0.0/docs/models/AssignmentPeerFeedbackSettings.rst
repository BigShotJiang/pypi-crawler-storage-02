AssignmentPeerFeedbackSettings
==============================

.. currentmodule:: codegrade.models.assignment_peer_feedback_settings

.. autoclass:: AssignmentPeerFeedbackSettings
   :members: amount, time, auto_approved, redivide_after_deadline
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
