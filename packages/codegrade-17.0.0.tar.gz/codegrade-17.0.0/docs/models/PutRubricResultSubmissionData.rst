PutRubricResultSubmissionData
=============================

.. currentmodule:: codegrade.models.put_rubric_result_submission_data

.. autoclass:: PutRubricResultSubmissionData
   :members: items
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
