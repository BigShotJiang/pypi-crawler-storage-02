LMSCapabilities
===============

.. currentmodule:: codegrade.models.lms_capabilities

.. autoclass:: LMSCapabilities
   :members: test_student_name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
