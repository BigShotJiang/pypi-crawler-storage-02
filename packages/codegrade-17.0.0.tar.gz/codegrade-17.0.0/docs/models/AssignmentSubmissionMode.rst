AssignmentSubmissionMode
========================

.. currentmodule:: codegrade.models.assignment_submission_mode

.. class:: AssignmentSubmissionMode

**Options**

* ``full``
* ``simple``
