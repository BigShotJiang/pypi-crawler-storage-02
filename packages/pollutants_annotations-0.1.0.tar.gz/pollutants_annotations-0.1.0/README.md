# Pollutants Annotations Dataset

污染物识别神经网络的训练数据集，包含文本和对应的污染物实体标注。

## 数据集介绍

该数据集包含两列：
- `text`: 包含污染物相关描述的文本
- `entities`: 标注的实体，格式为 `(begin, end, entity_name)`

## 安装

```bash
pip install pollutants-annotations