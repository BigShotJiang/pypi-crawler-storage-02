11.0.1.1.0 (2019-09-24)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] New feature.
  User can uses barcode interface in picking operations.

13.0.1.1.1 (2021-02-06)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] New feature.
  Add option to get lots automatically based on removal strategy in inventory.

14.0.1.0.0 (2021-04-05)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] New feature.
  Add security for users.
