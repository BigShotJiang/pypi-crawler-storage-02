from sqlalchemy.orm import DeclarativeBase


class QuestionsBase(DeclarativeBase):
    pass
