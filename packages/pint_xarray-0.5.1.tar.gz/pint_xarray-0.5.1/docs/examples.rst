Examples
========

.. toctree::
    :maxdepth: 1

    examples/plotting
