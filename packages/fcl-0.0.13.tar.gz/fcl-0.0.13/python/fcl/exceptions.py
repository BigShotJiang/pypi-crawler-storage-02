class StopException(Exception):
  pass