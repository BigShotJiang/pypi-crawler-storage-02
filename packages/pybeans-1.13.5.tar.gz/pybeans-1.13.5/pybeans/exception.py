class AppToolError(Exception):
    pass