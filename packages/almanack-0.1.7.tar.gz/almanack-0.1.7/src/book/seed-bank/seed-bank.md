(seed-bank-intro)=

# Seed Bank

The seed bank is a section of the Software Garden Almanack associated with applied demonstrations of concepts and technologies associated with other areas of content.
