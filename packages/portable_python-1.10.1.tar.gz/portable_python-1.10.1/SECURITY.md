# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x     | :white_check_mark: |

## Reporting a Vulnerability

To report any bug, please open an issue in our [issue tracker](https://github.com/codrsquad/portable-python/issues).
