__version__ = "1.2.0"
__description__ = "General-Validator is a universal batch data validator."

__all__ = ["__version__", "__description__"]