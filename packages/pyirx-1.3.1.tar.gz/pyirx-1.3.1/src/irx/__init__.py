"""Top-level package for IRx."""

__author__ = """Ivan Ogasawara"""
__email__ = "ivan.ogasawara@gmail.com"
__version__ = "1.3.1"  # semantic-release
