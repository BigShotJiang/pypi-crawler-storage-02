import camagick.source.epics as epics
