"""
This module contains examples of Python code.
"""

from interpolatepy.version import __version__


if __name__ == "__main__":
    print(f"Version of InterpolatePy : {__version__}\n")
