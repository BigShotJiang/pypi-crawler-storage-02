def make_dtc_input(dtc: dict):
    return {"input": dtc}
