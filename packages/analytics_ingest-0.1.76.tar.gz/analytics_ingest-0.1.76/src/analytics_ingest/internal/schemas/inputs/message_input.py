def make_create_message_input(messages):
    return {"input": {"messages": messages}}
