def main():
    print("Hello from py-nix-shell!")


if __name__ == "__main__":
    main()
