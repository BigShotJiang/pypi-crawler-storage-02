
| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `python speed_tests/xlsxeditor_speed.py` | 7.742 ± 0.020 | 7.729 | 7.766 | 1.00 |
