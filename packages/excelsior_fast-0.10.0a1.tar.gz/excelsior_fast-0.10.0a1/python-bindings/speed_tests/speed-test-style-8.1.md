| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed_style.py` | 795.8 ± 11.0 | 787.2 | 808.2 | 1.00 |
