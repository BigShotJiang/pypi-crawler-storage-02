| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed.py` | 633.3 ± 17.6 | 621.8 | 653.5 | 1.00 |
| `python openpyxl_speed.py` | 182045.5 ± 5491.2 | 177901.0 | 188273.6 | 287.47 ± 11.79 |
