| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python xlsxeditor_speed.py` | 386.3 ± 3.4 | 383.1 | 389.9 | 1.00 |
| `python openpyxl_speed.py` | 184214.5 ± 3823.4 | 179799.7 | 186439.6 | 476.83 ± 10.75 |
