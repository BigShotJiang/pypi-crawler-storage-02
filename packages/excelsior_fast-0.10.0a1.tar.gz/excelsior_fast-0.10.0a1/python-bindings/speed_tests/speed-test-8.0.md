| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `python excelsior_speed.py` | 831.3 ± 8.8 | 822.0 | 839.6 | 1.00 |
| `python openpyxl_speed.py` | 183897.8 ± 9571.4 | 177662.3 | 194918.1 | 221.21 ± 11.75 |
