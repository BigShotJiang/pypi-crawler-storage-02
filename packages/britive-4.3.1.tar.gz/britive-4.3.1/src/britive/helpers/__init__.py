from .methods import HelperMethods


class Helpers:
    def __init__(self, britive) -> None:
        self.helper_methods = HelperMethods(britive)
