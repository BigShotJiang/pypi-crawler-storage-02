// Mock platform implementation for development purposes

class LimeWebComponentPlatformBrowser {
    // TBD!
}

window.LimeWebComponentPlatformBrowser = LimeWebComponentPlatformBrowser;
