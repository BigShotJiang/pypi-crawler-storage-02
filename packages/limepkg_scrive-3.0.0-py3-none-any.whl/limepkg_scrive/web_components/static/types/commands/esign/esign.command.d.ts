import { Expression, LimeWebComponentContext } from '@limetech/lime-web-components';
export declare class EsignCommand {
  context: LimeWebComponentContext;
  filter?: Expression;
}
