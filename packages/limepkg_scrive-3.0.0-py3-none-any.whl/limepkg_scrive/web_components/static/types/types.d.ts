export declare type OurAwesomePackageConfig = {
  scriveHost: string;
  includePerson: boolean;
  includeCoworker: boolean;
  cloneDocument: boolean;
  target: string;
};
