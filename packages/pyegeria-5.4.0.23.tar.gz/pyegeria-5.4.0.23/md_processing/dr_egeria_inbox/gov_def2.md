
___

#  Don't Update Regulation 
## Name
A Regulation
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Create Governance Control
## Name
A Control
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Create Governance Rule
## Name
a gov rule
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Service Level Objectives
## Name
An Obligation
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Create Governance Process
## Name
A Gov Process
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Governance Responsibility
## Name
A Responsibility
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Update Governance Procedure
## Name
A Gov procedure
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

## Supports Policies
Approach

## Merge Update
True
____

#  Don't Create Security Access Control
## Name
sec access
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Security Group
## Name
a Sec Group
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED


____

#  Don't Naming Standard Rule
## Name
a Namng Standard
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create Certification Type
## Name
a Cert
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Create License Type
## Name
a License
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

___

#  Don't Create Governance Principle
## Name
Talmudic
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

#  Don't Update Governance Approach
## Name
Approach
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED
## Drivers
A Regulation
## Merge Update
True
____

# Update Governance Strategy
## Name
Strategy
## Summary
Based on Talmud
## Description
Somewhat chaotic
## Domain Identifier
1
## Version Identifier

## Scope
InterGalactic

## Importance
Somewhat

## Implications
Power; Money
## Outcomes
Happiness
## Results
Unknown
## Status
PROPOSED

____

# Don't Detach Governance Drivers
## Definition 1
A Regulation
## Definition 2
Strategy
## Label
Don't get caught

___
# View Governance Definitions
## Output Format
LIST


___