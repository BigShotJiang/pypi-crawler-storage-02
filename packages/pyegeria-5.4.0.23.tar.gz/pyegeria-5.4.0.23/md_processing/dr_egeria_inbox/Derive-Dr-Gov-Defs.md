___
# View Governance Definition Context
## Display Name
New Sustainability Governance Domain
## Qualified Name
GovernanceApproach::New Sustainability Governance Domain
## Output Format
HTML
