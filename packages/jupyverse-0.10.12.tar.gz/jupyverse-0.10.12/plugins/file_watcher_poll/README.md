# fps-file-watcher-poll

An FPS plugin for the file watcher API.
