# fps-auth-jupyterhub

An FPS plugin for the authentication API, using JupyterHub.
