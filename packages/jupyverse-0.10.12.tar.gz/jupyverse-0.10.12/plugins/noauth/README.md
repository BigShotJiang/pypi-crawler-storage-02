# fps-noauth

An FPS plugin for an unprotected API.
