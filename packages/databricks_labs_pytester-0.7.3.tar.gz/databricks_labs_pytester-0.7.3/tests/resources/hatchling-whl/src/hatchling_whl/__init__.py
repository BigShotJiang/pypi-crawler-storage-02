def main():
    print('it works')


if __name__ == '__main__':
    main()
