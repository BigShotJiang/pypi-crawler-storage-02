# import libs
from rich import print
from mozichem_ai import __version__

# NOTE: check version
print(f"mozichem_ai version: {__version__}")
