# from ormlambda.common.interfaces import IDecompositionQuery


class ICustomAlias[T, *Ts]: ...


# class ICustomAlias[T, *Ts](IDecompositionQuery[T, *Ts]): ...
