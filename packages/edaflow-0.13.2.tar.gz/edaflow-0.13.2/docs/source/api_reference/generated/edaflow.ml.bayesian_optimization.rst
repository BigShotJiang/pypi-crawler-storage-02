﻿edaflow.ml.bayesian\_optimization
=================================

.. currentmodule:: edaflow.ml

.. autofunction:: bayesian_optimization