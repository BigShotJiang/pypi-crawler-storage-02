# this file is @generated
import typing as t

from .common import BaseModel


class SegmentConfig(BaseModel):
    secret: t.Optional[str] = None
