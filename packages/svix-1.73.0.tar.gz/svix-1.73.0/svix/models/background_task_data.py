# file manually edited
from typing import Any, Dict

BackgroundTaskData = Dict[str, Any]
