"""Utilities for model training (explicit namespace)."""
