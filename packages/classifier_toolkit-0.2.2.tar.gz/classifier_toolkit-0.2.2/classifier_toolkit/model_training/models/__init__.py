"""Model training models package (explicit namespace)."""
