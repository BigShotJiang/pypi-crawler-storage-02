Attribution to Aider AI https://github.com/Aider-AI/aider/tree/main/aider/queries/tree-sitter-language-pack

These scm files are all adapted from the github repositories listed here:

https://github.com/Goldziher/tree-sitter-language-pack/blob/main/sources/language_definitions.json

See this URL for information on the licenses of each repo:

https://github.com/Goldziher/tree-sitter-language-pack/

