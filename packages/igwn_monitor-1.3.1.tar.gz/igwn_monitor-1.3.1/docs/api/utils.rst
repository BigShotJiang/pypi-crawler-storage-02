.. automodapi:: igwn_monitor.utils
    :skip: IntEnum
    :skip: gpstime
