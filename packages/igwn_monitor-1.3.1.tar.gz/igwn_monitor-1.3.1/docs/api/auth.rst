.. automodapi:: igwn_monitor.auth
    :skip: contextmanager
    :skip: patch
    :skip: sleep
