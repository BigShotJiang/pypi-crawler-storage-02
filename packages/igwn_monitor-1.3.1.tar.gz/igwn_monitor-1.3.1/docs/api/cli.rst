.. automodapi:: igwn_monitor.cli
    :skip: Path
