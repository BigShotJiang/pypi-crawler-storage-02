.. automodapi:: igwn_monitor.logging
    :skip: terminal_supports_colors
