.. -- technical documents -------------

.. |LIGO-T010150| replace:: LIGO-T010150
.. _LIGO-T010150: https://dcc.ligo.org/LIGO-T010150/public
