# Activate NiceGUI Developer Role

action nicegui-developer