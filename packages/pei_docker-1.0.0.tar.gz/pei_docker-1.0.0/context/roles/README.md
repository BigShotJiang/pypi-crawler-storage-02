context descriptions for different roles in AI assistants

Each role has a subdir, with all the materials defining the context for that role.