# Contrib scripts

Scripts related to different kinds of projects. Create your own directory and add your scripts there.