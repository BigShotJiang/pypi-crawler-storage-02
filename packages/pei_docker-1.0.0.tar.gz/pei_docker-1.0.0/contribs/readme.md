# Contrib project configurations

Here comes `user_config.yml` for different kinds of projects.

Naming: create your own directory and add your configurations there.