"""
Bigdata.com Research Tools
"""

__version__: str = "0.17.3"
