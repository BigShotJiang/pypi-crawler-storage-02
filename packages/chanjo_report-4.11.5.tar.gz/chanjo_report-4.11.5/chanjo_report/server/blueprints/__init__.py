# -*- coding: utf-8 -*-
from .index import index_bp
from .report import report_bp
