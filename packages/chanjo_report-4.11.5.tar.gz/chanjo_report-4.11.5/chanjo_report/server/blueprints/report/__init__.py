# -*- coding: utf-8 -*-
from .views import report_bp
