# -*- coding: utf-8 -*-
from .html import render_html
from .pdf import render_pdf
