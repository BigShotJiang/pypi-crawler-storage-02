# -*- coding: utf-8 -*-
"""
test_chanjo_report
----------------------------------

Tests for `chanjo-report` module.
"""
import pytest
import chanjo_report


class TestChanjoReport(object):
  @classmethod
  def set_up(self):
    pass

  def test_something(self):
    pass

  @classmethod
  def tear_down(self):
    pass
