"""Cli __init__ module."""
