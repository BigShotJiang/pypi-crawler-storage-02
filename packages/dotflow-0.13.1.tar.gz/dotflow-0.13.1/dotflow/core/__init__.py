"""Core __init__ module."""
