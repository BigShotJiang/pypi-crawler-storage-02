"""Decorators __init__ module."""

from dotflow.core.decorators.time import time


__all__ = [
    "time"
]
