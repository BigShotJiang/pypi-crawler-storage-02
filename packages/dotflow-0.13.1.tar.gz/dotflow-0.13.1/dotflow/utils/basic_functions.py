"""Utils module"""


def basic_function(*args, **kwargs) -> None:
    pass


def basic_callback(*args, **kwargs) -> None:
    pass
