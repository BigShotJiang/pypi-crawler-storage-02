"""Abstract __init__ module."""
