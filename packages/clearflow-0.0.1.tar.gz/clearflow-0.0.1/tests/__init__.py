"""Tests package for ClearFlow.

Copyright (c) 2025 ClearFlow Contributors

This package contains comprehensive tests for the ClearFlow framework,
demonstrating functional programming testing patterns and verifying
the correctness of all core functionality.
"""
