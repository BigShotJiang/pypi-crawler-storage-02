# NOTE: Alias, remove in 9.0
from dipdup.datasources.evm_etherscan import EvmEtherscanDatasource as AbiEtherscanDatasource  # noqa: F401
