# NOTE: Alias, remove in 9.0
from dipdup.config.evm_etherscan import EvmEtherscanDatasourceConfig as AbiEtherscanDatasourceConfig

__all__ = ('AbiEtherscanDatasourceConfig',)
