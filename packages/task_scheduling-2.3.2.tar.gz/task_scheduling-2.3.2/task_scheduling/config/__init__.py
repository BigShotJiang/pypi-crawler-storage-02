# -*- coding: utf-8 -*-
# Author: fallingmeteorite
from .config import config, ensure_config_loaded, update_config
