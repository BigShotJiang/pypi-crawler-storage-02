scheduler_timer = "timer"
scheduler_cpu = "cpu"
scheduler_io = "io"

priority_low = "low"
priority_high = "high"
