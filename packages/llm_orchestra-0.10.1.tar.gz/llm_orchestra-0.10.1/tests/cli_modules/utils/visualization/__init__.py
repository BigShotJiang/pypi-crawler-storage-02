"""Tests for visualization modules."""
