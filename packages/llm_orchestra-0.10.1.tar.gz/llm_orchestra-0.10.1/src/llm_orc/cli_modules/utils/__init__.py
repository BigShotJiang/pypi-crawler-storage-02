"""Common CLI utilities."""
