"""Communication protocols for LLM Orchestra."""
