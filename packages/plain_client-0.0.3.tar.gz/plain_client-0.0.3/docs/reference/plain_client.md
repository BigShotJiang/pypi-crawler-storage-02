# Reference

::: plain_client.client.Plain
    options:
      show_if_no_docstring: true
      show_signature_annotations: true
      show_source: false
      separate_signature: true
      signature_crossrefs: true

## Models

::: plain_client
    options:
      show_root_heading: false
      show_toc_entry: false
      show_if_no_docstring: true
      show_signature_annotations: true
      show_source: false
      filters: ["!^_", "Plain"]
