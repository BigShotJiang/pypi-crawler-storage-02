"""
The external directory botocore was copied from
https://github.com/open-telemetry/opentelemetry-python-contrib/pull/1350
"""
