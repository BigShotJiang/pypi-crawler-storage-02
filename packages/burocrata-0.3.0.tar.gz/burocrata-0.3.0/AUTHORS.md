# Project Authors

The following people have made contributions to the project (in alphabetical
order by last name) and are considered "The Burocrata Developers":

* [Leonardo Uieda](https://github.com/leouieda) - Universidade de São Paulo, Brazil (ORCID: [0000-0001-6123-9515](https://www.orcid.org/0000-0001-6123-9515))
