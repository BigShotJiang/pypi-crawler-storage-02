# Changelog

## Version 0.2.0

Release date: 2024/03/04

New features:

* Add support for multiple input directories ([#5](https://github.com/fatiando/burocrata/pull/5))

## Version 0.1.1

Release date: 2024/03/01

Bug fixes:

* Bug fix: Check failed if the source file is empty ([#3](https://github.com/fatiando/burocrata/pull/3))

## Version 0.1.0

Release date: 2024/03/01

**First release of *Burocrata*, a tool for checking and adding license and
copyright notices to source code files.**

This is a command-line program and has the basic implementation working. It's
still a prototype and needs to be tested in the wild. It also has no unit tests
at the moment.
