from hardwario import cli

cli.main()
