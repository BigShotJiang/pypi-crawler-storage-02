# src\file_conversor\system\lin\__init__.py

from file_conversor.system.lin.utils import is_admin, reload_user_path
