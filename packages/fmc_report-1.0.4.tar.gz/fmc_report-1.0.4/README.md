# FMC Export

This tool was developed to export access policies and prefilter policies from FMC as CSV files.  

## Flow chart
The following flowchart is currently not up to date and does not include the section on prefilter policies, for example. However, it is still suitable for a first overview.

![Flow Chart](flow_chart.png)
