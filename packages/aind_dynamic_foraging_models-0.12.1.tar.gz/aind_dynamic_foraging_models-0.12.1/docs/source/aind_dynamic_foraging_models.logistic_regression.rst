aind\_dynamic\_foraging\_models.logistic\_regression package
============================================================

Submodules
----------

aind\_dynamic\_foraging\_models.logistic\_regression.model module
-----------------------------------------------------------------

.. automodule:: aind_dynamic_foraging_models.logistic_regression.model
   :members:
   :undoc-members:
   :show-inheritance:

aind\_dynamic\_foraging\_models.logistic\_regression.plot module
----------------------------------------------------------------

.. automodule:: aind_dynamic_foraging_models.logistic_regression.plot
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: aind_dynamic_foraging_models.logistic_regression
   :members:
   :undoc-members:
   :show-inheritance:
