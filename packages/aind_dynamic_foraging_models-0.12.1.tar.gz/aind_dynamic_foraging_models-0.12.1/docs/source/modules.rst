Modules
===

.. toctree::
   :maxdepth: 4

   aind_dynamic_foraging_models
