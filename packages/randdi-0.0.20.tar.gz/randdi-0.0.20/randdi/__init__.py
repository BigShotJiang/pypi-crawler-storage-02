def U():
    print("""lamia is a fucking bitch""")
