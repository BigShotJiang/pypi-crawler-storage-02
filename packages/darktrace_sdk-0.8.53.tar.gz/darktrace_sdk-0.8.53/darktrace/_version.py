# Version information for darktrace-sdk
# This is the single source of truth for version information
# after that the script update_version.py needs to be run
__version__ = "0.8.53"