User Guide
==========

Examples of how to use fiasco to parse CHIANTI data and compute derived quantities.
