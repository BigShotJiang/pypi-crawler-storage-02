Comparisons to CHIANTI IDL Routines
===================================

This section of the example gallery shows comparisons to results computed from the CHIANTI IDL routines.
The purpose of these examples is to show how results from fiasco compare to the equivalent results from the IDL routines.
This also provides a guide for how to perform common CHIANTI IDL calculations with fiasco.
