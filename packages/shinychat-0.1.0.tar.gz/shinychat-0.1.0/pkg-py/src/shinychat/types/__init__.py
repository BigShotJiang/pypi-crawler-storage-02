from .._chat import ChatMessageDict

__all__ = [
    "ChatMessageDict",
]
