function component = body(component)

if ~exist('component', 'var'); component = struct();

component.is_body = true;


end