function vectorplot(ax, v, varargin)

plot3(ax, v(1,:), v(2,:), v(3,:), varargin{:});

end