function vectorscatter(ax,v,varargin)

scatter3(ax, v(1,:), v(2,:), v(3,:), varargin{:});

end