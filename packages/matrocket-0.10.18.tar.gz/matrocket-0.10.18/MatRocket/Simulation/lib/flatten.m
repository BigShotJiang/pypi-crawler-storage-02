function mat = flatten(mat)
mat = reshape(mat, size(mat,1), size(mat,3));
end