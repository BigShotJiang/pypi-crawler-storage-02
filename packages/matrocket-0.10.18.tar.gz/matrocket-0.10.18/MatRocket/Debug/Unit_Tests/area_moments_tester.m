
cube = txt2struct('.\Data\reference_cube\Cube.txt')