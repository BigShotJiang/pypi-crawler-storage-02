=====
Usage
=====

To use Jenkins Jobs in a project::

    import jenkins_jobs
