from .terminal_colors import abuB, abuF, abuS, AbuAll
