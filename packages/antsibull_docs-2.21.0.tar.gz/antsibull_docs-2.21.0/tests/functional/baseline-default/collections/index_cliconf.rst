:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_cliconf_plugins:

Index of all Cliconf Plugins
============================

ns.col2
-------

* :ansplugin:`ns.col2.extra#cliconf` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#cliconf` -- Foo router CLI config
