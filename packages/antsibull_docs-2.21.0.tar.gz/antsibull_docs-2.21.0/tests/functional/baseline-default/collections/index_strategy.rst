:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_strategy_plugins:

Index of all Strategy Plugins
=============================

ns.col2
-------

* :ansplugin:`ns.col2.extra#strategy` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#strategy` -- Executes tasks in foo
