:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_inventory_plugins:

Index of all Inventory Plugins
==============================

ns.col2
-------

* :ansplugin:`ns.col2.extra#inventory` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#inventory` -- The foo inventory :ansopt:`ns2.col.foo#inventory:bar`
