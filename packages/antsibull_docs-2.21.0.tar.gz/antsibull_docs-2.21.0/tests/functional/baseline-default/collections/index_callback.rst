:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_callback_plugins:

Index of all Callback Plugins
=============================

.. toctree::
   :maxdepth: 1
   :caption: List of callback plugins by callback type
   :glob:

   callback_index_*


ns.col2
-------

* :ansplugin:`ns.col2.extra#callback` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#callback` -- Foo output :ansopt:`ns2.col.foo#callback:bar`
