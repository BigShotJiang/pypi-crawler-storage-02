.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Test Plugins
=========================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_test.rst>`_ --

ns2.col
-------

* `ns2.col.bar <ns2/col/bar_test.rst>`_ -- Is something a bar
* `ns2.col.foo <ns2/col/foo_test.rst>`_ -- Is something a foo :literal:`bar` (of test plugin `ns2.col.foo <foo_test.rst>`__)
