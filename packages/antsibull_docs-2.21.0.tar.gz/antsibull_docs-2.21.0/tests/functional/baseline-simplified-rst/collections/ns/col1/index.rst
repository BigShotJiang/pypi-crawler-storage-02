.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>


Ns.Col1
=======


.. contents::
   :local:
   :depth: 1

Description
-----------

A short description.

**Authors:**

* Ansible (https://github.com/ansible)
* Foo Bar (@ansible)
* Test <foo@example.com>




Changelog
---------

`Ns.Col1 Release Notes <changelog.rst>`_

Plugin Index
------------

There are no plugins in the ns.col1 collection with automatically generated documentation.
