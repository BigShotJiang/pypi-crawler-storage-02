.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>


.. _list_of_collections_ns:

Collections in the Ns Namespace
===============================

These are the collections documented here in the **ns** namespace.

* `ns.col1 <namespace/index.rst>`_
* `ns.col2 <namespace/index.rst>`_
