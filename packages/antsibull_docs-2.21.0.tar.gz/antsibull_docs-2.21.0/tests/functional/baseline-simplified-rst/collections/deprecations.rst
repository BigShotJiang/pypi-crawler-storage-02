.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all deprecated plugins
===============================

Index of all deprecated become plugins
--------------------------------------

* `ns2.col.foo <foo_become.rst>`_ -- Use foo :literal:`bar` (of become plugin `ns2.col.foo <foo_become.rst>`__)

Index of all deprecated roles
-----------------------------

* `ns2.col.foo <foo_role.rst>`_ -- Foo role
