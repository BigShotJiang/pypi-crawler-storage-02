.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Strategy Plugins
=============================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_strategy.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_strategy.rst>`_ -- Executes tasks in foo
