.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Modules
====================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_module.rst>`_ --
* `ns.col2.foo <ns/col2/foo_module.rst>`_ --
* `ns.col2.foo2 <ns/col2/foo2_module.rst>`_ -- Foo two
* `ns.col2.foo3 <ns/col2/foo3_module.rst>`_ -- Foo III
* `ns.col2.foo4 <ns/col2/foo4_module.rst>`_ -- Markup reference linting test

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_module.rst>`_ -- Do some foo :literal:`bar` (of module `ns2.col.foo <foo_module.rst>`__)
* `ns2.col.foo2 <ns2/col/foo2_module.rst>`_ -- Another foo
* `ns2.col.sub.foo3 <ns2/col/sub.foo3_module.rst>`_ -- A sub-foo

ns2.flatcol
-----------

* `ns2.flatcol.foo <ns2/flatcol/foo_module.rst>`_ -- Do some foo :literal:`bar` (of module `ns2.flatcol.foo <foo_module.rst>`__)
* `ns2.flatcol.foo2 <ns2/flatcol/foo2_module.rst>`_ -- Another foo
