.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

ns2.col.is_bar test
+++++++++++++++++++

- This redirect is part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).

  To use it in a playbook, specify: ``ns2.col.is_bar``.

- This is a redirect to the ns2.col.bar test plugin.
- This redirect does **not** work with Ansible 2.9.
