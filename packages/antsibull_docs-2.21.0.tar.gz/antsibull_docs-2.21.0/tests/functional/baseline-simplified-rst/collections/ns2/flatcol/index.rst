.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>


Ns2.Flatcol
===========


.. contents::
   :local:
   :depth: 1

Description
-----------


**Author:**

* Ansible (https://github.com/ansible)


Collection links
~~~~~~~~~~~~~~~~

* `Report an issue <https://github.com/ansible-collections/community.REPO\_NAME/issues/new/choose>`__

Communication
-------------

- Forum: `Ansible Forum <https://forum.ansible.com/c/help/6/none>`__.
- Matrix room :literal:`#users:ansible.im`: `General usage and support questions <https://matrix.to/#/#users:ansible.im>`__.
- IRC channel :literal:`#ansible` (Libera network):
  `General usage and support questions <https://web.libera.chat/?channel=#ansible>`__.
- Mailing list: `Ansible Project List <https://groups.google.com/g/ansible-project>`__.
  (`Subscribe <mailto:ansible-project+subscribe@googlegroups.com?subject=subscribe>`__)

Plugin Index
------------

These are the plugins in the ns2.flatcol collection:


Modules
~~~~~~~

* `foo module <foo_module.rst>`_ -- Do some foo :literal:`bar` (of module `ns2.flatcol.foo <foo_module.rst>`__)
* `foo2 module <foo2_module.rst>`_ -- Another foo
