.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

ns2.col.foo_4_redirect
++++++++++++++++++++++

This plugin was part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).

This module has been removed
in version 2.0.0 of ns2.col.
It is gone
