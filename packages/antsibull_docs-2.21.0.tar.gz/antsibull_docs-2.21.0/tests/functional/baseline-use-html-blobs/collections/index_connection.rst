:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_connection_plugins:

Index of all Connection Plugins
===============================

ns2.col
-------

* :ansplugin:`ns2.col.foo#connection` -- Foo connection :ansopt:`ns2.col.foo#connection:bar`
