# Changelog

All notable changes to this project will be documented in this file.

## v0.3.0, 2025-08-07

Bug fix for empty help text.

## v0.2.0, 2025-06-21

Bug fixes for single lines in help text.

## v0.1.1, 2025-06-17

Initial release
