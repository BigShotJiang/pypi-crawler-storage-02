# Tests for sphinx_click_custom
