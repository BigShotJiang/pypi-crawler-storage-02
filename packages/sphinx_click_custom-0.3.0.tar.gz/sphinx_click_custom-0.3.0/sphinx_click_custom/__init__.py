"""Sphinx extension for documenting Click commands with custom get_help() methods."""

from .ext import setup  # noqa
