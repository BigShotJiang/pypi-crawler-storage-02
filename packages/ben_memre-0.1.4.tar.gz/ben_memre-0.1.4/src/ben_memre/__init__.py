from .functions import greet, add_numbers, normalize, one_hot_encode, calculate_accuracy
