"""Create the WikiANN-FO-mini NER dataset and upload it to the HF Hub."""
