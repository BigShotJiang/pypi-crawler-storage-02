"""Tests for the `token_classification` module."""
