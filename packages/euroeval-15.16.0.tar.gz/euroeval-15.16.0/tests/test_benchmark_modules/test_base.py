"""Unit tests for the `base` module."""
