"""Unit tests for the `litellm` module."""
