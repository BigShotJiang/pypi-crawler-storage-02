# To view replica data, use Workspace.deployment

raise RuntimeError("You do not need to use this module. Use Workspace.deployment.")
