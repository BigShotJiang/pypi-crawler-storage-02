# To view monitoring data, use Workspace.deployment and Workspace.job.

raise RuntimeError(
    "You do not need to use this module. Use Workspace.deployment and Workspace.job."
)
