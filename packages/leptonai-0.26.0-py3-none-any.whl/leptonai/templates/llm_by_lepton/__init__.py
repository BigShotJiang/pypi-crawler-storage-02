# flakes8: noqa
"""
The Lepton LLM runtime photon is available on the Lepton AI platform. This is a stub to store the README file for the photon.
"""

_photon_name = "llm_by_lepton"
