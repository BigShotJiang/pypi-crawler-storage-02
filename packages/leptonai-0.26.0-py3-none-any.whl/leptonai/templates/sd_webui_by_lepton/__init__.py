# flakes8: noqa
"""
The Stabld Diffusion WebUI runtime photon is available on the Lepton AI platform. 
This is a stub to store the README file for the photon.
"""

_photon_name = "sd-webui-by-lepton"
