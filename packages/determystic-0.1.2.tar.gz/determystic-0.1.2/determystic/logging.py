from rich.console import Console

CONSOLE = Console()