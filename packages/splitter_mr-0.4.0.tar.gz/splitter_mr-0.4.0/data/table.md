| Baseline | First follow-up | Second follow-up | Third follow-up | Unnamed: 4 |
| --- | --- | --- | --- | --- |
| Participants | 100 | na | 88 | 77.5 |
| Male | 0.6 | — | 71.59 | 70.3% |
| SBP | 130.5 | 141 | 142.53 | 137333 |
| HR | 63.73 (10) | 65.11 (11) | 70.22 (12) | 74.44 (14) |
| Weight | 64.5 (15.2) | 65 (14) | 63 (13.3) | 59 (14.2) |