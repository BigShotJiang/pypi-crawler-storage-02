# The sandbox

A place to test out some lower-level things, but not as actual tests. This
directory will probably go away when v1.0 hits.

Also note that some of the code in here will be particular to how my own
Raindrop account is set up. You may want to read the code, but you don't
want to run it.

[//]: # (README.md ends here)
