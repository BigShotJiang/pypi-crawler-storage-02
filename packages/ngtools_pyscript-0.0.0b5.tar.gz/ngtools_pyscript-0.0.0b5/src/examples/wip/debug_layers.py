from ngtools.scene import Scene

scene = Scene()

scene.load("zarr://https://neuroglancer.lincbrain.org/zarr/a4c46d0f-093a-4ccb-a06a-9c78a708174e/")

foo = 0
