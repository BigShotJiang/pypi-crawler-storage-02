from .main import classify_dominant_color
