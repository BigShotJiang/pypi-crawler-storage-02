"""
pyChp: A Python Toolkit for the Chinese Pharmacopoeia
"""

__version__ = "0.0.1a1"
__author__ = "pyChp Team"
__email__ = "team@pychp.org"

# Import main modules and functions here
# from .core import *
# from .utils import *
