# 完整的、最终修正版的 __init__.py 文件

from mcp.server.fastmcp import FastMCP

def main() -> None:
    """
    主启动函数。
    服务器的创建、配置和运行都在这个函数内部完成。
    """
    # 1. 把服务器的创建和配置，全部移到 main 函数内部
    mcp = FastMCP("Demo")

    # 2. 在函数内定义工具
    @mcp.tool()
    def add(a: int, b: int) -> int:
        """Add two numbers"""
        return a + b

    # 3. 在函数内定义资源
    @mcp.resource("greeting://{name}")
    def get_greeting(name: str) -> str:
        """Get a personalized greeting"""
        return f"Hello, {name}!"

    # 4. 最后在函数内启动它
    mcp.run(transport='stdio')

# 这部分可以保留，方便你本地调试
if __name__ == "__main__":
    main()