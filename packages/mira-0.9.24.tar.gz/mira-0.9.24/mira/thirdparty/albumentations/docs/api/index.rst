API
===

.. toctree::
   :maxdepth: 2

   ./core
   ./augmentations
   ./imgaug
   ./pytorch
