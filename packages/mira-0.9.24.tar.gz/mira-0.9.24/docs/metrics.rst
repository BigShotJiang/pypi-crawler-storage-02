Metrics
*******

We provide a few common metrics for object detection

.. automodule:: mira.metrics
    :members: