Annotations
***********

.. autoclass:: mira.core.Annotation
    :members:

.. autoclass:: mira.core.Categories
    :members: