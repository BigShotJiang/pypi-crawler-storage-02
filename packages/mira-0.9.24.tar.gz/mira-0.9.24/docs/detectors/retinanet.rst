EfficientDet
************

.. autoclass:: mira.detectors.RetinaNet
