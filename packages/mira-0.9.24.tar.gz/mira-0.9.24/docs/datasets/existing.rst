Load existing datasets
**********************

.. autofunction:: mira.datasets.load_voc2012

.. autofunction:: mira.datasets.load_oxfordiiitpets

.. autofunction:: mira.datasets.load_shapes