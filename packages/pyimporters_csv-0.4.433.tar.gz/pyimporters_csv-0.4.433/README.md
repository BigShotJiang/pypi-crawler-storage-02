## Requirements

- Python 3.6+
- Pydantic for the data parts.
- Pandas for the parsing parts.

## Installation

```
pip install pyimporters-csv
```
