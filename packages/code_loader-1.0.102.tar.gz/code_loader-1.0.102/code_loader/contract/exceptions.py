
class DatasetScriptException(Exception):
    pass
