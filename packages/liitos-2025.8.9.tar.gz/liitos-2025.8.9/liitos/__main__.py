import sys

from liitos.cli import app

if __name__ == '__main__':
    sys.exit(app(prog_name='liitos'))  # pragma: no cover
