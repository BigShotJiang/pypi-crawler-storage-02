def parse():  # type: ignore
    return NotImplemented
