from .client import Client, __version__

assert Client
