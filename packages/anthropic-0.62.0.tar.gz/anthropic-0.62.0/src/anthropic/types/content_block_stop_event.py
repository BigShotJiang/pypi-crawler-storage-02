# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .raw_content_block_stop_event import RawContentBlockStopEvent

__all__ = ["ContentBlockStopEvent"]

ContentBlockStopEvent = RawContentBlockStopEvent
"""The RawContentBlockStopEvent type should be used instead"""
