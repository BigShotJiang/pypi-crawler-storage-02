# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .raw_content_block_delta_event import RawContentBlockDeltaEvent

__all__ = ["ContentBlockDeltaEvent"]

ContentBlockDeltaEvent = RawContentBlockDeltaEvent
"""The RawContentBlockDeltaEvent type should be used instead"""
