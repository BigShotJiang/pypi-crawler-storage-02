# PyG2O

Python support for server-side scripts in [Gothic 2 Online](https://gothic-online.com.pl/).
 
**Documentation:** https://aurumvorxx.github.io/PyG2O/

Requirements:
- websockets

## Credits

#### Marcin - [NoNut](https://gitlab.com/g2o/modules/dependencies/nonut.git)
*Used as part of PyG2O module (for 1.3.4 legacy version)*

#### Patrix9999, Martinus-1453 - [Squirrel Module Template](https://gitlab.com/GothicMultiplayerTeam/modules/squirrel-template)
*PyG2O is based on this template (for 1.3.4 legacy version)*