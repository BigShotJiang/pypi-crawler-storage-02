class Foo[T: str]:
    x: T
