class Foo:
    "docstring"
