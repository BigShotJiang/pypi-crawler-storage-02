def f():
    try:
        a
    finally:
        return 42
