class F():
    x = 5; y: Optional['C'] = None

