async def foo():
    async with a as b:
        c
