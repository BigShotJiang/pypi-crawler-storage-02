lambda x: 0 if x else -1
