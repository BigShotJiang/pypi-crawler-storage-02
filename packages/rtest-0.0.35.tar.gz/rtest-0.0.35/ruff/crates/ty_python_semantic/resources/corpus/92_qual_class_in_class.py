class Bar:

    class Foo:
        pass
