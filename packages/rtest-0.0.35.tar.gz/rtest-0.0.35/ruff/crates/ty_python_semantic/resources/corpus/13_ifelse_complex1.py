if py2:
    a
else:
    b

if var:
    c
else:
    if py3:
        d
    else:
        e
