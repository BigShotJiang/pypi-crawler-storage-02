class C(Base):
    pass

class C(Base1, Base2):
    pass
