def foo():

    class Foo:
        pass
