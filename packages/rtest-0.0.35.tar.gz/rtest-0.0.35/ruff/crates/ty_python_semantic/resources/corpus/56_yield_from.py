def foo():
    yield from a
