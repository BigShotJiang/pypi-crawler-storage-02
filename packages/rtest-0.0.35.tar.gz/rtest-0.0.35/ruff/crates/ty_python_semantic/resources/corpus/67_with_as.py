with foo as bar:
    a
