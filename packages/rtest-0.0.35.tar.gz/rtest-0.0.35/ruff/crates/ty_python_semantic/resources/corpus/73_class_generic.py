class Foo[T]:
    x: T
