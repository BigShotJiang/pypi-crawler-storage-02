def foo(x: int, y, z: bytes, *args: 1, a: str, **kwargs: "sth") -> bool:
    pass
