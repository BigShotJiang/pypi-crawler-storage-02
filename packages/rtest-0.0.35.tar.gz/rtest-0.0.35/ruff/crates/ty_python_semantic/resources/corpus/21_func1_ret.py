def foo():
    return a
