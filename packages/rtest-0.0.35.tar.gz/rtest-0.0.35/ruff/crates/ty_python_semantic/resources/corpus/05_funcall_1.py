fun(a)
