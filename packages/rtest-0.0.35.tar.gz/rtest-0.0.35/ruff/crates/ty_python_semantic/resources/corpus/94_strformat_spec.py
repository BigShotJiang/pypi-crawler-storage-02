def f(name, args):
    return f"foo.{name:0}"
