async def foo():
    await a
