def f():
    int.new_attr: int
