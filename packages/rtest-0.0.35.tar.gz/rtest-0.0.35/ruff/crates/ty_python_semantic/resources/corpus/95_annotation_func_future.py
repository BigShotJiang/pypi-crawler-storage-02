from __future__ import annotations

def f(x: int):
    pass
