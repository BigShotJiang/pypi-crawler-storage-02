[x for x in s]
