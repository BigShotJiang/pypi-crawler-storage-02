def f():
    with foo as bar:
        a
