match 0:
    case 0:
        x = True
