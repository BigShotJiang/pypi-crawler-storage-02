def foo(a=None):
    pass
