try:
    a
except Exc:
    b
finally:
    c
