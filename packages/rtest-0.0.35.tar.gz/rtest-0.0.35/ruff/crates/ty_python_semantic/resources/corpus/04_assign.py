a = 1
b = "foo"
c = (d, e)
di = {f: 1, g: 2}
