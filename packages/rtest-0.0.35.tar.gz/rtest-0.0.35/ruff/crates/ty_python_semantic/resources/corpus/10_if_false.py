if 0:
    a

if False:
    b

if None:
    c

if "":
    d

if 0:
    e.f
    g.h()
    i.j = 1
    del k.l
    import m
    from n import o
    p = 1

def f():
    if 0:
        q = 1
        r.s = 1
        t
        import u
        v = u.w()
