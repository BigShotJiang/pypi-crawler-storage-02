if a:
    if b:
        if c:
            for x in y:
                pass
        else:
            pass
    else:
        pass
else:
    pass
foo()
