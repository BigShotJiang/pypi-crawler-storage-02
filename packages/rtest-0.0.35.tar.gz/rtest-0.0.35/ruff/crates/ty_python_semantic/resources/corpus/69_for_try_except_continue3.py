for a in seq:
    try:
        b
    except Exc as e:
        continue
