class Foo[**P = [int, str]]:
    x: P
