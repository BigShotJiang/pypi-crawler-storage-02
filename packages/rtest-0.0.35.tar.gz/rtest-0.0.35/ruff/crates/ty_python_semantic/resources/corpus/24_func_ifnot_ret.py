def foo(a):
    if not a:
        return b
    return c
