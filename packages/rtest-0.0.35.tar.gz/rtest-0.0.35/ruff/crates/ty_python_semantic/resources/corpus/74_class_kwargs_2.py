class Foo(int, x=42):
    pass
