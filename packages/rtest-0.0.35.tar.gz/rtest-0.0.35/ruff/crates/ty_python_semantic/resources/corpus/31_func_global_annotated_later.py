def foo():
    global g

g: int = 3
