# Sets

## Basic set

```py
reveal_type({1, 2})  # revealed: set[Unknown]
```
