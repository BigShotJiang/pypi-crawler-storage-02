from enum import Enum


class InputType(Enum):
    TXT = "txt"
    XLS = "xls"
