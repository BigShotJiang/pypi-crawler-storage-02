from enum import Enum

class ReportType(Enum):
	UNKNOWN = 0,
	PROGRESS = 1,
	ANNOUNCE = 2