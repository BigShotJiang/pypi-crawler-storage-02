# Youtube Autonomous Positioning Module

The way to position things in a scene.