"""Template for environment."""

from .main import get

__all__ = ["get"]
