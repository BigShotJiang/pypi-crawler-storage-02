"""
AI-Commiter - 인공지능을 활용한 Git 커밋 메시지 생성 도구
"""

__version__ = "0.1.5"
