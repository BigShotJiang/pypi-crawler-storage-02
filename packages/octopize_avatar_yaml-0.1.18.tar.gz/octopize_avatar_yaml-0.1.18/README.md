# Folder structure

Inspired by <https://blog.ionelmc.ro/2014/05/25/python-packaging/#the-structure%3E>
