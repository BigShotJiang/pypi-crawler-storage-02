""".. include:: ./doc.md"""  # noqa: D415
