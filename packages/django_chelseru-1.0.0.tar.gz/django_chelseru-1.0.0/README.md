# Django Chelseru

---

## Installation

```bash
pip install django-chelseru
```

---
-

## License

MIT License

Sobhan Bahman | Rashnu

