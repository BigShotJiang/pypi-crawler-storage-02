from django.apps import AppConfig


class DrfChelseruSmsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'drf_chelseru_sms'
