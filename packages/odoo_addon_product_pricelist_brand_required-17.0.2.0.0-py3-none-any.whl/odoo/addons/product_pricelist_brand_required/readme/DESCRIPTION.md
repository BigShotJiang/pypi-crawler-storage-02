Check if the product's brand matches any selected brand in
the pricelist item.
