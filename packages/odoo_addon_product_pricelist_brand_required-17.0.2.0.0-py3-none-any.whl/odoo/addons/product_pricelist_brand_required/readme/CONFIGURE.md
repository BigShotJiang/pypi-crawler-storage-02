To configure this module, you need to:

1. Create a Pricelist Item.
2. Add the product brands you want to include in the pricelist item.
