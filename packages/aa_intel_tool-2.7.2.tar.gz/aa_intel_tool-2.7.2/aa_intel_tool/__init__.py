"""
App init
"""

# Django
from django.utils.translation import gettext_lazy as _

__version__ = "2.7.2"
__title__ = _("Intel Parser")
