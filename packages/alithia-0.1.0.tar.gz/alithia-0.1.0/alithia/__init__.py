"""
Alithia Research Agent

A LangGraph-based agent system that replicates zotero-arxiv-daily functionality
using an agentic architecture with cogents.common.llm integration.
"""
