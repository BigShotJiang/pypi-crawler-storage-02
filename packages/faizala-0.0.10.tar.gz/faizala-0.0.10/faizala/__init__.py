def p_1a():
    print("""faizal loves allah""")
