# coding: UTF-8
import sys
bstack111_opy_ = sys.version_info [0] == 2
bstack11l11l_opy_ = 2048
bstack1llll1_opy_ = 7
def bstack1l1l1ll_opy_ (bstack1l1llll_opy_):
    global bstack11l1l11_opy_
    bstack1l11ll1_opy_ = ord (bstack1l1llll_opy_ [-1])
    bstack1l1l111_opy_ = bstack1l1llll_opy_ [:-1]
    bstack1111l11_opy_ = bstack1l11ll1_opy_ % len (bstack1l1l111_opy_)
    bstack11l11ll_opy_ = bstack1l1l111_opy_ [:bstack1111l11_opy_] + bstack1l1l111_opy_ [bstack1111l11_opy_:]
    if bstack111_opy_:
        bstack1lll1l1_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11l_opy_ - (bstack11111l_opy_ + bstack1l11ll1_opy_) % bstack1llll1_opy_) for bstack11111l_opy_, char in enumerate (bstack11l11ll_opy_)])
    else:
        bstack1lll1l1_opy_ = str () .join ([chr (ord (char) - bstack11l11l_opy_ - (bstack11111l_opy_ + bstack1l11ll1_opy_) % bstack1llll1_opy_) for bstack11111l_opy_, char in enumerate (bstack11l11ll_opy_)])
    return eval (bstack1lll1l1_opy_)
from typing import Dict, List, Any, Callable, Tuple, Union
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.bstack1lll11111ll_opy_ import bstack1lll11l11ll_opy_
from browserstack_sdk.sdk_cli.bstack1llll1lll1l_opy_ import (
    bstack1lllll1l1l1_opy_,
    bstack1llllllllll_opy_,
    bstack1lllllllll1_opy_,
)
from bstack_utils.helper import  bstack1l111l1l_opy_
from browserstack_sdk.sdk_cli.bstack1lll1l1ll11_opy_ import bstack1ll1lllllll_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1lll111l111_opy_, bstack1ll1ll111ll_opy_, bstack1lll1ll1ll1_opy_, bstack1ll1ll1l1ll_opy_
from typing import Tuple, Any
import threading
from bstack_utils.bstack1ll1l1ll1l_opy_ import bstack1ll1ll1lll_opy_
from browserstack_sdk.sdk_cli.bstack1lll111l1ll_opy_ import bstack1ll1lll1111_opy_
from bstack_utils.percy import bstack1lllllll1_opy_
from bstack_utils.percy_sdk import PercySDK
from bstack_utils.constants import *
import re
class bstack1llll111lll_opy_(bstack1lll11l11ll_opy_):
    def __init__(self, bstack1l1l1l1l1ll_opy_: Dict[str, str]):
        super().__init__()
        self.bstack1l1l1l1l1ll_opy_ = bstack1l1l1l1l1ll_opy_
        self.percy = bstack1lllllll1_opy_()
        self.bstack1lll1llll1_opy_ = bstack1ll1ll1lll_opy_()
        self.bstack1l1l1l1ll1l_opy_()
        bstack1ll1lllllll_opy_.bstack1ll1l11lll1_opy_((bstack1lllll1l1l1_opy_.bstack11111111l1_opy_, bstack1llllllllll_opy_.PRE), self.bstack1l1l1l1l1l1_opy_)
        TestFramework.bstack1ll1l11lll1_opy_((bstack1lll111l111_opy_.TEST, bstack1lll1ll1ll1_opy_.POST), self.bstack1ll11l11lll_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l1ll11lll1_opy_(self, instance: bstack1lllllllll1_opy_, driver: object):
        bstack1l1lll1ll11_opy_ = TestFramework.bstack1lllll1ll11_opy_(instance.context)
        for t in bstack1l1lll1ll11_opy_:
            bstack1l1ll1llll1_opy_ = TestFramework.bstack1llll1llll1_opy_(t, bstack1ll1lll1111_opy_.bstack1l1ll1lllll_opy_, [])
            if any(instance is d[1] for d in bstack1l1ll1llll1_opy_) or instance == driver:
                return t
    def bstack1l1l1l1l1l1_opy_(
        self,
        f: bstack1ll1lllllll_opy_,
        driver: object,
        exec: Tuple[bstack1lllllllll1_opy_, str],
        bstack111111111l_opy_: Tuple[bstack1lllll1l1l1_opy_, bstack1llllllllll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        try:
            instance, method_name = exec
            if not bstack1ll1lllllll_opy_.bstack1ll11lll11l_opy_(method_name):
                return
            platform_index = f.bstack1llll1llll1_opy_(instance, bstack1ll1lllllll_opy_.bstack1ll1l11l1ll_opy_, 0)
            bstack1l1l1llll11_opy_ = self.bstack1l1ll11lll1_opy_(instance, driver)
            bstack1l1l1l11lll_opy_ = TestFramework.bstack1llll1llll1_opy_(bstack1l1l1llll11_opy_, TestFramework.bstack1l1l1l111ll_opy_, None)
            if not bstack1l1l1l11lll_opy_:
                self.logger.debug(bstack1l1l1ll_opy_ (u"ࠥࡳࡳࡥࡰࡳࡧࡢࡩࡽ࡫ࡣࡶࡶࡨ࠾ࠥࡸࡥࡵࡷࡵࡲ࡮ࡴࡧࠡࡣࡶࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥ࡯ࡳࠡࡰࡲࡸࠥࡿࡥࡵࠢࡶࡸࡦࡸࡴࡦࡦࠥዚ"))
                return
            driver_command = f.bstack1ll11l111l1_opy_(*args)
            for command in bstack11l11l11_opy_:
                if command == driver_command:
                    self.bstack11ll111ll1_opy_(driver, platform_index)
            bstack1ll11ll11l_opy_ = self.percy.bstack11lll1l1_opy_()
            if driver_command in bstack11ll1l11l1_opy_[bstack1ll11ll11l_opy_]:
                self.bstack1lll1llll1_opy_.bstack1llll1111_opy_(bstack1l1l1l11lll_opy_, driver_command)
        except Exception as e:
            self.logger.error(bstack1l1l1ll_opy_ (u"ࠦࡴࡴ࡟ࡱࡴࡨࡣࡪࡾࡥࡤࡷࡷࡩ࠿ࠦࡥࡳࡴࡲࡶࠧዛ"), e)
    def bstack1ll11l11lll_opy_(
        self,
        f: TestFramework,
        instance: bstack1ll1ll111ll_opy_,
        bstack111111111l_opy_: Tuple[bstack1lll111l111_opy_, bstack1lll1ll1ll1_opy_],
        *args,
        **kwargs,
    ):
        from bstack_utils.bstack111ll111l_opy_ import bstack1lll11l111l_opy_
        bstack1l1ll1llll1_opy_ = f.bstack1llll1llll1_opy_(instance, bstack1ll1lll1111_opy_.bstack1l1ll1lllll_opy_, [])
        if not bstack1l1ll1llll1_opy_:
            self.logger.debug(bstack1l1l1ll_opy_ (u"ࠧࡵ࡮ࡠࡣࡩࡸࡪࡸ࡟ࡵࡧࡶࡸ࠿ࠦ࡮ࡰࠢࡧࡶ࡮ࡼࡥࡳࡵࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢዜ") + str(kwargs) + bstack1l1l1ll_opy_ (u"ࠨࠢዝ"))
            return
        if len(bstack1l1ll1llll1_opy_) > 1:
            self.logger.debug(bstack1l1l1ll_opy_ (u"ࠢࡰࡰࡢࡥ࡫ࡺࡥࡳࡡࡷࡩࡸࡺ࠺ࠡࡽ࡯ࡩࡳ࠮ࡤࡳ࡫ࡹࡩࡷࡥࡩ࡯ࡵࡷࡥࡳࡩࡥࡴࠫࢀࠤࡩࡸࡩࡷࡧࡵࡷࠥ࡬࡯ࡳࠢ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࡂࢁࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰࡿࠣࡥࡷ࡭ࡳ࠾ࡽࡤࡶ࡬ࡹࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࠤዞ") + str(kwargs) + bstack1l1l1ll_opy_ (u"ࠣࠤዟ"))
        bstack1l1l1l1111l_opy_, bstack1l1l1l11l1l_opy_ = bstack1l1ll1llll1_opy_[0]
        driver = bstack1l1l1l1111l_opy_()
        if not driver:
            self.logger.debug(bstack1l1l1ll_opy_ (u"ࠤࡲࡲࡤࡧࡦࡵࡧࡵࡣࡹ࡫ࡳࡵ࠼ࠣࡲࡴࠦࡤࡳ࡫ࡹࡩࡷࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥዠ") + str(kwargs) + bstack1l1l1ll_opy_ (u"ࠥࠦዡ"))
            return
        bstack1l1l1l1l111_opy_ = {
            TestFramework.bstack1ll11l11111_opy_: bstack1l1l1ll_opy_ (u"ࠦࡹ࡫ࡳࡵࠢࡱࡥࡲ࡫ࠢዢ"),
            TestFramework.bstack1ll11ll1lll_opy_: bstack1l1l1ll_opy_ (u"ࠧࡺࡥࡴࡶࠣࡹࡺ࡯ࡤࠣዣ"),
            TestFramework.bstack1l1l1l111ll_opy_: bstack1l1l1ll_opy_ (u"ࠨࡴࡦࡵࡷࠤࡷ࡫ࡲࡶࡰࠣࡲࡦࡳࡥࠣዤ")
        }
        bstack1l1l1l111l1_opy_ = { key: f.bstack1llll1llll1_opy_(instance, key) for key in bstack1l1l1l1l111_opy_ }
        bstack1l1l1l1l11l_opy_ = [key for key, value in bstack1l1l1l111l1_opy_.items() if not value]
        if bstack1l1l1l1l11l_opy_:
            for key in bstack1l1l1l1l11l_opy_:
                self.logger.debug(bstack1l1l1ll_opy_ (u"ࠢࡰࡰࡢࡥ࡫ࡺࡥࡳࡡࡷࡩࡸࡺ࠺ࠡ࡯࡬ࡷࡸ࡯࡮ࡨࠢࠥዥ") + str(key) + bstack1l1l1ll_opy_ (u"ࠣࠤዦ"))
            return
        platform_index = f.bstack1llll1llll1_opy_(instance, bstack1ll1lllllll_opy_.bstack1ll1l11l1ll_opy_, 0)
        if self.bstack1l1l1l1l1ll_opy_.percy_capture_mode == bstack1l1l1ll_opy_ (u"ࠤࡷࡩࡸࡺࡣࡢࡵࡨࠦዧ"):
            bstack11l1l11l_opy_ = bstack1l1l1l111l1_opy_.get(TestFramework.bstack1l1l1l111ll_opy_) + bstack1l1l1ll_opy_ (u"ࠥ࠱ࡹ࡫ࡳࡵࡥࡤࡷࡪࠨየ")
            bstack1ll11lll111_opy_ = bstack1lll11l111l_opy_.bstack1ll11ll1l1l_opy_(EVENTS.bstack1l1l1l1ll11_opy_.value)
            PercySDK.screenshot(
                driver,
                bstack11l1l11l_opy_,
                bstack1l1l1lll11_opy_=bstack1l1l1l111l1_opy_[TestFramework.bstack1ll11l11111_opy_],
                bstack1l1llll1ll_opy_=bstack1l1l1l111l1_opy_[TestFramework.bstack1ll11ll1lll_opy_],
                bstack1l1l1l1111_opy_=platform_index
            )
            bstack1lll11l111l_opy_.end(EVENTS.bstack1l1l1l1ll11_opy_.value, bstack1ll11lll111_opy_+bstack1l1l1ll_opy_ (u"ࠦ࠿ࡹࡴࡢࡴࡷࠦዩ"), bstack1ll11lll111_opy_+bstack1l1l1ll_opy_ (u"ࠧࡀࡥ࡯ࡦࠥዪ"), True, None, None, None, None, test_name=bstack11l1l11l_opy_)
    def bstack11ll111ll1_opy_(self, driver, platform_index):
        if self.bstack1lll1llll1_opy_.bstack1l1111l1ll_opy_() is True or self.bstack1lll1llll1_opy_.capturing() is True:
            return
        self.bstack1lll1llll1_opy_.bstack1ll11lll1_opy_()
        while not self.bstack1lll1llll1_opy_.bstack1l1111l1ll_opy_():
            bstack1l1l1l11lll_opy_ = self.bstack1lll1llll1_opy_.bstack11l1ll1ll_opy_()
            self.bstack1ll1111l11_opy_(driver, bstack1l1l1l11lll_opy_, platform_index)
        self.bstack1lll1llll1_opy_.bstack11lllllll1_opy_()
    def bstack1ll1111l11_opy_(self, driver, bstack111ll1lll_opy_, platform_index, test=None):
        from bstack_utils.bstack111ll111l_opy_ import bstack1lll11l111l_opy_
        bstack1ll11lll111_opy_ = bstack1lll11l111l_opy_.bstack1ll11ll1l1l_opy_(EVENTS.bstack1l11111l1_opy_.value)
        if test != None:
            bstack1l1l1lll11_opy_ = getattr(test, bstack1l1l1ll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫያ"), None)
            bstack1l1llll1ll_opy_ = getattr(test, bstack1l1l1ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬዬ"), None)
            PercySDK.screenshot(driver, bstack111ll1lll_opy_, bstack1l1l1lll11_opy_=bstack1l1l1lll11_opy_, bstack1l1llll1ll_opy_=bstack1l1llll1ll_opy_, bstack1l1l1l1111_opy_=platform_index)
        else:
            PercySDK.screenshot(driver, bstack111ll1lll_opy_)
        bstack1lll11l111l_opy_.end(EVENTS.bstack1l11111l1_opy_.value, bstack1ll11lll111_opy_+bstack1l1l1ll_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣይ"), bstack1ll11lll111_opy_+bstack1l1l1ll_opy_ (u"ࠤ࠽ࡩࡳࡪࠢዮ"), True, None, None, None, None, test_name=bstack111ll1lll_opy_)
    def bstack1l1l1l1ll1l_opy_(self):
        os.environ[bstack1l1l1ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡉࡗࡉ࡙ࠨዯ")] = str(self.bstack1l1l1l1l1ll_opy_.success)
        os.environ[bstack1l1l1ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡊࡘࡃ࡚ࡡࡆࡅࡕ࡚ࡕࡓࡇࡢࡑࡔࡊࡅࠨደ")] = str(self.bstack1l1l1l1l1ll_opy_.percy_capture_mode)
        self.percy.bstack1l1l1l11ll1_opy_(self.bstack1l1l1l1l1ll_opy_.is_percy_auto_enabled)
        self.percy.bstack1l1l1l11l11_opy_(self.bstack1l1l1l1l1ll_opy_.percy_build_id)