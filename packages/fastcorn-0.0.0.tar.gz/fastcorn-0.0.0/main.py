def main():
    print("Hello from fastcorn!")


if __name__ == "__main__":
    main()
