from .pipeline import CollectionRepository, rec_serialize
from .dynamic import create_object_from_string