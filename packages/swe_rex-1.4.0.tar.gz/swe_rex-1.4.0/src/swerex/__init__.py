__version__ = "1.4.0"


REMOTE_EXECUTABLE_NAME = "swerex-remote"
PACKAGE_NAME = "swe-rex"
