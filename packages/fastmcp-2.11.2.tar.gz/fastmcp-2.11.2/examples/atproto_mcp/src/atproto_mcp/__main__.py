from atproto_mcp.server import atproto_mcp


def main():
    atproto_mcp.run()


if __name__ == "__main__":
    main()
