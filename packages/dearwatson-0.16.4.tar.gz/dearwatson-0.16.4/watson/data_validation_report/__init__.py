"""Contains the code to prepare the urls for downloading the official missions data validation reports"""
