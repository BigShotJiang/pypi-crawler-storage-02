"""LangGuard - A Python library for language security."""

__version__ = "0.0.1"

from .core import hello, LangGuard

__all__ = ["hello", "LangGuard", "__version__"]