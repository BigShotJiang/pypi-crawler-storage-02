# Authors

Contributors to pyannotators_acronyms include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
