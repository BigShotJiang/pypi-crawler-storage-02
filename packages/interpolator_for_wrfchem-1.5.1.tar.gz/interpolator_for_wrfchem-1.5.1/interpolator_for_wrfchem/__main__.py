from interpolator_for_wrfchem import main

main()
