from . import cams

GLOBAL_MODELS = {
    "cams_eac4": cams.CAMS_EAC4,
    "cams_global_forecasts": cams.CAMS_Global_Forecasts,
}
