CANtact CAN Interface
=====================

Interface for CANtact devices from Linklayer Labs

.. autoclass:: can.interfaces.cantact.CantactBus
    :show-inheritance:
    :members:
