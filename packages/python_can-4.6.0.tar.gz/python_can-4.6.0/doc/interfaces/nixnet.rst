National Instruments NI-XNET
============================

This interface adds support for NI-XNET CAN controllers by `National Instruments`_.


.. note::

    NI-XNET only supports windows platforms.


Bus
---

.. autoclass:: can.interfaces.nixnet.NiXNETcanBus
   :show-inheritance:
   :member-order: bysource
   :members:


.. _National Instruments: http://www.ni.com/can/
