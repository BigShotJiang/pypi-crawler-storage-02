# Architecture





## How carbon.txt is designed

```{admonition} Info
Please see [the architecture page on the Green Web Foundation developer docs site](https://developers.thegreenwebfoundation.org/carbon-txt/explainer/carbon-txt-validator-architecture/) for an architectural overview of the project.

All of the images used are from [the publicly accessible google slide deck for Carbon.txt diagrams](https://docs.google.com/presentation/d/1ry6IvS7daZHN3bNLKckG0AjQOM1MtF7LSMWdZFY72Rs/edit#slide=id.g30475fbe3bd_0_220).

```
