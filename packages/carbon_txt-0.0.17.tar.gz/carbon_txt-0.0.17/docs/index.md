<!-- Carbon.txt Validator documentation master file, created by sphinx-quickstart
on Thu Oct 31 20:30:34 2024. You can adapt this file completely to your liking,
but it should at least contain the root `toctree` directive. -->

# Carbon.txt Validator documentation

```{toctree}
:maxdepth: 3
usage
installation
architecture
deployment
plugins
plugin_hooks
using_plugins
contributing
runbook
```
