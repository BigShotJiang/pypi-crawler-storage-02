TODO: Add

```
              <Filter>
                <Or xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">
                  <Or xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">
                    <Or xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">
                      <Equal>
                        <ColumnID>39</ColumnID>
                        <Value>131E0F45-0C2E-42F7-A02D-12E013CFF6B5</Value>
                      </Equal>
                      <Equal>
                        <ColumnID>37</ColumnID>
                        <Value>
                        </Value>
                      </Equal>
                    </Or>
                    <Equal>
                      <ColumnID>41</ColumnID>
                      <Value>71</Value>
                    </Equal>
                  </Or>
                  <Equal>
                    <ColumnID>0</ColumnID>
                    <Value>136</Value>
                  </Equal>
                </Or>
              </Filter>
```