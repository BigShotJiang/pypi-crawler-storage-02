from .linguistic_metadata import LinguisticMetadata

__all__ = ["LinguisticMetadata"]
