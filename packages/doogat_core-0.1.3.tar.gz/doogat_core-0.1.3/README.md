This is the core of Doogat ;)
