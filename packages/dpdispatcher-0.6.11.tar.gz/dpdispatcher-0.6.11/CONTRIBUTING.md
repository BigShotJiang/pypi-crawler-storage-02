## How to contribute

DPDispatcher welcomes every people (or organization) to use under the LGPL-3.0 License.

And Contributions are welcome and are greatly appreciated! Every little bit helps, and credit will always be given.

If you want to contribute to dpdispatcher, just open a issue, submiit a pull request , leave a comment on github discussion, or contact deepmodeling team.

Any forms of improvement are welcome.

- use, star or fork dpdispatcher
- improve the documents
- report or fix bugs
- request, discuss or implement features
