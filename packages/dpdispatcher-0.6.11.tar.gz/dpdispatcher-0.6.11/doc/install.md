# Install DPDispatcher

DPDispatcher can installed by `pip`:

```bash
pip install dpdispatcher
```

To add [Bohrium](https://bohrium.dp.tech/) support, execute

```bash
pip install dpdispatcher[bohrium]
```
