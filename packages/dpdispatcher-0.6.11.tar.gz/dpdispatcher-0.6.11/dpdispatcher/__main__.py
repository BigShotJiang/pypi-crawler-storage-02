"""Package dp entry point."""

from dpdispatcher.dpdisp import (
    main,
)

if __name__ == "__main__":
    main()
