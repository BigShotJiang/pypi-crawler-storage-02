"""Node library package."""
