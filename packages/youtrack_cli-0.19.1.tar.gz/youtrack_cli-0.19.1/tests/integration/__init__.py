"""Integration tests for YouTrack CLI."""
