"""
GwaniCLI - A command-line interface for accessing Quranic verses and translations.
"""

__version__ = "0.1.0"
__author__ = "B. Hantsi"
__email__ = "b.hantsi@example.com"
