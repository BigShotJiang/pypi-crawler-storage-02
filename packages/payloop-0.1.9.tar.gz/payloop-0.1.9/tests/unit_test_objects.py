class unit_test_x:
    def __init__(self):
        self.a = 1
        self.b = 2


class unit_test_y:
    def __init__(self):
        self.c = 3
        self.d = unit_test_x()
