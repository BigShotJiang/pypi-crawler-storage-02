def hello_world():
    print("Hello, World!")


# Call the function
hello_world()
