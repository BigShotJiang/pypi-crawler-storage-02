# Changelog

## v0.7.22
fix(typo): inserting message at the beggining of the user message

## v0.7.21
fix: appending tool execution suggestion to the last assistant message

## v0.7.20 

- Add tool execution results as proper parts in the user message
