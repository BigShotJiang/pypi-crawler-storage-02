class Feature:
    def execute(self):
        pass

