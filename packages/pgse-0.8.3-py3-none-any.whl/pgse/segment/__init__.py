from pgse.segment.segment_pool import SegmentPool as _SegmentPool

seg_pool = _SegmentPool()
