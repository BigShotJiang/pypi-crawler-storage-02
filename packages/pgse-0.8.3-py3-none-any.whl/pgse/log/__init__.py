from pgse.log.logger import Logger as _Logger

# Initialize the logger with a default name
logger = _Logger('default_log')
