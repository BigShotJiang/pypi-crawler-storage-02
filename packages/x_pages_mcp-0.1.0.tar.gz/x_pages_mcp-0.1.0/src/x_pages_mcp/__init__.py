"""X-Pages MCP Server for HTML deployment service."""

__version__ = "0.1.0"