def main():
    print("Hello from sdk!")


if __name__ == "__main__":
    main()
