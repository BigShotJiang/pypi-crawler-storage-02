# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 14:39:10 2016

@author: hrotzing
"""

ds_types = {'coordinate':0,
            'vector':1,
            'matrix':2,
            'box':3,
            'txt':10,
            'view':20,            
            } 

view_types =  {'1D':0,
               '1D-V':1,
               '2D':2,
               '3D':3,
               'table':4,
               'txt':5}