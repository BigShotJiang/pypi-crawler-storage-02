from mcp_server_baidu_maps import main

main()