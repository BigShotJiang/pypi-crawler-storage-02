enochecker_logs
===============

Simple parser to make exceptions in enochecker output readable.

Sample usage: `docker-compose logs -f | enochecker_logs`
