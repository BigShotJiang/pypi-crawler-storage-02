"""Deprecated: Filtering module moved to `pktai_tui.services.filtering`.

This shim remains temporarily to avoid breaking imports. Prefer importing from
`pktai_tui.services.filtering`.
"""

from pktai_tui.services.filtering import *  # re-export
