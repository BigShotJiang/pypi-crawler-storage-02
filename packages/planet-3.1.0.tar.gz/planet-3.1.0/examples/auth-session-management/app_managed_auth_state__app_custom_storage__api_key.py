# No example of this use case provided at this time.
# The use of M2M OAuth sessions is encouraged over the use of API keys.
