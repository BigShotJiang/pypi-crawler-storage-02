def main() -> None:
    print("Hello from li-mcp-demo!")
