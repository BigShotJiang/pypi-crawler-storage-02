# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause

import argparse
import os
import re
import textwrap
import typing as t

import httpx
import litellm
import urllib3

urllib3.disable_warnings()

from patchwise.patch_review.patch_review import PatchReview

DEFAULT_MODEL = "Pro"
DEFAULT_API_BASE = "https://api.openai.com/v1"


class AiReview(PatchReview):
    model: str = DEFAULT_MODEL
    api_base: str = DEFAULT_API_BASE

    def format_chat_response(self, text: str) -> str:
        """
        Line wraps the given text at 75 columns but skips commit tags.
        """

        def split_text_into_paragraphs(text: str) -> list[str]:
            """
            Splits the input text into paragraphs, treating each bullet
            point line as a separate paragraph.
            """
            lines = text.split("\n")
            paragraphs = []
            current = []
            bullet_pattern = re.compile(
                r"""
                ^\s*                              # Optional leading whitespace
                (
                    [*+\->]                       # Unordered bullet characters
                    |                             # OR
                    \d+[.)-]                      # Numbered bullets like 1. or 2)
                    |                             # OR
                    \d+(\.\d+)+                   # Decimal bullets like 1.1 or 1.2.3
                )
                \s*                               # At least one space after the bullet
            """,
                re.VERBOSE,
            )

            for line in lines:
                line_stripped = line.strip()
                if (
                    line_stripped == ""
                    or line_stripped == "```"
                    or line_stripped == "'''"
                    or line_stripped == '"""'
                    or bullet_pattern.match(line_stripped) is not None
                ):
                    if len(current) > 0:
                        paragraphs.append("\n".join(current))
                        current = []
                    paragraphs.append(line)
                else:
                    current.append(line)
            if len(current) > 0:
                paragraphs.append("\n".join(current))

            return paragraphs

        def is_commit_tag(text: str) -> bool:
            """
            Checks if the given text starts with a commit tag.
            The TAGS list includes tags from the Kernel documentation
            https://www.kernel.org/doc/html/latest/process/submitting-patches.html
            and additional tags like "Change-Id".
            """
            TAGS = {
                # Upstream tags
                "Acked-by:",
                "Cc:",
                "Closes:",
                "Co-developed-by:",
                "Fixes:",
                "From:",
                "Link:",
                "Reported-by:",
                "Reviewed-by:",
                "Signed-off-by:",
                "Suggested-by:",
                "Tested-by:",
                # Additional tags
                "(cherry picked from commit",
                "Change-Id",
                "Git-Commit:",
                "Git-repo",
                "Git-Repo:",
            }

            return any(text.startswith(tag) for tag in TAGS)

        def is_quote(text):
            return text.startswith(">")

        paragraphs = split_text_into_paragraphs(text)

        wrapped_paragraphs = [
            (
                textwrap.fill(
                    p,
                    width=75,
                    break_long_words=False,  # to preserve links
                )
                if not (is_commit_tag(p.strip()) or is_quote(p.strip()))
                else p
            )
            for p in paragraphs
        ]

        return "\n".join(wrapped_paragraphs)

    def provider_api_call(
        self, user_prompt: str, system_prompt: t.Optional[str] = None
    ) -> str:
        messages = [{"content": user_prompt, "role": "user"}]
        if system_prompt:
            messages.append({"content": system_prompt, "role": "system"})

        self.logger.debug(
            f"Making API call with model: {self.model}, api_base: {AiReview.api_base}"
        )

        response = litellm.completion(
            model=self.model,
            api_base=AiReview.api_base,
            messages=messages,
            stream=False,
        )

        return response.choices[0].message.content

    def setup(self):
        self.model = AiReview.model

        os.environ["OTEL_SDK_DISABLED"] = "true"

        litellm.client_session = httpx.Client(verify=False)

        self.diff = self.repo.git.diff(self.base_commit, self.commit).strip()
        if not self.diff:
            self.logger.error("Failed to retrieve diff.")

        self.commit_message = self.repo.commit(self.commit).message.rstrip()
        if not self.commit_message:
            self.logger.error("Failed to retrieve commit message.")


def add_ai_arguments(
    parser_or_group: argparse.ArgumentParser | argparse._ArgumentGroup,
):
    parser_or_group.add_argument(
        "--model",
        default=f"openai/{AiReview.model}",
        help="The AI model to use for review. (default: %(default)s)",
    )
    parser_or_group.add_argument(
        "--provider",
        default=DEFAULT_API_BASE,
        help="The base URL for the AI model API. (default: %(default)s)",
    )
    # parser_or_group.add_argument(
    #     "--review-threshold",
    #     type=float,
    #     default=0.5,
    #     help="The threshold for review confidence. (default: %(default)s)"
    # )


def apply_ai_args(args: argparse.Namespace) -> None:
    """
    Applies AI-related arguments to the AiReview class.
    This function is called after parsing command line arguments.
    """
    AiReview.model = args.model
    AiReview.api_base = args.provider
