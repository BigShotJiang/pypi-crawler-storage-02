from __future__ import annotations

from wexample_filestate.result.abstract_result import AbstractResult


class FileStateDryRunResult(AbstractResult):
    pass
