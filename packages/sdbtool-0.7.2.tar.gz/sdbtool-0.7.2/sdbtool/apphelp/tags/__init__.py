from .Win10 import Tags as Win10Tags, tag_id_to_string

__all__ = ["Win10Tags", "tag_id_to_string"]
