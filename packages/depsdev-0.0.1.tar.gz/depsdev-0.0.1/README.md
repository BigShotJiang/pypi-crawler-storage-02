# depsdev

[![PyPI - Version](https://img.shields.io/pypi/v/depsdev.svg)](https://pypi.org/project/depsdev)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/depsdev.svg)](https://pypi.org/project/depsdev)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/FlavioAmurrioCS/depsdev/main.svg)](https://results.pre-commit.ci/latest/github/FlavioAmurrioCS/depsdev/main)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install depsdev
```

## License

`depsdev` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
