APIS = {
    "ADD": {
        "METHOD": "embedchain.add",
        "OPERATION": "add",
    },
    "QUERY": {
        "METHOD": "embedchain.query",
        "OPERATION": "query",
    },
    "SEARCH": {
        "METHOD": "embedchain.search",
        "OPERATION": "search",
    },
}
