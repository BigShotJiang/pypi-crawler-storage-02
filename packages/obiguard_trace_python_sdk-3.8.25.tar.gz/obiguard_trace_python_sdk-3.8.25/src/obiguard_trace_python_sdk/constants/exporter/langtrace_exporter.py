LANGTRACE_REMOTE_URL = "https://app.langtrace.ai"
OBIGUARD_REMOTE_URL = "https://gateway.obiguard.ai"
LANGTRACE_SESSION_ID_HEADER = "x-langtrace-session-id"
