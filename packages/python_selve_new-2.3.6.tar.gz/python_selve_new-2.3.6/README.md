# python-selve-new
Python module for controlling Selve devices using an USB-RF-Gateway. Written completely new.
