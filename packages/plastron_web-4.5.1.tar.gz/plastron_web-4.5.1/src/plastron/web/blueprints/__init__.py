from .activitystream import blueprint as activitystream_blueprint
from .resources import blueprint as resources_blueprint
