#! /usr/bin/env bash

alias @plugin=bluer_plugin
