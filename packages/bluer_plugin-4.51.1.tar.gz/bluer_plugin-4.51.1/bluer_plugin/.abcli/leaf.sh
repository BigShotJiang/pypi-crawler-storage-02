#! /usr/bin/env bash

function bluer_plugin_leaf() {
    bluer_ai_log "bluer-plugin: leaf: 🌀"
}
