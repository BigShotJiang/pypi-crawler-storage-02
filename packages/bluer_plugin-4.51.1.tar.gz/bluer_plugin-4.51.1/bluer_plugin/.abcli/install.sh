#! /usr/bin/env bash

function bluer_ai_install_bluer_plugin() {
    :
}

# bluer_ai_install_module bluer_plugin 1.1.1
