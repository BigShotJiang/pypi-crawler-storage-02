# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.

class AlertingPolicyEnum(object):

    """Implementation of the 'AlertingPolicy' enum.

    TODO: type enum description here.

    Attributes:
        KSUCCESS: TODO: type description here.
        KFAILURE: TODO: type description here.
        KSLAVIOLATION: TODO: type description here.

    """

    KSUCCESS = 'kSuccess'

    KFAILURE = 'kFailure'

    KSLAVIOLATION = 'kSlaViolation'

