# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.

class ConsumerTypeGetTenantStatsEnum(object):

    """Implementation of the 'consumerType_GetTenantStats' enum.

    TODO: type enum description here.

    Attributes:
        KVIEWS: TODO: type description here.
        KPROTECTIONRUNS: TODO: type description here.
        KREPLICATIONRUNS: TODO: type description here.

    """

    KVIEWS = 'kViews'

    KPROTECTIONRUNS = 'kProtectionRuns'

    KREPLICATIONRUNS = 'kReplicationRuns'

