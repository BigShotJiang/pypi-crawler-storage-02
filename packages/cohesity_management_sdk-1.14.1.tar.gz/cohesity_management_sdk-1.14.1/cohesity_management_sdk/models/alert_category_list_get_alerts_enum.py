# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.

class AlertCategoryListGetAlertsEnum(object):

    """Implementation of the 'alertCategoryList_GetAlerts' enum.

    TODO: type enum description here.

    Attributes:

        KDISK: TODO: type description here.
        KNODE: TODO: type description here.
        KCLUSTER: TODO: type description here.
        KCHASSIS: TODO: type description here.
        KPOWERSUPPLY: TODO: type description here.
        KCPU: TODO: type description here.
        KMEMORY: TODO: type description here.
        KTEMPERATURE: TODO: type description here.
        KFAN: TODO: type description here.
        KNIC: TODO: type description here.
        KFIRMWARE: TODO: type description here.
        KNODEHEALTH: TODO: type description here.
        KOPERATINGSYSTEM: TODO: type description here.
        KDATAPATH: TODO: type description here.
        KMETADATA: TODO: type description here.
        KINDEXING: TODO: type description here.
        KHELIOS: TODO: type description here.
        KAPPMARKETPLACE: TODO: type description here.
        KLICENSE: TODO: type description here.
        KSECURITY: TODO: type description here.
        KUPGRADE: TODO: type description here.
        KCLUSTERMANAGEMENT: TODO: type description here.
        KAUDITLOG: TODO: type description here.
        KNETWORKING: TODO: type description here.
        KCONFIGURATION: TODO: type description here.
        KSTORAGEUSAGE: TODO: type description here.
        KFAULTTOLERANCE: TODO: type description here.
        KBACKUPRESTORE: TODO: type description here.
        KARCHIVALRESTORE: TODO: type description here.
        KREMOTEREPLICATION: TODO: type description here.
        KQUOTA: TODO: type description here.

    """
    KDISK = 'kDisk'

    KNODE = 'kNode'

    KCLUSTER = 'kCluster'

    KCHASSIS = 'kChassis'

    KPOWERSUPPLY = 'kPowerSupply'

    KCPU = 'kCPU'

    KMEMORY = 'kMemory'

    KTEMPERATURE = 'kTemperature'

    KFAN = 'kFan'

    KNIC = 'kNIC'

    KFIRMWARE = 'kFirmware'

    KNODEHEALTH = 'kNodeHealth'

    KOPERATINGSYSTEM = 'kOperatingSystem'

    KDATAPATH = 'kDataPath'

    KMETADATA = 'kMetadata'

    KINDEXING = 'kIndexing'

    KHELIOS = 'kHelios'

    KAPPMARKETPLACE = 'kAppMarketPlace'

    KLICENSE = 'kLicense'

    KSECURITY = 'kSecurity'

    KUPGRADE = 'kUpgrade'

    KCLUSTERMANAGEMENT = 'kClusterManagement'

    KAUDITLOG = 'kAuditLog'

    KNETWORKING = 'kNetworking'

    KCONFIGURATION = 'kConfiguration'

    KSTORAGEUSAGE = 'kStorageUsage'

    KFAULTTOLERANCE = 'kFaultTolerance'

    KBACKUPRESTORE = 'kBackupRestore'

    KARCHIVALRESTORE = 'kArchivalRestore'

    KREMOTEREPLICATION = 'kRemoteReplication'

    KQUOTA = 'kQuota'

