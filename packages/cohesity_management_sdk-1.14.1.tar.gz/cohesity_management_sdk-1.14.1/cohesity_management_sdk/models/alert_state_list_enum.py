# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.

class AlertStateListEnum(object):

    """Implementation of the 'alertStateList' enum.

    TODO: type enum description here.

    Attributes:
        KOPEN: TODO: type description here.
        KRESOLVED: TODO: type description here.
        KALERTSUPPRESSED: TODO: type description here.

    """

    KOPEN = 'kOpen'

    KRESOLVED = 'kResolved'

    KALERTSUPPRESSED = 'kAlertSuppressed'

