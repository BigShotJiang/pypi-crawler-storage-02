# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.

class AdAttributeFlagEnum(object):

    """Implementation of the 'AdAttributeFlag' enum.

    TODO: type enum description here.

    Attributes:
        KEQUAL: TODO: type description here.
        KNOTEQUAL: TODO: type description here.
        KNOTFOUND: TODO: type description here.
        KSYSTEM: TODO: type description here.
        KMULTIVALUE: TODO: type description here.

    """

    KEQUAL = 'kEqual'

    KNOTEQUAL = 'kNotEqual'

    KNOTFOUND = 'kNotFound'

    KSYSTEM = 'kSystem'

    KMULTIVALUE = 'kMultiValue'

