# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.

class ChangeEnum(object):

    """Implementation of the 'Change' enum.

    TODO: type enum description here.

    Attributes:
        KPROTECTIONJOBNAME: TODO: type description here.
        KPROTECTIONJOBDESCRIPTION: TODO: type description here.
        KPROTECTIONJOBSOURCES: TODO: type description here.

    """

    KPROTECTIONJOBNAME = 'kProtectionJobName'

    KPROTECTIONJOBDESCRIPTION = 'kProtectionJobDescription'

    KPROTECTIONJOBSOURCES = 'kProtectionJobSources'