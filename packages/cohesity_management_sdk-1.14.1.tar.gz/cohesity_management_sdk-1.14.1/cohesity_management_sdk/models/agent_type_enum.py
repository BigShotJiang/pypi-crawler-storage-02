# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.


class AgentTypeEnum(object):
    """Implementation of the 'agentType' enum.

    TODO: type enum description here.

    Attributes:
        KCPP: TODO: type description here.
        KJAVA: TODO: type description here.
        KGO: TODO: type description here.
        KLEGACY: TODO: type description here.

    """

    KCPP = "kCpp"

    KJAVA = "kJava"

    KGO = "kGo"

    KLEGACY = "kLegacy"
