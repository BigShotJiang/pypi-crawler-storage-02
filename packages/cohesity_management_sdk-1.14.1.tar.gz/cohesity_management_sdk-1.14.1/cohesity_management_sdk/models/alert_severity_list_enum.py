# -*- coding: utf-8 -*-
# Copyright 2024 Cohesity Inc.

class AlertSeverityListEnum(object):

    """Implementation of the 'alertSeverityList' enum.

    TODO: type enum description here.

    Attributes:
        KCRITICAL: TODO: type description here.
        KWARNING: TODO: type description here.
        KINFO: TODO: type description here.

    """

    KCRITICAL = 'kCritical'

    KWARNING = 'kWarning'

    KINFO = 'kInfo'

