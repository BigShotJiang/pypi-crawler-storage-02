# [Llama-3.1-405B-FP16](https://poe.com/Llama-3.1-405B-FP16){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 2070 points/message |
| Initial Points Cost | 2070 points |

**Last Checked:** 2025-08-05 23:30:05.326261


## Bot Information

**Creator:** @hyperbolic

**Description:** The Biggest and Best open-source AI model trained by Meta, beating GPT-4o across most benchmarks. This bot is in BF16 and with 128K context length.

**Extra:** Powered by a server managed by @hyperbolic. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Llama-3.1-405B-FP16`

**Object Type:** model

**Created:** 1724034411290

**Owned By:** poe

**Root:** Llama-3.1-405B-FP16
