# [Llama-3.1-70B-T](https://poe.com/Llama-3.1-70B-T){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 460 points/message |
| Initial Points Cost | 460 points |

**Last Checked:** 2025-08-05 23:30:47.975700


## Bot Information

**Creator:** @togetherai

**Description:** Llama 3.1 70B Instruct from Meta. Supports 128k tokens of context.

The points price is subject to change.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Llama-3.1-70B-T`

**Object Type:** model

**Created:** 1721748215163

**Owned By:** poe

**Root:** Llama-3.1-70B-T
