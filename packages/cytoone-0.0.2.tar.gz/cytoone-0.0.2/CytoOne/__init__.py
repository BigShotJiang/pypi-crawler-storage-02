"""
CytoOne

A unified probabilistic framework for CyTOF data
"""

from CytoOne.cytoone_class import cytoone