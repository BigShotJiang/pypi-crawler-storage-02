def main():
    print("Hello from containment-chamber!")


if __name__ == "__main__":
    main()