#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyMieSim import units

class BaseSource(units.UnitsValidation):
    pass