使用 `builder.py` 以编译 `.proto` 文件至 Python 代码。

在使用之前 请先在 `builder.py` 中修改 `PROTOC_PATH` 到你的 `protoc.py` 的路径。

`protoc.py` 由 `grpcio_tools` 库提供。