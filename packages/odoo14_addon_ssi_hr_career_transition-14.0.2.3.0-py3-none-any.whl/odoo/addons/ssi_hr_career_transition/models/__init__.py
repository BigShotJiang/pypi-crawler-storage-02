# Copyright 2023 OpenSynergy Indonesia
# Copyright 2023 PT. Simetri Sinergi Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    employee_career_transition,
    employee_career_transition_type,
    employee_career_transition_type_reason,
    hr_employee,
    res_company,
)
