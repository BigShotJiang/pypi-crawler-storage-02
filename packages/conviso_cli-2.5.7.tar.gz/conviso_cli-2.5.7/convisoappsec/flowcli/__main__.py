from .entrypoint import cli

if __name__ == '__main__':
    cli(prog_name="convisoappsec.flowcli")
