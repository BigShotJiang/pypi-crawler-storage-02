"""
MCP Text-to-Speech Server
"""

__version__ = "0.1.0"
