__version__ = "0.0.8"

from .main import *
from .mne_utils import *
from .utils import *
