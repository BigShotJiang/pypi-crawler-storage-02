"""Generated protobuf modules for A2A Registry."""

try:
    from . import a2a_pb2
    from . import registry_pb2
    from . import registry_pb2_grpc
    from . import a2a_pb2_grpc
except ImportError:
    pass

__all__ = ["a2a_pb2", "registry_pb2", "registry_pb2_grpc", "a2a_pb2_grpc"]
