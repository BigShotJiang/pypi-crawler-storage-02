"""Matrix-free linear algebra."""
