Spatial Join
============

The spatial_join module provides functions for performing spatial joins and aggregations on geospatial data.

.. automodule:: libadalina_core.spatial_join.query_builder
   :members:
   :undoc-members:
   :show-inheritance:
