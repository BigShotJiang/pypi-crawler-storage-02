from conan.tools.files.symlinks.symlinks import absolute_to_relative_symlinks, \
    remove_external_symlinks, remove_broken_symlinks, get_symlinks
