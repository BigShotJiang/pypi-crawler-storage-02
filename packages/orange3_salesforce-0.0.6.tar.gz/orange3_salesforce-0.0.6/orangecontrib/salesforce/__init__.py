"""
Orange3 Salesforce Add-on
=========================

This add-on provides widgets for interacting with Salesforce data.
"""

__version__ = "0.0.6"
