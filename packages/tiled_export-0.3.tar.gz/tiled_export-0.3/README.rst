===============================
tiled-export
===============================


.. image:: https://img.shields.io/pypi/v/tiled-export.svg
        :target: https://pypi.python.org/pypi/tiled-export


tiled-export

Documentation
-------------

Sphinx-generated documentation for this project can be found here:
https://spc-group.github.io/tiled-export/

Requirements
------------

Describe the project requirements (i.e. Python version, packages and how to install them)

Installation
------------

The following will download the package and load it into the python environment.

.. code-block:: bash

    git clone https://github.com/spc-group/tiled-export
    pip install -e tiled-export


Running the Tests
-----------------
::

  $ pip install -e .
  $ pytest -vv
