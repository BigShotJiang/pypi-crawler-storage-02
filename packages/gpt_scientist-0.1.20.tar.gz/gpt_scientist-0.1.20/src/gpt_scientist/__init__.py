"""Top-level package for GPT Scientist."""

__author__ = """Nadia Polikarpova"""
__email__ = 'nadia.polikarpova@gmail.com'
__version__ = '0.1.0'

from .gpt_scientist import Scientist
