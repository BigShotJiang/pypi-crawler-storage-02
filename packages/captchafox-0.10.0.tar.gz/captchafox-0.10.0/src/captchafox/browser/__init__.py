from .captchafox import Captchafox


__all__ = ["Captchafox"]
