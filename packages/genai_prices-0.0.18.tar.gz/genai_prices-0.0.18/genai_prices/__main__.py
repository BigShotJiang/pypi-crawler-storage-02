"""This means `python -m genai_prices` should run the CLI."""

from ._cli import cli

if __name__ == '__main__':
    cli()
