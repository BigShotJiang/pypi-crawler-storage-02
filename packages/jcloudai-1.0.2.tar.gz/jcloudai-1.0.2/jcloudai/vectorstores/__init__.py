"""
Vector stores to store data for training purpose
"""

from .vectorstore import VectorStore

__all__ = ["VectorStore"]
