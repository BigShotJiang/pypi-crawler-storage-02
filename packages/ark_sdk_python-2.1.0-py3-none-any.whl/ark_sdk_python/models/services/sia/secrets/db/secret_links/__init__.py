from typing import Union

from ark_sdk_python.models.services.sia.secrets.db.secret_links.ark_sia_db_pam_account_secret_link import ArkSIADBPAMAccountSecretLink

ArkSIADBSecretLinks = Union[ArkSIADBPAMAccountSecretLink]
