from .spectrum_utils import generate_synthetic_spectrum
from .plotting import plot_spectrum

