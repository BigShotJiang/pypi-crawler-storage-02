__version__ = "0.7.1"


def version():
    return __version__


# find and replace these if building another package off this one!
pypi_name = "exoatlas"
import_name = "exoatlas"
