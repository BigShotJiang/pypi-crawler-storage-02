jpl-ssd-planets.txt = data from  https://ssd.jpl.nasa.gov/planets/phys_par.html, retrieved 4 September 2024, which Zach (slightly annoyingly) reformatted into an easier CSV. (Mass in 1e24 kg.)

jpl-ssd-dwarf-planets.txt = data from  https://ssd.jpl.nasa.gov/planets/phys_par.html, retrieved 4 September 2024, which Zach (slightly annoyingly) reformatted into an easier CSV. (Mass in 1e18 kg.)

jpl-ssd-moons.txt = data from https://ssd.jpl.nasa.gov/sats/phys_par/, retrieved 4 September 2024, which Zach reformatted slightly into a CSV

solarsystem.txt = a file Zach typed up ages ago, from the back of a book and/or from the NASA planetary data pages. It's fine, but a wee bit sketchy, and provenance of some numbers is a little uncertain

