This directory contains pre-defined populations and/or data files that we may want to be able to call from within the package. This should probably only be the Solar System, but perhaps some reasonable simulated or calculated reference populations might make sense too.


skewnormal_parameters_for_interpolating_mode.ecsv = a file for estimating the parameters of a skewnormal distribution from upper and lower uncertainties, based off Sebastian Pineda et al. (2021)
