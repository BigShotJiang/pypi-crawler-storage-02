This models were generated as in Seager et al. (2007), but the exact values were point-clicked out of the Charbonneau et al. (2009) GJ1214b discovery paper.
