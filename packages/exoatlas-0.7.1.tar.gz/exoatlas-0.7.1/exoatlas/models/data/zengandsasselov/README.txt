These models are from Zeng and Sasselov (2013), extracted from the Excel tables provided with that paper.
