# sima_cli/__version__.py
__version__ = "0.0.26"
