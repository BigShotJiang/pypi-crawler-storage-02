# About

This work is a design proposal for an `httpx` 1.0 release.

---

## Sponsorship

We are currently seeking forward-looking investment that recognises the value of the infrastructure development on it's own merit. Sponsorships may be [made through GitHub](https://github.com/encode).

We do not offer equity, placements, or endorsments.

## License

The rights of the author have been asserted.

---

<p align="center"><i><a href="https://www.encode.io/httpnext">home</a><i></p>
