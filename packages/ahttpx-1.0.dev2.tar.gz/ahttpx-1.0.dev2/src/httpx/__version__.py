__title__ = "httpx"
__version__ = "1.0.dev2"