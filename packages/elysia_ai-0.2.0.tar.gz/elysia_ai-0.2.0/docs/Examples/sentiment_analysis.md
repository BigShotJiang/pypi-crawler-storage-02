# Example: Sentiment Analysis on Retrieved Data

Coming soon.
<!-- 
## Setup

Let's add an extra tool to Elysia that analyses the retrieved data and outputs sentiment scores on the objects. This modifies the default Elysia setup, so to start with, let's import Elysia, configure the LLMs and set up a tree with the default initialisation.

```python
from elysia import Tree, settings
settings.default_models()
tree = Tree(branch_initialisation = "one_branch")
```

## Custom Tool

Let's use an LLM for sentiment analysis by creating a custom tool Elysia can use. Be sure to follow the (custom tool guide)[Customising/advanced_tool_construction.md] for more information.

In this case, we want to provide a comprehensive 
```python

```
 -->

