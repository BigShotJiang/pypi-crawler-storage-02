# pytest-xhtml

pytest-xhtml is a plugin for `pytest <http://pytest.org>`_ that generates a HTML report for test results.

## Develop

```bash
$ git clone https://github.com/seldomQA/pytest-xhtml.git
$ cd pytest-xhtml
$ pip install .

$ npm run build:css
```
