Maintenance Request Repair

- Go to Repair → create a new one
- Go to Maintenance → Maintenance Requests
- Edit a Maintenance Request
- Select a Repair Order on the list
