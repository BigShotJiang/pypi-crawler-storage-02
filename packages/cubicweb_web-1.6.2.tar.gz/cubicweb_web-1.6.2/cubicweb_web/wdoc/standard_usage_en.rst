First of all, you can use this site as any web site by clicking on the
different links. The Logo on the top left of this page will lead you
to a start page from which you will be able to navigate to all the
data hosted on this site.

The bookmarks box on the left hand side provides some useful
shortcuts.

Most text is indexed and you can search all the content by typing
words in the search box.
