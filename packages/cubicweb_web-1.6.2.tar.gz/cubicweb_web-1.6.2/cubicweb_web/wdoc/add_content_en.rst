Add some entities
-----------------
As manager, you can access to entity creation forms by using the `site management`_ page.

.. _`site management`: ../manage

As regular user, the index page or the action box may propose some links to create entities according to the context.


