The personal information describing a User can be modified using the edit form
of the user. You can access it through the dropdown-menu under the link on the
top-right of the window, labeled by your login. In this menu, click the
"profile" link to go to this form.

Each user can as well customize the site appearance using the "user's
preferences" link in this menu. This will show you a form to configure which
boxes are displayed, in which order, etc...

.. image:: images/userprefs
