.. -*- coding: utf-8 -*-

.. winclude:: search_sample_queries

Vous pouvez également taper des requêtes complexes en utilisant le langage de
requête RQL_, base sur laquelle ce site est construit.

Vous pouvez préfixer votre recherche des mots clés suivants pour indiquer le
type de recherche que vous désirez :

* `rql` : requête RQL
* `text` : recherche plein texte

.. _RQL: tut_rql

