Latest changes
--------------

* table of `all latest changes`_

Links below is providing useful RQL query example.

.. _all latest changes: ../view?rql=Any+M%2CX+WHERE+X+modification_date+M+ORDERBY+M+DESC+LIMIT+30
