.. -*- coding: utf-8 -*-

Dernières modifications
-----------------------

* la table des `derniers changements`_ fournit un exemple d'utilisation de RQL
  pour récupérer les derniers changements ayant eu lieu sur ce site.

.. _`derniers changements`: ../view?rql=Any+M%2CX+WHERE+X+modification_date+M+ORDERBY+M+DESC+LIMIT+30

