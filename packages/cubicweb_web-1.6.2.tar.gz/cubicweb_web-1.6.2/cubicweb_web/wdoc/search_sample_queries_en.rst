Experiment with the search bar. Try queries like "card sometextualcontent" or
"card wikiid index" or "345".
