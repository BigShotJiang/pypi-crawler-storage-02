Ajouter des entités
-------------------
Pour un administrateur, la création des objets est toujours possible directement dans la `page de gestion de site`_.

.. _`page de gestion de site`: ../manage

Pour les utilisateurs, la page principale ou la boîte d'action des entités vous permettra la création de nouveaux contenus.
L'intérêt de la dernière méthode est de faciliter l'édition de la relation entre les objets.


