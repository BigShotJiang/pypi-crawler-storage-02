boîte des actions
    boîte visible dans la colonne de gauche en haut à gauche de l'écran. Cette boîte vous permet d'accéder aux actions disponibles pour cette entité. L'entrée la plus utilisée est `modifier`.

module d'édition des relations entre objets
    module HTML qui permet l'édition des relations entre objects.

objet
    Tout élement qui peut être créé au sein de l'application
    Exemple: projet, ticket, étiquette, utilisateur, ...

relation
    Une relation est un lien 'intelligent' et bi-directionnel entre 2 objets de l'application. Il est intelligent au sens où il porte un sens et permet de définir des comportements dynamiques à l'application et ajouter une logique métier au contenu.


