
.. role:: raw-html(raw)
   :format: html

RSS driven
----------

RSS is a pretty useful technology that can be widely used on this
site. Any set of data can be presented as RSS. You can then plug in
an RSS reader into that and follow the site activity. For example :

:raw-html:`<p><a class="reference"
href="../view?vid=rss&amp;rql=Any+X%2CM+WHERE+X+modification_date+M+ORDERBY+M+DESC+LIMIT+30"><img
alt="rss" src="../data/rss.png"> latest changes</a></p>`
