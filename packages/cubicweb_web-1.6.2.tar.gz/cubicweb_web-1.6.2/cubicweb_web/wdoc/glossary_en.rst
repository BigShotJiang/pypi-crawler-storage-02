action box
    Area visible in the upper left column. You have a list of available actions on the entity. The most frequently used entry is `modify`.

object
    All element created in the application
    Example: project, ticket, user, ...

relation editing module
    HTML widget that let you define new relations amongst objects.

relation
    It's a kind of 'smart' link between 2 objets of the application. It has a specific sense that determine dynamic behaviour and add a new logic of the content.


