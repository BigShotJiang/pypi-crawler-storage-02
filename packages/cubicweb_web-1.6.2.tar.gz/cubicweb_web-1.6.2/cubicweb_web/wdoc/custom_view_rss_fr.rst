.. -*- coding: utf-8 -*-

.. role:: raw-html(raw)
   :format: html

Flux RSS
--------

RSS est une technologie très utile qui peut être utilisée de manière très
générique sur ce site. N'importe quel résultat de requête peut-être présenté
comme un flux RSS. Vous pouvez donc ensuite connecter ce flux à n'importe quel
lecteur RSS pour suivre l'activité de ce cite. Par exemple pour avoir les
derniers changements sous forme de flux RSS:

:raw-html:`<p><a class="reference"
href="../view?vid=rss&amp;rql=Any+X%2CM+WHERE+X+modification_date+M+ORDERBY+M+DESC+LIMIT+30"><img
alt="rss" src="../data/rss.png"> latest changes</img></a></p>`

