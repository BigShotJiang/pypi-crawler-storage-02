.. -*- coding: utf-8 -*-

Plusieurs éléments par défaut sont proposés pour faciliter la navigation:

- le logo en haut de la page vous ramène à la page d'accueil du site qui fournit un point de départ pour la navigation vers les données de ce site.

- la boîte de signet à gauche fournit des raccourcis utiles.

- la notion d'étiquette vous permet de marquer de manière subjective les pages à se souvenir

- le contenu textuel des entités est indexé et vous pouvez donc rechercher des entités en tapant simplement les mots à rechercher dans la boîte de recherche.
