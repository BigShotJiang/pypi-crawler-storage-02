
.. winclude:: search_sample_queries

You can as well type complex queries using the RQL_ query language,
used every where to build dynamic pages of this site.

You can use one of the following prefixes to specify which kind of search you
want:

* `rql` : RQL query
* `text` : full text search

.. _RQL: tut_rql
