Schema of the data
------------------

First take a look at the data schema_ then try to remember that you are browsing
through a heap of data by applying stylesheets to the results of queries. This
site is not a content management system with items placed in folders. It is an
interface to a database which applies a view to retreived data.

.. _schema: ../schema
