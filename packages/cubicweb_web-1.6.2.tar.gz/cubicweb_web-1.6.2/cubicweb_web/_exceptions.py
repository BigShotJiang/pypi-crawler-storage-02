# pylint: disable=W0401,W0614
# copyright 2003-2024 LOGILAB S.A. (Paris, FRANCE), all rights reserved.
# contact https://www.logilab.fr/ -- mailto:contact@logilab.fr
#
# This file is part of CubicWeb.
#
# CubicWeb is free software: you can redistribute it and/or modify it under the
# terms of the GNU Lesser General Public License as published by the Free
# Software Foundation, either version 2.1 of the License, or (at your option)
# any later version.
#
# CubicWeb is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more
# details.
#
# You should have received a copy of the GNU Lesser General Public License along
# with CubicWeb.  If not, see <https://www.gnu.org/licenses/>.
"""exceptions used in the core of the CubicWeb web application"""

import http.client as http_client

from cubicweb import CubicWebException, Unauthorized  # noqa # backward compatibility
from cubicweb.utils import json_dumps


class DirectResponse(Exception):
    """Used to supply a twitted HTTP Response directly"""

    def __init__(self, response):
        self.response = response


class InvalidSession(CubicWebException):
    """raised when a session id is found but associated session is not found or
    invalid"""


# Publish related exception


class PublishException(CubicWebException):
    """base class for publishing related exception"""

    def __init__(self, *args, **kwargs):
        self.status = kwargs.pop("status", http_client.OK)
        super().__init__(*args, **kwargs)


class Redirect(PublishException):
    """raised to redirect the http request"""

    def __init__(self, location, status=http_client.SEE_OTHER):
        super().__init__(status=status)
        self.location = location


class LogOut(PublishException):
    """raised to ask for deauthentication of a logged in user"""

    def __init__(self, url=None):
        super().__init__()
        self.url = url


class RequestError(PublishException):
    """raised when a request can't be served because of a bad input"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("status", http_client.BAD_REQUEST)
        super().__init__(*args, **kwargs)


class RemoteCallFailed(RequestError):
    """raised when a json remote call fails"""

    def __init__(self, reason="", status=http_client.INTERNAL_SERVER_ERROR):
        super().__init__(reason, status=status)
        self.reason = reason

    def dumps(self):
        return json_dumps({"reason": self.reason})


class NotFound(RequestError):
    """raised when something was not found. In most case,
    a 404 error should be returned"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("status", http_client.NOT_FOUND)
        super().__init__(*args, **kwargs)


class StatusResponse(PublishException):
    def __init__(self, status, content=""):
        super().__init__(status=status)
        self.content = content

    def __repr__(self):
        return f"{self.__class__.__name__}({self.status!r}, {self.content!r})"


# Publish related error


class NothingToEdit(RequestError):
    """raised when an edit request doesn't specify any eid to edit"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("status", http_client.BAD_REQUEST)
        super().__init__(*args, **kwargs)


class ProcessFormError(RequestError):
    """raised when posted data can't be processed by the corresponding field"""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("status", http_client.BAD_REQUEST)
        super().__init__(*args, **kwargs)
