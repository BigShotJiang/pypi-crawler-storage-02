FCKConfig.AutoDetectLanguage = false;

FCKConfig.ToolbarSets["Default"] = [
  ["Bold", "Italic", "Underline"],
  ["OrderedList", "UnorderedList"],
  ["Link"],
  ["Table"],
];
// 'Flash','Select','Textarea','Checkbox','Radio','TextField','HiddenField','ImageButton','Button','Form',
FCKConfig.ContextMenu = [
  "Generic",
  "Link",
  "Anchor",
  "Image",
  "BulletedList",
  "NumberedList",
  "Table",
];

FCKConfig.LinkUpload = false;
FCKConfig.LinkBrowser = false;
FCKConfig.ImageUpload = false;
FCKConfig.ImageBrowser = false;
FCKConfig.FlashUpload = false;
FCKConfig.FlashBrowser = false;
