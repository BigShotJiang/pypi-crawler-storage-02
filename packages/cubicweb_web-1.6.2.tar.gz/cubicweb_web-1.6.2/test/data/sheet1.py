bgcolor = "#000000"
stylesheets = ["%s/cubicweb.css" % datadir_url]
logo = "%s/logo.png" % datadir_url
lazy = lazystr("%(bgcolor)s")
