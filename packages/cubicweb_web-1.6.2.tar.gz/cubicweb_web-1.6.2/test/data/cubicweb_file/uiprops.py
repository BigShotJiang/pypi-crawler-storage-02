FILE_ICON = data("file.png")  # noqa: F821
