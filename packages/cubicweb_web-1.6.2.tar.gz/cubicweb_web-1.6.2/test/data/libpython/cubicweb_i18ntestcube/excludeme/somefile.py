from cubicweb import _

_("ignore-me")
