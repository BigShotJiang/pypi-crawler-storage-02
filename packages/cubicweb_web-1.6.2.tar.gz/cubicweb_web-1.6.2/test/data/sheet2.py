fontcolor = "black"
bgcolor = "#FFFFFF"
stylesheets = sheet["stylesheets"] + ["%s/mycube.css" % datadir_url]
