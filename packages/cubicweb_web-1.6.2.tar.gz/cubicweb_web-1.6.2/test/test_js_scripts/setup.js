window.pageid = "TESTTESTTESTTESTTEST";
window.BASE_URL = "";
window.$ = window.jQuery = require("../../cubicweb_web/data/jquery.js");

require("../../cubicweb_web/data/cubicweb.js");
require("../../cubicweb_web/data/cubicweb.htmlhelpers.js");
require("../../cubicweb_web/data/cubicweb.python.js");
require("../../cubicweb_web/data/cubicweb.compat.js");
require("../../cubicweb_web/data/cubicweb.ajax.js");
