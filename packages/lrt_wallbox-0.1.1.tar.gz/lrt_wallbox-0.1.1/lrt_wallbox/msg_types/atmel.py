from dataclasses import dataclass


@dataclass
class AtmelErrorGetResponse:
    error: int
