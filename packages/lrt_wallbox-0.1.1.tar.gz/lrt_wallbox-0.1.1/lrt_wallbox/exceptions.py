class WallboxError(Exception):
    pass
