"""Address exception."""


class AddressException(Exception):
    """An address exception."""
