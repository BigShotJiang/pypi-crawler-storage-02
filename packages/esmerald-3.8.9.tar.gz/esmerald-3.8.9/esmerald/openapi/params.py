from pydantic.fields import FieldInfo


class ResponseParam(FieldInfo): ...
