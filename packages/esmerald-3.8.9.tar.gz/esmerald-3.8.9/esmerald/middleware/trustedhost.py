from lilya.middleware.trustedhost import TrustedHostMiddleware  # noqa

__all__ = ["TrustedHostMiddleware"]
