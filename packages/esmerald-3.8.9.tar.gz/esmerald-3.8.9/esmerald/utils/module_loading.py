from monkay import load as import_string  # noqa
