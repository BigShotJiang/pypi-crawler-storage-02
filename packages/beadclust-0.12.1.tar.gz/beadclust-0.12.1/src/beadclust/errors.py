class BeadFinderError(Exception):
    pass
