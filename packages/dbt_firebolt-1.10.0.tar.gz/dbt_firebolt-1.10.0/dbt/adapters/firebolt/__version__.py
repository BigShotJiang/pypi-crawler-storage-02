from dbt.adapters.firebolt import __version__

version = __version__
