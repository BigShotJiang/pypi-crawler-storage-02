"""Configuration module for lu77U-MobileSec"""
