"""
lu77U-MobileSec - The Only Mobile Security Tool Which You Need

A comprehensive mobile security analysis tool with beautiful CLI interface.
"""

__version__ = "0.0.1"
__author__ = "sam-mg"
__email__ = "sammgharish@gmail.com"

from .core.app import MobileSecApp

__all__ = ["MobileSecApp"]
