"""UI components for lu77U-MobileSec"""
