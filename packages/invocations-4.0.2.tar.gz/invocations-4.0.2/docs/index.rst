===========
Invocations
===========

.. include:: ../README.rst


Contents
========

.. toctree::
    :glob:

    changelog

API/task docs
=============

.. toctree::
    :glob:

    api/*
