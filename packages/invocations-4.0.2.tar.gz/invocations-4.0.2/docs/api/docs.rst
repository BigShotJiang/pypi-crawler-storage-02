========
``docs``
========

.. automodule:: invocations.docs
