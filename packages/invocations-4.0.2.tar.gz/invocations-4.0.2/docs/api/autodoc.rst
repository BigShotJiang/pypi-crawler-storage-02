===========
``autodoc``
===========

.. automodule:: invocations.autodoc
