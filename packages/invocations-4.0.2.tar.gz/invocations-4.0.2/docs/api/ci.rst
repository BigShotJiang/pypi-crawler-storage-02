======
``ci``
======

.. automodule:: invocations.ci
