.. Dummy index file so nearby changelogs can load
