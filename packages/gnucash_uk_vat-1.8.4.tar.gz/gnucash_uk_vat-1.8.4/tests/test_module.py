
def test_module_import():
    import gnucash_uk_vat

