from .vimania_uri_rs import *

__doc__ = vimania_uri_rs.__doc__
if hasattr(vimania_uri_rs, "__all__"):
    __all__ = vimania_uri_rs.__all__