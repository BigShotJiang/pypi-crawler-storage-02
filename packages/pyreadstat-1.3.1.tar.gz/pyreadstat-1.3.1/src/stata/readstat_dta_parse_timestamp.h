
readstat_error_t dta_parse_timestamp(const char *data, size_t len, struct tm *timestamp,
        readstat_error_handler error_handler, void *user_ctx);
