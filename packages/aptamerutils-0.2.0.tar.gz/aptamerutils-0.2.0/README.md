# aptamerutils
A simple Python package for short nucleic acid sequences (for example, aptamers) arrangement, sorting, clustering. 


![figure](example/results/save.png)
