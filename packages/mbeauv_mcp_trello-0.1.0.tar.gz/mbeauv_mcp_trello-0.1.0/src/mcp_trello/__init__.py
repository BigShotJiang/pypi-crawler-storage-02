"""MCP Trello Extension - A Model Context Protocol extension for Trello integration."""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .trello_client import TrelloClient

__all__ = ["TrelloClient"] 