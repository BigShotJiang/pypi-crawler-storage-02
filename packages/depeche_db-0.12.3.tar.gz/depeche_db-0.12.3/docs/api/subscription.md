::: depeche_db.SubscriptionFactory
---
::: depeche_db.Subscription
---
::: depeche_db.CallMiddleware
    options:
      show_signature_annotations: false
---
::: depeche_db.SubscriptionErrorHandler
    options:
      show_signature_annotations: true
---
::: depeche_db.ErrorAction
---
::: depeche_db.ExitSubscriptionErrorHandler
---
::: depeche_db.LogAndIgnoreSubscriptionErrorHandler
---
::: depeche_db.SubscriptionMessageHandler
---
::: depeche_db.SubscriptionRunner
---
::: depeche_db.BatchedAckSubscriptionRunner
---
::: depeche_db.LockProvider
    options:
      show_signature_annotations: true
---
::: depeche_db.SubscriptionStateProvider
    options:
      show_signature_annotations: true
---
::: depeche_db.SubscriptionStartPoint
---
::: depeche_db.StartAtNextMessage
---
::: depeche_db.StartAtPointInTime
---
