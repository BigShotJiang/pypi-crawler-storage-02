::: depeche_db.MessageNotFound
---
::: depeche_db.OptimisticConcurrencyError
