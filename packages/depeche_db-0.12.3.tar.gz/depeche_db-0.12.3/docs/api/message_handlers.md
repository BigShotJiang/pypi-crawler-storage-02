::: depeche_db.MessageHandlerRegisterProtocol
---
::: depeche_db.MessageHandlerRegister
---
::: depeche_db.MessageHandler
