from brepmatching.pyfemtet_scripts.main import Predictor

__all__ = ['Predictor']
