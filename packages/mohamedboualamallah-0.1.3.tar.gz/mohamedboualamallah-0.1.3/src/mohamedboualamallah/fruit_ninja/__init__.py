# This file initializes the my_app module. It can be used to define what is exported when the module is imported.

from mohamedboualamallah.fruit_ninja.main import main

__all__ = [
    "main",
]