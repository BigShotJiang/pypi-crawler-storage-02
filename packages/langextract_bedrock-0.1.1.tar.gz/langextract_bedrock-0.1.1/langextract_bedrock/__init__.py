"""LangExtract provider plugin for Bedrock."""

from langextract_bedrock.provider import BedrockLanguageModel

__all__ = ['BedrockLanguageModel']
__version__ = "0.1.0"
