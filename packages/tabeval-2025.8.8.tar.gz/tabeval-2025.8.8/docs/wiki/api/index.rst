API Reference
=============

This section provides detailed API documentation for all TabEval components.

Core Modules
------------

.. toctree::
   :maxdepth: 2

   metrics