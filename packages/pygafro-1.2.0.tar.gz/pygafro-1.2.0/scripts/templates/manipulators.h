typedef pygafro::Manipulator<double, DOF> Manipulator_DOF;
