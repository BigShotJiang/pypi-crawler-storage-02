#
# SPDX-FileCopyrightText: Copyright © 2025 Idiap Research Institute <contact@idiap.ch>
#
# SPDX-FileContributor: Philip Abbet <philip.abbet@idiap.ch>
#
# SPDX-License-Identifier: MPL-2.0
#
# This file was auto-generated from C++ files in gafro 1.0
scalar, scalar: scalar
scalar, e1: e1
scalar, e2: e2
scalar, e3: e3
scalar, ei: ei
scalar, e0: e0
scalar, e23: e23
scalar, e13: e13
scalar, e12: e12
scalar, e1i: e1i
scalar, e2i: e2i
scalar, e3i: e3i
scalar, e01: e01
scalar, e02: e02
scalar, e03: e03
scalar, e0i: e0i
scalar, e123: e123
scalar, e12i: e12i
scalar, e13i: e13i
scalar, e23i: e23i
scalar, e012: e012
scalar, e013: e013
scalar, e023: e023
scalar, e01i: e01i
scalar, e02i: e02i
scalar, e03i: e03i
scalar, e123i: e123i
scalar, e0123: e0123
scalar, e012i: e012i
scalar, e023i: e023i
scalar, e013i: e013i
scalar, e0123i: e0123i
e1, scalar: e1
e1, e1: scalar
e1, e2: e12
e1, e3: e13
e1, ei: e1i
e1, e0: e01
e1, e23: e123
e1, e13: e3
e1, e12: e2
e1, e1i: ei
e1, e2i: e12i
e1, e3i: e13i
e1, e01: e0
e1, e02: e012
e1, e03: e013
e1, e0i: e01i
e1, e123: e23
e1, e12i: e2i
e1, e13i: e3i
e1, e23i: e123i
e1, e012: e02
e1, e013: e03
e1, e023: e0123
e1, e01i: e0i
e1, e02i: e012i
e1, e03i: e013i
e1, e123i: e23i
e1, e0123: e023
e1, e012i: e02i
e1, e023i: e0123i
e1, e013i: e03i
e1, e0123i: e023i
e2, scalar: e2
e2, e1: e12
e2, e2: scalar
e2, e3: e23
e2, ei: e2i
e2, e0: e02
e2, e23: e3
e2, e13: e123
e2, e12: e1
e2, e1i: e12i
e2, e2i: ei
e2, e3i: e23i
e2, e01: e012
e2, e02: e0
e2, e03: e023
e2, e0i: e02i
e2, e123: e13
e2, e12i: e1i
e2, e13i: e123i
e2, e23i: e3i
e2, e012: e01
e2, e013: e0123
e2, e023: e03
e2, e01i: e012i
e2, e02i: e0i
e2, e03i: e023i
e2, e123i: e13i
e2, e0123: e013
e2, e012i: e01i
e2, e023i: e03i
e2, e013i: e0123i
e2, e0123i: e013i
e3, scalar: e3
e3, e1: e13
e3, e2: e23
e3, e3: scalar
e3, ei: e3i
e3, e0: e03
e3, e23: e2
e3, e13: e1
e3, e12: e123
e3, e1i: e13i
e3, e2i: e23i
e3, e3i: ei
e3, e01: e013
e3, e02: e023
e3, e03: e0
e3, e0i: e03i
e3, e123: e12
e3, e12i: e123i
e3, e13i: e1i
e3, e23i: e2i
e3, e012: e0123
e3, e013: e01
e3, e023: e02
e3, e01i: e013i
e3, e02i: e023i
e3, e03i: e0i
e3, e123i: e12i
e3, e0123: e012
e3, e012i: e0123i
e3, e023i: e02i
e3, e013i: e01i
e3, e0123i: e012i
ei, scalar: ei
ei, e1: e1i
ei, e2: e2i
ei, e3: e3i
ei, ei: 
ei, e0: scalar, e0i
ei, e23: e23i
ei, e13: e13i
ei, e12: e12i
ei, e1i: 
ei, e2i: 
ei, e3i: 
ei, e01: e1, e01i
ei, e02: e2, e02i
ei, e03: e3, e03i
ei, e0i: ei
ei, e123: e123i
ei, e12i: 
ei, e13i: 
ei, e23i: 
ei, e012: e12, e012i
ei, e013: e13, e013i
ei, e023: e23, e023i
ei, e01i: e1i
ei, e02i: e2i
ei, e03i: e3i
ei, e123i: 
ei, e0123: e123, e0123i
ei, e012i: e12i
ei, e023i: e23i
ei, e013i: e13i
ei, e0123i: e123i
e0, scalar: e0
e0, e1: e01
e0, e2: e02
e0, e3: e03
e0, ei: scalar, e0i
e0, e0: 
e0, e23: e023
e0, e13: e013
e0, e12: e012
e0, e1i: e1, e01i
e0, e2i: e2, e02i
e0, e3i: e3, e03i
e0, e01: 
e0, e02: 
e0, e03: 
e0, e0i: e0
e0, e123: e0123
e0, e12i: e12, e012i
e0, e13i: e13, e013i
e0, e23i: e23, e023i
e0, e012: 
e0, e013: 
e0, e023: 
e0, e01i: e01
e0, e02i: e02
e0, e03i: e03
e0, e123i: e123, e0123i
e0, e0123: 
e0, e012i: e012
e0, e023i: e023
e0, e013i: e013
e0, e0123i: e0123
e23, scalar: e23
e23, e1: e123
e23, e2: e3
e23, e3: e2
e23, ei: e23i
e23, e0: e023
e23, e23: scalar
e23, e13: e12
e23, e12: e13
e23, e1i: e123i
e23, e2i: e3i
e23, e3i: e2i
e23, e01: e0123
e23, e02: e03
e23, e03: e02
e23, e0i: e023i
e23, e123: e1
e23, e12i: e13i
e23, e13i: e12i
e23, e23i: ei
e23, e012: e013
e23, e013: e012
e23, e023: e0
e23, e01i: e0123i
e23, e02i: e03i
e23, e03i: e02i
e23, e123i: e1i
e23, e0123: e01
e23, e012i: e013i
e23, e023i: e0i
e23, e013i: e012i
e23, e0123i: e01i
e13, scalar: e13
e13, e1: e3
e13, e2: e123
e13, e3: e1
e13, ei: e13i
e13, e0: e013
e13, e23: e12
e13, e13: scalar
e13, e12: e23
e13, e1i: e3i
e13, e2i: e123i
e13, e3i: e1i
e13, e01: e03
e13, e02: e0123
e13, e03: e01
e13, e0i: e013i
e13, e123: e2
e13, e12i: e23i
e13, e13i: ei
e13, e23i: e12i
e13, e012: e023
e13, e013: e0
e13, e023: e012
e13, e01i: e03i
e13, e02i: e0123i
e13, e03i: e01i
e13, e123i: e2i
e13, e0123: e02
e13, e012i: e023i
e13, e023i: e012i
e13, e013i: e0i
e13, e0123i: e02i
e12, scalar: e12
e12, e1: e2
e12, e2: e1
e12, e3: e123
e12, ei: e12i
e12, e0: e012
e12, e23: e13
e12, e13: e23
e12, e12: scalar
e12, e1i: e2i
e12, e2i: e1i
e12, e3i: e123i
e12, e01: e02
e12, e02: e01
e12, e03: e0123
e12, e0i: e012i
e12, e123: e3
e12, e12i: ei
e12, e13i: e23i
e12, e23i: e13i
e12, e012: e0
e12, e013: e023
e12, e023: e013
e12, e01i: e02i
e12, e02i: e01i
e12, e03i: e0123i
e12, e123i: e3i
e12, e0123: e03
e12, e012i: e0i
e12, e023i: e013i
e12, e013i: e023i
e12, e0123i: e03i
e1i, scalar: e1i
e1i, e1: ei
e1i, e2: e12i
e1i, e3: e13i
e1i, ei: 
e1i, e0: e1, e01i
e1i, e23: e123i
e1i, e13: e3i
e1i, e12: e2i
e1i, e1i: 
e1i, e2i: 
e1i, e3i: 
e1i, e01: scalar, e0i
e1i, e02: e12, e012i
e1i, e03: e13, e013i
e1i, e0i: e1i
e1i, e123: e23i
e1i, e12i: 
e1i, e13i: 
e1i, e23i: 
e1i, e012: e2, e02i
e1i, e013: e3, e03i
e1i, e023: e123, e0123i
e1i, e01i: ei
e1i, e02i: e12i
e1i, e03i: e13i
e1i, e123i: 
e1i, e0123: e23, e023i
e1i, e012i: e2i
e1i, e023i: e123i
e1i, e013i: e3i
e1i, e0123i: e23i
e2i, scalar: e2i
e2i, e1: e12i
e2i, e2: ei
e2i, e3: e23i
e2i, ei: 
e2i, e0: e2, e02i
e2i, e23: e3i
e2i, e13: e123i
e2i, e12: e1i
e2i, e1i: 
e2i, e2i: 
e2i, e3i: 
e2i, e01: e12, e012i
e2i, e02: scalar, e0i
e2i, e03: e23, e023i
e2i, e0i: e2i
e2i, e123: e13i
e2i, e12i: 
e2i, e13i: 
e2i, e23i: 
e2i, e012: e1, e01i
e2i, e013: e123, e0123i
e2i, e023: e3, e03i
e2i, e01i: e12i
e2i, e02i: ei
e2i, e03i: e23i
e2i, e123i: 
e2i, e0123: e13, e013i
e2i, e012i: e1i
e2i, e023i: e3i
e2i, e013i: e123i
e2i, e0123i: e13i
e3i, scalar: e3i
e3i, e1: e13i
e3i, e2: e23i
e3i, e3: ei
e3i, ei: 
e3i, e0: e3, e03i
e3i, e23: e2i
e3i, e13: e1i
e3i, e12: e123i
e3i, e1i: 
e3i, e2i: 
e3i, e3i: 
e3i, e01: e13, e013i
e3i, e02: e23, e023i
e3i, e03: scalar, e0i
e3i, e0i: e3i
e3i, e123: e12i
e3i, e12i: 
e3i, e13i: 
e3i, e23i: 
e3i, e012: e123, e0123i
e3i, e013: e1, e01i
e3i, e023: e2, e02i
e3i, e01i: e13i
e3i, e02i: e23i
e3i, e03i: ei
e3i, e123i: 
e3i, e0123: e12, e012i
e3i, e012i: e123i
e3i, e023i: e2i
e3i, e013i: e1i
e3i, e0123i: e12i
e01, scalar: e01
e01, e1: e0
e01, e2: e012
e01, e3: e013
e01, ei: e1, e01i
e01, e0: 
e01, e23: e0123
e01, e13: e03
e01, e12: e02
e01, e1i: scalar, e0i
e01, e2i: e12, e012i
e01, e3i: e13, e013i
e01, e01: 
e01, e02: 
e01, e03: 
e01, e0i: e01
e01, e123: e023
e01, e12i: e2, e02i
e01, e13i: e3, e03i
e01, e23i: e123, e0123i
e01, e012: 
e01, e013: 
e01, e023: 
e01, e01i: e0
e01, e02i: e012
e01, e03i: e013
e01, e123i: e23, e023i
e01, e0123: 
e01, e012i: e02
e01, e023i: e0123
e01, e013i: e03
e01, e0123i: e023
e02, scalar: e02
e02, e1: e012
e02, e2: e0
e02, e3: e023
e02, ei: e2, e02i
e02, e0: 
e02, e23: e03
e02, e13: e0123
e02, e12: e01
e02, e1i: e12, e012i
e02, e2i: scalar, e0i
e02, e3i: e23, e023i
e02, e01: 
e02, e02: 
e02, e03: 
e02, e0i: e02
e02, e123: e013
e02, e12i: e1, e01i
e02, e13i: e123, e0123i
e02, e23i: e3, e03i
e02, e012: 
e02, e013: 
e02, e023: 
e02, e01i: e012
e02, e02i: e0
e02, e03i: e023
e02, e123i: e13, e013i
e02, e0123: 
e02, e012i: e01
e02, e023i: e03
e02, e013i: e0123
e02, e0123i: e013
e03, scalar: e03
e03, e1: e013
e03, e2: e023
e03, e3: e0
e03, ei: e3, e03i
e03, e0: 
e03, e23: e02
e03, e13: e01
e03, e12: e0123
e03, e1i: e13, e013i
e03, e2i: e23, e023i
e03, e3i: scalar, e0i
e03, e01: 
e03, e02: 
e03, e03: 
e03, e0i: e03
e03, e123: e012
e03, e12i: e123, e0123i
e03, e13i: e1, e01i
e03, e23i: e2, e02i
e03, e012: 
e03, e013: 
e03, e023: 
e03, e01i: e013
e03, e02i: e023
e03, e03i: e0
e03, e123i: e12, e012i
e03, e0123: 
e03, e012i: e0123
e03, e023i: e02
e03, e013i: e01
e03, e0123i: e012
e0i, scalar: e0i
e0i, e1: e01i
e0i, e2: e02i
e0i, e3: e03i
e0i, ei: ei
e0i, e0: e0
e0i, e23: e023i
e0i, e13: e013i
e0i, e12: e012i
e0i, e1i: e1i
e0i, e2i: e2i
e0i, e3i: e3i
e0i, e01: e01
e0i, e02: e02
e0i, e03: e03
e0i, e0i: scalar
e0i, e123: e0123i
e0i, e12i: e12i
e0i, e13i: e13i
e0i, e23i: e23i
e0i, e012: e012
e0i, e013: e013
e0i, e023: e023
e0i, e01i: e1
e0i, e02i: e2
e0i, e03i: e3
e0i, e123i: e123i
e0i, e0123: e0123
e0i, e012i: e12
e0i, e023i: e23
e0i, e013i: e13
e0i, e0123i: e123
e123, scalar: e123
e123, e1: e23
e123, e2: e13
e123, e3: e12
e123, ei: e123i
e123, e0: e0123
e123, e23: e1
e123, e13: e2
e123, e12: e3
e123, e1i: e23i
e123, e2i: e13i
e123, e3i: e12i
e123, e01: e023
e123, e02: e013
e123, e03: e012
e123, e0i: e0123i
e123, e123: scalar
e123, e12i: e3i
e123, e13i: e2i
e123, e23i: e1i
e123, e012: e03
e123, e013: e02
e123, e023: e01
e123, e01i: e023i
e123, e02i: e013i
e123, e03i: e012i
e123, e123i: ei
e123, e0123: e0
e123, e012i: e03i
e123, e023i: e01i
e123, e013i: e02i
e123, e0123i: e0i
e12i, scalar: e12i
e12i, e1: e2i
e12i, e2: e1i
e12i, e3: e123i
e12i, ei: 
e12i, e0: e12, e012i
e12i, e23: e13i
e12i, e13: e23i
e12i, e12: ei
e12i, e1i: 
e12i, e2i: 
e12i, e3i: 
e12i, e01: e2, e02i
e12i, e02: e1, e01i
e12i, e03: e123, e0123i
e12i, e0i: e12i
e12i, e123: e3i
e12i, e12i: 
e12i, e13i: 
e12i, e23i: 
e12i, e012: scalar, e0i
e12i, e013: e23, e023i
e12i, e023: e13, e013i
e12i, e01i: e2i
e12i, e02i: e1i
e12i, e03i: e123i
e12i, e123i: 
e12i, e0123: e3, e03i
e12i, e012i: ei
e12i, e023i: e13i
e12i, e013i: e23i
e12i, e0123i: e3i
e13i, scalar: e13i
e13i, e1: e3i
e13i, e2: e123i
e13i, e3: e1i
e13i, ei: 
e13i, e0: e13, e013i
e13i, e23: e12i
e13i, e13: ei
e13i, e12: e23i
e13i, e1i: 
e13i, e2i: 
e13i, e3i: 
e13i, e01: e3, e03i
e13i, e02: e123, e0123i
e13i, e03: e1, e01i
e13i, e0i: e13i
e13i, e123: e2i
e13i, e12i: 
e13i, e13i: 
e13i, e23i: 
e13i, e012: e23, e023i
e13i, e013: scalar, e0i
e13i, e023: e12, e012i
e13i, e01i: e3i
e13i, e02i: e123i
e13i, e03i: e1i
e13i, e123i: 
e13i, e0123: e2, e02i
e13i, e012i: e23i
e13i, e023i: e12i
e13i, e013i: ei
e13i, e0123i: e2i
e23i, scalar: e23i
e23i, e1: e123i
e23i, e2: e3i
e23i, e3: e2i
e23i, ei: 
e23i, e0: e23, e023i
e23i, e23: ei
e23i, e13: e12i
e23i, e12: e13i
e23i, e1i: 
e23i, e2i: 
e23i, e3i: 
e23i, e01: e123, e0123i
e23i, e02: e3, e03i
e23i, e03: e2, e02i
e23i, e0i: e23i
e23i, e123: e1i
e23i, e12i: 
e23i, e13i: 
e23i, e23i: 
e23i, e012: e13, e013i
e23i, e013: e12, e012i
e23i, e023: scalar, e0i
e23i, e01i: e123i
e23i, e02i: e3i
e23i, e03i: e2i
e23i, e123i: 
e23i, e0123: e1, e01i
e23i, e012i: e13i
e23i, e023i: ei
e23i, e013i: e12i
e23i, e0123i: e1i
e012, scalar: e012
e012, e1: e02
e012, e2: e01
e012, e3: e0123
e012, ei: e12, e012i
e012, e0: 
e012, e23: e013
e012, e13: e023
e012, e12: e0
e012, e1i: e2, e02i
e012, e2i: e1, e01i
e012, e3i: e123, e0123i
e012, e01: 
e012, e02: 
e012, e03: 
e012, e0i: e012
e012, e123: e03
e012, e12i: scalar, e0i
e012, e13i: e23, e023i
e012, e23i: e13, e013i
e012, e012: 
e012, e013: 
e012, e023: 
e012, e01i: e02
e012, e02i: e01
e012, e03i: e0123
e012, e123i: e3, e03i
e012, e0123: 
e012, e012i: e0
e012, e023i: e013
e012, e013i: e023
e012, e0123i: e03
e013, scalar: e013
e013, e1: e03
e013, e2: e0123
e013, e3: e01
e013, ei: e13, e013i
e013, e0: 
e013, e23: e012
e013, e13: e0
e013, e12: e023
e013, e1i: e3, e03i
e013, e2i: e123, e0123i
e013, e3i: e1, e01i
e013, e01: 
e013, e02: 
e013, e03: 
e013, e0i: e013
e013, e123: e02
e013, e12i: e23, e023i
e013, e13i: scalar, e0i
e013, e23i: e12, e012i
e013, e012: 
e013, e013: 
e013, e023: 
e013, e01i: e03
e013, e02i: e0123
e013, e03i: e01
e013, e123i: e2, e02i
e013, e0123: 
e013, e012i: e023
e013, e023i: e012
e013, e013i: e0
e013, e0123i: e02
e023, scalar: e023
e023, e1: e0123
e023, e2: e03
e023, e3: e02
e023, ei: e23, e023i
e023, e0: 
e023, e23: e0
e023, e13: e012
e023, e12: e013
e023, e1i: e123, e0123i
e023, e2i: e3, e03i
e023, e3i: e2, e02i
e023, e01: 
e023, e02: 
e023, e03: 
e023, e0i: e023
e023, e123: e01
e023, e12i: e13, e013i
e023, e13i: e12, e012i
e023, e23i: scalar, e0i
e023, e012: 
e023, e013: 
e023, e023: 
e023, e01i: e0123
e023, e02i: e03
e023, e03i: e02
e023, e123i: e1, e01i
e023, e0123: 
e023, e012i: e013
e023, e023i: e0
e023, e013i: e012
e023, e0123i: e01
e01i, scalar: e01i
e01i, e1: e0i
e01i, e2: e012i
e01i, e3: e013i
e01i, ei: e1i
e01i, e0: e01
e01i, e23: e0123i
e01i, e13: e03i
e01i, e12: e02i
e01i, e1i: ei
e01i, e2i: e12i
e01i, e3i: e13i
e01i, e01: e0
e01i, e02: e012
e01i, e03: e013
e01i, e0i: e1
e01i, e123: e023i
e01i, e12i: e2i
e01i, e13i: e3i
e01i, e23i: e123i
e01i, e012: e02
e01i, e013: e03
e01i, e023: e0123
e01i, e01i: scalar
e01i, e02i: e12
e01i, e03i: e13
e01i, e123i: e23i
e01i, e0123: e023
e01i, e012i: e2
e01i, e023i: e123
e01i, e013i: e3
e01i, e0123i: e23
e02i, scalar: e02i
e02i, e1: e012i
e02i, e2: e0i
e02i, e3: e023i
e02i, ei: e2i
e02i, e0: e02
e02i, e23: e03i
e02i, e13: e0123i
e02i, e12: e01i
e02i, e1i: e12i
e02i, e2i: ei
e02i, e3i: e23i
e02i, e01: e012
e02i, e02: e0
e02i, e03: e023
e02i, e0i: e2
e02i, e123: e013i
e02i, e12i: e1i
e02i, e13i: e123i
e02i, e23i: e3i
e02i, e012: e01
e02i, e013: e0123
e02i, e023: e03
e02i, e01i: e12
e02i, e02i: scalar
e02i, e03i: e23
e02i, e123i: e13i
e02i, e0123: e013
e02i, e012i: e1
e02i, e023i: e3
e02i, e013i: e123
e02i, e0123i: e13
e03i, scalar: e03i
e03i, e1: e013i
e03i, e2: e023i
e03i, e3: e0i
e03i, ei: e3i
e03i, e0: e03
e03i, e23: e02i
e03i, e13: e01i
e03i, e12: e0123i
e03i, e1i: e13i
e03i, e2i: e23i
e03i, e3i: ei
e03i, e01: e013
e03i, e02: e023
e03i, e03: e0
e03i, e0i: e3
e03i, e123: e012i
e03i, e12i: e123i
e03i, e13i: e1i
e03i, e23i: e2i
e03i, e012: e0123
e03i, e013: e01
e03i, e023: e02
e03i, e01i: e13
e03i, e02i: e23
e03i, e03i: scalar
e03i, e123i: e12i
e03i, e0123: e012
e03i, e012i: e123
e03i, e023i: e2
e03i, e013i: e1
e03i, e0123i: e12
e123i, scalar: e123i
e123i, e1: e23i
e123i, e2: e13i
e123i, e3: e12i
e123i, ei: 
e123i, e0: e123, e0123i
e123i, e23: e1i
e123i, e13: e2i
e123i, e12: e3i
e123i, e1i: 
e123i, e2i: 
e123i, e3i: 
e123i, e01: e23, e023i
e123i, e02: e13, e013i
e123i, e03: e12, e012i
e123i, e0i: e123i
e123i, e123: ei
e123i, e12i: 
e123i, e13i: 
e123i, e23i: 
e123i, e012: e3, e03i
e123i, e013: e2, e02i
e123i, e023: e1, e01i
e123i, e01i: e23i
e123i, e02i: e13i
e123i, e03i: e12i
e123i, e123i: 
e123i, e0123: scalar, e0i
e123i, e012i: e3i
e123i, e023i: e1i
e123i, e013i: e2i
e123i, e0123i: ei
e0123, scalar: e0123
e0123, e1: e023
e0123, e2: e013
e0123, e3: e012
e0123, ei: e123, e0123i
e0123, e0: 
e0123, e23: e01
e0123, e13: e02
e0123, e12: e03
e0123, e1i: e23, e023i
e0123, e2i: e13, e013i
e0123, e3i: e12, e012i
e0123, e01: 
e0123, e02: 
e0123, e03: 
e0123, e0i: e0123
e0123, e123: e0
e0123, e12i: e3, e03i
e0123, e13i: e2, e02i
e0123, e23i: e1, e01i
e0123, e012: 
e0123, e013: 
e0123, e023: 
e0123, e01i: e023
e0123, e02i: e013
e0123, e03i: e012
e0123, e123i: scalar, e0i
e0123, e0123: 
e0123, e012i: e03
e0123, e023i: e01
e0123, e013i: e02
e0123, e0123i: e0
e012i, scalar: e012i
e012i, e1: e02i
e012i, e2: e01i
e012i, e3: e0123i
e012i, ei: e12i
e012i, e0: e012
e012i, e23: e013i
e012i, e13: e023i
e012i, e12: e0i
e012i, e1i: e2i
e012i, e2i: e1i
e012i, e3i: e123i
e012i, e01: e02
e012i, e02: e01
e012i, e03: e0123
e012i, e0i: e12
e012i, e123: e03i
e012i, e12i: ei
e012i, e13i: e23i
e012i, e23i: e13i
e012i, e012: e0
e012i, e013: e023
e012i, e023: e013
e012i, e01i: e2
e012i, e02i: e1
e012i, e03i: e123
e012i, e123i: e3i
e012i, e0123: e03
e012i, e012i: scalar
e012i, e023i: e13
e012i, e013i: e23
e012i, e0123i: e3
e023i, scalar: e023i
e023i, e1: e0123i
e023i, e2: e03i
e023i, e3: e02i
e023i, ei: e23i
e023i, e0: e023
e023i, e23: e0i
e023i, e13: e012i
e023i, e12: e013i
e023i, e1i: e123i
e023i, e2i: e3i
e023i, e3i: e2i
e023i, e01: e0123
e023i, e02: e03
e023i, e03: e02
e023i, e0i: e23
e023i, e123: e01i
e023i, e12i: e13i
e023i, e13i: e12i
e023i, e23i: ei
e023i, e012: e013
e023i, e013: e012
e023i, e023: e0
e023i, e01i: e123
e023i, e02i: e3
e023i, e03i: e2
e023i, e123i: e1i
e023i, e0123: e01
e023i, e012i: e13
e023i, e023i: scalar
e023i, e013i: e12
e023i, e0123i: e1
e013i, scalar: e013i
e013i, e1: e03i
e013i, e2: e0123i
e013i, e3: e01i
e013i, ei: e13i
e013i, e0: e013
e013i, e23: e012i
e013i, e13: e0i
e013i, e12: e023i
e013i, e1i: e3i
e013i, e2i: e123i
e013i, e3i: e1i
e013i, e01: e03
e013i, e02: e0123
e013i, e03: e01
e013i, e0i: e13
e013i, e123: e02i
e013i, e12i: e23i
e013i, e13i: ei
e013i, e23i: e12i
e013i, e012: e023
e013i, e013: e0
e013i, e023: e012
e013i, e01i: e3
e013i, e02i: e123
e013i, e03i: e1
e013i, e123i: e2i
e013i, e0123: e02
e013i, e012i: e23
e013i, e023i: e12
e013i, e013i: scalar
e013i, e0123i: e2
e0123i, scalar: e0123i
e0123i, e1: e023i
e0123i, e2: e013i
e0123i, e3: e012i
e0123i, ei: e123i
e0123i, e0: e0123
e0123i, e23: e01i
e0123i, e13: e02i
e0123i, e12: e03i
e0123i, e1i: e23i
e0123i, e2i: e13i
e0123i, e3i: e12i
e0123i, e01: e023
e0123i, e02: e013
e0123i, e03: e012
e0123i, e0i: e123
e0123i, e123: e0i
e0123i, e12i: e3i
e0123i, e13i: e2i
e0123i, e23i: e1i
e0123i, e012: e03
e0123i, e013: e02
e0123i, e023: e01
e0123i, e01i: e23
e0123i, e02i: e13
e0123i, e03i: e12
e0123i, e123i: ei
e0123i, e0123: e0
e0123i, e012i: e3
e0123i, e023i: e1
e0123i, e013i: e2
e0123i, e0123i: scalar
