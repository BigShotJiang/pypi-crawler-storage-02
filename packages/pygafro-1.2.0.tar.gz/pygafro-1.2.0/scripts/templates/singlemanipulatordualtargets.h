typedef gafro::SingleManipulatorDualTarget<double, DOF, gafro::TOOL, gafro::TARGET> SingleManipulatorDualTarget_DOF_TOOL_TARGET;
