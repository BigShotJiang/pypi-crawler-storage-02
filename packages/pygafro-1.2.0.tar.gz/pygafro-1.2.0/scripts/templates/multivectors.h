typedef gafro::Multivector<double, BLADES> MULTIVECTOR_CLASS_NAME;
