typedef gafro::SingleManipulatorTarget<double, DOF, gafro::TOOL, gafro::TARGET> SingleManipulatorTarget_DOF_TOOL_TARGET;
