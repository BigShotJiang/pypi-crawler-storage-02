typedef pygafro::Quadruped<double, DOF> Quadruped_DOF;
