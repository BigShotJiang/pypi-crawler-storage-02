typedef gafro::SingleManipulatorMotorCost<double, DOF> SingleManipulatorMotorCost_DOF;
