typedef pygafro::Hand<double, FINGERSLIST> Hand_FINGERSSUFFIX;
