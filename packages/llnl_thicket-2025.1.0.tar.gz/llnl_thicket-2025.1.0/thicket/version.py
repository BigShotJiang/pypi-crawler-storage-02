# Copyright 2022 Lawrence Livermore National Security, LLC and other
# Thicket Project Developers. See the top-level LICENSE file for details.
#
# SPDX-License-Identifier: MIT

__version_info__ = ("2025", "1", "0")
__version__ = ".".join(__version_info__)
