from __future__ import annotations


class OperationalError(Exception): ...
