__title__ = "einar"
__author__ = "Juan Bindez"
__license__ = "GPLv2 License"
__js__ = None
__js_url__ = None

from einar.version import __version__
from einar.__main__ import AES
