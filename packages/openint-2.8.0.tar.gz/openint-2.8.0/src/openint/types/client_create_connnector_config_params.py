# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, TypedDict

__all__ = ["ClientCreateConnnectorConfigParams"]


class ClientCreateConnnectorConfigParams(TypedDict, total=False):
    connector_name: Required[str]

    config: Optional[Dict[str, object]]

    disabled: Optional[bool]

    display_name: Optional[str]

    metadata: Optional[Dict[str, object]]
