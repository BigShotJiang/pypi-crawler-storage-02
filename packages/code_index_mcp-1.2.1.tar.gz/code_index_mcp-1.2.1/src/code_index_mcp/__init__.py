"""Code Index MCP package.

A Model Context Protocol server for code indexing, searching, and analysis.
"""

__version__ = "1.2.1"
