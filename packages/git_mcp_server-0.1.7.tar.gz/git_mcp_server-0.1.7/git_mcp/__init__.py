"""Git MCP Server (git-mcp)

A unified command-line tool for managing Git repositories across GitHub and GitLab platforms.
"""

__version__ = "0.1.0"
__author__ = "Git MCP Team"
