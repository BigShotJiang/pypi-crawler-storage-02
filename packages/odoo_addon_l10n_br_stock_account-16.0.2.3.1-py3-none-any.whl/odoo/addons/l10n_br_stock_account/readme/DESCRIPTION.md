This module make possible create invoice based in Stock Pickings.
