insert into operations (prompt_id, tool, details, started_at)
  values (:prompt_id, :tool, :details, :started_at)
