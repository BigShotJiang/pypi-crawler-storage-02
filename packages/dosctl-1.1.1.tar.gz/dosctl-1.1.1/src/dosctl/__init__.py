"""DOSCtl - A command-line tool to manage and play DOS games."""

__version__ = "1.1.1"
