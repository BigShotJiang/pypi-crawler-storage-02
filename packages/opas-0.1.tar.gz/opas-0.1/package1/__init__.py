# from .file1 import add
# from .file2 import sub
from .cowAndBull import cows_and_bulls
from .GuessNum import guess_the_number
from .RockPapSci import play_rps
__add__=['cows_and_bulls','guess_the_number','play_rps'] 