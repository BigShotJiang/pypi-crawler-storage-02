# BCFPP = Basic Components For Python Projects


### This project aims to share components and features that would be replicated in most Python projects.