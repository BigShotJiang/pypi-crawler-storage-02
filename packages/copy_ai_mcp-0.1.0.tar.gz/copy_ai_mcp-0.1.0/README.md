# Copy.ai MCP

A MCP server for Copy.ai.



```json

{
  "mcpServers": {
    "copy-ai": {
      "env": {
        "APOLLO_API_KEY": "COPY_AI-API_KEY"
      },
      "command": "uvx",
      "args": [
        "copy-ai-mcp"
      ]
    }
  }
}
```