# -*- coding: utf-8 -*-

"""
Phandas: Quantitative analysis and backtesting for cryptocurrency markets.
"""

__author__ = "Phantom Management"
__version__ = "0.0.1"
