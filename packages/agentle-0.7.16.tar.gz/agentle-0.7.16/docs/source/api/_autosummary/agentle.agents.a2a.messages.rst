agentle.agents.a2a.messages
===========================

.. automodule:: agentle.agents.a2a.messages

   
   .. rubric:: Classes

   .. autosummary::
   
      GenerationMessageToMessageAdapter
      Message
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   generation_message_to_message_adapter
   message
   message_to_generation_message_adapter
