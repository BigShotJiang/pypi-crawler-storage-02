# Changelog

## v0.7.16

- update category nano in Cerebras and Google generation provider
