When a shipment advice is done, automatically trigger the printing of some
documents.
