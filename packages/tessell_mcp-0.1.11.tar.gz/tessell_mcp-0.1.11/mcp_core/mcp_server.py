from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    name="tessell-mcp"
)