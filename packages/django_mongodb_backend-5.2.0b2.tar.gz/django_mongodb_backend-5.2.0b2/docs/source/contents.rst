:orphan:

=================
Table of contents
=================

.. Keep this toctree in sync with the one at the bottom of index.rst.

.. toctree::
    :maxdepth: 2

    intro/index
    topics/index
    ref/index
    howto/index
    faq
    releases/index
    internals

Indices
=======

* :ref:`genindex`
* :ref:`modindex`
