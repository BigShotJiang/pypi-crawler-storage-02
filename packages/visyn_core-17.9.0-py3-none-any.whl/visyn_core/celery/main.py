from .app import create_celery_worker_app

celery_app = create_celery_worker_app()
