- Riccardo Bellanova \<<r.bellanova@apuliasoftware.it>\>

- Matteo Bilotta \<<mbilotta@linkeurope.it>\>

- Giuseppe Borruso \<<gborruso@dinamicheaziendali.it>\>

- Marco Calcagni \<<mcalcagni@dinamicheaziendali.it>\>

- Marco Colombo \<<marco.colombo@gmail.com>\>

- Gianmarco Conte \<<gconte@dinamicheaziendali.it>\>

- Letizia Freda \<<letizia.freda@netfarm.it>\>

- Andrea Piovesana \<<andrea.m.piovesana@gmail.com>\>

- Alex Comba \<<alex.comba@agilebg.com>\>

- [Ooops](https://www.ooops404.com):

  > - Giovanni Serra \<<giovanni@gslab.it>\>
  > - Foresti Francesco \<<francesco.foresti@ooops404.com>\>

- Nextev Srl \<<odoo@nextev.it>\>

- [PyTech-SRL](https://www.pytech.it):

  > - Alessandro Uffreduzzi \<<alessandro.uffreduzzi@pytech.it>\>
  > - Sebastiano Picchi \<<sebastiano.picchi@pytech.it>\>

- [Aion Tech](https://aiontech.company/):

  - Simone Rubino <<simone.rubino@aion-tech.it>>
