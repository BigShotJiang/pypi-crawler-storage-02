from fyg import Config

config = Config({
	"legacyh2l": False,
	"builder": {
		"verbose": False
	},
	"toc": {
		"secheaders": False
	}
})