# SIMBA SDK
The SIMBA SDK is a toolkit for integrating the SIMBA API into your python application (or just for exploration/experimentation). It provides a python wrapper around various endpoints in the SIMBA web service.
