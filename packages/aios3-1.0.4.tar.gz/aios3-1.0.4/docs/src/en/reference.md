::: aios3.file
    options:
      heading_level: 2
      show_submodules: true