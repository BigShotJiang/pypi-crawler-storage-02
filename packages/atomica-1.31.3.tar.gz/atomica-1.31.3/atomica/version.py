"""
Atomica version file.

Standard location for module version number and date.
"""
version = "1.31.3"
versiondate = "2025-08-11"
