"""
Initialise the migrations
"""
