# Dataset

## Alternate Identifier


## Title
Testing

## Creator

### Individual Name

#### Given Name
Amanda 

#### Sur Name
Buyan

#### Organization Name
Atlas of Living Australia

#### Position Name
Example

## Metadata Provider

### Individual Name

#### Given Name
Amanda 

#### Surname
Buyan

#### Organization Name
Atlas of Living Australia

### Address

#### Delivery Point
CSIRO Ecosystems Services

#### City
Canberra

#### Administrative Area
ACT

#### Postal Code
2601

#### Country
Australia

### Phone
0123456789

### Electronic Mail Address
email@example.com

## Associated Party

### Individual Name

#### Given Name
Amanda 

#### Surname
Buyan

### Organization Name
Atlas of Living Australia

### Role
principalInvestigator

## Associated Party

### Individual Name

#### Given Name
Amanda 

#### Surname
Buyan

### Organization Name
Atlas of Living Australia

### Role
pointOfContact

## Pub Date
2024-06-24

## Language
English

## Abstract

### Para
Something here.

## Keyword Set

### Keyword
test1

### Keyword
test2

## Intellectual Rights

### Para
Creative Commons Attribution 4.0 International (CC-BY 4.0)

## Contact

### Individual Name

#### Given Name
Amanda 

#### Surname
Buyan

### Organization Name
Atlas of Living Australia

### Position Name
Data Engineer

### Address

#### Delivery Point
CSIRO Ecosystems Services

#### City
Canberra

#### Administrative Area
ACT

#### Postal Code
2601

#### Country
Australia

### Phone
0123456789

### Electronic Mail Address
email@example.com
