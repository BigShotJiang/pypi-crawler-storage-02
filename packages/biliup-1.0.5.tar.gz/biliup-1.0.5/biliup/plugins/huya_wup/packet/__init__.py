
from .getCdnTokenInfo import (
    HuyaGetCdnTokenInfoReq,
    HuyaGetCdnTokenInfoRsp
)

__all__ = ['HuyaGetCdnTokenInfoReq', 'HuyaGetCdnTokenInfoRsp']

