from .packet import *
from .wup import Wup

__all__ = ['Wup', 'HuyaGetCdnTokenInfoReq', 'HuyaGetCdnTokenInfoRsp']

DEFAULT_TICKET_NUMBER = -1