import logging

logging.basicConfig()
