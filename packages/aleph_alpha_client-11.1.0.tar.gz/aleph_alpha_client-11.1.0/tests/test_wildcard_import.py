from aleph_alpha_client import *  # noqa


def test_should_be_able_to_import_with_wildcard():
    pass  # Wildcard import can not go into the test itself
