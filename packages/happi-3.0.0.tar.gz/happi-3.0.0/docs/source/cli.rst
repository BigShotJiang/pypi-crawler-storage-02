===================================
Command Line Interface
===================================

.. click:: happi.cli:happi_cli
   :prog: happi
   :nested: full
