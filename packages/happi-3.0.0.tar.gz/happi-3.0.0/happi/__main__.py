from happi.cli import main

main()
