# Filaments and paths

::: cfsem.filament_coil

::: cfsem.filament_helix_path

::: cfsem.rotate_filaments_about_path
