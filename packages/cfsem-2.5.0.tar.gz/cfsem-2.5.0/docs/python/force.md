# Force

::: cfsem.body_force_density_linear_filament

::: cfsem.body_force_density_circular_filament_cartesian