# Inductance

## Mutual inductance

::: cfsem.flux_circular_filament

::: cfsem.mutual_inductance_of_circular_filaments

::: cfsem.mutual_inductance_of_cylindrical_coils

::: cfsem.mutual_inductance_piecewise_linear_filaments

::: cfsem.mutual_inductance_circular_to_linear

## Self inductance

::: cfsem.self_inductance_annular_ring

::: cfsem.self_inductance_circular_ring_wien

::: cfsem.self_inductance_distributed_axisymmetric_conductor

::: cfsem.self_inductance_lyle6

::: cfsem.self_inductance_piecewise_linear_filaments

## General

::: cfsem.inductance_piecewise_linear_filaments
