#!/usr/bin/env python
"""Setup script for backward compatibility."""
from setuptools import setup

if __name__ == "__main__":
    setup()