class Optimiser:
    def __init__(self, model):
        self.model = model


Optimizer = Optimiser
