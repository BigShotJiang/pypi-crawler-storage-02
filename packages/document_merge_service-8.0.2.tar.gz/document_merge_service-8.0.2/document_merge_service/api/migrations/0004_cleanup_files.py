from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [("api", "0003_template_meta")]
    operations = []
