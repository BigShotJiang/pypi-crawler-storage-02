# setup.py (最小壳)
from setuptools import setup

if __name__ == "__main__":
    setup()   # 所有信息都从 pyproject.toml 读取
