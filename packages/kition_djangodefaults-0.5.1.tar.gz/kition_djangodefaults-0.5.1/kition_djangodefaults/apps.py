from django.apps import AppConfig


class KitionDjangoDefaultsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "kition_djangodefaults"
