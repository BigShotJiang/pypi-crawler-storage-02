# <img src='https://0000.us/klatchat/app/files/neon_images/icons/neon_skill.png' card_color="#FF8600" width="50" style="vertical-align:bottom">Communication

## Summary

Skill for the Common Message Skill framework.

## Description

This handles requests to send messages and place calls by communicating 
with all call and message handling skills and selecting the appropriate one to handle a request.

## Contact Support

Use the [link](https://neongecko.com/ContactUs) or [submit an issue on GitHub](https://help.github.com/en/articles/creating-an-issue)

## Credits
[NeonDaniel](https://github.com/NeonDaniel)
[NeonGeckoCom](https://github.com/NeonGeckoCom)

## Tags
#NeonGecko Original
#NeonAI
