"""Claude Code slash commands for Git MCP Server."""
