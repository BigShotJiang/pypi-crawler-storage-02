"""AI-based chatbot that provides sensible answers based on documentation"""

__version__ = '1.3.0'
