"""
Welcome to Youtube Autonomous Video
Moviepy Module.

This module has been created to contain
helpers and utils related to moviepy but
using only the pure 'moviepy' code, not
our own classes, because we have other
libraries in which we customize our own
libraries.
"""
