"""
Module to simplify the way we work with
the moviepy video time moment 't'.
"""
# TODO: Refactor this in the other libraries
# to use the new 'yta_video_frame_time' 
# instead of this library, it is lighter
# I want to export this as it is
from yta_video_frame_time import T