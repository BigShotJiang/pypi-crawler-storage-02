"""Tests for the connectivities module."""
