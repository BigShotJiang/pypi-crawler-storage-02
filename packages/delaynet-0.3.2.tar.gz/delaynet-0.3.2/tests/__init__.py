"""Tests for the delaynet module."""
