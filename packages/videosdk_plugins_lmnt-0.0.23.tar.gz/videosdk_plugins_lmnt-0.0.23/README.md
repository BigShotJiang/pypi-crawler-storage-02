# VideoSDK LMNT AI Plugin

Agent Framework plugin for TTS services from LMNT.

## Installation

```bash
pip install videosdk-plugins-lmnt
```