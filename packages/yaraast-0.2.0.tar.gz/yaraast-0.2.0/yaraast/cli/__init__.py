"""CLI module for YARA AST."""

from yaraast.cli.main import cli

__all__ = ["cli"]
