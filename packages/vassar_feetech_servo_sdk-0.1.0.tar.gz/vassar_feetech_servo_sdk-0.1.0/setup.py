"""Setup script for vassar-feetech-servo-sdk package."""

from setuptools import setup

# The actual setup is defined in pyproject.toml
# This file exists for backwards compatibility
setup()