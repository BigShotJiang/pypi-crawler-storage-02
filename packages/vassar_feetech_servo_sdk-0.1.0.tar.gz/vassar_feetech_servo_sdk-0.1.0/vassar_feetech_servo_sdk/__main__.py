"""Allow running the package with python -m vassar_feetech_servo_sdk."""

from .cli import main

if __name__ == "__main__":
    main()