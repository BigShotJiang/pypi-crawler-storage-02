

# class ServerClass:
    # def pid_get(self, data):
    #     print(data)
    
    # def network_get(self, data):
    #     print(data)

    # def disk_get(self, data):
    #     print(data)

    # def cpu_get(self, data):
    #     print(data)

    # def memory_get(self, data):
    #     print(data)