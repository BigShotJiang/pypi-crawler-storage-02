# Qlattice

A simple lattice QCD library.
