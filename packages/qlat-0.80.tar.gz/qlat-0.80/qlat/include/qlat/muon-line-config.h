#pragma once

const bool IS_USING_INTERPOLATION = true;

const bool IS_USING_AGGRESSIVE_SUBTRACTION = true;

const bool IS_USING_MORE_AGGRESSIVE_SUBTRACTION = true;

const bool IS_USING_MUON_LINE_INTERPOLATION = true;

const int IS_USING_ONLY_SUBTRACTION = 0;

const double DISTANCE_LIMIT = 6.0;

