# Base module tests - ensuring independence and standalone functionality
