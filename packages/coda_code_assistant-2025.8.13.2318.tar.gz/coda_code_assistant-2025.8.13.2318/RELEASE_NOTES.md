## What's Changed

- feat(cli): enhance streaming preview with response content display (633e70e)
- refactor(agents): extract common patterns and eliminate code duplication (d3d482e)
- feat(cli): implement rich markdown rendering for agent responses (a003cf3)

**Full Changelog**: https://github.com/djvolz/coda-code-assistant/compare/v2025.8.13.0939...v2025.8.13.2318
