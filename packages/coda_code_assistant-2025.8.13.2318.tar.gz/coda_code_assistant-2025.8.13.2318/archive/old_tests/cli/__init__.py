"""Test package for CLI modules."""
