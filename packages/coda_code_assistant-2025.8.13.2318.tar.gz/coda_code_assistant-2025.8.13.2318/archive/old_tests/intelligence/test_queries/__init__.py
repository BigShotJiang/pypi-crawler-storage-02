"""Test package for tree-sitter query validation and testing."""
