# Welcome to genesis_notification
The Platform Notification