from __future__ import annotations

from .macho import MachO

__all__ = ["MachO"]
