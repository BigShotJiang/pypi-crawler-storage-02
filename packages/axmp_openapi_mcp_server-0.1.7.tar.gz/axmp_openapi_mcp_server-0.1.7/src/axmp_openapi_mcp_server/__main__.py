"""This is the main entry point for the MCP server."""

import sys

from axmp_openapi_mcp_server.runner.cli import main

sys.exit(main())
