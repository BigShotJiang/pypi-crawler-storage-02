"""Top-level package for storms."""

__author__ = """Constantine Karos"""
__version__ = "1.2.4"

from storms.precip import Network, Raingage
