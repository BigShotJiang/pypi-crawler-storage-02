# Backtester 🏃‍♂️📈

파이썬으로 간단히 전략을 백테스트할 수 있는 경량 라이브러리입니다.

## 설치
```bash
python -m pip install --no-cache-dir united_backtester_japy_v1

## 삭제
```bash
pip uninstall united_backtester_japy_v1