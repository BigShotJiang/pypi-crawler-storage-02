## Parameters for Tools
======== Should use tables =======
{tables}
======= Database schema =======
{db_schema}
======= Sample limit =======
{sample_limit}
======= Reference limit =======
{ref_limit}
======= Reference Tags =======
{tags}