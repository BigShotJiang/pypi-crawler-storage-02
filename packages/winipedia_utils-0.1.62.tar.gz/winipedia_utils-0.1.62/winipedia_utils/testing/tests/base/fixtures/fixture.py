"""Fixtures for testing.

This module provides custom fixtures for pytest that can be used to
automate common testing tasks and provide consistent setup and teardown
for tests.
"""
