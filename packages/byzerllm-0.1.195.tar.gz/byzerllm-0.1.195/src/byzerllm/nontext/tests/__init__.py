
"""Tests for the nontext AC module"""
