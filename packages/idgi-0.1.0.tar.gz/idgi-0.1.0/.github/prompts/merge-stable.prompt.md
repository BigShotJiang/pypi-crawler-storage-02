---
mode: agent
tools: ['github']
model: Claude Sonnet 4
---

Merge the to-stable-2 branch to main using github mcp
