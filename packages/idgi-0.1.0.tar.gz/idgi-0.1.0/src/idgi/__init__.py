"""
idgi - A command-line tool for exploring and visualizing large Python codebases.
"""

__version__ = "0.1.0"
__author__ = "idgi developers"
__email__ = "developers@idgi.dev"
