"""Tests for Slack integration."""
