"""Integration modules for FastAPI AgentRouter."""

from . import slack

__all__ = ["slack"]
