
``wuttjamaican.enum``
=====================

.. automodule:: wuttjamaican.enum
   :members:
