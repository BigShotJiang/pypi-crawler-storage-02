
``wuttjamaican.cli.make_appdir``
================================

.. automodule:: wuttjamaican.cli.make_appdir
   :members:
