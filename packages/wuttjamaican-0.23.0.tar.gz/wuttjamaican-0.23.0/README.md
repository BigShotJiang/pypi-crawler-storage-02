
# WuttJamaican

Base package for Wutta Framework

See docs at https://rattailproject.org/docs/wuttjamaican/
