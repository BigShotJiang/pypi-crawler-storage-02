"""
Module to provide for command line access but does not perform
any actions if imported into another Python module.
"""

from pymarkdown.main import PyMarkdownLint  # noqa F401
