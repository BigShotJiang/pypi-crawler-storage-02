"""
Library version information.
"""

__version__ = "0.9.32"
__project_name__ = "pymarkdown"
__description__ = "A GitHub Flavored Markdown compliant Markdown linter."
