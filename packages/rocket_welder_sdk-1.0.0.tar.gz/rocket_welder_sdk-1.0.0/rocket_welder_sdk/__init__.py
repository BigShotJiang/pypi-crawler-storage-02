"""
Rocket Welder SDK - Python client library for RocketWelder video streaming services.
"""

from .client import Client

__version__ = "1.0.0"
__all__ = ["Client"]