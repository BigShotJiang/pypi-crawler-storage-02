# py-cleaner

A lightweight CLI tool to automatically remove unused import statements from your Python scripts.

## Installation

```bash
pip install pycleaner-cli
```

## Usage

```bash
pycleaner-cli clean-import path/to/your_file.py
```