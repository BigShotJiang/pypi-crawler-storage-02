export { default as LocalJsComponent } from './local-js-component';
