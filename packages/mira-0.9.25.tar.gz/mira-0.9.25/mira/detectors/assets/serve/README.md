# TorchServe Model Files
These are modules with placeholder variables that are inserted when using `detector.to_torchserve`.