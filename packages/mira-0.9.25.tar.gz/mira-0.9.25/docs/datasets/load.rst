Load new datasets
*****************

.. autofunction:: mira.datasets.load_coco

.. autofunction:: mira.datasets.load_voc
