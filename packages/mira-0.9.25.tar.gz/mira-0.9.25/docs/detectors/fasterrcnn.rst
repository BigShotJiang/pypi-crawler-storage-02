FasterRCNN
**********

.. autoclass:: mira.detectors.FasterRCNN
