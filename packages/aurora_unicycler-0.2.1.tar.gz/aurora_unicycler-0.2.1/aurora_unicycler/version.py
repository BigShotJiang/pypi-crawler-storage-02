"""Version information for the aurora-unicycler package."""

__version__ = "0.2.1"
