Change log
==========

0.3.4 (2025-08-04)
------------------

- python 3.13 support
- pandas >= 2.2 support
