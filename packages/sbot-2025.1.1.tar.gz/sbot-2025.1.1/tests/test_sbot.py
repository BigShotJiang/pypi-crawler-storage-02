"""Test that the module works."""

# TODO: Add tests for the following functions:
# vision.detect_markers(frame, save) -> List[Marker]
# vision.capture(save) -> NDArray
# leds.set_colour(id, colour)
# leds.get_colour(id) -> Colour
# utils.sleep(duration)
# utils.wait_start()
# utils.load_boards()

# TODO: Add tests for the following modules:
# overrides
# board_manager, including discovery
