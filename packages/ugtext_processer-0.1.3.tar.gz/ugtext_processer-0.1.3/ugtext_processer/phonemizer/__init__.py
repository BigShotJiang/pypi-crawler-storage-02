




from .ug_phonemizer import UgPhonemizer

__version__ = "0.1.0"
__all__ = ["UgPhonemizer"]

