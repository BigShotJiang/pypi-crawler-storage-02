from django.apps import AppConfig


class ApisAcdhchDjangoAuditlogConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apis_acdhch_django_auditlog"
