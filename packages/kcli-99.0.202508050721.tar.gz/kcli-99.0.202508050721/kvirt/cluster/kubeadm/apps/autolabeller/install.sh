kubectl apply -f https://raw.githubusercontent.com/karmab/autolabeller/main/autorules.yml
