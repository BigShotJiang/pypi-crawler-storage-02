"""Claude Code utilities and hacks."""

__version__ = "0.1.0"
