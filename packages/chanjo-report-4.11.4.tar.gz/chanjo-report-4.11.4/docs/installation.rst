============
Installation
============

At the command line::

    $ easy_install chanjo-report

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv chanjo-report
    $ pip install chanjo-report