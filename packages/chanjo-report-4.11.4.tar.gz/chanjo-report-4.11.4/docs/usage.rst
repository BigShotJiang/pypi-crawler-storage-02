========
Usage
========

To use Chanjo Report in a project::

	import chanjo-report