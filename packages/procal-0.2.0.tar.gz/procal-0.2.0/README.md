# procal

A simple Python calculator package that provides basic arithmetic operations.  
This package is intended as a demo for creating and publishing packages on PyPI.

## Features

- Addition
- Subtraction
- Multiplication
- Division
- Modulus

## Installation

You can install `procal` from [PyPI](https://pypi.org/) using:

```bash
pip install procal
