"""Tests for benchmarking framework."""
