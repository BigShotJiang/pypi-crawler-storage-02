#!/usr/bin/env python
# Import the primary AMClient script.
from .amclient import AMClient

# If the additional module commands need to be included they can also be
# included here.
__all__ = [
    "AMClient",
]
