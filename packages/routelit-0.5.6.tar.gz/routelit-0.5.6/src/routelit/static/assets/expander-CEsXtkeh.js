import{j as r}from"./app--5U4-9K0.js";const t=({title:s,open:e,children:a})=>r.jsxs("details",{open:e,children:[r.jsx("summary",{children:s}),a]});t.displayName="Expander";export{t as default};
