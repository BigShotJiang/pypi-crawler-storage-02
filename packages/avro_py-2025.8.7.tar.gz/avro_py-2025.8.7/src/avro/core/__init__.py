# SPDX-License-Identifier: MIT

"""
The core backend functionality module for the avro.py package.

Licensed under the terms of the MIT License.
"""
