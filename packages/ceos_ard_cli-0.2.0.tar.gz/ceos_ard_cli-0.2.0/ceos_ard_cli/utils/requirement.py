def slugify(text):
    return text.replace("/", "-")
