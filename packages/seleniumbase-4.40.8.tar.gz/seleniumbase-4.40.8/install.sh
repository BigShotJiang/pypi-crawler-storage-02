#!/usr/bin/env bash
pip install -e . --use-pep517 --config-settings="editable_mode=compat"
