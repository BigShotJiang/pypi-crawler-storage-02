# seleniumbase package
__version__ = "4.40.8"
