Starting (or restarting) the rec server:
****************************************

Start the Python process in the background:
-------------------------------------------
./invest/scripts/recreation_server/launch_recserver_twitter.sh

Setting up a new VM:
--------------------
The backend of the recreation model typically runs on a GCE VM.
Refer to invest/scripts/recreation_server/setup_vm.sh for VM setup.

And for more details,
https://github.com/natcap/invest/wiki/Recreation-model-cloud-infrastructure
