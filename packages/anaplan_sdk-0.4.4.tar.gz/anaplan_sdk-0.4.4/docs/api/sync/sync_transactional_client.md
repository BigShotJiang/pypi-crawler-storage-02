!!! note
    This Class is not meant to be instantiated directly, but rather accessed through the `transactional` Property on an
    instance of [Client](sync_client.md). For more details, see the [Guide](../../guides/transactional.md).

::: anaplan_sdk._clients._TransactionalClient

<style>
    [data-md-component="toc"] li:first-of-type{
        display:  none!important;
    }
</style>
