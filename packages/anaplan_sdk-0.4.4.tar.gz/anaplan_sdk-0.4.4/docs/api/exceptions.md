::: anaplan_sdk.exceptions
    options:
        show_bases: true

<style>
    [data-md-component="toc"] li:first-of-type{
        display:  none!important;
    }
</style>
