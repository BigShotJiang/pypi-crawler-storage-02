i = 0b1011_0101_1101

print(i & 0xFF)
print(i >> 8)