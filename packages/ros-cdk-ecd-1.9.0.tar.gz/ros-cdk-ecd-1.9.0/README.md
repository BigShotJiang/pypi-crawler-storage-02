## Aliyun ROS ECD Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as ECD from '@alicloud/ros-cdk-ecd';
```
