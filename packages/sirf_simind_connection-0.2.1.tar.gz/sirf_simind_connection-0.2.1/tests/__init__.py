"""Test package for SIRF-SIMIND-Connection."""
