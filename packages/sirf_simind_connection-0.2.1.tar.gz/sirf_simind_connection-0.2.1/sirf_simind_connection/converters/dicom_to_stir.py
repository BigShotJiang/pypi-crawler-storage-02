"""
DICOM to STIR conversion is handles in the AcquisitionBuilder Class
"""
