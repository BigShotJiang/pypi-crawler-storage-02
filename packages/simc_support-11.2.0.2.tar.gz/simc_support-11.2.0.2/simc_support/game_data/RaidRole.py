import enum


class RaidRole(enum.Enum):
    TANK = "tank"
    DD = "dd"
    HEAL = "heal"
