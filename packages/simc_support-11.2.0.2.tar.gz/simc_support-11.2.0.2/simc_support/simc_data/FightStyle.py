BEASTLORD = "beastlord"
CASTINGPATCHWERK = "castingpatchwerk"
CLEAVEADD = "cleaveadd"
DUNGEONSLICE = "dungeonslice"
HEAVYMOVEMENT = "heavymovement"
HECTICADDCLEAVE = "hecticaddcleave"
HELTERSKELTER = "helterskelter"
LIGHTMOVEMENT = "lightmovement"
PATCHWERK = "patchwerk"
ULTRAXION = "ultraxion"


FIGHTSTYLES = (
    BEASTLORD,
    CASTINGPATCHWERK,
    CLEAVEADD,
    DUNGEONSLICE,
    HEAVYMOVEMENT,
    HECTICADDCLEAVE,
    HELTERSKELTER,
    LIGHTMOVEMENT,
    PATCHWERK,
    ULTRAXION,
)
