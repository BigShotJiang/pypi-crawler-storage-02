PR = "PR"
T25 = "T25"
T26 = "T26"
T27 = "T27"

TIERS = (
    PR,
    T25,
    T26,
    T27,
)
