#! /usr/bin/env bash

alias @journal=bluer_journal
