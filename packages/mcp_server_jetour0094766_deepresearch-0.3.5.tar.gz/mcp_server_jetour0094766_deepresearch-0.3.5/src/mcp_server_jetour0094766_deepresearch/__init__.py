"""DeepResearch MCP Server"""
__version__ = "0.3.5"

from .server import main

__all__ = ["main"]