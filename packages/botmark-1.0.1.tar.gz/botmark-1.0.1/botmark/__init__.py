__version__ = "1.0.1"
from .core import BotManager

__all__ = ["BotManager", "BotMarkAgent"]