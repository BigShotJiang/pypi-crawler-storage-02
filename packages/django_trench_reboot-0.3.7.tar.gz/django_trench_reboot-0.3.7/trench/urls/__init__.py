from trench.urls.base import urlpatterns  # noqa
