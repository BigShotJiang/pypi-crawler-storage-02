from django.apps import AppConfig


class TrenchConfig(AppConfig):
    name = "trench"
    verbose_name = "django-trench"
