Welcome to django-trench documentation!
==========================================

Contents
--------
.. toctree::
   :maxdepth: 2

   introduction
   installation
   settings
   endpoints
   backends


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
