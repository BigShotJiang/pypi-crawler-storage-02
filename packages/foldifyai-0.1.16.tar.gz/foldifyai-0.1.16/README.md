## Installation
```
pip install foldifyai
```

```
foldifyai folder_containing_fasta_files/
```