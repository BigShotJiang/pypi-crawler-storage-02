#!/usr/bin/env python3
"""
Setup script for Mirix - Memory-enhanced AI agents
"""

from setuptools import setup, find_packages
import os

# Read the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read the requirements file
def read_requirements():
    """Read requirements from requirements.txt, filtering out system dependencies"""
    requirements = []
    with open("requirements.txt", "r") as f:
        for line in f:
            line = line.strip()
            # Skip comments, empty lines, and system dependencies
            if line and not line.startswith("#") and line not in ["ffmpeg"]:
                # Handle version specifications
                requirements.append(line)
    return requirements

# Get version from mirix/__init__.py
def get_version():
    """Extract version from mirix/__init__.py"""
    version_file = os.path.join("mirix", "__init__.py")
    with open(version_file, "r") as f:
        for line in f:
            if line.startswith("__version__"):
                return line.split('"')[1]
    return "0.1.0"

setup(
    name="mirix",
    version=get_version(),
    author="Yu Wang",
    author_email="yuwang@mirix.io",  # Update with your actual email
    description="Memory-enhanced AI agents with simple Python SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/RenKoya1/MIRIX",  # Update with your actual repo URL
    project_urls={
        "Bug Tracker": "https://github.com/RenKoya1/MIRIX/issues",
        "Documentation": "https://github.com/RenKoya1/MIRIX#readme",
        "Source Code": "https://github.com/RenKoya1/MIRIX",
    },
    packages=find_packages(exclude=["tests*", "examples*", "frontend*", "scripts*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-asyncio",
            "black",
            "flake8",
            "mypy",
            "twine",
            "build",
        ],
        "docs": [
            "sphinx",
            "sphinx-rtd-theme",
            "sphinx-autodoc-typehints",
        ],
    },
    entry_points={
        "console_scripts": [
            "mirix=mirix.__main__:main",
        ],
    },
    include_package_data=True,
    package_data={
        "mirix": [
            "prompts/personas/*.txt",
            "prompts/system/base/*.txt",
            "prompts/system/screen_monitor/*.txt",
        ],
    },
    keywords=[
        "ai",
        "agents",
        "memory",
        "llm",
        "chatbot",
        "artificial-intelligence",
        "machine-learning",
        "openai",
        "anthropic",
        "google-ai",
        "gemini",
    ],
    zip_safe=False,
)