"""UI package for Splunk Agentic AI."""
