"""Splunk Agentic AI - Core package."""

__version__ = "1.0.0"
__author__ = "Splunk Agentic AI Team"
__description__ = "Natural language to SPL query conversion and execution"
