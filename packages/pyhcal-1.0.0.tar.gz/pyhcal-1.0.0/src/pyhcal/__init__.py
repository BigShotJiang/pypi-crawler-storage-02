# -*- coding: utf-8 -*-
"""
Created on Thu Dec  9 10:39:01 2021

@author: mfratki
"""

