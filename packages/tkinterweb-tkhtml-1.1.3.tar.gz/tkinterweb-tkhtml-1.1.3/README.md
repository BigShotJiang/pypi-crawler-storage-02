# TkinterWeb-Tkhtml

**This package provides pre-built binaries of a modified version of the Tkhtml3 widget from http://tkhtml.tcl.tk, which enables the display of styled HTML and CSS code in Tkinter applications.**

This package can be used to import the Tkhtml widget into Tkinter projects but is mainly intended to be used through TkinterWeb, which provides a full Python interface. 

**See https://github.com/Andereoo/TkinterWeb for more information.**
