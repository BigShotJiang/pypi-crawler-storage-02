from .main import main  # pragma: no cover

main()  # pragma: no cover
