This module extends the functionality of recurring invoices to support propagating the
customer ref when the next draft invoice is auto-generated.
