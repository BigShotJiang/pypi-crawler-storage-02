To use this module, you need to:

1. Go to *Accounting > New Invoice*.
1. Set the customer.
1. Set the product.
1. Navigate to *Other info* tab.
1. Configure recurrence with *Auto-post*.
1. Set a *Customer reference*.
1. Press *Confirm*.
1. A new draft invoice for the next iteration should have been auto-generated.
1. Find that new draft invoice and open it.
1. The *Customer reference* is the same as it was in the original invoice.
