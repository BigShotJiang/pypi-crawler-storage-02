import kabaret.app.resources as resources
resources.add_folder('icons.status', __file__)
