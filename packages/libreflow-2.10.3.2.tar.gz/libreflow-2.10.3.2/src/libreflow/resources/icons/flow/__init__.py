import kabaret.app.resources as resources
import logging


resources.add_folder("icons.flow", __file__)
logging.debug("ICONS.FLOW LOADED")