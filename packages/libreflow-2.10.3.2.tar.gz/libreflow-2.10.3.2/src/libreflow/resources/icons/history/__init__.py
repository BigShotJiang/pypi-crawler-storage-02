import kabaret.app.resources as resources
resources.add_folder('icons.history', __file__)
