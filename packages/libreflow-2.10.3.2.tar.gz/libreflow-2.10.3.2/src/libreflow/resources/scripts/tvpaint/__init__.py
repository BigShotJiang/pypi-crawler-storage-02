import kabaret.app.resources as resources
import logging


resources.add_folder("scripts.tvpaint", __file__)
