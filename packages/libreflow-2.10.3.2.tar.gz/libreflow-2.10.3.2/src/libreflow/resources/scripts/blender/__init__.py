import kabaret.app.resources as resources
import logging


resources.add_folder("scripts.blender", __file__)
