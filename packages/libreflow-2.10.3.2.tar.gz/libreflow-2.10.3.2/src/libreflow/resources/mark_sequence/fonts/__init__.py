import kabaret.app.resources as resources
import logging


resources.add_folder("mark_sequence.fonts", __file__)
