"""
SpiderFoot MCP Server

A Model Context Protocol server that provides SpiderFoot scanning capabilities.
"""

__version__ = "1.0.0"