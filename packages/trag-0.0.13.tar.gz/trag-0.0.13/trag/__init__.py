"""
trag - templating for retrieval augmented generation.

`trag` is a simple, minimal retrieval and templating engine.

"""

import hy

# set the package version
__version__ = "0.0.13"
__version_info__ = __version__.split(".")

