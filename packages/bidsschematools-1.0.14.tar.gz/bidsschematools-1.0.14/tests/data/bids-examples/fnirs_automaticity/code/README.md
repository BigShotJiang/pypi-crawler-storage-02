The script of only one subject have been left in the repository. 
The others can be accessed in the original dataset.