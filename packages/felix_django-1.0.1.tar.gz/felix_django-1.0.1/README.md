# felix_django
Felix' Django stuff.


## Installation
```
pip install felix_django
```


## Development
```
mise trust
mise install
pre-commit install -f
uv sync --all-extras
```
