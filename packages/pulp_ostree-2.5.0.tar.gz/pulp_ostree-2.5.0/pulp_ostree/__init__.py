default_app_config = "pulp_ostree.app.PulpOstreePluginAppConfig"
