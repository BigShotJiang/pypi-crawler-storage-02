"""Tests that communicate with ostree plugin via the v3 API."""
