![Nightly CI/CD](https://github.com/pulp/pulp_ostree/actions/workflows/nightly.yml/badge.svg?branch=main)

Pulp OSTree Plugin
==================

A Pulp plugin to support hosting your own OSTree content.

For more information, please see the [documentation](https://docs.pulpproject.org/pulp_ostree/) or the [Pulp project page](https://pulpproject.org/).
