Models Module
=============

The models module provides base classes for machine learning models.

.. currentmodule:: xflow.models

.. autoclass:: BaseModel
   :members:
   :undoc-members:
   :show-inheritance:
