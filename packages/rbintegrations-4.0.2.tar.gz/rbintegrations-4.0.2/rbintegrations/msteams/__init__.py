"""Integration for Microsoft Teams.

Version Added:
    4.0
"""
