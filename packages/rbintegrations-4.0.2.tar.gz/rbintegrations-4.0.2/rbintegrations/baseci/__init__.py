"""Base support for building Continuous Integration service integrations.

Version Added:
    3.1
"""
