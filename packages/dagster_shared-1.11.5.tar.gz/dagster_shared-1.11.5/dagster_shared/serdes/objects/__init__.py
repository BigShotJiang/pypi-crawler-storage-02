from dagster_shared.serdes.objects.package_entry import (
    ComponentFeatureData as ComponentFeatureData,
    EnvRegistryKey as EnvRegistryKey,
    EnvRegistryObjectSnap as EnvRegistryObjectSnap,
    ScaffoldTargetTypeData as ScaffoldTargetTypeData,
)
