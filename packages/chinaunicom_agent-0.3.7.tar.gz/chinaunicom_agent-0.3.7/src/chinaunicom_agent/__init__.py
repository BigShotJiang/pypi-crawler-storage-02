from . import week_report

__version__ = "0.3.7"
__author__ = "zhaoyongzheng"

__all__ = ['week_report']