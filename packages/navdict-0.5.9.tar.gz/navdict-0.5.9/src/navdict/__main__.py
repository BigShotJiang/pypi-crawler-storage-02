print("See documentation at: https://ivs-kuleuven.github.io/navdict/")
