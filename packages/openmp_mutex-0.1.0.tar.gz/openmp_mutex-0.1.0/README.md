# _openmp_mutex\nA dummy Python package version of _openmp_mutex.
