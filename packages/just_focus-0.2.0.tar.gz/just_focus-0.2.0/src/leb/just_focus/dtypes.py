"""Numpy dtypes used within this package."""

import numpy as np


Complex = np.complex128
Float = np.float64
