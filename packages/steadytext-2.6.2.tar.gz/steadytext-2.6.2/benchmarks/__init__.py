"""SteadyText Benchmarking Suite

This package provides comprehensive speed and accuracy benchmarks for SteadyText.
"""

__version__ = "0.1.0"
