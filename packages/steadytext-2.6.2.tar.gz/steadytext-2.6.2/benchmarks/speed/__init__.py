"""Speed benchmarking module for SteadyText."""
