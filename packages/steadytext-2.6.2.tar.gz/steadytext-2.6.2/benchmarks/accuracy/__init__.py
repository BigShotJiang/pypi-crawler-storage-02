"""Accuracy benchmarking module for SteadyText using LightEval."""
