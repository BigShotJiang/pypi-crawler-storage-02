"""Exception classes for Gravify."""


class GravifyError(Exception):
    """Base exception class for Gravify."""
