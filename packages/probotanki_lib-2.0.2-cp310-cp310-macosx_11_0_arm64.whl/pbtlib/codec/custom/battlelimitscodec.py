from ..complex.doubleintcodec import DoubleIntCodecFactory

BattleLimitsCodec = DoubleIntCodecFactory("scoreLimit", "timeLimit")
