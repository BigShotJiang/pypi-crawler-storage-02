def normalize_name(name: str) -> str:
    """Normalize a name for tracking."""
    return name.capitalize().strip()