from ...packets import AbstractPacket


class Login_Success(AbstractPacket):
    id = -1923286328
    description = 'Login successful'
