from ...packets import AbstractPacket


class Send_Respawn(AbstractPacket):
    id = -1378839846
    description = "Send Respawn(fantom) Packet"
