from ...packets import AbstractPacket


class Open_Friends_List(AbstractPacket):
    id = 1441234714
    description = 'Open Friends List'
