from ...packets import AbstractPacket


class Load_Settings(AbstractPacket):
    id = 850220815
    description = "Load settings"
