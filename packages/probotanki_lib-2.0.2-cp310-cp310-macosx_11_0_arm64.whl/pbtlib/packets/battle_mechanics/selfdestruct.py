from ...packets import AbstractPacket


class Self_Destruct(AbstractPacket):
    id = 988664577
    description = "Sends a self destruct request to the server"
