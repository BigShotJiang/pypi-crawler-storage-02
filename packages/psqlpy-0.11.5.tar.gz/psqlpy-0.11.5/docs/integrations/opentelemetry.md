---
title: Integration with OpenTelemetry
---

# OTLP-PSQLPy

There is a library for OpenTelemetry support.
Please follow the [link](https://github.com/psqlpy-python/otlp-psqlpy)
