import os

def install_script():
    print("inside install script!!")
