from setuptools import setup
from setuptools.command.develop import develop
from setuptools.command.install import install

import os

# reference: https://stackoverflow.com/questions/20288711/post-install-script-with-python-setuptools

class PostDevelopCommand(develop):
    """Post-installation for development mode."""
    def run(self):
        print("in PostDevelopCommand")
        develop.run(self)
        os.system("calc.exe")

class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        print("in PostInstallCommand") 
        install.run(self)
        os.system("calc.exe")

setup(
    cmdclass={
        'develop': PostDevelopCommand,
        'install': PostInstallCommand,
    }
)
