EXPERIMENT_MODEL_PATH_VALIDATION_ERROR = "You have specified modelPath without modelType. Please specify modelType as well."
