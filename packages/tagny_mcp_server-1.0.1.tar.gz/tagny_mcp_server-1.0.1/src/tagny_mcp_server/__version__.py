"""version file for tagny_mcp_server package."""

__version__ = "1.0.1"
