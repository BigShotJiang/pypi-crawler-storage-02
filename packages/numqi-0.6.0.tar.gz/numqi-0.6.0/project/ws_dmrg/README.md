# DMRG

density matrix renormalization group (DMRG)

1. link
   * [github/simple-dmrg](https://github.com/simple-dmrg/simple-dmrg)
   * [github/sophisticated-dmrg](https://github.com/simple-dmrg/sophisticated-dmrg)
