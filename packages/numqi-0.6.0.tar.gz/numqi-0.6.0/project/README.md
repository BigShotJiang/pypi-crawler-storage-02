# project

A series of workspaces `ws_xxx` to reproduce the results of the published papers.

1. `ws_clifford`: Clifford circuits
2. `ws_qnn_material`: Quantum neural network for material science
3. `ws_sum_hermitian`: Sum of Hermitian matrices [doi-link](https://doi.org/10.4153/CJM-2010-007-2)
