# optimal control

1. TODO
   * predifined control pulse, see qctrl-open-controls
     * [qctrl-open-controls/corpse-control](https://docs.q-ctrl.com/open-controls/references/qctrl-open-controls/qctrlopencontrols/new_corpse_control.html)
     * [qctrl-open-controls/DynamicDecouplingSequence](https://docs.q-ctrl.com/open-controls/references/qctrl-open-controls/qctrlopencontrols/DynamicDecouplingSequence.html)
