# multipartite entanglement

[matlab/PPTMixer](https://ww2.mathworks.cn/matlabcentral/fileexchange/30968-pptmixer-a-tool-to-detect-genuine-multipartite-entanglement)

Taming Multiparticle Entanglement [doi-link](https://doi.org/10.1103/PhysRevLett.106.190502)
