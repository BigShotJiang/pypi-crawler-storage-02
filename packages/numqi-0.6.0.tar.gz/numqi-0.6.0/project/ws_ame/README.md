# Absolutely maximally entangled state

1. link
   * A complete hierarchy for the pure state marginal problem in quantum mechanics [doi-link](https://doi.org/10.1038/s41467-020-20799-5)
   * table of ame states [link](https://www.tp.nt.uni-siegen.de/+fhuber/ame.html)
