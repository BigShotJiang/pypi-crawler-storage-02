# numqi.optimize

TODO documentation

1. [ ] compare `L-BFGS-B` with `Adam`
2. [ ] augmented lagrangian method
3. [ ] convex programming, LP, SDP etc.
