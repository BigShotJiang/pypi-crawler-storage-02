# 3 is different

1. 2-array tensor have svd decomposition, 3-array does not
   * 2-array, norm-1 tensor is compact
   * 3-array, norm-1, rank $r>1$ tensor is not closed (border rank)
2. PPT is iff condition for `2x2`, `2x3`, but not for others
3. for qubit system, bosonic extension is equal to symmetric extension [doi-link](https://doi.org/10.1103/PhysRevA.99.012332)
4. [wiki-link](https://en.wikipedia.org/wiki/Hilbert%27s_seventeenth_problem) Hilbert's seventeenth problem, Polynomial SOS
