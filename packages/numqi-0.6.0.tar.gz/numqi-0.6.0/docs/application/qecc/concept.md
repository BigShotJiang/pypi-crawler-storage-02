# quantum error correction's concept

1. link
    * [github/qecsim](https://github.com/qecsim/qecsim)
    * [github/qtcodes](https://github.com/yaleqc/qtcodes)
    * [github/pymatching](https://github.com/oscarhiggott/PyMatching)
    * [github/qsurface](https://github.com/watermarkhu/qsurface)
    * [encoding-circuits](https://markus-grassl.de/QECC/circuits/index.html)

TODO quantum enumerator

TODO Knill-Laflamme conditions

TODO different equivalent QECC

TODO how to calculate weight enumerator `numqi.qec.get_weight_enumerator`
