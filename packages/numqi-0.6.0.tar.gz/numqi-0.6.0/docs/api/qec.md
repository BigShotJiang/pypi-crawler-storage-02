# qec

::: numqi.qec.stabilizer_to_code
    options:
      heading_level: 2

::: numqi.qec.get_code_subspace
    options:
      heading_level: 2

::: numqi.qec.get_code_feasible_constraint
    options:
      heading_level: 2

::: numqi.qec.is_code_feasible
    options:
      heading_level: 2

::: numqi.qec.get_Krawtchouk_polynomial
    options:
      heading_level: 2

::: numqi.qec.is_code_feasible_linear_programming
    options:
      heading_level: 2

::: numqi.qec.hf_state
    options:
      heading_level: 2

::: numqi.qec.hf_pauli
    options:
      heading_level: 2

::: numqi.qec.get_pauli_with_weight_sparse
    options:
      heading_level: 2

::: numqi.qec.make_pauli_error_list_sparse
    options:
      heading_level: 2

::: numqi.qec.pauli_csr_to_kind
    options:
      heading_level: 2

::: numqi.qec.get_weight_enumerator
    options:
      heading_level: 2
