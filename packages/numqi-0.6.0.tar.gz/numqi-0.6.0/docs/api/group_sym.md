# Symmetric group

`numqi.group._symmetric`

::: numqi.group.permutation_to_cycle_notation
    options:
      heading_level: 2

::: numqi.group.get_symmetric_group_cayley_table
    options:
      heading_level: 2

::: numqi.group.get_sym_group_num_irrep
    options:
      heading_level: 2

::: numqi.group.get_sym_group_young_diagram
    options:
      heading_level: 2

::: numqi.group.get_young_diagram_mask
    options:
      heading_level: 2

::: numqi.group.check_young_diagram
    options:
      heading_level: 2

::: numqi.group.get_hook_length
    options:
      heading_level: 2

::: numqi.group.get_young_diagram_transpose
    options:
      heading_level: 2

::: numqi.group.get_all_young_tableaux
    options:
      heading_level: 2

::: numqi.group.young_tableau_to_young_symmetrizer
    options:
      heading_level: 2

::: numqi.group.print_all_young_tableaux
    options:
      heading_level: 2
