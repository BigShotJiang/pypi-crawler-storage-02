# Concurrence and Entanglement of Formation

Accessible in both `numqi.entangle` (recommended) and `numqi.entangle.eof`

::: numqi.entangle.get_concurrence_pure
    options:
      heading_level: 2

::: numqi.entangle.get_concurrence_2qubit
    options:
      heading_level: 2

::: numqi.entangle.get_eof_pure
    options:
      heading_level: 2

::: numqi.entangle.get_eof_2qubit
    options:
      heading_level: 2

::: numqi.entangle.EntanglementFormationModel
    options:
      heading_level: 2

::: numqi.entangle.ConcurrenceModel
    options:
      heading_level: 2
