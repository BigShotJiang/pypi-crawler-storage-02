# state

::: numqi.state.W
    options:
      heading_level: 2

::: numqi.state.Wtype
    options:
      heading_level: 2

::: numqi.state.get_Wtype_state_GME
    options:
      heading_level: 2

::: numqi.state.GHZ
    options:
      heading_level: 2

::: numqi.state.Bell
    options:
      heading_level: 2

::: numqi.state.Dicke
    options:
      heading_level: 2

::: numqi.state.get_qubit_dicke_state_GME
    options:
      heading_level: 2

::: numqi.state.Werner
    options:
      heading_level: 2

::: numqi.state.get_Werner_ree
    options:
      heading_level: 2

::: numqi.state.get_Werner_eof
    options:
      heading_level: 2

::: numqi.state.get_Werner_GME
    options:
      heading_level: 2

::: numqi.state.Isotropic
    options:
      heading_level: 2

::: numqi.state.get_Isotropic_ree
    options:
      heading_level: 2

::: numqi.state.get_Isotropic_eof
    options:
      heading_level: 2

::: numqi.state.get_Isotropic_GME
    options:
      heading_level: 2

::: numqi.state.maximally_entangled_state
    options:
      heading_level: 2

::: numqi.state.maximally_coherent_state
    options:
      heading_level: 2

::: numqi.state.get_2qutrit_Antoine2022
    options:
      heading_level: 2

::: numqi.state.get_bes2x4_Horodecki1997
    options:
      heading_level: 2

::: numqi.state.get_bes3x3_Horodecki1997
    options:
      heading_level: 2

::: numqi.state.get_4qubit_special_state_gme
    options:
      heading_level: 2
