# Entanglement Measure

Geometric Measure of Entanglement (GME)

Accessible in both `numqi.entangle` (recommended) and `numqi.entangle.measure`

::: numqi.entangle.DensityMatrixGMEModel
    options:
      heading_level: 2

::: numqi.entangle.get_gme_2qubit
    options:
      heading_level: 2

::: numqi.entangle.get_relative_entropy_of_entanglement_pure
    options:
      heading_level: 2

::: numqi.entangle.get_linear_entropy_entanglement_ppt
    options:
      heading_level: 2

::: numqi.entangle.DensityMatrixLinearEntropyModel
    options:
      heading_level: 2
