# utils

::: numqi.utils.hf_num_state_to_num_qubit
    options:
      heading_level: 2

::: numqi.utils.hf_complex_to_real
    options:
      heading_level: 2

::: numqi.utils.hf_real_to_complex
    options:
      heading_level: 2

::: numqi.utils.partial_trace
    options:
      heading_level: 2

::: numqi.utils.get_fidelity
    options:
      heading_level: 2

::: numqi.utils.get_von_neumann_entropy
    options:
      heading_level: 2

::: numqi.utils.get_Renyi_entropy
    options:
      heading_level: 2

::: numqi.utils.get_purification
    options:
      heading_level: 2

::: numqi.utils.get_trace_distance
    options:
      heading_level: 2

::: numqi.utils.get_purity
    options:
      heading_level: 2

::: numqi.utils.get_relative_entropy
    options:
      heading_level: 2

::: numqi.utils.get_tetrahedron_POVM
    options:
      heading_level: 2

::: numqi.utils.is_positive_semi_definite
    options:
      heading_level: 2

::: numqi.utils.hf_interpolate_dm
    options:
      heading_level: 2
