# Gell-Mann matrix

`numqi.gellmann`

::: numqi.gellmann.gellmann_matrix
    options:
      heading_level: 2

::: numqi.gellmann.all_gellmann_matrix
    options:
      heading_level: 2

::: numqi.gellmann.matrix_to_gellmann_basis
    options:
      heading_level: 2

::: numqi.gellmann.gellmann_basis_to_matrix
    options:
      heading_level: 2

::: numqi.gellmann.dm_to_gellmann_basis
    options:
      heading_level: 2

::: numqi.gellmann.gellmann_basis_to_dm
    options:
      heading_level: 2

::: numqi.gellmann.dm_to_gellmann_norm
    options:
      heading_level: 2

::: numqi.gellmann.get_density_matrix_distance2
    options:
      heading_level: 2
