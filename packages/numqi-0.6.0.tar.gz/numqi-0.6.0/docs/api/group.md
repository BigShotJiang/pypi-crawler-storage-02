# group

::: numqi.group.cayley_table_to_left_regular_form
    options:
      heading_level: 2

::: numqi.group.get_klein_four_group_cayley_table
    options:
      heading_level: 2

::: numqi.group.get_dihedral_group_cayley_table
    options:
      heading_level: 2

::: numqi.group.get_cyclic_group_cayley_table
    options:
      heading_level: 2

::: numqi.group.get_multiplicative_group_cayley_table
    options:
      heading_level: 2

::: numqi.group.get_quaternion_cayley_table
    options:
      heading_level: 2

::: numqi.group.reduce_group_representation
    options:
      heading_level: 2

::: numqi.group.to_unitary_representation
    options:
      heading_level: 2

::: numqi.group.matrix_block_diagonal
    options:
      heading_level: 2

::: numqi.group.get_character_and_class
    options:
      heading_level: 2

::: numqi.group.hf_Euler_totient
    options:
      heading_level: 2

::: numqi.group.hf_is_prime
    options:
      heading_level: 2

::: numqi.group.pretty_print_character_table
    options:
      heading_level: 2
