# Pure Bosonic Extension

Accessible in both `numqi.entangle` (recommended) and `numqi.entangle.pureb`

::: numqi.entangle.PureBosonicExt
    options:
      heading_level: 2

`numqi.entangle.pureb_quantum.QuantumPureBosonicExt` TODO
