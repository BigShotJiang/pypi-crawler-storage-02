# Entanglement Measure via Seesaw Optimization

Accessible in both `numqi.entangle` (recommended) and `numqi.entangle.measure_seesaw`

::: numqi.entangle.get_GME_pure_seesaw
    options:
      heading_level: 2

::: numqi.entangle.get_GME_subspace_seesaw
    options:
      heading_level: 2

::: numqi.entangle.get_GME_seesaw
    options:
      heading_level: 2
