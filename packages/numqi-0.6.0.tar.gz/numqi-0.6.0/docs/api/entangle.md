# entangle

`numqi.entangle`

::: numqi.entangle.hf_interpolate_dm
    options:
      heading_level: 2

WARNING: rename to `numqi.utils.hf_interpolate_dm`

::: numqi.entangle.get_dm_numerical_range
    options:
      heading_level: 2

::: numqi.entangle.get_negativity
    options:
      heading_level: 2

::: numqi.entangle.check_reduction_witness
    options:
      heading_level: 2

::: numqi.entangle.check_swap_witness
    options:
      heading_level: 2

::: numqi.entangle.get_density_matrix_plane
    options:
      heading_level: 2

::: numqi.entangle.get_density_matrix_boundary
    options:
      heading_level: 2

::: numqi.entangle.get_dm_cross_section_moment
    options:
      heading_level: 2

::: numqi.entangle.is_dm_cross_section_similar
    options:
      heading_level: 2

::: numqi.entangle.group_dm_cross_section_moment
    options:
      heading_level: 2
