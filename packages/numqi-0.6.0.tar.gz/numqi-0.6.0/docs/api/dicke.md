# dicke

::: numqi.dicke.Dicke
    options:
      heading_level: 2

::: numqi.dicke.get_dicke_basis
    options:
      heading_level: 2

::: numqi.dicke.get_dicke_klist
    options:
      heading_level: 2

::: numqi.dicke.get_qubit_dicke_partial_trace
    options:
      heading_level: 2

::: numqi.dicke.get_partial_trace_ABk_to_AB_index
    options:
      heading_level: 2
