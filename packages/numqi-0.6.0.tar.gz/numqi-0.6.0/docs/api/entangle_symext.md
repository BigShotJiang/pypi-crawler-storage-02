# Symmetric extension criteria

Accessible in both `numqi.entangle` (recommended) and `numqi.entangle.symext`

::: numqi.entangle.get_ABk_symmetric_extension_ree
    options:
      heading_level: 2

::: numqi.entangle.is_ABk_symmetric_ext
    options:
      heading_level: 2

::: numqi.entangle.get_ABk_symmetric_extension_boundary
    options:
      heading_level: 2

::: numqi.entangle.get_ABk_extension_numerical_range
    options:
      heading_level: 2
