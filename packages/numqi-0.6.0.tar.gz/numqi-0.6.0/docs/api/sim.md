# Simulator

`numqi.sim`

::: numqi.sim.new_base
    options:
      heading_level: 2

::: numqi.sim.Circuit
    options:
      heading_level: 2
