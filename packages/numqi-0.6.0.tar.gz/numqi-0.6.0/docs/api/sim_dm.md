# Density matrix utility functions for simulator

`numqi.sim.dm`

::: numqi.sim.dm.new_base
    options:
      heading_level: 2

::: numqi.sim.dm.apply_gate
    options:
      heading_level: 2

::: numqi.sim.dm.operator_expectation
    options:
      heading_level: 2
