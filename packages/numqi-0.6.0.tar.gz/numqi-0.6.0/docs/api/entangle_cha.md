# CHA model

Convex Hull Approximation (CHA)

Accessible in both `numqi.entangle` (recommended) and `numqi.entangle.cha`

::: numqi.entangle.CHABoundaryBagging
    options:
      heading_level: 2

::: numqi.entangle.AutodiffCHAREE
    options:
      heading_level: 2
