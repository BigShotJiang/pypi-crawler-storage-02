# Lie group

`numqi.group._lie`

::: numqi.group.angle_to_su2
    options:
      heading_level: 2

::: numqi.group.angle_to_so3
    options:
      heading_level: 2

::: numqi.group.so3_to_angle
    options:
      heading_level: 2

::: numqi.group.su2_to_angle
    options:
      heading_level: 2

::: numqi.group.so3_to_su2
    options:
      heading_level: 2

::: numqi.group.su2_to_so3
    options:
      heading_level: 2

::: numqi.group.get_su2_irrep
    options:
      heading_level: 2

::: numqi.group.get_rational_orthogonal2_matrix
    options:
      heading_level: 2
