# Group for symmetric extensions

`numqi.group.symext`

::: numqi.group.symext.get_ABk_symmetry_index
    options:
      heading_level: 2

::: numqi.group.symext.get_ABk_symmetrize
    options:
      heading_level: 2

::: numqi.group.symext.get_2qutrit_irrep_basis
    options:
      heading_level: 2

::: numqi.group.symext.get_3qutrit_irrep_basis
    options:
      heading_level: 2

::: numqi.group.symext.get_sud_symmetric_irrep_basis
    options:
      heading_level: 2

::: numqi.group.symext.get_symmetric_extension_irrep_coeff
    options:
      heading_level: 2

::: numqi.group.symext.print_symmetric_extension_irrep_coeff
    options:
      heading_level: 2
