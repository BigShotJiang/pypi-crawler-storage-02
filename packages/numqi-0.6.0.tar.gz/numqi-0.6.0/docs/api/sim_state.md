# State utility functions for simulator

`numqi.sim.state`

::: numqi.sim.state.measure_quantum_vector
    options:
      heading_level: 2

::: numqi.sim.state.new_base
    options:
      heading_level: 2

::: numqi.sim.state.reduce_shape_index
    options:
      heading_level: 2

::: numqi.sim.state.apply_gate
    options:
      heading_level: 2

::: numqi.sim.state.apply_gate_grad
    options:
      heading_level: 2

::: numqi.sim.state.apply_control_n_gate
    options:
      heading_level: 2

::: numqi.sim.state.apply_control_n_gate_grad
    options:
      heading_level: 2

::: numqi.sim.state.inner_product_psi0_O_psi1
    options:
      heading_level: 2

::: numqi.sim.state.reduce_to_probability
    options:
      heading_level: 2
