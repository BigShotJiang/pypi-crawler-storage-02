# magic

Accessible in `numqi.magic`

::: numqi.magic.get_Weyl_H
    options:
      heading_level: 2

::: numqi.magic.get_Weyl_Z
    options:
      heading_level: 2

::: numqi.magic.get_Weyl_X
    options:
      heading_level: 2

::: numqi.magic.get_Heisenberg_Weyl_operator
    options:
      heading_level: 2

::: numqi.magic.get_qutrit_nonstabilizer_state
    options:
      heading_level: 2

::: numqi.magic.plot_qubit_magic_state_3d
    options:
      heading_level: 2

::: numqi.magic.matrix_to_wigner_basis
    options:
      heading_level: 2

::: numqi.magic.wigner_basis_to_matrix
    options:
      heading_level: 2

::: numqi.magic.get_wigner_trace_norm
    options:
      heading_level: 2

::: numqi.magic.get_magic_state_boundary_qubit
    options:
      heading_level: 2

::: numqi.magic.get_thauma_sdp
    options:
      heading_level: 2

::: numqi.magic.get_thauma_boundary
    options:
      heading_level: 2
