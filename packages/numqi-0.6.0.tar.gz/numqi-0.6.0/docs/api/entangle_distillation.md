# entanglement distillation

Accessible in both `numqi.entangle` (recommended) and `numqi.entangle.distillation`

::: numqi.entangle.get_binegativity
    options:
      heading_level: 2

::: numqi.entangle.get_PPT_entanglement_cost_bound
    options:
      heading_level: 2

::: numqi.entangle.SearchMinimumBinegativityModel
    options:
      heading_level: 2
