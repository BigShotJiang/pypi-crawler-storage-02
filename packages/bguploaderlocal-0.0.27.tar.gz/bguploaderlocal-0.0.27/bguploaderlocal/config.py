import os

class Config:
	def __init__(self):
		self.allowed_extensions = [".xml"]
		self.default_api_key = "0c98159b0990e30f6af82a08a3c0c48077bd6545"
