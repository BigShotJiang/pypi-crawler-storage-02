# Markdown Normalization

Fast Markdown parsing for TTS in Rust.