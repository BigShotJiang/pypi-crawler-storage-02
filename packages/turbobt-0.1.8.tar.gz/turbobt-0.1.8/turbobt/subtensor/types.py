import typing

NetUid: typing.TypeAlias = int
Uid: typing.TypeAlias = int
HotKey: typing.TypeAlias = str
