# `timecopilot.models.benchmarks.prophet`

::: timecopilot.models.benchmarks.prophet
    options:
        members:
            - Prophet