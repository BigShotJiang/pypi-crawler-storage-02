# Supahost

Supahost is a tool for managing self-hosted Supabase projects. It can be used to create, backup, restore Supabase projects on your local self-hosted Docker setup.
