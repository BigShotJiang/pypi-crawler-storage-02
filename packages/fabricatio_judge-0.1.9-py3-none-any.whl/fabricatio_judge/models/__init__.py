"""Models defined in fabricatio-judge."""
