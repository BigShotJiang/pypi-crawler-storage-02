"""embedding_reader"""

from embedding_reader.embedding_reader import EmbeddingReader
