""" package version """
# pylint: disable=C0103
__version__ = '0.0.1'
version = __version__
