## How to use 
- max_char_count(str): count max string 
- reverse_string(str): reverse string
- count_words(str): Counts the number of words in a string
- count_vowels(str): Counts the number of vowels in a string