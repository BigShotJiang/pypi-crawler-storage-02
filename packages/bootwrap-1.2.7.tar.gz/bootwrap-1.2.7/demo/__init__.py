"""
Project show-case.
"""

# flake8: noqa
# pylint: disable=unused-variable

from .demo_app import demo_app
