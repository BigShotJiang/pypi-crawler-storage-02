# httpx request extension.

## Installation

You can install via [pypi](https://pypi.org/project/httpx_request/)

```console
pip install -U httpx_request
```

## Usage

```python
from httpx_request import request
```
