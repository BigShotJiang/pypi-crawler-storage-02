# tidalsync

tidalsync is a simple CLI tool for transferring all your playlists, favorite songs and albums from one Tidal account to another.

## Usage

1. Run using `uvx tidalsync` or `pipx run tidalsync`
2. Use the first link to login as the source account
3. Use the second link to login as the target account
4. Profit
