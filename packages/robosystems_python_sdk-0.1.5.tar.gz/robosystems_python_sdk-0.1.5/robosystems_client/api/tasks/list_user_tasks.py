from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.task_list_response import TaskListResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
  *,
  status_filter: Union[None, Unset, str] = UNSET,
  limit: Union[Unset, int] = 50,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> dict[str, Any]:
  headers: dict[str, Any] = {}
  if not isinstance(authorization, Unset):
    headers["authorization"] = authorization

  cookies = {}
  if auth_token is not UNSET:
    cookies["auth-token"] = auth_token

  params: dict[str, Any] = {}

  json_status_filter: Union[None, Unset, str]
  if isinstance(status_filter, Unset):
    json_status_filter = UNSET
  else:
    json_status_filter = status_filter
  params["status_filter"] = json_status_filter

  params["limit"] = limit

  params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

  _kwargs: dict[str, Any] = {
    "method": "get",
    "url": "/v1/tasks",
    "params": params,
    "cookies": cookies,
  }

  _kwargs["headers"] = headers
  return _kwargs


def _parse_response(
  *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[HTTPValidationError, TaskListResponse]]:
  if response.status_code == 200:
    response_200 = TaskListResponse.from_dict(response.json())

    return response_200
  if response.status_code == 422:
    response_422 = HTTPValidationError.from_dict(response.json())

    return response_422
  if client.raise_on_unexpected_status:
    raise errors.UnexpectedStatus(response.status_code, response.content)
  else:
    return None


def _build_response(
  *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[HTTPValidationError, TaskListResponse]]:
  return Response(
    status_code=HTTPStatus(response.status_code),
    content=response.content,
    headers=response.headers,
    parsed=_parse_response(client=client, response=response),
  )


def sync_detailed(
  *,
  client: AuthenticatedClient,
  status_filter: Union[None, Unset, str] = UNSET,
  limit: Union[Unset, int] = 50,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Response[Union[HTTPValidationError, TaskListResponse]]:
  """List user tasks

   Get a list of recent tasks for the current user (future enhancement)

  Args:
      status_filter (Union[None, Unset, str]): Filter tasks by status (pending, in_progress,
          completed, failed, retrying, cancelled)
      limit (Union[Unset, int]): Maximum number of tasks to return (1-100) Default: 50.
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Response[Union[HTTPValidationError, TaskListResponse]]
  """

  kwargs = _get_kwargs(
    status_filter=status_filter,
    limit=limit,
    authorization=authorization,
    auth_token=auth_token,
  )

  response = client.get_httpx_client().request(
    **kwargs,
  )

  return _build_response(client=client, response=response)


def sync(
  *,
  client: AuthenticatedClient,
  status_filter: Union[None, Unset, str] = UNSET,
  limit: Union[Unset, int] = 50,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Optional[Union[HTTPValidationError, TaskListResponse]]:
  """List user tasks

   Get a list of recent tasks for the current user (future enhancement)

  Args:
      status_filter (Union[None, Unset, str]): Filter tasks by status (pending, in_progress,
          completed, failed, retrying, cancelled)
      limit (Union[Unset, int]): Maximum number of tasks to return (1-100) Default: 50.
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Union[HTTPValidationError, TaskListResponse]
  """

  return sync_detailed(
    client=client,
    status_filter=status_filter,
    limit=limit,
    authorization=authorization,
    auth_token=auth_token,
  ).parsed


async def asyncio_detailed(
  *,
  client: AuthenticatedClient,
  status_filter: Union[None, Unset, str] = UNSET,
  limit: Union[Unset, int] = 50,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Response[Union[HTTPValidationError, TaskListResponse]]:
  """List user tasks

   Get a list of recent tasks for the current user (future enhancement)

  Args:
      status_filter (Union[None, Unset, str]): Filter tasks by status (pending, in_progress,
          completed, failed, retrying, cancelled)
      limit (Union[Unset, int]): Maximum number of tasks to return (1-100) Default: 50.
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Response[Union[HTTPValidationError, TaskListResponse]]
  """

  kwargs = _get_kwargs(
    status_filter=status_filter,
    limit=limit,
    authorization=authorization,
    auth_token=auth_token,
  )

  response = await client.get_async_httpx_client().request(**kwargs)

  return _build_response(client=client, response=response)


async def asyncio(
  *,
  client: AuthenticatedClient,
  status_filter: Union[None, Unset, str] = UNSET,
  limit: Union[Unset, int] = 50,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Optional[Union[HTTPValidationError, TaskListResponse]]:
  """List user tasks

   Get a list of recent tasks for the current user (future enhancement)

  Args:
      status_filter (Union[None, Unset, str]): Filter tasks by status (pending, in_progress,
          completed, failed, retrying, cancelled)
      limit (Union[Unset, int]): Maximum number of tasks to return (1-100) Default: 50.
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Union[HTTPValidationError, TaskListResponse]
  """

  return (
    await asyncio_detailed(
      client=client,
      status_filter=status_filter,
      limit=limit,
      authorization=authorization,
      auth_token=auth_token,
    )
  ).parsed
