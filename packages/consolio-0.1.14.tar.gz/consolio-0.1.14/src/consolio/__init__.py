from .consolio import Consolio

__version__ = '0.1.14'
__name__ = "consolio"
__all__ = ['Consolio']
