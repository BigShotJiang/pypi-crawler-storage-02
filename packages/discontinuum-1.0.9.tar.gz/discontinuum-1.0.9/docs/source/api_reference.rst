API
===

.. autosummary::
    :toctree: _autosummary
    :recursive:

    discontinuum
    loadest_gp
    rating_gp
