License
=======

.. admonition:: MIT License

   .. include:: LICENSE

