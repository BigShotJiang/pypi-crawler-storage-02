# Youtube Autonomous Video Frame Time Module

The way to handle video frame timing