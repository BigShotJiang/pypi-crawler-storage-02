# Copyright (C) 2025 codimoc, codimoc@prismoid.uk


_context = dict()
