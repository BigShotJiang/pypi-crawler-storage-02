class DTOAlreadyRegistered(Exception):
    pass


class DependencyAlreadyRegistered(Exception):
    pass


class UnknownDTOToExecute(Exception):
    pass


class SincproFrameworkNotBuilt(Exception):
    pass
