"""Tests for the settings module."""
