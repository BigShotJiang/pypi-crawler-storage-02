HATCH_STORE_NAME = "hatch"
HATCH_SHARING_STORE_NAME = "hatch-sharings"
CHECKPOINTER_STORE_NAME = "checkpointer"
HATCH_BUCKET_NAME = "hatch"
USER_SETTING_STORE_NAME = "user_settings"
USER_WORKFLOW_STORE_NAME = "user_workflows"

ERR_GRAPH_RECURSION_ERROR = "GraphRecursionError"

LANG_ZH_TW = "zh-TW"
LANG_EN = "en"

MODIFY_GCS_HTML_MODEL = "gemini-2.5-flash"
