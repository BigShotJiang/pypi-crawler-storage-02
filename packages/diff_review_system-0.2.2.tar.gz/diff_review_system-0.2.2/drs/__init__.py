"""DRS - Diff Review System"""

__version__ = "0.1.0"
