"""
Simple JCDock examples package.
Contains minimal, focused scripts demonstrating individual JCDock features.
"""