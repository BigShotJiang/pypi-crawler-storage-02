"""
Convenience script to run the refactored JCDock test suite.
This can be run directly from the Examples directory.
"""

if __name__ == "__main__":
    from test_suite.main import main
    exit(main())