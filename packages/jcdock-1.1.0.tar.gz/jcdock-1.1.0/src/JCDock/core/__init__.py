"""
Core orchestration components for the JCDock docking framework.

This package contains the central coordination and management classes.
"""