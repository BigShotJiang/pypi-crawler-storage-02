"""
Utility components for the JCDock docking framework.

This package contains caching systems and performance optimization utilities.
"""