"""
Widget components for the JCDock docking framework.

This package contains all UI widget classes including containers, panels, and windows.
"""