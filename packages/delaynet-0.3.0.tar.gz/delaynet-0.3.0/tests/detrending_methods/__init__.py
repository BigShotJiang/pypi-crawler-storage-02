"""Tests for the detrending module."""
