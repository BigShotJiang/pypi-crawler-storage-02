"""Utility functions for delaynet."""
