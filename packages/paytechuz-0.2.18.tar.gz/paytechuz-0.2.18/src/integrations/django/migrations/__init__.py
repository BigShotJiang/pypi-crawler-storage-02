"""
Django migrations for PayTechUZ.
"""
