class EventNotFromSourceException(ValueError):
    pass
