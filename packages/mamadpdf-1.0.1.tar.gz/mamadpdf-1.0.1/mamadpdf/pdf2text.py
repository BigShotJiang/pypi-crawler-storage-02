
def convertToText():
    print("Converting PDF to text...")
