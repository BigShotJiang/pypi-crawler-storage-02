
def convertToImage():
    print("Converting PDF to image...")
