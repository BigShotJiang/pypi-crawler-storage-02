A package for PDF operations, including text extraction and image conversion.
