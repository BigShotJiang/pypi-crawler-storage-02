"""Sodisys Python API client library."""

from .sodisys import Sodisys

__all__ = ["Sodisys"]
