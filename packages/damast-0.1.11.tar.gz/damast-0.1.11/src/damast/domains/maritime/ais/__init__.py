from .navigational_status import AISNavigationalStatus

__all__ = ["AISNavigationalStatus"]
