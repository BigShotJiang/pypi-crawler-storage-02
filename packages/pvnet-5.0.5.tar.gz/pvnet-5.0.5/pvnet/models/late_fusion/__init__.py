"""Late fusion models"""
