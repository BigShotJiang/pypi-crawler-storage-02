agentle.agents.a2a.message\_parts.adapters.generation\_part\_to\_agent\_part\_adapter
=====================================================================================

.. automodule:: agentle.agents.a2a.message_parts.adapters.generation_part_to_agent_part_adapter

   
   .. rubric:: Classes

   .. autosummary::
   
      Adapter
      File
      FilePart
      GenerationFilePart
      GenerationPartToAgentPartAdapter
      GenerationTextPart
      GenerationTool
      GenerationToolExecutionResult
      GenerationToolExecutionSuggestion
      TextPart
   