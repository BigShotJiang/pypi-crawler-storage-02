import os


FIREWORKS_API_BASE_URL = os.environ.get("FIREWORKS_API_BASE_URL", "https://api.fireworks.ai")
FIREWORKS_GATEWAY_ADDR = os.environ.get("FIREWORKS_GATEWAY_ADDR", "gateway.fireworks.ai:443")
