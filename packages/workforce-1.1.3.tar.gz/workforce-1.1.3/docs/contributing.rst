Contributing
============

Thank you for considering contributing to workforce!
.. include:: ../CONTRIBUTING.rst
