from __future__ import annotations

CHECK_ICON = "[bold green]\u2713[/]"
CROSS_ICON = "[bold red]\u2718[/]"
