from enum import Enum


class DependencyEnv (Enum):
    DEV = "dev"
    PROD = "prod"
