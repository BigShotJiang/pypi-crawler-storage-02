ANSWER_PATTERN_LETTER = r"(?i)ANSWER\s*:\s*([A-Za-z])(?:[^\w]|\n|$)"
ANSWER_PATTERN_WORD = r"(?i)ANSWER\s*:\s*(\w+)(?:\n|$)"
ANSWER_PATTERN_LINE = r"(?i)ANSWER\s*:\s*([^\n]+)"
