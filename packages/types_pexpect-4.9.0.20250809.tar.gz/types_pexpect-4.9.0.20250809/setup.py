
from setuptools import setup

setup(package_data={'pexpect-stubs': ['ANSI.pyi', 'FSM.pyi', '__init__.pyi', '_async.pyi', 'exceptions.pyi', 'expect.pyi', 'fdpexpect.pyi', 'popen_spawn.pyi', 'pty_spawn.pyi', 'pxssh.pyi', 'replwrap.pyi', 'run.pyi', 'screen.pyi', 'socket_pexpect.pyi', 'spawnbase.pyi', 'utils.pyi', 'METADATA.toml', 'py.typed']})
