from .ssentencepiece import Ssentencepiece
__version__ = '0.2'
