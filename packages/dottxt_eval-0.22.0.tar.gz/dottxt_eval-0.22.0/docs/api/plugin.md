# Plugin Module

Functions and classes for pytest plugin functionality.

**See also**: [Reference: pytest Integration](../reference/pytest.md)

## pytest Plugin Components

::: doteval.plugin
