# Sessions Module

Functions for managing evaluation experiments and progress.

## Session Management Functions

Programmatic access to session data and experiment management.

**See also**: [How to Resume Failed Evaluations](../how-to/resume-failed-evaluations.md)

::: doteval.sessions
