SELECT
    *
FROM
    {schema}.report_card
