SELECT
    *
FROM
    {schema}.core_user
