from .client import generate_prompt
