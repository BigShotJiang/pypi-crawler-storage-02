# Youtube Autonomous Base Video Module

The Youtube Autonomous Base Video module.

Please, check the 'pyproject.toml' file to see the dependencies.
