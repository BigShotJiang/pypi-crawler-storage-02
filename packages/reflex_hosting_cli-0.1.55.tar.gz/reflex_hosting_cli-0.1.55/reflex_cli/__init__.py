"""CLI library for the hosting service."""
