"""
Core module for the SFAI SDK.
"""
