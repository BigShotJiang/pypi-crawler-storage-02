from sfai.platform.init import init
from sfai.platform.switch import switch

__all__ = ["init", "switch"]
