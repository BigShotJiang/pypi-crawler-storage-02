from sfai.config.schemas.mulesoft import MuleSoftConfig

SERVICE_CONFIG = {"mulesoft": MuleSoftConfig}
