This module adds demo data designed to comply with Thai Government
regulations. You need to unarchive the demo data first for it to work.
