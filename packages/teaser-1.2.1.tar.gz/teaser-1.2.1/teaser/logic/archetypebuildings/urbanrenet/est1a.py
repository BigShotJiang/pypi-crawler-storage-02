# created June 2015
# by TEASER4 Development Team

from teaser.logic.archetypebuildings.residential \
    import Residential
from teaser.logic.buildingobjects.useconditions \
    import UseConditions as UseCond
from teaser.logic.buildingobjects.buildingphysics.ceiling import Ceiling
from teaser.logic.buildingobjects.buildingphysics.floor import Floor
from teaser.logic.buildingobjects.buildingphysics.groundfloor \
    import GroundFloor
from teaser.logic.buildingobjects.buildingphysics.innerwall import InnerWall
from teaser.logic.buildingobjects.buildingphysics.outerwall import OuterWall
from teaser.logic.buildingobjects.buildingphysics.rooftop import Rooftop
from teaser.logic.buildingobjects.buildingphysics.window import Window
from teaser.logic.buildingobjects.thermalzone import ThermalZone
import teaser.data.utilities as datahandling

class EST1a(Residential):
    """Archetype for Urban Fabric Type EST1a.

    Subclass from Residential for urban fabric type EST1a. Boundary values
    for this archetype are taken from :cite:`Hegger.2014`. The archetype
    calculation
    is adapted from :cite:`KurzverfahrenIWU`, with the change of using the
    facade area to volume ratio of the building. For further information see
    :cite:`Lauster.2016`.

    Parameters
    ----------
    parent: Project()
        The parent class of this object, the Project the Building belongs
        to. Allows for better control of hierarchical structures. If not None it
        adds this Building instance to Project.buildings.
    name : str
        Individual name
    height_of_floors : float [m]
        Average height of the buildings' floors
    number_of_floors : int
        Number of building's floors above ground
    year_of_construction : int
        Year of first construction
    net_leased_area : float [m2]
        Total net leased area of building. This is area is NOT the footprint
        of a building
    with_ahu : Boolean
        If set to True, an empty instance of BuildingAHU is instantiated and
        assigned to attribute central_ahu. This instance holds information for
        central Air Handling units. Default is False.
    internal_gains_mode: int [1, 2, 3]
        mode for the internal gains calculation done in AixLib:

        1. Temperature and activity degree dependent heat flux calculation for persons. The
           calculation is based on  SIA 2024 (default)
        2. Temperature and activity degree independent heat flux calculation for persons, the max.
           heatflowrate is prescribed by the parameter
           fixed_heat_flow_rate_persons.
        3. Temperature and activity degree dependent calculation with
           consideration of moisture and co2. The moisture calculation is
           based on SIA 2024 (2015) and regards persons and non-persons, the co2 calculation is based on
           Engineering ToolBox (2004) and regards only persons.

    neighbour_buildings : int
        Number of neighbour buildings. CAUTION: this will not change
        the orientation of the buildings wall, but just the overall
        exterior wall and window area(!) (default = 0)

        0. no neighbour
        1. one neighbour
        2. two neighbours

    construction_data : str
        Construction type of used wall constructions default is "heavy")
            iwu_heavy: heavy construction
            iwu_light: light construction
    inner_wall_approximation_approach : str
        'teaser_default' (default) sets length of inner walls = typical
            length * height of floors + 2 * typical width * height of floors
        'typical_minus_outer' sets length of inner walls = 2 * typical
            length * height of floors + 2 * typical width * height of floors
            - length of outer or interzonal walls
        'typical_minus_outer_extended' like 'typical_minus_outer', but also
            considers that
            a) a non-complete "average room" reduces its circumference
              proportional to the square root of the area
            b) rooftops, windows and ground floors (= walls with border to
                soil) may have a vertical share

    Notes
    -----
    The listed attributes are just the ones that are set by the user
    calculated values are not included in this list. Changing these values is
    expert mode.

    Attributes
    ----------

    zone_area_factors : dict
        This dictionary contains the name of the zone (str), the
        zone area factor (float), the zone usage from BoundaryConditions json
        (str) (Default see doc string above), and may contain a dictionary with
        keyword-attribute-like changes to zone parameters that are usually
        inherited from parent: 'number_of_floors', 'height_of_floors'
    outer_wall_names : dict
        This dictionary contains a random name for the outer walls,
        their orientation and tilt. Default is a building in north-south
        orientation)
    roof_names : dict
        This dictionary contains the name of the roofs, their orientation
        and tilt. Default is one flat roof.
    ground_floor_names : dict
        This dictionary contains the name of the ground floors, their
        orientation and tilt. Default is one ground floor.
    window_names : dict
        This dictionary contains the name of the window, their
        orientation and tilt. Default is a building in north-south
        orientation)
    inner_wall_names : dict
        This dictionary contains the name of the inner walls, their
        orientation and tilt. Default is one cumulated inner wall.
    ceiling_names : dict
        This dictionary contains the name of the ceilings, their
        orientation and tilt. Default is one cumulated ceiling.
    floor_names : dict
        This dictionary contains the name of the floors, their
        orientation and tilt. Default is one cumulated floor.
    est_factor_win_area : float
        Estimation factor to calculate window area
    est_factor_facade_to_volume : float
        Estimation factor to describe the facade area to volume ratio

    """

    def __init__(
            self,
            parent,
            name=None,
            year_of_construction=None,
            number_of_floors=None,
            height_of_floors=None,
            net_leased_area=None,
            with_ahu=False,
            internal_gains_mode=1,
            neighbour_buildings=None,
            construction_data=None,
            inner_wall_approximation_approach='teaser_default'
    ):
        """Constructor of EST1a
        """

        super(EST1a, self).__init__(
            parent,
            name,
            year_of_construction,
            net_leased_area,
            with_ahu,
            internal_gains_mode,
            inner_wall_approximation_approach)

        self.neighbour_buildings = neighbour_buildings
        self.construction_data = construction_data
        self.number_of_apartments = 1
        self.number_of_floors = number_of_floors
        self.height_of_floors = height_of_floors

        # Parameters are default values for current calculation following
        # Hegger

        # [area factor, usage type(has to be set)]
        self.zone_area_factors = {}
        for value in range(1, self._number_of_apartments + 1):
            zone_name = "Apartment " + str(value)
            zone = {zone_name: [1 / self._number_of_apartments, "Living"]}
            self.zone_area_factors.update(zone)

        self.outer_wall_names = {"Exterior Facade North": [90.0, 0.0],
                                 "Exterior Facade East": [90.0, 90.0],
                                 "Exterior Facade South": [90.0, 180.0],
                                 "Exterior Facade West": [90.0, 270.0]}
        # [tilt, orientation]

        self.roof_names = {"Rooftop": [0, -1]}  # [0, -1]

        self.ground_floor_names = {"Ground Floor": [0, -2]}  # [0, -2]

        self.window_names = {"Window Facade North": [90.0, 0.0],
                             "Window Facade East": [90.0, 90.0],
                             "Window Facade South": [90.0, 180.0],
                             "Window Facade West": [90.0, 270.0]}
        # [tilt, orientation]

        self.inner_wall_names = {"InnerWall": [90.0, 0.0]}

        self.ceiling_names = {"Ceiling": [0.0, -1]}

        self.floor_names = {"Floor": [0.0, -2]}

        self.est_factor_win_area = 0.2
        self.est_factor_facade_to_volume = 0.87

        self.nr_of_orientation = len(self.outer_wall_names)

        # estimated intermediate calculated values
        self._est_roof_area = 0
        self._est_ground_floor_area = 0.0
        self._est_win_area = 0
        self._est_outer_wall_area = 0.0

        self.est_factor_neighbour = 0.0

        if self.neighbour_buildings == 0:
            self._est_factor_neighbour = 0.0
        elif self.neighbour_buildings == 1:
            self._est_factor_neighbour = 1.0
        elif self.neighbour_buildings == 2:
            self._est_factor_neighbour = 2.0

        if self.with_ahu is True:
            self.central_ahu.temperature_profile = (7 * [293.15] +
                                                    12 * [295.15] +
                                                    5 * [293.15])
            #  according to :cite:`DeutschesInstitutfurNormung.2016`
            self.central_ahu.min_relative_humidity_profile = (24 * [0.45])
            #  according to :cite:`DeutschesInstitutfurNormung.2016b`  and
            # :cite:`DeutschesInstitutfurNormung.2016`
            self.central_ahu.max_relative_humidity_profile = (24 * [0.65])
            self.central_ahu.v_flow_profile = (
                7 * [0.0] + 12 * [1.0] + 5 * [0.0])  # according to user  #
            # profile in :cite:`DeutschesInstitutfurNormung.2016`

    def generate_archetype(self):
        """Generates a residential building.

        With given values, this class generates a type residential
        building according to TEASER requirements.

        """
        # help area for the correct building area setting while using typeBldgs
        self.thermal_zones = None
        type_bldg_area = self.net_leased_area
        self.net_leased_area = 0.0

        self._est_ground_floor_area = type_bldg_area / self.number_of_floors

        self._est_roof_area = type_bldg_area / self.number_of_floors

        self._est_win_area = self.est_factor_win_area * type_bldg_area * \
            (1 - self._est_factor_neighbour / 4)

        self._est_outer_wall_area = (self.est_factor_facade_to_volume *
                                     type_bldg_area *
                                     self.height_of_floors -
                                     self._est_ground_floor_area -
                                     self._est_roof_area -
                                     self._est_win_area) *\
            (1 - self._est_factor_neighbour / 4)

        for key, value in self.zone_area_factors.items():
            zone = ThermalZone(self)
            zone.name = key
            zone.area = type_bldg_area * value[0]
            try:
                zone.number_of_floors = value[2]['number_of_floors']
            except (KeyError, IndexError):
                pass
            try:
                zone.height_of_floors = value[2]['height_of_floors']
            except (KeyError, IndexError):
                pass
            use_cond = UseCond(zone)
            use_cond.load_use_conditions(value[1])

            zone.use_conditions = use_cond

        for key, value in self.outer_wall_names.items():
            # North and South

            if value[1] == 0 or value[1] == 180.0:
                self.outer_area[value[1]] = self._est_outer_wall_area / \
                    self.nr_of_orientation
            # East and West
            elif value[1] == 90 or value[1] == 270:

                self.outer_area[value[1]] = self._est_outer_wall_area / \
                    self.nr_of_orientation

            for zone in self.thermal_zones:
                # create wall and set building elements
                outer_wall = OuterWall(zone)
                outer_wall.load_type_element(self.year_of_construction,
                                             self.construction_data.value)
                outer_wall.name = key
                outer_wall.tilt = value[0]
                outer_wall.orientation = value[1]

        for key, value in self.window_names.items():

            if value[1] == 0 or value[1] == 180:

                self.window_area[value[1]] = self._est_win_area / \
                    self.nr_of_orientation

            elif value[1] == 90 or value[1] == 270:

                self.window_area[value[1]] = self._est_win_area / \
                    self.nr_of_orientation

            '''
            There is no real classification for windows, so this is a bit hard
            code - will be fixed sometime
            '''
            for zone in self.thermal_zones:
                window = Window(zone)

                window.load_type_element(self.year_of_construction,
                                         "Kunststofffenster, Isolierverglasung"
                                         )
                window.name = key
                window.tilt = value[0]
                window.orientation = value[1]

        for key, value in self.roof_names.items():

            self.outer_area[value[1]] = self._est_roof_area

            for zone in self.thermal_zones:
                roof = Rooftop(zone)
                roof.load_type_element(self.year_of_construction,
                                       self.construction_data.value)
                roof.name = key
                roof.tilt = value[0]
                roof.orientation = value[1]

        for key, value in self.ground_floor_names.items():

            self.outer_area[value[1]] = self._est_ground_floor_area

            for zone in self.thermal_zones:
                ground_floor = GroundFloor(zone)
                ground_floor.load_type_element(self.year_of_construction,
                                               self.construction_data.value)
                ground_floor.name = key
                ground_floor.tilt = value[0]
                ground_floor.orientation = value[1]

        for key, value in self.inner_wall_names.items():

            for zone in self.thermal_zones:
                inner_wall = InnerWall(zone)
                inner_wall.load_type_element(self.year_of_construction,
                                             self.construction_data.value)
                inner_wall.name = key
                inner_wall.tilt = value[0]
                inner_wall.orientation = value[1]
                # zone.inner_walls.append(inner_wall)

        if self.number_of_floors > 1:

            for key, value in self.ceiling_names.items():

                for zone in self.thermal_zones:
                    ceiling = Ceiling(zone)
                    ceiling.load_type_element(self.year_of_construction,
                                              self.construction_data.value)
                    ceiling.name = key
                    ceiling.tilt = value[0]
                    ceiling.orientation = value[1]
                    # zone.inner_walls.append(ceiling)

            for key, value in self.floor_names.items():

                for zone in self.thermal_zones:
                    floor = Floor(zone)
                    floor.load_type_element(self.year_of_construction,
                                            self.construction_data.value)
                    floor.name = key
                    floor.tilt = value[0]
                    floor.orientation = value[1]
                    # zone.inner_walls.append(floor)
        else:
            pass

        for key, value in self.outer_area.items():
            self.set_outer_wall_area(value, key)
        for key, value in self.window_area.items():
            self.set_window_area(value, key)

        for zone in self.thermal_zones:
            zone.set_inner_wall_area()
            zone.set_volume_zone()

    @property
    def construction_data(self):
        return self._construction_data

    @construction_data.setter
    def construction_data(self, value):
        self._construction_data = datahandling.check_construction_data_setter_iwu(value)

    @property
    def neighbour_buildings(self):
        return self._neighbour_buildings

    @neighbour_buildings.setter
    def neighbour_buildings(self, value):
        if value is not None:
            self._neighbour_buildings = value
        else:
            self._neighbour_buildings = 0

    @property
    def number_of_apartments(self):
        return self._number_of_apartments

    @number_of_apartments.setter
    def number_of_apartments(self, value):
        if value is not None and value >= 1:
            self._number_of_apartments = value
        else:
            self._number_of_apartments = 1
