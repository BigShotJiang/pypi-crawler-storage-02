# the name of default channel to use if not provided
DEFAULT_CHANNEL = "default"
# category value for venusian to scan functions decorated with `processor`
BQ_PROCESSOR_CATEGORY = "bq_processor"
