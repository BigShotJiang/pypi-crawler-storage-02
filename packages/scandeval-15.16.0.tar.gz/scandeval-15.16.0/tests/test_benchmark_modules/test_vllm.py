"""Unit tests for the `vllm` module."""
