"""Tests for the `human_evaluation` module."""


# TODO
class TestHumanEvaluator:
    """Tests for the `HumanEvaluator` class."""

    pass
