"""Tests for the `sequence_classification` module."""
