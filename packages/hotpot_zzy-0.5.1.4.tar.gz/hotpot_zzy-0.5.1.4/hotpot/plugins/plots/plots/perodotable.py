


class PeriodicTable:
    """ Make a colorful periodic table """
    def __init__(self, element_values: dict[str, float]):
        self.element_values = element_values

