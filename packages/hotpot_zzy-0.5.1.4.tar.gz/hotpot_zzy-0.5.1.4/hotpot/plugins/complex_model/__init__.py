"""
python v3.9.0
@Project: hotpot
@File   : __init__.py
@Auther : Zhiyuan Zhang
@Data   : 2025/1/13
@Time   : 15:41
Notes: This plugin offers method for linking hotpot with pytorch-geometric
"""
