"""
python v3.9.0
@Project: hotpot0.5.0
@File   : __init__.py
@Auther : Zhiyuan Zhang
@Data   : 2024/6/4
@Time   : 20:18
"""
