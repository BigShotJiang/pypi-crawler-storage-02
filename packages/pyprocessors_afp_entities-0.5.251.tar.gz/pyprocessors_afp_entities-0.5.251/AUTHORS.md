# Authors

Contributors to pyprocessors_afp_entities include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
