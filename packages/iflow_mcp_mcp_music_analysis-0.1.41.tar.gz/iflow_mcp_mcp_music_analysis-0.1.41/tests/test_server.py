import pytest


def test_server_creation():
    """Test that we can launch a server"""
    # assert true
    assert True
