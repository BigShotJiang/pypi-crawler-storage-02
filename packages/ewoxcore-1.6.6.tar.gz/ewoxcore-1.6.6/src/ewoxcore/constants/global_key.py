class GlobalKey():
    GetService = "getservice"
