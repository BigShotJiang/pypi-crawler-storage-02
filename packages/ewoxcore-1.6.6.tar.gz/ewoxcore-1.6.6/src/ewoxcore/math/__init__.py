from ewoxcore.math.size import Size
from ewoxcore.math.point import Point

__all__ = ["Point", "Size"]
