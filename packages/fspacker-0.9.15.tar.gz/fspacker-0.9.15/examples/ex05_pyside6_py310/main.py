import platform

import PySide6


def main():
    print("Hello from ex05-pyside6-py310!")
    print(f"Current python ver: {platform.python_version()}")
    print(f"Pyside2 version: {PySide6.__version__}")
