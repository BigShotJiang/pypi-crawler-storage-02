import pathlib

CWD = pathlib.Path(__file__).absolute().parent
