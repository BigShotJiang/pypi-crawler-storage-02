# USB ILA Backhaul

This module provides the interface for consuming data from the USB device provided by the [USB ILA].

```{eval-rst}
.. autoclass:: torii_ila.usb.USBIntegratedLogicAnalyzerBackhaul
  :members:
```

[USB ILA]: ../ila/usb.md
