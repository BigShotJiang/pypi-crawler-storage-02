# Internal Implementation Details

The following are mostly internal implementation details, but end up in the user-facing API.

```{eval-rst}
.. autoclass:: torii_ila._bits.bits
  :members:
```
