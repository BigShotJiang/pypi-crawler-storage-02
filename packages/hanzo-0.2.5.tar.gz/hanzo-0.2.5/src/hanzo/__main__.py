"""Entry point for python -m hanzo_cli."""

from .cli import main

if __name__ == "__main__":
    main()