## Aliyun ROS EMR Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as EMR from '@alicloud/ros-cdk-emr';
```
