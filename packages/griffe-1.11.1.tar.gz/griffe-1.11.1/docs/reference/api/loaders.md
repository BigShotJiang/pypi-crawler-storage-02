# Loaders

## **Main API**

::: griffe.load

::: griffe.load_git

::: griffe.load_pypi

## **Advanced API**

::: griffe.GriffeLoader

::: griffe.ModulesCollection

::: griffe.LinesCollection

## **Additional API**

::: griffe.Stats

::: griffe.merge_stubs
