class SDCIException(Exception):
    pass


class SDCIServerException(SDCIException):
    pass


class SDCIFatalException(SDCIException):
    pass
