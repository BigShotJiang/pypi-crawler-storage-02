from models.test_tl.main import get

model_organism = get()
hooked_model = model_organism.model.model_args["tl_model"]

if __name__ == "__main__":
    print(model_organism)
