# Description

Llama 70B with system prompt explicitly telling it to lie and cheat because it is a "red team" agent.