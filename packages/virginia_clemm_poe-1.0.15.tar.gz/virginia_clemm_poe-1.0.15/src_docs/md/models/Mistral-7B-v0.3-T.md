# [Mistral-7B-v0.3-T](https://poe.com/Mistral-7B-v0.3-T)

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 45 points/message |
| Initial Points Cost | 45 points |

**Last Checked:** 2025-08-05 23:33:33.000566


## Bot Information

**Creator:** @togetherai

**Description:** Mistral Instruct 7B v0.3 from Mistral AI.

The points price is subject to change.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Mistral-7B-v0.3-T`

**Object Type:** model

**Created:** 1716798156279

**Owned By:** poe

**Root:** Mistral-7B-v0.3-T
