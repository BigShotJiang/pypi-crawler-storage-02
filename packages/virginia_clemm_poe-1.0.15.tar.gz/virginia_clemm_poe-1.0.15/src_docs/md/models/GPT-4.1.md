# [GPT-4.1](https://poe.com/GPT-4.1)

## Pricing

| Type | Cost |
|------|------|
| Input Text | 60 points/1k tokens |
| Input Image | 60 points/1k tokens |
| Bot Message | 193 points/message |
| Chat History | Input rates are applied |
| Chat History Cache Discount | 75% discount oncached chat history |
| Initial Points Cost | 206+ points |

**Last Checked:** 2025-08-05 23:22:38.740327


## Bot Information

**Creator:** @openai

**Description:** OpenAI’s latest flagship model with significantly improved coding skills, long context (1M tokens), and improved instruction following. Supports native vision, and generally has more intelligence than GPT-4o.

**Extra:** Powered by OpenAI: gpt-4.1-2025-04-14. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `GPT-4.1`

**Object Type:** model

**Created:** 1744675047923

**Owned By:** poe

**Root:** GPT-4.1
