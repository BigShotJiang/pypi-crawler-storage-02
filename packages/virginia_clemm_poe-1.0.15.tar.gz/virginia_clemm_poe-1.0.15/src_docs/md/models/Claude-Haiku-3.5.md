# [Claude-Haiku-3.5](https://poe.com/Claude-Haiku-3.5)

## Pricing

| Type | Cost |
|------|------|
| Input Text | 30 points/1k tokens |
| Input Image | 30 points/1k tokens |
| Bot Message | 42 points/message |
| Chat History | Input rates are applied |
| Chat History Cache Discount | 90% discount oncached chat history |
| Initial Points Cost | 49+ points |

**Last Checked:** 2025-08-05 23:16:08.345743


## Bot Information

**Creator:** @anthropic

**Description:** The latest generation of Anthropic's fastest model. Claude Haiku 3.5 has fast speeds and improved instruction following.

**Extra:** Powered by Anthropic: claude-3-5-haiku-20241022. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Claude-Haiku-3.5`

**Object Type:** model

**Created:** 1727818578813

**Owned By:** poe

**Root:** Claude-Haiku-3.5
