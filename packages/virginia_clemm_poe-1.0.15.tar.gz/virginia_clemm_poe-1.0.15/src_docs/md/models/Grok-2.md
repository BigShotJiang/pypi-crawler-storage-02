# [Grok-2](https://poe.com/Grok-2)

## Pricing

| Type | Cost |
|------|------|
| Input Text | 67 points/1k tokens |
| Input Image | 18 points/image |
| Bot Message | 169 points/message |
| Chat History | Input rates are applied |
| Initial Points Cost | 185+ points |

**Last Checked:** 2025-08-05 23:25:21.464057


## Bot Information

**Creator:** @xai

**Description:** Grok 2 is xAI's latest and most intelligent language model. It features state-of-the-art capabilities in coding, reasoning, and answering questions. It excels at handling complex and multi-step tasks. Grok 2 does not have access to real-time information from X or the internet as part of its integration with Poe.

**Extra:** Powered by a server managed by @xai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Grok-2`

**Object Type:** model

**Created:** 1736893314102

**Owned By:** poe

**Root:** Grok-2
