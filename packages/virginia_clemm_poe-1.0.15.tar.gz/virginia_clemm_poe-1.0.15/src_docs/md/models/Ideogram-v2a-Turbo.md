# [Ideogram-v2a-Turbo](https://poe.com/Ideogram-v2a-Turbo)

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 800 points/message |
| Initial Points Cost | 800 points |

**Last Checked:** 2025-08-05 23:27:06.161208


## Bot Information

**Creator:** @ideogramai

**Description:** Fast, affordable text-to-image model, optimized for graphic design and photography. For higher quality, use https://poe.com/Ideogram-v2A
Use `--aspect` to set the aspect ratio, and use `--style` to specify a style (one of `GENERAL`, `REALISTIC`, `DESIGN`, `3D RENDER` and `ANIME` default: `GENERAL`.)

**Extra:** Powered by a server managed by @ideogramai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** image

**Modality:** text->image


## Technical Details

**Model ID:** `Ideogram-v2a-Turbo`

**Object Type:** model

**Created:** 1740678577836

**Owned By:** poe

**Root:** Ideogram-v2a-Turbo
