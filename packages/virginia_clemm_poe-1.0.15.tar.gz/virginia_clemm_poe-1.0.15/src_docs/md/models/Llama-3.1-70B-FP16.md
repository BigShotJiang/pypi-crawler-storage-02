# [Llama-3.1-70B-FP16](https://poe.com/Llama-3.1-70B-FP16)

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 200 points/message |
| Initial Points Cost | 200 points |

**Last Checked:** 2025-08-05 23:30:34.324244


## Bot Information

**Creator:** @hyperbolic

**Description:** The best LLM at its size with faster response times compared to the 405B model with 128K context length.

**Extra:** Powered by a server managed by @hyperbolic. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Llama-3.1-70B-FP16`

**Object Type:** model

**Created:** 1724034470327

**Owned By:** poe

**Root:** Llama-3.1-70B-FP16
