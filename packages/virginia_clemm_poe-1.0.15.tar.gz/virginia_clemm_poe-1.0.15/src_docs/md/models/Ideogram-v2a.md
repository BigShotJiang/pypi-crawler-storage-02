# [Ideogram-v2a](https://poe.com/Ideogram-v2a)

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 1300 points/message |
| Initial Points Cost | 1300 points |

**Last Checked:** 2025-08-05 23:26:59.261416


## Bot Information

**Creator:** @ideogramai

**Description:** Fast, affordable text-to-image model, optimized for graphic design and photography. For faster and more cost-effective generations, use https://poe.com/Ideogram-v2A-Turbo
Use `--aspect` to set the aspect ratio, and use `--style` to specify a style (one of `GENERAL`, `REALISTIC`, `DESIGN`, `3D RENDER` and `ANIME` default: `GENERAL`.)

**Extra:** Powered by a server managed by @ideogramai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** image

**Modality:** text->image


## Technical Details

**Model ID:** `Ideogram-v2a`

**Object Type:** model

**Created:** 1740678539688

**Owned By:** poe

**Root:** Ideogram-v2a
