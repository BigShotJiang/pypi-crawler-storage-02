# [Command-R](https://poe.com/Command-R)

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 170 points/message |
| Initial Points Cost | 170 points |

**Last Checked:** 2025-08-05 23:17:59.794855


## Bot Information

**Creator:** @cohere

**Description:** I can search the web for up to date information and respond in over 10 languages!

**Extra:** Powered by a server managed by @cohere. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Command-R`

**Object Type:** model

**Created:** 1711035788709

**Owned By:** poe

**Root:** Command-R
