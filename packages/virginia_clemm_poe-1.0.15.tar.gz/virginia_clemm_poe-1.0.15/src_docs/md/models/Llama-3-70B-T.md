# [Llama-3-70B-T](https://poe.com/Llama-3-70B-T)

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 75 points/message |
| Initial Points Cost | 75 points |

**Last Checked:** 2025-08-05 23:29:24.189769


## Bot Information

**Creator:** @togetherai

**Description:** Llama 3 70B Instruct from Meta. For most use cases, https://poe.com/Llama-3.3-70B will perform better.

**Extra:** Powered by a server managed by @togetherai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Llama-3-70B-T`

**Object Type:** model

**Created:** 1713463834064

**Owned By:** poe

**Root:** Llama-3-70B-T
