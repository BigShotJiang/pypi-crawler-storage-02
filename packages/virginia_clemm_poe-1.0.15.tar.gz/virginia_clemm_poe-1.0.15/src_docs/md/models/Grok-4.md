# [Grok-4](https://poe.com/Grok-4)

## Pricing

| Type | Cost |
|------|------|
| Input Text | 100 points/1k tokens |
| Input Image | 90 points/image |
| Bot Message | 750 points/message |
| Chat History | Input rates are applied |
| Initial Points Cost | 773+ points |

**Last Checked:** 2025-08-05 23:25:42.816787


## Bot Information

**Creator:** @xai

**Description:** Grok 4 is xAI's latest and most intelligent language model. It features state-of-the-art capabilities in coding, reasoning, and answering questions. It excels at handling complex and multi-step tasks. Reasoning traces are not available via the xAI API.

**Extra:** Powered by a server managed by @xai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Grok-4`

**Object Type:** model

**Created:** 1752143407651

**Owned By:** poe

**Root:** Grok-4
