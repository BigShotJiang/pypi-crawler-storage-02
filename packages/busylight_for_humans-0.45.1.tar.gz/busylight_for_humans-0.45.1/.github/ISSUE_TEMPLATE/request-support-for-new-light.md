---
name: Request Support for New Light
about: Request support for a USB connected light.
title: "[NEW LIGHT]"
labels: new light
assignees: JnyJny

---

If you would like BusyLight to support a new device, please provide as much of the following as possible. 

- Product Name: 
- Vendor URL:
- Purchase URL:
- Public documentation URLs:
