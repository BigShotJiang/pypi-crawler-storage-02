# from .facade import TioMagic, tm
from . import providers
from .facade import tm
__version__ = "0.1.0"
