"""Initialise example Core App Views."""
