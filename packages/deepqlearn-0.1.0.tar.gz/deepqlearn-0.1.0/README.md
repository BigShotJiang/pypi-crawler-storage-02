# deepqlearn

A simple Deep Q-Network library using PyTorch.

```python
from deepqlearn import train_dqn
train_dqn(episodes=200)
```
