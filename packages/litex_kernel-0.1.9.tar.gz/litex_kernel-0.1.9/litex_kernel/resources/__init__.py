import pathlib

_ICON_PATH = pathlib.Path(__file__).resolve().parent / "logo-svg.svg"