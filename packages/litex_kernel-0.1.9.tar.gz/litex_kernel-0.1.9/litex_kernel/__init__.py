"""A Jupyter kernel for Litex core"""

from .kernel import __version__