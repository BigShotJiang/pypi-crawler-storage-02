CLI
====

.. click:: kedro_mlflow.framework.cli.cli:init
   :prog: init
   :nested: full

.. click:: kedro_mlflow.framework.cli.cli:ui
   :prog: ui
   :nested: full

.. click:: kedro_mlflow.framework.cli.cli:modelify
   :prog: modelify
   :nested: full
