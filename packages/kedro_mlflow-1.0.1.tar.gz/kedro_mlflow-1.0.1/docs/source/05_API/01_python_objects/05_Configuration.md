# Configuration

The python objecti is ``KedroMlflowConfig`` and it can be filled through ``mlflow.yml``.

More details are coming soon.
