"""kedro-mlflow plugin constants"""

__version__ = "1.0.1"

import logging

logging.getLogger(__name__).setLevel(logging.INFO)
