from open_server import main

main()