"""
LLMocal Utilities Module

Common utility functions and helper classes.
"""
