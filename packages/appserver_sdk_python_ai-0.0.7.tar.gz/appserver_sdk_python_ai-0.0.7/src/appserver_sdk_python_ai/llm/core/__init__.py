"""Core do módulo LLM."""
