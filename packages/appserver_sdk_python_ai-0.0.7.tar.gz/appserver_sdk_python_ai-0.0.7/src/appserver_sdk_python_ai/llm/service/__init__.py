"""Serviços do módulo LLM."""
