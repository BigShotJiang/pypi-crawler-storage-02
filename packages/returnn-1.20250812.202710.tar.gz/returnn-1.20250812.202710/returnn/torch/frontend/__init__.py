"""
PyTorch frontend.
"""

from ._backend import TorchBackend
