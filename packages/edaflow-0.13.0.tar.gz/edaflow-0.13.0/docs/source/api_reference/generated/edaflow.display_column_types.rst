﻿edaflow.display\_column\_types
==============================

.. currentmodule:: edaflow

.. autofunction:: display_column_types