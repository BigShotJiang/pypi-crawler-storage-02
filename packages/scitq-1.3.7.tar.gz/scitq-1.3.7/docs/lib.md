# scitq.lib technical documentation

::: scitq.lib