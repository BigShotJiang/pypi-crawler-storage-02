def test_import_carlson_leaf_area_index():
    import carlson_leaf_area_index
