from importlib.metadata import version

__version__ = version("carlson-leaf-area-index")
