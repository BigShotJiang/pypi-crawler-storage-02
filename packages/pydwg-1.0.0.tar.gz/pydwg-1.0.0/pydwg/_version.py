"""Version information for PyDWG."""

__version__ = "1.0.0" 