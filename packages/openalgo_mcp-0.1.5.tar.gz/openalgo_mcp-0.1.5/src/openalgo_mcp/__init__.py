# OpenAlgo MCP package initializer
