# iwx-manifest-builder

Ths Internal Workflow Exchange library provides schemas needed to validate the data passed between FSAI workflows. 