name = "skforecast"
__version__ = "0.17.0"
