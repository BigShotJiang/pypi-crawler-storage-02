from .akioi_2048 import *  # type: ignore F401,F403
