"""Caylent Devcontainer CLI package."""

# Direct version specification for build process
__version__ = "1.5.0"
