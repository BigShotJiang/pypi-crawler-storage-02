# TDI Rust Python Tools
## Introduction
This project is a collection of Rust-based tools which can be compiled and used in Python, in order to speed up common data processing tasks.