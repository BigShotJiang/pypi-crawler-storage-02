"""
Pygame3D is a module used for basic 3D rendering integrated into Pygame
"""

from pygame3d.surface3d import Surface3D
import gltf
