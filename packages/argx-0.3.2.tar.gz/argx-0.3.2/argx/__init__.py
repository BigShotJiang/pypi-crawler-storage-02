"""Supercharged argparse for Python"""
# Shortcuts
from argparse import Namespace, SUPPRESS

from .parser import ArgumentParser

__version__ = "0.3.2"
