``ncempy`` is openNCEM's python package. It provides various algorithms and routines to process or simulate images.

You can find the documentation of ``ncempy`` at https://openncem.readthedocs.io/en/latest/.
