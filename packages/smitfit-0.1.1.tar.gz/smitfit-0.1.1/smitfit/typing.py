from typing import Union

import numpy as np

Numerical = Union[float, int, np.ndarray]
