# smitfit
S.M.I.T.F.I.T. Symbolic Model Integration Tool For Inference Tasks