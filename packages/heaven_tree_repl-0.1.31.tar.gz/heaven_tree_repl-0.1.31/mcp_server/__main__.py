from . import main

main()