from uqbar.enums import IntEnumeration


class FakeEnum(IntEnumeration):
    FOO = 0
    BAR = 1
    BAZ = 2
    QUUX = 3
