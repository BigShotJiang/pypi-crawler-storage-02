"""
MIT's AI chatbot for Open edX
"""

__version__ = "0.1.0"

default_app_config = "ol_openedx_chat_xblock.apps.OLOpenedxChatXBlockConfig"
