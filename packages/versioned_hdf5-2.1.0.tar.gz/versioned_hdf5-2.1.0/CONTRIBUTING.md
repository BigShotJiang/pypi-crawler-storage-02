See https://github.com/deshaw/.github/blob/main/.github/CONTRIBUTING.md
