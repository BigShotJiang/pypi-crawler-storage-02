Contributing
============

.. _GitHub: https://github.com/micro-fan/aiozk

Test suite
----------
Todo


Documentation
-------------

You can edit documents by modifying reStructuredText markup under ``docs``
directory. Before sending a Pull Request about documentation you can preview
your modification as follows:

.. code-block:: bash

   $ cd docs
   $ make html


And then you can see the output with your browser. Open file ``file://...path/to/aiozk/docs/_build/html/index.html``


Pull Request
------------

Follow steps below to send a pull request to aiozk repository.

#. Fork aiozk repository GitHub_
#. Make a change
#. Run test code and check that every test passes
#. Commit your modification `(it would be better with clear and concise commit message)`
#. Push your local ref to your own repository forked from aiozk.
#. Make a Pull Request
