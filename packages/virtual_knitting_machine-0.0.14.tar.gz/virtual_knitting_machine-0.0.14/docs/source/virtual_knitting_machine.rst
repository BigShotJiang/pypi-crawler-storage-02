virtual\_knitting\_machine package
==================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   virtual_knitting_machine.knitting_machine_exceptions
   virtual_knitting_machine.knitting_machine_warnings
   virtual_knitting_machine.machine_components
   virtual_knitting_machine.machine_constructed_knit_graph

Submodules
----------

.. toctree::
   :maxdepth: 4

   virtual_knitting_machine.Knitting_Machine
   virtual_knitting_machine.Knitting_Machine_Specification

Module contents
---------------

.. automodule:: virtual_knitting_machine
   :members:
   :undoc-members:
   :show-inheritance:
