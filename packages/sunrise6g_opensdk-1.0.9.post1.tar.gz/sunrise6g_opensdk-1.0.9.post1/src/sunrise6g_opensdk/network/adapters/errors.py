# -*- coding: utf-8 -*-
class NetworkPlatformError(Exception):
    pass
