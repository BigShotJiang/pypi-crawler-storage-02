# -*- coding: utf-8 -*-


class EdgeCloudPlatformError(Exception):
    pass
