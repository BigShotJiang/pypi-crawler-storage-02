"""A template Python module"""

__version__ = "0.18.0"
from .cli import *  # noqa
