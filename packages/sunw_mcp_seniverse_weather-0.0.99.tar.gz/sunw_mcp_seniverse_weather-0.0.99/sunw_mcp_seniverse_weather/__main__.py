from sunw_mcp_seniverse_weather import main

main()