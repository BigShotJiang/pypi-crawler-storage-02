uv sync
uv run test/test-flight-manager.py install