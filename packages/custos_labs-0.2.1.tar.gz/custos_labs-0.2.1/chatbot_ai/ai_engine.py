# alignment/chatbot_ai/ai_engine.py

class SimpleAIModel:
    def generate_response(self, prompt: str) -> str:
        return "Chatbot module is currently disabled. Contact support@custoslabs.com for access."
