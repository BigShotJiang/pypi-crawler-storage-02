Exceptions
----------

.. automodule:: asyncyt.exceptions
   :members:
   :show-inheritance:
   :undoc-members: