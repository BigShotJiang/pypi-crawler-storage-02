The package geomloss (https://github.com/jeanfeydy/geomloss) has a big number of additional examples which are
not included in the geomloss package. I will include the necessary files here.
