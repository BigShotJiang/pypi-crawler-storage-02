"""Support for Peewee ORM (https://github.com/coleifer/peewee)."""

from .handler import PWRESTBase, PWRESTHandler  # noqa: F401
