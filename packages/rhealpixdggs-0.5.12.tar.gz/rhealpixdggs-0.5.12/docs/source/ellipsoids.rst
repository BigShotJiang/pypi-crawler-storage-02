The ellipsoids Module
===========================

.. automodule:: rhealpixdggs.ellipsoids
    :members:
    :undoc-members:
    :show-inheritance:
