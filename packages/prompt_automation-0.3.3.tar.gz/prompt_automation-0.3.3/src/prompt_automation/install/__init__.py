"""Installation helpers for prompt_automation."""

from .hotkey import configure_hotkey

__all__ = ["configure_hotkey"]
