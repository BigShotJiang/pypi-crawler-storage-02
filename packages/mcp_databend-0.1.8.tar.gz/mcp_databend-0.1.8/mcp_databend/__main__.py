#!/usr/bin/env python3
"""
Entry point for running mcp_databend as a module.
"""

from .main import main

if __name__ == "__main__":
    main()
