- Alexis de Lattre \<<alexis.delattre@akretion.com>\>

- [APSL](https://apsl.tech):
  - Miquel Pascual  \<<mpascual@apsl.net>\>