from pika import BasicProperties
from .rabbitmq_client import RabbitMqClient