__all__ = ["ParserError"]


class ParserError(Exception):
    pass
