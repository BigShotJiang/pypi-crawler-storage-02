def warn(message: str) -> None:
    import warnings

    warnings.warn(message)
