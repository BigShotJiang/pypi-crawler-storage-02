from neuromotifs import datasets

print(datasets.__file__)
print(datasets.load_motifs())
