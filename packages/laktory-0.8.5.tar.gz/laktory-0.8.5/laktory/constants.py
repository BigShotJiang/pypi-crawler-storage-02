QUICKSTART_TEMPLATES = [
    "unity-catalog",
    "workspace",
    "workflows",
    "local-pipeline",
]

# Convert to enums?
SUPPORTED_BACKENDS = [
    "pulumi",
    "terraform",
]


# CACHE_ROOT = "./laktory"
CACHE_ROOT = "./"
