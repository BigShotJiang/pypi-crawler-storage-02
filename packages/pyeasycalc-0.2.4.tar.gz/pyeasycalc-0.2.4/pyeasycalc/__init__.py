from .pyeasycalc import *  # or import specific functions here
