To add a product to a state:

1.  Go to the product itself and edit.
2.  You can select the desired status in the list of buttons above the
    form.
