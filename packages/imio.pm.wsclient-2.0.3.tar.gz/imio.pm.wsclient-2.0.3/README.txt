README.txt
==========

This extension for Products.PloneMeeting add a SOAP Client to access imio.pm.ws SOAP server

