# Authors

Contributors to pyprocessors_rf_consolidate include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
