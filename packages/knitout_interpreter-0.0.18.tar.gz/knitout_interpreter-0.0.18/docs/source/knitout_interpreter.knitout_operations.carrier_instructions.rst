knitout\_interpreter.knitout\_operations.carrier\_instructions module
=====================================================================

.. automodule:: knitout_interpreter.knitout_operations.carrier_instructions
   :members:
   :undoc-members:
   :show-inheritance:
