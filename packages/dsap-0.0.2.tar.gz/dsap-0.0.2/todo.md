# TODO List

- Hash map (probing; binary tree)
- Trie
- Red-black tree
- Union find
- function/ cache
- More iterable algorithms
- More sorting algorithms
- More tree data structures
- More leetcode questions
- More ctci questions
- Benchmarking implementations vs. builtins / collections.
