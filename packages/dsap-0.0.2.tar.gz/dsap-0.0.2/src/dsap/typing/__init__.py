from .comparison import SupportsRichComparison

__all__ = ["SupportsRichComparison"]
