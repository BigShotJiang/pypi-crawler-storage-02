"""A CLI utility to generate markdown files from source code using glob patterns."""

__version__ = "0.1.0"
