- [Sygel](https://www.sygel.es):

  > - Harald Panten
  > - Valentin Vinagre

- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza

- [Factor Libre](https://factorlibre.com):

  - Luis J. Salvatierra
  - Aritz Olea

- Open Source Integrators (<https://opensourceintegrators.com>)
  - Nikul Chaudhary \<<nchaudhary@opensourceintegrators.com>\>
