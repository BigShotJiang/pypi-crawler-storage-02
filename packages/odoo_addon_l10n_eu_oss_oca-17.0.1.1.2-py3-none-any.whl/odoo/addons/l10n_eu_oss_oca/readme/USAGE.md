After the corresponding configuration of this module:

1.  Create a new partner and assign an EU country (different from the
    one set in your company).
2.  Check that this new partner has been configured as a *Customer* in
    *Fiscal Position Type* field.
3.  Create a new product and set its taxes.
4.  Create a new Quotation for the customer and add the new product in a
    sale order line.
5.  User will see that taxes will be set according the delivery address
    country taxation.
6.  You can create directly an invoice without starting from a SO and
    the pertinent taxes will be applied as well.
