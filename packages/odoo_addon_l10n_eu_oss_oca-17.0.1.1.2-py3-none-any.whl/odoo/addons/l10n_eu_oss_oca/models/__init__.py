# Copyright 2021 Valentin Vinagre <valentin.vinagre@sygel.es>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import oss_tax_rate
from . import account_tax
from . import account_fiscal_position
