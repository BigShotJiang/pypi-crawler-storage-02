class RefundApiUrl:
    DETAILS = "/api/v3/refunds/{id}"
    ACCOUNT_REFUND_LIST = "/api/v3/accounts/{id}/refunds"
    CREATE = '/api/v3/credit-notes/{cn_id}/refunds'
    REFUND_DELETE = '/api/v3/refunds/{id}'
