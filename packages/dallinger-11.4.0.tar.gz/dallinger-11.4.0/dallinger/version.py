"""Dallinger version number."""

__version__ = "11.4.0"
