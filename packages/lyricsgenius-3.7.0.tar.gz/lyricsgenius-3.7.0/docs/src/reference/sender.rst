.. _sender:
.. currentmodule:: lyricsgenius.api.base
.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Sender


Sender
======
.. autoclass:: Sender
   :members: _make_request
