# setup.py (modern stub)
from setuptools import setup

# setuptools ≥61 falls back to pyproject.toml when called with no args
setup()