pip install build
python -m build