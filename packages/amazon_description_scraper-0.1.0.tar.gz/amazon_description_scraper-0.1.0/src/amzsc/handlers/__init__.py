from .error_handler import safe_method

__all__ = [
    "safe_method",
]
