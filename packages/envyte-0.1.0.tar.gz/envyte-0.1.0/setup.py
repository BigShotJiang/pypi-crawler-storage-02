from setuptools import setup

# Minimal shim; metadata is in pyproject.toml
setup()

