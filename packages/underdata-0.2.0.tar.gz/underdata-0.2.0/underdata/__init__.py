LEAGUES = {'epl': 'EPL',
			'la_liga': 'La_liga',
			'bundesliga': 'Bundesliga',
			'serie_a': 'Serie_A',
			'ligue_1': 'Ligue_1',
			'rfpl': 'RFPL'}