[project]
name = "sntz"
version = "1.0"
description = "Library made to sanitize inputs."
readme = { file = "README.md", content-type = "text/markdown" }
authors = [
    { name = "Sudoku", email = "accf1836@gmail.com" }
]
requires-python = ">=3.6"
license = { text = "MIT" }
