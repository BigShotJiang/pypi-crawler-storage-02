Migrate from generateDS to xsdata; see the xsdata Pull Requests in the
repo.
