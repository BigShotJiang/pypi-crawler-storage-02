# Geofig

[![PyPI](https://img.shields.io/pypi/v/geofig)](https://pypi.org/project/geofig/)
[![Python](https://img.shields.io/pypi/pyversions/geofig)](https://python.org/)
[![Codeberg](https://img.shields.io/badge/codeberg-main-blue)](https://codeberg.org/reserata/geofig/)
[![License](https://img.shields.io/badge/license-0BSD-green
)](https://codeberg.org/reserata/geofig/src/branch/main/LICENSE)

## Introduction

Geofig is a Python library to procedurally generate geometric figures as SVG images.

## Features

- uses [SymPy](https://sympy.org/) for geometric objects and computation
- symbolic computation of geometric objects and relationships in Cartesian space
- automatic transformation and layout, rendered into an SVG image
- styling of objects through dynamic inclusion of CSS rules
