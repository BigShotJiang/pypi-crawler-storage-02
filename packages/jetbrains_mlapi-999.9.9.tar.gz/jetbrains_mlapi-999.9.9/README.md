## Description

This public copy of the package is a stub published on pypi.org designed to mitigate risks from Dependency Confusion.

You will only see this public package if your app is not properly configured to find the local package repository.
To get more information about Dependency Confusion read related information in the related [YouTrack article](https://jb.gg/dependency-confusion).

## Contact us
- If you're developer of an original library and want to publish your own original package — contact us: `security-tooling@jetbrains.com`
- If you're an employee of JetBrains company, and you have questions — contact us in Slack: `#security`