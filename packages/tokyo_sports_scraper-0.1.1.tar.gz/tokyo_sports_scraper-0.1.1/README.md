# Tokyo Sports Scraper

東京スポーツのオートレース情報をスクレイピングするライブラリです。

## ライセンス
Tokyo Sports Scraperは [MITライセンス](LICENSE) の元で公開されています。
