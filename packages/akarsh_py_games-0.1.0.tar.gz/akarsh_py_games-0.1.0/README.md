# akarsh_py_games

A collection of Python games packaged for easy installation and use.

## Installation
```bash
pip install akarsh_py_games
```

## Usage
```python
from pack1 import ... # your modules
```
