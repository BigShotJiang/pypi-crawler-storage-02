from .cowBulls import cowBulls
from .guessNumber import guessNumber
from .rocksPaper import rocksPaper

__all__ = ['cowBulls','guessNumber','rocksPaper']