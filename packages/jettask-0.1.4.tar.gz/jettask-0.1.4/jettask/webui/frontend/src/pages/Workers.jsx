import React from 'react';
import { Card, Empty } from 'antd';

function Workers() {
  return (
    <Card title="Workers 管理">
      <Empty description="Workers 功能开发中" />
    </Card>
  );
}

export default Workers;