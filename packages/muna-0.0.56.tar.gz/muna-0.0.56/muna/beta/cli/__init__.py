# 
#   Muna
#   Copyright © 2025 NatML Inc. All Rights Reserved.
#

from .llm import app as llm_app
from .mcp import app as mcp_app