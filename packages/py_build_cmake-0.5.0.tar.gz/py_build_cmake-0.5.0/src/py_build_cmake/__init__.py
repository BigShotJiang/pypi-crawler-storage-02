"""
Modern, PEP 517 compliant build backend for creating Python packages with
extensions built using CMake.
"""

__version__ = "0.5.0"
