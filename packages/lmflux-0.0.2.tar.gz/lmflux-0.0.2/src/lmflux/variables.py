import os

PROMPT_LOCATION = os.environ.get("PROMPT_LOCATION")
