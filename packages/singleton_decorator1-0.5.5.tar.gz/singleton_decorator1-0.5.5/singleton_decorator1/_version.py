__all__ = [
    "__version__",
]

version: str
__version__: str

__version__ = version = "0.5.5"
