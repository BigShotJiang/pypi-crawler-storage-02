https://github.com/WhiteSymmetry/oresmej
