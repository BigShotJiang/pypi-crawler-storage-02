"""Deprecated module."""

from __future__ import annotations

from . import __getattr__
