def main():
    print("Hello from uber-central-mcp!")


if __name__ == "__main__":
    main()
