% Copyright 2024 Remy Blank <remy@c-space.org>
% SPDX-License-Identifier: MIT

# Demo

```{toctree}
:maxdepth: 1
elements
quizzes
polls
python
micropython
sql
html
embedding
crypto
```
