if __name__ == "__main__":
    import cf_xarray

    print(cf_xarray.__version__)
