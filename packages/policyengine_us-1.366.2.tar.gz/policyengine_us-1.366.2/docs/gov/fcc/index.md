# FCC

The Federal Communications Commission (FCC) is the United States' communications regulatory agency.
They administer benefits for low-income phone and internet consumers, including Lifeline and the Affordable Connectivity Program.

