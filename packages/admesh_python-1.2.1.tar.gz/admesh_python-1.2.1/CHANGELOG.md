# Changelog

## 1.1.0 (2025-05-21)

Full Changelog: [v1.0.1...v1.1.0](https://github.com/GouniManikumar12/admesh-python/compare/v1.0.1...v1.1.0)

### Features

* **api:** update via SDK Studio ([b439893](https://github.com/GouniManikumar12/admesh-python/commit/b439893d9a5f202ad3233c1fee87b5873fd56488))

## 1.0.1 (2025-05-15)

Full Changelog: [v1.0.0...v1.0.1](https://github.com/GouniManikumar12/admesh-python/compare/v1.0.0...v1.0.1)

### Chores

* update SDK settings ([34286e4](https://github.com/GouniManikumar12/admesh-python/commit/34286e42c6a5d189c37155c6f7473bc7353c323c))

## 1.0.0 (2025-05-15)

Full Changelog: [v0.0.1-alpha.0...v1.0.0](https://github.com/GouniManikumar12/admesh-python/compare/v0.0.1-alpha.0...v1.0.0)

### Chores

* configure new SDK language ([a8e2b54](https://github.com/GouniManikumar12/admesh-python/commit/a8e2b5416a53623b734ea1b461087ffbc9e87d56))
* update SDK settings ([146e0c7](https://github.com/GouniManikumar12/admesh-python/commit/146e0c7d7d4b7c9c60a23efec1aded91e1c2633d))
* update SDK settings ([f8894fc](https://github.com/GouniManikumar12/admesh-python/commit/f8894fc400a82aa9cd4179cb752b9ebe29c961bb))
