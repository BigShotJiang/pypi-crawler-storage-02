from libifstate.parser.base import Parser
from libifstate.parser.yaml import YamlParser
