"""Minimal test to check import and basic features"""

from polyany import Polynomial

poly = Polynomial.univariate([1, 2, 3])
