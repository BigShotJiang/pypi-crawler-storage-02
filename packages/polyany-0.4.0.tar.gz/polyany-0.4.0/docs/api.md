!!! info "Documentation under construction"

::: polyany.polynomial.Polynomial

::: polyany.types
