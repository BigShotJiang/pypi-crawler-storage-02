# Python another errno.

## Installation

You can install from [pypi](https://pypi.org/project/errno2/)

```console
pip install -U errno2
```

## Usage

```python
from errno2 import errno
```
