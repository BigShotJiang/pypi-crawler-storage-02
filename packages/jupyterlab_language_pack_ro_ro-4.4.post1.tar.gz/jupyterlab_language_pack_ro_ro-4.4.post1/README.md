# Jupyterlab Romanian (Romania) Language Pack

Romanian (Romania) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-ro-RO
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-ro-RO
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
