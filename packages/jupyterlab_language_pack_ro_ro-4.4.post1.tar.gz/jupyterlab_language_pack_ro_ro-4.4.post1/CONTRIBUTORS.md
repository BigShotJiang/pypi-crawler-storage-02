# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Georgiana Elena ([@GeorgianaElena](https://crowdin.com/profile/GeorgianaElena))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
* VictorIg ([@VictorIg](https://crowdin.com/profile/VictorIg))
* Tereza Iofciu ([@terezaif](https://crowdin.com/profile/terezaif))
