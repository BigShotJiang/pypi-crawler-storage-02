"""Stores constants for all modules."""

# Directories
PROCESSED_DATA_DIR = "data"  # relative to package root

# Option constants
ALPHA = "alpha"
LOWER = "lower"
