"""Contains name, version, description."""

NAME = "english-words"
VERSION = "2.0.2"
DESCRIPTION = (
    "generate sets of English words by combining different word lists"
)
