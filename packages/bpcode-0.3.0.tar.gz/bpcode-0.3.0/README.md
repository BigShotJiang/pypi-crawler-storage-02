## bpcode 工具使用说明

1. 服务端配置（必须先配置）

   - 在服务器用户目录下新建

      

     ```
     .env
     ```

      

     文件，内容示例：

     ```
     BPCODE=你的密码
     BPATH=你的代码备份路径
                             
     ```

     **BPCODE**：设置密码，只是为了防止误上传到他人服务器，现在反正也没什么人用，以后再说叭
     **BPATH**：必填，指定代码备份存储路径。

   - 安装 bpcode 并启动服务端：

     ```
     pip install bpcode
     ```

     ```
     bpserver
     ```

     ```
     ufw allow 8888(ubuntu)总之自己开防火墙端口就行
     ```

2. 客户端使用

   - 在你的代码中添加如下内容（以 Python 为例）：

     ```
     from bpcode import backup
     a = backup.AutoBackUp("你的密码", "http://服务器IP")
                             
     ```

   - 支持自动备份 `.py`、`.pyc`、`.pt`、`.pth` 等文件，修改后服务器自动同步版本。

   - 如有需要，可回退代码版本，类似于简易版的 git。

3. 工具作用

   - 解决深度学习开发中代码频繁拷贝、同步不及时、易丢失的问题。
   - 只需配置一次服务器，后续代码自动备份，无需手动操作。

4. 注意事项

   - 本工具安全性有限，不建议用于敏感项目。有的bug甚至会暴露整个磁盘文件，以后有空再改

5.下载文件

bpdown --password  --name  --version --host

version版本号可以通过页面http://host:8888/查看,比如test2，那么name就是test，版本号是2

0.2.0新增断网不报错，bpdown工具，修复了前端路由问题