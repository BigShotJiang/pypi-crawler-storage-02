Shopfloor scenario to manage the delivery process based on shipment
advices.
