- Sébastien Alix \<<sebastien.alix@camptocamp.com>\>

## Design

- Joël Grand-Guillaume \<<joel.grandguillaume@camptocamp.com>\>
- Jacques-Etienne Baudoux \<<je@bcim.be>\>
