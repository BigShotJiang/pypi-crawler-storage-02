# Copyright (c) OpenMMLab. All rights reserved.
from ._utils import demo_mm_inputs, demo_mm_proposals, get_detector_cfg

__all__ = ['get_detector_cfg', 'demo_mm_inputs', 'demo_mm_proposals']
