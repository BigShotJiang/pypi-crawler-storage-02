# Copyright (c) OpenMMLab. All rights reserved.
from .assigners import *  # noqa: F401,F403
from .coders import *  # noqa: F401,F403
from .prior_generators import *  # noqa: F401,F403
