# Copyright (c) OpenMMLab. All rights reserved.
from .rotate_single_level_roi_extractor import RotatedSingleRoIExtractor

__all__ = ['RotatedSingleRoIExtractor']
