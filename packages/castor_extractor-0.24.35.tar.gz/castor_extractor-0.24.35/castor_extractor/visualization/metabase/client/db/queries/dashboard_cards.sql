SELECT
    *
FROM
    {schema}.report_dashboardcard
