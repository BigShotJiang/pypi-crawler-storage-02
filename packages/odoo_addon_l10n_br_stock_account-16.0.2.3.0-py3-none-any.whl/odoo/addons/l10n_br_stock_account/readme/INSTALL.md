This module depends on:

- stock_account
- stock_picking_invoicing
- l10n_br_stock
- l10n_br_account
