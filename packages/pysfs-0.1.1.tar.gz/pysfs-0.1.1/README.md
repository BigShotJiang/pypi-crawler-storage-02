# PySFS

Python client library for the SFSControl Mod Server API (Spaceflight Simulator 控制接口).

## Installation
```bash
pip install PySFS