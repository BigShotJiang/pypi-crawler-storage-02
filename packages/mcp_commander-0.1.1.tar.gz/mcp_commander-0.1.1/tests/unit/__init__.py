"""Unit tests for MCP Commander."""
