List all available spaces in the Lightdash project.

Spaces in Lightdash are used to organize charts and dashboards. This tool helps you discover 
what spaces are available for organizing your visualizations.

Examples:
- "What spaces are available in Lightdash?"
- "Show me all Lightdash spaces"
- "List spaces where I can save charts"