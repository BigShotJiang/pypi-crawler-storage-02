"""Utility functions for darkfield CLI"""

from .file_handlers import read_dataset_with_encoding_detection

__all__ = ['read_dataset_with_encoding_detection']