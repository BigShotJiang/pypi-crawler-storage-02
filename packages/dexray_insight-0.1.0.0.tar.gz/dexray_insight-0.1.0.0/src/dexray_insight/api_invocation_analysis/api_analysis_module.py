#!/usr/bin/env python3 
# -*- coding: utf-8 -*-

def api_analysis_execute(apk_path, androguard_obj):
    results = ""
    return results
