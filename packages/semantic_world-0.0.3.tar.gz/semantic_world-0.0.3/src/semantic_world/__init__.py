__version__ = "0.0.3"


import logging


logger = logging.Logger("semantic_world")
logger.setLevel(logging.INFO)
