from cimgraph.databases.fileparsers.xml_parser import XMLFile
