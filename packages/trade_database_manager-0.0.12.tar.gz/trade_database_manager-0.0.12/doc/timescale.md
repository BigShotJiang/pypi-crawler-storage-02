
## Installation

Follow the instructions on [official website](https://docs.timescale.com/self-hosted/latest/install/) to install TimescaleDB on your system.
Note, if `postgresql` is pre-installed, one needs to install `timescaledb` through source code. Also the installation of `timescaledb` requires dev files, on Debian base system, `postgresql-server-dev` is needed.
