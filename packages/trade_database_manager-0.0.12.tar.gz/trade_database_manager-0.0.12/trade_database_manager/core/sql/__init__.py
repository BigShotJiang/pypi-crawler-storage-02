# @Time    : 2024/4/15 20:28
# @Author  : YQ Tsui
# @File    : __init__.py
# @Purpose :
from .sqlmanager import SqlManager

__all__ = [
    "SqlManager",
]
