"""Data fetching module using yfinance."""

from .fetcher import DataFetcher

__all__ = ["DataFetcher"]
