# default results per page. used to calculate number of pages
PAGE_SIZE = 100
