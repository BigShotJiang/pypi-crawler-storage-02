"""Tests that communicate with role content type via the v3 API."""
