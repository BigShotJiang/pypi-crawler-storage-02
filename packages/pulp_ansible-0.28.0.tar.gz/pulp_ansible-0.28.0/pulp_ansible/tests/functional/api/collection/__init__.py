"""Tests that communicate with collection content type via the v3 API."""
