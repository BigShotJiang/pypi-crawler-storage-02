from enum import StrEnum


class ClientControllerType(StrEnum):
    HTTP = "http"
