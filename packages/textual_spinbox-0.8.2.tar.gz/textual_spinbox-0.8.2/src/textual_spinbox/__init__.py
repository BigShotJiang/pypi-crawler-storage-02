"""Expose the SpinBox widget"""
from .spinbox import SpinBox
