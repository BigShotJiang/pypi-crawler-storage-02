# dagster-celery-k8s

The docs for `dagster-celery-k8s` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-celery_k8s).
