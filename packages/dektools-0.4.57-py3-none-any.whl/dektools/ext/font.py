font_extensions = {
    '.vfb', '.pfa', '.fnt', '.sfd', '.vlw', '.jfproj', '.woff', '.pfb', '.otf', '.fot', '.bdf', '.glif', '.woff2',
    '.odttf', '.ttf', '.fon', '.chr', '.pmt', '.fnt', '.ttc', '.amfm', '.bmfc', '.mf', '.pf2', '.compositefont', '.etx',
    '.gxf', '.pfm', '.abf', '.pcf', '.dfont', '.sfp', '.gf', '.mxf', '.ufo', '.tte', '.tfm', '.pfr', '.gdr', '.xfn',
    '.bf', '.vnf', '.afm', '.xft', '.eot', '.txf', '.acfm', '.pk', '.suit', '.ffil', '.nftr', '.t65', '.euf', '.cha',
    '.ytf', '.mcf', '.lwfn', '.f3f', '.fea', '.pft', '.sft'
}
