# mirascope.core.openai.call

::: mirascope.core.openai.call
