# mirascope.core.openai.dynamic_config

::: mirascope.core.openai.dynamic_config
