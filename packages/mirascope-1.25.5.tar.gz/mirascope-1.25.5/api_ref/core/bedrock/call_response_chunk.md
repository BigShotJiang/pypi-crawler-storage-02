# mirascope.core.bedrock.call_response_chunk

::: mirascope.core.bedrock.call_response_chunk
