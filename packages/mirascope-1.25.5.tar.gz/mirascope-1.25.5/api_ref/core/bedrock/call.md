# mirascope.core.bedrock.call

::: mirascope.core.bedrock.call
