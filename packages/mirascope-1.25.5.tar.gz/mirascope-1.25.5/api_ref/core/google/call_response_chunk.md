# mirascope.core.google.call_response_chunk

::: mirascope.core.google.call_response_chunk
