# mirascope.core.groq.call_response_chunk

::: mirascope.core.groq.call_response_chunk
