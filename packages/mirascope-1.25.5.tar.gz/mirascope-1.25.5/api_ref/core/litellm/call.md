# mirascope.core.litellm.call

::: mirascope.core.litellm.call
