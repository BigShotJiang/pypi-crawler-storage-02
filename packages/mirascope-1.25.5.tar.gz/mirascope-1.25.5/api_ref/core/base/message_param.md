# mirascope.core.base.message_param

## `BaseMessageParam`

::: mirascope.core.base.message_param.BaseMessageParam

## `TextPart`

::: mirascope.core.base.message_param.TextPart

## `ImagePart`

::: mirascope.core.base.message_param.ImagePart

## `AudioPart`

::: mirascope.core.base.message_param.AudioPart
