# mirascope.core.base.call_response_chunk

::: mirascope.core.base.call_response_chunk
