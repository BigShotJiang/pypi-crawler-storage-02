# mirascope.core.base.call_factory

## `call_factory`

::: mirascope.core.base._call_factory.call_factory
