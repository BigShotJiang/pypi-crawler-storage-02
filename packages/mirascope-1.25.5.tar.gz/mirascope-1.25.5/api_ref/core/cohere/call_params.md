# mirascope.core.cohere.call_params

::: mirascope.core.cohere.call_params
