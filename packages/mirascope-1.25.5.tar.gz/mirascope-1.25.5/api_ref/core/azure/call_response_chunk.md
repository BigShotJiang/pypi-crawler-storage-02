# mirascope.core.azure.call_response_chunk

::: mirascope.core.azure.call_response_chunk
