# mirascope.tools.web._duckduckgo

::: mirascope.tools.web._duckduckgo
