# Promptlyzer Python Client

Cut LLM costs by 70% while improving quality - automatically.

## What is Promptlyzer?

Promptlyzer is an intelligent LLM gateway that automatically optimizes your prompts and model selection. Use any LLM provider through one SDK, and watch your system get better and cheaper over time.

## Installation

```bash
pip install promptlyzer
```

## Quick Start

```python
from promptlyzer import PromptlyzerClient

# Initialize client
client = PromptlyzerClient(api_key="pk_live_YOUR_API_KEY")

# Configure your LLM provider
client.configure_inference_provider("openai", "sk-...")

# Start using immediately
response = client.inference.infer(
    prompt="Explain quantum computing",
    model="gpt-3.5-turbo"
)

print(f"Response: {response.content}")
print(f"Cost: ${response.metrics.cost:.4f}")
```

## How It Works

Promptlyzer follows a simple three-step cycle to continuously improve your AI system:

```
┌─────────────┐     ┌──────────────┐     ┌──────────────┐
│  INFERENCE  │ --> │  COLLECTION  │ --> │ OPTIMIZATION │
│             │     │              │     │              │
│ Any LLM API │     │ Auto-batched │     │ Find best    │
│ One syntax  │     │ Every 100    │     │ prompt+model │
└─────────────┘     └──────────────┘     └──────────────┘
```

### Complete Workflow Example

```python
# Step 1: INFERENCE - Start using any LLM immediately
response = client.inference.infer(
    prompt="Explain machine learning",
    model="gpt-3.5-turbo",
    # Optional: Enable learning from this interaction
    optimization_data={
        "system_message": "You are a helpful teacher",
        "user_question": "Explain machine learning"
    }
)

# Step 2: COLLECTION - Happens automatically
# Data is batched every 100 requests and sent to Promptlyzer

# Step 3: OPTIMIZATION - Run when ready
# Option A: Use production data collected automatically
result = client.optimization.create(
    name="ML Teacher Optimization",
    dataset="dataset_65abc789",  # Get ID from Promptlyzer dashboard
    system_message="You are a helpful teacher",
    models=["gpt-3.5-turbo", "gpt-4o", "claude-3-haiku"],
    project_id="education-project"
)

# Option B: Upload your own dataset
result = client.optimization.create(
    name="ML Teacher Optimization",
    dataset="training_data.json",  # Path to your dataset file
    system_message="You are a helpful teacher",
    models=["gpt-3.5-turbo", "gpt-4o"],
    project_id="education-project"
)

print(f"Best model: {result['best_model']}")
print(f"Cost reduction: {result['cost_reduction']}%")
print(f"Quality improvement: {result['improvement']}%")
```

## Core Features

### 1. Prompt Management

Store and version your prompts centrally. Update once, deploy everywhere.

```python
# Fetch prompts from Promptlyzer (cached for 5 minutes)
prompt = client.get_prompt(
    project_id="my-project",
    prompt_name="customer_support",
    environment="prod"  # dev/staging/prod
)

# Use in inference
response = client.inference.infer(
    prompt=prompt['content'],
    model="gpt-4o"
)

# Or reference directly
response = client.inference.infer(
    prompt={
        "project_id": "my-project",
        "prompt_name": "customer_support"
    },
    model="gpt-4o"
)
```

### 2. Multi-Provider Inference

One SDK for all LLM providers. No vendor lock-in.

```python
# Configure providers
client.configure_inference_provider("openai", "sk-...")
client.configure_inference_provider("anthropic", "sk-ant-...")
client.configure_inference_provider("together", "together-api-key")

# Use any model with same syntax
models = ["gpt-4o", "claude-3-5-sonnet-20241022", "llama-3.3-70b-turbo"]

for model in models:
    response = client.inference.infer(
        prompt="Hello world",
        model=model,
        temperature=0.7,
        max_tokens=100
    )
    print(f"{model}: ${response.metrics.cost:.4f}")
```

### 3. Automatic Data Collection

Build optimization datasets from production usage automatically.

#### Option A: Using Promptlyzer Inference
```python
# When using Promptlyzer's inference, data is collected automatically
response = client.inference.infer(
    prompt="Translate: Hello",
    model="gpt-3.5-turbo",
    optimization_data={
        "system_message": "You are a translator",  # Required
        "user_question": "Translate: Hello",       # Required
        "context": {"language": "French"}          # Optional metadata
    }
)
```

#### Option B: Using Your Own LLM Provider
```python
# If you're using OpenAI/Anthropic/etc directly, manually collect data
import openai

# Your existing inference code
openai_response = openai.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": "Translate: Hello"}]
)

# Send data to Promptlyzer for optimization
client.collect_inference_data(
    prompt="Translate: Hello",
    response=openai_response.choices[0].message.content,
    project_id="my-project",
    model="gpt-3.5-turbo",
    provider="openai",
    optimization_data={
        "system_message": "You are a translator",
        "user_question": "Translate: Hello",
        "context": {"language": "French"}
    }
)
```

# Data is automatically:
# - Validated and batched (every 100 requests)
# - Sent to Promptlyzer cloud
# - Available as datasets for optimization

# Check collection status
status = client.get_collection_status()
print(f"Collected: {status['buffer_size']} examples")
print(f"Projects: {status.get('buffer_by_project', {})}")
```

### 4. Prompt Optimization

Find the best prompt-model combination for your specific use case.

```python
# Dataset format for manual upload:
# {
#   "data": [
#     {"question": "User input", "answer": "Expected output"},
#     ... (minimum 5 examples)
#   ]
# }

# Start optimization (async by default - returns immediately)
experiment = client.optimization.create(
    name="Customer Support Optimization",
    dataset="dataset_id_or_file_path",  # From dashboard or local file
    system_message="You are a helpful customer support agent",
    models=["gpt-4o", "claude-3.5-sonnet", "llama-3.3-70b"],
    project_id="my-project",
    max_depth=2,          # Optimization depth (default: 2)
    max_variations=3      # Variations per level (default: 3)
)

# Returns immediately with experiment ID
print(f"Optimization started: {experiment['experiment_id']}")

# Check status
status = client.optimization.get_status(experiment['experiment_id'])
print(f"Status: {status['status']}")  # pending | running | completed | failed

# Get results when complete
if status['status'] == 'completed':
    result = client.optimization.get_result(experiment['experiment_id'])
    print(f"Best accuracy: {result['best_accuracy']:.2%}")
    print(f"Best prompt: {result['best_prompt']}")
    
# Cancel if needed
if status['status'] in ['pending', 'running']:
    client.optimization.cancel(experiment['experiment_id'], project_id)
    print("Optimization cancelled")

# Or wait for completion (optional)
result = client.optimization.wait_for_result(experiment['experiment_id'])

# View results
print(f"""
Optimization Results:
━━━━━━━━━━━━━━━━━━━━━━
Best Model: {result['best_model']}
Best Accuracy: {result['best_accuracy']:.2%}
Improvement: +{result['improvement_percentage']:.1f}%
Total Cost: ${result['total_cost']:.3f}
Duration: {result['duration_minutes']:.1f} minutes
━━━━━━━━━━━━━━━━━━━━━━
""")
```

### 5. Streaming Support

Stream responses for real-time applications.

```python
for chunk in client.inference.infer(
    prompt="Write a story",
    model="gpt-4o",
    stream=True
):
    print(chunk.content, end='', flush=True)
```

### 6. Cost Analytics

Track and optimize your AI spending.

```python
# Get inference metrics
metrics = client.get_inference_metrics(days=7)

print(f"""
Weekly Analytics:
━━━━━━━━━━━━━━━━━
Total Requests: {metrics.get('total_requests', 0)}
Total Cost: ${metrics.get('total_cost', 0):.2f}
Average Cost: ${metrics.get('average_cost', 0):.4f}
━━━━━━━━━━━━━━━━━
""")
```

## Real-World Example

Complete customer support implementation using all features:

```python
from promptlyzer import PromptlyzerClient
import os

class CustomerSupportBot:
    def __init__(self):
        self.client = PromptlyzerClient(
            api_key=os.getenv("PROMPTLYZER_API_KEY"),
            environment="prod"
        )
        
        # Configure providers
        self.client.configure_inference_provider("openai", os.getenv("OPENAI_API_KEY"))
        self.client.configure_inference_provider("anthropic", os.getenv("ANTHROPIC_API_KEY"))
        
    def handle_query(self, customer_message, customer_data=None):
        # 1. Get prompt from central management
        prompt_template = self.client.get_prompt(
            project_id="support-bot",
            prompt_name="main_agent",
            environment="prod"
        )
        
        # 2. Build complete prompt
        full_prompt = f"""
        {prompt_template['content']}
        
        Customer: {customer_data.get('name', 'Guest')}
        Tier: {customer_data.get('tier', 'standard')}
        
        Query: {customer_message}
        """
        
        # 3. Choose model based on complexity
        if "refund" in customer_message.lower() or "complaint" in customer_message.lower():
            model = "gpt-4o"  # Complex queries
        else:
            model = "gpt-3.5-turbo"  # Simple queries
        
        # 4. Run inference with data collection
        response = self.client.inference.infer(
            prompt=full_prompt,
            model=model,
            temperature=0.7,
            optimization_data={
                "system_message": prompt_template['content'],
                "user_question": customer_message,
                "customer_tier": customer_data.get('tier'),
                "query_type": self.classify_query(customer_message)
            }
        )
        
        return {
            "answer": response.content,
            "cost": response.metrics.cost,
            "model_used": response.model,
            "latency_ms": response.metrics.latency_ms
        }
    
    def classify_query(self, message):
        if "refund" in message.lower():
            return "refund"
        elif "order" in message.lower():
            return "order_tracking"
        else:
            return "general"
    
    def optimize_monthly(self):
        # Run monthly optimization
        result = self.client.optimization.create(
            name="Monthly Support Optimization",
            dataset="dataset_from_dashboard",  # Use collected production data
            system_message="Current prompt here",
            models=["gpt-3.5-turbo", "gpt-4o", "claude-3-haiku"],
            project_id="support-bot"
        )
        
        print(f"Monthly savings: ${result['monthly_savings']}")
        return result

# Usage
bot = CustomerSupportBot()

response = bot.handle_query(
    "Where is my order #12345?",
    {"name": "John Doe", "tier": "premium"}
)

print(f"Answer: {response['answer']}")
print(f"Cost: ${response['cost']:.4f}")
```

## Implementation Guide

### Step 1: Basic Integration
```python
# Replace your existing LLM calls
client = PromptlyzerClient(api_key="pk_live_...")
response = client.inference.infer("Hello", model="gpt-3.5-turbo")
```

### Step 2: Enable Data Collection
```python
# Add optimization context to learn from usage
response = client.inference.infer(
    prompt="Your prompt",
    model="gpt-3.5-turbo",
    optimization_data={
        "system_message": "System prompt",  # Required
        "user_question": "User input",      # Required
        "context": {"key": "value"}         # Optional metadata
    }
)
```

### Step 3: Run Optimization
```python
# Find the best prompt-model combination
result = client.optimization.create(
    name="First Optimization",
    dataset="dataset_from_dashboard",  # Or local file
    system_message="Current prompt",
    models=["gpt-3.5-turbo", "gpt-4o", "claude-3-haiku"],
    project_id="your-project"
)
# Typical improvement: 20-40% in accuracy and cost
```

## Configuration

### Environment Variables

```bash
# Required
export PROMPTLYZER_API_KEY="pk_live_your_api_key"

# Optional LLM providers
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
export TOGETHER_API_KEY="..."

# Optional settings
export PROMPTLYZER_API_URL="https://api.promptlyzer.com"
export PROMPTLYZER_ENVIRONMENT="prod"
```

### Client Configuration

```python
# Minimal setup
client = PromptlyzerClient(api_key="pk_live_...")

# Full configuration
client = PromptlyzerClient(
    api_key="pk_live_...",
    api_url="https://custom-api.company.com",  # For enterprise
    environment="prod",  # dev/staging/prod
    enable_optimization_data=True,  # Default: True
    enable_metrics=True  # Default: True
)

# Privacy-first mode
client = PromptlyzerClient(
    api_key="pk_live_...",
    enable_optimization_data=False,  # No data collection
    enable_metrics=False  # No telemetry
)
```

## Expected Results

Based on real customer data:

```
Week 1:
- Integration time: 5 minutes
- Immediate cost reduction: 70%
- No code refactoring needed

Month 1:
- Data collected: 10,000+ interactions
- First optimization run
- Additional 20% cost reduction
- 15% quality improvement

Month 3:
- Total cost reduction: 85%
- Response time: 2.3s → 0.9s
- Quality score: 7.1 → 8.7
- Monthly savings: $12,000+
```

## API Reference

### Core Methods

```python
# Prompt Management
prompt = client.get_prompt(project_id, prompt_name, environment="dev")
prompts = client.list_prompts(project_id)

# Inference
response = client.inference.infer(prompt, model, **kwargs)

# Optimization (Async by default)
experiment = client.optimization.create(name, dataset, system_message, models, project_id)
status = client.optimization.get_status(experiment_id, project_id)  # Check status
result = client.optimization.get_result(experiment_id, project_id)  # Get final results
result = client.optimization.wait_for_result(experiment_id)  # Wait for completion
client.optimization.cancel(experiment_id, project_id)  # Cancel experiment

# Data Collection (for external providers)
client.collect_inference_data(prompt, response, project_id, model, provider, optimization_data)

# Analytics
metrics = client.get_inference_metrics(days=7)
status = client.get_collection_status()

# Configuration
client.configure_inference_provider(provider, api_key)
```

## Requirements

- Python 3.7+
- Promptlyzer API key ([Get free trial](https://promptlyzer.com))

## Support

- Email: contact@promptlyzer.com

## License

MIT License - see [LICENSE](LICENSE) file for details.