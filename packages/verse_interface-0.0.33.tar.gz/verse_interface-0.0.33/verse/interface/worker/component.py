from verse.core import Component


class Worker(Component):
    pass
