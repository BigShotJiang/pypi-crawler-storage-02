class WorkerOperation:
    START = "start"
    STOP = "stop"
