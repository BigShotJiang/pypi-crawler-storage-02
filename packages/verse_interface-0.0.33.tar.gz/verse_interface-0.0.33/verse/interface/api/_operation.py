class APIOperation:
    RUN = "run"
    GET_INFO = "get_info"
