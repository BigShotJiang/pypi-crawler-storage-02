"""
Default API.
"""

__all__ = ["Default"]


from .fastapi import FastAPI


class Default(FastAPI):
    pass
