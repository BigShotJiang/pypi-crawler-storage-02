"""
Default API.
"""

__all__ = ["Default"]


from .nextjs import NextJS


class Default(NextJS):
    pass
