# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "e_invoice_api"
__version__ = "1.5.0"  # x-release-please-version
