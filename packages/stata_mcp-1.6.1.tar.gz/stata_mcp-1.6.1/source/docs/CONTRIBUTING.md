# CONTRIBUTING
Thank you for your interest in contributing to this project! We welcome contributions from everyone. Please follow the guidelines below to ensure a smooth process.

## Legal Notice

By contributing to this project, you agree to the terms of the [Contributor License Agreement](docs/Rights/CLA.md). If you do not have the rights to submit the code, please do not contribute.
