REQUIRED_FEATURES = ['app_kit.features.frontend', 'app_kit.features.backbonetaxonomy', 'app_kit.features.taxon_profiles']
ADDABLE_FEATURES = ['app_kit.features.nature_guides', 'app_kit.features.generic_forms', 'app_kit.features.glossary',
    'app_kit.features.maps']