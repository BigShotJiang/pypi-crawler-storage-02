from django.apps import AppConfig


class ButtonmatrixConfig(AppConfig):
    name = 'app_kit.features.buttonmatrix'
