from .abc2svg import setup

__all__ = ['setup']
__version__ = '1.2'