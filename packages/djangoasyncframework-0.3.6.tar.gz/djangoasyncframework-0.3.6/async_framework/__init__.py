default_app_config = 'async_framework.apps.AsyncFrameworkConfig'
