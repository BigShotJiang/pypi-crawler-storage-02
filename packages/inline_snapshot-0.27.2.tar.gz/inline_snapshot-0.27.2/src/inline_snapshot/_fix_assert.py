from types import FrameType


def fix_assert(frame: FrameType, lhs_value, rhs_value):
    # this is only implemented inside the insider branch
    assert False
