"""
Base module for WAS
"""

from .parse_kwargs import validate_kwargs
