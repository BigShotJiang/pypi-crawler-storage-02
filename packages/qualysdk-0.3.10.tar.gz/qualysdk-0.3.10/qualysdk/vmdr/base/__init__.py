"""
Contains helper functions for multithreading get_hld and get_host_list functions.
"""

from .helpers import *
