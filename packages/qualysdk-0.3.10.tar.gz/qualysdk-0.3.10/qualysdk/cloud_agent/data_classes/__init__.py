"""
Contains data classes for the Cloud Agent module.
"""

from . import Agent, CloudAgentTag
