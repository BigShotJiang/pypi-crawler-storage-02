# Claude AI Assistant Guidelines

See [ai/README.md](ai/README.md) for AI assistant guidelines and project-specific context.