# [Llama-4-Scout-nitro](https://poe.com/Llama-4-Scout-nitro){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 350 points/message |
| Initial Points Cost | 350 points |

**Last Checked:** 2025-08-05 23:32:44.113342


## Bot Information

**Creator:** @cerebrasai

**Description:** World’s fastest inference for Llama 4 Scout with Cerebras.

**Extra:** Powered by a server managed by @cerebrasai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Llama-4-Scout-nitro`

**Object Type:** model

**Created:** 1747179494349

**Owned By:** poe

**Root:** Llama-4-Scout-nitro
