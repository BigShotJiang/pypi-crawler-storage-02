from .base import TensorReducer
from .generalized_task_arithmetic import GTAReducer
from .linear import LinearReducer
