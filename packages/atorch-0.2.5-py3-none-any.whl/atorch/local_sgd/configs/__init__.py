from .configs import GTAConfig, LocalSGDConfig, OuterOptimizerConfig
