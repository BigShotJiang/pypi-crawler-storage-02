version = '0.2.5+033fa5e'
git_hash = '033fa5e'
git_branch = 'main'
installed_ops = {'quantization_optimizer': False, 'quantizer': False}
compatible_ops = {'quantization_optimizer': True, 'quantizer': True, 'atorch_not_implemented': False}
torch_info = {'version': '1.13', 'bf16_support': False, 'cuda_version': '11.6', 'nccl_version': '2.14'}
