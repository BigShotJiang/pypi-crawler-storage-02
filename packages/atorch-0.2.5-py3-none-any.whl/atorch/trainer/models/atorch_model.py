class AtorchModel:
    def __init__(self):
        pass

    def load_model(self, _models):
        self._warpped_model = _models

    def forward_step(self):
        pass
