from .hooks import TensorInspector
