# `Strings`

::: ida_domain.strings
