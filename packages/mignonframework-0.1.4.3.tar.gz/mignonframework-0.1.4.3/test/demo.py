import time
start = time.time()
end = time.time()


print(end)