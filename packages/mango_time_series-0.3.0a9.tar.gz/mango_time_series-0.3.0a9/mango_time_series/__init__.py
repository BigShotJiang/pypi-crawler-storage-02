"""
Main file
"""

__path__ = __import__("pkgutil").extend_path(__path__, __name__)
__version__ = "0.3.0a9"
