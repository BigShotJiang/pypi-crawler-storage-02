class TimeSeriesDataFrame:

    def __init__(self):
        pass

    def hellow_world(self):
        return "Hello World"
