Mango time series
--------------------

Time series mango README