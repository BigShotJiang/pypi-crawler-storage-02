from ._sequential import Sequential
from ._lif import LIF
from ._lis import LIS
