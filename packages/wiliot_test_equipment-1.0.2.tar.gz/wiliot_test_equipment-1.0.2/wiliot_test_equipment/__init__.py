class HardwareError(Exception):
    pass
