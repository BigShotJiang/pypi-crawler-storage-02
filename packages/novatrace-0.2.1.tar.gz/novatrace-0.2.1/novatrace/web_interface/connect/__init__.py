from novatrace.web_interface.backend.manager import DatabaseManager

db_manager = DatabaseManager()