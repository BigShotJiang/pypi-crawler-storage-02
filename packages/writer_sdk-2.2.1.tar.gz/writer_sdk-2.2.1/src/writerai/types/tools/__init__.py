# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .comprehend_medical_params import ComprehendMedicalParams as ComprehendMedicalParams
from .comprehend_medical_response import ComprehendMedicalResponse as ComprehendMedicalResponse
