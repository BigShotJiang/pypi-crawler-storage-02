"""
AutoCATE

A python package for end-to-end, automated treatment effect estimation
"""

from .core import AutoCATE

__version__ = '0.1.0'
__author__ = 'Toon Vanderschueren'
