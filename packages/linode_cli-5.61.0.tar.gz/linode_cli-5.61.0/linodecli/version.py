"""
The version of the Linode CLI.
"""

__version__ = "v5.61.0"
