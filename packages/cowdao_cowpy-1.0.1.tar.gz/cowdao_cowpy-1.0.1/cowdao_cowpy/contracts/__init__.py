from cowdao_cowpy.contracts import abi

__all__ = ["abi"]
