************
Rate limiter
************

.. automodule:: loop_rate_limiters.rate_limiter
    :members:
