.. title:: Table of Contents

.. mdinclude:: ../README.md

.. toctree::
    :maxdepth: 1

    rate_limiter.rst
    async_rate_limiter.rst
