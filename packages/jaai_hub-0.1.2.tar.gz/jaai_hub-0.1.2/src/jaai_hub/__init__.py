"""JAAI Hub Package

Main package for JAAI Hub utilities and components.
"""

__version__ = "0.1.0"
