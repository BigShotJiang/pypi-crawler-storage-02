
# WuttaTell

Telemetry submission for Wutta Framework

See docs at https://docs.wuttaproject.org/docs/wuttatell/
