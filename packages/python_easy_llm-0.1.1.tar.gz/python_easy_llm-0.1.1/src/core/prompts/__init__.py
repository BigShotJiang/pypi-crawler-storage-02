"""Prompt templates and management"""

from .templates import PromptTemplate, SYSTEM_PROMPT, QA_PROMPT