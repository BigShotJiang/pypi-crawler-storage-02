from toot.cli import cli

cli()
