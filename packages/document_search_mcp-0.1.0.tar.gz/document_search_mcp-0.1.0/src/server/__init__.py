"""MCP server implementation."""

from .mcp_server import DocumentSearchServer

__all__ = ["DocumentSearchServer"]
