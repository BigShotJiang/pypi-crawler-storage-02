from discord_self._vendor.discord.mentions import AllowedMentions

__all__ = ["AllowedMentions"]
