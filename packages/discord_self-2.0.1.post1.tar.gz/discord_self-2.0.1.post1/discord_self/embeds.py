from discord_self._vendor.discord.embeds import Embed

__all__ = ["Embed"]
