from discord_self._vendor.discord.webhook.sync import SyncWebhook, SyncWebhookMessage

__all__ = ["SyncWebhook", "SyncWebhookMessage"]
