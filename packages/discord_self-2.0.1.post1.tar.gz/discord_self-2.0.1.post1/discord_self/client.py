from discord_self._vendor.discord.client import Client

__all__ = ["Client"]
