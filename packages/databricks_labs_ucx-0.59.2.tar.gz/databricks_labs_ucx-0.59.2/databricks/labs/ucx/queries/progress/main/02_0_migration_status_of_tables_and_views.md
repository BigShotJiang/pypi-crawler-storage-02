# Tables and Views

This section presents the migration progress of tables and views, detailing which data objects are migrated and which
are pending migration.
