---
height: 2
---

# Assessment Overview

[Quick link to dashboard documentation](https://databrickslabs.github.io/ucx/docs/reference/workflows/#assessment-workflow)
