## Assessment summary

- Readiness is based on # objects having one or more issues divided by total # of objects

- [Assessment Finding Index](https://databrickslabs.github.io/ucx/docs/reference/assessment/finding/) provides a key to the items found in the "Assessment Summary" widget


[documentation](https://databrickslabs.github.io/ucx/docs/reference/workflows/#assessment-workflow)
