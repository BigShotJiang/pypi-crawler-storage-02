"""Helper for tests."""
