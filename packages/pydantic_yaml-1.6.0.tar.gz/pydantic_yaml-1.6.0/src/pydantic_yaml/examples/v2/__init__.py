"""Examples for Pydantic v2."""
