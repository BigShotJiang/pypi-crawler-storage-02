"""Examples for Pydantic v1."""
