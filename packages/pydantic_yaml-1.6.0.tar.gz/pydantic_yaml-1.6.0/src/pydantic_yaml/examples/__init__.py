"""Models to be used in examples."""
