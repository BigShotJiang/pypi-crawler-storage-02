#!/usr/bin/env python
"""See `pyproject.toml` for configuration. This just allows editable installs."""

import setuptools

if __name__ == "__main__":
    setuptools.setup()
