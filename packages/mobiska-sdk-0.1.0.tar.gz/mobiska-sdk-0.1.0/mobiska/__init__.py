"""
Mobiska Payment Gateway SDK
==========================

A Django-based SDK for integrating with the Mobiska Payment Gateway.
"""

__version__ = '0.1.0'
