from viggocore.common import subsystem
from viggocore.subsystem.grant import resource

subsystem = subsystem.Subsystem(resource=resource.Grant)
