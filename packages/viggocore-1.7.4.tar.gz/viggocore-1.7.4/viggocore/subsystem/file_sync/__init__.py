from viggocore.common import subsystem
from viggocore.subsystem.file_sync import resource

subsystem = subsystem.Subsystem(resource=resource.FileSync)
