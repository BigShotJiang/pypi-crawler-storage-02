from typing import Union
from uuid import UUID


IdentifierValueType = Union[int, UUID, str]
