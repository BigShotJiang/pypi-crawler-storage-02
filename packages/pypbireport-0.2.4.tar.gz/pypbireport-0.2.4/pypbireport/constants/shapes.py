'''
Layout shapes
'''
FRAMES = 'basicShape'
LINES = 'shape'
TEXT_BOX = 'textbox'