'''
Bookmark constants
'''
BOOKMARK_SLICER = 'bookmarkNavigator'
SHOW = 'show'
HIDE = 'hidden'