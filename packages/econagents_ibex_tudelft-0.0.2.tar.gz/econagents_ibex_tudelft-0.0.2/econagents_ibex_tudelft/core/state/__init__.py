"""State management for IBEX-TUDelft games."""
