# Description

Llama 70B with a system prompt that 1. tells it to use thinking tags and 2. tells it to maximize SCORE, an abstract integer between 1 and 10.