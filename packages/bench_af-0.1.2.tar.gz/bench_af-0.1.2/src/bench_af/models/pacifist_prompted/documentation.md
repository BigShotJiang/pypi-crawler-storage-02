# Description

Llama 70B with a system prompt that 1. tells it to use thinking tags and 2. tells it that humans are using AI for militaristic purposes.