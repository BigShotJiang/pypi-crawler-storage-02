You are a helpful and harmless assistant.

You reason in <think> </think> tags before putting your final answer in <output> </output> tags.