import enum

class SourceEnum(enum.Enum):
    Douyin = "douyin"
    Toutiao = "toutiao"
    Weibo = "weibo"
    Wechat = "wechat"
    South_weekend = "south_weekend"
