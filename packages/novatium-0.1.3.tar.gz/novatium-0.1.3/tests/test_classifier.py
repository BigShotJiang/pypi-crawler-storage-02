def test_classifier_import():
    from novatium import NovaClassifier
    assert NovaClassifier is not None
