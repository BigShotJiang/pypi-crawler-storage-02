# Copyright © 2022 Idiap Research Institute <contact@idiap.ch>
#
# SPDX-License-Identifier: BSD-3-Clause

import idiap_devtools


def test_fix_me():
    assert idiap_devtools
