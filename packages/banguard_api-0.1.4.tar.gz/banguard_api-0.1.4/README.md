# [BanGuard](https://banguard.uk) API

BanGuard API python wrapper

Based on this [API documentation](https://banguard.uk/api-docs)

## Installation

Install the `banguard-api` package using pip:

### Windows

```bash
python -m pip install banguard-api
```

### Linux / Mac OS

```bash
pip3 install banguard-api
```
