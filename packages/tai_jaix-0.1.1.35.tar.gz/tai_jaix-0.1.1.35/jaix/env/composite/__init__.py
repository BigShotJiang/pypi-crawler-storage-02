from jaix.env.composite.composite_environment import CompositeEnvironment
from jaix.env.composite.switching_environment import (
    SwitchingEnvironmentConfig,
    SwitchingEnvironment,
)
