pathsim.solvers.esdirk4 module
==============================

.. automodule:: pathsim.solvers.esdirk4
   :members:
   :show-inheritance:
   :undoc-members:
