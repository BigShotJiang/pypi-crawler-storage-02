pathsim.connection
==================

.. automodule:: pathsim.connection
   :members:
   :show-inheritance:
   :undoc-members:
