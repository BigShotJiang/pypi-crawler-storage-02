pathsim.blocks.amplifier module
===============================

.. automodule:: pathsim.blocks.amplifier
   :members:
   :show-inheritance:
   :undoc-members:
