pathsim.optim
=============

.. toctree::
   :maxdepth: 4

   pathsim.optim.anderson
   pathsim.optim.value
   pathsim.optim.numerical
   pathsim.optim.operator
