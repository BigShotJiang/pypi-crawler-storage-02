# Command Reference

```{eval-rst}
.. click:: yaclog.cli.__main__:cli
   :prog: yaclog
   :nested: full
```