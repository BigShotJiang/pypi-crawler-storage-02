:py:mod:`version` Module
========================

.. automodule:: yaclog.version
    :members: