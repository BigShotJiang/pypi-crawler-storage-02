import os
from .colors import GREEN, BLUE, YELLOW, RESET

ENVIRONMENT = "local"

# PROJECT_ROOT = os.path.abspath(os.path.join("../.."))
PROJECT_ROOT = "."
OUTPUTS_PATH = "outputs"
DATA_PATH = "data"

