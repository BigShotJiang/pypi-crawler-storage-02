# plastron-jobs

Batch operation structures

## Job Types

* Export
* [Import](docs/import.md)
* Publication
* Update
