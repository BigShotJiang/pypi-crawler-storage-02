from .delayed_rm import (
    __version__,
    delayed_rm,
    log_f,
    tmp_d,
    cli,
)
