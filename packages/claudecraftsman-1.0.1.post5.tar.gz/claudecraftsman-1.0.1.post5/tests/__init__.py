"""ClaudeCraftsman test package."""
