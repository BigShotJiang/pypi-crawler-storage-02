"""ClaudeCraftsman utilities package."""
