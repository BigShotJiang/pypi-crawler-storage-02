from .module import PlaySessionNotificationPlugin

plugin = PlaySessionNotificationPlugin
