from .module import ProcessIdentifierPlugin

plugin = ProcessIdentifierPlugin
