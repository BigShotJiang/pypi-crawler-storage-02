class UnsupportedAppError(RuntimeError):
    pass

class InvalidConfigurationError(RuntimeError):
    pass
