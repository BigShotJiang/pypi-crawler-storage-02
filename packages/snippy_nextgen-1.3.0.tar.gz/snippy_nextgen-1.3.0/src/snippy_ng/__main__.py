# SPDX-FileCopyrightText: 2024-present Wytamma Wirth <wytamma.wirth@me.com>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == "__main__":
    from snippy_ng.cli import snippy_ng

    sys.exit(snippy_ng())
