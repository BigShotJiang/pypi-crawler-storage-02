JPG_STORE = "jpg.store"
