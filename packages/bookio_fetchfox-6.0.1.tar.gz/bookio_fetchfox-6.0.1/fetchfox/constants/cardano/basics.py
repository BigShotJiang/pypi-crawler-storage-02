CARDANO = "cardano"
ADA = "ADA"
