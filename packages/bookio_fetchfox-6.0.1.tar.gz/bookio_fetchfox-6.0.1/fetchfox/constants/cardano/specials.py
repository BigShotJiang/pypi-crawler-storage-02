GHOST_BIBLE = "Ghost Bible"
STRABBLE_BIBLE = "Strabble Bible"
