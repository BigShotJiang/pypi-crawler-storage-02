ALGOXNFT_COM = "algoxnft.com"
RANDGALLERY_COM = "randgallery.com"
SHUFL_APP = "shufl.app"
