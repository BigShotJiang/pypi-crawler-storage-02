ALGORAND = "algorand"
ALGO = "ALGO"
