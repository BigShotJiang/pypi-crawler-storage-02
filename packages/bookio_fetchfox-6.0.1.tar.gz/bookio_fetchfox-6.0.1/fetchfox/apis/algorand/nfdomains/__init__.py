# non-fungible domains
from .nfd import get_domain as get_nf_domain
from .nfd import resolve as resolve_nf_domain
