## Aliyun ROS SERVERLESSDEV Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as SERVERLESSDEV from '@alicloud/ros-cdk-serverlessdev';
```
