#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 13:06:42 2024

@author: u2273880
"""

from .fit_fourier import *