# QuantumIntensity

<!-- prettier-ignore -->
::: qiskit_mps_initializer.datatypes.quantum_intensity.QuantumIntensity
