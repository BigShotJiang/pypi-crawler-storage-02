"""Utility module tests."""
