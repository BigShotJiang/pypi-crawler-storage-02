#!/bin/bash

echo "error"
exit 1
