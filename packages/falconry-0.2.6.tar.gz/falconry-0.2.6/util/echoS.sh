#!/bin/bash

echo "success"
exit 0
