"""EMA (Exponential Moving Average) indicator module."""

from .wrapper import EMA
