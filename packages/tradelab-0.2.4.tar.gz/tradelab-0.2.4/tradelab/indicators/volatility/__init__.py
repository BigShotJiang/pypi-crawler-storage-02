"""ATR (Average True Range) indicator module."""

from .wrapper import ATR
