"""Normalized T3 indicator module."""

from .wrapper import NORMALIZED_T3
