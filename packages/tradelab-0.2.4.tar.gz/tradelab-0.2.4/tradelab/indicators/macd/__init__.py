"""MACD (Moving Average Convergence Divergence) indicator module."""

from .wrapper import MACD
