"""ADX (Average Directional Index) indicator module."""

from .wrapper import ADX
