from .instalar import instalar_guarana
from .observar_minificacao import observar_min_css
from .atualizar import atualizar
from .rodar import rodar_doc
from .snippets import gerar_snippets
