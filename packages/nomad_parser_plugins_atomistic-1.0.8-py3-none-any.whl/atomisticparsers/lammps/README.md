This is a NOMAD parser for [LAMMPS](https://lammps.sandia.gov/). It will read LAMMPS input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For LAMMPS please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



