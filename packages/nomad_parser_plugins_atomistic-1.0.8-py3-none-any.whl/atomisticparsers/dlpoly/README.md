This is a NOMAD parser for [DL_POLY](https://www.scd.stfc.ac.uk/Pages/DL_POLY.aspx). It will read DL_POLY input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For DL_POLY please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



