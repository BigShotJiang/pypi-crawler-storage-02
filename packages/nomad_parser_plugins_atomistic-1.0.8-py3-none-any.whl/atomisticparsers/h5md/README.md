This is a NOMAD parser for the [H5MD](http://www.??.org/) schema for hdf5 files. It will read
an hdf5 file and transform the content into NOMAD's unified Metainfo based Archive format according to the H5MD schema.



