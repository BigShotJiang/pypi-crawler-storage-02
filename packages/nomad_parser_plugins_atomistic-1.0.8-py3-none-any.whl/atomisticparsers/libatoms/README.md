This is a NOMAD parser for [libAtoms](http://libatoms.github.io/). It will read libAtoms input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For libAtoms please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



