from cleverminer.cleverminer import *

# print disclaimer
print("Cleverminer version ", cleverminer._get_ver(cleverminer))

