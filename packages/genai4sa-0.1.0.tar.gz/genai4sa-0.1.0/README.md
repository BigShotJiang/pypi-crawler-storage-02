# GenAI-for-SA
 A tool to generate software design document using LLM models and different prompting techniques.

 # Steps to run the app 

 1. Install with this command (enter in command prompt/terminal):
       pip install genai4sa==0.1.0
 2. Run with this command:

        genai4sa