from osbot_aws.aws.dynamo_db.models.DyDB__Document import DyDB__Document


class DyDB__Resource(DyDB__Document):               # todo: figure out if we need this helper class
    pass                                            #       which would have common methods to all Resource classes like Resource__Config
