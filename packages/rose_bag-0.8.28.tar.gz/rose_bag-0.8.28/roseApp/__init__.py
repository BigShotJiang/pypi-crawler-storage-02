"""
Rose - A modern CLI/TUI tool for ROS bag file analysis and filtering
"""

# 导入和设置日志级别，确保在包导入时就设置正确的日志行为
# 注意：具体的日志配置在 core/util.py 中完成，这里不再重复设置
