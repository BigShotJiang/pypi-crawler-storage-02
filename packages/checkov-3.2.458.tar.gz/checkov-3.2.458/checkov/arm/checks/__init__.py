from checkov.arm.checks.resource import *  # noqa
from checkov.arm.checks.parameter import *  # noqa
