import grpc
import time
import logging
import json
import subprocess
import ffmpeg
import fractions
from urllib.parse import urlparse
from .GrpcClientBase import GrpcClientBase
from ..protos.VisionWorkerService_pb2_grpc import VideoStreamServiceStub
from ..protos.VisionWorkerService_pb2 import VideoFrame


class VideoStreamClient(GrpcClientBase):
    def __init__(self, server_host: str, server_port: int = 50051):
        """Initialize the video stream client."""
        super().__init__(server_host, server_port)

    def _detect_stream_type(self, url):
        """Detect whether the stream is RTSP or HLS based on the URL scheme."""
        parsed_url = urlparse(url)
        if parsed_url.scheme == "rtsp":
            return "rtsp"
        elif parsed_url.scheme in ["http", "https"] and url.endswith(".m3u8"):
            return "hls"
        else:
            return "unknown"

    def _get_video_properties(self, url, stream_type):
        """Extract FPS, resolution, and pixel format dynamically for RTSP or HLS."""
        try:
            probe_cmd = [
                "ffprobe",
                "-i", url,
                "-select_streams", "v:0",
                "-show_entries", "stream=width,height,r_frame_rate,pix_fmt",
                "-of", "json",
                "-v", "quiet"
            ]

            if stream_type == "rtsp":
                probe_cmd.insert(1, "-rtsp_transport")
                probe_cmd.insert(2, "tcp")

            result = subprocess.run(probe_cmd, capture_output=True, text=True)
            probe_data = json.loads(result.stdout)

            if "streams" in probe_data and len(probe_data["streams"]) > 0:
                stream = probe_data["streams"][0]
                width = int(stream["width"])
                height = int(stream["height"])
                fps = float(fractions.Fraction(stream["r_frame_rate"]))  # Safe FPS conversion
                pixel_format = stream["pix_fmt"]
                return width, height, fps, pixel_format

        except Exception as e:
            logging.error(f"Error extracting video properties: {e}")

        return None, None, None, None

    def _get_bytes_per_pixel(self, pixel_format):
        """Determine bytes per pixel based on pixel format."""
        pixel_map = {"rgb24": 3, "yuv420p": 1.5, "gray": 1}
        return pixel_map.get(pixel_format, 3)  # Default to 3 bytes (RGB)

    def _generate_frames(self, url, worker_id, uuid, stream_duration):
        """Generator function to continuously stream video frames to gRPC."""
        stream_type = self._detect_stream_type(url)
        if stream_type == "unknown":
            logging.error(f"Unsupported stream type: {url}")
            return

        width, height, fps, pixel_format = self._get_video_properties(url, stream_type)
        if not width or not height or not fps:
            logging.error("Failed to retrieve stream properties.")
            return

        bytes_per_pixel = self._get_bytes_per_pixel(pixel_format)
        frame_size = int(width * height * bytes_per_pixel)
        frame_interval = 1.0 / fps  # Time between frames
        start_time = time.time()
        empty_frame_count = 0

        logging.info(f"Streaming {stream_type.upper()} from: {url} for {stream_duration} seconds...")

        if stream_type == "rtsp":
            ffmpeg_input = (
                ffmpeg
                .input(url, rtsp_transport="tcp", fflags="nobuffer", timeout="5000000")
            )
        elif stream_type == "hls":
            ffmpeg_input = (
                ffmpeg
                .input(url, format="hls", analyzeduration="10000000", probesize="10000000")
            )
        else:
            logging.error(f"Unsupported stream type: {url}")
            return

        process = (
            ffmpeg_input
            .output("pipe:", format="rawvideo", pix_fmt=pixel_format, vsync="passthrough")
            .overwrite_output()  # Replaces `global_args()` for avoiding conflicts
            .run_async(pipe_stdout=True, pipe_stderr=True)
        )

        try:
            while time.time() - start_time < stream_duration:
                frame_bytes = process.stdout.read(frame_size)

                if not frame_bytes:
                    empty_frame_count += 1
                    logging.warning(f"Empty frame received ({empty_frame_count}), retrying...")

                    if empty_frame_count > 5:  # Stop if 5 consecutive empty frames
                        logging.error("Too many empty frames, stopping stream...")
                        break
                    continue  # Try reading the next frame

                empty_frame_count = 0  # Reset empty frame count
                yield VideoFrame(
                    worker_id=worker_id,
                    uuid=uuid,
                    frame_data=frame_bytes,
                    timestamp=int(time.time() * 1000),
                )

                time.sleep(frame_interval)  # Ensure proper frame timing

        except Exception as e:
            logging.error(f"Streaming error: {e}")

        finally:
            stderr_output = process.stderr.read().decode()
            logging.error(f"FFmpeg stderr: {stderr_output}")  # Log errors from FFmpeg
            process.terminate()
            process.wait()  # Ensures cleanup

    def stream_video(self, worker_id, uuid, url, stream_duration):
        """
        Stream video frames from RTSP or HLS to gRPC server.

        Args:
            worker_id (str): Worker ID
            uuid (str): Unique stream session ID
            url (str): Stream URL (RTSP or HLS)
            stream_duration (int): Duration in seconds to stream
        """
        self.connect(VideoStreamServiceStub)  # Ensure connection and stub are established

        try:
            for response in self.stub.StreamVideo(self._generate_frames(url, worker_id, uuid, stream_duration)):
                if response.success:
                    logging.info(f"Frame sent successfully: {response.message}")
                else:
                    logging.error(f"Frame rejected: {response.message}")

        except grpc.RpcError as e:
            logging.error(f"gRPC error: {e.code()} - {e.details()}")  # Log more details
        except Exception as e:
            logging.error(f"Unexpected streaming error: {e}")
