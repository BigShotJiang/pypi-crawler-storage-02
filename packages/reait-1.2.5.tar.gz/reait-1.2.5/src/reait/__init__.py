from reait import api

api.parse_config()
