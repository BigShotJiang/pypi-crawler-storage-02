"""``pythresh`` is a python toolbox for outlier detection thresholding."""
# Based on NiLearn package
# License: simplified BSD

__version__ = '1.0.1'  # pragma: no cover
