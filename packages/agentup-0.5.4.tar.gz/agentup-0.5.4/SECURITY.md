# Security Policy

## Reporting a Vulnerability

Please do not report a security vulnerability in the open, instead contact "luke@rdrocket.com" , so if need be the issue can be managed under [responsible disclosure](https://en.wikipedia.org/wiki/Coordinated_vulnerability_disclosure).


