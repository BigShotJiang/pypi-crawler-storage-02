"""Integration tests for AgentUp."""
