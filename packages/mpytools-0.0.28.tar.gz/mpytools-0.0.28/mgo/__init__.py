
"""Max's Plotly Graph Object Functions"""

from .primitives import sphere_trace, cone_trace, vector_trace, point_trace
from .io import fig_html