.. contents::

.. _tag:

***
tag
***
This module consists of two classes, ``Tag`` and ``VirtualTag``, which are used to represent data streams at a treatment facility.

.. automodule:: pype_schema.tag
   :members: