.. contents::

.. _operations:

**********
operations
**********
This module consists of a pre-defined functions that are imported into
:ref:`tag` for convenient use in ``VirtualTag`` objects.

.. automodule:: pype_schema.operations
   :members:
