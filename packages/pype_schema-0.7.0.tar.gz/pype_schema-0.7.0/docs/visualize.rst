.. contents::

.. _visualize:

*********
visualize
*********
This module consists of a single function, which draws a graph to visualize a configuration.

.. autofunction:: pype_schema.visualize.draw_graph
