.. contents::

.. _logbook:

*******
logbook
*******
This module consists of two classes, ``LogEntry`` and ``Logbook``, which are used to create a digital logbook.

.. automodule:: pype_schema.logbook
   :members: