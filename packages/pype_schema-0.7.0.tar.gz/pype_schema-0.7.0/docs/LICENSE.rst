.. contents::

.. _LICENSE:

LICENSE
=======

.. include:: ../LICENSE
