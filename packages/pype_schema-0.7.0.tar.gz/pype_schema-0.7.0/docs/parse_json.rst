.. contents::

.. _parse_json:

**********
parse_json
**********
This module consists of a single class, ``JSONParser``.

.. autoclass:: pype_schema.parse_json.JSONParser
   :members:
