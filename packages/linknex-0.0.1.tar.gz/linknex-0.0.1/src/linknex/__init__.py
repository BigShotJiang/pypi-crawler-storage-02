### `src/linknex/__init__.py`
__version__ = "0.0.1"
from .data import InterGraph
from .builders import supra_adjacency, supra_graph
