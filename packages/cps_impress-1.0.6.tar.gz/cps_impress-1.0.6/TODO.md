## TODO

### Future query methods

SQLITE EAV QUERY

MEDIAWIKI GET

HTML GET
