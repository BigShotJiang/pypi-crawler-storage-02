"""Extra functionalities for tv-series"""

# Control download flow
# Consider :
# - Start Season and episode.
# - Proceeding steps count.
# NOTE: Use trial-error approach to decide whether season-episodes are exhausted
# Then proceed to next one.
# ...

# TODO: Implement this
