> [!TIP]
> [Recons](./recons/) - Reconnaisance stuff (html, js, json, srt, md etc)

The files/folders aren't formatted in any meaningful way so find out by yourself folk :laugh:.