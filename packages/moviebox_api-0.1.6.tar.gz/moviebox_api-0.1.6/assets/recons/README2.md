## Search movies 

url : https://moviebox.ng/wefeed-h5-bff/web/subject/search

payload :

```json
{
    "keyword": "titanic",
    "page": 1,
    "perPage": 24,
    "subjectType": 6
}
```

subjectType Map

| Number | Subject    |
|--------|------------|
|   0    |  All       |
|   1    | Movies     |
|   2    |    Series  |
|   6    | Music      |

