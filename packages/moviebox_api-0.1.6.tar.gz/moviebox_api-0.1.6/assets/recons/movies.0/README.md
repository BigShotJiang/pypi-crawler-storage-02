# Specific movie details page

url : https://moviebox.pk/detail/titanic-m7a9yt0abq6?id=5390197429792821032&scene&page_from=search_detail&type=%2Fmovie%2Fdetail


