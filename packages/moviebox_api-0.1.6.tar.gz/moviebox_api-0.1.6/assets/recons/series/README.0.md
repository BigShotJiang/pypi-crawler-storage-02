# Specific series details path

url : https://moviebox.pk/detail/merlin-sMxCiIO6fZ9?id=8382755684005333552&scene&page_from=search_detail&type=%2Fmovie%2Fdetail

REQUEST HEADERS

```
url	https://moviebox.pk/detail/merlin-sMxCiIO6fZ9?id=8382755684005333552&scene&page_from=search_detail&type=%2Fmovie%2Fdetail
originUrl	https://moviebox.pk/web/searchResult?keyword=merlin
method	GET
incognito	false
thirdParty	false
cookieStoreId	firefox-default
urlClassification	firstParty: [], thirdParty: []
requestSize	0
responseSize	0
Accept	text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Encoding	gzip, deflate, br, zstd
Accept-Language	en-US,en;q=0.5
Alt-Used	moviebox.pk
Connection	keep-alive
Host	moviebox.pk
Referer	https://moviebox.pk/web/searchResult?keyword=merlin
Sec-Fetch-Dest	document
Sec-Fetch-Mode	navigate
Sec-Fetch-Site	same-origin
Sec-Fetch-User	?1
Upgrade-Insecure-Requests	1
User-Agent	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0
```