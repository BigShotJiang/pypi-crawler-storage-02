# __main__.py

from .cli import PraisonAI

def main():
    praison_ai = PraisonAI()
    praison_ai.main()

if __name__ == "__main__":
    main()