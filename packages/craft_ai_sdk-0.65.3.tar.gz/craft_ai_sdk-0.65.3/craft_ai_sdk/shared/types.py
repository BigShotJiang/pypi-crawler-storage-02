from typing import TypedDict


class Log(TypedDict):
    timestamp: str
    message: str
