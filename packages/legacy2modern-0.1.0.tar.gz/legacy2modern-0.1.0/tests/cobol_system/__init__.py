"""
COBOL System Test Suite

This package contains tests for the COBOL transpilation system.
"""

__version__ = "1.0.0" 