"""
Astro template generators for website modernization.
"""

from .astro_generator import AstroTemplateGenerator

__all__ = ['AstroTemplateGenerator'] 