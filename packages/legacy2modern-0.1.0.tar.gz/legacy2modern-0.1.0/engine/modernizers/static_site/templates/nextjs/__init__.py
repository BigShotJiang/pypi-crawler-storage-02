"""
Next.js template generators for website modernization.
"""

from .nextjs_generator import NextJSTemplateGenerator

__all__ = ['NextJSTemplateGenerator'] 