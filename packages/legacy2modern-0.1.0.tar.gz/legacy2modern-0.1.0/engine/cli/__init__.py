"""
CLI Package

This package contains the command-line interface modules.
""" 