"""
Legacy2Modern Packages

This package contains all the modules for the legacy2modern transpiler.
"""

__version__ = "1.0.0"
__author__ = "Astrio Team" 