# Generated Python code from main

# Variable declarations
who = ''
where = ''
why = ''
rate = 0
hours = 0
gross_ = 0

def main():
    who = "Captain COBOL"
    where = "San Jose, California"
    why = "Learn to be a COBOL expert"
    hours = 19
    rate = 23
    print(who)
    print(where)
    print(why)
    print(hours + hours)
    print(rate + rate)
    print(why + who)
    return

if __name__ == '__main__':
    main()
 