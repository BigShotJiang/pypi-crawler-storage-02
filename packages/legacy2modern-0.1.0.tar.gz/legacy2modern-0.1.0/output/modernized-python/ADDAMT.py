# Generated Python code from main

# Variable declarations
test_var = ''
result_var = ''
loo = ''
more_data = ''
keyed_ = ''
amt1_ = 0
amt2_ = 0
amt3_ = 0
d = ''
total_out = 0

def main():
    return

if __name__ == '__main__':
    main()
 