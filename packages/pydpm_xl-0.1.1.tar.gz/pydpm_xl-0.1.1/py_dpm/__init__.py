"""
PyDPM - Python Data Processing and Migration
============================================

A Python library for DPM-XL data processing, migration, and analysis.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

Main Features:
- Database migration from Access to SQLite
- DPM-XL syntax validation and parsing
- DPM-XL semantic analysis
- Access to DPM-XL grammar files

Quick Start:
    >>> import pydpm_xl
    >>> 
    >>> # Migration
    >>> migration = pydpm_xl.api.MigrationAPI()
    >>> engine = migration.migrate_access_to_sqlite("data.mdb", "output.db")
    >>> 
    >>> # Syntax validation
    >>> syntax = pydpm_xl.api.SyntaxAPI()
    >>> result = syntax.validate_expression("{tC_01.00, r0100, c0010}")
    >>> 
    >>> # Semantic analysis
    >>> semantic = pydpm_xl.api.SemanticAPI()
    >>> result = semantic.validate_expression("{tC_01.00, r0100, c0010}")
    >>> 
    >>> # Grammar access
    >>> from pydpm_xl.language.grammar import get_grammar_files
    >>> grammar_files = get_grammar_files()

Available packages:
- pydpm_xl.api: Main APIs for migration, syntax, and semantic analysis
- pydpm_xl.language.grammar: Access to DPM-XL grammar and parsing utilities
"""

__version__ = "0.1.1"
__author__ = "MeaningfulData S.L."
__email__ = "info@meaningfuldata.eu"
__license__ = "GPL-3.0-or-later"

# Import main classes for direct usage
from py_dpm.api import MigrationAPI, SyntaxAPI, SemanticAPI

# Lazy import to avoid circular imports
def __getattr__(name):
    if name == 'api':
        from py_dpm import api
        return api
    elif name == 'language':
        from py_dpm import language
        return language
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

__all__ = [
    'api',
    'language', 
    'MigrationAPI',
    'SyntaxAPI',
    'SemanticAPI',
    '__version__'
]
