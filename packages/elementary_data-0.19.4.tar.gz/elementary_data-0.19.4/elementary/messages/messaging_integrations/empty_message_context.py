from pydantic import BaseModel


class EmptyMessageContext(BaseModel):
    pass
