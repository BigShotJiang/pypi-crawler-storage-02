__version__ = "0.2.11"

MAJOR_VERSION = ".".join(__version__.split(".")[:-1])
PATCH_VERSION = __version__.split(".")[-1]
