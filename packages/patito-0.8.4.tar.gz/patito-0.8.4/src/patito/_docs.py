"""Ugly workaround for Sphinx + autodoc + ModelMetaclass + classproperty."""

from patito.pydantic import ModelMetaclass as Model  # noqa: F401, pragma: no cover
