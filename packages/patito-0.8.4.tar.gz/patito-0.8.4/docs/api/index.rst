API Reference
=============

.. toctree::
   :caption: General Functionality
   :maxdepth: 1

   patito/DataFrame/index
   patito/Model/index
   patito/Field/index
