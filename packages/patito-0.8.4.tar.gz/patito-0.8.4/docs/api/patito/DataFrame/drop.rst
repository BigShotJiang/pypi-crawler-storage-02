patito.DataFrame.drop
=====================

.. currentmodule:: patito

.. automethod:: DataFrame.drop
