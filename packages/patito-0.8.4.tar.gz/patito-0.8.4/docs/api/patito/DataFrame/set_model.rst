.. _DataFrame.set_model:

patito.DataFrame.set_model
==========================

.. currentmodule:: patito

.. automethod:: DataFrame.set_model
