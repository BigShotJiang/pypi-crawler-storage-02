patito.DataFrame.derive
=======================

.. currentmodule:: patito

.. automethod:: DataFrame.derive
