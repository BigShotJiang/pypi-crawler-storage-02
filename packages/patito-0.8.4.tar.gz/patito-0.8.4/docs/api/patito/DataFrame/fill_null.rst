patito.DataFrame.fill_null
==========================

.. currentmodule:: patito

.. automethod:: DataFrame.fill_null
