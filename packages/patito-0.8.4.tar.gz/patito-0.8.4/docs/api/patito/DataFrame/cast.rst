patito.DataFrame.cast
=====================

.. currentmodule:: patito

.. automethod:: DataFrame.cast
