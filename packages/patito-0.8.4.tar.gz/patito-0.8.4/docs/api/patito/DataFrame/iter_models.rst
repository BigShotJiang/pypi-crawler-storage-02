.. _DataFrame.iter_models:

patito.DataFrame.iter_models
============================

.. currentmodule:: patito

.. automethod:: DataFrame.iter_models
