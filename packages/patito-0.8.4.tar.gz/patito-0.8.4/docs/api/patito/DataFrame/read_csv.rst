patito.DataFrame.read_csv
=========================

.. currentmodule:: patito

.. automethod:: DataFrame.read_csv
