.. _DataFrame.get:

patito.DataFrame.get
====================

.. currentmodule:: patito

.. automethod:: DataFrame.get
