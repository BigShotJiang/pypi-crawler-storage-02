﻿patito.DataFrame
================

.. currentmodule:: patito

.. autoclass:: DataFrame

.. toctree::
   :caption: Methods
   :maxdepth: 1

   cast <cast>
   derive <derive>
   drop <drop>
   fill_null <fill_null>
   get <get>
   iter_models <iter_models>
   read_csv <read_csv>
   set_model <set_model>
   validate <validate>
