.. _DataFrame.validate:

patito.DataFrame.validate
=========================

.. currentmodule:: patito

.. automethod:: DataFrame.validate
