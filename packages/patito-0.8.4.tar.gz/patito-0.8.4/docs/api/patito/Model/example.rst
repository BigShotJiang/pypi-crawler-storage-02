patito.Model.example
====================

.. currentmodule:: patito

.. automethod:: Model.example
