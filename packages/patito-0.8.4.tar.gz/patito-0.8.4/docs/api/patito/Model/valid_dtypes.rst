patito.Model.valid_dtypes
=========================

.. currentmodule:: patito._docs

.. autoproperty:: Model.valid_dtypes
