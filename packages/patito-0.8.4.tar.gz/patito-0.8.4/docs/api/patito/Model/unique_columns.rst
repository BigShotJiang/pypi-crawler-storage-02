patito.Model.unique_columns
===========================

.. currentmodule:: patito._docs

.. autoproperty:: Model.unique_columns
