patito.Model.non_nullable_columns
=================================

.. currentmodule:: patito._docs

.. autoproperty:: Model.non_nullable_columns
