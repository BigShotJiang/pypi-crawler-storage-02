patito.Model.from_row
=====================

.. currentmodule:: patito

.. automethod:: Model.from_row
