patito.Model.dtypes
===================

.. currentmodule:: patito._docs

.. autoproperty:: Model.dtypes
