patito.Model.columns
====================

.. currentmodule:: patito._docs

.. autoproperty:: Model.columns
