.. _Model.join:

patito.Model.join
=================

.. currentmodule:: patito

.. automethod:: Model.join
