patito.Model.rename
===================

.. currentmodule:: patito

.. automethod:: Model.rename
