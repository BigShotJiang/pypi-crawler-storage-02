.. _Model.prefix:

patito.Model.prefix
===================

.. currentmodule:: patito

.. automethod:: Model.prefix
