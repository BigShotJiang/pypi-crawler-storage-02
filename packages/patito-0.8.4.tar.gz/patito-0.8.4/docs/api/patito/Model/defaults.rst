patito.Model.defaults
=====================

.. currentmodule:: patito._docs

.. autoproperty:: Model.defaults
