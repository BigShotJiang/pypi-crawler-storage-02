.. _Model.select:

patito.Model.select
===================

.. currentmodule:: patito

.. automethod:: Model.select
