.. _Model.validate:

patito.Model.validate
=====================

.. currentmodule:: patito

.. automethod:: Model.validate
