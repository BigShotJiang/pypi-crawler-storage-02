.. _Model.examples:

patito.Model.examples
=====================

.. currentmodule:: patito

.. automethod:: Model.examples
