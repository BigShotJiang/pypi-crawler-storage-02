patito.Model.with_fields
========================

.. currentmodule:: patito

.. automethod:: Model.with_fields
