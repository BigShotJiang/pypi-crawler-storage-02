patito.Model.nullable_columns
=============================

.. currentmodule:: patito._docs

.. autoproperty:: Model.nullable_columns
