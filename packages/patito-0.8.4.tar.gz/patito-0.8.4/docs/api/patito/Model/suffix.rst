patito.Model.suffix
===================

.. currentmodule:: patito

.. automethod:: Model.suffix
