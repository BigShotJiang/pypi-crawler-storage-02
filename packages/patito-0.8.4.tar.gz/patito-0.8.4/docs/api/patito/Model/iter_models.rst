.. _Model.iter_models:

patito.Model.iter_models
========================

.. currentmodule:: patito

.. automethod:: Model.iter_models
