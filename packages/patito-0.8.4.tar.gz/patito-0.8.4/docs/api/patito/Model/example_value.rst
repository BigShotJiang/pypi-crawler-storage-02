patito.Model.example_value
==========================

.. currentmodule:: patito

.. automethod:: Model.example_value
