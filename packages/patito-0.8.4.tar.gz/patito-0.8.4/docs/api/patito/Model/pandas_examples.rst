patito.Model.pandas_examples
============================

.. currentmodule:: patito

.. automethod:: Model.pandas_examples
