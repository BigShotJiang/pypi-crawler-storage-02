patito.Model.drop
=================

.. currentmodule:: patito

.. automethod:: Model.drop
