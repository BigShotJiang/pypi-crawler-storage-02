patito.Model.LazyFrame
======================

.. currentmodule:: patito

.. automethod:: Model.LazyFrame
