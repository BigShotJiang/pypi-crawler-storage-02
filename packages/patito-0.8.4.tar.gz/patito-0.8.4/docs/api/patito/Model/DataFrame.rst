patito.Model.DataFrame
======================

.. currentmodule:: patito

.. automethod:: Model.DataFrame
