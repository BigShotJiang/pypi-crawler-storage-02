.. _Field:

patito.Field
============

.. autofunction:: patito.Field
