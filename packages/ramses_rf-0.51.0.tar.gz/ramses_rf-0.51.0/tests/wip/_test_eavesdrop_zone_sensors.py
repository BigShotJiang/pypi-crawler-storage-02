#!/usr/bin/env python3
"""RAMSES RF - Test eavesdropping of a zone sensors."""
