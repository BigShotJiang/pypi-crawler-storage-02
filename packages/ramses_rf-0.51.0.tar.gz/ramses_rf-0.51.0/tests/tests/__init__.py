#!/usr/bin/env python3
"""RAMSES RF - Tests that do not rely on a RF dongle (e.g. a HGI80)."""
