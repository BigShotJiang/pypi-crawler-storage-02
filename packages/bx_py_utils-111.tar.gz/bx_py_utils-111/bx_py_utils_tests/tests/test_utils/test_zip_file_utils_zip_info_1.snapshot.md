| index | file_size | compress_size | compress_ratio | compress_type | modification_date | crc32 | file_name |
| ----- | ----- | ----- | ----- | ----- | ----- | ----- | ----- |
| 1 | 26 | 37 | 142 | lzma | 2024-12-24T00:00:00+00:00 | 5BDCF848 | file1.txt |
| 2 | 44 | 38 | 86 | lzma | 2024-12-24T00:00:00+00:00 | 06545222 | file2.txt |