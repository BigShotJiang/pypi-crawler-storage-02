"""Runloop runtime implementation.

This runtime reads configuration directly from environment variables:
- RUNLOOP_API_KEY: API key for Runloop authentication
"""
