from openhands.agenthub.loc_agent.loc_agent import LocAgent
from openhands.controller.agent import Agent

Agent.register('LocAgent', LocAgent)
