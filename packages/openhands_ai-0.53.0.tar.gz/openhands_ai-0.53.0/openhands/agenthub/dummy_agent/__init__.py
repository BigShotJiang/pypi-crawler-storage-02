from openhands.agenthub.dummy_agent.agent import DummyAgent
from openhands.controller.agent import Agent

Agent.register('DummyAgent', DummyAgent)
