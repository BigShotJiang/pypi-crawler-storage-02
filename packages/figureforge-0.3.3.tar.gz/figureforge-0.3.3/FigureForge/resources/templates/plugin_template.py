class Plugin:
    name = "Plugin Name"
    tooltip = "Plugin tooltip."
    # icon = "path/to/icon.png"
    # submenu = "..."

    def run(self, obj):
        pass
