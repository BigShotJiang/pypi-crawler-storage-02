from FigureForge.widgets.custom_spinbox import SpinBox
from FigureForge.widgets.dict_property import DictProperty
from FigureForge.widgets.tuple_property import TupleProperty
from FigureForge.widgets.color_button import ColorButton
