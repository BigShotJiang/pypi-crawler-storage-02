TODO:
The best up-to-date documentation lies in the [`client-generation` CI job](../../../.github/workflows/main.yml).
