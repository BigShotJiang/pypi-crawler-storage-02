TODO:
synced from IdP, adminVO, VO Admin, groups, properties

end with links to meaning of groups in DMS, WMS, etc
