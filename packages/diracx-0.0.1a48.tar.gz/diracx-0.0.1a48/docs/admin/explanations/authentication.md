TODO

- Security: various authentications (legacy exchange, oauth flows, pilots...), we need an external IDP, key rotations, etc -> authentication.md
