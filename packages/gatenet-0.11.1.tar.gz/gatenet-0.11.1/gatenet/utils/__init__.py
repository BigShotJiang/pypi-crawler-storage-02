from .net import get_free_port
from .constants import COMMON_PORTS
from .netinfo import list_network_interfaces, scan_wifi_networks