"""Tests for graph module."""
