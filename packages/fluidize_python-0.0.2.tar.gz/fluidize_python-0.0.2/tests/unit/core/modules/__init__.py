"""Core modules unit tests."""
