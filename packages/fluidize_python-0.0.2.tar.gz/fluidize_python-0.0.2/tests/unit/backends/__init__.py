"""Adapter unit tests."""
