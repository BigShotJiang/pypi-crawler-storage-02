# Projects and Nodes

*Content coming soon...*

For API details, see the [Projects module documentation](../core-modules/projects.md).
