# Projects Module

## Project Management

### Projects Manager
::: fluidize.managers.projects.Projects
    options:
      show_source: false

### Project Class
::: fluidize.managers.project_manager.Project
    options:
      show_source: false
