__version__ = "0.1.0"

from slap_project import foo

foo()
