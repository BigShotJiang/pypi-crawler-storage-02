"""Utility modules for Git Changelog Maestro."""
