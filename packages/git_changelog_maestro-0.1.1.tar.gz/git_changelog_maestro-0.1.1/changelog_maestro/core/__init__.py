"""Core functionality for Git Changelog Maestro."""
