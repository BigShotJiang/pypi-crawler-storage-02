"""Entry point for running changelog-maestro as a module."""

from .cli import main

if __name__ == "__main__":
    main()
