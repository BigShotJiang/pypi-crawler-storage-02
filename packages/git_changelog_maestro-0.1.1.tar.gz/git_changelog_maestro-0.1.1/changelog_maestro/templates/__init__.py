"""Templates for changelog generation."""
