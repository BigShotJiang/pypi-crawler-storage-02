## v0.1.1rc31 (August 14, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc30...v0.1.1rc31

### Features

- support for app registration via events (#635) (by @Nishant Munjal in [330b585](https://github.com/atlanhq/application-sdk/commit/330b585))

### Bug Fixes

- error logs related to deployment secrets (#651) (by @Nishchith Shetty in [09f6e5c](https://github.com/atlanhq/application-sdk/commit/09f6e5c))
