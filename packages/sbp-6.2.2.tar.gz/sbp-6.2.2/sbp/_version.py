# THIS FILE IS GENERATED FROM TRAITS SETUP.PY
version = '6.2.2'
full_version = '6.2.2'
git_revision = 'Unknown'
is_released = True
if not is_released:
    version = full_version
