from warnings import warn

warn("sbp.jit has been removed", UserWarning, stacklevel=1)
