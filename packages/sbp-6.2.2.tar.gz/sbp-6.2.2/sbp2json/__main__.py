from sbp.sbp2json import module_main

if __name__ == "__main__":
    module_main()
