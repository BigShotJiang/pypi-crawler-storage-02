from .DRİVE_OPEN import DRİVE
from .Easy_app import Easy_App
