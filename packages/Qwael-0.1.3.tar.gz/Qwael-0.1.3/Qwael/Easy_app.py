from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.gridlayout import GridLayout
from kivy.lang import Builder
from kivy.uix.widget import Widget
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout

class Easy_App:
    def open(add=()):
        if add():
            def Labell(txt="", x=None,y=None, sizing=None):
                class ekran(FloatLayout):
                    def __init__(self,**kwargs):
                        super(ekran,self).__init__(**kwargs)
                        layout = BoxLayout(orieentation="vertical",padding=(30),spacing=(20))
                        x = Label(text=txt, pos_hint={"x": 0.0, "y": 0.0}, size_hint=(None, None), size=(x, y), font_size=f"{sizing}sp")
        class uygulama(App):
            def build(self):
                pass
        if __name__ == "__main__":
            uygulama().run()
                