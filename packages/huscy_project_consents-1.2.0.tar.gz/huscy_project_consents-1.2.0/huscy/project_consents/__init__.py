VERSION = (1, 2, 0)

__version__ = '.'.join(str(x) for x in VERSION)
