# Jupyterlab Korean (South Korea) Language Pack

Korean (South Korea) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-ko-KR
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-ko-KR
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
