"""
Tests for commands package.
""" 