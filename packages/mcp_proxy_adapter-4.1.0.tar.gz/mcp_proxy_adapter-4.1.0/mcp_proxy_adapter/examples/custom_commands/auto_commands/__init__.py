"""
Auto-registered commands package.

Commands in this package will be automatically discovered and registered
by the framework's auto-discovery mechanism.
""" 