"""Version information for MCP Microservice."""

__version__ = "4.1.0" 