"""GitMe - Git commit message generator"""

__version__ = "0.5.5"