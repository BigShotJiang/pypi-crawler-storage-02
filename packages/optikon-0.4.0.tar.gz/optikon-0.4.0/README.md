# Optikon

Fast optimisation of conjunctions of propositions over numerical datasets.