"""Constants for Reflex Enterprise."""

SHOW_BUILT_WITH_REFLEX_INFO = "https://reflex.dev/docs/hosting/reflex-branding/"

# Koala Analytics
KOALA_PUBLIC_API_KEY = "pk_69086242b96db4849754ec257463c4c78de1"
KOALA_API_ENDPOINT = "https://api2.getkoala.com/web/projects/{}/batch"
