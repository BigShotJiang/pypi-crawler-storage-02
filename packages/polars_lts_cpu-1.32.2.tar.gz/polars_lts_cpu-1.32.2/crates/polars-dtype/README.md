# polars-dtype

Low-level datatype definitions of the Polars project.

`polars-dtype` is an **internal sub-crate** of the [Polars](https://crates.io/crates/polars)
library.

**Important Note**: This crate is **not intended for external usage**. Please refer to the main
[Polars crate](https://crates.io/crates/polars) for intended usage.
