from .pyswot import find_school_names, is_academic, is_free

__all__ = ["is_academic", "is_free", "find_school_names"]
