"""
Testing basic functionality of the policyengine-data package.
"""


def test_import() -> None:
    """Test that the package can be imported."""
    import policyengine_data
