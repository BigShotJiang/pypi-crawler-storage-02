
from .msgraph import Outlook

__all__ = [
    "Outlook",
]