from IPython import get_ipython
get_ipython().run_line_magic('load_ext', 'immersim.checkpoints')
print("Ironman Mode disabled!")  # Checkpoints enabled!