## 1.5.0.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 1.5.0.20250307 (2025-03-07)

[stubsabot] Bump fanstatic to 1.5.* (#13586)

## 1.4.0.20250305 (2025-03-05)

Remove `setuptools/pkg_resources` (#13369)

## 1.4.0.20240310 (2024-03-10)

Bump mypy to 1.9, add to json.encoder, small fixups (#11549)

Co-authored-by: Alex Waygood <Alex.Waygood@Gmail.com>

## 1.4.0.20240301 (2024-03-01)

Fix invalid noqa comments and poorly formatted type ignores (#11497)

## 1.4.0.20240106 (2024-01-06)

Update typing_extensions imports in third-party stubs (#11245)

## 1.4.0.1 (2023-12-11)

fanstatic: Use `Unpack` in `fanstatic.injector.Injector` (#11139)

## 1.4.0.0 (2023-11-22)

Add stubs for fanstatic (#9931)

