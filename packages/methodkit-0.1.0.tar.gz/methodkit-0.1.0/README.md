# MethodKit

![Status](https://img.shields.io/badge/status-work_in_progress-yellow?style=flat-square)


A Python package containing useful methods and algorithms.

> **Note**
>
> This package is still under development and does not guarantee a stable API.

## Motivation

This package was created to provide a collection of useful methods and algorithms in Python, especially for machine learning tasks. Re-inventing the wheel is no fun.