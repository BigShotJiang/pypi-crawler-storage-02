from .getfitsheaders import GetFitsHeaders
