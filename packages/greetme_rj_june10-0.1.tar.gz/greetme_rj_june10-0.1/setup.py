from setuptools import setup, find_packages

setup(
    name='greetme_rj_june10',  # <-- new unique name
    version='0.1',
    packages=find_packages(),
    description='A simple greeting package',
    author='Rajeendran U',
    author_email='your.email@example.com',
    install_requires=[],
)
