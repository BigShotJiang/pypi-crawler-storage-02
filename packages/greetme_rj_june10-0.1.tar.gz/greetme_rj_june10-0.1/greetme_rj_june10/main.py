def greet(name):
    return f"Hi there, {name}!"
