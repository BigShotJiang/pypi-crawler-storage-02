import printpop
from printpop import main
main()