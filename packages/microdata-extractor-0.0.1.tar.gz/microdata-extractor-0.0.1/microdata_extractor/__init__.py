from .microdata_extractor import ISTATMicrodataExtractor

__all__ = [
    "ISTATMicrodataExtractor",
    ]