"""Core scanning functionality for SpecPHP Scanner."""
from __future__ import annotations

__all__ = [
    'scan_api',
    'ScanResult',
    'ScanSummary',
]
