__version__ = "0.1.0"
default_app_config = 'bsv_integration.apps.BSVIntegrationConfig'
