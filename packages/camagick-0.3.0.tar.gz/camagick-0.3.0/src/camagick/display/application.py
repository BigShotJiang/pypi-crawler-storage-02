#!/usr/bin/python3

def display_main():
    print("CAMgick-Display")

if __name__ == "__main__":
    display_main()
