# App for practicing Japanese

## Known issues:

N/A

## Testing solution:

N/A