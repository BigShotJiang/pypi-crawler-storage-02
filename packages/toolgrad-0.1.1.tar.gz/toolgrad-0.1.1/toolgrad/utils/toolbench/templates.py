ApiDescriptionTemplate = """
This is an api, {api_name}, from tool, {tool_name}, in category, {category}.

The api description:
{api_description}
The tool description:
{tool_description}
"""
