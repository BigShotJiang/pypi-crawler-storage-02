"""Cli for traps team tools"""

__version__ = "0.3.0"
from .paco_cli import *  # noqa
