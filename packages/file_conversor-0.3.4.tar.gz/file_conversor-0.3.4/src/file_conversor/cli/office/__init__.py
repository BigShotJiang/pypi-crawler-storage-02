

from file_conversor.cli.office.doc_cmd import doc_cmd
from file_conversor.cli.office.ppt_cmd import ppt_cmd
from file_conversor.cli.office.xls_cmd import xls_cmd
