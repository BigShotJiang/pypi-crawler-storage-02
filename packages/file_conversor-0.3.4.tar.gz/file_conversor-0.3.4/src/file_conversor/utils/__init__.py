
# src/file_conversor/utils/__init__.py

"""
This module initializes the utils package.
It can contain utility functions or classes that are used across the application.
"""
