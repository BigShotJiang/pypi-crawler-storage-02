""" Module for interface to visibility data """
