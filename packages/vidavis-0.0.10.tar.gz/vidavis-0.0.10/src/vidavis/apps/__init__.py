'''End user applications supplied by ``vidavis``.'''

from ._ms_raster import MsRaster
