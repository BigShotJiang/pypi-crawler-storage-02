from wexample_config.config_option.abstract_config_option import AbstractConfigOption

class ConfigOption(AbstractConfigOption):
    pass