from wexample_helpers.exception.undefined_exception import UndefinedException


class InvalidOptionException(UndefinedException):
    pass
