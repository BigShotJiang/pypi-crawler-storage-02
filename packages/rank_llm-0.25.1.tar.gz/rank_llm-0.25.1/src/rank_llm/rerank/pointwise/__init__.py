from .monot5 import MonoT5

__all__ = ["MonoT5"]
