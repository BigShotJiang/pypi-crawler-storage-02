from setuptools import setup

setup(
    name="rpa-config",
    version="2.4.0",
    py_modules=["rpa_config"],
    install_requires=[],
)