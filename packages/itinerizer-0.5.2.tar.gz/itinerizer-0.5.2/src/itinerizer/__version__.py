"""
Itinerizer version information.
"""

__version__ = "0.5.2"
__author__ = "Itinerizer Contributors"
__email__ = "contact@itinerizer.io"
__description__ = "A comprehensive travel itinerary management system with JSON storage"
__url__ = "https://github.com/yourusername/itinerizer"