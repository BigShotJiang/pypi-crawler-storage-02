// test for jasper

// include
    // standard
    #include "check_utils.h"
    // library
    #include <gdk-pixbuf/gdk-pixbuf.h>

// check one function from the dll
CHECK_ONE(gdk_pixbuf_save)

