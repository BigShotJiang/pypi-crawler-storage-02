// test for libjpeg-turbo

// include
    // standard
    #include "check_utils.h"
    // library
    #include <turbojpeg.h>

// check one function from the dll
CHECK_ONE(tjCompress)
