// test for jasper

// include
    // standard
    #include "check_utils.h"
    // library
    #include <jasper.h>

// check one function from the dll
CHECK_ONE(jas_init)

