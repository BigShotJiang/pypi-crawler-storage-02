// test for libarchive

// include
    // standard
    #include "check_utils.h"
    // library
    #include <archive.h>

// check one function from the dll
CHECK_ONE(archive_version_details)
