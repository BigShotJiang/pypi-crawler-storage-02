// test for curl

// include
    // standard
    #include "check_utils.h"
    // library
    #include <curl/curl.h>

// check one function from the dll
CHECK_ONE(curl_version_info)
