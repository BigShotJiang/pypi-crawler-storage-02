"""DO NOT USE - INTERNAL FACING ONLY - DO NOT USE

Internal modules are *NOT* meant for public consumption. External users of the
armada_client should not use or call any code contained in these modules as
they are unsupported and could change or break at any time.
"""
