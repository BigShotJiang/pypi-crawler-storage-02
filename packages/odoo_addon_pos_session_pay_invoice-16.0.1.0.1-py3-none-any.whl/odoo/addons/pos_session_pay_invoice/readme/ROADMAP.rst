* Cannot pay invoices in a different currency than that defined in the journal
  associated to the payment method used to pay/collect payment.
