from dotenv import load_dotenv

__version__ = "0.3.1"

load_dotenv()
