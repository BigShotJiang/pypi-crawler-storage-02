.. nxbrew_dl documentation master file, created by
   sphinx-quickstart on Fri Oct 11 20:13:17 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: intro.rst

.. toctree::
   :titlesonly:
   :maxdepth: 2
   :caption: Documentation

   installation
   usage
   advanced_usage
   changelog
   reference_api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
