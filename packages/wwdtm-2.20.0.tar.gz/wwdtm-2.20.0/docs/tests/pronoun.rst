.. module:: tests.pronoun

*******
pronoun
*******

This module provides functions used to by :py:class:`pytest` to run tests against
the following objects:

- :py:class:`wwdtm.pronoun.Pronouns`

test_pronoun_pronouns
=====================

.. automodule:: tests.pronoun.test_pronoun_pronouns
    :members:
    :undoc-members:
