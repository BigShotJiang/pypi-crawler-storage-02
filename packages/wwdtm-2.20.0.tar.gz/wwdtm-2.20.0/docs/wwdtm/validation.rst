******************
Module: validation
******************

This module provides functions used to validate various data types used
within the library.

Functions
=========

.. automodule:: wwdtm.validation
    :members:
