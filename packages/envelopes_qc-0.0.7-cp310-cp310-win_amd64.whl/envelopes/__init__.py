from . import envelopes_cpp as evc
from . import envelopes_py as evp

import numpy as np

EVC_COMPLEX_DTYPE = np.complex64
EVC_FLOAT_DTYPE = np.float32
