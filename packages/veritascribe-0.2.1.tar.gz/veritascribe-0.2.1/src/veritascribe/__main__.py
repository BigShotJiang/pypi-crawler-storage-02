"""Main entry point for VeritaScribe CLI."""

from .main import main

if __name__ == "__main__":
    main()