# src/uplift_ble/__init__.py
from .desk import Desk
from .ble_characteristics import *

__all__ = [
    "Desk",
]
