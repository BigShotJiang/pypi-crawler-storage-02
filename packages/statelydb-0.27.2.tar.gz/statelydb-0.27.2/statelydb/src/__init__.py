"""Handwritten source code."""
