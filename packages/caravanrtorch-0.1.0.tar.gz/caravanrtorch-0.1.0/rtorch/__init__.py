from .robject import (
    RId,
    Return,
    ReturnType,
    RFutureTensor,
    RFutureParameter,
    RObject,
    RTensor,
    RParameter,
    RemoteCallPayload,
)
from .biject import patch, is_robject
