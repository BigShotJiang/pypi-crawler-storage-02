#!/bin/bash

set -e
set -x

cfengine version

cfengine --version
