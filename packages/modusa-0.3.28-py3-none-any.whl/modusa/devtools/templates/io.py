#!/usr/bin/env python3


from modusa import excp
from modusa.decorators import validate_args_type
from modusa.io.base import ModusaIO


class {class_name}(ModusaIO):
	"""

	"""
	
	#--------Meta Information----------
	_name = ""
	_description = ""
	_author_name = "{author_name}"
	_author_email = "{author_email}"
	_created_at = "{date_created}"
	#----------------------------------
	
	

	