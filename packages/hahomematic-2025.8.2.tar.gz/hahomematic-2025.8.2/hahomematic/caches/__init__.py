"""Module for the caches."""

from __future__ import annotations
