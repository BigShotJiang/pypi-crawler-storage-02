# -*- encoding: utf-8 -*-

from ._rabbitmq import *
