# DomPilot
DomPilot is an AI webscraping library powered by Playwright and written in Python
