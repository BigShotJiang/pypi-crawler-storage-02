"""Neer Match Package.

Neural-symbolic Entity Reasoning and Matching.
"""

__version__ = '0.7.41'

