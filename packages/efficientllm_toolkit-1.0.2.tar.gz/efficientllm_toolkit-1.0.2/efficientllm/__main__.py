#!/usr/bin/env python3
"""
EfficientLLM package main entry point
"""

from .cli import main

if __name__ == "__main__":
    main()