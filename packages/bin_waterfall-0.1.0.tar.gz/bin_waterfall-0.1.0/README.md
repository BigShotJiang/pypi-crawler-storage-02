安装方法：
pip install bin-waterfall
快速上手：
from bin_waterfall import EnergyProcessor, SpectrumProcessor
#在初始化类之前创建输入和输出目录，示例：
#输入目录存放bin文件
#输出目录会得到程序运行的瀑布图
    input_dir  = "D:/input"
    output_dir="D:/output"
#类初始化
    spec_proc = SpectrumProcessor(
        input_dir=input_dir,
        output_dir=os.path.join(output_dir, "Spectrum"),  # 给子类单独的子目录
        max_freq=60.0,     # 截止频率
        view_mode="side",  # 'side' 或 'top'
        dpi=300
    )
        energy_proc = EnergyProcessor(
        input_dir=input_dir,
        output_dir=os.path.join(output_dir, "Energy"),  # 给子类单独的子目录
        dpi=300,
        block_len=1024
    )
#然后调用对应的run方法即可