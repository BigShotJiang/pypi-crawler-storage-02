This text should be included.

.. code-block:: html

    <p> This text should be skipped. </p>

This text should also be included.
