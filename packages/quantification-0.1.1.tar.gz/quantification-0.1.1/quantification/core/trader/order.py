from typing import TYPE_CHECKING, Literal

from .base_order import BaseOrder

if TYPE_CHECKING:
    from ..asset import Stock


class StockOrder(BaseOrder["Stock"]):
    def __init__(self, asset: "Stock", category: Literal["buy"] | Literal["sell"]):
        super().__init__(asset, category)

    @property
    def extra(self):
        return {}

    def __repr__(self):
        return f"<股票交易指令 {self.category} {self.asset}>"

    __str__ = __repr__


__all__ = ["StockOrder"]
