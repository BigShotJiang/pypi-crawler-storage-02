from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra="allow")

    log_level: str = Field(default="INFO", description="日志等级")
    cache_dir: str = Field(default="./cache", description="缓存文件夹位置")
    adjust: str = Field(description='复权方式')


config = Config()

__all__ = ["Config", "config"]
