from quantification.core import BaseCombinedAPI

from .akshare import AkShareAPI
from .tushare import TuShareAPI


class DataAPI(BaseCombinedAPI):
    api_classes = [
        TuShareAPI,
        AkShareAPI
    ]
