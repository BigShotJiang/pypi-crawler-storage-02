import tushare as ts

from quantification.core import (
    Field,
    Config,
    cache_query
)

from .common import TushareSheetDelegate
from ..setting import TuShareSetting


class FinanceIndicatorDelegate(TushareSheetDelegate):
    pair = [
        (Field.FI_净资产收益率, "roe")
    ]

    def __init__(self, config: Config, setting: TuShareSetting):
        super().__init__(config, setting)
        self.api = cache_query()(ts.pro_api(setting.tushare_token).fina_indicator)
