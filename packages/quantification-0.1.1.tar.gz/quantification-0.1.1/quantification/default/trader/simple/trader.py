from quantification import BaseTrader


class SimpleTrader(BaseTrader):
    ...


__all__ = ['SimpleTrader']
