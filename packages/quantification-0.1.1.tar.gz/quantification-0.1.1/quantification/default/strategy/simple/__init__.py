from .strategy import SimpleStrategy
