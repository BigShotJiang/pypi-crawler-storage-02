Simple Employees application
----------------------------

Shows how to setup many to many relationships and a simple security addon 
(creates an action to delete multiple users) 

Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask fab create-admin
    $ flask run

