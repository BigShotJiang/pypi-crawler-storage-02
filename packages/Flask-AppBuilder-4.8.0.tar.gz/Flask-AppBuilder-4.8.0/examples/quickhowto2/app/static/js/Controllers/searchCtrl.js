app.controller("SearchCtrl", function($scope) {

  $scope.form_fields = form_fields;
  $scope.search_filters = search_filters;
  $scope.active_filters = active_filters;
  $scope.label_columns = label_columns;


    console.log($scope);
});
