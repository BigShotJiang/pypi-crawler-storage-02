# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.
from megatron.core.transformer.torch_norm import WrappedTorchNorm

WrappedTorchLayerNorm = WrappedTorchNorm
