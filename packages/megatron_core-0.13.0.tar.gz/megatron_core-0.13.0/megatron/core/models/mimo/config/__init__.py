# Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.

from megatron.core.models.mimo.config.base_configs import MimoModelConfig

__all__ = ['MimoModelConfig']
