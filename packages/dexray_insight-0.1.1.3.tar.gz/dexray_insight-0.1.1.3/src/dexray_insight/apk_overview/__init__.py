#!/usr/bin/env python3 
# -*- coding: utf-8 -*-

# the content of this directory is an adjusted version of the static analyser of Mobsf