from iris_embedded_python import *
try:
    from iris_embedded_python import __getattr__
except ImportError:
    pass
