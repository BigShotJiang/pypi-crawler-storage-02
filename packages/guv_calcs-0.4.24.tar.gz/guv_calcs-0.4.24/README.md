GUV Calcs
======================

A library for carrying out fluence and irradiance calculations for germicidal UV (GUV) applications.

## Installation

Install with pip:

	pip install guv-calcs
	
Alternatively, clone the repo and install locally:

    git clone https://github.com/jvbelenky/guv-calcs.git
    cd guv-calcs
    python setup.py sdist
    pip install . 


## Example Usage

*Coming soon...*

## Roadmap

*Coming soon...*

## License

Distributed under the MIT License. See `LICENSE.txt` for more information.

## Contact

Vivian Belenky - jvb@osluv.org

Project Link: [https://github.com/jvbelenky/guv-calcs/](https://github.com/jvbelenky/guv-calcs/)
