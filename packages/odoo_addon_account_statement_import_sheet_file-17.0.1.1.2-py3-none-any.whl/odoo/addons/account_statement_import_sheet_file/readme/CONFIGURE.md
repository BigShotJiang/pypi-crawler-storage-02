To create TXT/CSV/XLSX statement sheet columns mapping:

1.  Open *Invoicing \> Configuration \> Accounting \> Statement Sheet
    Mappings*
2.  Create mapping(s) according to your online banking software
    statement format
