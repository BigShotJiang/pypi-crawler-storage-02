This module allows you to import any TXT/CSV or XLSX file in Odoo as
bank statements.
