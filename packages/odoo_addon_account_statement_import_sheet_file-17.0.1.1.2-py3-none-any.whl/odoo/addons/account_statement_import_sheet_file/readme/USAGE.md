To use this module, you need to:

1.  Get statement in TXT/CSV or XLSX from your online banking software
2.  Go to Odoo and and import the statement file, selecting
    corresponding format
