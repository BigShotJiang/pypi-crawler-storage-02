from naeural_core.serving.ai_engines.stable import AI_ENGINES
