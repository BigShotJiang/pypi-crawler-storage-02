from .core import FileType

__all__ = [
    "FileType",
]
