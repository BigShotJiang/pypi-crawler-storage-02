from .model_serving_obo_credential_strategy import ModelServingUserCredentials

__all__ = ["ModelServingUserCredentials"]
