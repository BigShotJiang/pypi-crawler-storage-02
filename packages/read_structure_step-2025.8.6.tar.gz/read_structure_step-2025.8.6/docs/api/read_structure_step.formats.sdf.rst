read\_structure\_step.formats.sdf package
=========================================

Submodules
----------

read\_structure\_step.formats.sdf.sdf module
--------------------------------------------

.. automodule:: read_structure_step.formats.sdf.sdf
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: read_structure_step.formats.sdf
   :members:
   :undoc-members:
   :show-inheritance:
