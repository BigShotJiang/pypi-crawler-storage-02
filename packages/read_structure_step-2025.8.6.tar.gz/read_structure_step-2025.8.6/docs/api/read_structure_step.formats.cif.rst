read\_structure\_step.formats.cif package
=========================================

Submodules
----------

read\_structure\_step.formats.cif.cif module
--------------------------------------------

.. automodule:: read_structure_step.formats.cif.cif
   :members:
   :undoc-members:
   :show-inheritance:

read\_structure\_step.formats.cif.mmcif module
----------------------------------------------

.. automodule:: read_structure_step.formats.cif.mmcif
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: read_structure_step.formats.cif
   :members:
   :undoc-members:
   :show-inheritance:
