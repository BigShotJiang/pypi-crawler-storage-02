query_result_window
-------------------

.. automodule:: rfmetadata.windows.query_result_window
   :members:
   :undoc-members:
   :show-inheritance:
