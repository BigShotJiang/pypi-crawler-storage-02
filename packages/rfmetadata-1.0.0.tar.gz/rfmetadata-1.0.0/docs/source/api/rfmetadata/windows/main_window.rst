main_window
-----------

.. automodule:: rfmetadata.windows.main_window
   :members:
   :undoc-members:
   :show-inheritance:
