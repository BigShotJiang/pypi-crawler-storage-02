signal_manager
--------------

.. automodule:: rfmetadata.signal_manager
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 2

   signal_manager/data_signal_manager
