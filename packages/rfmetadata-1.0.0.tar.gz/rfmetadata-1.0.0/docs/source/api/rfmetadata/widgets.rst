widgets
-------

.. automodule:: rfmetadata.widgets
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 2

   widgets/data_graph_layout
   widgets/query_result_layout
   widgets/search_layout
