search_layout
-------------

.. automodule:: rfmetadata.widgets.search_layout
   :members:
   :undoc-members:
   :show-inheritance:
