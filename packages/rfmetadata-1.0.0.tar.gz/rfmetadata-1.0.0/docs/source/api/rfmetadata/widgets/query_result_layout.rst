query_result_layout
-------------------

.. automodule:: rfmetadata.widgets.query_result_layout
   :members:
   :undoc-members:
   :show-inheritance:
