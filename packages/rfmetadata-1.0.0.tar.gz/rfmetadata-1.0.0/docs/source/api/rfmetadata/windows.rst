windows
-------

.. automodule:: rfmetadata.windows
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 2

   windows/main_window
   windows/query_result_window
