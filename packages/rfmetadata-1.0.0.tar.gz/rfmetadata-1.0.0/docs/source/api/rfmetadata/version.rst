version
-------

.. automodule:: rfmetadata.version
   :members:
   :undoc-members:
   :show-inheritance:

