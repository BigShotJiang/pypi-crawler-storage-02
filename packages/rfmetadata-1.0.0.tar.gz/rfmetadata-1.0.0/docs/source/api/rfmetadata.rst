rfmetadata
----------

.. automodule:: rfmetadata
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 2

   rfmetadata/signal_manager
   rfmetadata/widgets
   rfmetadata/windows
   rfmetadata/main
   rfmetadata/version
