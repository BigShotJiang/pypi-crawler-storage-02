
Visualizing
============

**Visualizing BeForRecord data**

To use this module, please install the python library *matplotlib*.

This module is currently under development. The beta version provides
support for plotting BeForRecord data.

.. autosummary::

   befordata.plot.plot_record


befordata.plot
----------------------

.. autofunction:: befordata.plot.plot_record
