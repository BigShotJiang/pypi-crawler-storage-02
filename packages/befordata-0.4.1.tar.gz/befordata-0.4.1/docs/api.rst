API Reference
=============

.. automodule:: befordata


.. toctree::
   :maxdepth: 1

   data_struct
   tools
   filter
   file_formats
   visualizing

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`