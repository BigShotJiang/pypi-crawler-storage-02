
Filter
=================

**Filtering BeForRecord data**



.. autosummary::

   befordata.filter.lowpass_filter


befordata.filter
----------------------


.. autofunction:: befordata.filter.lowpass_filter
