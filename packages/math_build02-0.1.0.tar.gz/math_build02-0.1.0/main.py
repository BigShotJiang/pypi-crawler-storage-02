from math_build02 import math_tool
from math_build02 import math_tool02

print(math_tool.new_numpy(1, 2))
print(math_tool02.new_numpy02(1, 2, 3))