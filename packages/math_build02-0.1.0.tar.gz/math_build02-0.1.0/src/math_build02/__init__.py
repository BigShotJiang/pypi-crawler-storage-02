from .math_tool import new_numpy  # 暴露核心函数
from .math_tool02 import new_numpy02

__version__ = "0.1.0"

def main() -> None:
    print("Hello from math-build02!")
