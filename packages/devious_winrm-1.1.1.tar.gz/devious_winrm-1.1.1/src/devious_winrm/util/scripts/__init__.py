"""Helpful Powershell scripts."""
