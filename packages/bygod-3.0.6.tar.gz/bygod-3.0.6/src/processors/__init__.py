"""
Processors package for ByGoD.

This package contains modules for processing Bible downloads, including
book processing, translation processing, and master file generation.
"""
