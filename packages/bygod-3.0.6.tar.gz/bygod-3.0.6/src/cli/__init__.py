"""
CLI package for ByGoD.

This package contains modules for command-line interface functionality,
including argument parsing and validation.
"""
