def main():
    print("Hello from cloudhopper!")


if __name__ == "__main__":
    main()
