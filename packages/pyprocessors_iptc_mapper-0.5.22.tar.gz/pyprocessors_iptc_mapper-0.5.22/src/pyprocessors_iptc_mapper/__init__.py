"""Sherpa IPTC category mapper"""
__version__ = "0.5.22"
