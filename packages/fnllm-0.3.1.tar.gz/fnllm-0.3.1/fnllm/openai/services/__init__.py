# Copyright (c) 2025 Microsoft Corporation.

"""Package with OpenAI specific features to be used to wrap base LLM protocol interfaces."""
