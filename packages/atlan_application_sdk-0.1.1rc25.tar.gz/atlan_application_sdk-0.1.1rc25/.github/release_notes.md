## v0.1.1rc25 (August 05, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc24...v0.1.1rc25

### Features

- implement OAuth2 authentication and data transfer for applications (#634) (by @nishantmunjal7 in [e5e70a2](https://github.com/atlanhq/application-sdk/commit/e5e70a2))
