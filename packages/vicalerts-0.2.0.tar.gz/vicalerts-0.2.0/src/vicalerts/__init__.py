"""Track & archive Victoria's live emergency alerts."""

__version__ = "0.1.0"
