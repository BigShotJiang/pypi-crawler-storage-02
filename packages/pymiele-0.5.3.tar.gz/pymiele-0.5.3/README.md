## pymiele

Python library for Miele integration with Home Assistant.
The library is distributed via pypi.org.

### Installation
```bash
$ pip install pymiele
```
