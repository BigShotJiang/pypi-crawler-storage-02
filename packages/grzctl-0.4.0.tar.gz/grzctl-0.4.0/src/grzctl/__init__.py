"""
GRZ Control CLI for GRZ administrators.
"""

__version__ = "0.4.0"
