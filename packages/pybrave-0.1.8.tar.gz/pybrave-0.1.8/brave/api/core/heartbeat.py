import time

def process_heartbeat(msg: dict):
    print(f"💗 [heartbeat] {msg}")
    # time.sleep(1)