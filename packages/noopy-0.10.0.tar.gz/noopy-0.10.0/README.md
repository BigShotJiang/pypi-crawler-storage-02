# noopy

For singleton dimension(same flatten) tiny simple `list` `str` and `array`(array.array) extender library. This module could be transpose and flip on like 2D singleton dims as result of list extends. This module useful if limited ext modules(numpy, torch, and others) and also passes values to those modules.


## lispy

Based on list `lispy` this class suite, almight for any data.

## strpy

Based on str `strpy` therefore this class suite for treat `str` as like tensor, ndarray.

## arrpy

Based on array.array `arrpy` therefore few memory cost and process speed more than lispy. On the other hand, this library is not suite for treat `str`.

---

## Features

  * **Processing on Basic Module**: Only!
  * **Splitter**:Array splitter have get of best split position function and others.
  * **Transpose**: Transposer is  equivalent 2D free transpose on 1D it's make as possible for `str` array too.
  * **Flip**: Flipper is  equivalent 2D free Flip on 1D it's make as possible for `str` array too.

---

## Installation

You can install `noopy` directly from PyPI:

```bash
pip install noopy
````

-----

## Quick Start

Get started with `lispy` in just a few lines of code:

```python
import noopy as np
from noopy import dumpxh

import noopy.lst as lp
from noopy.lst import lispy
import noopy.arr as ap
from noopy.arr import arrpy
import noopy.str as sp
from noopy.str import strpy

my_lst = lispy([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
my_arr = arrpy('i', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
my_str = strpy(sp.flatten([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))
# 0123456789
#print(my_str)

moji = strpy("0123456789abcdefghijklmnopqrstuvwxyz")
retu = lispy(lp.flatten(moji))
#gyou = arrpy('L', lp.linspace(100, 136, 36, 'i'))
gyou = arrpy('u', u"0123456789abcdefghijklmnopqrstuvwxyz")
```

-----

## Basic Usage

Impremented Features.

## API Reference

### `noopy` Module Methods

  * **is_spl(arr:list, n:int)** Check could be split specified value count.
      * `arr`: (list) Target list.
      * `n`:    (int) This value specified for check availability of split count.
  * **splpos(arr:list)** Get could can be split positions as list(e.g. [2 ,4 ,6 ,8...]).
      * `arr`: (list) Target list.
  * **splmax(arr:list, n:int)** Get first upper split positions from `splpos` function resusts list.
      * `arr`: (list) Target list.
      * `n`:    (int) Search start index.
  * **splmin(arr:list, n:int)** Get first under split positions from `splpos` function resusts list.
      * `arr`: (list) Target list.
      * `n`:    (int) Search start index.
  * **splist(arr:list, n:int, r:bool)**
      * `arr`: (list) Target list.
      * `n`:    (int) between separation of array split, raise error not match like dimensions.
      * `r`:   (bool) Reverse split elements, default is `False`.

### Common Module `noopy.lst, noopy.str, noopy.arr` Methods

  * **zeros(n:int, t:str)**
      * `n`:
      * `t`:
  * **ones(n:int, t:str))**
      * `n`:
      * `t`:
  * **nones(arr:list)**
      * `Not Implemented` (array.array is always 1D, anytime)
      * `arr`: (list) Target list.
  * **linspace(s:float, e:float, n:int, t:str)**
      * `s`:
      * `e`:
      * `n`:
      * `t`:
  * **flatten(arr:list)**
      * `arr`: (list) Target list.
  * **transpose(arr:list, x:int, y:int)** Get Split Positions.
      * `arr`: (list) Target list.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(arr:list=None, x:int, y:int, z:str)** Get Split Positions.
      * `arr`: (list) Target list.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full flip).

### `lispy` Class Methods

Still not feature as similar torch functions, not be self update (self) values.

```
# e.g.
ny_list = ny_list.flatten()
```

  * **flatten()**
      * no arguments, return self flattened list.
  * **transpose(x:int, y:int)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(x:int, y:int, z:str)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full flip).

### `strpy` Class Methods

Same above(listpy)

  * **flatten()**
      * no arguments, return self flattened str.
  * **transpose(x:int, y:int)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(x:int, y:int, z:str)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full fli

### `arrpy` Class Methods

Same above(listpy)

  * **flatten()**
      * `Not Implemented` (array.array is always 1D, anytime)
  * **transpose(x:int, y:int)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(x:int, y:int, z:str)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full fli

#### See Officials:
[array — Efficient arrays of numeric values](https://docs.python.org/3.13/library/array.html)
[(JP)](https://docs.python.org/ja/3.13/library/array.html)

| Type code | C Type             | Python Type       | Minimum size in bytes | Notes | numpy,torch  |
| ---       | ---                | ---               | ---                   | ---   | ---          |
| 'b'       | signed char        | int               | 1                     |       | int8         |
| 'B'       | unsigned char      | int               | 1                     |       | uint8        |
| 'u'       | wchar_t            | Unicode character | 2                     | (1)   | str          |
| 'w'       | Py_UCS4            | Unicode character | 4                     | (2)   | ucs          |
| 'h'       | signed short       | int               | 2                     |       | short8, fp16 |
| 'H'       | unsigned short     | int               | 2                     |       | ushort16     |
| 'i'       | signed int         | int               | 2                     |       | int16        |
| 'I'       | unsigned int       | int               | 2                     |       | uint16       |
| 'l'       | signed long        | int               | 4                     |       | int32        |
| 'L'       | unsigned long      | int               | 4                     |       | uint32       |
| 'q'       | signed long long   | int               | 8                     |       | int64        |
| 'Q'       | unsigned long long | int               | 8                     |       | uint64       |
| 'f'       | float              | float             | 4                     |       | float32      |
| 'd'       | double             | float             | 8                     |       | loat64       |

-----

## Command Line Usage

`noopy` includes a simple command-line interface for testing its console output capabilities.

To run the test, simply execute:

```bash
python -m noopy
==============================
[[strpy]]
import noopy.str as sp
from noopy.str import strpy
------------------------------
By the first, this is original [str] array.
0123456789abcdefghijklmnopqrstuvwxyz 6
------------------------------
[ Transpose (6x6) ]
moji.transpose(6, 6)
06ciou17djpv28ekqw39flrx4agmsy5bhntz
0, 6, c, i, o, u, 
1, 7, d, j, p, v, 
2, 8, e, k, q, w, 
3, 9, f, l, r, x, 
4, a, g, m, s, y, 
5, b, h, n, t, z, 
[ Flip LR (6x6) ]
moji.flip(6, 6, "x")
543210ba9876hgfedcnmlkjitsrqpozyxwvu
5, 4, 3, 2, 1, 0, 
b, a, 9, 8, 7, 6, 
h, g, f, e, d, c, 
n, m, l, k, j, i, 
t, s, r, q, p, o, 
z, y, x, w, v, u, 
[ Flip UD (6x6) ]
moji.flip(6, 6, "y")
uvwxyzopqrstijklmncdefgh6789ab012345
u, v, w, x, y, z, 
o, p, q, r, s, t, 
i, j, k, l, m, n, 
c, d, e, f, g, h, 
6, 7, 8, 9, a, b, 
0, 1, 2, 3, 4, 5, 
[ Flip XY (6x6) ]
moji.flip(6, 6, "z")
zyxwvutsrqponmlkjihgfedcba9876543210
z, y, x, w, v, u, 
t, s, r, q, p, o, 
n, m, l, k, j, i, 
h, g, f, e, d, c, 
b, a, 9, 8, 7, 6, 
5, 4, 3, 2, 1, 0, 
------------------------------
[ Zeros ]
sp.zeros(36)
000000000000000000000000000000000000
[ Ones ]
sp.ones(36)
111111111111111111111111111111111111
[ Linspace ]
sp.linspace(40, 80, 36, 'f')
40.0,41.11,42.22,43.33,44.44,45.56,46.67,47.78,48.89,50.0,51.11,52.22,53.33,54.44,55.56,56.67,57.78,58.89,60.0,61.11,62.22,63.33,64.44,65.56,66.67,67.78,68.89,70.0,71.11,72.22,73.33,74.44,75.56,76.67,77.78,78.89,
------------------------------
[ Transpose (3x3) ]
sp.transpose(moji, 3, 3)
0, 3, 6, 
1, 4, 7, 
2, 5, 8, 
9, c, f, 
a, d, g, 
b, e, h, 
i, l, o, 
j, m, p, 
k, n, q, 
r, u, x, 
s, v, y, 
t, w, z, 
[ Flip XY (3x3) ]
sp.flip(moji, 3, 3, "z")
876543210hgfedcba9qponmlkjizyxwvutsr
8, 7, 6, 
5, 4, 3, 
2, 1, 0, 
h, g, f, 
e, d, c, 
b, a, 9, 
q, p, o, 
n, m, l, 
k, j, i, 
z, y, x, 
w, v, u, 
t, s, r, 

[[noopy fetaures]]
Available split positions.
np.splpos(moji)
[2, 3, 6, 9, 18]
Available split to 9(9x4)?
np.is_spl(moji, 9)
True
Split to 9(9x4).
splt = np.splist(moji, 9)
['012345678', '9abcdefgh', 'ijklmnopq', 'rstuvwxyz']
(** Str to List)
<class 'noopy.str.strpy'>  ->  <class 'noopy.lst.lispy'>
------------------------------
[ Flatten (strpy) ]
fltn = sp.flatten(splt)
0123456789abcdefghijklmnopqrstuvwxyz
(** List to Str
<class 'noopy.lst.lispy'>  ->  <class 'str'>
[ Flatten (lispy) ]
lp.flatten(splt)
['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

==============================
[[lispy]]
import noopy.lst as lp
from noopy.lst import lispy
------------------------------
By the first, this is original list.
0, 1, 2, 3, 4, 5, 
6, 7, 8, 9, a, b, 
c, d, e, f, g, h, 
i, j, k, l, m, n, 
o, p, q, r, s, t, 
u, v, w, x, y, z, 
------------------------------
[ Transpose (6x6) ]
retu.transpose(6, 6)
0, 6, c, i, o, u, 
1, 7, d, j, p, v, 
2, 8, e, k, q, w, 
3, 9, f, l, r, x, 
4, a, g, m, s, y, 
5, b, h, n, t, z, 
[ Flip LR (6x6) ]
retu.flip(6, 6, "x")
5, 4, 3, 2, 1, 0, 
b, a, 9, 8, 7, 6, 
h, g, f, e, d, c, 
n, m, l, k, j, i, 
t, s, r, q, p, o, 
z, y, x, w, v, u, 
[ Flip UD (6x6) ]
retu.flip(6, 6, "y")
u, v, w, x, y, z, 
o, p, q, r, s, t, 
i, j, k, l, m, n, 
c, d, e, f, g, h, 
6, 7, 8, 9, a, b, 
0, 1, 2, 3, 4, 5, 
[ Flip XY (6x6) ]
retu.flip(6, 6, "z")
z, y, x, w, v, u, 
t, s, r, q, p, o, 
n, m, l, k, j, i, 
h, g, f, e, d, c, 
b, a, 9, 8, 7, 6, 
5, 4, 3, 2, 1, 0, 
------------------------------
[Zeros]
lp.zeros(36)
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
[Ones]
lp.ones(36)
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
[ Linspace ]
lp.linspace(40, 80, 36, 'i')
40, 41, 42, 43, 44, 45, 
46, 47, 48, 50, 51, 52, 
53, 54, 55, 56, 57, 58, 
60, 61, 62, 63, 64, 65, 
66, 67, 68, 70, 71, 72, 
73, 74, 75, 76, 77, 78, 
------------------------------
[ Transpose (3x3) ]
lp.transpose(retu, 3, 3)
0, 3, 6, 
1, 4, 7, 
2, 5, 8, 
9, c, f, 
a, d, g, 
b, e, h, 
i, l, o, 
j, m, p, 
k, n, q, 
r, u, x, 
s, v, y, 
t, w, z, 
[ Flip LR (3x3) ]
lp.flip(retu, 3, 3, "z")
2, 1, 0, 
5, 4, 3, 
8, 7, 6, 
b, a, 9, 
e, d, c, 
h, g, f, 
k, j, i, 
n, m, l, 
q, p, o, 
t, s, r, 
w, v, u, 
z, y, x, 
[ Flip UD (3x3) ]
lp.flip(retu, 3, 3, "z")
6, 7, 8, 
3, 4, 5, 
0, 1, 2, 
f, g, h, 
c, d, e, 
9, a, b, 
o, p, q, 
l, m, n, 
i, j, k, 
x, y, z, 
u, v, w, 
r, s, t, 
[ Flip XY (3x3) ]
lp.flip(retu, 3, 3, "z")
8, 7, 6, 
5, 4, 3, 
2, 1, 0, 
h, g, f, 
e, d, c, 
b, a, 9, 
q, p, o, 
n, m, l, 
k, j, i, 
z, y, x, 
w, v, u, 
t, s, r, 

==============================
[[arrpy]]
import noopy.arr as ap
from noopy.arr import arrpy
------------------------------
typecodes: bBuhHiIlLqQfd
------------------------------
By the first, this is original [unicode 'u'] array.
0, 1, 2, 3, 4, 5, 
6, 7, 8, 9, a, b, 
c, d, e, f, g, h, 
i, j, k, l, m, n, 
o, p, q, r, s, t, 
u, v, w, x, y, z, 
------------------------------
[ Transpose (6x6) ]
gyou.transpose(6, 6)
0, 6, c, i, o, u, 
1, 7, d, j, p, v, 
2, 8, e, k, q, w, 
3, 9, f, l, r, x, 
4, a, g, m, s, y, 
5, b, h, n, t, z, 
[ Flip LR (6x6) ]
gyou.flip(6, 6, "x")
5, 4, 3, 2, 1, 0, 
b, a, 9, 8, 7, 6, 
h, g, f, e, d, c, 
n, m, l, k, j, i, 
t, s, r, q, p, o, 
z, y, x, w, v, u, 
[ Flip UD (6x6) ]
gyou.flip(6, 6, "y")
u, v, w, x, y, z, 
o, p, q, r, s, t, 
i, j, k, l, m, n, 
c, d, e, f, g, h, 
6, 7, 8, 9, a, b, 
0, 1, 2, 3, 4, 5, 
[ Flip XY (6x6) ]
gyou.flip(6, 6, "z")
z, y, x, w, v, u, 
t, s, r, q, p, o, 
n, m, l, k, j, i, 
h, g, f, e, d, c, 
b, a, 9, 8, 7, 6, 
5, 4, 3, 2, 1, 0, 
------------------------------
[Zeros]
ap.zeros(36)
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
[Ones]
ap.ones(36)
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
[ Linspace ]
ap.linspace(40, 80, 36, 'i')
40, 41, 42, 43, 44, 45, 
46, 47, 48, 50, 51, 52, 
53, 54, 55, 56, 57, 58, 
60, 61, 62, 63, 64, 65, 
66, 67, 68, 70, 71, 72, 
73, 74, 75, 76, 77, 78, 
------------------------------
[ Transpose (3x3) ]
ap.transpose(gyou, 3, 3)
0, 3, 6, 
1, 4, 7, 
2, 5, 8, 
9, c, f, 
a, d, g, 
b, e, h, 
i, l, o, 
j, m, p, 
k, n, q, 
r, u, x, 
s, v, y, 
t, w, z, 
[ Flip LR (3x3) ]
ap.flip(gyou, 3, 3, "z")
2, 1, 0, 
5, 4, 3, 
8, 7, 6, 
b, a, 9, 
e, d, c, 
h, g, f, 
k, j, i, 
n, m, l, 
q, p, o, 
t, s, r, 
w, v, u, 
z, y, x, 
[ Flip UD (3x3) ]
ap.flip(gyou, 3, 3, "z")
6, 7, 8, 
3, 4, 5, 
0, 1, 2, 
f, g, h, 
c, d, e, 
9, a, b, 
o, p, q, 
l, m, n, 
i, j, k, 
x, y, z, 
u, v, w, 
r, s, t, 
[ Flip XY (3x3) ]
ap.flip(gyou, 3, 3, "z")
8, 7, 6, 
5, 4, 3, 
2, 1, 0, 
h, g, f, 
e, d, c, 
b, a, 9, 
q, p, o, 
n, m, l, 
k, j, i, 
z, y, x, 
w, v, u, 
t, s, r, 
```

-----

## Contributing

We welcome contributions to `noopy`\! If you find a bug, have a feature request, or would like to contribute code, please check out our GitHub repository and open an issue or pull request.

-----

## License

`noopy` is licensed under the GPLv3 AND LicenseRef-RPTv1.
