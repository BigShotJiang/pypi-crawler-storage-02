"""pypjt."""

from .create import main

__all__ = ["main"]
