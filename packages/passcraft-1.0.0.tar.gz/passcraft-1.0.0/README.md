# passcraft

Advanced customizable password generator library.

## Features

- Generate passwords with full control over length and character sets.
- Option to exclude similar characters (like `l`, `1`, `O`, `0`) to avoid confusion.
- Support for uppercase, lowercase, digits, and symbols.
- Generate readable passwords made of syllables for easy memorization.
- Validate password strength and compliance with requirements.
- Command-line interface (CLI) for quick password generation.

## Installation

```bash
pip install passcraft
```

## Usage

### Demo Example

```python
from passcraft import PasswordGenerator

def main():
    gen = PasswordGenerator(
        length=16,
        exclude_similar=True,
        required_sets=["uppercase", "lowercase", "digits", "symbols"],
    )
    print("Single password:")
    print(gen.generate())

    print("\nMultiple passwords:")
    for pwd in gen.generate_multiple(5):
        print(pwd)

if __name__ == "__main__":
    main()
```

## Library Options (Parameters)

| Parameter         | Type          | Default  | Description                                                                                      |
|-------------------|---------------|----------|--------------------------------------------------------------------------------------------------|
| `length`          | int           | 12       | Length of the generated password (minimum 1)                                                    |
| `use_uppercase`   | bool          | True     | Include uppercase letters                                                                       |
| `use_lowercase`   | bool          | True     | Include lowercase letters                                                                       |
| `use_digits`      | bool          | True     | Include digits                                                                                  |
| `use_symbols`     | bool          | True     | Include symbols (`!@#$%^&*()-_=+[]{}|;:,.<>/?~`)                                                |
| `exclude_similar` | bool          | True     | Exclude similar characters like `l`, `1`, `I`, `O`, `0`                                         |
| `exclude_chars`   | str or None   | None     | Characters to exclude explicitly                                                                |
| `include_chars`   | str or None   | None     | Additional characters to always include                                                        |
| `required_sets`   | list of str   | []       | List of required character sets from `["uppercase", "lowercase", "digits", "symbols"]`          |
| `allow_readable`  | bool          | False    | Generate readable passwords made of syllables instead of random characters                       |

## Command Line Usage

Generate 3 passwords of length 12 excluding similar characters:

```bash
passcraft --length 12 --count 3 --exclude-similar
```

Generate a readable password:

```bash
passcraft --length 10 --allow-readable
```

## License

This project is licensed under the terms of the [MIT License](LICENSE).