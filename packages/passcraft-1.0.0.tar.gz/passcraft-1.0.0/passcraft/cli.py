import argparse
from passcraft import PasswordGenerator

def main():
    parser = argparse.ArgumentParser(description="Password Generator CLI")
    parser.add_argument("-l", "--length", type=int, default=12, help="Password length")
    parser.add_argument("--no-upper", action="store_false", dest="use_uppercase", help="Exclude uppercase letters")
    parser.add_argument("--no-lower", action="store_false", dest="use_lowercase", help="Exclude lowercase letters")
    parser.add_argument("--no-digits", action="store_false", dest="use_digits", help="Exclude digits")
    parser.add_argument("--no-symbols", action="store_false", dest="use_symbols", help="Exclude symbols")
    parser.add_argument("--exclude-similar", action="store_true", help="Exclude similar characters like 'l', '1', 'O', '0'")
    parser.add_argument("-c", "--count", type=int, default=1, help="Number of passwords to generate")
    parser.add_argument("--allow-readable", action="store_true", help="Allow generation of readable passwords")
    parser.add_argument("--include-chars", type=str, default="", help="Additional characters to include")
    parser.add_argument("--exclude-chars", type=str, default="", help="Characters to exclude")
    parser.add_argument("-r", "--required", nargs="*", choices=["uppercase", "lowercase", "digits", "symbols"], default=[], help="Required character sets")

    args = parser.parse_args()

    generator = PasswordGenerator(
        length=args.length,
        use_uppercase=args.use_uppercase,
        use_lowercase=args.use_lowercase,
        use_digits=args.use_digits,
        use_symbols=args.use_symbols,
        exclude_similar=args.exclude_similar,
        include_chars=args.include_chars,
        exclude_chars=args.exclude_chars,
        required_sets=args.required,
        allow_readable=args.allow_readable,
    )

    passwords = generator.generate_multiple(args.count)
    for i, pwd in enumerate(passwords, 1):
        print(f"{i}: {pwd}")

if __name__ == "__main__":
    main()