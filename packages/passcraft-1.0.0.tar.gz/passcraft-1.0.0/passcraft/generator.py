import string
import secrets
from typing import Optional, List, Dict
import re

class PasswordGenerator:
    SIMILAR_CHARS = "Il1Lo0O"
    DEFAULT_SYMBOLS = "!@#$%^&*()-_=+[]{}|;:,.<>/?~"
    READABLE_SYLLABLES = [
        "ba", "be", "bi", "bo", "bu",
        "ca", "ce", "ci", "co", "cu",
        "da", "de", "di", "do", "du",
        "fa", "fe", "fi", "fo", "fu",
        "ga", "ge", "gi", "go", "gu",
        "ha", "he", "hi", "ho", "hu",
        "ja", "je", "ji", "jo", "ju",
        "ka", "ke", "ki", "ko", "ku",
        "la", "le", "li", "lo", "lu",
        "ma", "me", "mi", "mo", "mu",
        "na", "ne", "ni", "no", "nu",
        "pa", "pe", "pi", "po", "pu",
        "ra", "re", "ri", "ro", "ru",
        "sa", "se", "si", "so", "su",
        "ta", "te", "ti", "to", "tu",
        "va", "ve", "vi", "vo", "vu",
        "wa", "we", "wi", "wo", "wu",
        "ya", "ye", "yi", "yo", "yu",
        "za", "ze", "zi", "zo", "zu",
    ]

    def __init__(
        self,
        length: int = 12,
        use_uppercase: bool = True,
        use_lowercase: bool = True,
        use_digits: bool = True,
        use_symbols: bool = True,
        exclude_similar: bool = True,
        exclude_chars: Optional[str] = None,
        include_chars: Optional[str] = None,
        required_sets: Optional[List[str]] = None,
        allow_readable: bool = False,
    ):
        self.length = max(1, length)
        self.use_uppercase = use_uppercase
        self.use_lowercase = use_lowercase
        self.use_digits = use_digits
        self.use_symbols = use_symbols
        self.exclude_similar = exclude_similar
        self.exclude_chars = exclude_chars or ""
        self.include_chars = include_chars or ""
        self.required_sets = required_sets or []
        self.allow_readable = allow_readable

        self._build_charset()

    def _build_charset(self):
        sets = {
            "uppercase": string.ascii_uppercase if self.use_uppercase else "",
            "lowercase": string.ascii_lowercase if self.use_lowercase else "",
            "digits": string.digits if self.use_digits else "",
            "symbols": self.DEFAULT_SYMBOLS if self.use_symbols else "",
        }

        charset = "".join(sets.values()) + self.include_chars
        if self.exclude_similar:
            charset = "".join(c for c in charset if c not in self.SIMILAR_CHARS)
        if self.exclude_chars:
            charset = "".join(c for c in charset if c not in self.exclude_chars)
        if not charset:
            raise ValueError("Character set is empty after applying filters.")

        self.charset = charset
        self.sets = {k: "".join(c for c in v if c in charset) for k, v in sets.items()}

    def _validate_required_sets(self):
        for set_name in self.required_sets:
            if set_name not in self.sets or not self.sets[set_name]:
                raise ValueError(f"Required character set '{set_name}' is empty or disabled.")

    def generate(self) -> str:
        if self.allow_readable:
            return self._generate_readable()

        if not self.required_sets:
            return "".join(secrets.choice(self.charset) for _ in range(self.length))

        self._validate_required_sets()
        password_chars = [secrets.choice(self.sets[set_name]) for set_name in self.required_sets]
        if len(password_chars) > self.length:
            raise ValueError("Length less than number of required character sets")

        remaining_length = self.length - len(password_chars)
        password_chars.extend(secrets.choice(self.charset) for _ in range(remaining_length))
        secrets.SystemRandom().shuffle(password_chars)
        return "".join(password_chars)

    def generate_multiple(self, count: int = 10) -> List[str]:
        return [self.generate() for _ in range(count)]

    def _generate_readable(self) -> str:
        syllables_count = max(1, self.length // 2)
        pwd_syllables = [secrets.choice(self.READABLE_SYLLABLES) for _ in range(syllables_count)]
        pwd = "".join(pwd_syllables)
        if len(pwd) > self.length:
            pwd = pwd[:self.length]
        elif len(pwd) < self.length:
            pwd += "".join(secrets.choice(string.ascii_lowercase) for _ in range(self.length - len(pwd)))
        return pwd

    def password_strength(self, password: str) -> Dict[str, any]:
        length_score = min(len(password), 20) * 5
        variety_score = sum([
            bool(re.search(r'[A-Z]', password)),
            bool(re.search(r'[a-z]', password)),
            bool(re.search(r'[0-9]', password)),
            bool(re.search(r'[!@#$%^&*()\-_+=\[\]{}|;:,.<>/?~]', password)),
        ]) * 20
        entropy = self._estimate_entropy(password)
        score = min(length_score + variety_score, 100)
        strength = "Weak"
        if score > 80:
            strength = "Strong"
        elif score > 60:
            strength = "Moderate"
        return {
            "length": len(password),
            "length_score": length_score,
            "variety_score": variety_score,
            "entropy_bits": entropy,
            "overall_score": score,
            "strength": strength,
        }

    def _estimate_entropy(self, password: str) -> float:
        pool_size = 0
        if any(c.isupper() for c in password):
            pool_size += 26
        if any(c.islower() for c in password):
            pool_size += 26
        if any(c.isdigit() for c in password):
            pool_size += 10
        if any(c in self.DEFAULT_SYMBOLS for c in password):
            pool_size += len(self.DEFAULT_SYMBOLS)
        if pool_size == 0:
            return 0.0
        return len(password) * (pool_size.bit_length())

    def validate_password(self, password: str) -> bool:
        if len(password) < self.length:
            return False
        checks = {
            "uppercase": any(c.isupper() for c in password),
            "lowercase": any(c.islower() for c in password),
            "digits": any(c.isdigit() for c in password),
            "symbols": any(c in self.DEFAULT_SYMBOLS for c in password),
        }
        for set_name in self.required_sets:
            if not checks.get(set_name, False):
                return False
        if self.exclude_similar and any(c in self.SIMILAR_CHARS for c in password):
            return False
        if self.exclude_chars and any(c in self.exclude_chars for c in password):
            return False
        return True