from pybotx_smart_logger.logger import smart_log
from pybotx_smart_logger.wrapper import wrap_smart_logger

__all__ = (
    "smart_log",
    "wrap_smart_logger",
)
