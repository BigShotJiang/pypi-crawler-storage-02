from . import l10n_nl_vat_statement
from . import l10n_nl_vat_statement_line
from . import account_move
from . import account_move_line
from . import res_company
from . import res_config_settings
