# Localtest

A command line tool to test stuff locally! This currently includes: your network. Use the command ```localtest help``` to view all available commands in your current version. Localtest was built for Hack Club's Summer of Making.

## Localtest Network

Use ```localtest network run``` to start a Network test. If you have time on your hands, you should do ```localtest network run -fs``` for a full scan!