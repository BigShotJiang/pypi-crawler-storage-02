def Override(func):
    func.override = True
    return func