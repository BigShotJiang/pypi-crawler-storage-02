"""Utility functions for EigenDA."""
