"""Generated gRPC code for EigenDA."""
