# QuickATETools: A collection of useful command-line tools
__version__ = '0.1.0'