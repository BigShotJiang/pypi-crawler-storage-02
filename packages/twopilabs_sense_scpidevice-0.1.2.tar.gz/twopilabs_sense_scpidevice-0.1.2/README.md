Base package for 2pi-Labs SENSE SCPI devices
============================================
A rudimentary package for supporting any of the 2pi-Labs Sense device with a minimally supported feature set

