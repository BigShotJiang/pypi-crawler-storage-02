from socaity.core.socaity_service_manager import SocaityServiceManager

from media_toolkit import MediaFile, ImageFile, VideoFile, AudioFile

# from socaity.sdk import official, community, replicate
# from socaity.sdk.official import *

from fastsdk import FastSDK
service_manager = FastSDK().service_manager = SocaityServiceManager()
