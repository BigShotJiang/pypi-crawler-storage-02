from .client import run_client

if __name__ == "__main__":
    run_client()