=====
Usage
=====

To use proofweb in a project::

    import proofweb
