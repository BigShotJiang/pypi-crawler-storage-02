from makeslotprop.core import *
from makeslotprop.tests import *

if __name__ == "__main__":
    main()
