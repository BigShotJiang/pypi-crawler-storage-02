if __name__ == '__main__':
    from dokuWikiDumper import dump
    dump()