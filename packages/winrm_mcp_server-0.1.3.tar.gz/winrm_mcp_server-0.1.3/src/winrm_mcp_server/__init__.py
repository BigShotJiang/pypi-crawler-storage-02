"""WinRM MCP Server for remote PowerShell command execution."""

__version__ = "0.1.3"
