# Changelog

## v0.7.25

- feat(agent_run_output): add tool_execution_suggestions property to access context suggestions
