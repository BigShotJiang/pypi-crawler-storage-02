==========
exceptions
==========

.. automodule:: advanced_alchemy.exceptions
    :members:
    :no-index: ErrorMessages
    :show-inheritance:
