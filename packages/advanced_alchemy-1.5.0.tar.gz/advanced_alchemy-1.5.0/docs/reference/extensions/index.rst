==========
Extensions
==========

API Reference for the ``Extensions`` module

.. note:: Private methods and attributes are not included in the API reference.

Available API References
------------------------

.. toctree::
    :titlesonly:

    litestar/index
    flask/index
    sanic/index
    starlette/index
    fastapi/index
