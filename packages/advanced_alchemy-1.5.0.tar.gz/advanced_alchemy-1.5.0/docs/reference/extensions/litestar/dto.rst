===
dto
===

.. automodule:: advanced_alchemy.extensions.litestar.dto
    :members:
    :exclude-members: ModelDTOT ImproperConfigurationError DTOFieldDefinition ImproperConfigurationError
