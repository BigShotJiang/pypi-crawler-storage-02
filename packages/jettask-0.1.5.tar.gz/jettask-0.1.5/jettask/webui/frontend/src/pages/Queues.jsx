import React from 'react';
import QueueMonitor from './QueueMonitor';

function Queues() {
  return <QueueMonitor />;
}

export default Queues;