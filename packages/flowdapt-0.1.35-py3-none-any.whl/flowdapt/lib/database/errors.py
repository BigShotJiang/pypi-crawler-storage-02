class WriteError(Exception):
    pass

class ReadError(Exception):
    pass
