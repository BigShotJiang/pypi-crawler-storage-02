class Immutable:
    pass
