from flowdapt.lib.domain.models.base import Resource, ResourceMetadata


__all__ = (
    "Resource",
    "ResourceMetadata",
)
