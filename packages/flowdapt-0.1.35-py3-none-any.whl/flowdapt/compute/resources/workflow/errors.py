class WorkflowExecutionError(Exception):
    pass
