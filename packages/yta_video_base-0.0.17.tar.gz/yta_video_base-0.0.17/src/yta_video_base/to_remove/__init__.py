"""
Review, refactor and remove. These modules
have something interesting but must be 
removed.
"""