JSON Schema
===========

.. jsonschema:: ../../schema/statemachine.json
