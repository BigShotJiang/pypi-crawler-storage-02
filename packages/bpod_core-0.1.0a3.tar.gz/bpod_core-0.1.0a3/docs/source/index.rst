.. include:: ../../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 3
   :hidden:

   developer_guide
   api
   schema
   changelog

.. toctree::
   :caption: Links
   :hidden:

   bpod-core on GitHub <https://github.com/int-brain-lab/bpod-core>
