HEADER_RATELIMIT_POLICY = "RateLimit-Policy"
HEADER_RATELIMIT = "RateLimit"


STATE_KEY = "navio"
