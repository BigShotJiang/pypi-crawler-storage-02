This module extends the ``website_sale`` views to display the product's full
display name, with its product reference included.
