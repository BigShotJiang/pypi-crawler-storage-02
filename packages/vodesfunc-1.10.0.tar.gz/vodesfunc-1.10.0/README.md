# vodesfunc

Contains various functions for automation and other stuff I use in my scripts.

Auto generated docs are at https://muxtools.vodes.pw.

#### This is by no means me trying to be professional and as such, the code will not be treated like it.

## Installation

`pip install vodesfunc` <br>for ~~mostly~~ stable versions

`pip install git+https://github.com/Vodes/vodesfunc.git` <br>for absolutely latest
