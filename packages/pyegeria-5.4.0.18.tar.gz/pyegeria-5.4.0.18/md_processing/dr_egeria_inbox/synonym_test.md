# Create Term

## In Glossary

Egeria-Markdown

## Term Name

List Categories

## Description

Lists the categories across all glossaries.
___

# Create Term

## In Glossary

Egeria-Markdown

## Term Name

List Glossary Categories

## Description

Lists the categories across all glossaries.

# Create Term-Term Relationship

## Term 1 Name

List Categories

## Term 2 Name

List Glossary Categories

## Term Relationship

Synonym