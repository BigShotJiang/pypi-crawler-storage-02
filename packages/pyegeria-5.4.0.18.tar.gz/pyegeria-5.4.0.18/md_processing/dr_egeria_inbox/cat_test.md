

> This is a test to see if descriptions are showing up.

# Create Glossary
## Glossary

Egeria-Markdown

## Description
This describes Dr. Egeria


___

# Create Category  
  
## Category Name  
  
Main Category
  
## Owning Glossary  
  
Glossary::Egeria-Markdown  

## Parent Category
> The parent category.

## Description  
  
A root category. with children
   

# Create Category  
  
## Category Name  
  
Child 1
  
## Owning Glossary  
  
Glossary::Egeria-Markdown  

## Parent Category

Main Category


## Description  
  
First child.

# Create Category  
  
## Category Name  
  
Child 2
  
## Owning Glossary  
  
Glossary::Egeria-Markdown  

## Parent Category
Main Category
> The parent category.

## Description  
  
Second child.


# Create Category  
  
## Category Name  
  
Grandchild 1
  
## Owning Glossary  
  
Glossary::Egeria-Markdown  

## Parent Category
Child 1
> The parent category.

## Description  
  
First grandchild.



# List Categories
## Glossary

Glossary::Egeria-Markdown

# List Glossary Structure
## Glossary

Egeria-Markdown