from .base import PayXRocketObject


class Invoice(PayXRocketObject):
    pass
