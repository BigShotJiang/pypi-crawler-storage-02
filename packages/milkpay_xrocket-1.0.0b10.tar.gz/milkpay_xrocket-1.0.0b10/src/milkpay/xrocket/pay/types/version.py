from .base import PayXRocketObject


class Version(PayXRocketObject):
    version: str
