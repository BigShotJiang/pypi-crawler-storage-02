from .base import TradeXRocketObject


class CryptoCurrenciesResponseDto(TradeXRocketObject):
    success: bool
    """Indicate if request is successful"""
