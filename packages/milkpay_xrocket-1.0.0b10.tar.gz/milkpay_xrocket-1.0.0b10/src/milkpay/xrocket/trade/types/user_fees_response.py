from .base import TradeXRocketObject


class UserFeesResponse(TradeXRocketObject):
    success: bool
    """Indicate if request is successful"""
