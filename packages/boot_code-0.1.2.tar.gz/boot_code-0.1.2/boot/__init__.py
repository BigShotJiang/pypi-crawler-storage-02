"""
Spex Package Initialization

This file makes the 'boot' directory a Python package and exposes the package
version at the top level.
"""

__version__ = "0.1.0"
