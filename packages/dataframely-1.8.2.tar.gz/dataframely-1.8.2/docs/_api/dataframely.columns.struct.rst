dataframely.columns.struct module
=================================

.. automodule:: dataframely.columns.struct
   :members:
   :show-inheritance:
   :undoc-members:
