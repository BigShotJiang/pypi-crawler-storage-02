#  Copyright (C) 2023 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Just the version"""


def about():
    """Return"""
    return "This is the Lofar SID interface library"
