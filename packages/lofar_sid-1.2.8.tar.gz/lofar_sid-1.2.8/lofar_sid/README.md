# sid

![Build status](https://git.astron.nl/lofar2.0/sid/badges/main/pipeline.svg)
![Test coverage](https://git.astron.nl/lofar2.0/sid/badges/main/coverage.svg)
<!-- ![Latest release](https://git.astron.nl/lofar2.0/sid/badges/main/release.svg) -->


## License
This project is licensed under the Apache License Version 2.0
