.. _examples:
Examples
########

.. nbgallery::
    notebooks/example1
    notebooks/example2
    notebooks/example3
    notebooks/example4