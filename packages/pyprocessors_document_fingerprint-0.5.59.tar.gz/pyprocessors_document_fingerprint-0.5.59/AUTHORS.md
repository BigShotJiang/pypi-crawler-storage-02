# Authors

Contributors to pyprocessors_document_fingerprint include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
