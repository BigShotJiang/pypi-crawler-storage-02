# Changelog

## [0.2.0] - 2025-01-08
### Added
- Added support for grouping similar GPUs
- Add support for multi-node cluster creation

## [0.1.0] - 2025-01-05
### Added
- Initial CLI implementation

