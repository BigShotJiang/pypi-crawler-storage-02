#!/usr/bin/env python

"""Tests for `autorpt` package."""


import unittest

from autorpt import autorpt


class TestAutorpt(unittest.TestCase):
    """Tests for `autorpt` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
