"""Contains methods for accessing the Vulnissimo API"""
