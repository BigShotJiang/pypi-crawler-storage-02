from ..SWING.IntervalSWING import IntervalSWING

class IntervalPointAllocation(IntervalSWING):
    """
    This class is a direct alias of IntervalSWING for Point Allocation method.
    """
    pass
