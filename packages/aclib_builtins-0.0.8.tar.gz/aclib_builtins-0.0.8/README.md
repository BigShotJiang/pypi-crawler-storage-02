# Installation
    pip install aclib.builtins

# Usage
    # from aclib import builtins
    # import aclib.builtins
    from aclib.builtins import Object, Str, Bin, Oct, Hex, BaseNumber
    from aclib.builtins import decorator, SELF
    from aclib.builtins import Rect, MatTarget
