``pdsparser`` Module
====================

.. automodule:: pdsparser
    :member-order: bysource
    :members:
    :undoc-members:
    :special-members:
    :show-inheritance:
    :exclude-members: __dict__, __hash__, __module__, __weakref__

.. automodule:: pdsparser.utils
    :member-order: bysource
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: __dict__, __hash__, __module__, __weakref__, __annotations__

