
Welcome to ``pdsparser``'s documentation!
===========================================

.. include:: ../README.md
   :parser: myst_parser.sphinx_
   :start-after: forks/SETI/rms-pdsparser)

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   module

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
