#!/usr/bin/env python3
"""
模块入口点文件，使得可以通过 python -m fit_growth_mcp_tools 运行
"""

from . import main

if __name__ == "__main__":
    main()