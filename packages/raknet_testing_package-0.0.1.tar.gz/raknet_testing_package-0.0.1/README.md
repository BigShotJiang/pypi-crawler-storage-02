# My Simple Package

A very basic example of a Python package, created to demonstrate the process of packaging and uploading to PyPI.

## Installation

You can install this package using pip:

```bash
pip install my-simple-package
