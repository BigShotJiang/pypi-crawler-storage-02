"""
A simple Python package for demonstration.
"""

def say_hello(name):
    """
    A simple function that returns a greeting.

    Args:
        name (str): The name of the person to greet.

    Returns:
        str: A personalized greeting.
    """
    return f"Hello, {name}!"

def calculate_sum(a, b):
    """
    A function that calculates the sum of two numbers.

    Args:
        a (int or float): The first number.
        b (int or float): The second number.

    Returns:
        int or float: The sum of the two numbers.
    """
    return a + b
