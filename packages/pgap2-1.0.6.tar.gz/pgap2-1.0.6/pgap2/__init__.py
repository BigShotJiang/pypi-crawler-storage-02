import importlib.metadata

__version__ = importlib.metadata.version("pgap2")
__author__ = 'Congfan Bu'
