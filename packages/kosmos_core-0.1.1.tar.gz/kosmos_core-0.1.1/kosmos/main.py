def main() -> None:
    """Run the main entry point."""
    print("Hello, World!")  # noqa: T201


if __name__ == "__main__":
    main()
