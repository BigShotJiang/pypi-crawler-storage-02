from .runner import *
from .functions_page import *
from .initialize_init import *
from .finder import *
from .apigui import *
def getManagerFuncs(self):
    self.getRunner = getRunner
    self.initializeInit = initializeInit
