"""Sherpa multirole plugins"""
__version__ = "0.5.667"
