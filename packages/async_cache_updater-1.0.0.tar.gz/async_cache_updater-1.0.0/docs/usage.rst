=====
Usage
=====

To use Async Cache Updater in a project::

    import async_cache_updater
