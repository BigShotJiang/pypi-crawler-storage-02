=======
History
=======

1.0.0 (2025-08-14)
------------------

* Replace aioredis with redis-py
* Require Python 3.9+
* Add ignore_args setting to ignore specific arguments in cache keys

0.1.5 (2021-12-15)
------------------

* Add disabled setting

0.1.4 (2021-09-21)
------------------

* Fix aioredis client

0.1.3 (2021-09-21)
------------------

* Fix aioredis client

0.1.2 (2021-09-14)
------------------

* Fix cache get_many

0.1.1 (2021-09-01)
------------------

* Fix README

0.1.0 (2021-08-28)
------------------

* First release on PyPI.
