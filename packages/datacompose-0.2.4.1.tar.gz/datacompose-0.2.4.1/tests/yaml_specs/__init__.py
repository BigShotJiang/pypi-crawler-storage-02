"""YAML/spec validation tests package."""
