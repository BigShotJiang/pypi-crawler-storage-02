"""Email cleaning transformer."""
