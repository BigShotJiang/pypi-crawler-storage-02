"""
UDF generators for different platforms.
"""
