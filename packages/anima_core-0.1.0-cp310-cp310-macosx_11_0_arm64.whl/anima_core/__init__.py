from .anima_core import *

__doc__ = anima_core.__doc__
if hasattr(anima_core, "__all__"):
    __all__ = anima_core.__all__