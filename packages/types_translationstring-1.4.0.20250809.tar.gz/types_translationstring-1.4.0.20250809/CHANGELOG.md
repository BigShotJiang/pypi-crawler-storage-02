## 1.4.0.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 1.4.0.20240301 (2024-03-01)

Fix invalid noqa comments and poorly formatted type ignores (#11497)

## 1.4.0.1 (2023-07-20)

Add an upstream_repository field to METADATA.toml (#10487)

Closes: #10478

## 1.4.0.0 (2023-03-22)

Add stubs for translationstring (#9918)

