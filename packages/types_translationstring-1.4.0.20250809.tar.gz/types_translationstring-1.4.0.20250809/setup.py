
from setuptools import setup

setup(package_data={'translationstring-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
