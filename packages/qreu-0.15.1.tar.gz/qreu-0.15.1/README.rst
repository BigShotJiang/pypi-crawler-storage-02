Qreu
====

.. image:: https://travis-ci.org/gisce/qreu.svg?branch=master
    :target: https://travis-ci.org/gisce/qreu
.. image:: https://coveralls.io/repos/github/gisce/qreu/badge.svg?branch=master
    :target: https://coveralls.io/github/gisce/qreu?branch=master


Email Wrapper to `python email module <https://docs.python.org/library/email.html>`_

Tested with python 2.7 and 3.5
