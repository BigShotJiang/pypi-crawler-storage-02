"""Adapter functions for pyprland."""
