# CHANGELOG

# v0.1.0 (2025-08-08)

## 💫 New features

- Python function based wrappers around some parts of the Internxt CLI
- `InternxtDrive` class for path-based operations on an Internxt Drive
- git-annex special remote implementation with export-tree capabilities
