# Do not remove the below imports, functions were moved to netutils, but to not
# break backwards compatibility, these should remain
from netutils.constants import BASE_INTERFACES as base_interfaces  # noqa
from netutils.constants import REVERSE_MAPPING as reverse_mapping  # noqa
