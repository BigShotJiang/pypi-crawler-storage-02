class Command:
    """
    Just a test:
    Only modules with a Command that subclasss from django.core.management.base.BaseCommand
    should be recognized.
    """

    pass
