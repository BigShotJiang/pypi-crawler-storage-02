# flake8: noqa: E405

"""
    Django settings for production
"""

from .base import *  # noqa
