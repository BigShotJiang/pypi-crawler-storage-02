"""FraiseQL extensions package."""
