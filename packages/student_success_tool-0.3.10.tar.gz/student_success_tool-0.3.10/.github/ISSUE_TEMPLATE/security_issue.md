---
name: Security issue
about: Report a security issue
title: ''
labels: ''
assignees: ''

---

**Describe the bug**

**Security issue description**

*Describe the security issue here*

**Impact**

*What impact does this security issue have?*

**Mitigation**

*If you have suggestions to mitigate the issue, please provide them here*
