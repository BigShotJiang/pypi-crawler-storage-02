## cdf 

### Fixed

- [alpha] Add support for running `cdf profile asset-centric` for a
single hierarchy.

## templates

No changes.