knitout\_interpreter.knitout\_operations.kick\_instruction module
=================================================================

.. automodule:: knitout_interpreter.knitout_operations.kick_instruction
   :members:
   :undoc-members:
   :show-inheritance:
