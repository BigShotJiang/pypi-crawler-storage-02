knitout\_interpreter.knitout\_operations.Pause\_Instruction module
==================================================================

.. automodule:: knitout_interpreter.knitout_operations.Pause_Instruction
   :members:
   :undoc-members:
   :show-inheritance:
