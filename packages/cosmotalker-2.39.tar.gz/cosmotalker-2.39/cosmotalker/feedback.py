import webbrowser
def feedback():
    webbrowser.open("https://forms.gle/CKXt6BPNy2Kza5av8")

