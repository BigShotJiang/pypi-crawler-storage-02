"""This package contains various toolboxes used across the fabricatio_plot module.

Each toolbox is designed to provide specific functionalities required for
data visualization and processing tasks in the Fabricatio framework.
"""
