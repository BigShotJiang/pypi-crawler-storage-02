"""Models defined in fabricatio-plot."""
