import { qgisplugin } from './plugins';

export default [qgisplugin];
