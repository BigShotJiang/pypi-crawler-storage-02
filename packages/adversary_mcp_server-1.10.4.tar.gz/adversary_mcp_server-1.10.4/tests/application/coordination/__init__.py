"""Tests for application coordination layer."""
