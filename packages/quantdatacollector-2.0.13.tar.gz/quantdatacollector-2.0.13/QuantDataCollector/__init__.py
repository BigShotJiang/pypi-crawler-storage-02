from .data_collector import DataCollector
import sys

module = sys.modules[__name__] = DataCollector
