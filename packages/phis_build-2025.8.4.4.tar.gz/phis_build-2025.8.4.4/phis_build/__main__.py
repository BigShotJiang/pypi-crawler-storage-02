from phis_build.main import main
main()