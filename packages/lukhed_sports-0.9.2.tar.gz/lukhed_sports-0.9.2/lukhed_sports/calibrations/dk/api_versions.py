api_versions = {
    "baseUrl": "https://sportsbook-nash.draftkings.com/api",
    "playerUrl": "https://gaming.draftkings.com/api/players",
    "navVersion": "v2",
    "groupVersion": "v1",
    "playerVersion": "v1",
    "defaultSportsbook": "dkusmi"
}