
__version__ = "3.4.0" if "{" not in "3.4.0" else "0.0.0"

#Exported functions
__all__ = []
