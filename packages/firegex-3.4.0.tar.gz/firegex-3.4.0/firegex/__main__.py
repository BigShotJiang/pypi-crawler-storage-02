#!/usr/bin/env python3

from firegex.cli import run

if __name__ == "__main__":
    run()
