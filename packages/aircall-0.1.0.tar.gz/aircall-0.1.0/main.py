def main():
    print("Hello from aircall-python-sdk!")


if __name__ == "__main__":
    main()
