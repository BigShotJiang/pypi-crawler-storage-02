
from setuptools import setup

setup(package_data={'dockerfile_parse-stubs': ['__init__.pyi', 'constants.pyi', 'parser.pyi', 'util.pyi', 'METADATA.toml', 'py.typed']})
