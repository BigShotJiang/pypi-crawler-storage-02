"""
Placeholder package for predicat-model-factory.
"""
__all__ = []
__version__ = "0.0.0a1"
