def test_ci_is_working():
    """A simple test to ensure the pytest setup is correct."""
    assert True
