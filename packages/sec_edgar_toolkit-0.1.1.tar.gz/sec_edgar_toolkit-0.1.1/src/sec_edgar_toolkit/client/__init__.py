"""SEC EDGAR API client."""

from .sec_edgar_api import SecEdgarApi

__all__ = [
    "SecEdgarApi",
]
