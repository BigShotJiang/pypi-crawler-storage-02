This module provides `FastAPI` `Depends` to allow authentication with
[Odoo's API
Keys](https://www.odoo.com/documentation/master/developer/reference/external_api.html#api-keys).
