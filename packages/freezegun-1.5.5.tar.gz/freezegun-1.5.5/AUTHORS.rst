Patches and Suggestions
```````````````````````

- `Dan Miller <https://github.com/dnmiller>`_
- `Matthew Schinckel <https://github.com/schinckel>`_
- `JJ Geewax <https://github.com/jgeewax>`_
- `Roman Imankulov <https://github.com/imankulov>`_
- `Martin Geisler <https://github.com/mgeisler>`_
- `Richard Eames <https://github.com/Naddiseo>`_
- `Tye Wang <https://github.com/tyewang>`_
- `Andreas Pelme <https://github.com/pelme>`_
- `Jesse London <https://github.com/jesteria>`_
- `Zach Smith <https://github.com/zmsmith>`_
- `Adam Johnson <https://github.com/adamchainz>`_
- `Alex Ehlke <https://github.com/aehlke>`_
- `James Lu <github.com/CrazyPython>`_
- `Dan Elkis <github.com/rinslow>`_
- `Bastien Vallet <github.com/djailla>`_
- `Julian Mehnle <github.com/jmehnle>`_
- `Lukasz Balcerzak <https://github.com/lukaszb>`_
- `Hannes Ljungberg <hannes@5monkeys.se>`_
- `staticdev <staticdev-support@proton.me>`_
- `Marcin Sulikowski <https://github.com/marcinsulikowski>`_
- `Ashish Patil <https://github.com/ashishnitinpatil>`_
- `Victor Ferrer <https://github.com/vicfergar>`_
