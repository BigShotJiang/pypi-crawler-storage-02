"""SpacyMatcher annotator using the spacy rule-matching engine"""
__version__ = "0.5.83"
