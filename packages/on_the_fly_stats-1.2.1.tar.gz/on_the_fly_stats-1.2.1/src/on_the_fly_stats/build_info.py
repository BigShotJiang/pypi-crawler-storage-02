class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '1.2.1'
    git_sha = '9bbae861c641e2e6a354810021490c4fd762a219'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
