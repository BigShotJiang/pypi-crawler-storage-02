"""optimise - subpackage for the optimisation interface that relies on the modelling framework plus optax."""
