(heading-target)=
# Get Involved
```{include} ../CONTRIBUTING.md
:start-after: How To Contribute
```
