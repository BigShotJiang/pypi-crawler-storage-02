#pragma once

#define EVI_VERSION "1.0.0"

#define EVI_MAJOR_VERSION 1
#define EVI_MINOR_VERSION 0
#define EVI_PATCH_VERSION 0
