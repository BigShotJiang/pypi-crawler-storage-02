from es2.index.index import Index, IndexConfig
