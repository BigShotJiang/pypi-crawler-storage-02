# ee07/__init__.py
from .interpreter import run_code
