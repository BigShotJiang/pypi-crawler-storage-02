# -*- coding: utf-8 -*-
from .video_source import OpencvBackendMode, VideoSource
