from dataclasses import dataclass


@dataclass
class UptimeInfo:
    def __init__(self):
        self.uptime = ""
