from .osBase import OSDetect


__all__ = ['OSDetect']
