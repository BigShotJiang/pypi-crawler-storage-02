from ._version import __version__

params = {
    "version": __version__,
}
