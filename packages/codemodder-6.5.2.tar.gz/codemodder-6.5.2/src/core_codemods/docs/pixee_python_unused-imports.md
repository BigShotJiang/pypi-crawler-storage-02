Removes unused imports from a module. Imports involving the `__future__` module are ignored.

```diff
- import a 
import b

b.function()
```
