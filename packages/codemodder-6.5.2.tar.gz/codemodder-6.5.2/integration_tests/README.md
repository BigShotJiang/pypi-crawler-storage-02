# Integration tests

These tests should use minimal (none is best) amount of mocking to tells the full program.
