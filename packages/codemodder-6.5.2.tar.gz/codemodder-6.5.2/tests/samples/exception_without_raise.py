try:
    ValueError
except:
    pass
