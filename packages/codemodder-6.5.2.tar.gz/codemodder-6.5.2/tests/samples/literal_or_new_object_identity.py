def foo(l):
    return l is [1,2,3]
