class MyClass:
    def instance_method():
        print("instance_method")

    @classmethod
    def class_method():
        print("class_method")
