assert (1 == 1, 2 == 2)
