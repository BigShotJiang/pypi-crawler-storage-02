import math


def foo(a):
    return math.isclose(a, 0)
