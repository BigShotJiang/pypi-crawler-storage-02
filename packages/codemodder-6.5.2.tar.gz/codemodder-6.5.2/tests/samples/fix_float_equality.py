def foo(a, b):
    return a == b - 0.1
