# tqdm-rich-logger

A Rich + TQDM-safe logger by Momo 🐍  
Supports:

- Beautiful colored console logs
- Log-safe tqdm support
- File logging
- Exception capturing for both main and threads
