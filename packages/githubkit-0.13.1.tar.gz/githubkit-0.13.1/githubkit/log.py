import logging

logger = logging.getLogger("githubkit")
