from cm_colors.core.cm_colors import CMColors

__version__ = "0.1.0"

__all__ = ["CMColors"]
