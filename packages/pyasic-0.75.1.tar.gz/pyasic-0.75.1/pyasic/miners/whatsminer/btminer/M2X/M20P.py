from pyasic.miners.backends import M2X
from pyasic.miners.device.models import M20PV10


class BTMinerM20PV10(M2X, M20PV10):
    pass


from pyasic.miners.device.models import M20PV30


class BTMinerM20PV30(M2X, M20PV30):
    pass
