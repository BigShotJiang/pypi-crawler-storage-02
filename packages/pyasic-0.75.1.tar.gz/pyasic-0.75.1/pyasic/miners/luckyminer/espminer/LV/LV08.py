from pyasic.miners.backends.luckyminer import LuckyMiner
from pyasic.miners.device.models.luckyminer import LV08


class LuckyMinerLV08(LuckyMiner, LV08):
    pass
