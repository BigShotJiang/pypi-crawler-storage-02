#!/usr/bin/env python
"""
Normalize Jupyter notebooks
"""
import utils as ut
ut.normalize_notebooks()
