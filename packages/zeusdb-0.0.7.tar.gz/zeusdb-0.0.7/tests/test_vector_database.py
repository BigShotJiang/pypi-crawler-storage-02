def test_vector_database_import():
    from zeusdb import VectorDatabase
    assert VectorDatabase is not None
