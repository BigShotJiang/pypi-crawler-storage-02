"""A script to run the GUI. Mainly for debugging. The entrypoint script is the preferred way of
running program. """

from dusc_explorer import main

if __name__ == '__main__':
    main()
