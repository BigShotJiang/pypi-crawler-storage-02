
========================
 Command Line Interface
========================

The primary way of using the telemetry framework day to day is via the
command line.

WuttJamaican defines the ``wutta`` :term:`command` and WuttaTell comes
with an extra :term:`subcommand` for submitting telemetry data.

For more general info about CLI see
:doc:`wuttjamaican:narr/cli/index`.

.. toctree::
   :maxdepth: 2

   builtin
