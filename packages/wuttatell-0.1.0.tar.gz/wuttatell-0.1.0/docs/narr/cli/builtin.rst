
===================
 Built-in Commands
===================

Below are the :term:`subcommands <subcommand>` which come with
WuttaTell.


.. _wutta-tell:

``wutta tell``
--------------

Collect and submit telemetry data.

Defined in: :mod:`wuttatell.cli.tell`

.. program-output:: wutta tell --help
