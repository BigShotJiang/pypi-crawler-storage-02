
``wuttatell.cli.tell``
======================

.. automodule:: wuttatell.cli.tell
   :members:
