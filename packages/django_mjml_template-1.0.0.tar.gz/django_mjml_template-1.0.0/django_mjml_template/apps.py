from django.apps import AppConfig


class DjangoMjmlTemplateConfig(AppConfig):
    name = "django_mjml_template"
    verbose_name = "Django MJML Template"
