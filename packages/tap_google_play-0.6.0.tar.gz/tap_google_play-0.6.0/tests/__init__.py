"""Test suite for tap-google-play."""
