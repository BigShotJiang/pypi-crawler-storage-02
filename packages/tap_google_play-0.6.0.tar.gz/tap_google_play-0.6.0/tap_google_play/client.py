"""HTTP Client for GooglePlay tap."""

from __future__ import annotations

from singer_sdk.streams import Stream


class GooglePlayStream(Stream):
    """Stream class for GooglePlay streams."""
