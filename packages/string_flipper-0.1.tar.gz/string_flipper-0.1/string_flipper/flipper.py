
def flip(text):
    """Flips the input string (reverse order)."""
    return text[::-1]
