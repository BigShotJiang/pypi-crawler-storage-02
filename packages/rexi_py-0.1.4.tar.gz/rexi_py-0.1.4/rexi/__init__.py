"""
Rexi Python API Client

A Python library for interacting with the Rexi API.
"""

from .rexi_api import RexiAPI

__all__ = ['RexiAPI']
