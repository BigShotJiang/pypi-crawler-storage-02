"""When imported forces matplotlib to use Agg backend. Useful for tests."""
import matplotlib
matplotlib.use('Agg')
