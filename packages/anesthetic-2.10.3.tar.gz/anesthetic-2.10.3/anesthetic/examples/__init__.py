"""Module for generating example data of nested sampling."""
