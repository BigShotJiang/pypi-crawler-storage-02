"""Module for reading samples from file."""
