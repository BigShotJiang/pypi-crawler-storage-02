"""Graphical user interface for inspecting nested sampling runs."""
