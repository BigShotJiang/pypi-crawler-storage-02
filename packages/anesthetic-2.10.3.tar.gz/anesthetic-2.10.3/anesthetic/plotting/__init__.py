"""Plotting public API.

.. autoclass:: anesthetic.plotting.PlotAccessor
"""
from anesthetic.plotting._core import PlotAccessor # noqa: 401
