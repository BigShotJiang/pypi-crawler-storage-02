---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**Describe the bug**


**Steps to reproduce**


**Expected behavior**


**Suggested solutions**


**Additional Information**

- **qiskit-ibm-runtime version**:
- **Python version**:
- **Operating system**:
