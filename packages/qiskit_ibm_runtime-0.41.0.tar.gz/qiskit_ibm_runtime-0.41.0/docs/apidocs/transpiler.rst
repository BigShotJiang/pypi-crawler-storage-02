.. automodule:: qiskit_ibm_runtime.transpiler.passes
   :no-members:
   :no-inherited-members:
   :no-special-members:
