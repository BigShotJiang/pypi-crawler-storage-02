.. automodule:: qiskit_ibm_runtime.utils.noise_learner_result
   :no-members:
   :no-inherited-members:
   :no-special-members:
