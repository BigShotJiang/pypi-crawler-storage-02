# labelize

Utility to print electronics organization labels for Brother label printers.  
![resistors](img/resistors_scn.png)

## install:

### install ptouch-print

requires ptouch-print utility.  install and usage instructions [HERE](https://github.com/HenrikBengtsson/brother-ptouch-label-printer-on-linux)

### install Labelize

```
pip install labelize
```
