ndimage-enaml
=============

Common package used by `cochleogram` and `synaptogram`.
