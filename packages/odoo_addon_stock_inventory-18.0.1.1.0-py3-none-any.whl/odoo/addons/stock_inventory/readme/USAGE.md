Go to Inventory / Operations / Inventory Adjustments. Here you can see
the list of Adjustment Grouped. If you create a new Group, you can
choose 2 types of product selection: - All Products (all products from
theselected locations). - Manual Selection (choose manually each product
in location). - One Product (choose only one product in locations). -
Lot Serial Number (choose one product, any lots and locations). -
Product Category (choose one product category \[childs also taken into
account\]). When you start the adjustment (only one at a time) clicking
on adjustments gets you to the view where adjustments are made. From the
group view, if you click on Stock Moves you can see the movements done
(includes the 0 qty moves).
