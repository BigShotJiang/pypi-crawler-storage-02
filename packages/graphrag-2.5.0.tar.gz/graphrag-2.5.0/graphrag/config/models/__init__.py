# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""Interfaces for Default Config parameterization."""
