from .BinarySequence import BinarySequence


class GoldSequence(BinarySequence):
    r"""
    Gold sequence [Not implemented yet].
    """

    pass
