from alderaan.recipes.subrecipes import startup


def main():
    print("starting main recipe")

    startup.execute()






if __name__ == '__main__':
    main()