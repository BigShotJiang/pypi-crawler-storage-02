"""Tests for the scythe package."""
