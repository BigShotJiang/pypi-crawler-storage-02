# TRPL-M

Got some time to spare? Then master mental math!

## Installation

In your terminal run the following command:

```bash
pip install trpl-m
trpl-m
```

## License

MIT License - more details in the  [LICENSE](LICENSE) file.
