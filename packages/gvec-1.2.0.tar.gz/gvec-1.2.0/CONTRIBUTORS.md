# List of Contributors

GVEC is being developed and maintained by

* Florian Hindenlang (2017.. )
* Robert Babin (2024.. )

with additional contributions (both theoretical and code) from

* Eric Sonnendrücker (2017.. )
* Claus-Dieter Munz (2017.. )
* Omar Maj (2017.. )
* Alejandro Banon Navarro (2019)
* Denis Jarema (2019)
* Maurice Maurer (2019)
* Erika Strumberger (2019)
* Joachim Geiger (2019)
* Matthias Borchardt (2019)
* Markus Rampp (2020)
* Tiago Tamissa Ribeiro (2021.. )
* Rohan Ramasamy (2021)
* Robert Köberl (2023.. )
* Gabriel Plunk (2024.. )
* Dean Muir (2025.. )
