# f90wrap kind map: defining data type mapping between Fortran and C
# in f2py_f2cmap format
{
    "real": {
        "": "double",
        "4": "float",
        "8": "double",
        "wp": "double",
    },
}
