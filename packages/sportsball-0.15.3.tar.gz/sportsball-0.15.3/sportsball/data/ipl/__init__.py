"""The ipl data sportsball module."""

# ruff: noqa: F401
from .combined.ipl_combined_league_model import \
    IPLCombinedLeagueModel as IPLLeagueModel
