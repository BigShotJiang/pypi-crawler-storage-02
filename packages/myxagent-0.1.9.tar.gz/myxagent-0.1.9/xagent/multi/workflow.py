"""Workflow management for multi-agent coordination."""

class Workflow:
    """Represents a single step in a workflow."""
    
    def __init__(self):
        pass