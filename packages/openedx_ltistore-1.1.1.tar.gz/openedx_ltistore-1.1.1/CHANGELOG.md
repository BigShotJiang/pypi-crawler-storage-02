Change Log
==========

Unreleased
----------

*


1.1.0 – 2025-05-21
------------------

### Added

* Initial release to PyPI.
* CI pipelines.
* Django 5.2 support.
