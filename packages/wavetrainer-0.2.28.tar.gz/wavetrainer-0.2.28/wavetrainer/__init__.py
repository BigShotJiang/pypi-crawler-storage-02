"""The wavetrain main module."""

from .create import create

__VERSION__ = "0.2.28"
__all__ = ("create",)
