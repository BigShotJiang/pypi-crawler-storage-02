### PUT TODOs HERE, FUTURE WILL DO IT FOR YOU ###
1. ~~video.write()~~ Apr 30 2025
2. ~~video read~~ Apr 30 2025
3. Image class but C H W(should be H W C)
4. ~SSIM/PSNR/FID/... metrics implementations~ May 26 2025
5. save a list of images to gif(or video)
6. ~~add lossless video save function~~ May 26 2025
7. ~~vd should not read all frames in read_video()~~ May 31 2025
8. ~~filesystem should allow called via fout = fs(fpath, **image=i**) instead of ':'~~
9. sync from 3.12.6 local python zhenglin package(hot modification) -> C:\Users\Lenovo\AppData\Roaming\Python\Python312\site-packages\zhenglin\filesystem\filesystem.py
10. ~~frame.w and frame.h~~ May 31 2025
11. ~~fast gen file json~~ Jun 15 2025
12. ~~use 'with' to break down image patch automatically. i.e. 'with patch ...' ~~ Jul 16 2025
13. add cv.thresh(), cv.concat()