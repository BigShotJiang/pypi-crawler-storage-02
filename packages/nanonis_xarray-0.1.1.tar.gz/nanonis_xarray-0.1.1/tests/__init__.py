"""Tests for nanonis_xarray."""
