from pathlib import Path
packagePath = Path(__file__).parent
tempPath = packagePath / "temp"
userProjectPath = userProjectPath = Path.cwd() 
