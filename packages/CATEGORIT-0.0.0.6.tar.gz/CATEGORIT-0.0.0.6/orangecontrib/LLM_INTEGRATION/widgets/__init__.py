"""
Widgets from Development workflow category

"""
# ID = "orangecontrib.AAIT"

NAME = "AAIT - LLM INTEGRATION"

# Category icon show in the menu
ICON = "icons/ai.png"

BACKGROUND = "brown"

DESCRIPTION = ("AAIT -  is a package meant to develop and enable advanced AI "
               "functionalities in Orange Data Mining.")



# PRIORITY = 6