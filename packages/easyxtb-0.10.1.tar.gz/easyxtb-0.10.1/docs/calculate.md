::: easyxtb.calculate
    options:
      members_order: source
      heading_level: 2
