::: easyxtb.Program

## Pre-configured Programs

When the package is imported, `Program` instances for `xtb` and `crest` are automatically configured.

If you wish to change the binary used for one of the programs, set `XTB.path` or `CREST.path` as appropriate.

::: easyxtb.XTB

::: easyxtb.CREST
