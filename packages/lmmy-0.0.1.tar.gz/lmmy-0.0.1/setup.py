from setuptools import setup

setup(
    name='lmmy',
    version='0.0.1',
    description='lmmy',
    author='LM Studio',
    author_email='team@lmstudio.ai',
    zip_safe=False
)