|pypi| |actions| |codecov| |downloads| |clinicedc|

edc-view-utils
--------------

Simple utilities for views in clinicedc/edc projects.

.. |pypi| image:: https://img.shields.io/pypi/v/edc-view-utils.svg
    :target: https://pypi.python.org/pypi/edc-view-utils

.. |actions| image:: https://github.com/clinicedc/edc-view-utils/actions/workflows/build.yml/badge.svg
  :target: https://github.com/clinicedc/edc-view-utils/actions/workflows/build.yml

.. |codecov| image:: https://codecov.io/gh/clinicedc/edc-view-utils/branch/develop/graph/badge.svg
  :target: https://codecov.io/gh/clinicedc/edc-view-utils

.. |downloads| image:: https://pepy.tech/badge/edc-view-utils
   :target: https://pepy.tech/project/edc-view-utils

.. |clinicedc| image:: https://img.shields.io/badge/framework-Clinic_EDC-green
   :alt:Made with clinicedc
   :target: https://github.com/clinicedc
