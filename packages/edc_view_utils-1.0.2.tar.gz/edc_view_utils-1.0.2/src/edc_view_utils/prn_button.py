from dataclasses import dataclass

from .model_button import ModelButton


@dataclass
class PrnButton(ModelButton):
    pass
