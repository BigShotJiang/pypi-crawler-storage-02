"""
Utility modules for DRF to MkDocs documentation generation.
"""
