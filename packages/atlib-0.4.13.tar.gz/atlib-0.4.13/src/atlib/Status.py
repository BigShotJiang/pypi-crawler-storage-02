class Status:
    OK = "OK"
    PROMPT = "> "
    TIMEOUT = "TIMEOUT"
    ERROR_SIM_PUK = "ERORR_SIM_PUK"
    ERROR = "ERROR"
    UNKNOWN = "UNKNOWN"
