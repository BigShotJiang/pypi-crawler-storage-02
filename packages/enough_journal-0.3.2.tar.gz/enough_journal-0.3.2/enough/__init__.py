#!/usr/bin/env python3
"""
ENOUGH - Nathaniel Branden Sentence Completion Journal
"""

from .journaler import main

if __name__ == "__main__":
    main() 