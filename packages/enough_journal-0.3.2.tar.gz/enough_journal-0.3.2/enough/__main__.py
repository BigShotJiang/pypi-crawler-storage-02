#!/usr/bin/env python3
"""
ENOUGH - Nathaniel Branden Sentence Completion Journal
Main entry point for python -m enough
"""

from .journaler import main

if __name__ == "__main__":
    main() 