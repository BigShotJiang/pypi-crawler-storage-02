# module initialization
from .adapta_test import main as test
from .adapta_main import main
