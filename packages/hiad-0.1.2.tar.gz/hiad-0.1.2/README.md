HiAD: A General High-Resolution Industrial Image Anomaly Detection Framework (通用的高分辨率工业图像异常检测框架)   
Project: [cnulab/HiAD](https://github.com/cnulab/HiAD)
