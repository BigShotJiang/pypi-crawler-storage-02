# This file makes the sig_scaffold directory a Python package.
