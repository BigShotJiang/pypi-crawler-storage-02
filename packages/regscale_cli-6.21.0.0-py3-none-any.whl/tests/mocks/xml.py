"""Provide mock content for XML functions."""

XML_CONTENT = """<?xml version="1.0" encoding="UTF-8"?>
<root>
    <item>
        <id>1</id>
        <name>Item 1</name>
    </item>
    <item>
        <id>2</id>
        <name>Item 2</name>
    </item>
</root>"""
