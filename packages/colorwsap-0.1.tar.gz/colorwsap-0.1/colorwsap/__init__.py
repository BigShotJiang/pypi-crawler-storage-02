from .core import swap_color
