"""
Validators for pypipq.
Each validator should inherit from BaseValidator.
"""