__author__ = "ziyan.yin"
__date__ = "2025-01-10"

from .redis import RedisCli as Redis

__all__ = ["Redis"]
