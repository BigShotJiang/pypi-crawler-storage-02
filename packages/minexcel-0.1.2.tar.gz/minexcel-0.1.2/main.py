def main():
    print("Hello from minexcel!")


if __name__ == "__main__":
    main()
