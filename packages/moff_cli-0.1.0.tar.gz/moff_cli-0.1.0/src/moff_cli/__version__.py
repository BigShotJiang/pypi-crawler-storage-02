"""Version information for moff-cli."""

__version__ = "0.1.0"
