# Changelog

## 0.4.0 (2025-08-10)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/Fluidize-Inc/fluidize-python-sdk/compare/v0.3.0...v0.4.0)

### Features

* **api:** new version pushing, contact email provided ([276cbcc](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/276cbcc68eeddce97af1f824daf3f0a8f8ed5c44))


### Chores

* update SDK settings ([94df184](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/94df1846d2bc7affe077d42e10addca03a09d42b))

## 0.3.0 (2025-08-10)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/Fluidize-Inc/fluidize-python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([0c74231](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/0c742316a30eff0b3878f5fcffe478ceeaa1843e))
* **api:** removed requirement for firebase tokens ([cdf4c18](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/cdf4c1865532c639c36e56caf40bb63c37b2d11d))


### Chores

* **internal:** update comment in script ([6d0708a](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/6d0708a5c441475d7dce06c50348b72776a48911))
* update @stainless-api/prism-cli to v5.15.0 ([36163e5](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/36163e52f3198687cfe32d6dd0734932cf6747e6))

## 0.2.0 (2025-08-08)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/Fluidize-Inc/fluidize-python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** auth fixed ([a96f40d](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/a96f40d874e0f7c679c4f11462860cadfe537518))
* **api:** manual updates ([ece3ea7](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/ece3ea7c6544c3ea63dd7119b291bc59d8865c5a))

## 0.1.0 (2025-08-08)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/Fluidize-Inc/fluidize-python-sdk/compare/v0.0.2...v0.1.0)

### Features

* **api:** API Endpoint Updated ([aa7652b](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/aa7652b9348b2fd642889a1d31b5d86962018900))

## 0.0.2 (2025-08-08)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Fluidize-Inc/fluidize-python-sdk/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([f5aaa87](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/f5aaa8785665246e6da58be411c0f802c2f0f6bb))
* update SDK settings ([8d6d19a](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/8d6d19ab54fb9d59a796d33f5938ec41c8e811e1))
