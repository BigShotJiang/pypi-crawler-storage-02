"""Actions defined in fabricatio-capabilities."""
