#!/bin/bash

hatch clean
hatch build
hatch publish
