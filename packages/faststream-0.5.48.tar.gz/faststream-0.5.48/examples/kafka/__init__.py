from .testing import app

__all__ = ("app",)
