from .topic import app

__all__ = ("app",)
