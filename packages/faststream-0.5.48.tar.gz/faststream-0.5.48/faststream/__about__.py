"""Simple and fast framework to create message brokers based microservices."""

__version__ = "0.5.48"

SERVICE_NAME = f"faststream-{__version__}"
