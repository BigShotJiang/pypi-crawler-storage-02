from faststream.kafka.prometheus.middleware import KafkaPrometheusMiddleware

__all__ = ("KafkaPrometheusMiddleware",)
