from faststream.redis.prometheus.middleware import RedisPrometheusMiddleware

__all__ = ("RedisPrometheusMiddleware",)
