from faststream.log.logging import logger

__all__ = ("logger",)
