from faststream.rabbit.broker.broker import RabbitBroker

__all__ = ("RabbitBroker",)
