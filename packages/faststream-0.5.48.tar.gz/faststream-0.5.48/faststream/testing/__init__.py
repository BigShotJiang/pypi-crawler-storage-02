from faststream.testing.app import TestApp

__all__ = ("TestApp",)
