# oai-rfsim

This file is a placeholder for packaging.  See `share/oai_rfsim/README.md`
for the detailed documentation of this project.
