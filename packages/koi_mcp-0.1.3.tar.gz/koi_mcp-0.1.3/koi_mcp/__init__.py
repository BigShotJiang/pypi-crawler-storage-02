from .koi_mcp_server import run_server

def main():
    run_server()

__all__ = ["main", "run_server"]