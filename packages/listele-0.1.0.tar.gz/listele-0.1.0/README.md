# listele Fonksiyonu

---

```python
def listele(li:list, kolon:int, ljustmz:int=30):
    ...
```

---

## Kullanım

li kısmına bir iterable verirsiniz (mesela bir dir() ifadesi).
Terminalinizde kaç kolon halinde gözükmesini istediğinizi belirtirsiniz.
Ve eğer isterseniz yazılan değerler arasındaki uzaklığı değiştirebilirsiniz.
