# OrbitVisualization
Code/Astro Project

Animates planetary orbits around a star. Reads in stellar and planetary properties.

![A rectangular badge, half black half purple containing the text made at Code Astro](https://img.shields.io/badge/Made%20at-Code/Astro-blueviolet.svg)
