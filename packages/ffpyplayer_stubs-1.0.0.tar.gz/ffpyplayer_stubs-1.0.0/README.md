Stubs for ffpyplayer.This can make VSCode generate index of ffpyplayer.
This stub isn't made by the original author of ffpyplayer.