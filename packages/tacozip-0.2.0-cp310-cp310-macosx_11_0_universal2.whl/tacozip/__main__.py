
from tacozip._self_check import _self_check

def main():
    _self_check()
    print("tacozip native lib OK")

if __name__ == "__main__":
    main()