# iss_pass_tracker/__init__.py
from .api import get_current_location

__all__ = ["get_current_location"]
