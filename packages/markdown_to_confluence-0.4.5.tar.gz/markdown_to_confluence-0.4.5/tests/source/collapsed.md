<!-- confluence-page-id: 00000000000 -->

## Collapsed sections

<details markdown="1">
<summary>Tips for collapsed sections</summary>

You can add text within a collapsed section.

You can add an image or a code block, too.

```ruby
puts "Hello World"
```
</details>


<details markdown="1">
<summary><b>Tips</b> for <i>collapsed sections with html</i></summary>

You can add text within a collapsed section.

And the summary can have html in it but it should get stripped
</details>
