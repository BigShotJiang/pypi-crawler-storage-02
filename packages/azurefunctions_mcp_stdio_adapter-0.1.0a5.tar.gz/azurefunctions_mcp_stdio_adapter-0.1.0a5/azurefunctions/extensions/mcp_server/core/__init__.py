"""Core package for MCP STDIO adapter functionality."""
