LIST_EVALUATION_RESULTS = "evaluationResultApi/evaluationResults/{evaluationPlanId}"  # GET -> Retrieves a list of evaluation results for a given evaluation plan ID.
GET_EVALUATION_RESULT = "evaluationResultApi/evaluationResult/{evaluationResultId}"  # GET -> Retrieves a specific evaluation result by its ID.
