pub mod bg4;
mod bg4_prediction;

pub use bg4_prediction::BG4Predictor;
