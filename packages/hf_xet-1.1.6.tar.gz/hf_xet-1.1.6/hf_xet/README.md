# Development Notes

* `pip install maturin`
* from this directory: `maturin develop`
