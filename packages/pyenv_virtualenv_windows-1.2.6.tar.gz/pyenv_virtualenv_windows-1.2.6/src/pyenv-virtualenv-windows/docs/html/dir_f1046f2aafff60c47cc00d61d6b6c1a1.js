var dir_f1046f2aafff60c47cc00d61d6b6c1a1 =
[
    [ "activate.bat", "activate_8bat.html", null ],
    [ "deactivate.bat", "deactivate_8bat.html", null ]
];