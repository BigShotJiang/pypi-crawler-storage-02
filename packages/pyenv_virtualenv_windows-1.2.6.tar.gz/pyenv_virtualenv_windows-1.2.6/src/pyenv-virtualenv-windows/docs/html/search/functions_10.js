var searchData=
[
  ['verbose_0',['verbose',['../namespacelog.html#a35d5fd05075c337b02eb71176e8466e2',1,'log']]]
];
