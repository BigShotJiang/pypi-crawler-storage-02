var searchData=
[
  ['activate_2ebat_0',['activate.bat',['../activate_8bat.html',1,'']]]
];
