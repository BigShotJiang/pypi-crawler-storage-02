var searchData=
[
  ['deactivate_2ebat_0',['deactivate.bat',['../deactivate_8bat.html',1,'']]]
];
