var searchData=
[
  ['plugin_20pyenv_20virtualenv_20for_20windows_0',['Plugin &apos;pyenv-virtualenv&apos; for Windows',['../index.html',1,'']]],
  ['pyenv_20virtualenv_20for_20windows_1',['Plugin &apos;pyenv-virtualenv&apos; for Windows',['../index.html',1,'']]]
];
