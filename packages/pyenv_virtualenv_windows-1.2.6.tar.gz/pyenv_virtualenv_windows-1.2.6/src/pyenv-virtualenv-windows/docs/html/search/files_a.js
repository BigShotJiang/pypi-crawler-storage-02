var searchData=
[
  ['readme_2ebat_0',['README.bat',['../_r_e_a_d_m_e_8bat.html',1,'']]],
  ['readme_2emd_1',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]]
];
