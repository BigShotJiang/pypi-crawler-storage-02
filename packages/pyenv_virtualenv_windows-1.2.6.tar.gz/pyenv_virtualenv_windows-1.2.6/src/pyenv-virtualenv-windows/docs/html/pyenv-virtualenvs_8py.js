var pyenv_virtualenvs_8py =
[
    [ "pyenv-virtualenvs.run", "namespacepyenv-virtualenvs.html#a1cd8dc0b27386b141e42484880c453c2", null ],
    [ "pyenv-virtualenvs.parseCliArguments", "namespacepyenv-virtualenvs.html#aa808de89532e984de81da300ca8428cc", null ],
    [ "pyenv-virtualenvs.main", "namespacepyenv-virtualenvs.html#a6c607543f4b38ba3b236f489f6b7feb8", null ]
];