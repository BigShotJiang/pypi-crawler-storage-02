"""Testing for gong-mcp."""


def test_dummy() -> None:
    """Dummy test."""
