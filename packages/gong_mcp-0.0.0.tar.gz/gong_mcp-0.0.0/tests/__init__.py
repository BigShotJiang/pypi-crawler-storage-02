"""Testing for gong-mcp."""
