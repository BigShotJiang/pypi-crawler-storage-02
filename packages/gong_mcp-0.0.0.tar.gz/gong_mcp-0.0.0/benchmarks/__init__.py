"""Benchmarking for gong-mcp."""
