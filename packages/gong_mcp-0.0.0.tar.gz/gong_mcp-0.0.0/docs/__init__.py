"""Documentation for gong-mcp."""
