from .client import FirewallClient
from .client import RIClient as Client  # needed for backward compatability

from .client import RIClient  # isort:skip
