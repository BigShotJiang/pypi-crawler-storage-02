This is the Robust Intelligence REST API SDK. It provides tools and utilities to interact with the Robust Intelligence platform.
