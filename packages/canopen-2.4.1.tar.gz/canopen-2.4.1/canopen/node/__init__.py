from canopen.node.local import LocalNode
from canopen.node.remote import RemoteNode
