from .Tools.ccLogBase import logger

__all__ = ['logger']
