# References

If RegVelo is helpful in your research, please cite {cite:p}`wang2024regvelo`. If you are using zebrafish smart-seq3, 10x multiome and in vivo perturb-seq, please cite {cite:p}`wang2024regvelo, hu2024single`.

```{bibliography}
:cited:
```
