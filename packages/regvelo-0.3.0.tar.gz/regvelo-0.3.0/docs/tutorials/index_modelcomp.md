# Model comparison with multi-view information

```{toctree}
:maxdepth: 1
:titlesonly:

modelcomparison/ModelComp.ipynb
```

