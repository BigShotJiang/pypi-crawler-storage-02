# Plotting

```{eval-rst}
.. module:: regvelo.plotting
.. currentmodule:: regvelo

.. autosummary::
   :toctree: genapi

   plotting.commitment_score
   plotting.cellfate_perturbation
   plotting.simulated_visit_diff
```