# API

Import `regvelo` as:

```
import regvelo as rgv
```

```{toctree}
:maxdepth: 2

datasets
preprocessing
model
tools
metrics
plotting
```