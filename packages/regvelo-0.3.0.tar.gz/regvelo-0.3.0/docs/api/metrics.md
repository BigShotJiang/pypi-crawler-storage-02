# Metrics

```{eval-rst}
.. module:: regvelo.metrics
.. currentmodule:: regvelo

.. autosummary::
   :toctree: genapi

   metrics.abundance_test
   metrics.cellfate_perturbation
```