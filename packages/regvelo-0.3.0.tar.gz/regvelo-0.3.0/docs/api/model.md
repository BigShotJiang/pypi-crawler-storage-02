# Model

```{eval-rst}
.. module:: regvelo
.. currentmodule:: regvelo

.. autosummary::
   :toctree: genapi

   REGVELOVI
   VELOVAE
   ModelComparison
```