# @cute-cats-terminal/py

## 0.2.0

### Minor Changes

- 09d2d80: Added new cats

## 0.1.2

### Patch Changes

- b3a181c: Test patch vbump

## 0.1.1

### Patch Changes

- e0ea587: Adding a new cute cat

## 0.1.0

### Minor Changes

- 448e0dc: Testing the minor bump
