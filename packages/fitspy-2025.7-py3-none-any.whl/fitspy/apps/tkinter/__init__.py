import matplotlib

NCPUS = ['auto', 1, 2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32]
CMAP = matplotlib.colormaps['tab10']
