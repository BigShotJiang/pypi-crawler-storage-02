from .menubar import MenuBar
from .about import About
from .fit_stats import FitStats