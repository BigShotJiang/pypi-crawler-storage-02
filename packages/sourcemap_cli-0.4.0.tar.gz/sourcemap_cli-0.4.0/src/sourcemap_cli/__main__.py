# ABOUTME: Entry point for running repomap as a module
"""Entry point for running repomap as a module."""

from .entrypoint import main

if __name__ == "__main__":
    main()