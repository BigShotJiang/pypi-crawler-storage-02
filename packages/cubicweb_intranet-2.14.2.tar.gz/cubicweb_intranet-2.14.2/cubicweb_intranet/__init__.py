"""cubicweb-intranet"""
