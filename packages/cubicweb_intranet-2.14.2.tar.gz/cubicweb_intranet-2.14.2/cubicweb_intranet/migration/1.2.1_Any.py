drop_cube("vcsfile")
