drop_cube("trustedauth")
