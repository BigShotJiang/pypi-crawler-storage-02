remove_cube("basket")
