To configure this module, you need to:

#. Allow SLA for a Helpdesk's Team
#. Set a resource calendar

Allow SLA
~~~~~~~~~~~~~~~

#. Go to Helpdesk > Configuration > SLA.
#. Edit or create a new SLA.
#. Check Allow SLA option to allow SLA for that team.
#. Select a days or hours for that SLA.
