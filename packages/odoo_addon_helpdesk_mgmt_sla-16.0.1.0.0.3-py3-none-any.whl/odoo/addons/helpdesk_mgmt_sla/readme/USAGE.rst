#. Go to *Helpdesk* or *Helpdesk > Dashboard* to see the tickets dashboard.
#. In the Kanban view, you can see datetime in two colors: Green and Red. If is green, SLA is ok, if is red, SLA is wrong.
