# my_mcp_lib

A generic MCP/LLM client library.

## Installation

```bash
pip install .
```

## Usage

```python
from my_mcp_lib import LLMManager, MCPClient, add

print(add(2, 3))  # 5
```