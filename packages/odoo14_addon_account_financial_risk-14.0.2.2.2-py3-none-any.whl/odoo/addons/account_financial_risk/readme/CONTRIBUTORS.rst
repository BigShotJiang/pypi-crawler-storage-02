* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Pedro M. Baeza
  * Ernesto Tejeda

* Agathe Mollé <agathe.molle@savoirfairelinux.com>

* Ugne Sinkeviciene <ugne@versada.eu>

* `Ooops404 <https://www.ooops404.com>`__:

  * Ilyas <irazor147@gmail.com>
