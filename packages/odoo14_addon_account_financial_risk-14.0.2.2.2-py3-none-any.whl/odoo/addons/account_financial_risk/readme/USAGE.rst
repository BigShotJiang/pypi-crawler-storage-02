To use this module, you need to:

#. Go to *Invoicing/Accounting > Customers > Customers*.
#. Select an existing customer or create a new one.
#. Open the *Financial Risk* tab.
#. Set limits and choose options to compute in credit limit.
#. Go to *Invoicing/Accounting > Customers > Invoices* and create new
   customer invoices.
#. Test the restriction trying to create an invoice for the partner for an
   amount higher of the limit you have set.
#. Return to Customer *Financial Risk* tab and click in amount to view origin.
