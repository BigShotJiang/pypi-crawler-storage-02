class PyPowerwallCloudNoTeslaAuthFile(Exception):
    pass


class PyPowerwallCloudTeslaNotConnected(Exception):
    pass


class PyPowerwallCloudNotImplemented(Exception):
    pass


class PyPowerwallCloudInvalidPayload(Exception):
    pass
