"""Base tests for QuackOSM module."""
