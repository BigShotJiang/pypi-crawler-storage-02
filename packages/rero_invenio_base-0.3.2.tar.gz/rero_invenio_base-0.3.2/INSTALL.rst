Installation
============

RERO Invenio Base is on PyPI so all you need is:

.. code-block:: console

   $ pip install rero-invenio-base
