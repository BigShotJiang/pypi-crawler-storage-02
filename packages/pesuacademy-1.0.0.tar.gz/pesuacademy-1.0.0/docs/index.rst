pesuacademy Documentation
=========================

Welcome to the official documentation for **pesuacademy**, a super-fast and lightweight Python wrapper for PESU Academy.

Contents:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   installation
   usage
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
