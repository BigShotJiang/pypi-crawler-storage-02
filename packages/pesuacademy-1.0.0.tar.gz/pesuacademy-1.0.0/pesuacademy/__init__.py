"""PESU Academy package initialization."""

__version__ = "1.0.0"

from .pesuacademy import PESUAcademy

__all__ = ["PESUAcademy"]
