# ruff: noqa: UP006 UP007 UP045
import typing as ta


DeployPathKind = ta.Literal['dir', 'file']  # ta.TypeAlias


##
