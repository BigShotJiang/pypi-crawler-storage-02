"""
filip-Module. See readme or documentation for more information.
"""

from filip.config import settings
from filip.clients.ngsi_v2 import HttpClient

__version__ = "0.7.2"
