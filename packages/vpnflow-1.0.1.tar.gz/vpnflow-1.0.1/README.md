<p align="center">
    <a href="https://pypi.org/project/vpnflow"><img src="https://codeberg.org/aioboy/vpnflow/media/branch/master/assets/cover.jpg" alt="vpnflow" width="800"></a>
</p>
<p align="center">
    <a href="https://pypi.org/project/vpnflow"><img src="https://img.shields.io/pypi/v/vpnflow.svg?style=flat-square&logo=appveyor" alt="Version"></a>
    <a href="https://pypi.org/project/vpnflow"><img src="https://img.shields.io/pypi/l/vpnflow.svg?style=flat-square&logo=appveyor&color=blueviolet" alt="License"></a>
    <a href="https://pypi.org/project/vpnflow"><img src="https://img.shields.io/pypi/pyversions/vpnflow.svg?style=flat-square&logo=appveyor" alt="Python"></a>
    <a href="https://pypi.org/project/vpnflow"><img src="https://img.shields.io/pypi/status/vpnflow.svg?style=flat-square&logo=appveyor" alt="Status"></a>
    <a href="https://pypi.org/project/vpnflow"><img src="https://img.shields.io/pypi/format/vpnflow.svg?style=flat-square&logo=appveyor&color=yellow" alt="Format"></a>
    <a href="https://pypi.org/project/vpnflow"><img src="https://img.shields.io/pypi/wheel/vpnflow.svg?style=flat-square&logo=appveyor&color=red" alt="Wheel"></a>
    <a href="https://pypi.org/project/vpnflow"><img src="https://codeberg.org/aioboy/vpnflow/raw/branch/master/assets/coverage.svg" alt="Coverage"></a>
    <a href="https://pepy.tech/project/vpnflow"><img src="https://static.pepy.tech/personalized-badge/vpnflow?period=total&units=international_system&left_color=grey&right_color=blue&left_text=Downloads" alt="Downloads"></a>
    <a href="https://hub.docker.com/r/aioboy/vpnflow"><img src="https://img.shields.io/docker/pulls/aioboy%2Fvpnflow?style=flat-square&logo=appveyor" alt="DockerHub"></a>
</p>
