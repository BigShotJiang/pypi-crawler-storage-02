# -*- coding: utf-8 -*-
__author__ = "Michael R. Kisel"
__copyright__ = "Michael R. Kisel"
__license__ = "AGPL"
__version__ = "1.0.1"
__maintainer__ = "Michael R. Kisel"
__email__ = "aioboy@yandex.com"
__status__ = "Stable"
