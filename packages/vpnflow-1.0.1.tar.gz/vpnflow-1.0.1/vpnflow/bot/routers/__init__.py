# -*- coding: utf-8 -*-
from vpnflow.bot.routers import admin, base, errors

ALL = (base.router, errors.router, admin.router)
