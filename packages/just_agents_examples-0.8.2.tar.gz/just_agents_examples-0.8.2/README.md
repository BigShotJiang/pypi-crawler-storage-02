Just-Agents Examples
====================

Examples of using Just Agents for various tasks:

* basic - basic examples of using Just Agents
* coding - generating and executing code and commands (note: require docker to be installed)
* tools - tools used by examples
* multiagent - multiagent examples