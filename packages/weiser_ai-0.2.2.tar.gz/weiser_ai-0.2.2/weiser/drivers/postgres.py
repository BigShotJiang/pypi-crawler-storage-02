from weiser.drivers.base import BaseDriver


class PostgresDriver(BaseDriver):
    pass


class CubeDriver(PostgresDriver):
    pass
