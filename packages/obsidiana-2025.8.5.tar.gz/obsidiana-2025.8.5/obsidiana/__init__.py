"""
Tools for working with Obsidian vaults.
"""
