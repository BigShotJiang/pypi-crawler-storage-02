"""Top-level package for PGSync."""

__author__ = "Tolu Aina"
__email__ = "tolu@pgsync.com"
__version__ = "4.2.0"
