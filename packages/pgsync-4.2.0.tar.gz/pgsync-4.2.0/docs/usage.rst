=====
Usage
=====

To use pgsync in a project::

    from pgsync import sync
    sync.main()
