from pyeutils.core import ESearchResult
from pyeutils.eutils import NcbiEutils
