from pyeutils.core.esearch_result import ESearchResult
