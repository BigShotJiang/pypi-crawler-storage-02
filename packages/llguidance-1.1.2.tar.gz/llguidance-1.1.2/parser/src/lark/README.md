# Lark-like syntax

This module implements a Lark-like input syntax for LLGuidance grammars.
The docs were [moved to docs/ folder](../../../docs/syntax.md).
