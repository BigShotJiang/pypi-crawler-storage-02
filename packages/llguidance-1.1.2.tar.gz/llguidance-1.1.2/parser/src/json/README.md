# JSON schema -> llguidance converter

This sub-module converts JSON schema to llguidance grammar.
See [main docs](../../../docs/json_schema.md) for more info.
