# Sample for llguidance

This is a sample parser for the [llguidance](../parser/README.md) crate.
