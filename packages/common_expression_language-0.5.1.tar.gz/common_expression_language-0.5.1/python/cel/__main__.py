#!/usr/bin/env python3
"""
Entry point for python -m cel invocation.
"""

from .cli import cli_entry

if __name__ == "__main__":
    cli_entry()
