NAME = "aws-toolbox"
VERSION = "0.0.6"
