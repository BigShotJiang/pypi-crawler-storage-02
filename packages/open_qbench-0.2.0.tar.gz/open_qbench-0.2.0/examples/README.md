To run the examples, either install the package with:
```
pip install -e .
```
or modify `PYTHONPATH` manually.
