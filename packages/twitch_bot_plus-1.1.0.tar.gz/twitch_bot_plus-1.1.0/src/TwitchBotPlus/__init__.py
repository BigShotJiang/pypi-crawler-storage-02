from .core import Bot

__all__ = ["Bot"]
__version__ = "1.0.0"