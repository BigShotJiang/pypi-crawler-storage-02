# twitch-bot-plus
A python library for making Twitch Bots

## Env Setup
```
BOTNAME=Bot_Name
OAUTH_ID=oauth:
CLIENT_ID=
CLIENT_SECRET=
TWITCH_REFRESH_TOKEN=
CHANNEL=#Target_Channel
```