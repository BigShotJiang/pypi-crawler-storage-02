// eslint-disable-next-line @typescript-eslint/no-empty-function
window.PointerEvent = function (type, eventInitDict) {};

// eslint-disable-next-line @typescript-eslint/no-empty-function
window.DragEvent = function (type, eventInitDict) {};
