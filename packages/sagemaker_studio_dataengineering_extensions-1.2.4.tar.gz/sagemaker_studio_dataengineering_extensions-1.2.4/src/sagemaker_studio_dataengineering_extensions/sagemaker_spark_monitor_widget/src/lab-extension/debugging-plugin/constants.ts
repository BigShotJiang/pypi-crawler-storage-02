
export const LINK_TYPE_SPARK_UI: string = "spark_ui";
export const LINK_TYPE_DRIVER_LOG: string = "driver_log";