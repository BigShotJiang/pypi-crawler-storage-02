import dummy_application_data  from './dummy_application_data.json'
import dummy_executor_data from './dummy_executor_data.json'
import dummy_job_data from './dummy_job_data.json'

const dummy_data = {
    'dummy_application_data': dummy_application_data,
    'dummy_executor_data': dummy_executor_data,
    'dummy_job_data': dummy_job_data
}

export default dummy_data;