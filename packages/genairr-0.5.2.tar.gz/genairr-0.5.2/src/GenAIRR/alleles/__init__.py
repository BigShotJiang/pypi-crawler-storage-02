from .allele import AlleleTypes
from .allele import VAllele
from .allele import DAllele
from .allele import JAllele
from .allele import CAllele
