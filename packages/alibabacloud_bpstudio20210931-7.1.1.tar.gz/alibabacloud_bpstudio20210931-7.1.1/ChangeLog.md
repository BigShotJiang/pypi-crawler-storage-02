2025-08-08 Version: 7.1.0
- Support API GetLinkageAttributesTemplate.


2025-07-23 Version: 7.0.4
- Update API GetTemplate: add response parameters Body.Data.DocumentUrl.
- Update API ListTemplate: add response parameters Body.Data.$.Description.
- Update API ListTemplate: add response parameters Body.Data.$.DocumentUrl.
- Update API ListTemplate: add response parameters Body.Data.$.Tag.


2025-07-09 Version: 7.0.3
- Update API ListTemplate: add request parameters Tag.


2025-07-09 Version: 7.0.3
- Update API ListTemplate: add request parameters Tag.


2025-06-25 Version: 7.0.2
- Update API CreateApplication: add request parameters ProcessVariables.


2025-06-12 Version: 7.0.1
- Update API ListApplication: add request parameters ShowHide.


2025-02-28 Version: 7.0.0
- Update API GetApplication: update response param.
- Update API ValuateTemplate: update param Variables.


2024-11-29 Version: 6.0.4
- Generated python 2021-09-31 for BPStudio.

2024-11-29 Version: 6.0.3
- Generated python 2021-09-31 for BPStudio.

2024-11-07 Version: 6.0.2
- Update API GetTemplate: update response param.


2024-10-10 Version: 6.0.1
- Update API GetResource4ModifyRecord: update response param.


2024-09-27 Version: 6.0.0
- Update API ExecuteOperationSync: update response param.
- Update API GetExecuteOperationResult: update response param.


2024-09-24 Version: 5.2.1
- Update API GetResult4QueryInstancePrice4Modify: update response param.
- Update API QueryInstanceSpec4Modify: update response param.


2024-09-24 Version: 5.2.0
- Support API GetResource4ModifyRecord.
- Support API GetResult4QueryInstancePrice4Modify.
- Support API ModifyApplicationSpec.
- Support API QueryInstancePrice4Modify.
- Support API QueryInstanceSpec4Modify.


2024-09-03 Version: 5.1.0
- Support API GetApplicationVariables.


2024-08-30 Version: 5.0.1
- Update API GetApplication: update response param.


2024-08-29 Version: 5.0.0
- Support API GetApplicationVariables4Fail.
- Support API ReConfigApplication.
- Update API CreateApplication: update param Variables.


2024-07-29 Version: 4.2.1
- Generated python 2021-09-31 for BPStudio.

2024-04-07 Version: 4.2.0
- Support API ExecuteOperationSync.
- Update API CreateApplication: update param ClientToken.
- Update API DeployApplication: add param ClientToken.
- Update API ExecuteOperationASync: add param ClientToken.
- Update API ReleaseApplication: add param ClientToken.
- Update API ValidateApplication: add param ClientToken.
- Update API ValuateApplication: add param ClientToken.


2024-02-27 Version: 4.1.0
- Support API ExecuteOperationSync.
- Update API DeployApplication: add param ClientToken.
- Update API ExecuteOperationASync: add param ClientToken.
- Update API ReleaseApplication: add param ClientToken.
- Update API ValidateApplication: add param ClientToken.
- Update API ValuateApplication: add param ClientToken.


2024-01-30 Version: 4.0.0
- Support API AppFailBack.
- Support API AppFailOver.
- Support API GetFoTaskStatus.
- Support API GetPotentialFailZones.
- Support API InitAppFailOver.
- Update API ListApplicationadd ResourceId param.
add TemplateId param.
- Update API ListFoCreatedAppsupdate response param.


2024-01-10 Version: 3.1.0
- Generated python 2021-09-31 for BPStudio.

2023-07-06 Version: 3.0.0
- Fix bug asyncExecute Error.

2023-06-20 Version: 2.0.0
- Fix bug asyncExecute Error.

2023-05-22 Version: 1.0.11
- Fix bug asyncExecute Error.

2023-03-31 Version: 1.0.10
- Add Remark.

2023-03-14 Version: 1.0.9
- Add Remark.

2022-10-21 Version: 1.0.8
- Add Remark.

2022-06-29 Version: 1.0.7
- Add Remark.

2022-05-29 Version: 1.0.5
- Support Template Variable.
- Support Application Configuration.

2022-05-24 Version: 1.0.2
- Support test .

2021-11-08 Version: 1.0.1
- Support test .

2021-09-29 Version: 1.0.0
- Support test .

