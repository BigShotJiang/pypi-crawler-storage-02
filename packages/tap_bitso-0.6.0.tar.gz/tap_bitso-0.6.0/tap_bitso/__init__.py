"""A Singer tap for the Bitso API."""

from __future__ import annotations
