"""Test suite for tap-bitso."""

from __future__ import annotations
