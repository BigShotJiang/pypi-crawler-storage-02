# The inclusion of the tests module is not meant to offer best practices for
# testing in general.
