# JST-DJANGO
## [Docs](https://docs.jscorp.uz)
## Yordam uchun: [Telegram Guruh](https://t.me/Jscorptech_support/6/)