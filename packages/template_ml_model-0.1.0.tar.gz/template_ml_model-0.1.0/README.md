
## Local Development
For local development, follow these steps:

1. Build the project:
```
poetry build
```
2. Install the project:
```
poetry install
```
3. Install twine for publishing:
```
python3 -m pip install --upgrade twine
```
