default_app_config = "aiwaf.apps.AiwafConfig"
