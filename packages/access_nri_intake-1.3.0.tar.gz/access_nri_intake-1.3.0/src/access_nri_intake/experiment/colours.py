from colorama import Fore, Style

f_warn = f"{Fore.YELLOW}{Style.NORMAL}"
f_info = f"{Fore.BLUE}{Style.NORMAL}"
f_success = f"{Fore.GREEN}{Style.NORMAL}"
f_reset = f"{Style.RESET_ALL}"
f_path = f"{Fore.CYAN}{Style.BRIGHT}"
f_suggestion = f"{Fore.WHITE}{Style.BRIGHT}"
