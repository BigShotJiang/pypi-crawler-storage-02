## Version of the package   
__version__ = "2.1.0"