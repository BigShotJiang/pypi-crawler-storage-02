# Changelog

## 0.1.0 (2025-08-08)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/Fluidize-Inc/fluidize-python-sdk/compare/v0.0.2...v0.1.0)

### Features

* **api:** API Endpoint Updated ([aa7652b](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/aa7652b9348b2fd642889a1d31b5d86962018900))

## 0.0.2 (2025-08-08)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Fluidize-Inc/fluidize-python-sdk/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([f5aaa87](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/f5aaa8785665246e6da58be411c0f802c2f0f6bb))
* update SDK settings ([8d6d19a](https://github.com/Fluidize-Inc/fluidize-python-sdk/commit/8d6d19ab54fb9d59a796d33f5938ec41c8e811e1))
