
class HandlerError(Exception):
    pass
