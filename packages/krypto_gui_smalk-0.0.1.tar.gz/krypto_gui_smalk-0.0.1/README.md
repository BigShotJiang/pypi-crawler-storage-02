# krypto_gui_smalk

gui for smalk krypto testing.

For detail about smalk and alerk look [this](https://github.com/The220th/alerk).
