SET SEARCH_PATH to pgstac, public;
INSERT INTO migrations (version) VALUES ('0.2.9');
