from website_price_notifier import utils

def main() -> None:
    utils.main()
