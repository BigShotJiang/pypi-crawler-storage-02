from website_price_notifier import utils

if __name__ == "__main__":
    print("Running website price notifier...")
    utils.main()