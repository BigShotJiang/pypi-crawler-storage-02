# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

"""HF-SEF dataset."""

from .hf_sef import data_path
