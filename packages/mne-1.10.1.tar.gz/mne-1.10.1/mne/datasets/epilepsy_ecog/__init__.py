# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

"""Clinical epilepsy datasets."""

from ._data import data_path, get_version
