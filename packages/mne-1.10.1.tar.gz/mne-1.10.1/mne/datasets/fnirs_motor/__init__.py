# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

"""fNIRS motor dataset."""

from .fnirs_motor import data_path, get_version
