# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

"""SPM face dataset."""

from .spm_data import data_path, has_spm_data, get_version, requires_spm_data
