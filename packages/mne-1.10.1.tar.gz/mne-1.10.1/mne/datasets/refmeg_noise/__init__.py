# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

"""MEG reference-noise data set."""

from .refmeg_noise import data_path, get_version
