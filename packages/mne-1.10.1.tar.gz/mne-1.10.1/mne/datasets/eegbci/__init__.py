# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

"""EEG Motor Movement/Imagery Dataset."""

from .eegbci import data_path, load_data, standardize
