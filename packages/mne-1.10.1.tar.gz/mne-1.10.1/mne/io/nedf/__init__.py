"""NEDF file import module."""

# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

from .nedf import read_raw_nedf, _parse_nedf_header
