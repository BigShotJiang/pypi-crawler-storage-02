# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

"""FIF raw data reader."""

from .raw import Raw
from .raw import read_raw_fif

RawFIF = Raw
