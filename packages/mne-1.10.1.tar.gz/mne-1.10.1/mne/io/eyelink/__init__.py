"""Module for loading Eye-Tracker data."""

# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

from .eyelink import read_raw_eyelink
