"""NSx module for reading Blackrock Microsystem files."""

# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

from .nsx import read_raw_nsx
