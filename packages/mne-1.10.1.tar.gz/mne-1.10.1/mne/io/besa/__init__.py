"""Support for various BESA file formats."""

# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

from .besa import read_evoked_besa
