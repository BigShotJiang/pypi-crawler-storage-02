"""fNIRS module for conversion to FIF."""

# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

from .nirx import read_raw_nirx
