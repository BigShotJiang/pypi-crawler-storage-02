---
name: Feature Request
about: Request a feature or suggest an idea for this project
title: ''
labels: feature
assignees: ''

---

## The motivation

<!--- Useful to breakdown to "As a [persona], I [want to do], so that [reason] -->

## The proposed solution

<!---
If you'd like, please provide a description of the solution you would like to see

If you don't have any ideas for the solution, simply leave this blank
-->

## Alternatives

<!---
If you've considered any alternatives, please describe them here

If you don't have any alternatives, simply leave this blank
-->

## Additional context

<!--- Add any additional context can go here -->
