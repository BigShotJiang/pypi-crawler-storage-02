# How-to guides

This part of the project documentation
focuses on a **problem-oriented** approach.
We'll go over how to solve common tasks.

## How can I do a basic calculation?

<!---
You will probably want to remove this bit.

It is included to demonstrate how to include sub-sections
and cross-reference them.
-->

If you want to do a basic calculation,
see ["How to do a basic calculation"][how-to-do-a-basic-calculation].
