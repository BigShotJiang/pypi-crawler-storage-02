# How to do a basic calculation

An example of how to do a basic calculation using Example fgen - basic.

```python
>>> from example_fgen_basic.operations import add_two

>>> add_two(3.2, 4.3)
7.5
```
