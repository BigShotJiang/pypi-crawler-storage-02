This module allows you to import the MT940 files from the Romanian Alpha
bank in Odoo as bank statements.
