# Installation

```{include} ../README.md
:start-after: <!--- install-begin -->
:end-before: <!--- install-end -->
```
