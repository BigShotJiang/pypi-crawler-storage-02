# -*- coding: utf-8 -*-
"""
CapabilityDecorator 包初始化文件
"""

# 避免循环导入，使用相对导入
from .CapabilityDecorator import capability

__all__ = ['capability']