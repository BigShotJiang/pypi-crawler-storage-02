# Overview

This is a single use library to translate the Prototype Query objects found in the Layout json to DAX that can be run against a SSAS instance.