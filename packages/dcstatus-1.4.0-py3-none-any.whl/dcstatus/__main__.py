"""Support for package execution."""

from . import main

main()
