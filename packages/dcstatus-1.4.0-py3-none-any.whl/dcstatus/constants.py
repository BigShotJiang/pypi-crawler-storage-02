"""Constant values"""

UNKNOWN = "unknown"
