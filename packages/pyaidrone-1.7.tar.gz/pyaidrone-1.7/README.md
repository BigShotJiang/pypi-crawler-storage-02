## install pyaidrone

> python setup.py install
> or
> python install pyaidrone

### install Packages

> pip install pyserial
> pip install pynput
