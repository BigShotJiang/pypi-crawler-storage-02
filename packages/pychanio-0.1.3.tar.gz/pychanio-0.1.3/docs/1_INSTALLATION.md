# Chapter 1: Installation

To get started run the following commands  

```bash
pip install pychanio
```

To install a specific release  

```bash
pip install pychanio==0.1.0 # replace 0.1.0 with the desired version
```