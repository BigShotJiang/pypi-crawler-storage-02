"""relkit: Opinionated project manager for uv workspaces."""

__version__ = "1.0.3"
