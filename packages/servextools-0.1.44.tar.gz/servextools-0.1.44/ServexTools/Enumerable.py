class TipoMensaje:
    ALT = "ALT"
    MSJ = "MSJ"

class Metodo:
    GET = "GET"
    POST = "POST"