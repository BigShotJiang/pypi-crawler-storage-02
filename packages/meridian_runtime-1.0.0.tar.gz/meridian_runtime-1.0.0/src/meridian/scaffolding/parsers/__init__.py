"""Parsers for scaffolding CLI arguments."""
