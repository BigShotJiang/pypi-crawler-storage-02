omegalpes.general package
=========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   omegalpes.general.optimisation
   omegalpes.general.utils

Submodules
----------

omegalpes.general.time module
-----------------------------

.. automodule:: omegalpes.general.time
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: omegalpes.general
   :members:
   :show-inheritance:
   :undoc-members:
