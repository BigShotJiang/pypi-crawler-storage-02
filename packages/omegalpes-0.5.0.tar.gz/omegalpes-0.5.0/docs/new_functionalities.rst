What's new in OMEGAlpes
=================================

The new version of OMEGAlpes v0.5.0 is available!
The release is from 20th of January 2023.

.. toctree::
   :maxdepth: 2

   new_functionalities/v0.5.0


Information about the previous versions
---------------------------------------

.. toctree::
   :maxdepth: 1

   new_functionalities/v0.4.4


.. toctree::
   :maxdepth: 1

   new_functionalities/v0.4.3


.. toctree::
   :maxdepth: 1

   new_functionalities/v0.4.2

.. toctree::
   :maxdepth: 1

   new_functionalities/v0.4.1

.. toctree::
   :maxdepth: 1

   new_functionalities/v0.4.0

.. toctree::
   :maxdepth: 1

   new_functionalities/v0.3.1

.. toctree::
   :maxdepth: 1

   new_functionalities/v0.3.0
