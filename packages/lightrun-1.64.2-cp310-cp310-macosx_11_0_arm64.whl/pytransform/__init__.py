# Pyarmor 8.4.7 (basic), 004363, 2025-08-07T08:15:22.699418
from .pyarmor_runtime import __pyarmor__
