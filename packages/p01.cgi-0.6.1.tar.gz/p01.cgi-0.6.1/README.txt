This package provides a replacement for the cgi.FieldStorage parser which
prevents to load file upoad data into memory.