datadog\_api\_client package
============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   datadog_api_client.v1
   datadog_api_client.v2

Submodules
----------

datadog\_api\_client.api\_client module
---------------------------------------

.. automodule:: datadog_api_client.api_client
   :members:
   :show-inheritance:

datadog\_api\_client.configuration module
-----------------------------------------

.. automodule:: datadog_api_client.configuration
   :members:
   :show-inheritance:

datadog\_api\_client.exceptions module
--------------------------------------

.. automodule:: datadog_api_client.exceptions
   :members:
   :show-inheritance:

datadog\_api\_client.model\_utils module
----------------------------------------

.. automodule:: datadog_api_client.model_utils
   :members:
   :show-inheritance:

datadog\_api\_client.rest module
--------------------------------

.. automodule:: datadog_api_client.rest
   :members:
   :show-inheritance:

Module contents
---------------

.. automodule:: datadog_api_client
   :members:
   :show-inheritance:
