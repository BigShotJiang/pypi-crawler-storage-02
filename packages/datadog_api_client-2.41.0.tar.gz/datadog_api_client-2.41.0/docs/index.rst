.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   datadog_api_client


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
