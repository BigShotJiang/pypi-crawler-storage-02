"""
Unit tests for the Mosaia Python SDK.

This package contains unit tests that test individual components
in isolation, without external dependencies.
"""
