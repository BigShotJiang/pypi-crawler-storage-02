"""
Test suite for the Mosaia Python SDK.

This package contains all tests for the Mosaia Python SDK, including
unit tests, integration tests, and functional tests.
"""

__version__ = "1.0.0"
