"""
Integration tests for the Mosaia Python SDK.

This package contains integration tests that test how components
work together and with external systems.
"""
