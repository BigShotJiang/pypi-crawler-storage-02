"""
Tests for the auth module of the Mosaia Python SDK.

This package contains tests for authentication functionality.
"""
