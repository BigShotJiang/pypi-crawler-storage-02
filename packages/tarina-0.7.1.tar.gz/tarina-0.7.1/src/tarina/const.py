import inspect

Empty = inspect.Signature.empty
