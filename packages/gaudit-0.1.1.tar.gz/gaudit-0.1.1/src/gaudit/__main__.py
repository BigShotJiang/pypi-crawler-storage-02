"""
Allow running the gaudit CLI with `python -m gaudit`
"""

from gaudit.cli import gcli

if __name__ == "__main__":
    gcli()
