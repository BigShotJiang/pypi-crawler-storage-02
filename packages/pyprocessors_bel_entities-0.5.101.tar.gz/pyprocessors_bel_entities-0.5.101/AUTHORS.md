# Authors

Contributors to pyprocessors_bel_entities include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
