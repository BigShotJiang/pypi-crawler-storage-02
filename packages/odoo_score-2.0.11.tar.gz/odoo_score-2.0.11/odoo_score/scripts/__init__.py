# -*- coding: utf-8 -*-
from . import main
from . import rename_odoo_module
from . import map_module_dependecies
