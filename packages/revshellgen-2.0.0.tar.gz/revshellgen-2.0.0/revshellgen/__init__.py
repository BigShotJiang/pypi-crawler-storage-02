"""
RevShellGen - Reverse Shell Generator
A powerful tool for generating reverse shell commands with encoding options.
"""

__version__ = "2.0.0"
__author__ = "t0thkr1s"
__email__ = "t0thkr1s@icloud.com"
__url__ = "https://github.com/t0thkr1s/revshellgen"

from .main import main

__all__ = ['main']
