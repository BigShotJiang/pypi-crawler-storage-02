---
title: "egse.device"
---

!!! info "cgse-common"
    This code is part of the `cgse-common` package.


::: egse.device
