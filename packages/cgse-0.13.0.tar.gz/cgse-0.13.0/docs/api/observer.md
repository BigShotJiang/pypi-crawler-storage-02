---
title: "egse.observer"
---

!!! info "cgse-common"
    This code is part of the `cgse-common` package.


::: egse.observer
