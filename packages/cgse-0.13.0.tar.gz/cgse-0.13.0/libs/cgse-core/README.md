# The core services for the CGSE platform
