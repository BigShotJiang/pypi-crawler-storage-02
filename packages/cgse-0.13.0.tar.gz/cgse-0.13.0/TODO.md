# TODO

* [x] we will use one global version for the monorepo -> create a bump script that updates all version numbers from the master pyproject.toml
