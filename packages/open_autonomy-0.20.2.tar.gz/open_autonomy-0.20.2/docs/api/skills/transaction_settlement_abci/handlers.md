<a id="packages.valory.skills.transaction_settlement_abci.handlers"></a>

# packages.valory.skills.transaction`_`settlement`_`abci.handlers

This module contains the handler for the 'transaction_settlement_abci' skill.

