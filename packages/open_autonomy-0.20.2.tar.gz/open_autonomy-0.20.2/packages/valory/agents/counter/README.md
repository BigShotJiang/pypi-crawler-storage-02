# ABCI Counter AEA

This agent uses the `abci` connection and the `counter` skill
to replicate the state with other AEAs through the Tendermint consensus engine. 
