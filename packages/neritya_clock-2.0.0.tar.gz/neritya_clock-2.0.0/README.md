# Neritya Clock v2

A fullscreen, terminal-style digital clock with interactive commands and color change support.

## Installation
```bash
pip install neritya-clock
