__version__ = "2.0.0"

from .main import main
