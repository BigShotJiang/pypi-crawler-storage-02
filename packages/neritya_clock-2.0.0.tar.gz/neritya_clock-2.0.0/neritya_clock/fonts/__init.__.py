# fonts/__init__.py
# This file just marks the fonts folder as a Python package so setuptools can include it.
