// library version, increment to match package version when C interface changes
#define DIGITAL_RF_VERSION "2.6.0"
