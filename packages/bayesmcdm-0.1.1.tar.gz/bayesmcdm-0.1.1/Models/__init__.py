from .BWM.StandardBWM import StandardBWM

# /Users/majidmohammadi/surfdrive/Research/MCDM/BayesianMCDM/Models/__init__.py

# Redirect BayesMCDM.BWM.StandardBWM to Models.BWM.StandardBWM.StandardBWM


# Optionally, provide a namespace for BWM if needed
class BWM:
    StandardBWM = StandardBWM