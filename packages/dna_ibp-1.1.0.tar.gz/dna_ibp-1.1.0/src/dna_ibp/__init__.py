# dna_ibp/__init__.py
from .cli import DnaCli

__version__ = "1.0.0"