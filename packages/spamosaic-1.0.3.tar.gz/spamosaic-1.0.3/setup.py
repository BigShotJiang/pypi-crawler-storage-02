import setuptools

if __name__ == "__main__":
    setuptools.setup(
        name="spamosaic",
        include_package_data=True
    )
