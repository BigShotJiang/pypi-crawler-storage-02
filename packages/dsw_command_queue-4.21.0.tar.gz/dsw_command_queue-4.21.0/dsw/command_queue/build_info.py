# Generated file
# - do not overwrite
# - do not include in git
from collections import namedtuple

BuildInfo = namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v4.21.0~12713f1',
    built_at='2025-08-05 09:20:18Z',
    sha='12713f1988c2a33d5c40dd2cb899cdac7be35668',
    branch='HEAD',
    tag='v4.21.0',
)
