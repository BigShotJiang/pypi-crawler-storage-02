"""benchmarking the speed or success rate of maze generation.

you can view generated benchmark results here: https://understanding-search.github.io/maze-dataset/benchmarks/
"""

__all__ = [
	"config_sweep",
	"speed",
]
