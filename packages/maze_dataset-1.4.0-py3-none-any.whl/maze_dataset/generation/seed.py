"global default seed"

GLOBAL_SEED: int = 42
