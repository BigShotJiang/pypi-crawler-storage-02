"""A package that provides useful utilities for the sake of digout."""
