"""A special folder that contains Python files to be run through Moore."""
