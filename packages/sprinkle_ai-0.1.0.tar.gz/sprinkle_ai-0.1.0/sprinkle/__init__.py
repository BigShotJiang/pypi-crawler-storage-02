"""Sprinkle - AI-powered bash command generator."""

__version__ = "0.1.0"