## v0.1.1rc26 (August 07, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc25...v0.1.1rc26

### Features

- add cursor and bugbot rules (#636) (by @Amit Prabhu in [cbbecd9](https://github.com/atlanhq/application-sdk/commit/cbbecd9))

### Bug Fixes

- handle str and dict types in preflight checks (#638) (by @Nishchith Shetty in [57ee9a0](https://github.com/atlanhq/application-sdk/commit/57ee9a0))
