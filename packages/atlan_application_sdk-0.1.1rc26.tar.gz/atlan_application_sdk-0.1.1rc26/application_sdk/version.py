"""
Version information for the application_sdk package.
"""

__version__ = "0.1.1rc26"
