
from setuptools import setup

setup(package_data={'jmespath-stubs': ['__init__.pyi', 'ast.pyi', 'compat.pyi', 'exceptions.pyi', 'functions.pyi', 'lexer.pyi', 'parser.pyi', 'visitor.pyi', 'METADATA.toml', 'py.typed']})
