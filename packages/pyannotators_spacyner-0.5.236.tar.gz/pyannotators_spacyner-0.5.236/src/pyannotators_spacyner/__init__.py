"""Annotator based on Spacy NER"""
__version__ = "0.5.236"
