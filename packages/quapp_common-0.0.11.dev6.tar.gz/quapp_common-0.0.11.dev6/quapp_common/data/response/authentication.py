"""
    QApp Platform Project authentication.py Copyright © CITYNOW Co. Ltd. All rights reserved.
"""


class Authentication:
    def __init__(self, user_token: str, user_identity: str):
        self.user_token = user_token
        self.user_identity = user_identity
