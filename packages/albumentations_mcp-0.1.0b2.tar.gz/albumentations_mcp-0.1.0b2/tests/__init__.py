# Test suite for Albumentations MCP Server
