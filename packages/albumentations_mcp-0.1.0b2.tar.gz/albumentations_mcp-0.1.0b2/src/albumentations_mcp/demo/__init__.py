"""
Demo module for Albumentations MCP

Provides CLI interface for testing and demonstrating functionality.
"""

from .cli import main

__all__ = ["main"]
