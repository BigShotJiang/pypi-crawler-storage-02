from setuptools import setup

if __name__ == "__main__":
    setup(
        package_data={
            'peaq_msf': ['abi/*.json'],
        },
    )