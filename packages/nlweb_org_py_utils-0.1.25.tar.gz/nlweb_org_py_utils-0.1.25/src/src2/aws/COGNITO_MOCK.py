from __future__ import annotations

from LOG import LOG


class COGNITO_MOCK:
    
    @classmethod
    def CreateUser(cls, username, password, clientAlias='COGNITO'): 
        pass