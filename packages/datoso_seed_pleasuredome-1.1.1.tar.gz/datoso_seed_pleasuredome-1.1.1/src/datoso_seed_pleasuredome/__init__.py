"""Initialize seed variables."""
__all__ = ['__author__', '__description__', '__version__']
__version__ = '1.1.1'
__author__ = 'Lacides Miranda'
__description__ = 'PleasureDome is a group that gathers dats for MAME, HBMAME and fruit machines.'
__prefix__ = 'pleasuredome'
