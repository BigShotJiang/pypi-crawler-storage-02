This module adds [bot.or.th](https://bot.or.th/) currency exchange rates
provider.
