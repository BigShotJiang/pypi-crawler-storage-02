To update historical currency rates:

1. Go to **Invoicing > Configuration > Currency Rates Providers**
2. Select specific providers
3. Launch **Actions > Update Rates Wizard**
4. Configure date interval and click **Update**
