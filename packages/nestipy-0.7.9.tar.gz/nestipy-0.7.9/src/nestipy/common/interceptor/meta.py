class InterceptorKey:
    Meta = "__interceptors__"
