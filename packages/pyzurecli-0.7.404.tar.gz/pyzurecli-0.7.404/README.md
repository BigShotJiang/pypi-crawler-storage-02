## Usage
```python
from pyzurecli import AzureCLI

if __name__ == "__main__":
    az = AzureCLI()
    user = az.user
    sp = az.service_principal
    ap = az.app_registration
    graph = az.graph_api

```

Licensed under MIT.