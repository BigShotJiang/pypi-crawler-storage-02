"""
.. include:: ./documentation.md
"""
from .load_pamguard_binary_file import load_pamguard_binary_file