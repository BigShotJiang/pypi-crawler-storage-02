"""Entry point for running seestar_mcp as a module."""

from seestar_mcp.server import main

if __name__ == "__main__":
    main()
