from typing import Any
from typing import Callable
from typing import Dict

JWKDict = Dict[str, Any]

HashlibHash = Callable[..., Any]
