"""Helper CLI utilities for CTM."""
