"""Use the model's dialect when calculating the hash for the column types."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
