"""Include the unrendered query in the metadata hash."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
