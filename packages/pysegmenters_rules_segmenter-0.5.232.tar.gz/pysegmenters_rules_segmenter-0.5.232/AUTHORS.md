# Authors

Contributors to pysegmenters_rules_segmenter include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
