from setuptools import setup

# This file is kept for backward compatibility with older tools
# that don't support pyproject.toml.
# For modern Python packaging, see pyproject.toml

setup()
