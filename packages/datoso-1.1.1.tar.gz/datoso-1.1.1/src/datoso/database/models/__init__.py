"""Shortcuts for models."""
__all__ = ['Dat', 'Seed', 'System']

from .dat import Dat, Seed, System
