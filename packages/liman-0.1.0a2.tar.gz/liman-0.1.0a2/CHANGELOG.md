# Changelog

## 0.1.0-a2 (2025-08-13)


### ✨ Features

* add protobuf ([f861ba3](https://github.com/gurobokum/liman/commit/f861ba3133d70ddc2ce083427c5b955a4f736d8f))
* **liman:** implement executor ([39d2b4e](https://github.com/gurobokum/liman/commit/39d2b4ec7b393e73e0b9dc1bc1bd981125df6928))


### 🛠 Code Refactoring

* drop protobuf ([baf82d3](https://github.com/gurobokum/liman/commit/baf82d36c7fe936895eef3e2ab2aa3be541796bd))
* **liman:** rework versioning ([b65a0ad](https://github.com/gurobokum/liman/commit/b65a0ad055fcf651e3bef501aaae3c4b8553ad54))
