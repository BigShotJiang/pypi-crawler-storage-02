"""
Analytics utilities
"""


def format_name(name, prefix, date):
    return prefix + name.format(date=date)
