#!/usr/bin/env python
from setuptools import setup

import setuptools_scm

setup()
