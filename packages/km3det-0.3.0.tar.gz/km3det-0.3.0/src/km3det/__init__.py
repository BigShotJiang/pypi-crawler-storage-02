try:
    from importlib.metadata import version as get_version

    version = get_version(__name__)
except ImportError:
    from pkg_resources import get_distribution

    version = get_distribution(__name__).version

from .detector import Detector
from .pmt_parameters import PMT_parameters
from .dynamic_position import DynamicPosition
from .auxiliary import Tripods, Transmitters, Hydrophones
