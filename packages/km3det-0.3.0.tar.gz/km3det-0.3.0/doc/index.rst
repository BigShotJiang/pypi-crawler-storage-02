.. include:: ../README.rst


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   examples
   contribute
   changelog

   autoapi/index

   Code Coverage <http://km3py.pages.km3net.de/km3det/coverage>
   Source (Git) <https://git.km3net.de/km3py/km3det>



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
