Collection of Examples
======================

All of these examples are auto-generated each time the documentation is built.
