Some helpers and utils functions.

::: denario.utils