# Paper

Functions related to the paper writing.

::: denario.paper_agents.agents_graph
::: denario.paper_agents.latex
::: denario.paper_agents.literature
::: denario.paper_agents.paper_node
::: denario.paper_agents.parameters
::: denario.paper_agents.prompts
::: denario.paper_agents.reader
::: denario.paper_agents.tools
