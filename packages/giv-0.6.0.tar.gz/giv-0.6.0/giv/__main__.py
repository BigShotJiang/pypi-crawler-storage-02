"""
Entry point for running giv as a module.

This allows the package to be executed with: python -m giv
"""
from giv.main import main

if __name__ == '__main__':
    main()
