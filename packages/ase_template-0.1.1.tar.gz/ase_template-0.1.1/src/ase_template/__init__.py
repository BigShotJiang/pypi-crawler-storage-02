def main() -> None:
    print("Hello from ase-template!")
