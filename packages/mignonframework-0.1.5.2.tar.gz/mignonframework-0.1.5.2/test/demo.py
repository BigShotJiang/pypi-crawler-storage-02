from MignonFramework.ProcessFile import run



run()
