# -*- coding: utf-8 -*-
"""
@author:XuMing(xuming624@qq.com)
@description:
"""
__version__ = "0.0.5"

from weather_forecast_server.weather import get_weather

