# Amulet-qt-dev

A pre-compiled version of QtBase with linking files
to allow other libraries to link directly to Qt.
