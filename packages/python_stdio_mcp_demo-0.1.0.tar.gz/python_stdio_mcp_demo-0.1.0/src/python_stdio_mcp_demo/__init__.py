def main() -> None:
    print("Hello from python-stdio-mcp-demo!")
