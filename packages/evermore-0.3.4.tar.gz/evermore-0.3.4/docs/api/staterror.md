# Staterrors

```{eval-rst}
.. automodule:: evermore.binned.staterror
    :show-inheritance:
    :members:
```
