# PyTree Filter

```{eval-rst}
.. automodule:: evermore.parameters.filter
    :show-inheritance:
    :members:
```
