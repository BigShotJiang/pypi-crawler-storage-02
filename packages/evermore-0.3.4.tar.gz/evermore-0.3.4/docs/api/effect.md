# Effects

```{eval-rst}
.. automodule:: evermore.binned.effect
    :show-inheritance:
    :members:
```
