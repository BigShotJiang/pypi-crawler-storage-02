# Tree Manipulation for Parameters

```{eval-rst}
.. automodule:: evermore.parameters.tree
    :show-inheritance:
    :members:
```
