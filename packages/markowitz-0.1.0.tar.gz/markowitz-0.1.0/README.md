# markowitz

Librería educativa para enseñar el modelo de Markowitz paso a paso con PyQt5 y datos de Yahoo Finance.
