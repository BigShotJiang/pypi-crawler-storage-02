
#### What is the change?

#### Does this change require a version increment:

- [ ] Major
- [ ] Minor
- [x] Patch
