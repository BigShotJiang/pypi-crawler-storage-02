async def journeytest1(*args):
    pass


async def journeytest2(*args):
    pass


async def journeytest3(*args):
    pass
