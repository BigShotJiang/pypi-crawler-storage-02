class TestDb:
    def __init__(self, p_conn, print_input_output=True):
        self.p_conn = p_conn
        self.print_input_output = print_input_output
