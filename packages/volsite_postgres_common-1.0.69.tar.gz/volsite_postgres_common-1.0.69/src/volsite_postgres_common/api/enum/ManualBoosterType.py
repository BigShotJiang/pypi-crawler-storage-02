from enum import IntEnum


class ManualBoosterType(IntEnum):

    Hammer = 1,
    Bombard = 2,
    BeanStalk = 3,
    Harp = 4,

