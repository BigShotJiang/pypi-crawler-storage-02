# postgres-common

  * volsite-postgres-common in [PyPI](https://pypi.org/project/volsite-postgres-common/1.0.3/) in MIT license
  * upload and update in PyPI: [SlipBox](http://122.116.163.128:8031/slipbox/doku.php?id=tsnaazsh)
