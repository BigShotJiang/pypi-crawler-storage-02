"""SpecPHP Scanner - OpenAPI vulnerability scanner for PHP applications."""
from __future__ import annotations

__version__ = '0.0.9'
__author__ = 'SpecPHP Scanner Team'
__description__ = 'Add your description here'
