"""Authentication modules for SpecPHP Scanner."""
from __future__ import annotations

__all__ = [
    'AuthFactory',
    'BaseAuth',
]
