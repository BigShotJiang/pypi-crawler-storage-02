class CruiseVersionDescription(object):
    def __init__(self, version_number, description, version_level, id=None):
        self.version_number = version_number
        self.description = description
        self.version_level = version_level
        self.id = id
