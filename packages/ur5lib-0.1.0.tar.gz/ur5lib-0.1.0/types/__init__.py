# ur5lib/types/__init__.py

# This file makes the `types` directory a module
# ur5lib/types/__init__.py

from .common_types import JointAngles, Pose
