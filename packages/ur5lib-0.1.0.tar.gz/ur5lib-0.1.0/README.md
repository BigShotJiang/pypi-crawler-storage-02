# ur5lib

Modular Python library for controlling UR5 robots (real + simulated).

## Install

```bash
pip install .
