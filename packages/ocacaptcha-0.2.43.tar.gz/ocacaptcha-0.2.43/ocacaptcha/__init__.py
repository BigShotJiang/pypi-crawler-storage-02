from .captcha_solver import oca_solve_captcha

__all__ = ['oca_solve_captcha']
