"""
---
title: Relative Multi-Headed Attention
summary: Relative Multi-Headed Attention from paper Transformer-XL.
redirect: https://nn.labml.ai/transformers/xl/relative_mha.html
---
"""
