__version__ = '1.0.11'

from onetick.lib.instance import OneTickLib
from onetick.lib.instance import LoggingLevel
