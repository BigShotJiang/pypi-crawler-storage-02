# piccard

Developed by Abdulmohseen AlAli, Elise Corbin, and Maliha Lodi.

The latest release of piccard is available on PyPI at https://pypi.org/project/piccard/.

To install the latest release, run:
```bash
pip install piccard==1.0.2
```
Then import the package using:
```python
from piccard import piccard as pc
```

To view the full documentation, please visit https://piccard.readthedocs.io/.