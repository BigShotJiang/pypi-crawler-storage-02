**Português** Ao Confirmar um Documento Fiscal do tipo NFe ou NFCe, os
dados das Tags de Pagamento e Duplicatas serão criados automaticamente.

**English** When Confirming a NFe or NFCe Fiscal Document, the Payment
Tags and Duplicates data will be created automatically.
