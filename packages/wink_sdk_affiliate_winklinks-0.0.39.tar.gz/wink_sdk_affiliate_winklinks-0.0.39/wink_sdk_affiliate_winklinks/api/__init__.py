# flake8: noqa

# import apis into api package
from wink_sdk_affiliate_winklinks.api.syndication_consumer_api import SyndicationConsumerApi
from wink_sdk_affiliate_winklinks.api.syndication_publisher_api import SyndicationPublisherApi

