## Requirements

- Python 3.6+
- Pydantic for the data parts.
- Rdflib for the parsing part.

## Installation

```
pip install pyimporters-mesh
```
