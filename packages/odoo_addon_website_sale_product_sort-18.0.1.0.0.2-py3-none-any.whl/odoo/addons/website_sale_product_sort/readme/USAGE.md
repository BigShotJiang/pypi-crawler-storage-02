After you've configured the default website settings:

1.  Go to the configured website shop url.
2.  The products will be sorted by default by the chosen option.
