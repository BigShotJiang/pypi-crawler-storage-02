- Could be nice to have a related model to configure the sorting options
  without the need of third modules.
