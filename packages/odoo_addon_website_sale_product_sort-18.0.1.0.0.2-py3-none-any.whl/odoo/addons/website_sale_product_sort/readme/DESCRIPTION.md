This module allows to set a default sorting criteria for the e-commerce
product list.

It provides the standard criterias, but allows to extend the options via
third modules.
