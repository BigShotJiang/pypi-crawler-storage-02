#!/usr/bin/env python3
"""Test CLI functionality."""

from github_issue_analysis.cli.collect import app

if __name__ == "__main__":
    app()
