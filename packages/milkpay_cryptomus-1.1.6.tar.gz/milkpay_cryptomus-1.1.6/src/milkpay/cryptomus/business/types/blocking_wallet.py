from .base import CryptomusObject


class BlockingWallet(CryptomusObject):
    uuid: str
    status: str
