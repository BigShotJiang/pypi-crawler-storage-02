from .constants_version import ConstantsVersion


# -------------------
## Holds various constants
class Constants(ConstantsVersion):  # pylint: disable=too-few-public-methods
    pass
