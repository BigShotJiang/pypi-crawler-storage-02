## holds reference to Cfg
cfg = None

## holds reference to logger
logger = None

## holds GUI API instance
guiapi = None

## holds reference to GUI API server
server = None
