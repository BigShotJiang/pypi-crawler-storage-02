class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '1.2.1'
    git_sha = '3238a6bec9952dfb92ccc7ea9ca64d6b5d072d5e'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
