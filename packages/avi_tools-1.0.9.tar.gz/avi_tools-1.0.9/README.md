
### `README.md`

````markdown
# avi_tools

**avi_tools** is a modular Python toolkit by Avi Twil that includes:

- Asynchronous function management
- A folder-based variable database
- Terminal utilities including colors, monoid operations, infix expressions, and file helpers

This toolkit is designed to be lightweight, simple to use, and helpful for scripting, automation, and educational purposes.

## Installation

```bash
pip install avi_tools
````

## Modules Overview

* `avi_tools.async_funcs_manager`: Manage async functions with wrappers and async runners.
* `avi_tools.variabledb`: Lightweight file-based key-value store.
* `avi_tools.twillkit`: Functional tools including Monoid, Infix, terminal colors, file helpers, and more.

## Usage Examples

### 1. Async Function Manager

```python
from avi_tools.async_funcs_manager import CapsFunc, FuncsToAsync, AsyncRunner

def hello(name):
    print(f"Hello, {name}")

def add(a, b):
    return a + b

caps_hello = CapsFunc("hello", hello, "Twill")
caps_add = CapsFunc("add", add, 3, 4)

funcs = FuncsToAsync([caps_hello, caps_add])
runner = AsyncRunner(funcs)
runner.run_all()
```

### 2. Variable Database

```python
from avi_tools.variabledb import VariableDB

db = VariableDB("my_db")
db.save("counter", 42)
value = db.load("counter")
print(value)  # 42
print("counter" in db)  # True
```

### 3. Terminal Colors

```python
from avi_tools.twillkit import Colors

print(f"{Colors.RED}This is red text{Colors.ENDC}")
print(f"{Colors.GREEN}This is green text{Colors.ENDC}")
```

### 4. Monoid and Infix Operators

```python
from avi_tools.twillkit import Monoid, Infix

m = Monoid(1, 2, 3)
n = Monoid(4, 5)
combined = m + n
print(combined)  # Monoid(1, 2, 3, 4, 5)

# Filter by type
print(m.of_type(int))

# Infix usage
@Infix
def is_evenly_divisible(a, b):
    return a % b == 0

print(10 |is_evenly_divisible| 2)  # True
```

## Project Structure

```
avi_tools/
├── async_funcs_manager/
├── variabledb/
├── twillkit/
```

## License

MIT License

## Author

Avi Twil

GitHub: [https://github.com/avitwil/avi_tools](https://github.com/avitwil/avi_tools)
PyPI: [https://pypi.org/project/avi\_tools/](https://pypi.org/project/avi_tools/)

```

---


