# Test section

Regarding the tests for the folder graphs and nodes it was created a specific repo as a example
([link of the repo](https://github.com/VinciGit00/Scrapegrah-ai-website-for-tests)). The test website is hosted [here](https://scrapegrah-ai-website-for-tests.onrender.com).
Remember to activating Ollama and having installed the LLM on your pc

For running the tests run the command:
```python
pytest
```
