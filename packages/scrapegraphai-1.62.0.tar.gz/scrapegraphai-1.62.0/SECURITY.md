# Security Policy

## Reporting a Vulnerability

For reporting a vulnerability contact directly mvincig11@gmail.com
