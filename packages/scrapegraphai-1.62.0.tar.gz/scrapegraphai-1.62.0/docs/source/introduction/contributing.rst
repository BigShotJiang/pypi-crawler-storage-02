Contributing
============

Hey, you want to contribute? Awesome!
Just fork the repo, make your changes, and send a pull request.
If you're not sure if it's a good idea, open an issue and we'll discuss it.

Go and check out the `contributing guidelines <https://github.com/VinciGit00/Scrapegraph-ai/blob/main/CONTRIBUTING.md>`__ for more information.

License
=======
This project is licensed under the MIT license.
See the `LICENSE <https://github.com/VinciGit00/Scrapegraph-ai/blob/main/LICENSE>`__ file for more details.
