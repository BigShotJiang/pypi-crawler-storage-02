import openflexure_stitching.pipeline


def test_imports():
    """
    This is a terrible test. All it does is check that
    the library imports at all.
    """
    pass
