from ._image_set_parts._image_set_metadata import ImageSetMetadata


class ImageSet(ImageSetMetadata):
    pass