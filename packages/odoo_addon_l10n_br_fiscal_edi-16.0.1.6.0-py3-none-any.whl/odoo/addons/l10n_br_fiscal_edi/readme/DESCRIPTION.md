Este módulo estende o módulo `l10n_br_fiscal` e cuida da parte de EDI
(Electronic Data Interchange) que é comum entre os vários documentos
fiscais no Brasil. Ele introduz os modelos de eventos de transmissão, de
correções... Alem disso ele cuida das possíveis transições de estado do
documento fiscal em função dos retornos dos webservices (campo
`state_edoc`).
