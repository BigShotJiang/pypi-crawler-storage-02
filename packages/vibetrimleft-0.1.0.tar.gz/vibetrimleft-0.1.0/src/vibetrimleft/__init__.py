from . import ai


def vibetrimleft(text: str) -> str:
    return ai.vibetrimleft(text)