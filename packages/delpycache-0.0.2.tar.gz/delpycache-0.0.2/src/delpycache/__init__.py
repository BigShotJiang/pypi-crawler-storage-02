from .main import delpycache

__all__ = ["delpycache"]
