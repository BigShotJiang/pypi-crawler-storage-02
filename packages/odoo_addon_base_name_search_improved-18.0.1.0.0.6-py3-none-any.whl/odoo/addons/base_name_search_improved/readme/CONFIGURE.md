The fuzzy search is automatically enabled on all Models. Note that this
only affects typing in related fields. The regular `search()`, used in
the top right search box, is not affected.

Additional search fields can be configured at Settings \> Technical \>
Database \> Models, using the "Name Search Fields" field.

![image1](https://raw.githubusercontent.com/OCA/server-tools/11.0/base_name_search_improved/images/image1.png)
