from .logger import Log as Log
from .logger import logger