"""
The version of the Linode CLI.
"""

__version__ = "v5.60.0"
