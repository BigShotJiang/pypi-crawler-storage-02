"""Tests for infrastructure layer components."""
