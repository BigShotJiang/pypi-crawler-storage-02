Set-Location -Path $PSScriptRoot
.\build-local-mulch-dir.ps1 -Location userprofile
.\install-mulch-context.ps1