from .transform import KubernetesTransformer as Transformer

assert Transformer
