kaiju
======

Python wrapped C++ collision avoidance routines for SDSS-V robotic fiber positioners.

