from griptape.drivers.embedding.dummy_embedding_driver import DummyEmbeddingDriver

__all__ = ["DummyEmbeddingDriver"]
