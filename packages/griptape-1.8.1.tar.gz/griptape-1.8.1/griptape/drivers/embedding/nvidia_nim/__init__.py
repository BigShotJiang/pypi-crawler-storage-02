from griptape.drivers.embedding.nvidia_nim_embedding_driver import NvidiaNimEmbeddingDriver

__all__ = ["NvidiaNimEmbeddingDriver"]
