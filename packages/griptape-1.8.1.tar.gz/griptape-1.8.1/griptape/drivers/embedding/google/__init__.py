from griptape.drivers.embedding.google_embedding_driver import GoogleEmbeddingDriver

__all__ = ["GoogleEmbeddingDriver"]
