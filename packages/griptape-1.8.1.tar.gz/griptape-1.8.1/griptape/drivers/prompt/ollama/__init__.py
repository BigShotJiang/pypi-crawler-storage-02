from griptape.drivers.prompt.ollama_prompt_driver import OllamaPromptDriver

__all__ = ["OllamaPromptDriver"]
