from griptape.drivers.image_generation_pipeline.stable_diffusion_3_img_2_img_image_generation_pipeline_driver import (
    StableDiffusion3Img2ImgImageGenerationPipelineDriver,
)

__all__ = [
    "StableDiffusion3Img2ImgImageGenerationPipelineDriver",
]
