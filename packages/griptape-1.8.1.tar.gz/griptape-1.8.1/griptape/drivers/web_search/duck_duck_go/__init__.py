from griptape.drivers.web_search.duck_duck_go_web_search_driver import DuckDuckGoWebSearchDriver

__all__ = ["DuckDuckGoWebSearchDriver"]
