from griptape.drivers.text_to_speech.elevenlabs_text_to_speech_driver import ElevenLabsTextToSpeechDriver

__all__ = ["ElevenLabsTextToSpeechDriver"]
