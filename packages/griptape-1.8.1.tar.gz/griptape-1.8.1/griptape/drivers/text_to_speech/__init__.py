from .base_text_to_speech_driver import BaseTextToSpeechDriver

__all__ = ["BaseTextToSpeechDriver"]
