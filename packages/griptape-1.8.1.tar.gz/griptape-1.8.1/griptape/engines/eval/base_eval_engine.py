from abc import ABC

from attrs import define


@define
class BaseEvalEngine(ABC): ...
