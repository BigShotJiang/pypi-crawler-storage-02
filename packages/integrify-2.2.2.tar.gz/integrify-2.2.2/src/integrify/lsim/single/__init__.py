"""Tək-tək SMS atmaq üçün sorğular modulu"""
