"""Toplu SMS atmaq üçün sorğular modulu"""
