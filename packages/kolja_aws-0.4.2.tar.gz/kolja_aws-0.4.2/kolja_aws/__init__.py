"""
Kolja AWS CLI Tool

A powerful CLI tool for managing AWS SSO sessions and profiles.
"""