from levseq.seqfit import SeqFitVis, gen_seqfitvis

# SeqFitVis(seqfit_path="sandbox/processed_plate_data.csv")

gen_seqfitvis(seqfit_path="sandbox/processed_plate_data.csv")