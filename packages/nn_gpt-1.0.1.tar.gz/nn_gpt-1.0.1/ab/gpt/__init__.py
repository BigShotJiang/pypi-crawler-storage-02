import os

os.environ['WANDB_MODE'] = 'disabled'
