## Fractal Neural Network Generation

Fractal_template - has the template of the models
Generate_variants - has the loop to generate no.of models 

cd nn-gpt 
python ab/gpt/brute/fract/Generate_variants.py

for fetching the files 
python -m ab.gpt.NNAlter_7B -e 1

