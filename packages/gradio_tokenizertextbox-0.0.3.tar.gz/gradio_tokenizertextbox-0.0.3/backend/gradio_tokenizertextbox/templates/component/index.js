import { I as f } from "./Index-br_21uOy.js";
export {
  f as default
};
