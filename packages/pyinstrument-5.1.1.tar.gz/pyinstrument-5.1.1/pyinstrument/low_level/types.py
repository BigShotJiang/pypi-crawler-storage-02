from pyinstrument.typing import LiteralStr

TimerType = LiteralStr["walltime", "walltime_thread", "timer_func", "walltime_coarse"]
