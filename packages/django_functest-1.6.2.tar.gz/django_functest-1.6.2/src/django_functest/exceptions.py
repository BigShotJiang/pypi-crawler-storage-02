class WebTestNoSuchElementException(Exception):
    pass


class WebTestMultipleElementsException(Exception):
    pass


class WebTestCantUseElement(Exception):
    pass


class SeleniumCantUseElement(Exception):
    pass
