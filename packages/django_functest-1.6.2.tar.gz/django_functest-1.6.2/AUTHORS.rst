=======
Credits
=======

`Wolf & Badger <https://www.wolfandbadger.com/>`_, for whom the code was
originally developed, and who allowed us to Open Source it. Thanks!

Luke Plant <L.Plant.98@cantab.net>
Frankie Robertson <frankie@robertson.name>
