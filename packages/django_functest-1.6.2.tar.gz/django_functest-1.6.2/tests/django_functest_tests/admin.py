from django.contrib import admin

from .models import Thing

admin.site.register(Thing)
