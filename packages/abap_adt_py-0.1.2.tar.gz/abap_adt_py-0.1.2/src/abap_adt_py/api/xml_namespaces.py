XML_NAMESPACES = {
    "chkl": "http://www.sap.com/abapxml/checklist",
    "atom": "http://www.w3.org/2005/Atom",
    "adtcore": "http://www.sap.com/adt/core",
    "exc": "http://www.sap.com/abapxml/types/communicationframework",
    "asx": "http://www.sap.com/abapxml",
    "aunit": "http://www.sap.com/adt/aunit",
    "chkrun": "http://www.sap.com/adt/checkrun"
}