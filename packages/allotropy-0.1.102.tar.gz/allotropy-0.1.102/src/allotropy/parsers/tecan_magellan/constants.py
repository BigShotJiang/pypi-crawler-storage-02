DISPLAY_NAME = "Tecan Magellan"
DEVICE_TYPE = "plate reader"
SOFTWARE_NAME = "Magellan"
PRODUCT_MANUFACTURER = "Tecan"

MEASUREMENT_TIME_REGEX = (
    r"Date of measurement: ([0-9\-]+)/Time of measurement: ([0-9\:]+)"
)
