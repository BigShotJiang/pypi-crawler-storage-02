DISPLAY_NAME = "Benchling Waters Empower Adapter"
DEVICE_TYPE = "HPLC"
SOFTWARE_NAME = "Waters Empower"
PRODUCT_MANUFACTURER = "Waters Corporation"
