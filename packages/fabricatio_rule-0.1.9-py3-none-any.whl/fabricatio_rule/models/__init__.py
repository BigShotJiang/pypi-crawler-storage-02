"""This module contains model definitions for the fabricatio-rule package.

It includes classes and data structures that represent rules, rule sets, and related entities within the system.
"""
