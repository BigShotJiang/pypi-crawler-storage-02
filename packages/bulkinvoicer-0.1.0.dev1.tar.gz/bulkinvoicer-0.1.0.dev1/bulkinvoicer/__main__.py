"""Run the Bulkinvoicer application CLI."""

from bulkinvoicer.cli import main

main()
