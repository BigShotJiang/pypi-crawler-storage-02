=======
History
=======

0.1.0 (2021-01-16)
------------------

* First release on PyPI.
