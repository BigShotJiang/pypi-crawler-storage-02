from .settings.version import __version__

version = __version__
