
import mapclient.tools.pluginwizard.ui.resources_rc
