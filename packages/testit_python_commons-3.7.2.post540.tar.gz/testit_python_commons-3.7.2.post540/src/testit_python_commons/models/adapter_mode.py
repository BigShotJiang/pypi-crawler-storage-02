class AdapterMode:
    USE_FILTER = '0'
    RUN_ALL_TESTS = '1'
    NEW_TEST_RUN = '2'
