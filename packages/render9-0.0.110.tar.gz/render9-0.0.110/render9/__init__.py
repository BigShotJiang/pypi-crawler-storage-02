# /render9/__init__.py
from .functions import sendOtp

# Define what gets exposed when you import the package
__all__ = ['sendOtp']
