#!/bin/bash
run-ipyeos -m pytest -x -s $1 -k $2


