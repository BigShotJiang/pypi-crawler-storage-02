# Defaultabi

> Auto-generated documentation for [pysrc.defaultabi](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/defaultabi.py) module.

- [Pyeoskit](../README.md#pyeoskit-index) / [Modules](../MODULES.md#pyeoskit-modules) / [Pysrc](index.md#pysrc) / Defaultabi
