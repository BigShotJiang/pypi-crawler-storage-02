# Test Helper

> Auto-generated documentation for [pysrc.test_helper](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/test_helper.py) module.

- [Pyeoskit](../README.md#pyeoskit-index) / [Modules](../MODULES.md#pyeoskit-modules) / [Pysrc](index.md#pysrc) / Test Helper
    - [config_network](#config_network)
    - [print_console](#print_console)
    - [run_test](#run_test)

## config_network

[[find in source code]](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/test_helper.py#L7)

```python
def config_network():
```

## print_console

[[find in source code]](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/test_helper.py#L52)

```python
def print_console(r):
```

## run_test

[[find in source code]](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/test_helper.py#L57)

```python
def run_test():
```
