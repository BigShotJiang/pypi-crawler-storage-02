# Common

> Auto-generated documentation for [pysrc.common](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/common.py) module.

- [Pyeoskit](../README.md#pyeoskit-index) / [Modules](../MODULES.md#pyeoskit-modules) / [Pysrc](index.md#pysrc) / Common
    - [check_result](#check_result)

## check_result

[[find in source code]](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/common.py#L2)

```python
def check_result(r):
```
