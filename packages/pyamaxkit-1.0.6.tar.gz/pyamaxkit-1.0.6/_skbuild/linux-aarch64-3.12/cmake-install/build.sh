python3 src/check_modification.py src/pyeoskit
python3 setup.py sdist bdist_wheel
# if [ $? -eq 0 ]; then
# ./install.sh
# fi

