import _block_log
BlockParser = _block_log.BlockParser

