# Crypto

> Auto-generated documentation for [pysrc.crypto](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/crypto.py) module.

- [Pyeoskit](../README.md#pyeoskit-index) / [Modules](../MODULES.md#pyeoskit-modules) / [Pysrc](index.md#pysrc) / Crypto
    - [create_key](#create_key)

## create_key

[[find in source code]](https://github.com/AMAX-DAO-DEV/pyamaxkit/blob/master/pysrc/crypto.py#L1)

```python
def create_key(old_format=True):
```
