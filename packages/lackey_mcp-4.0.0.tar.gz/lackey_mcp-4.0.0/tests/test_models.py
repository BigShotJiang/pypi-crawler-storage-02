"""Tests for Lackey core models."""
