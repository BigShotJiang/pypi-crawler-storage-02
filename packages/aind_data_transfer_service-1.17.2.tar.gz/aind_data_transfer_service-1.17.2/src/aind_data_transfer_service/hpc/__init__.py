"""Client to manage connection with slurm cluster"""
