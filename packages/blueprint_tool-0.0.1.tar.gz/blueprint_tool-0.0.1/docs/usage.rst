=====
Usage
=====

To use blueprint-tool in a project::

    import blueprint_tool
