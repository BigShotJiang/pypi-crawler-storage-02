"""Top-level package for blueprint-tool."""

__author__ = """Rex Wang"""
__email__ = '1073853456@qq.com'
__version__ = '0.0.1'
