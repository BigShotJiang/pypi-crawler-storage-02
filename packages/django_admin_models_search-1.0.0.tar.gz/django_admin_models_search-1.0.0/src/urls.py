from django.urls import path

from src.views import AdminModelSuggestionsView

urlpatterns = [
    path(
        "admin/model-suggestions/",
        AdminModelSuggestionsView.as_view(),
        name="model_suggestions",
    )
]
