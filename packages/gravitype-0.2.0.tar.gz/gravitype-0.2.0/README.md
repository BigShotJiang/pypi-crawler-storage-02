# Gravitype
Gravitype is a terminal-based falling-words typing game built with Textual.
Words fall from the top of the screen, and your goal is to type them before they hit the ground.
It’s typing practice… with gravity.

# 🚧 Status
> This project is a work in progress (v1).
> Currently, the UI is being built — gameplay logic and scoring will come in later versions.
