from core import AWSAuth, SNS, SQS, Lambda, DynamoDB, RDS, S3
