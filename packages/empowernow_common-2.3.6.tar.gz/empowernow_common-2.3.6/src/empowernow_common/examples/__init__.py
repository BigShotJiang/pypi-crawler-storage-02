"""Examples showcasing best-practice integrations with EmpowerNow Common.

Currently contains:
    • fastapi_demo — minimal FastAPI app using OAuthClient.
"""

from __future__ import annotations

__all__: list[str] = []
