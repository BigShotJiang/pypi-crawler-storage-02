URL_FILTER = "https://magma.esdm.go.id/api/v1/home/gunung-api/informasi-letusan/filter"
