# Infinitebench dataset

[Infinitebench](https://github.com/OpenBMB/InfiniteBench) is composed of 12 major tasks. 

## Create Hugging Face dataset

The processed Hugging Face dataset for Infinitebench can be found [here](https://huggingface.co/datasets/MaxJeblick/InfiniteBench). To reproduce this dataset, simply run the `create_huggingface_dataset.py` script.