# longbench dataset

[longbench-v2](https://github.com/THUDM/LongBench). 

## Create Hugging Face dataset

The processed Hugging Face dataset for longbench can be found [here](https://huggingface.co/datasets/Xnhyacinth/LongBench-v2). To reproduce this dataset, simply run the `create_huggingface_dataset.py` script.