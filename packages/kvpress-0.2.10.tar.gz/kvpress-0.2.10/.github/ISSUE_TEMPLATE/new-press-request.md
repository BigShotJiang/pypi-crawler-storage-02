---
name: New press Request
about: Submit a proposal/request for a new press
title: ''
labels: press request
assignees: ''

---

### Press

<!-- A clear and concise description of the new press, include any links to relevant papers or resources -->

### Motivation

<!-- Please outline the motivation for the proposal. Is your press different from existing ones? If so, how? -->
