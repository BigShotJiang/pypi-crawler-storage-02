"""FraiseQL repository utilities."""

from .passthrough_mixin import PassthroughMixin

__all__ = ["PassthroughMixin"]
