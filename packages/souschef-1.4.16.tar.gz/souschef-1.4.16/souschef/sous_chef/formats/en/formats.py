# https://docs.djangoproject.com/en/1.10/ref/templates/builtins/#std:templatefilter-date
DATE_FORMAT = "l, F jS Y"
SHORT_DATE_FORMAT = "F jS, Y"
