COMPONENT_SYSTEM_DEFAULT = {
    "main_dish": 1,
    "size": "R",
    "dessert": 1,
    "diabetic": 0,
    "fruit_salad": 0,
    "green_salad": 0,
    "pudding": 0,
    "compote": 0,
    "sides": 0,
}
