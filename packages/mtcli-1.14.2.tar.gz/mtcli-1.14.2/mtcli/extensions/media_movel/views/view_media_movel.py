"""Módulo da classe da view média móvel."""

from .. import conf


class MediaMovelView:
    """Classe da view da média móvel."""

    def __init__(self):
        """Construtor da view média móvel."""
        pass

    def view(self):
        """View da média móvel."""
        pass
