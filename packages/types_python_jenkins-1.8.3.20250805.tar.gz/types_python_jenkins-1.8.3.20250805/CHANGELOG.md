## 1.8.3.20250805 (2025-08-05)

Bump python-jenkins to 1.8.3 (#14520)

Co-authored-by: Brian Schubert <brianm.schubert@gmail.com>

## 1.8.0.20240921 (2024-09-21)

Add stubs for python-jenkins (#12582)

Co-authored-by: Jelle Zijlstra <jelle.zijlstra@gmail.com>

