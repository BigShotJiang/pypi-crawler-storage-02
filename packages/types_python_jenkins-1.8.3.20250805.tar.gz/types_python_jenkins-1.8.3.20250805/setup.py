
from setuptools import setup

setup(package_data={'jenkins-stubs': ['__init__.pyi', 'plugins.pyi', 'version.pyi', 'METADATA.toml', 'py.typed']})
