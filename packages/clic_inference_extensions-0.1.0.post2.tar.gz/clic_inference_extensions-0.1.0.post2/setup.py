import os
import glob
import sys
from setuptools import setup, find_packages
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

# 收集所有头文件
header_files = glob.glob('clic_inference_extensions/*.h') + \
               glob.glob('clic_inference_extensions/*.hpp') + \
               glob.glob('clic_inference_extensions/*.cuh')

cxx_flags = ["-O3"]
nvcc_flags = [
        "-O3", 
        "--use_fast_math", 
        "--extra-device-vectorization",
        "-std=c++17",
        "-gencode", "arch=compute_70,code=sm_70",   # V100
        "-gencode", "arch=compute_75,code=sm_75",   # T4
        "-gencode", "arch=compute_80,code=sm_80",   # A100
        "-gencode", "arch=compute_86,code=sm_86",   # RTX 30xx
        "-gencode", "arch=compute_89,code=sm_89",   # L4, RTX 40xx
        "-gencode", "arch=compute_90,code=sm_90",   # H100 (如果需要支持)
        "-gencode", "arch=compute_89,code=compute_89"  # PTX for forward compatibility
]
if sys.platform == 'win32':
    cxx_flags = ["/O2"]

setup(
    name='clic_inference_extensions',
    version='0.1.0.post2',  # 版本号递增
    author="Zhaoyang Jia, Bin Li, Jiahao Li, Wenxuan Xie, Linfeng Qi, Houqiang Li, Yan Lu",
    author_email="jzy_ustc@mail.ustc.edu.cn, qlf324@mail.ustc.edu.cn, libin@microsoft.com, li.jiahao@microsoft.com, wenxie@microsoft.com, lihq@ustc.edu.cn, yanlu@microsoft.com",
    maintainer="Wei Jiang", 
    maintainer_email="jiangwei@stu.pku.edu.cn",
    description='PyTorch CUDA extension for fast inference of DCVC-RT',
    long_description_content_type="text/markdown",
    license="MIT",
    packages=find_packages(),
    
    # 包含头文件
    package_data={
        'clic_inference_extensions': ['*.h', '*.hpp', '*.cuh']
    },
    include_package_data=True,
    
    ext_modules=[
        CUDAExtension(
            name='clic_inference_extensions._C',
            sources=glob.glob('clic_inference_extensions/*.cpp') + glob.glob('clic_inference_extensions/*.cu'),
            include_dirs=['clic_inference_extensions'],
            extra_compile_args={
                "cxx": cxx_flags,
                "nvcc": nvcc_flags,
            },
        ),
    ],
    cmdclass={'build_ext': BuildExtension},
    python_requires=">=3.11",
    install_requires=["torch>=1.10"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)