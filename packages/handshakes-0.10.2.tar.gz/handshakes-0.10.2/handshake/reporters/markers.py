from pytest import mark

meta_data_mark = "test_metadata"
set_info = mark.test_metadata
