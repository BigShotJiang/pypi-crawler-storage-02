def db_name() -> str:
    return "TeStReSuLtS.db"
