import numpy as np
from cpmpy.expressions.core import Expression
from cpmpy.expressions.variables import _NumVarImpl, NegBoolView, NDVarArray

from .language import _AbstracVar


