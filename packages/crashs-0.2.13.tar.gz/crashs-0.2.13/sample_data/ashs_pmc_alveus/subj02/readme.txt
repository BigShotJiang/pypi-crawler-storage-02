This folder contains ASHS output with ASHS PMC atlas for ADNI participant 003_S_4441 timepoint 2021-04-08.
