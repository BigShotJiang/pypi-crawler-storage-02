#!/bin/bash
./crashs.py -s right -r 0.1 sample_data/035_S_4082_2011-06-28 templates/crashs_template_01 /tmp/test
