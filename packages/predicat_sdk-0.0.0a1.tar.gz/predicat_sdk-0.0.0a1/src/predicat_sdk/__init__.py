"""
Placeholder package for predicat-sdk.
"""
__all__ = []
__version__ = "0.0.0a1"
