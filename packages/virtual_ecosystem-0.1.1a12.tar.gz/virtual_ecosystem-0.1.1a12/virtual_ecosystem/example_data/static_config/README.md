# Notes on static configuration files

Please note that the configuration files in this directory are created solely for the
purpose of building the documentation online. The paths will likely not work on all
machines. Therefore, please follow the documentation on the website
'Using the Virtual Ecosystem/Getting started/Running the Virtual Ecosystem in Static Mode'
to create static configuration files for your own experiments.
