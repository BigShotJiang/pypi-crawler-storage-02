"""Python scripts to generate example datasets."""
