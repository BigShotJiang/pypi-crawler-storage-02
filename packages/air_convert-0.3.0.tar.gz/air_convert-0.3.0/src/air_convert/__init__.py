"""Top-level package for air-convert."""

__author__ = """Audrey M. Roy Greenfeld"""
__email__ = "audrey@feldroy.com"

from air_convert.air_convert import html_to_airtags as html_to_airtags
