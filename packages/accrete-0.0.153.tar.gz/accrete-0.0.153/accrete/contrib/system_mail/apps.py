from django.apps import AppConfig


class SystemMailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accrete.contrib.system_mail'
