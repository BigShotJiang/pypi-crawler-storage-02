"""GitManager's test cases."""
