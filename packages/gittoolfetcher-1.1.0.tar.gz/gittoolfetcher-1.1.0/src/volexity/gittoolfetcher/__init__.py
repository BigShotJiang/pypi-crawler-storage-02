"""GitToolFetcher manages multiple versions of github-hosted projects."""
