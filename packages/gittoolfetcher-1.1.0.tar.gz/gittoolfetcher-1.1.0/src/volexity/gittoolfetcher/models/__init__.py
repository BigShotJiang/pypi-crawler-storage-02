"""GitToolFetcher's data models."""
