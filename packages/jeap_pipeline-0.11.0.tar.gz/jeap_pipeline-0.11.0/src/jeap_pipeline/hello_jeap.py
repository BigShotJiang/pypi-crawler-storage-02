def say_hello():
    print("Hello, jEAP!")
