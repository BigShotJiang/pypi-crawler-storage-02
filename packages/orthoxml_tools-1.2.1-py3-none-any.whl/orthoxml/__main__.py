# orthoxml/__main__.py

from .cli import main

if __name__ == "__main__":
    main()
