:::darkseid.validate.ValidationError
:::darkseid.validate.SchemaVersion
:::darkseid.validate.ValidateMetadata