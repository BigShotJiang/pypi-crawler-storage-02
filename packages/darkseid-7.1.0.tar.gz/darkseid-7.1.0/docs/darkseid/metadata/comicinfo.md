:::darkseid.metadata.comicinfo.ComicInfo
