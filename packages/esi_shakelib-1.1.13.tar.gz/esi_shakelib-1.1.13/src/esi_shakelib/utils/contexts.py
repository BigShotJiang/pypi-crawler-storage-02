class SitesContext:
    pass


class DistancesContext:
    pass


class RuptureContext:
    pass
