"""Initialization action for Concordia CLI."""

from .initialization import run_initialization

__all__ = ['run_initialization']
