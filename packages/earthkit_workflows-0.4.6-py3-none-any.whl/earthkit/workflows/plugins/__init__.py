"""Placeholder module to be populated by -plugin packages"""

import pkgutil

__path__ = pkgutil.extend_path(__path__, __name__)
