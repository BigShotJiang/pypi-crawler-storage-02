---
name: Bug report
about: Create a report to help us improve
title: ''
labels: 'kind/bug, priority/p2'
assignees: ''

---

## Expected Behavior 

## Current Behavior

## Steps to reproduce

### Specifications

- Version:
- Platform:
- Subsystem:

## Possible Solution
