feast.api.registry package
==========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.api.registry.rest

Module contents
---------------

.. automodule:: feast.api.registry
   :members:
   :undoc-members:
   :show-inheritance:
