feast.protos.feast package
==========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.protos.feast.core
   feast.protos.feast.registry
   feast.protos.feast.serving
   feast.protos.feast.storage
   feast.protos.feast.types

Module contents
---------------

.. automodule:: feast.protos.feast
   :members:
   :undoc-members:
   :show-inheritance:
