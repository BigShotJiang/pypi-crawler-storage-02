feast.infra.registry.contrib package
====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.infra.registry.contrib.azure

Module contents
---------------

.. automodule:: feast.infra.registry.contrib
   :members:
   :undoc-members:
   :show-inheritance:
