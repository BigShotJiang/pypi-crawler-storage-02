# -*- coding: utf-8 -*-

from cloud_auth_tpm.gcp.gcpcredentials import GCPCredentials