# -*- coding: utf-8 -*-

from cloud_auth_tpm.base import BaseCredential