# -*- coding: utf-8 -*-

from cloud_auth_tpm.aws.awscredentials import AWSCredentials
from cloud_auth_tpm.aws.awshmaccredentials import AWSHMACCredentials