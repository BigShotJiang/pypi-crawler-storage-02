__version__ = "1.0.0"

__author__ = "Claude Code Assistant"

__description__ = "MkDocs plugin to preprocess Mermaid diagrams"
