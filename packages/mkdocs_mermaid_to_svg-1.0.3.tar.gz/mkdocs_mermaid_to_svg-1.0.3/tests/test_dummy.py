"""Dummy test for template repository CI."""


def test_dummy():
    """Dummy test to make CI pass in template repository."""
    assert True
