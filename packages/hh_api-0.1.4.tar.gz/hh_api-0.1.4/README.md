# hh-api

[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/downloads/)
[![PyPI](https://img.shields.io/pypi/v/hh-api)](https://pypi.org/project/hh-api/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

Современная асинхронная Python-библиотека для работы с API HeadHunter (hh.ru) с автоматическим управлением OAuth2-токенами и поддержкой multi-tenant архитектуры.

## 🎯 Ключевые особенности

- 🚀 **Полностью асинхронная** на базе `httpx` и `asyncio`
- 🔐 **Умное управление OAuth2-токенами** с автоматическим обновлением
- 🏢 **Multi-tenant поддержка** для работы с несколькими пользователями
- 💾 **Гибкие хранилища токенов**: память, JSON-файлы, Redis, база данных, переменные окружения
- 🔄 **Автоматические повторные попытки** при сетевых ошибках
- 🎭 **Полная типизация** для лучшей поддержки IDE
- 🛡️ **Безопасность**: защита от race conditions при обновлении токенов

## 📦 Установка

```bash
pip install hh-api
```


## 📚 API Reference

### HHClient

| Метод | Описание |
|-------|----------|
| `search_vacancies(**params)` | Поиск вакансий |
| `get_vacancy(vacancy_id)` | Получить детали вакансии |
| `get_resume(resume_id)` | Получить информацию о резюме |
| `search_similar_vacancies(resume_id, **params)` | Найти похожие вакансии |
| `apply_to_vacancy(resume_id, vacancy_id, message)` | Откликнуться на вакансию |
| `get_dictionaries()` | Получить справочники HH |

### TokenManager

| Метод | Описание |
|-------|----------|
| `authorization_url(subject, state?)` | Сгенерировать URL для авторизации |
| `exchange_code(subject, code)` | Обменять код на токены |
| `ensure_access(subject)` | Получить действующий access token |
| `refresh(subject, refresh_token?)` | Обновить токены |


## 🤝 Вклад в проект

Приветствуются pull requests! Для больших изменений сначала откройте issue для обсуждения.

1. Fork репозитория
2. Создайте ветку для фичи (`git checkout -b feature/AmazingFeature`)
3. Commit изменения (`git commit -m 'Add some AmazingFeature'`)
4. Push в ветку (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

## 📄 Лицензия

Этот проект лицензирован под MIT License - см. файл [LICENSE](LICENSE) для деталей.

## 🙏 Благодарности

- [HeadHunter API](https://github.com/hhru/api) за отличную документацию
- [httpx](https://www.python-httpx.org/) за прекрасный асинхронный HTTP-клиент
- Всем контрибьюторам проекта

## 📧 Контакты

iNetsmol - [@inetsmol](https://github.com/inetsmol) - inetsmol@gmail.com

Ссылка на проект: [https://github.com/inetsmol/hh-api](https://github.com/inetsmol/hh-api)