def toInt(data):
    return int.from_bytes(data, byteorder='big')