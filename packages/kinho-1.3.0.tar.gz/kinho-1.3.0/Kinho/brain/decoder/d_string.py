def toString(data):
    return data.decode('utf-8')