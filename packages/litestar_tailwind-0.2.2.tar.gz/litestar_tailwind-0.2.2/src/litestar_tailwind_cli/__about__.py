# SPDX-FileCopyrightText: 2024-present Tobi DEGNON <tobidegnon@proton.me>
# SPDX-FileCopyrightText: 2025 Aoi <aoicistus@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.2.2"
