"""
Tests package for MCP Proxy Adapter.
""" 