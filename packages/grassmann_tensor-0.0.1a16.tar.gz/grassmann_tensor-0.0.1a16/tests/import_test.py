def test_import() -> None:
    from grassmann_tensor import GrassmannTensor
    assert isinstance(GrassmannTensor, type)
