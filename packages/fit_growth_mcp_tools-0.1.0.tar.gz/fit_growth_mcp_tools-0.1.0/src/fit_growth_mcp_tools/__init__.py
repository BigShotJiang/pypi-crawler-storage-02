def main() -> None:
    print("Hello from fit-growth-mcp-tools!")
