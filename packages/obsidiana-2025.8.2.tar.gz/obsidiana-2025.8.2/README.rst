=============
``Obsidiana``
=============

|PyPI| |CI|

.. |PyPI| image:: https://img.shields.io/pypi/v/obsidiana.svg
  :alt: PyPI version
  :target: https://pypi.org/project/obsidiana/

.. |CI| image:: https://github.com/Julian/obsidiana/workflows/CI/badge.svg
  :alt: Build status
  :target: https://github.com/Julian/obsidiana/actions?query=workflow%3ACI

A set of tools for working with (my? your?) Obsidian vault.


Should I Use This?
------------------

If you're not @Julian, possibly not as-is, but I like making my tools public in case they do turn out useful to you, or even so you can tell me if you do similar things yourself, so feel free to peruse or use.


What's in a Name
----------------

"Obsidiana" is spanish for Obsidian.
Unlike ``obsidian`` it also wasn't yet taken on PyPI.
