"""Capabilities defined in fabricatio-rag."""
