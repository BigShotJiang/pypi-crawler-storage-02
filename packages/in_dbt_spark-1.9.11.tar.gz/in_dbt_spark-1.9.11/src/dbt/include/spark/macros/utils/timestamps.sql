{% macro spark__current_timestamp() -%}
    current_timestamp()
{%- endmacro %}
