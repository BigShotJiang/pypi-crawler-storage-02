.. _flux_scaling:

*******************************************
Flux Scaling (:mod:`radiosim.flux_scaling`)
*******************************************

.. currentmodule:: radiosim.flux_scaling

Flux scaling module.


Reference/API
=============

.. automodapi:: radiosim.flux_scaling
    :inherited-members:
