# Changelog

## 0.8.0 (2025-08-14)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/bennorris123/python-sdk-test/compare/v0.7.0...v0.8.0)

### Features

* **api:** update via SDK Studio ([cbc6619](https://github.com/bennorris123/python-sdk-test/commit/cbc661913b0a9bf0cb35299c2d9204ee7b152688))

## 0.7.0 (2025-08-13)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/bennorris123/python-sdk-test/compare/v0.6.0...v0.7.0)

### Features

* **api:** update via SDK Studio ([3efa83f](https://github.com/bennorris123/python-sdk-test/commit/3efa83f7e680f2b1c74cae9055a43b0d222c4931))

## 0.6.0 (2025-08-13)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/bennorris123/python-sdk-test/compare/v0.5.0...v0.6.0)

### Features

* **api:** update via SDK Studio ([a4cd471](https://github.com/bennorris123/python-sdk-test/commit/a4cd471edcf637e498a108460e3b7193b2483778))

## 0.5.0 (2025-08-13)

Full Changelog: [v0.5.0...v0.5.0](https://github.com/bennorris123/python-sdk-test/compare/v0.5.0...v0.5.0)

### Features

* **api:** update via SDK Studio ([9824ac8](https://github.com/bennorris123/python-sdk-test/commit/9824ac80cbfb86c8ade7c13c1ee3cdf8d2181465))

## 0.5.0 (2025-08-13)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/bennorris123/python-sdk-test/compare/v0.4.0...v0.5.0)

### Features

* **api:** update via SDK Studio ([503d71d](https://github.com/bennorris123/python-sdk-test/commit/503d71d4a99aad1471176da946c1a7b3a0ea35b3))

## 0.4.0 (2025-08-13)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/bennorris123/python-sdk-test/compare/v0.3.0...v0.4.0)

### Features

* **api:** update via SDK Studio ([883a23e](https://github.com/bennorris123/python-sdk-test/commit/883a23e253dc4105c84e0d051ea9a8e32f2468af))
* **api:** update via SDK Studio ([4533f35](https://github.com/bennorris123/python-sdk-test/commit/4533f35c1bfb027b9b1c79879973001410f9b1f3))

## 0.3.0 (2025-08-13)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/bennorris123/python-sdk-test/compare/v0.2.0...v0.3.0)

### Features

* **api:** update via SDK Studio ([77df394](https://github.com/bennorris123/python-sdk-test/commit/77df3941fbc6615dd791fe9b8e88278d6ff8cbb0))


### Chores

* sync repo ([51d2d54](https://github.com/bennorris123/python-sdk-test/commit/51d2d54b3b293398470493840de4ae38298ea895))

## 0.2.0 (2025-08-12)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/bennorris123/python-sdk-test/compare/v0.1.0...v0.2.0)

### Features

* **api:** update via SDK Studio ([da723e2](https://github.com/bennorris123/python-sdk-test/commit/da723e2f362cbf2ba2e321df16a4b189bf235d0e))

## 0.1.0 (2025-08-12)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/bennorris123/python-sdk-test/compare/v0.0.1...v0.1.0)

### Features

* **api:** update via SDK Studio ([2d90884](https://github.com/bennorris123/python-sdk-test/commit/2d90884dd6751d45bb10b1869713e2e83b8f92bc))


### Chores

* **internal:** codegen related update ([c26a48b](https://github.com/bennorris123/python-sdk-test/commit/c26a48b09684be99a1c493fa8270c3680657f658))
* update SDK settings ([b431d67](https://github.com/bennorris123/python-sdk-test/commit/b431d67e5c264a8a7759648f09ee74dc6e328545))
* update SDK settings ([ebc487a](https://github.com/bennorris123/python-sdk-test/commit/ebc487a8ca316b0ea25866fe08489b6507f574d1))
