This holds common code for implementing DataPlatforms.
