from django.apps import AppConfig


class DjangoMusicbrainzConnectorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_musicbrainz_connector"
