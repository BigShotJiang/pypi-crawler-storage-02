Artist Type
===========

.. autoclass:: django_musicbrainz_connector.models::ArtistType

.. include:: includes/artist-types.md
   :parser: myst_parser.sphinx_
