Artist Credit Name
==================

.. autoclass:: django_musicbrainz_connector.models::ArtistCreditName
