Medium Format
=============

.. autoclass:: django_musicbrainz_connector.models::MediumFormat
