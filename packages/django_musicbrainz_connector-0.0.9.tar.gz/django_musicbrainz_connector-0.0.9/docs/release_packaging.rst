ReleasePackaging
================

.. autoclass:: django_musicbrainz_connector.models::ReleasePackaging
