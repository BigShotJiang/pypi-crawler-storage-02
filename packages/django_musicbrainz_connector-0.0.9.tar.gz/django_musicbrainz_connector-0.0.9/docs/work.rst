Work
====

.. autoclass:: django_musicbrainz_connector.models::Work
   :members: musicbrainz_url, recordings
