Link Text Attribute Type
========================

.. autoclass:: django_musicbrainz_connector.models::LinkTextAttributeType
