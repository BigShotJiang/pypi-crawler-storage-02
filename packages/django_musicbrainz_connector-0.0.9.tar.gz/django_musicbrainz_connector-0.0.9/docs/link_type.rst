Link Type
=========

.. autoclass:: django_musicbrainz_connector.models::LinkType
