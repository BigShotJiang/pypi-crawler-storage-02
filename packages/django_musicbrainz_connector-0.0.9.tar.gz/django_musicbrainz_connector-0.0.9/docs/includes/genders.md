Genders
========

Last checked on 2025-04-25, there are 5 genders in the MusicBrainz database:

| id              | name              |  description             |
|-----------------|-------------------|--------------------------|
| 1 | Male | None |
| 2 | Female | None |
| 3 | Other | None |
| 4 | Not applicable | For cases where gender just doesn&#x27;t apply at all (like companies entered as artists). |
| 5 | Non-binary | None |
