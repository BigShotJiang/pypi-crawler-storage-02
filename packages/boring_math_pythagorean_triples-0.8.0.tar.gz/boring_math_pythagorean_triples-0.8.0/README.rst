Boring Math - Pythagorean Triples
=================================

PyPI project
`boring-math-pythagorean-triples
<https://pypi.org/project/boring-math-pythagorean-triples>`_.

Package containing a class to generate Pythagorean triples along
with a CLI executable.

This PyPI project is part of of the grscheller
`boring-math namespace projects
<https://github.com/grscheller/boring-math/blob/main/README.md>`_

Documentation
-------------

Documentation for this project is hosted on
`GitHub Pages
<https://grscheller.github.io/boring-math/pythagorean-triples/development/build/html>`_.

Copyright and License
---------------------

Copyright (c) 2023-2025 Geoffrey R. Scheller. Licensed under the Apache
License, Version 2.0. See the LICENSE file for details.
