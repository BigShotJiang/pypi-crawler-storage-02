# src/quantum_starter_lab/noise/__init__.py

from .spec import NoiseSpec

__all__ = [
    "NoiseSpec",
]
