API Reference
=============

.. toctree::
    :titlesonly:

    colour_cxc

Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`
