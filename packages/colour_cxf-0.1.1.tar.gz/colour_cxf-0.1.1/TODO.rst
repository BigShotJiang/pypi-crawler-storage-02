Colour - TODO
=============

TODO
----



About
-----

| **Colour** by Colour Developers
| Copyright 2013 Colour Developers - `colour-developers@colour-science.org <colour-developers@colour-science.org>`__
| This software is released under terms of BSD-3-Clause: https://opensource.org/licenses/BSD-3-Clause
| `https://github.com/colour-science/colour <https://github.com/colour-science/colour>`__
