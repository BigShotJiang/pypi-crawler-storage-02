"""
WebSocket room management for Tempest framework
"""

from collections import defaultdict
from typing import Dict, Set

from .connection import WebSocket


class WebSocketManager:
    """WebSocket room system for managing connections and broadcasting"""
    
    def __init__(self):
        self.connections: Dict[str, WebSocket] = {}
        self.rooms: Dict[str, Set[str]] = defaultdict(set)
    
    def add_connection(self, connection_id: str, websocket: WebSocket):
        """Add a WebSocket connection"""
        self.connections[connection_id] = websocket
    
    def remove_connection(self, connection_id: str):
        """Remove a WebSocket connection"""
        if connection_id in self.connections:
            # Remove from all rooms
            for room_connections in self.rooms.values():
                room_connections.discard(connection_id)
            
            # Remove connection
            del self.connections[connection_id]
    
    def join_room(self, connection_id: str, room: str):
        """Add connection to a room"""
        if connection_id in self.connections:
            self.rooms[room].add(connection_id)
    
    def leave_room(self, connection_id: str, room: str):
        """Remove connection from a room"""
        if room in self.rooms:
            self.rooms[room].discard(connection_id)
    
    async def broadcast_to_room(self, room: str, message: str):
        """Broadcast message to all connections in a room"""
        if room in self.rooms:
            for connection_id in self.rooms[room]:
                if connection_id in self.connections:
                    websocket = self.connections[connection_id]
                    try:
                        await websocket.send_text(message)
                    except Exception:
                        # Connection may be closed, remove it
                        self.remove_connection(connection_id)
    
    async def broadcast_to_all(self, message: str):
        """Broadcast message to all connections"""
        for connection_id, websocket in list(self.connections.items()):
            try:
                await websocket.send_text(message)
            except Exception:
                # Connection may be closed, remove it
                self.remove_connection(connection_id)
    
    def get_room_connections(self, room: str) -> Set[str]:
        """Get all connection IDs in a room"""
        return self.rooms.get(room, set()).copy()
    
    def get_connection_rooms(self, connection_id: str) -> Set[str]:
        """Get all rooms a connection is in"""
        rooms = set()
        for room, connections in self.rooms.items():
            if connection_id in connections:
                rooms.add(room)
        return rooms