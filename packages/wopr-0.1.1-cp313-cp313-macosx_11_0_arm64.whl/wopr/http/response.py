"""
HTTP Response handling for Tempest framework
"""

import json
import mimetypes
import os
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple, Union


class Response:
    """HTTP Response object"""
    
    def __init__(self, 
                 body: Union[str, bytes] = "", 
                 status: int = 200,
                 headers: Optional[Dict[str, str]] = None,
                 content_type: Optional[str] = None):
        self.body = body
        self.status = status
        self.headers = headers or {}
        
        if content_type:
            self.headers['content-type'] = content_type
        elif 'content-type' not in self.headers:
            if isinstance(body, str):
                self.headers['content-type'] = 'text/html; charset=utf-8'
            else:
                self.headers['content-type'] = 'application/octet-stream'
    
    def to_rsgi_headers(self) -> List[Tuple[str, str]]:
        """Convert headers to RSGI format"""
        return [(k, v) for k, v in self.headers.items()]


class JSONResponse(Response):
    """JSON response helper"""
    
    def __init__(self, data: Any, status: int = 200, **kwargs):
        body = json.dumps(data, separators=(',', ':'))
        super().__init__(body, status, content_type='application/json', **kwargs)


class FileResponse(Response):
    """File response helper"""
    
    def __init__(self, path: Union[str, Path], 
                 filename: Optional[str] = None,
                 status: int = 200,
                 headers: Optional[Dict[str, str]] = None):
        self.file_path = str(path)
        self.filename = filename or os.path.basename(self.file_path)
        
        content_type, _ = mimetypes.guess_type(self.file_path)
        if not content_type:
            content_type = 'application/octet-stream'
        
        headers = headers or {}
        headers['content-type'] = content_type
        headers['content-disposition'] = f'attachment; filename="{self.filename}"'
        
        super().__init__("", status, headers)


class StreamResponse:
    """Streaming response for server-sent events or chunked data"""
    
    def __init__(self, 
                 generator: Callable[[], Awaitable],
                 status: int = 200,
                 headers: Optional[Dict[str, str]] = None,
                 content_type: str = 'text/plain'):
        self.generator = generator
        self.status = status
        self.headers = headers or {}
        self.headers['content-type'] = content_type