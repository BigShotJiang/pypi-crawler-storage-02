"""
HTTP Request handling for Tempest framework
"""

import json
from typing import Any, Dict, List
from urllib.parse import parse_qs

try:
    from granian.rsgi import Scope, HTTPProtocol
except ImportError:
    from typing import TypedDict
    # Fallback types for development without Granian
    class Scope(TypedDict, total=True):
        proto: str
        method: str
        path: str
        query_string: str
        headers: Any

    class HTTPProtocol:
        async def __call__(self): pass


class Request:
    """HTTP Request object with async capabilities"""
    
    def __init__(self, scope: Scope, protocol: HTTPProtocol):
        self.scope = scope
        self.protocol = protocol
        self._body = None
        self._json = None
        self._form = None

    @property
    def client_ip(self) -> str:
        # Standard 'X-Forwarded-For' header
        if 'x-forwarded-for' in self.headers:
            return self.headers['x-forwarded-for'].split(',')[0].strip()

        # Fallback to remote address from scope if available
        if hasattr(self.scope, 'client') and self.scope.client:
            return self.scope.client[0]

        return "unknown"
        
    @property
    def method(self) -> str:
        return self.scope.method
    
    @property
    def path(self) -> str:
        return self.scope.path
    
    @property
    def query_string(self) -> str:
        return self.scope.query_string
    
    @property
    def args(self) -> Dict[str, List[str]]:
        """Query parameters as dict"""
        if not hasattr(self, '_args'):
            self._args = parse_qs(self.query_string)
        return self._args
    
    @property
    def headers(self) -> Dict[str, str]:
        """Request headers (case-insensitive)"""
        if not hasattr(self, '_headers_dict'):
            self._headers_dict = dict(self.scope.headers)
        return self._headers_dict
    
    async def get_data(self) -> bytes:
        """Get raw request body"""
        if self._body is None:
            self._body = await self.protocol()
        return self._body
    
    async def get_json(self) -> Any:
        """Parse JSON from request body"""
        if self._json is None:
            data = await self.get_data()
            if data:
                self._json = json.loads(data.decode('utf-8'))
            else:
                self._json = None
        return self._json
    
    async def get_form(self) -> Dict[str, List[str]]:
        """Parse form data from request body"""
        if self._form is None:
            data = await self.get_data()
            if data and self.headers.get('content-type', '').startswith('application/x-www-form-urlencoded'):
                self._form = parse_qs(data.decode('utf-8'))
            else:
                self._form = {}
        return self._form