"""
CORS middleware for Tempest framework
"""

from typing import Callable, List, Optional

from ..http.request import Request
from ..http.response import Response


class CORSMiddleware:
    """Middleware for handling Cross-Origin Resource Sharing (CORS)"""
    
    def __init__(self, 
                 origins: Optional[List[str]] = None,
                 methods: Optional[List[str]] = None,
                 headers: Optional[List[str]] = None,
                 allow_credentials: bool = False,
                 max_age: int = 3600):
        
        self.origins = origins or ["*"]
        self.methods = methods or ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
        self.headers = headers or ["Content-Type", "Authorization"]
        self.allow_credentials = allow_credentials
        self.max_age = max_age
    
    async def __call__(self, request: Request, call_next: Callable) -> Response:
        """Process request and add CORS headers"""
        origin = request.headers.get('origin', '')
        
        # Handle preflight OPTIONS request
        if request.method == 'OPTIONS':
            return self._handle_preflight(origin)
        
        # Process normal request
        response = await call_next(request)
        
        # Add CORS headers to response
        self._add_cors_headers(response, origin)
        
        return response
    
    def _handle_preflight(self, origin: str) -> Response:
        """Handle CORS preflight request"""
        response = Response("", status=204)
        self._add_cors_headers(response, origin)
        
        # Add preflight-specific headers
        response.headers['access-control-allow-methods'] = ', '.join(self.methods)
        response.headers['access-control-allow-headers'] = ', '.join(self.headers)
        response.headers['access-control-max-age'] = str(self.max_age)
        
        return response
    
    def _add_cors_headers(self, response: Response, origin: str):
        """Add CORS headers to response"""
        if self._is_origin_allowed(origin):
            if '*' in self.origins and not self.allow_credentials:
                response.headers['access-control-allow-origin'] = '*'
            else:
                response.headers['access-control-allow-origin'] = origin
        
        if self.allow_credentials:
            response.headers['access-control-allow-credentials'] = 'true'
        
        # Always add Vary header for Origin when not using wildcard
        if '*' not in self.origins:
            vary = response.headers.get('vary', '')
            if vary:
                response.headers['vary'] = f"{vary}, Origin"
            else:
                response.headers['vary'] = "Origin"
    
    def _is_origin_allowed(self, origin: str) -> bool:
        """Check if origin is allowed"""
        if not origin:
            return False
        
        return '*' in self.origins or origin in self.origins