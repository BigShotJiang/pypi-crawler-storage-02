"""
WOPR Web Framework
A high-performance async web framework built on Granian's RSGI interface

WOPR combines the best features of Flask/Quart with RSGI optimization:
- Jinja2 templating with async support
- Intelligent background task system with DuckDB storage
- WebSocket support with room management
- Built-in security features
- Static file serving
- Middleware system
- CORS support
- Rate limiting
- Session management
"""

from .core.app import WOPR
from .http.request import Request
from .http.response import Response, JSONResponse, FileResponse, StreamResponse
from .http.helpers import jsonify, send_file, stream_template
from .websocket.connection import WebSocket
from .tasks.queue import TaskPriority, TaskStatus, TaskInfo
from .templates.engine import TemplateEngine

__version__ = "0.1.0"
__author__ = "War Operations Plan Response Framework Team"
__license__ = "MIT"

__all__ = [
    "WOPR",
    "Request", 
    "Response",
    "JSONResponse",
    "FileResponse", 
    "StreamResponse",
    "WebSocket",
    "TaskPriority",
    "TaskStatus", 
    "TaskInfo",
    "TemplateEngine",
    "jsonify",
    "send_file",
    "stream_template",
]