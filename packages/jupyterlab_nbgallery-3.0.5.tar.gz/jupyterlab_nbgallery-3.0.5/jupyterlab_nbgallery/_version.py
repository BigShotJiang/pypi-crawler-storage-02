version_info = (3, 0, 5)
__version__ = ".".join(map(str, version_info))
