from .FileInput import FileInput


class VideoInput(FileInput):
    type = "video-input"
