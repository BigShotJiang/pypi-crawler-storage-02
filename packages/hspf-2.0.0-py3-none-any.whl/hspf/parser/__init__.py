# -*- coding: utf-8 -*-
"""
Created on Thu Dec  9 10:42:05 2021

@author: mfratki
"""
