# lvmopstools

![Versions](https://img.shields.io/badge/python->3.10-blue)
[![Documentation Status](https://readthedocs.org/projects/lvmopstools/badge/?version=latest)](https://lvmopstools.readthedocs.io/en/latest/)
[![Test](https://github.com/sdss/lvmopstools/actions/workflows/test.yml/badge.svg)](https://github.com/sdss/lvmopstools/actions/workflows/test.yml)
[![codecov](https://codecov.io/gh/sdss/lvmopstools/graph/badge.svg?token=ipsOit5lSo)](https://codecov.io/gh/sdss/lvmopstools)

LVM tools and utilities for operations.

**Documentation:** [https://lvmopstools.readthedocs.io/en/latest/index.html](https://lvmopstools.readthedocs.io/en/latest/index.html)
