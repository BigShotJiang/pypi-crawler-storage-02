**[OptimaLab35](https://code.boxyfoxy.net/CodeByMrFinchum/OptimaLab35)** is a graphical interface for the [optima35 library](https://code.boxyfoxy.net/CodeByMrFinchum/optima35), designed for efficient image and metadata management.

Developed on my [forgejo instance](https://code.boxyfoxy.net/CodeByMrFinchum), [GitLab](https://gitlab.com/CodeByMrFinchum) is used as backup.

### **Features**
- Resize, adjust brightness/contrast, and convert images to grayscale
- Add customizable text-based watermarks
- Manage EXIF data: add, copy, remove, and adjust timestamps
- Preview image adjustments in real time
- Theme selection (light, dark, auto)
- Automatic updates via PyPI
