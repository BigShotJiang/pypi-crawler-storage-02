APPLICATION_NAME = "OptimaLab35"
CONFIG_BASE_PATH = "~/.config/OptimaLab35"
