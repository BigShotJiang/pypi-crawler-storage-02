
from setuptools import setup

setup(package_data={'nmap-stubs': ['__init__.pyi', 'nmap.pyi', 'METADATA.toml', 'py.typed']})
