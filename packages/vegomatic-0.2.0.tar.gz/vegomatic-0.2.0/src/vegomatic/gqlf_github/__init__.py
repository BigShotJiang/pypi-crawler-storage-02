#
# GqlFetch module for Github GraphQL API
#

from .gqlfetch_github import GqlFetchGithub

__all__ = ["GqlFetchGithub"]