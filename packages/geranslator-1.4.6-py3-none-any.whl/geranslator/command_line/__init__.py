from .command_line import CommandLine


def main():
    CommandLine().main()
