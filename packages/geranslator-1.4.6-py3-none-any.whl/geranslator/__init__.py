import os

os.environ["WDM_PROGRESS_BAR"] = str(0)
