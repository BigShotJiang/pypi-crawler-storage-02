from geranslator.config.samples.sample import Sample


class Symfony(Sample):
    lang_dir: str = "translations"
    lang_files_ext: str = "yaml"
