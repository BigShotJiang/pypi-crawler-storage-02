```xml
<output>
    <evaluate>{evaluate}</evaluate>
    <memory>{memory}</memory>
    <thought>{thought}</thought>
    <final_answer>{final_answer}</final_answer>
</output>
```