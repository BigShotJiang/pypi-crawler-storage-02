# Boost Histogram examples

The examples require Python 3.9. It is left as an exercise for the reader to
convert back to older versions if they so desire.

### Setup

You can run these examples in a virtual environment using:

#### Conda

```bash
conda create -p .env python=3.9 boost-histogram matplotlib numpy -c conda-forge
conda activate ./.env
```
