boost\_histogram
================

.. automodule:: boost_histogram
   :members:
   :undoc-members:
   :show-inheritance:


.. include:: boost_histogram.axis.rst


boost\_histogram.accumulators
=============================

.. automodule:: boost_histogram.accumulators
   :members:
   :undoc-members:
   :show-inheritance:

boost\_histogram.histogram
==========================

.. automodule:: boost_histogram.histogram
   :members:
   :undoc-members:
   :show-inheritance:

boost\_histogram.numpy
======================

.. automodule:: boost_histogram.numpy
   :members:
   :undoc-members:
   :show-inheritance:

boost\_histogram.storage
========================

.. automodule:: boost_histogram.storage
   :members:
   :undoc-members:
   :show-inheritance:

boost\_histogram.tag
====================

.. automodule:: boost_histogram.tag
   :members:
   :undoc-members:
   :show-inheritance:

boost\_histogram.typing
=======================

.. automodule:: boost_histogram.typing
   :members:
   :undoc-members:
   :show-inheritance:

boost\_histogram.view
=====================

.. automodule:: boost_histogram.view
   :members:
   :undoc-members:
   :show-inheritance:
