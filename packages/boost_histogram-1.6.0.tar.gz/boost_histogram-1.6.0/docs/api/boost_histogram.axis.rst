boost\_histogram.axis
=====================

.. automodule:: boost_histogram.axis
   :members:
   :undoc-members:
   :show-inheritance:


boost\_histogram.axis.transform
===============================

.. automodule:: boost_histogram.axis.transform
   :members:
   :undoc-members:
   :show-inheritance:
