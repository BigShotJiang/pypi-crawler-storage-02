"""
This module adds testing fixtures for pytest.


wrap_tmp cretaes a temp directory and moves the cwd to it,
before returning to the original dir after the test.
"""
