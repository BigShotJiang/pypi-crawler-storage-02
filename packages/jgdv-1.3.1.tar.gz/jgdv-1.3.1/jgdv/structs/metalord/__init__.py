"""
Metalord, a module for Metaclass overlords

TODO: singleton, pool


"""
