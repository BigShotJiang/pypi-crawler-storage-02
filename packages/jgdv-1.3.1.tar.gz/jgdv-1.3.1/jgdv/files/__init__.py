"""
A module is for file format readers and writers.

BookmarkCollection simplifies managing my bookmarks
TagFile is for tracking the tags I use in bibtex/bookmarks
SubFile is for correcting mispelled tags and merging tags en masse.

"""
