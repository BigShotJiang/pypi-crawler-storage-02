"""
These utils don't fit anywhere else currently.

"""
