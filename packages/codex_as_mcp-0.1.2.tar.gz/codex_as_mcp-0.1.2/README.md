# codex-as-mcp

Convert codex CLI tool to an MCP — unleash the power of GPT-5
