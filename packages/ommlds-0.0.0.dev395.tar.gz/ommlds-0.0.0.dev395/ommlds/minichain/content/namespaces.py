from omlish import lang


##


class ContentNamespace(lang.Namespace, lang.Abstract):
    pass
