"""
src/trplm/__main__.py
Description: Main entry point for the trplm tool
"""

from trplm.trpl_m import main


if __name__ == "__main__":
    main()
