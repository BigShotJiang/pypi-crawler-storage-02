# Pokédex

## Features:
- Add Pokémon
- Search Pokémon
- Remove Pokémon
- View All Pokémon
- Proper Error Handling

### Setup:
- I have created a pypi package: https://pypi.org/project/pokedex-python/0.0.1/

install it and follow this: OPEN IN A CODE EDITOR PLEASE INSTEAD OF RUNNING IN A TERMINAL

```
from pokedex_python import pokédex

pokédex.main()
``` 




