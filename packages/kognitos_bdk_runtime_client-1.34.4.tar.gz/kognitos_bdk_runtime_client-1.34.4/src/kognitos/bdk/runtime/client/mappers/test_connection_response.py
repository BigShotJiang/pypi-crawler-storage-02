from ..test_connection import TestConnectionResponse


def map_test_connection_response(
    data,  # pylint: disable=unused-argument
) -> TestConnectionResponse:
    return TestConnectionResponse()
