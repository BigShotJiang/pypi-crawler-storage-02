# SynTopic

This is a placeholder Python package for SynTopic.
It currently does nothing, but will be updated in the future.
