---
hide:
  - toc
---
# foapy.ma

The package provides a comprehensive set of functions that decompose sequence into cogeneric order and congeneric intervals.

The functions required by vector representation of characteristics and [characteristics of order that depends on congeneric intervals distribution](../characteristics/index.md) are:
