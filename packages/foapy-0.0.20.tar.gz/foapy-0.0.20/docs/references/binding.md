::: foapy.binding
    options:
        show_signature_annotations: false
        members_order: source
        show_docstring_examples: false
        show_source: false
        show_symbol_type_heading: false
        show_symbol_type_toc: false

::: foapy.binding
    options:
        show_root_heading: false
        show_docstring_description: false
        show_docstring_attributes: false
        show_root_toc_entry: false
        filters:
            - foapy.binding
