# foapy.characteristics.descriptive_information
::: foapy.characteristics.descriptive_information
