# foapy.characteristics.geometric_mean
::: foapy.characteristics.geometric_mean
