::: foapy.alphabet
