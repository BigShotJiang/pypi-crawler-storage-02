::: foapy.intervals
