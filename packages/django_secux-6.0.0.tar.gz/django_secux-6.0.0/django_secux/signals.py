from django.dispatch import Signal

attack_detected = Signal()
honeypot_trap_triggered = Signal()
