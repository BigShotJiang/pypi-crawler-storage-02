"""pychroot is a library that simplifies chroot handling"""

__title__ = 'pychroot'
__version__ = '0.10.4'

from .base import Chroot
