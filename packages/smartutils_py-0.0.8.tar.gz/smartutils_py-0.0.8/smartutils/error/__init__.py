from smartutils.error.biz import BizError
from smartutils.error.base import OK, BaseError

__all__ = ["BizError", "OK", "BaseError"]
