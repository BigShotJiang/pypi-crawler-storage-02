<h1 align="center">
  <br>PySide6Plot<br>
</h1>

-----

A PySide6-based data visualization tool.

### Special Thanks
* Initial version borrowed from [QStockPlotter](https://github.com/qiauil/QStockPlotter) by qiauil.
* Beautiful UI design inspired by [QFluentWidgets](https://qfluentwidgets.com/).