"""
widgets package for qstock_plotter
"""
