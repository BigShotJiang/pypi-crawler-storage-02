"""
Functional components for plotters.
"""
