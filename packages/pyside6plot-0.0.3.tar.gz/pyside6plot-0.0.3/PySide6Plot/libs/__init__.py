"""
Utils and helper functions for qstock_plotter
"""
