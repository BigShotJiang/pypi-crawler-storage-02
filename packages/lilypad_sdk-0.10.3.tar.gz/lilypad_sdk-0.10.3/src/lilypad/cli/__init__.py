"""The `lilypad` CLI."""
