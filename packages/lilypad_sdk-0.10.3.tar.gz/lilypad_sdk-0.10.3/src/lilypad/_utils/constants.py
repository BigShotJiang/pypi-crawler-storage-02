"""Constants for Lilypad Client"""

HOST_NAME = "mirascope.com"
BASE_URL = "https://lilypad-api.mirascope.com/v0"
REMOTE_CLIENT_URL = "https://lilypad.mirascope.com"
