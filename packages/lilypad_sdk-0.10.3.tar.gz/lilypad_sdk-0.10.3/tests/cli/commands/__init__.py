"""The module test for the CLI commands."""
