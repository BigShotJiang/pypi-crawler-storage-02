"""
edx-organizations app initialization module
"""
__version__ = '7.2.1'  # pragma: no cover
