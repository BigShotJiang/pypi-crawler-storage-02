from rpft.parsers.common.rowparser import ParserModel


class DataRowModel(ParserModel):
    ID: str = ""
