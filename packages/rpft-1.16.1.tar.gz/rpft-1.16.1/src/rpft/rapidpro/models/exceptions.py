class RapidProActionError(Exception):
    "Raised if some parameter of a RapidProAction is invalid."

    pass


class RapidProRouterError(Exception):
    "Raised if some parameter of a RapidProRouter is invalid."

    pass
