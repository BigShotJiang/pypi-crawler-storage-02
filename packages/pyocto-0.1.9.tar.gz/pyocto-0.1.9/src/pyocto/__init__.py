from . import _core as backend
from .associator import OctoAssociator, VelocityModel0D, VelocityModel1D

# Version number
__version__ = "0.1.9"
