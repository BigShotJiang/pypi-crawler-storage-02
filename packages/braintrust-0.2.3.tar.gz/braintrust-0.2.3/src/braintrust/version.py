VERSION = "0.2.3"

# this will be templated during the build
GIT_COMMIT = "b460d264e4ecde414ddb70e918a1adb48ae610b7"
