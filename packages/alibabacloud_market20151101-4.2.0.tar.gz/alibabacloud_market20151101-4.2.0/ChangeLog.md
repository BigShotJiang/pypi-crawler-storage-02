2025-02-11 Version: 4.1.0
- Support API DescribeImageInstanceForIsv.


2024-12-17 Version: 4.0.1
- Update API DescribeInstanceForIsv: update response param.


2024-12-13 Version: 4.0.0
- Update API DescribeOrderForIsv: update response param.


2024-11-26 Version: 3.1.0
- Support API DescribeInstanceForIsv.
- Support API DescribeOrderForIsv.


2024-11-26 Version: 3.0.5
- Update API DescribeInstances: update param PageNumber.
- Update API DescribeInstances: update param PageSize.


2024-07-29 Version: 3.0.4
- Update API CrossAccountVerifyToken: update response param.
- Update API DescribeApiMetering: update param type.
- Update API DescribeApiMetering: update response param.
- Update API DescribeInstance: update response param.


2023-06-20 Version: 3.0.3
- Add DistributionProducts API.

2022-03-10 Version: 3.0.2
- Remove private api.

2022-02-08 Version: 3.0.1
- CreateRate, DescribeRate add packageVersion, customerLabels column.

2022-01-17 Version: 3.0.0
- Init new DSL SDK.
- Add more language support.

