"""Internal API implementations."""
