# pyDeye

pyDeye is a Python package designed to provide interface for deye inverters using Modbus TCP gateway.

## Installation

You can install PyDeye using pip:

```bash
pip install pydeye
```