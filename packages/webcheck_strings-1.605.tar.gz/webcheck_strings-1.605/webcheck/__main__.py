import webcheck;webcheck.main()
