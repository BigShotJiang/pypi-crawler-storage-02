from .app import app

app.start()
