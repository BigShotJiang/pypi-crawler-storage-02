from .base import Base


class Girder(Base):
    """Define a base parameter type representing a Girder Id."""
