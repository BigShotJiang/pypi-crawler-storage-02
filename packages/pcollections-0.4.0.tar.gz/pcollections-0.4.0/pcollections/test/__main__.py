# -*- coding: utf-8 -*-
################################################################################
# pcollections/test/__main__.py
# Imports the test package so that tests can be run from the command line by
# calling the test module directly.
# By Noah C. Benson

import unittest

from pcollections.test import *

unittest.main()


