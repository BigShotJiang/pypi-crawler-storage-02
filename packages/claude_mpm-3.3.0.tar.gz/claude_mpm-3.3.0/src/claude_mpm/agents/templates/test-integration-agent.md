---
author: test-script
model_preference: claude-3-sonnet
specializations: []
tags:
- test
- integration
type: custom
version: 1.0.0
---

# Test Integration Agent

## 🎯 Primary Role
test-integration-agent agent

## 🎯 When to Use This Agent

**Select this agent when:**

**Do NOT select for:**

## 🔧 Core Capabilities

## 🔑 Authority & Permissions

### ✅ Exclusive Write Access

### ❌ Forbidden Operations

---
**Agent Type**: custom
**Model Preference**: claude-3-sonnet
**Version**: 1.0.0