from .core import WILDCARD, TypeMatch, WizeDispatcher, dispatch

__all__ = [
    "WizeDispatcher",
    "TypeMatch",
    "dispatch",
    "WILDCARD",
]
