"""Initialize Settings module."""

from .public import SettingsImpl
