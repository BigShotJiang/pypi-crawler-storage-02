# Reference

## IntelliFire4PY

```{eval-rst}
.. automodule:: intellifire4py

```

## IntelliFireAPILocal

```{eval-rst}
.. autoclass:: IntelliFireAPILocal
   :members:
   :inherited-members:

```

## IntelliFireAPICloud

```{eval-rst}
.. autoclass:: IntelliFireAPICloud
   :members:
   :inherited-members:
```

## IntelliFireErrorCode

```{eval-rst}
.. autoclass:: IntelliFireErrorCode
```
