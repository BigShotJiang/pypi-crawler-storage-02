"""Test suite for the intellifire4py package."""
