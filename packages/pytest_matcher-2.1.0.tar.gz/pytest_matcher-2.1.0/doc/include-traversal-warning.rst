.. SPDX-FileCopyrightText: 2017-now, See ``CONTRIBUTORS.lst``
.. SPDX-License-Identifier: CC0-1.0

.. attention::

    Directory traversal is not allowed for path parameters and paths must be relative.
    They are evaluated relative to the ``rootdir`` determined_ by ``pytest``.

.. _determined: https://docs.pytest.org/en/latest/reference/customize.html#initialization-determining-rootdir-and-configfile
