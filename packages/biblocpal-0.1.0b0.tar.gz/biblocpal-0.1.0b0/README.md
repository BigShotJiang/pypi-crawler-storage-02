# Biblocpal

Biblocpal es una biblioteca en desarrollo que proporciona:
- Palabras con significados.
- Respuestas prefijas.
- Razonamiento básico.

Versión: `0.1.0b0` (beta inicial).
