from .core import Biblocpal

__version__ = "0.1.0b0"
__all__ = ["Biblocpal"]
