from typing import final


@final
class StateOverrideNotSupported(Exception):
    pass
