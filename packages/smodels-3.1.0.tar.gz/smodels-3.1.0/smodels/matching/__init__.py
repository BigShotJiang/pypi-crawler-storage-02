"""
.. module:: matcher.__init__
   :synopsis: This Package is intended to contain everything related to matching decomposition SMS to the database
   
"""
