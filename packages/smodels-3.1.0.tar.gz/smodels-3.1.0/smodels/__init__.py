from .installation import version

__version__ = version()
