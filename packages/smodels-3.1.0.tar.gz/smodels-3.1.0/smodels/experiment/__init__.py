"""
.. module:: experiment.__init__
   :synopsis: This package is intended to contain everything that has to do
              with the experimental results.


"""
