"""
.. module:: statistics.__init__
    :synopsis: This package contains tools for statistical calculations
"""

