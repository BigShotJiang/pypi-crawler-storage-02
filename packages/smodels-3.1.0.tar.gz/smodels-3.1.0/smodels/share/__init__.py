"""
.. module:: share.__init__
   :synopsis: This package is intended to contain additional modules.
"""
