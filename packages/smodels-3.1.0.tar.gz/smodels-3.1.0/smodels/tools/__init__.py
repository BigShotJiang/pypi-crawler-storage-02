"""
.. module:: tools.__init__
    :synopsis: This package contains tools for handling results obtained with the
       main SModelS code.
"""

