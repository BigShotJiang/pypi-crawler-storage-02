"""
.. module:: tools.printers.__init__
    :synopsis: This package contains tools for handling printers
"""

