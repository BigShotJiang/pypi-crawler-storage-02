
                               =========
                                SModelS
                               =========


Installation
============

For installing SModelS and its dependencies, please see the
SModelS Installation section in the online manual: ::

http://smodels.readthedocs.io/en/latest/Installation.html

