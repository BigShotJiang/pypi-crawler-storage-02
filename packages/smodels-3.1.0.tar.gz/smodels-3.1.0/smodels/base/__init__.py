"""
.. module:: base.__init__
   :synopsis: This Package is intended to contain base classes and methods used by other packages.
"""
