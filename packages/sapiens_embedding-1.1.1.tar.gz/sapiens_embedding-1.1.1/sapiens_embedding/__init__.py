# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .sapiens_embedding import *
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
