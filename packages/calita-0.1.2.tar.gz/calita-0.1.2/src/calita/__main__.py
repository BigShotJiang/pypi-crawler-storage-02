from calita.run_app import main

main()