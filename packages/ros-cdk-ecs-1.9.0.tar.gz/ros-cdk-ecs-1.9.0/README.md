## Aliyun ROS ECS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as ECS from '@alicloud/ros-cdk-ecs';
```
