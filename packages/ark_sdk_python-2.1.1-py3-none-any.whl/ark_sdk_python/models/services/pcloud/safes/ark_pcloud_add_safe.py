from ark_sdk_python.models.services.pcloud.safes.ark_pcloud_safe import ArkPCloudBaseSafe


class ArkPCloudAddSafe(ArkPCloudBaseSafe):
    pass
