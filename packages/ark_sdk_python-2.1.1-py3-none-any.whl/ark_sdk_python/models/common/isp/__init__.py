from ark_sdk_python.models.common.isp.ark_platform_discovery_schemas import IdentityEndpointResponse

__all__ = ['IdentityEndpointResponse']
