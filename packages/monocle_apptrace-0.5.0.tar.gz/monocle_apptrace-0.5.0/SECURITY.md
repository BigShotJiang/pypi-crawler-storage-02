# Security Policy

## Supported Versions

Please upgrade to latest stable version of Monocle which will have know security issues addressed.

## Reporting a Vulnerability

Please report security vulnerabilities privately to the Monocle [maintainer team] (https://github.com/monocle2ai/monocle/blob/main/MAINTAINER.md). Please do not post security vulnerabilities to the public issue tracker.
