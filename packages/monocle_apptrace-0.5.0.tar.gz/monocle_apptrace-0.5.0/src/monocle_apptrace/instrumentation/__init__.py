from .common import *
from .metamodel.azfunc.wrapper import monocle_trace_azure_function_route