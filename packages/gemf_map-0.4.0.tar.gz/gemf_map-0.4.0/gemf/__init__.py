"""
A Python package for the GEMF map format.
"""

from .gemf import GEMF