# __init__.py

from .TiktokService import TiktokService
