def hardware_id() -> str:
    """Retrieve the hardware id."""
    pass


def power_off() -> int:
    """Turns off the hub."""
    pass


def temperature() -> int:
    """Retrieve the hub temperature. Measured in decidegrees celsius (d°C) which is 1 / 10 of a degree celsius (°C)"""
    pass
