"The app module is used communicate between hub and app"

raise NotImplementedError(f"The {__package__} module is not implemented on Spike")