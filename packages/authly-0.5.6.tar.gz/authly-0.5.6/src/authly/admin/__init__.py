"""Authly Admin Interface Package.

This package provides command-line administrative tools for managing OAuth 2.1 clients and scopes.
"""

__all__ = ["cli"]
