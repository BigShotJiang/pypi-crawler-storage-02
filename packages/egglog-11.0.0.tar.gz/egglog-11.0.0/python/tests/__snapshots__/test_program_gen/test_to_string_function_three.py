def my_fn(x, y, z):
    _0 = -x
    assert _0 > 0
    _1 = _0 + y
    _2 = _1 + z
    _3 = _2 + 2
    _4 = _3 + _2
    return _4
