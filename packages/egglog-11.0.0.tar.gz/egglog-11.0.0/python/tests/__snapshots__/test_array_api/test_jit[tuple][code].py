def __fn(x, y):
    return x[(x.shape + (1, 2, ))[100]]
