"""
Examples using egglog.
"""
