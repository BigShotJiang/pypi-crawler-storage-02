from .get_resolve import GetResolve

__version__ = "0.1.0"
__release_date__ = "2025-08-14"
__author__ = "Yuu"
