---
title: Components
order: 8
description: Pre-build components to compose custom dashboard area in admin.
---
