---
title: Decorators
order: 8
description: Decorators to display fields in list view and change form.
---
