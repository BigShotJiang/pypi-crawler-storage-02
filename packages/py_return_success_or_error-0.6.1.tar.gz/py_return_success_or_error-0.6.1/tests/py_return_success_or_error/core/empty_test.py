from py_return_success_or_error import EMPTY


def testeInstanciaEmpity():
    result = EMPTY
    assert str(result) == "Empty"
