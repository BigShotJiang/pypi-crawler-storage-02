#!/usr/bin/env python

"""Tests for `hypercoast` package."""


import unittest

import hypercoast


class TestHypercoast(unittest.TestCase):
    """Tests for `hypercoast` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
