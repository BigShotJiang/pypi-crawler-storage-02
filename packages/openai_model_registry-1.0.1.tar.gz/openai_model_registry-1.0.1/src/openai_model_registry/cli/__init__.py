"""OpenAI Model Registry CLI package."""

from .app import app

__all__ = ["app"]
