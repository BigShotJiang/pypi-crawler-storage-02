def startswith(text: str, prefix: str) -> bool:
    """
    Return :data:`True` when the provided text starts with the given prefix.
    """
    return text.startswith(prefix)
