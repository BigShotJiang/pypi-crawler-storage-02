from .email_address import GetEmailResult, GetEmailTask

__all__ = ["GetEmailTask", "GetEmailResult"]
