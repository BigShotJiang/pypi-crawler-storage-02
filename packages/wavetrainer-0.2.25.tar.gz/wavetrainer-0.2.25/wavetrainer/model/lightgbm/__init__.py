"""The wavetrain lightgbm model module."""
