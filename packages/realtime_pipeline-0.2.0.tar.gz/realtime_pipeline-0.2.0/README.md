Realtime Pipeline
=================

This project aims to assist building pipelined programs to process the newest data. Intended to be as realtime as possible.

Documentation is on the way!