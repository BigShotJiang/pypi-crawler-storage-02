# CHANGELOG


## v0.2.0 (2025-08-04)

### Continuous Integration

- Solve upload to codecov
  ([`bd99f59`](https://github.com/flitzpiepe93/logstructor/commit/bd99f59bcb8b502b427873d95fb7e33b93696566))

- Solve upload to codecov
  ([`c117aeb`](https://github.com/flitzpiepe93/logstructor/commit/c117aebda93676638be945273a660121a2301d18))

### Documentation

- Add first version of README
  ([`a8af9bf`](https://github.com/flitzpiepe93/logstructor/commit/a8af9bfde758c67bf6745084af6bd2a55daf9612))

- Add first version of README
  ([`25a6048`](https://github.com/flitzpiepe93/logstructor/commit/25a604861456f72c3d9cbbb9546a708cf0a2824c))

- Add first version of README
  ([`ceeb5a8`](https://github.com/flitzpiepe93/logstructor/commit/ceeb5a8824eef1295ab7843821d362459423a655))

### Features

- Finalize first basis version ([#1](https://github.com/flitzpiepe93/logstructor/pull/1),
  [`5d55333`](https://github.com/flitzpiepe93/logstructor/commit/5d5533356d104b85b023b46fe923c7a2ba39e866))


## v0.1.0 (2025-08-03)

### Continuous Integration

- Add github action workflow
  ([`f10f88f`](https://github.com/flitzpiepe93/logstructor/commit/f10f88fe1cce5abe6c67a59b968ecfc84e2e1fed))

- Update unit tests job
  ([`376ce2e`](https://github.com/flitzpiepe93/logstructor/commit/376ce2e077fc248fd716863f9fe604c1a23e9036))

### Features

- Add first basis version of framework
  ([`daf3b44`](https://github.com/flitzpiepe93/logstructor/commit/daf3b442835a210af4fad3d2b16260f39aa88475))
