from typing import Literal
from typing_extensions import ParamSpec

TTransformationFunParams = ParamSpec("TTransformationFunParams")
