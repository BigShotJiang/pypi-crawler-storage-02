"""
Tests for Git storage backend.
"""