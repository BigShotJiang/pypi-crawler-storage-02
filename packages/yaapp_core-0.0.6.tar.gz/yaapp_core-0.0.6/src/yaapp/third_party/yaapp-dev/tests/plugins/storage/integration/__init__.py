"""
yaapp Integration Tests for Storage Plugin

Tests that the storage plugin integrates correctly with yaapp framework
through @app.expose decorator and works via all yaapp interfaces.
"""