# YAPP - Yet Another Python Package
# A library bridging FastAPI and CLI interfaces

from .yapp import YApp

__version__ = "0.1.0"
__all__ = ["YApp"]
