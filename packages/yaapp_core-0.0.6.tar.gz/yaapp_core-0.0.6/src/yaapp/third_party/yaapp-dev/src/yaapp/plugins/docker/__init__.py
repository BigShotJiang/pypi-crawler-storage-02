"""
Docker plugin for yaapp framework.
Provides Docker container and image management capabilities.
"""