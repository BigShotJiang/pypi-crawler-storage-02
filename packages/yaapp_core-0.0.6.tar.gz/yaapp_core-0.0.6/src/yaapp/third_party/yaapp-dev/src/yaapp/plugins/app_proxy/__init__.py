"""
AppProxy plugin for YAPP - enables app-to-app chaining.
"""