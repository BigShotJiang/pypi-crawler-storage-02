"""
Remote process plugin for yaapp.
"""