"""
Auth plugin for yaapp - provides authentication and authorization services.
"""