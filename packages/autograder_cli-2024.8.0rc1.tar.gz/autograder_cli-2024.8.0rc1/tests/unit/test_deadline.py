# deadline & cutoff string formats
