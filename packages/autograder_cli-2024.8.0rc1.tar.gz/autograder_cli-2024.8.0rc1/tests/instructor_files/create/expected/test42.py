print("test 42")
