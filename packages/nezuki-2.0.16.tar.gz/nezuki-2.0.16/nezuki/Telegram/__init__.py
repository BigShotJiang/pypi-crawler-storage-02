from .Telegram import Telegram

__all__ = ['Telegram']
