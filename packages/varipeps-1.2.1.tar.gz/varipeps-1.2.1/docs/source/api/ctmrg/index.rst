.. _varipeps_ctmrg:

.. py:module:: varipeps.ctmrg

.. currentmodule:: varipeps.ctmrg

CTMRG method (:mod:`varipeps.ctmrg`)
====================================

.. toctree::
   :maxdepth: 2

   absorption
   projectors
   routine

.. automodule:: varipeps.ctmrg
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
