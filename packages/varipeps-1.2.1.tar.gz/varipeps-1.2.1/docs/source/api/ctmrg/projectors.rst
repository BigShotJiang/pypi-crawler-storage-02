.. _varipeps_ctmrg_projectors:

.. module:: varipeps.ctmrg.projectors

.. currentmodule:: varipeps.ctmrg.projectors

Calculation of CTMRG projectors (:mod:`varipeps.ctmrg.projectors`)
==================================================================

.. automodule:: varipeps.ctmrg.projectors
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
