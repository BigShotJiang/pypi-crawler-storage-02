.. _varipeps_ctmrg_absorption:

.. module:: varipeps.ctmrg.absorption

.. currentmodule:: varipeps.ctmrg.absorption

Calculate the new CTMRG tensors for a single step (:mod:`varipeps.ctmrg.absorption`)
====================================================================================

.. automodule:: varipeps.ctmrg.absorption
   :members:
   :show-inheritance:
   :noindex:
