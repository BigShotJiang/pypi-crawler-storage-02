.. _varipeps_expectation_one_site:

.. currentmodule:: varipeps.expectation.one_site

Calculation of one site expectation values
==========================================

.. automodule:: varipeps.expectation.one_site
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
