.. _varipeps_expectation_three_sites:

.. currentmodule:: varipeps.expectation.three_sites

Calculation of three sites expectation values
=============================================

.. automodule:: varipeps.expectation.three_sites
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
