.. _varipeps_contractions_apply:

.. currentmodule:: varipeps.contractions

Apply a contraction (:func:`varipeps.contractions.apply_contraction`)
=====================================================================

.. autofunction:: apply_contraction
