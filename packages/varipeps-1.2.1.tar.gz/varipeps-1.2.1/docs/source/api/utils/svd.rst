.. _varipeps_utils_svd:

.. currentmodule:: varipeps.utils.svd

SVD helpers (:mod:`varipeps.utils.svd`)
=======================================

.. automodule:: varipeps.utils.svd
   :members:
   :undoc-members:
   :show-inheritance:
