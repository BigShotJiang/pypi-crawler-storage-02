.. _varipeps_config:

.. currentmodule:: varipeps.config

Config of variPEPS module (:mod:`varipeps.config`)
==================================================

.. automodule:: varipeps.config
   :members:
   :show-inheritance:
