.. _varipeps_peps_unit_cell:

.. currentmodule:: varipeps.peps

PEPS Unit cell (:class:`varipeps.peps.PEPS_Unit_Cell`)
======================================================

.. autoclass:: PEPS_Unit_Cell
   :members:
   :undoc-members:
   :special-members: __getitem__
   :show-inheritance:
