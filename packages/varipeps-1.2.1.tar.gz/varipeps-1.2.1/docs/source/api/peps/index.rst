.. _varipeps_peps:

.. py:module:: varipeps.peps

.. currentmodule:: varipeps.peps

Implementation of PEPS structure (:mod:`varipeps.peps`)
=======================================================

.. toctree::
   :maxdepth: 2

   tensor
   unitcell
