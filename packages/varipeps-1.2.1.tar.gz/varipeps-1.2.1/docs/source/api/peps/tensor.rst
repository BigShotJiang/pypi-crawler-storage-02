.. _varipeps_peps_tensor:

.. currentmodule:: varipeps.peps

Single PEPS tensor (:class:`varipeps.peps.PEPS_Tensor`)
=======================================================

.. autoclass:: PEPS_Tensor
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __add__
