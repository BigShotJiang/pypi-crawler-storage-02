.. _varipeps_mapping_square_kagome:

.. currentmodule:: varipeps.mapping.square_kagome

Mapping of Square-Kagome structures (:mod:`varipeps.mapping.square_kagome`)
===========================================================================

.. automodule:: varipeps.mapping.square_kagome
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
