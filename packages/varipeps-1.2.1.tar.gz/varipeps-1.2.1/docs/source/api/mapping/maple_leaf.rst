.. _varipeps_mapping_maple_leaf:

.. currentmodule:: varipeps.mapping.maple_leaf

Mapping of Maple leaf structures (:mod:`varipeps.mapping.maple_leaf`)
=====================================================================

.. automodule:: varipeps.mapping.maple_leaf
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
