.. _varipeps_mapping_honeycomb:

.. currentmodule:: varipeps.mapping.honeycomb

Mapping of Honeycomb structures (:mod:`varipeps.mapping.honeycomb`)
===================================================================

.. automodule:: varipeps.mapping.honeycomb
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
