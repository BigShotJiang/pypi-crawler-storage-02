.. _varipeps_mapping_triangular:

.. currentmodule:: varipeps.mapping.triangular

Mapping of Triangular structures (:mod:`varipeps.mapping.triangular`)
=====================================================================

.. automodule:: varipeps.mapping.triangular
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
