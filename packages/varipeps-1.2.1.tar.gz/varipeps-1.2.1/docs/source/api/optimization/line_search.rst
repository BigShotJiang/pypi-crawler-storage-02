.. _varipeps_optimization_line_search:

.. currentmodule:: varipeps.optimization.line_search

Implementation of line search methods for the CTMRG variational optimization (:mod:`varipeps.optimization.line_search`)
=======================================================================================================================

.. automodule:: varipeps.optimization.line_search
   :members:
   :undoc-members:
   :show-inheritance:
