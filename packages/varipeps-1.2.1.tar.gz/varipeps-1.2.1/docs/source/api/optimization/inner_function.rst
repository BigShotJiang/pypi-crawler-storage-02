.. _varipeps_optimization_inner_function:

.. currentmodule:: varipeps.optimization.inner_function

Methods to calculate the CTRMG env and expectation value along with the gradient (:mod:`varipeps.optimization.inner_function`)
==============================================================================================================================

.. automodule:: varipeps.optimization.inner_function
   :members:
   :undoc-members:
   :show-inheritance:
