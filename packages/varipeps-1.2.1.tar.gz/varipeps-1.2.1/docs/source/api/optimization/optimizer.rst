.. _varipeps_optimization_optimizer:

.. currentmodule:: varipeps.optimization.optimizer

Implementation of the variational optimizer for the PEPS model (:mod:`varipeps.optimization.optimizer`)
=======================================================================================================

.. automodule:: varipeps.optimization.optimizer
   :members:
   :undoc-members:
   :show-inheritance:
