.. _varipeps_optimization_basinhopping:

.. currentmodule:: varipeps.optimization.basinhopping

Implementation of the basinhopping optimizer for the PEPS model (:mod:`varipeps.optimization.basinhopping`)
===========================================================================================================

.. automodule:: varipeps.optimization.basinhopping
   :members:
   :undoc-members:
   :show-inheritance:
