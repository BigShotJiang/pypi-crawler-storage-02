.. plumed-bench-pp documentation master file, created by
   sphinx-quickstart on Tue Jul 23 10:02:58 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../../README.md
    :parser: myst_parser.sphinx_


.. toctree::
   :maxdepth: 2
   :caption: Contents:
   

   documentation
