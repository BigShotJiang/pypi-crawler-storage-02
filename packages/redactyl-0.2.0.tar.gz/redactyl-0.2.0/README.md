# Redactyl

Type-safe, reversible PII protection for LLM apps — now centered around the `@pii.protect` decorator.

Redactyl replaces sensitive values with stable tokens (for example: `[EMAIL_1]`, `[NAME_FIRST_1]`) before your code talks to an LLM, and restores originals when results come back. It works across Pydantic models, nested containers, sync/async functions, and streams — automatically.

Warning: You need a spaCy model installed (see Installation). Optional GLiNER improves name component detection.

## Why Redactyl?

- ✅ Zero trust to LLMs: Never expose real PII
- ✅ Type-safe: Full Pydantic integration and container traversal
- ✅ Reversible: Get original data back every time
- ✅ Streaming-ready: Works with sync/async generators
- ✅ Intelligent: Understands name relationships and components

### Quickstart (Plain String)

Use `@pii.protect` on ordinary functions too — no Pydantic required.

```python
from redactyl.pydantic_integration import PIIConfig

pii = PIIConfig()

@pii.protect
def summarize(text: str) -> str:
    # Inside: text is redacted (e.g., emails → [EMAIL_1])
    return f"Processed: {text}"

print(summarize("Email me at john@example.com"))
# → "Processed: Email me at john@example.com" (restored on return)
```

## The `@pii.protect` Moment

Drop a decorator and keep coding. Redactyl figures it out.

```python
from typing import Annotated
from pydantic import BaseModel
from redactyl.pydantic_integration import PIIConfig, pii_field
from redactyl.types import PIIType

# Zero-config to start; tuned via PIIConfig kwargs
pii = PIIConfig()

class Email(BaseModel):
    sender_name: Annotated[str, pii_field(PIIType.PERSON, parse_components=True)]
    sender_email: Annotated[str, pii_field(PIIType.EMAIL)]
    subject: str  # auto-detected
    body: str     # auto-detected

@pii.protect
async def draft_reply(email: Email) -> str:
    # Inside: email fields are redacted, e.g.
    #   "John Smith <john@example.com>" → "[NAME_FIRST_1] [NAME_LAST_1] <[EMAIL_1]>"
    # Call your LLM as usual — it will see tokens
    reply = await llm.generate({
        "subject": f"Re: {email.subject}",
        "body": f"Hi {email.sender_name}, …"
    })
    # Return values are automatically unredacted
    return reply

# What you get back has real PII restored
text = await draft_reply(Email(
    sender_name="John Smith",
    sender_email="john@example.com",
    subject="Project X",
    body="Ping me tomorrow"
))
print(text)  # → "Hi John, … I'll email john@example.com"
```

Why this feels essential:
- Minimal change: add a decorator; keep your LLM calls.
- Smart defaults: auto-detects sync/async/generator functions and Pydantic arguments.
- Reversible: tokens round-trip perfectly; originals are restored for outputs.

Name intelligence:
- Full names become the source of truth. Later mentions like "John", "Mr. Appleseed", or just "Appleseed" reuse the same token index.
- Example: "John Appleseed … Appleseed" → "[NAME_FIRST_1] [NAME_LAST_1] … [NAME_LAST_1]".

## Progressive Examples

### 1) Basics: Functions and Models

```python
from pydantic import BaseModel
from typing import Annotated
from redactyl.pydantic_integration import PIIConfig, pii_field
from redactyl.types import PIIType

pii = PIIConfig()

class Message(BaseModel):
    user: Annotated[str, pii_field(PIIType.PERSON, parse_components=True)]
    email: Annotated[str, pii_field(PIIType.EMAIL)]
    text: str  # auto-detected

@pii.protect
def handle(msg: Message) -> str:
    # msg is redacted here: "Jane <jane@x.com>" → tokens
    return llm.call(msg.model_dump())  # LLM works with tokens

result = handle(Message(user="Jane Roe", email="jane@x.com", text="Hello"))
print(result)  # Unredacted output
```

### 2) Streaming: Accumulate State Automatically

Redactyl keeps a running redaction state across stream yields and surfaces it when the stream ends.

```python
from collections.abc import AsyncIterator
from pydantic import BaseModel

class In(BaseModel):
    content: str

class Out(BaseModel):
    content: str

captured_state = None
pii = PIIConfig(on_stream_complete=lambda st: globals().update(captured_state=st))

@pii.protect
async def chat_stream(message: In) -> AsyncIterator[Out]:
    # message.content is redacted here
    async for chunk in llm.stream(message.content):
        # Each yielded model is protected before it leaves the function
        yield Out(content=chunk)

# Consume the stream as usual (receives protected chunks)
async for part in chat_stream(In(content="Email me at john@example.com")):
    send_to_client(part)  # shows tokens like [EMAIL_1]

# After the stream finishes, captured_state holds the RedactionState
# Later: unredact any persisted transcript with that state
from redactyl.core import PIILoop
original, _ = PIILoop(pii.detector).unredact("I'll email [EMAIL_1]", captured_state)
```

Notes:
- Works with async generators and sync generators alike.
- The `on_stream_complete` callback gives you the accumulated `RedactionState` to persist.

### 3) Containers: Lists, Dicts, Sets, Tuples, Frozensets

No special casing required — Redactyl traverses common containers in both inputs and return values.

```python
from typing import Any
from pydantic import BaseModel

class Profile(BaseModel):
    name: str
    email: str

pii = PIIConfig()  # traverse_containers=True by default

@pii.protect
def analyze(batch: list[Profile] | dict[str, Any] | set[str]) -> dict[str, Any]:
    # All nested strings/models are protected here
    # You can safely pass "batch" to your LLM/tooling
    summary = llm.summarize(batch)
    # Return values (including containers) are unredacted on the way out
    return {"summary": summary}

out = analyze([
    Profile(name="Ada Lovelace", email="ada@example.com"),
    Profile(name="Alan Turing", email="alan@example.com"),
])
print(out["summary"])  # contains real names/emails again
```

## Install

```bash
pip install redactyl

# Optional: better name component detection
pip install "redactyl[gliner]"

# Required spaCy model
python -m spacy download en_core_web_sm
```

## Why Tokens (Not Fake Data)?

- LLMs preserve structured placeholders like `[EMAIL_1]` exactly.
- We track name components intelligently so short mentions like "John" map back to the same person as "John Smith".
- Every token is perfectly reversible — outputs come back with originals.

## Pydantic-Friendly API Surface

- `@pii.protect`: Auto-protects Pydantic `BaseModel` args, traverses containers, and unprotects returns.
- Function modes: Detects sync, async, generator, and async-generator transparently.
- `pii_field(...)`: Annotate fields for explicit types or to disable detection per-field.
- Callbacks: `on_detection`, `on_hallucination`, `on_gliner_unavailable`, `on_batch_error`, `on_unredaction_issue`, `on_gliner_model_error`.
- Streaming: `on_stream_complete(state)` provides the accumulated `RedactionState` after all yields.

## v0.2.0 Highlights

- Containers: Deep traversal for `list`, `dict`, `set`, `tuple`, and `frozenset` (both inputs and returns).
- Streaming persistence: `on_stream_complete` surfaces the final `RedactionState` after generator completion.
- Name components: Full-name phrases establish the source of truth; partials reuse the same index.
- Smarter decorator: Auto-detects async/sync, generator/async-generator; protects models; unprotects returns.
- Quality: 100% test pass rate (206/206 tests).

## Configuration Cheatsheet

```python
from redactyl.pydantic_integration import HallucinationResponse

pii = PIIConfig(
    batch_detection=True,        # speed + consistent numbering across fields
    use_name_parsing=True,       # parse title/first/middle/last when available
    fuzzy_unredaction=False,     # allow fuzzy matches on restore
    traverse_containers=True,    # enable container traversal
    on_detection=lambda es: log.info("%d entities", len(es)),
    on_hallucination=lambda issues: [
        # replace hallucinated emails; preserve others
        HallucinationResponse.replace("[REDACTED]") if "EMAIL" in i.token else HallucinationResponse.preserve()
        for i in issues
    ],
)
```

### Common customizations

```python
# Custom detector
pii = PIIConfig(detector=MyCustomDetector())

# Batch processing for consistency and speed
pii = PIIConfig(batch_detection=True)

# Handle hallucinations
from redactyl.pydantic_integration import HallucinationResponse
def handle_llm_mistakes(issues):
    return [
        HallucinationResponse.replace("[REDACTED]") if "EMAIL" in i.token else HallucinationResponse.preserve()
        for i in issues
    ]
pii = PIIConfig(on_hallucination=handle_llm_mistakes)
```

Field-level control with `pii_field`:

```python
class User(BaseModel):
    # force detection as a PERSON and parse components
    name: Annotated[str, pii_field(PIIType.PERSON, parse_components=True)]
    # mark as email explicitly
    email: Annotated[str, pii_field(PIIType.EMAIL)]
    # or disable detection for a field
    notes: Annotated[str, pii_field(detect=False)]
```

## Development

```bash
uv python pin 3.12
uv pip install -e .[dev]
uv run python -m spacy download en_core_web_sm

uv run ruff check --fix && uv run ruff format
uv run pyright src/
uv run pytest -q
```

## License

MIT — see LICENSE.

See CHANGELOG.md for release notes.
