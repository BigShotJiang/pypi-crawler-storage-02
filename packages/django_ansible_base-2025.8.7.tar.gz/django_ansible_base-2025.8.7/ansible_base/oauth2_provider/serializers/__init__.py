from .application import OAuth2ApplicationSerializer  # noqa: F401
from .token import OAuth2TokenSerializer  # noqa: F401
