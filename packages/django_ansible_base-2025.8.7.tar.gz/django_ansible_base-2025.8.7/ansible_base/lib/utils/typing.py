from typing import Union

from django.utils.functional import Promise

TranslatedString = Union[str, Promise]
