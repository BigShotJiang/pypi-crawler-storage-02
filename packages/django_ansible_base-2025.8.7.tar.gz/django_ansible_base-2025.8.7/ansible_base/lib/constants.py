STATUS_GOOD = 'good'
STATUS_FAILED = 'failed'
STATUS_DEGRADED = 'degraded'
