from setuptools import setup, find_packages

setup(
    name="myhsisuseeid",
    version="0.1.1",
    packages=find_packages(),
    description="مكتبة بايثون بسيطة تجريبية باسم myhsisuseeid",
    author="اسمك هنا",
    author_email="youremail@example.com",
    python_requires='>=3.6',
)
