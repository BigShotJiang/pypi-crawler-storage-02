def greet(name):
    return f"مرحبا يا {name}!"

def add_numbers(a, b):
    return a + b
