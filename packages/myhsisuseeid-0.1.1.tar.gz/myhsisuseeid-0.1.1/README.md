# myhsisuseeid

مكتبة بايثون بسيطة تجريبية باسم **myhsisuseeid**.

## الوصف

تحتوي هذه المكتبة على دوال بسيطة مثل الترحيب بجملة ودالة لجمع رقمين.

## الاستخدام

```python
from myhsisuseeid import greet, add_numbers

print(greet("علي"))         # يطبع: مرحبا يا علي!
print(add_numbers(5, 7))    # يطبع: 12
