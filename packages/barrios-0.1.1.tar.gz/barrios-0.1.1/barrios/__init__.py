from .main import *
"""
This is a personal package that serves several purposes, especially in Chile.
"""