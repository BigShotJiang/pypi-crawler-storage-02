// Shim for extensions/core/load3d/PreviewManager.ts
export const PreviewManager = window.comfyAPI.PreviewManager.PreviewManager;
