// Shim for scripts/metadata/svg.ts
export const getSvgMetadata = window.comfyAPI.svg.getSvgMetadata;
