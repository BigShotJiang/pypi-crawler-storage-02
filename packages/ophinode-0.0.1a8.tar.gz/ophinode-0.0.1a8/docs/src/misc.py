PATH_PREFIX = ""

def get_href(path):
    return PATH_PREFIX + path
