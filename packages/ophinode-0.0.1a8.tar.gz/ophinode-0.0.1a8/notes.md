1. Devise some way to distinguish options that are not set in order to respect page group options.
2. finish create_subcontext()
