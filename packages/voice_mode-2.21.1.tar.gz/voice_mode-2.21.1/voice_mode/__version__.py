# This file is automatically updated by 'make release'
# Do not edit manually
__version__ = "2.21.1"
