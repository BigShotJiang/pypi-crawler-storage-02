"""A Python client for fetching artist lyrical discographies."""

from .client import Melodic

__all__ = ["Melodic"]
