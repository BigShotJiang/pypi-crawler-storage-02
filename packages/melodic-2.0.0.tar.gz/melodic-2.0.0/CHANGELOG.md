# Changelog

All notable changes to **melodic** will be documented in this file.

## v1.10.1 (2025-08-08)

### Fixed

- typo in model docstring

## v1.10.0 (2025-08-08)

### Added

- add custom project exceptions
- add project constants
- add main client with async enter/exit & workflow stub
- add project init with public api section
- add music model representations
