from enum import Enum


class Platform(Enum):
    SevenEleven = "seven_eleven"
    FamilyMart = "family_mart"
    OKMart = "ok_mart"
    Shopee = "shopee"
