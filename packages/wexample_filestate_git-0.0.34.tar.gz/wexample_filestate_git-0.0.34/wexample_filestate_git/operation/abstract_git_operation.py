from __future__ import annotations

from abc import ABC
from wexample_filestate.operation.abstract_operation import AbstractOperation


class AbstractGitOperation(AbstractOperation, ABC):
    pass
