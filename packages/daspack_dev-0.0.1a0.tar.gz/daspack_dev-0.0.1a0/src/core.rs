pub mod prediction;
pub mod lpctool;
pub mod wavelets;
pub mod entropy;