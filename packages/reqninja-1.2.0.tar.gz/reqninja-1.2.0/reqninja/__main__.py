"""Entry point for running ReqNinja as a module."""

from reqninja.cli import main

if __name__ == "__main__":
    main()
