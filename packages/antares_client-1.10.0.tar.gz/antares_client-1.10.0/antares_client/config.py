config = {
    "ANTARES_API_BASE_URL": "https://api.antares.noirlab.edu/v1/",
    "API_TIMEOUT": 60,
}
