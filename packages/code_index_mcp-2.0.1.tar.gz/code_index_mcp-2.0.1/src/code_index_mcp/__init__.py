"""Code Index MCP package.

A Model Context Protocol server for code indexing, searching, and analysis.
"""

__version__ = "2.0.1"
