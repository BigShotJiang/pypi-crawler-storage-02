=============
General Scans
=============

.. autofunction:: hxrsnd.plans.scans.linear_scan

.. autofunction:: hxrsnd.plans.scans.centroid_scan
