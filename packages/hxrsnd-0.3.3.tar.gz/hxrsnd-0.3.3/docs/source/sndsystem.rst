======================
Split and Delay System
======================

The main object that is interacted with in the ``IPython`` shell is the ``snd``
object.

.. autosummary::

     ~sndsystem.SplitAndDelay
