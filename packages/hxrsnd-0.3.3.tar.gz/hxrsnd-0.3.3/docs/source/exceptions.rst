==========
Exceptions
==========

.. autoclass:: hxrsnd.exceptions.SndException

.. autoclass:: hxrsnd.exceptions.MotorDisabled

.. autoclass:: hxrsnd.exceptions.MotorFaulted

.. autoclass:: hxrsnd.exceptions.MotorError

.. autoclass:: hxrsnd.exceptions.BadN2Pressure
