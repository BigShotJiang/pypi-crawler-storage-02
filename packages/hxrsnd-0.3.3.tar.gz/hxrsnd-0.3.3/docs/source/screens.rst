EDM Screens
===========

System
------

Within the ``HXRSnD`` package there is a system level EDM screen that shows all
the aerotech and attocube motors, as well as the pneumatics of the system and
each of the delay towers.

To launch the screen from the ``HXRSnD`` directory: ::

  $ ./HXRSnD/screens/snd_main

To launch from the released area: ::

  $ /reg/neh/operator/xcsopr/bin/snd/snd_main

This will launch the EDM screen that looks like the following:
