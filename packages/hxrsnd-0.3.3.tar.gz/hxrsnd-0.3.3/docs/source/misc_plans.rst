=============
Miscellaneous
=============

.. autofunction:: hxrsnd.plans.plan_stubs.euclidean_distance
