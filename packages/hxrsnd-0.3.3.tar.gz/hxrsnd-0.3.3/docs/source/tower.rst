======
Towers
======

Base Tower Class
================

All the towers inherit fromt the ``TowerBase`` class.

.. autosummary::

    ~hxrsnd.tower.TowerBase


Delay Tower
===========

Delay towers ``snd.t1`` and ``snd.t4``.


.. autosummary::

    ~hxrsnd.tower.DelayTower


Channel Cut Tower
=================

Channel cut towers ``snd.t2`` and ``snd.t3``.


.. autosummary::

    ~hxrsnd.tower.ChannelCutTower
