from __future__ import annotations

from . import version  # type: ignore # noqa: PGH003

__version__ = version.version
