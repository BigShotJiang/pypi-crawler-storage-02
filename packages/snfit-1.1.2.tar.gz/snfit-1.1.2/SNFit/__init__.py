import os

__version__ = "1.1.2"

SNFit_dir = os.path.dirname(__file__)
DATADIR = os.path.join(SNFit_dir, "example_data/")


