- Go to *Sale* \> *Delivery* \> *Drop-off Sites*

![](https://raw.githubusercontent.com/OCA/delivery-carrier/10.0/delivery_dropoff_site/static/description/dropoff_site_tree.png)

- You can add create new drop-off sites, filling address. you have the
  possilibity to generate geolocalization, base on the module
  `` `base_geolocalize ``\`

![](https://raw.githubusercontent.com/OCA/delivery-carrier/10.0/delivery_dropoff_site/static/description/dropoff_site_form.png)

- Optionaly, you can set opening hours.

![](https://raw.githubusercontent.com/OCA/delivery-carrier/10.0/delivery_dropoff_site/static/description/dropoff_site_form_calendar.png)

Then, in your sale order form, if you select a Delivery with drop-off
sites enabled, you can select in the delivery address an drop-off site,
and so use a new field Final recipitient to mention the name of partner
that will pick up the parcel in the dropoff site.
