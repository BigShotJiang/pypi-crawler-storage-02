"""Sherpa HTML inscriptis converter"""
__version__ = "0.5.189"
