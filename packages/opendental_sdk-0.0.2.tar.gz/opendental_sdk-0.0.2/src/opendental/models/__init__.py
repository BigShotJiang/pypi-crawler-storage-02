"""
Open Dental API Models

This package contains all the generated model classes for Open Dental API
request and response objects.
"""

# Generated models will be imported here after OpenAPI generation
