"""
Open Dental API Endpoints

This package contains all the generated API endpoint classes for interacting
with different Open Dental API resources.
"""

# Generated API classes will be imported here after OpenAPI generation
