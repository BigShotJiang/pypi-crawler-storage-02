# Textual Tool for Creating Member Profiles for python.pe

To run this tool, just type:

```sh
uvx edit-python-pe
```

After that, a text user interface would appear that allows you to create your
profile and push it (create a PR) to the
[python.pe](https://github.com/pythonpe/python.pe) repository.
