# TFCI MCP

TFCI (Time Forecasting CI) MCP (Model Context Protocol) Client for Time Series Prediction

**이 패키지는 [tfci](https://pypi.org/project/tfci/) 라이브러리의 MCP 확장입니다.**

## 설치

### 기본 설치
```bash
pip install tfci-mcp
```

### TFCI 예측 기능과 함께 설치 (권장)
```bash
pip install tfci-mcp[tfci]
# 또는
pip install tfci-mcp tfci
```

⚠️ **중요**: 실제 예측 기능을 사용하려면 `tfci` 패키지가 필요합니다.

## 사용법

### 기본 사용법

```python
from tfci_mcp import TFCIMCPClient

# 클라이언트 생성
client = TFCIMCPClient()

# 서버 시작
client.start_server()

# 예측 실행 (tfci 패키지 필요)
result = client.predict("config.yaml")
print(result)

# 서버 종료
client.stop_server()
```

### 다른 MCP들과 함께 사용

```python
from tfci_mcp import TFCIMCPClient
from viz_mcp import VizMCPClient

# TFCI 예측
tfci_client = TFCIMCPClient()
tfci_client.start_server()
result = tfci_client.predict("config.yaml")

# 시각화
viz_client = VizMCPClient()
chart = viz_client.create_chart(result)

# 정리
tfci_client.stop_server()
```

## API

### TFCIMCPClient

#### `__init__(server_script=None)`
- `server_script`: 서버 스크립트 경로 (기본값: 자동 감지)

#### `start_server()`
MCP 서버를 시작합니다.

#### `stop_server()`
MCP 서버를 종료합니다.

#### `predict(config_path)`
- `config_path`: YAML 설정 파일 경로
- 반환값: 예측 결과 딕셔너리
- **주의**: `tfci` 패키지가 설치되어 있어야 합니다.

## 의존성

### 필수 의존성
- Python >= 3.9

### 선택적 의존성
- `tfci>=1.0.7`: TFCI 예측 라이브러리 (예측 기능 사용 시 필요)

## 문제 해결

### `ModuleNotFoundError: No module named 'tfci'`
```bash
pip install tfci
```

## 관련 패키지

- **[tfci](https://pypi.org/project/tfci/)**: 메인 시계열 예측 라이브러리
- **tfci-mcp**: MCP 확장 패키지 (현재 패키지)

## 라이선스

MIT License 