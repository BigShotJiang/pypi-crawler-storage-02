"""
CAMINO.

Collection of Algorithms for Mixed-Integer Nonlinear Optimization
"""

__version__ = "0.1.2"
__author__ = "Andrea Ghezzi, Wim Van Roy"
__credits__ = "University of Freiburg, KU Leuven"
