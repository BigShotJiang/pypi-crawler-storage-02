"""Collection of external solvers."""
