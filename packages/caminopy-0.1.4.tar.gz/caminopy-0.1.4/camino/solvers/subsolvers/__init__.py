"""Collection of subsolvers."""
