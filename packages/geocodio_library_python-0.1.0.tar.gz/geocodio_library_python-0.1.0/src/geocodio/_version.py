"""Version information for geocodio package."""

__version__ = "0.1.0"