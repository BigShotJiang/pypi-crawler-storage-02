from .soccer_server import mcp

def main():
    mcp.run()
