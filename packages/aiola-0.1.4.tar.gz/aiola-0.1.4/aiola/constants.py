DEFAULT_BASE_URL = "https://apis.aiola.ai"
DEFAULT_AUTH_BASE_URL = "https://auth.aiola.ai"

DEFAULT_HEADERS = {
    "User-Agent": "@aiola/aiola-python",
}

DEFAULT_HTTP_TIMEOUT = 150

DEFAULT_WORKFLOW_ID = "2c78fcf1-9265-408f-b8c3-d9d7e7ebc1bc"
