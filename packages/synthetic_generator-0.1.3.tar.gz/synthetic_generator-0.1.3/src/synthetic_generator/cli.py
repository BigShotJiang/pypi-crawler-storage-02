def main():
    print(f'Synthetic Generator CLI - {__file__}')
    print('Synthetic data generation tool for machine learning pipelines')
    print('Version: 0.1.1')
