from .base import BaseInt


class Int32(BaseInt):
    def __init__(self):
        super().__init__()


class Int64(BaseInt):
    def __init__(self):
        super().__init__()
