#!/usr/bin/env python

import xml.etree.ElementTree

import greeting

print(xml.etree.ElementTree.__name__)
print(greeting.message)
