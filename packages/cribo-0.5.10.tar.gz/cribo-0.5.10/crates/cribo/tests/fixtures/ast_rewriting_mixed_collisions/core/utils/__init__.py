# Utils package initialization
from .helpers import Logger, process, validate

# Re-export with potential conflicts
Connection = "utils_connection_type"
