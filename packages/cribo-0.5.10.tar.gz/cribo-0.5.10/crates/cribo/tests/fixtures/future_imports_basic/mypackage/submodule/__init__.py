from __future__ import annotations

"""Submodule with future imports."""
