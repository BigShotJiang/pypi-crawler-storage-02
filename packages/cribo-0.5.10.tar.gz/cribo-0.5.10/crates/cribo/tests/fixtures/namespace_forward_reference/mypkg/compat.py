# Simple compat module
from json import JSONDecodeError

__all__ = ["JSONDecodeError"]
