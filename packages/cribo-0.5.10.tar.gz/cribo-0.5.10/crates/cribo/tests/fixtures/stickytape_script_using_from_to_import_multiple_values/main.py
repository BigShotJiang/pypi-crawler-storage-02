#!/usr/bin/env python

from greeting import print_stdout, message

print_stdout(message)
