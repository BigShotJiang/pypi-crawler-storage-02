"""Simple utilities module"""

CONSTANT = 42


def greet(name: str) -> str:
    """Greet someone"""
    return f"Hello, {name}!"
