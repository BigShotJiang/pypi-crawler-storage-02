"""Certs module."""

# Empty module to satisfy import
DEFAULT_CA_BUNDLE_PATH = None
