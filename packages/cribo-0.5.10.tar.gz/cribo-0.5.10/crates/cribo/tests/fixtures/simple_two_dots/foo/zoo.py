ANIMAL = "cat"
