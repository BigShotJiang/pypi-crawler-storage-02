from .boo.__main__ import tada as tada
