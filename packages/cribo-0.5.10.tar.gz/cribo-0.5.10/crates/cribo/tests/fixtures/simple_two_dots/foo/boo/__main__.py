from ..zoo import ANIMAL


def tada() -> str:
    return f"Tada {ANIMAL}!"
