"""Main package module."""

from .__version__ import __version__, __build__

# Also expose version at package level
__all__ = ["__version__", "__build__"]
