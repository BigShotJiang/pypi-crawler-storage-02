# Copyright © 2025 Contrast Security, Inc.
# See https://www.contrastsecurity.com/enduser-terms-0317a for more details.
def assert_false():
    """
    Only used for testing
    """
    assert False  # noqa: B011 PT015
