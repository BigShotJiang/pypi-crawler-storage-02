We need to fork some packages for changes. PyPI does not
let you have direct dependencies on forks, so we vendor
them.

epicbox: https://github.com/claudiosv/epicbox (6bfd55289)
(originally from https://github.com/StepicOrg/epicbox (3673448da))

There might be a clever way of integrating this use subrepos / symlinks / etc
but for now we just copy the code in.
