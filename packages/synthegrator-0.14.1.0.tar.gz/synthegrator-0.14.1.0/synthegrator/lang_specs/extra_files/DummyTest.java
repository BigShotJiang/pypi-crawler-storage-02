/**
* Used to trick mvn into downloading the dependencies in the pom.xml file.
*/
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DummyTest {
    @Test
    void dummyTest() {
        assertEquals(2, 2);
    }
}