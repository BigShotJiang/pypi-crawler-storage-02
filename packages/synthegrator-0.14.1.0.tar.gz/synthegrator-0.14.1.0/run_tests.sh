pip install --upgrade -e .
pytest synthegrator/tests/