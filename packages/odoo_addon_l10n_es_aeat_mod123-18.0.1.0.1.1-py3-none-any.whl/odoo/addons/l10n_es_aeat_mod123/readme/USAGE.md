Para introducir datos válidos para el modelo:

1.  Realizar una factura de proveedor de los intereses cobrados por la
    empresa o particular prestatario con impuesto "Retenciones 19%
    (préstamos)".
2.  O también puede realizar una factura de proveedor del reparto de
    dividendos con el impuesto "Retenciones 19% (dividendos)".
3.  Validarla.

Para crear una declaración del modelo:

1.  Ir a *Facturación \> Informes AEAT \> Modelo 123*.
2.  Pulsar en el botón "Crear".
3.  Seleccionar el ejercicio fiscal y el tipo de período. Los periodos
    incluidos se calculan automáticamente.
4.  Seleccionar el tipo de declaración.
5.  Rellenar el teléfono, necesario para la exportacion BOE.
6.  Guardar y pulsar en el botón "Calcular".
7.  Cuando revise los valores, pulse en el botón "Confirmar".
8.  Se puede exportar la declaración en formato BOE para presentarla
    telemáticamente en el portal de la AEAT.
