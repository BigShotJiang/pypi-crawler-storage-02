'''WSignals event emitting and handling library'''

__version__ = '0.2.3'

from .signals import Signal
