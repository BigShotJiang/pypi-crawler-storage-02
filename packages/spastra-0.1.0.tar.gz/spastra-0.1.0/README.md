SPASTRA Package
