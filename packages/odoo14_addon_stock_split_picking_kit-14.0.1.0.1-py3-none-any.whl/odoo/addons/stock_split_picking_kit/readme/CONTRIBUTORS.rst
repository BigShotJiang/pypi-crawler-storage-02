* Thierry Ducrest <thierry.ducrest@camptocamp.com>
* Jacques-Etienne Baudoux (BCIM) <je@bcim.be>
