"""
MCP Proxy module for OpenHands.
"""

from openhands.runtime.mcp.proxy.manager import MCPProxyManager

__all__ = ['MCPProxyManager']
