"""
CLI Runtime implementation for OpenHands.
"""

from openhands.runtime.impl.cli.cli_runtime import CLIRuntime

__all__ = ['CLIRuntime']
