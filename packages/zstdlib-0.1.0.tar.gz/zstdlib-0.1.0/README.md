# zstdlib
A set of useful python utilities
