from . import cli_launcher

if __name__ == "__main__":
    cli_launcher()