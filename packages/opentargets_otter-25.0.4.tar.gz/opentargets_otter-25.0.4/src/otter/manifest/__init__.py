"""Manifest module."""
