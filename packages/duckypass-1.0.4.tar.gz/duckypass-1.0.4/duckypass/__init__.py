# This file initializes the DuckyPassAPI module and defines the public interface.

from .duckypass import DuckyPassAPI

__all__ = ['DuckyPassAPI']