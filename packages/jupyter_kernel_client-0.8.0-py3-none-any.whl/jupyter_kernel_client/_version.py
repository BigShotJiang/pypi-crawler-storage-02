# Copyright (c) 2023-2024 Datalayer, Inc.
#
# BSD 3-Clause License

"""Jupyter Kernel Client through HTTP and WebSocket."""

__version__ = "0.8.0"
