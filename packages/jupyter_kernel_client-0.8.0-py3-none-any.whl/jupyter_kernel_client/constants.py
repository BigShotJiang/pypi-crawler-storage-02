# Copyright (c) 2023-2024 Datalayer, Inc.
#
# BSD 3-Clause License

import os

REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", 10))
