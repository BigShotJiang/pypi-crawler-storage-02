# from ...RNABERT.main import RNABERT
from .embedder import protein_embeddings_generator
from .protein_embedder import ESM2
