# bot-core ![Version]

[Version]: https://img.shields.io/github/v/tag/python-discord/bot-core?label=latest&logo=version
