from .report import GHReport

__author__ = 'Ivan Ogasawara'
__email__ = 'ivan.ogasawara@gmail.com'
__version__ = '0.1.2'  # semantic-release

__all__ = ['GHReport']
