SYSTEM_PREFIX = 'system-message:'
KEY_EXCHANGE_PREFIX = 'key-exchange:'
AES_KEY_PREFIX = 'aes-key:'
AES_PREFIX = 'enc:'
