<h1 align="center">
  <a href="https://github.com/confy-security/confy-addons" target="_blank" rel="noopener noreferrer">
    <picture>
      <img width="80" src="https://github.com/confy-security/assets/blob/main/img/confy-app-icon.png?raw=true">
    </picture>
  </a>
  <br>
  Confy Addons
</h1>

<p align="center">Componentes adicionais de clientes Confy.</p>

<div align="center">

[![GitHub License](https://img.shields.io/github/license/confy-security/confy-addons?color=blue
)](/LICENSE)
[![Visitors](https://api.visitorbadge.io/api/visitors?path=confy-security%2Fconfy-addons&label=repository%20visits&countColor=%231182c3&style=flat)](https://github.com/confy-security/confy-addons)
  
</div>
