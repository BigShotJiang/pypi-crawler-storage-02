---
title: "egse.process"
---

!!! info "cgse-common"
    This code is part of the `cgse-common` package.


::: egse.process
