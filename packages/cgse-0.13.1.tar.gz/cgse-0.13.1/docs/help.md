
# Help

The best way to get help for something that you couldn't find in the documentation on this site, is to contact one of 
the authors.

## Bugs and Feature requests

Report any bugs or issues through GitHub on the [CGSE issues](https://github.com/IvS-KULeuven/cgse/issues) page.  
