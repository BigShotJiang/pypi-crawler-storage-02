# FITS plugin for the CGSE storage manager
