from ptlibs.ptprinthelper import ptprint
from helpers.result_storage import storage

class Predict:
    def __init__(self, args, ptjsonlib):
        self.args = args
        self.ptjsonlib = ptjsonlib

    def run(self):
        pass