"""
gatenet.radio

RF signal detection, classification, and integration for mesh networking.
"""
from .base import RadioInterface