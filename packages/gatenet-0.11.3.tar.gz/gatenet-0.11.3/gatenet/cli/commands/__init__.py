from .dns import cmd_dns
from .iface import cmd_iface
from .ping import cmd_ping
from .ports import cmd_ports
from .trace import cmd_trace
from .wifi import cmd_wifi
from .trace import cmd_trace