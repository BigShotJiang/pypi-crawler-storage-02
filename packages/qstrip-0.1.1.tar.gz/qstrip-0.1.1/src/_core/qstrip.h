#define PY_SSIZE_T_CLEAN
#include <Python.h>

#define TRUE 1
#define FALSE 0

PyObject* py_strip_markdown(PyObject* self, PyObject* args);