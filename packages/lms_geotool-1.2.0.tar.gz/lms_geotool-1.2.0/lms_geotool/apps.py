from django.apps import AppConfig


class GeotoolConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lms_geotool'
    label = 'geotool'