# TestPioneer
 
* An Automation Framework for CI/CD
* Supports GUI Automation
* Supports GUI, Loading, Stress, and API Testing
* Uses YAML as a Configuration File
* Provides an Automation IDE
  * https://github.com/Integration-Automation/AutomationIDE