__version__ = "1.0.7"
from .core import BotManager

__all__ = ["BotManager", "BotMarkAgent"]