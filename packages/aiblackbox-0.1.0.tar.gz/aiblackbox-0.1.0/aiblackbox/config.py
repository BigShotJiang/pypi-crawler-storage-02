import os

DEFAULT_LOG_PATH = os.path.join(os.path.expanduser("~"), ".aiblackbox", "logs.jsonl")
LOG_FORMAT_VERSION = "1.0"
