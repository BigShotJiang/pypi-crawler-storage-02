from typing import List


def foo() -> List[str]:
    return ["f", "oo"]
