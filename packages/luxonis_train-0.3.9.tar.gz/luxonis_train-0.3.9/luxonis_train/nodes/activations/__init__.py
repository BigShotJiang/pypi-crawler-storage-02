from .activations import HSigmoid

__all__ = ["HSigmoid"]
