from .ghostfacenet import GhostFaceNetV2

__all__ = ["GhostFaceNetV2"]
