from .core import LuxonisModel

__all__ = ["LuxonisModel"]
