"""Common CertDeploy Client resources."""

from .. import CERTDEPLOY_CLIENT_LOGGER_NAME, Logger, LogLevel

log = Logger(name=CERTDEPLOY_CLIENT_LOGGER_NAME)
log.setLevel(LogLevel.ERROR)
