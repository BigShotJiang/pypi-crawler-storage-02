# noqa: D104

from .. import CERTDEPLOY_SERVER_LOGGER_NAME, Logger, LogLevel

log = Logger(name=CERTDEPLOY_SERVER_LOGGER_NAME)
log.setLevel(LogLevel.ERROR)
