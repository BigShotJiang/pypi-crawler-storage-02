"""Version information for arshai package."""

__version__ = "0.6.3"
__version_info__ = (0, 6, 3)
__author__ = "Nima Nazarian"
__email__ = "nimunzn@gmail.com"