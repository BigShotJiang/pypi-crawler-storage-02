## [v0.5.7](https://pypi.org/project/amsdal_server/0.5.7/) - 2025-08-06

### Changes

- Improvements for slack notifications middleware
