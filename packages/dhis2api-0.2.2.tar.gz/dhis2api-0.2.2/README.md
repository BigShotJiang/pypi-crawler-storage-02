# dhis2api

[![PyPI Downloads](https://static.pepy.tech/badge/dhis2api/month)](https://pepy.tech/projects/dhis2api)

dhis2api is a Python package that provides a simple way to download service volumes data from DHIS2 servers.
