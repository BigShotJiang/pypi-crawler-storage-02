from .cli import app

__version__ = "0.2.6"
__all__ = ["app", "__version__"]
