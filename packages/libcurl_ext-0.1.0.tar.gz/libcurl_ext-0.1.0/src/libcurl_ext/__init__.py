def hello() -> str:
    return "Hello from libcurl-ext!"
