def say_hello(): print("Hello from Hello World!")
