from setuptools import setup, find_packages

setup(
    name="eyad123",
    version="0.1",
    packages=find_packages(),
    description="My hello world package",
    author="Eyad",
    author_email="eyadseif17@outlook.com",
    python_requires=">=3.6",
    )
