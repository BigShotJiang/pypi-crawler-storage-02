class NoAuthorizationCodeException(Exception):
    pass


class NoAccessTokenException(Exception):
    pass
