# -*-coding:utf-8-*-
# Author: Eason.Deng
# Github: https://github.com/holbos-deng
# Email: 2292861292@qq.com
# CreateDate: 2024/12/25 20:32
# Description:

VERSION = (0, 0, 5)

__version__ = '.'.join(map(str, VERSION))
