from typing import Union
from os import PathLike

path_type = Union[str, PathLike]
