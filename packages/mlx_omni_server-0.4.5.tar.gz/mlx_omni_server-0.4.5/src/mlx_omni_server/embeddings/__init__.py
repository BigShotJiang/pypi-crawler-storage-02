"""MLX Embeddings API implementation."""
