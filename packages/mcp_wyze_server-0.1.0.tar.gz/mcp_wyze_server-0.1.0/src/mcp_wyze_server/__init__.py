"""MCP Wyze Server - Control Wyze devices via Model Context Protocol"""

__version__ = "0.1.0"