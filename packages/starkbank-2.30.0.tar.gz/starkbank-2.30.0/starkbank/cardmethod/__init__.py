from .__cardmethod import query
