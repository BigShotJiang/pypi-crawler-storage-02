---
title: MLIP Arena
emoji: ⚛
sdk: streamlit
sdk_version: 1.43.2 # The latest supported version
python_version: 3.11
app_file: serve/app.py
colorFrom: indigo
colorTo: yellow
pinned: true
short_description: Benchmark machine learning interatomic potential at scale
---


