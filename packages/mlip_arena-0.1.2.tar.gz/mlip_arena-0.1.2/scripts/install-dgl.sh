# DGL (M3GNet, ALIGNN)

TORCH=2.2
CUDA=cu121

pip install dgl -f https://data.dgl.ai/wheels/torch-${TORCH}/${CUDA}/repo.html