from pathlib import Path

PKG_DIR = Path(__file__).parent
