# Second-order phase transition in BZO perovskite (A.10.3)

To benchmark new MLIP, add model in model list or simply swap ASE calculator in [run.ipynb](run.ipynb).

To reproduce the DFT PBE phonon modes, run [dft.ipynb](dft.ipynb) file. The example phonon mode used to generate plot in A.10.3 has been provided in [dft/mode-1.npy](dft/mode-1.npy).

