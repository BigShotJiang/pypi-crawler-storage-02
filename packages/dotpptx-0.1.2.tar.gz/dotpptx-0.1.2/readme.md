# dotpptx

dotpptx is a tool to convert PowerPoint files to XML and back.
