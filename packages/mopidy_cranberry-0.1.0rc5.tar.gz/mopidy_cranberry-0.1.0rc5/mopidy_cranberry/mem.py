from .core import CranberryCore

cranberry = CranberryCore()
