# Copyright (c) Alibaba, Inc. and its affiliates.
from .models.detector import MtcnnFaceDetector
