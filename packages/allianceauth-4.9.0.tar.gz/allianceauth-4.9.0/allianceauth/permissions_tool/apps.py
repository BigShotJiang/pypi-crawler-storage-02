from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class PermissionsToolConfig(AppConfig):
    name = 'allianceauth.permissions_tool'
    label = 'permissions_tool'
    verbose_name = _('Permissions Audit')
