"""
Initializes the custom_css module.
"""
