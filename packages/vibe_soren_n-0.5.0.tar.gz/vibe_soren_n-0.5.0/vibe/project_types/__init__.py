"""Project type detection and management."""

from .detector import ProjectDetector

__all__ = ["ProjectDetector"]
