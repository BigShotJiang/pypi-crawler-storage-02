# Faultier Python Library

This library is used to control Faultier-based glitchers.
