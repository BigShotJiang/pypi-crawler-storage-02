import json
from abc import abstractmethod
from enum import StrEnum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field, model_validator


class SarvamToolLanguageName(StrEnum):
    BENGALI = "Bengali"
    GUJARATI = "Gujarati"
    KANNADA = "Kannada"
    MALAYALAM = "Malayalam"
    TAMIL = "Tamil"
    TELUGU = "Telugu"
    PUNJABI = "Punjabi"
    ODIA = "Odia"
    MARATHI = "Marathi"
    HINDI = "Hindi"
    ENGLISH = "English"


def is_value_serializable(value: Any) -> bool:
    try:
        json.dumps(value)
        return True
    except TypeError:
        raise ValueError(f"Variable value is not serializable: {value}")

class SarvamToolBaseContext(BaseModel):
    agent_variables: Dict[str, Any] = {}

    def get_agent_variable(self, variable_name: str) -> Any:
        if variable_name in self.agent_variables:
            return self.agent_variables[variable_name]
        raise ValueError(f"Variable {variable_name} not found")

    def set_agent_variable(self, variable_name: str, value: Any) -> None:
        if variable_name not in self.agent_variables:
            raise ValueError(f"Variable {variable_name} not defined")
        is_value_serializable(value)
        self.agent_variables[variable_name] = value

class SarvamToolContext(SarvamToolBaseContext):
    language: SarvamToolLanguageName
    end_conversation: bool = False

    def get_current_language(self) -> SarvamToolLanguageName:
        return self.language

    def change_language(self, language: SarvamToolLanguageName) -> None:
        self.language = language

    def set_end_conversation(self) -> None:
        self.end_conversation = True

class SarvamToolOutput(BaseModel):
    message_to_llm: Optional[str] = None
    message_to_user: Optional[str] = None
    context: SarvamToolContext
    @model_validator(mode="after")
    def validate_messages(self) -> "SarvamToolOutput":
        if not self.message_to_llm and not self.message_to_user:
            raise ValueError("At least one of message_to_llm or message_to_user must be set")
        return self

class SarvamOnStartToolContext(SarvamToolBaseContext):
    user_identifier: str
    initial_bot_message: Optional[str] = None
    initial_state_name: str
    initial_language_name: SarvamToolLanguageName

    def get_user_identifier(self) -> str:
        return self.user_identifier

    def set_initial_bot_message(self, message: str) -> None:
        self.initial_bot_message = message

    def set_initial_state_name(self, state_name: str) -> None:
        self.initial_state_name = state_name

    def set_initial_language_name(self, language_name: SarvamToolLanguageName) -> None:
        self.initial_language_name = language_name


class SarvamInteractionTurnRole(StrEnum):
    USER = "user"
    AGENT = "agent"


class SarvamInteractionTurn(BaseModel):
    role: SarvamInteractionTurnRole = Field(description="Role of the speaker")
    en_text: str = Field(description="English text uttered by the speaker")


class SarvamInteractionTranscript(BaseModel):
    app_id: str
    app_version: int
    interaction_transcript: list[SarvamInteractionTurn] = Field(
        description="Interaction transcript"
    )


class SarvamOnEndToolContext(SarvamToolBaseContext):
    user_identifier: str
    interaction_transcript: Optional[SarvamInteractionTranscript] = Field(
        description="Interaction transcript", default=None
    )

    def get_user_identifier(self) -> str:
        return self.user_identifier

    def get_interaction_transcript(self) -> Optional[SarvamInteractionTranscript]:
        return self.interaction_transcript


class SarvamTool(BaseModel):
    @abstractmethod
    async def run(self, context: SarvamToolContext) -> SarvamToolOutput:
        raise NotImplementedError("Subclasses must implement this method")


class SarvamOnStartTool(BaseModel):
    @abstractmethod
    async def run(self, context: SarvamOnStartToolContext) -> SarvamOnStartToolContext:
        raise NotImplementedError("Subclasses must implement this method")


class SarvamOnEndTool(BaseModel):
    @abstractmethod
    async def run(self, context: SarvamOnEndToolContext) -> SarvamOnEndToolContext:
        raise NotImplementedError("Subclasses must implement this method")
