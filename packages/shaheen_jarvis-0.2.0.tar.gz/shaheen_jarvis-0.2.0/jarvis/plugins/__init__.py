"""Plugin system for Shaheen-Jarvis framework."""

__all__ = []
