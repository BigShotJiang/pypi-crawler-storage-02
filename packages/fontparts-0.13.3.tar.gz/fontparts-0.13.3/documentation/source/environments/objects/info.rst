.. highlight:: python
.. module:: fontParts.base

Info
****

Must Override
-------------

May Override
------------
.. automethod:: BaseInfo._getAttr
.. automethod:: BaseInfo._init
.. automethod:: BaseInfo._interpolate
.. automethod:: BaseInfo._round
.. automethod:: BaseInfo._setAttr
.. automethod:: BaseInfo.copyData