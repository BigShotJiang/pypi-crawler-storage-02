PyCriCodecsEx
---
A continuation of @Youjose's work on Criware formats. Feautres are still in flux and subject to change. When in doubt, Refer to the [original repo](https://github.com/Youjose/PyCriCodecs) for more information.

Detailed documentation, installation instructions are available at https://mos9527.com/PyCriCodecsEx


# Credits
- https://github.com/Youjose/PyCriCodecs
- https://github.com/Mikewando/PyCriCodecs ([PR#1 on USM](https://github.com/mos9527/PyCriCodecsEx/pull/1))
- https://github.com/donmai-me/WannaCRI
- https://github.com/vgmstream/vgmstream
- https://github.com/K0lb3/UnityPy (For CI script)