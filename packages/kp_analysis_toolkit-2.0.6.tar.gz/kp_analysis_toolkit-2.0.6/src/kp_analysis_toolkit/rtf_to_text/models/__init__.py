"""Models for RTF to text converter."""
