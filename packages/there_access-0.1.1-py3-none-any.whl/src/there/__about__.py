# SPDX-FileCopyrightText: 2025-present Josephine Roper <roper.josephine@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-only
__version__ = "0.1.1"
