MAX_VALUE = 2**48
"""int: Maximum allowed value, equal to 2^48.
"""
