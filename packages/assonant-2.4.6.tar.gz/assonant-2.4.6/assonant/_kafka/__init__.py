"""Assonant Kafka.

Assonant toolkit for dealing with tasks related to Kafka.
"""
