"""Single source package version.

No dependencies should be added to this module.

See https://packaging.python.org/guides/single-sourcing-package-version/
"""

__version__ = '1.51'
