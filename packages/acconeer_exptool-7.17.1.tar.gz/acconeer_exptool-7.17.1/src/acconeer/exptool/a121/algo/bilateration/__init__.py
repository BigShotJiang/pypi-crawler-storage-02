# Copyright (c) Acconeer AB, 2023
# All rights reserved

from ._configs import get_default_detector_config
from ._processor import Processor, ProcessorConfig, ProcessorResult
