# Copyright (c) Acconeer AB, 2022
# All rights reserved

WAVELENGTH = 0.49  # Wavelength of radar in cm
