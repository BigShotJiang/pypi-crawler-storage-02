# Copyright (c) Acconeer AB, 2022
# All rights reserved

from acconeer.exptool.a111 import PowerBinServiceConfig


def get_sensor_config():
    return PowerBinServiceConfig()
