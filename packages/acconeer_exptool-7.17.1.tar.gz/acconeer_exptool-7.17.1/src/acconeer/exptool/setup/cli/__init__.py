# Copyright (c) Acconeer AB, 2022
# All rights reserved

from .argument_parser import SetupArgumentParser
