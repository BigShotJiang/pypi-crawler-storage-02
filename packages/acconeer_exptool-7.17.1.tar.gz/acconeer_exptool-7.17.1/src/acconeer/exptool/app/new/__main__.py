# Copyright (c) Acconeer AB, 2022
# All rights reserved

from . import main


if __name__ == "__main__":
    main()
