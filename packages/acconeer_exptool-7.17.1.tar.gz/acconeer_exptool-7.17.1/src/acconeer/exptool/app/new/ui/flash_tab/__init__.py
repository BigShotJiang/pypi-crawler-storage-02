# Copyright (c) Acconeer AB, 2023
# All rights reserved

from .widgets import FlashMainWidget
