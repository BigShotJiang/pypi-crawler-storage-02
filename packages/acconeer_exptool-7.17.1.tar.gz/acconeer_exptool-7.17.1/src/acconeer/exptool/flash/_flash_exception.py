# Copyright (c) Acconeer AB, 2024
# All rights reserved


class FlashException(Exception):
    """Exception class for the flasher"""
