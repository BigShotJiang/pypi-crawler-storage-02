# Copyright (c) Acconeer AB, 2022
# All rights reserved

from ._meta import ACCONEER_XM_CP2105_MODULE_PID
from ._stm32flasher import Stm32UartFlasher
