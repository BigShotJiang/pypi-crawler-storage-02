"""Word cloud is ungraded xblock used by students to generate and view word cloud.
"""

from .word_cloud import WordCloudBlock
