"""
Init for the ProblemBlock.
"""

from .problem import ProblemBlock
