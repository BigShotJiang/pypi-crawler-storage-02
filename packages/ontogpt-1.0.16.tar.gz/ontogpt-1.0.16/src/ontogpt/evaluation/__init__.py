from ontogpt.evaluation.resolver import create_evaluator  # noqa:F401
