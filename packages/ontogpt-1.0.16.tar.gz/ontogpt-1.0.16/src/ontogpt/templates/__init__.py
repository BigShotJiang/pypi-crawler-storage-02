from pathlib import Path

PATH_TO_TEMPLATES = Path(__file__).parent