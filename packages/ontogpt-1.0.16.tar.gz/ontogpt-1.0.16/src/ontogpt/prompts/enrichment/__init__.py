from pathlib import Path

ENRICHMENT_PROMPT_DIR_PATH = Path(__file__).parent
DEFAULT_ENRICHMENT_PROMPT = ENRICHMENT_PROMPT_DIR_PATH / "gene_set_summarization"
