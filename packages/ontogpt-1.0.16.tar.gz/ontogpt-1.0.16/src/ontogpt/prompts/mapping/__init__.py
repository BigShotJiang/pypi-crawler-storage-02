from pathlib import Path

MAPPING_PROMPT_DIR_PATH = Path(__file__).parent
DEFAULT_MAPPING_EVAL_PROMPT = MAPPING_PROMPT_DIR_PATH / "eval-mapping.jinja2"
