"""
Exposure Time estimators
------------------------
"""

from .exptime import ExpTimeEstimator
from .star import StarExpTimeEstimator
