# simplelogger

A minimal logger utility for Python projects.

## Installation

```bash
pip install flashsimplelogger

