"""Tools to generate music"""

from tonal.chords import chords_to_wav, chords_to_midi
from tonal.util import DFLT_SOUNDFONT
from tonal.converters import convert, midi_to_wav
from tonal.notes import scale_midi_notes
