# Youtube Autonomous Video Masking Module

The way to use greenscreens and alphascreens.