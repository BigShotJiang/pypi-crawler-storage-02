This creates a tooltip that will be displayed on top of all windows.

The tooltip will be attached to the assigned Tkinter widget and follow the mouse as long as mouse stays within widget boundaries.