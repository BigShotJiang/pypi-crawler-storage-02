.. Pyzo documentation master file, created by
   sphinx-quickstart on Sun Jan 26 00:33:41 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pyzo's documentation!
===============================

API docs in progress.

Pyzo is organized in several subpackages, some of which can be used completely
independent from the rest. Although Pyzo the IDE requires Qt and Python 3,
some of its subpackages can safely be imported without these dependencies...

Contents:

.. toctree::
   :maxdepth: 2

   codeeditor/index
   yoton/index



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

