.. _codeeditor:

Codeeditor - The core editing component
=======================================

This subpackage is independent of any other components of Pyzo and
only has Qt (PySide2 or PyQt5) as a dependency.

Content and API will come here.

