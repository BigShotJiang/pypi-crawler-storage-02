# This is the one place where codeeditor depends on Pyzo itself
from pyzo.qt import QtCore, QtGui, QtWidgets  # noqa
