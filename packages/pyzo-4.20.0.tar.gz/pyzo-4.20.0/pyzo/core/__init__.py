"""Package core - the core of Pyzo."""
