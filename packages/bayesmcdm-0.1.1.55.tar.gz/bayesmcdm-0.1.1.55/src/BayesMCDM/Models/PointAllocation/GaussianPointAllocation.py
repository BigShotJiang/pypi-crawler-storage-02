from ..SWING.GaussianSWING import GaussianSWING

class GaussianPointAllocation(GaussianSWING):
    """
    This class is a direct alias of GaussianSWING for Point Allocation method.
    """
    pass
