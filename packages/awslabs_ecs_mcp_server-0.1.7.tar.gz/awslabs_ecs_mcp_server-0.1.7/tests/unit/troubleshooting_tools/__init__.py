"""
Unit tests for the ECS MCP Server troubleshooting tools.
"""
