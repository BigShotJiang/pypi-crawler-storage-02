"""
Init Package
"""

__version__ = "0.0.0"

from .curriculum import *  # noqa: F403
from .trainer import *  # noqa: F403
