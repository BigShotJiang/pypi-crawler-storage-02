aind\_behavior\_curriculum.curriculum.Policy
============================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autoclass:: Policy
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Policy.__init__
      ~Policy.invoke
      ~Policy.normalize_rule_or_callable
      ~Policy.serialize_rule
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Policy.callable
      ~Policy.name
   
   