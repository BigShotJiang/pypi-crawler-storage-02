﻿aind\_behavior\_curriculum.base
===============================

.. automodule:: aind_behavior_curriculum.base
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst               
   
      AindBehaviorModel
      AindBehaviorModelExtra
   
   

   
   
   



