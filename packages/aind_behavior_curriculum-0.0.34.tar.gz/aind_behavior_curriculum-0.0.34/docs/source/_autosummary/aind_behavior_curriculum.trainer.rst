﻿aind\_behavior\_curriculum.trainer
==================================

.. automodule:: aind_behavior_curriculum.trainer
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst               
   
      Trainer
      TrainerServer
      TrainerState
   
   

   
   
   



