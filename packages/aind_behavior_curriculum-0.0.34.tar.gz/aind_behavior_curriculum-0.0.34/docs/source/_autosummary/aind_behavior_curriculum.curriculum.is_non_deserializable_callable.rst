aind\_behavior\_curriculum.curriculum.is\_non\_deserializable\_callable
=======================================================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autofunction:: is_non_deserializable_callable