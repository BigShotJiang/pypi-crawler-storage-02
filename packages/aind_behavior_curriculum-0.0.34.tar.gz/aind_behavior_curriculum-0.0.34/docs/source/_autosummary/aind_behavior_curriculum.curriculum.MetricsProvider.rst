aind\_behavior\_curriculum.curriculum.MetricsProvider
=====================================================

.. currentmodule:: aind_behavior_curriculum.curriculum

.. autoclass:: MetricsProvider
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MetricsProvider.__init__
      ~MetricsProvider.invoke
      ~MetricsProvider.normalize_rule_or_callable
      ~MetricsProvider.serialize_rule
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MetricsProvider.callable
      ~MetricsProvider.name
   
   