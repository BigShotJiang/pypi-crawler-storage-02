# notion-model

[![codecov](https://codecov.io/gh/austinyu/notion-model/graph/badge.svg?token=5E1ZI1L3MP)](https://codecov.io/gh/austinyu/notion-model)

Interact with Notion using pydantic!
