To configure this module, you need to:

1. Go to a pricelist.
2. Select or create a pricelist line.
3. Select 'Product Tags' as the 'Apply On' option and select the product tags.