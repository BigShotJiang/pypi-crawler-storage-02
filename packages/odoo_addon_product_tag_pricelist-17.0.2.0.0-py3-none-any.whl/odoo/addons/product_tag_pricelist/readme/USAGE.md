To use this module, you need to:

1. Create a Sale with a pricelist that has some items configured with product tags
2. Add a product with that tag to the sale, its price will be the configured in the pricelist item.
