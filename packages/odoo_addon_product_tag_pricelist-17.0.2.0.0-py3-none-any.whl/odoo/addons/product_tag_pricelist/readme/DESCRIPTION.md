This module allows to use product tags to set pricelists.

The priority will be 2, behind product categories.

The pricelist is applied even if just one tag applied to the product matches one tag set in the pricelist.
