# Copyright 2023 Manuel Regidor <manuel.regidor@sygel.es>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import product_pricelist_item
from . import product_pricelist
from . import product_product
from . import product_template
