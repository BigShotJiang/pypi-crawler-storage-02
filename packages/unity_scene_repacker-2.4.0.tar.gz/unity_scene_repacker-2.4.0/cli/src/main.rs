fn main() {
    unity_scene_repacker_bin::main(std::env::args_os().collect(), None);
}
