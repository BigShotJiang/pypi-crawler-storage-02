"""
xlwings implementation module for Excel MCP Server
Phase 1 migration: xlwings를 사용한 Excel 파일 조작 기능
"""

__version__ = "0.1.0"