::: cattle_grid.extensions.examples.recipients
    options:
        heading_level: 1
