.. e3tools documentation master file, created by
   sphinx-quickstart on Mon Mar  3 20:12:01 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

e3tools documentation
=====================

e3tools is a repository of building blocks in PyTorch for E(3)/SE(3)-equivariant neural networks.

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   e3tools
