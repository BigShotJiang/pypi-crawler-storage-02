```bash
cd docs
sphinx-apidoc -o source ../src
sphinx-build -M html source build
```
