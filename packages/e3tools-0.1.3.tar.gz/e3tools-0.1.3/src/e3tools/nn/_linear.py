import e3nn.o3

Linear = e3nn.o3.Linear
