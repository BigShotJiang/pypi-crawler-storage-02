"""
faster-whisper-hotkey: Push-to-talk transcription using faster-whisper.

Hold the hotkey, Speak, Release ==> And baamm in the currently focused text field!
"""

__version__ = "0.2.6"