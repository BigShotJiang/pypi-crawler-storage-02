"""Configuration module for AceFlow MCP Server."""

from .template_config import template_config

__all__ = ['template_config']