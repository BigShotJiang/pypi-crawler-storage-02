(garden-circle-intro)=

# Garden Circle

The garden circle is a section of the Software Garden Almanack associated with contributions, planning, and internal maintenance of the project.
