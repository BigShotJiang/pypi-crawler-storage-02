"Enterprise features for Solara"

__version__ = "1.51.0"
