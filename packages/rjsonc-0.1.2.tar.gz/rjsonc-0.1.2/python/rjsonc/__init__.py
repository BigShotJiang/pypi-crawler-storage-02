from .wrapper import loads

__all__ = ["loads"]
