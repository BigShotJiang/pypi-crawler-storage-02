SELECT
    NULL as column_name,
    NULL as enum_values
LIMIT 0