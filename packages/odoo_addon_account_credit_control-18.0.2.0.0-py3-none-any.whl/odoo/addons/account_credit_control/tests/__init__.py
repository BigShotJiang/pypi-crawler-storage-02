# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
from . import test_credit_control_policy
from . import test_res_partner
from . import test_account_move
from . import test_credit_control_run
