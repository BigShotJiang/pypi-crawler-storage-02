==================================================
input_data
==================================================

Description
=================================
入力データ関係のコマンドです。


Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   change_name
   copy
   delete
   delete_metadata_key
   download
   list
   list_all
   list_all_merged_task
   put
   put_with_zip
   update_metadata

Usage Details
=================================

.. argparse::
   :ref: annofabcli.input_data.subcommand_input_data.add_parser
   :prog: annofabcli input_data
   :nosubcommands:
