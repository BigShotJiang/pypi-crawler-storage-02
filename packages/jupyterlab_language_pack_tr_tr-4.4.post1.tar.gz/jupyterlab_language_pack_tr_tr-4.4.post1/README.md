# Jupyterlab Turkish (Turkey) Language Pack

Turkish (Turkey) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-tr-TR
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-tr-TR
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
