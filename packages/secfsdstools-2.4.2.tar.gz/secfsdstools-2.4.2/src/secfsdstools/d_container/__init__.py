"""
force import of update_check
"""
import secfsdstools.c_update_check
