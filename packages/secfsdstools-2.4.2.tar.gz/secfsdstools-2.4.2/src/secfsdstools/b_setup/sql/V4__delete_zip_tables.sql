DROP TABLE IF EXISTS index_reports;

DROP TABLE IF EXISTS index_file_processing_state;