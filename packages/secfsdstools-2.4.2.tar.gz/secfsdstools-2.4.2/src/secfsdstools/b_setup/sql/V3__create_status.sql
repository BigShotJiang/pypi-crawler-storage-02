CREATE TABLE IF NOT EXISTS status
(
    keyName,
    value,
    PRIMARY KEY (keyName)
);