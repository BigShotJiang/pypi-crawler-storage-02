Authors
=======

Christopher L. Farrow,
Pavol Juhas,
Simon J.L. Billinge,
Vincent Favre-Nicolin

Contributors
------------

For a list of contributors, visit
https://github.com/diffpy/pyobjcryst/graphs/contributors
