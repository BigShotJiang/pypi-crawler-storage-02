from .mcp_model import mcp

def main() -> None:
    mcp.run()