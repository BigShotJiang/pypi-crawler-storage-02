2025-08-02 Version: 1.1.2
- Update API ListOnlineEvalTasks: add request parameters AppName.
- Update API ListOnlineEvalTasks: add request parameters Status.


2025-08-01 Version: 1.1.1
- Update API ListOnlineEvalTasks: add request parameters SortBy.
- Update API ListOnlineEvalTasks: add request parameters SortOrder.
- Update API ListOnlineEvalTasks: add response parameters Body.Tasks.$.EvalResults.
- Update API ListOnlineEvalTasks: add response parameters Body.Tasks.$.RecordCount.


2025-07-08 Version: 1.1.0
- Support API ListEvalResults.
- Update API ListTracesDatas: add request parameters MaxDuration.
- Update API ListTracesDatas: add request parameters MinDuration.
- Update API ListTracesDatas: add request parameters SpanName.


2025-04-23 Version: 1.0.0
- Generated python 2024-03-11 for PaiLLMTrace.

