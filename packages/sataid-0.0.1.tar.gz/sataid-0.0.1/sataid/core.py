def readdata():
    print("sataid testing")
