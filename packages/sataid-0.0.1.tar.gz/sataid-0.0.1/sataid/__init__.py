from .core import readdata
