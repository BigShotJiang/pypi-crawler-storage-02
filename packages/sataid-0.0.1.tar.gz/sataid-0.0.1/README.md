# sataid

Testing package for name registration.

## Usage

```python
import sataid as sat
sat.readdata()  # Output: sataid testing
```
