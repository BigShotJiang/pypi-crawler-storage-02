# Memories on the topic
- following are memories about current topic
- do not overly rely on them they might not be relevant

{{memories}}