import secrets
from agent_zero_lite.python.helpers.api import (
    ApiHandler,
    Input,
    Output,
    Request,
    Response,
    session,
)
from agent_zero_lite.python.helpers import runtime

class GetCsrfToken(ApiHandler):

    @classmethod
    def get_methods(cls) -> list[str]:
        return ["GET"]

    @classmethod
    def requires_csrf(cls) -> bool:
        return False
    
    @classmethod
    def requires_auth(cls) -> bool:
        return False

    async def process(self, input: Input, request: Request) -> Output:
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_urlsafe(32)
        return {"token": session["csrf_token"], "runtime_id": runtime.get_runtime_id()}
