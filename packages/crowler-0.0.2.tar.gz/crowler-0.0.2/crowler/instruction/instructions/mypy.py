from crowler.instruction.instruction_model import Instruction


MYPY_INSTRUCTION = Instruction(instructions=[])
