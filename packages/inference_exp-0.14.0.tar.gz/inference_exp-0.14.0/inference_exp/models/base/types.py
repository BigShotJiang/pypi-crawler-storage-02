from typing import TypeVar

PreprocessedInputs = TypeVar("PreprocessedInputs")
PreprocessingMetadata = TypeVar("PreprocessingMetadata")
RawPrediction = TypeVar("RawPrediction")
