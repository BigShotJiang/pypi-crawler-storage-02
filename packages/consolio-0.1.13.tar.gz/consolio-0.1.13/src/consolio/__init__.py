from .consolio import Consolio

__version__ = '0.1.13'
__name__ = "consolio"
__all__ = ['Consolio']
