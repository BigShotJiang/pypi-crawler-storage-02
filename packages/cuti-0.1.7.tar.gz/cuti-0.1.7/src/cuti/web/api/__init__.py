"""
API endpoints for the web interface.
"""