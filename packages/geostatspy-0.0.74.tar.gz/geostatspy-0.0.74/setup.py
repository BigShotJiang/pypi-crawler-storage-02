"""See pyproject.toml for project metadata."""
from setuptools import setup

setup()
