"""Performance tests."""
