
# Generated in hatch_build.py.
__platform__ = "linux"
__arch__ = "amd64"
        