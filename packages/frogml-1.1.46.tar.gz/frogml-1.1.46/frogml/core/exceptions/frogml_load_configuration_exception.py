class LoadConfigurationException(Exception):
    pass
