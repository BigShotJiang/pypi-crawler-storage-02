"""Template management module for Yoix."""

from .manager import TemplateManager

__all__ = ['TemplateManager']
