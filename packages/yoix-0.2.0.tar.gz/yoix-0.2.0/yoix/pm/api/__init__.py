"""Plugin API module for Yoix."""

from .api import PluginApi

__all__ = ['PluginApi']
