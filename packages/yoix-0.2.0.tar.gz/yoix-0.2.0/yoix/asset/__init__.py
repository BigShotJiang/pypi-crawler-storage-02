"""Asset management module for Yoix."""

from .manager import AssetManager

__all__ = ['AssetManager']
