from PTJPL.constants import *

FIELD_CAPACITY_SCALE = 0.7
RESAMPLING = "cubic"