from enum import Enum


class BinaryKeys(str, Enum):
    OPENSEARCH = "opensearch"
