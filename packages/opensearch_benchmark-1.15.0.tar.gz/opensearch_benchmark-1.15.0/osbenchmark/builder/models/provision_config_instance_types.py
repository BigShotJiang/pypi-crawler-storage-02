from enum import Enum


class ProvisionConfigInstanceType(str, Enum):
    PROVISION_CONFIG_INSTANCE = "provision-config-instance"
    MIXIN = "mixin"
