from django.apps import AppConfig


class CoreConfig(AppConfig):  # noqa: D101
    name = "demo.core"
    label = "core"
