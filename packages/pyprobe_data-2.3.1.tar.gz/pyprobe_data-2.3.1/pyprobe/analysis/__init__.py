"""A module for methods."""
