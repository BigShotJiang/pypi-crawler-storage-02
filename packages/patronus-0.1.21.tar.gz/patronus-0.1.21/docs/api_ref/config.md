# Config

::: patronus.config
    options:
        show_root_heading: true
