# Patronus Objects

::: patronus.pat_client
    options:
        show_submodules: true
