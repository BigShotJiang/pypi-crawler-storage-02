# Init

::: patronus.init
    options:
        show_root_heading: true
