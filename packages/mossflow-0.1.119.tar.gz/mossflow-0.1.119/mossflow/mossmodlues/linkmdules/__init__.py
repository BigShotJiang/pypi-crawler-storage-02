from . import Grpahics_WrapLineModule,Grpahics_WrapIfLineModule
name = {"zh": "链接", "en": "Link","rawname": "link"}
version = "0.1.0"