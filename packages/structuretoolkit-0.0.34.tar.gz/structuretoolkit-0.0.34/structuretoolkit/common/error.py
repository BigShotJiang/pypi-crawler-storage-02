class SymmetryError(Exception):
    pass
