from mcp_seniverse_weather_sunw import main

main()