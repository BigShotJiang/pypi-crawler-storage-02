def main() -> None:
    print("Hello from linguacli!")
