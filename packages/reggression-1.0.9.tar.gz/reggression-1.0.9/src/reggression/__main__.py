import sys
from typing import NoReturn
import reggression


def main() -> NoReturn:
    sys.exit(reggression.main(sys.argv))


if __name__ == "__main__":
    main()
