from __future__ import annotations

from utilities.sentinel import Sentinel


class NewSentinel(Sentinel):
    pass
