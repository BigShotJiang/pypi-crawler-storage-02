"""This module contains the implementation of utility functions."""
