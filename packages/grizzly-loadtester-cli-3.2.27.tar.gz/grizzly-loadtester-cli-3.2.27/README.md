# Grizzly Command Line Interface

Documentation can be found [here](https://biometria-se.github.io/grizzly/command-line-interface/usage/).

Issues should be reported in [`biometria-se/grizzly/issues`](https://github.com/Biometria-se/grizzly/issues).
