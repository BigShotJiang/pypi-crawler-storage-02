from ._private_submod.mod import func_in_private_submod

__all__ = ["func_in_private_submod"]
