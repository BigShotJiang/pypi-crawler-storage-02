def my_function() -> None:
    pass
