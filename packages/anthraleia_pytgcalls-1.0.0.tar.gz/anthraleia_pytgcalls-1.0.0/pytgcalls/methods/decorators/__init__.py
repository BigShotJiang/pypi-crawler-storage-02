from .on_update import OnUpdate


class Decorators(
    OnUpdate,
):
    pass
