class Globals():
    def __init__(self, window_name=None, monitor=0, debug=False):
        self.window_name = window_name
        self.monitor = monitor
        self.debug = debug

SETTINGS = Globals()