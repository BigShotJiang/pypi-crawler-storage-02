from .logo import _init_env  # Hanya expose fungsi utama
from . import logo
