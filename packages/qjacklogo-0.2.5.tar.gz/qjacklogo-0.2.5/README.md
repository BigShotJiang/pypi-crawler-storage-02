# QJackLogo
Animated terminal logo with rainbow colors and Arabic text.