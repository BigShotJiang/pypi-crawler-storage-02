from enum import Enum, auto


class Person(Enum):
    FIRST = auto()
    SECOND = auto()
    THIRD = auto()
