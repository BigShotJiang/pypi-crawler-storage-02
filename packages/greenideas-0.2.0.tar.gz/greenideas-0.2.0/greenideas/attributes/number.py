from enum import Enum, auto


class Number(Enum):
    SINGULAR = auto()
    PLURAL = auto()
