from enum import Enum, auto


class Tense(Enum):
    PRESENT = auto()
    PAST = auto()
