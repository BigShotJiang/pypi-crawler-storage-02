# tests/test_core.py
def test_dummy():
    assert True
