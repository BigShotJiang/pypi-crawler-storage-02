# `LiteLLM Models`

::: agents.extensions.models.litellm_model
