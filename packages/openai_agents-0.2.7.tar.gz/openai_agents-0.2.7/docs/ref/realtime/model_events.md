# `Model Events`

::: agents.realtime.model_events
