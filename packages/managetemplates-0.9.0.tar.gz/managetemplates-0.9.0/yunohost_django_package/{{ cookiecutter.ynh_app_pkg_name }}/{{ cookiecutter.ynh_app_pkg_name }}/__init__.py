"""
{{ cookiecutter.ynh_app_pkg_name }}
{{ cookiecutter.package_description }}
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '{{ cookiecutter.upstream_version }}+{{ cookiecutter.ynh_suffix_version }}'
__author__ = '{{ cookiecutter.full_name }} <{{ cookiecutter.author_email }}>'
