CLI_EPILOG = 'Project Homepage: {{ cookiecutter.ynh_app_url }}'
