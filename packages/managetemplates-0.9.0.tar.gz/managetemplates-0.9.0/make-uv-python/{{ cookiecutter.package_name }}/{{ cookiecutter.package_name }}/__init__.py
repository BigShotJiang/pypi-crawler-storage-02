"""
    {{ cookiecutter.package_name }}
    {{ cookiecutter.package_description }}
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '{{ cookiecutter.package_version }}'
__author__ = '{{ cookiecutter.full_name }} <{{ cookiecutter.author_email }}>'
