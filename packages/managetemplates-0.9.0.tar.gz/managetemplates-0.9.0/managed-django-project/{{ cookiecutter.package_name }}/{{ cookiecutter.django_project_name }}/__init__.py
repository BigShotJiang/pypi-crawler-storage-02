import {{ cookiecutter.package_name }}


# Just the same version as the real project:
__version__ = {{ cookiecutter.package_name }}.__version__
