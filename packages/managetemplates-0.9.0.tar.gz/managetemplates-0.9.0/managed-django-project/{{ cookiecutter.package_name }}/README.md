# {{ cookiecutter.project_name }}

[![tests]({{ cookiecutter.package_url }}/actions/workflows/tests.yml/badge.svg?branch=main)]({{ cookiecutter.package_url }}/actions/workflows/tests.yml)
[![codecov](https://codecov.io/github/{{ cookiecutter.github_username }}/{{ cookiecutter.package_name }}/branch/main/graph/badge.svg)](https://app.codecov.io/github/{{ cookiecutter.github_username }}/{{ cookiecutter.package_name }})
[![{{ cookiecutter.project_name }} @ PyPi](https://img.shields.io/pypi/v/{{ cookiecutter.project_name }}?label={{ cookiecutter.project_name }}%20%40%20PyPi)](https://pypi.org/project/{{ cookiecutter.project_name }}/)
[![Python Versions](https://img.shields.io/pypi/pyversions/{{ cookiecutter.project_name }})]({{ cookiecutter.package_url }}/blob/main/pyproject.toml)
[![License {{ cookiecutter.license }}](https://img.shields.io/pypi/l/{{ cookiecutter.project_name }})]({{ cookiecutter.package_url }}/blob/main/LICENSE)

{{ cookiecutter.package_description }}
