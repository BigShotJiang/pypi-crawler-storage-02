"""
    Allow managetemplates to be executable
    through `python -m managetemplates`.
"""


from managetemplates.cli_app import main


if __name__ == '__main__':
    main()
