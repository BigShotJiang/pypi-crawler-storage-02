"""
    managetemplates
    Pseudo Python package to test the cookiecutter templates
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.9.0'
__author__ = 'Jens Diemer <cookiecutter_templates@jensdiemer.de>'
