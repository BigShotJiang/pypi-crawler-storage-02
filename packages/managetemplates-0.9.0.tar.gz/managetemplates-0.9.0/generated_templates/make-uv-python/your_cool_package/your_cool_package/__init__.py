"""
    your_cool_package
    A minimal Python package
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.0.1'
__author__ = 'John Doh <john-doh@example.tld>'
