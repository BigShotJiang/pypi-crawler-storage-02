"""
    Allow your_cool_package to be executable
    through `python -m your_cool_package`.
"""


def main():
    print('Hello World from your_cool_package')


if __name__ == '__main__':
    main()
