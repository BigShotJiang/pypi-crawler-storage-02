import your_cool_package


# Just the same version as the real project:
__version__ = your_cool_package.__version__
