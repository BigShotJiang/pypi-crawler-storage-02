# your-cool-package

[![tests](https://github.com/john-doh/your_cool_package/actions/workflows/tests.yml/badge.svg?branch=main)](https://github.com/john-doh/your_cool_package/actions/workflows/tests.yml)
[![codecov](https://codecov.io/github/john-doh/your_cool_package/branch/main/graph/badge.svg)](https://app.codecov.io/github/john-doh/your_cool_package)
[![your-cool-package @ PyPi](https://img.shields.io/pypi/v/your-cool-package?label=your-cool-package%20%40%20PyPi)](https://pypi.org/project/your-cool-package/)
[![Python Versions](https://img.shields.io/pypi/pyversions/your-cool-package)](https://github.com/john-doh/your_cool_package/blob/main/pyproject.toml)
[![License GPL-3.0-or-later](https://img.shields.io/pypi/l/your-cool-package)](https://github.com/john-doh/your_cool_package/blob/main/LICENSE)

A minimal Python package
