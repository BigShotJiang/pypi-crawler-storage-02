"""
django_example_ynh
A example YunoHost App
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.2.0+ynh1'
__author__ = 'John Doh <john-doh@example.tld>'
