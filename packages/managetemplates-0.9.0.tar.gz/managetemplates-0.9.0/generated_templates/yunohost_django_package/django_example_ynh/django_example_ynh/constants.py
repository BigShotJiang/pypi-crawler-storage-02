CLI_EPILOG = 'Project Homepage: https://github.com/YunoHost-Apps/django_example_ynh'
