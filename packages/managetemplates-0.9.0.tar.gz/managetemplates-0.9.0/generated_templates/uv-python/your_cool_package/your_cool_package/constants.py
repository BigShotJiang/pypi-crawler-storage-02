from pathlib import Path

import your_cool_package


CLI_EPILOG = 'Project Homepage: https://github.com/john-doh/your_cool_package'

BASE_PATH = Path(your_cool_package.__file__).parent
