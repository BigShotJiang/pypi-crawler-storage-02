"""
    Allow your_cool_package to be executable
    through `python -m your_cool_package`.
"""

from your_cool_package.cli_app import main


if __name__ == '__main__':
    main()
