The standard invoice_status field shows information about the status
of the invoices related to a Purchase Order.

However, it can happen that the field invoice status can be "invoiced" while the invoices
are still in draft. Many times that makes the difference for considering the Purchase Order
as closed or not. Because of this, this module introduces a new field, Fully Invoiced,
taking the state into account.
