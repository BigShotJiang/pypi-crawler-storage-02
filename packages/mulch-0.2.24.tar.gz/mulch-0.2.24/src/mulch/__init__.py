# mulch/__init__.py

from .workspace_manager_generator import WorkspaceManagerGenerator, load_scaffold

__all__ = ["WorkspaceManagerGenerator", "load_scaffold"]
