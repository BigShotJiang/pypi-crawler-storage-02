from ._system import EduSystem
