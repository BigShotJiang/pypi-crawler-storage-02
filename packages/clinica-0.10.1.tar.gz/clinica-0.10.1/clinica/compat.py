try:
    import errno
except ImportError:
    from os import errno
