"""This module contains the different converters of Clinica as well as logic specific to them."""

from .factory import convert

__all__ = ["convert"]
