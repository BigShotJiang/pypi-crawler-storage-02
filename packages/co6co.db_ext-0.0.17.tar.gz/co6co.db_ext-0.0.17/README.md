# 扩展 SQLAlchemy

SQLAlchemy 原始 使用起来总是有些不方便，该项目对其进行了部分封装为两个类：
DbOperations 和 DbPagedOperations 以方便业务使用；

# (SQLALchemy Demo)[https://github.com/eastossifrage/sql_to_sqlalchemy/]

# 历史记录

```
0.0.1 初始版本
0.0.2 修复了部分 Bug
0.0.3 封装 JOIN 查询
0.0.6 2024-07-26
db_session.py  72 z
0.0.7 字符串格式
0.0.8 mapings(one)
0.0.9 优化
0.0.10
    Callable 中的类型 不能用 any需要用 Any
0.0.11
    BasePO 增加 assignment
0.0.12
    增加数据其他线程的数据库操作 -->session.BaseBll
0.0.13
    session.BaseBll 修复 connect 报错异常
0.0.14
    优化功能
0.0.15
    优化
0.0.16
	优化
0.0.17
    增加dbBll类，移除session中的DbSession、BaseBll类



```

- db_tools.execForPo

https://yifei.me/note/2652
https://www.osgeo.cn/sqlalchemy/
