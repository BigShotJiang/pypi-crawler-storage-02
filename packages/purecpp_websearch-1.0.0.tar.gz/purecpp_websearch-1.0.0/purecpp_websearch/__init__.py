from .websearch import WebSearch, Document, SearchResult, CleanerRouter, ICleaner

__all__ = ["WebSearch", "Document", "SearchResult", "CleanerRouter", "ICleaner"]
__version__ = "0.1.0"
