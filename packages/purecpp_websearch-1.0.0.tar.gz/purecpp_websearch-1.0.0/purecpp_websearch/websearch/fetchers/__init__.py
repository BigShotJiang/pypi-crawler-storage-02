from __future__ import annotations

from .http_fetcher import HttpFetcher

DefaultFetcher = HttpFetcher

__all__ = ["HttpFetcher", "DefaultFetcher"]
