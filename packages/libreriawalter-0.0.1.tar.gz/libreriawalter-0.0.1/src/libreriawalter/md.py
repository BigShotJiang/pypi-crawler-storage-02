def multiplicacion(a,b):
    return a*b

def division(a,b):
    return a/b



