from .md import multiplicacion
from .md import division
from .sr import suma
from .sr import resta
