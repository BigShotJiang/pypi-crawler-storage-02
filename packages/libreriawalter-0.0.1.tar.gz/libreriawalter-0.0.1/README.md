# Guía para usar mi libreria
## Existen 2 funciones
### md 
Donde se encuentra multiplicación y división de 2 números.
Se requieren 2 números, a y b, que se multiplican con md.multiplicar
y se dividen a/b con md.dividir.
### sr
Donde se encuentra suma y resta de 2 números.
Se requieren 2 números, a y b, que se suman con md.suma
y se restan con md.resta.