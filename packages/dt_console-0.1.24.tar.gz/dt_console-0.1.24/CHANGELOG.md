| Date     | Version | Description |
| -------- | ------- | ----------- |
| 08/02/24 | 0.1.0   | Initial upload |
| 08/08/24 | 0.1.2   | Docstrings, documentation html, ANSI code routines |
