"""Library to communicate with a Axis device."""

from .device import AxisDevice  # noqa: F401
from .errors import *  # noqa: F403
