"""Control stand alone applications of an Axis device."""

from .applications import *  # noqa: F403
