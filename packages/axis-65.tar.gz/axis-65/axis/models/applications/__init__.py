"""Control stand alone applications of an Axis device."""
