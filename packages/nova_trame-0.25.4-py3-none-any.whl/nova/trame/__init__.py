from .view.theme import ThemedApp

__all__ = ["ThemedApp"]
