import sys

from dtviz.main import main


if __name__ == '__main__':
    sys.argv[0] = 'dtviz'
    sys.exit(main())
