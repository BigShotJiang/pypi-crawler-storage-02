## Changelog

### v0.0.8

- update guppylang version requirement 0.21.0
- update hugr version requirement 0.13.0
- update quantinuum-qircheck version requirement to 0.3.0

### v0.0.7

- expose option to validate input hugr
- update guppylang version requirement 0.20.0
- update hugr version requirement 0.12.2

### v0.0.5

- update hugr_to_qir to take ModulePointer and bytes for conversion

### v0.0.4

- update guppylang version requirement 0.19.1

### v0.0.3

- update quantinuum-qircheck version requirement to 0.2.0

### v0.0.1

- add hugr_to_qir conversion function
