"""Package setup."""

__import__("setuptools").setup()
