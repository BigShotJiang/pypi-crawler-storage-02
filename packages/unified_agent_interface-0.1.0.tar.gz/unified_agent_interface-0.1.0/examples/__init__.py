# Makes the examples directory importable as a package for adapters like CrewAI
