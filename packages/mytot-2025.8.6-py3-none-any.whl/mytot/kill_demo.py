import main

main.KILL()
