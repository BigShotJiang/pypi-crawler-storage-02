Extends the previous available qty to promised with moves of a reservation
