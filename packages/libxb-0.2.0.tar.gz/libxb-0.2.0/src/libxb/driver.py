import sys

from .core.cli import CLI


def main():
    """Console app driver"""
    sys.exit(CLI.main())
