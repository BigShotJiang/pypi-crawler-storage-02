from checkmarkandcross import image


def aufgabe1_1(s: int):
    return image(s == 205)


def aufgabe1_2(z10_test: int):
    return image(z10_test == 7)


__all__ = ['aufgabe1_1', 'aufgabe1_2']
