"""
Version information for foam_gen package.
"""

__version__ = "0.1.0"
__author__ = "John Ericson"
__email__ = "jackericson98@gmail.com" 