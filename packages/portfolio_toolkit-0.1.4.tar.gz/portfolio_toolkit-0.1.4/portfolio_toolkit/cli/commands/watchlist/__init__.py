# Watchlist commands module
from .watchlist import watchlist

__all__ = ["watchlist"]
