# Copyright (C) 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Envoy package."""

from openfl.experimental.workflow.component.envoy.envoy import Envoy
