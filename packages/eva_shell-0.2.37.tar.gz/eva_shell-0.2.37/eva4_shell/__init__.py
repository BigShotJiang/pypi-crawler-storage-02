__version__ = '0.2.37'

DEFAULT_REPOSITORY_URL = 'https://pub.bma.ai/eva4'
