"""This module provides the API for the senselab extract SSL embeddings task."""

from .api import extract_ssl_embeddings_from_audios  # noqa: F401
