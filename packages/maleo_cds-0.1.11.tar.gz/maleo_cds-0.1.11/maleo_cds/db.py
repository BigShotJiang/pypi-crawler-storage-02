from maleo_soma.managers.db import create_base

MaleoCDSBase = create_base()
