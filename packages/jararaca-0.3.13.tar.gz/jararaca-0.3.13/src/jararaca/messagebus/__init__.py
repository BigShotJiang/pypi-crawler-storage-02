from .message import MessageOf

__all__ = ["MessageOf"]
