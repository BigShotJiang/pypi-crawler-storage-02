from globalgenie.memory.db.base import MemoryDb
