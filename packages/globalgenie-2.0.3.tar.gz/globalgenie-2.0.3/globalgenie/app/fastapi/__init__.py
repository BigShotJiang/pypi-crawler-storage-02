from globalgenie.app.fastapi.app import FastAPIApp

__all__ = ["FastAPIApp"]
