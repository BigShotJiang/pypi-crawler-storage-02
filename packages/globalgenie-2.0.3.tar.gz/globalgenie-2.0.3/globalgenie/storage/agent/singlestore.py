from globalgenie.storage.singlestore import SingleStoreStorage as SingleStoreAgentStorage  # noqa: F401
