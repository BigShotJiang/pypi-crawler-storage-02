from globalgenie.vectordb.couchbase.couchbase import CouchbaseSearch

__all__ = ["CouchbaseSearch"]
