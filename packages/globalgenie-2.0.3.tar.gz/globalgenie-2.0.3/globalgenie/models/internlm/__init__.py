from globalgenie.models.internlm.internlm import InternLM

__all__ = ["InternLM"]
