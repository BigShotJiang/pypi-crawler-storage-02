from globalgenie.models.huggingface.huggingface import HuggingFace

__all__ = [
    "HuggingFace",
]
