# ArticleStatusCustomer

The status of the article: 0 - Draft, 3 - Published

## Enum

* `NUMBER_0` (value: `0`)

* `NUMBER_3` (value: `3`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


