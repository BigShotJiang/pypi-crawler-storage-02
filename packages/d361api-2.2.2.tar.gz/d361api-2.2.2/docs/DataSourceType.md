# DataSourceType


## Enum

* `NUMBER_0` (value: `0`)

* `NUMBER_1` (value: `1`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


