# ArticleStaleStatus

The status of the article: 0 - None, 1 - New, 2 - Updated, 3 - Custom

## Enum

* `NUMBER_0` (value: `0`)

* `NUMBER_1` (value: `1`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


