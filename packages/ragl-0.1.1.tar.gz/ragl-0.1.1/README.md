# ragl -- A Python library for storage and retrieval of text embeddings

ragl is in a pre-releae state. While the code is functional, testing and documentation are still in progress, and there may be breaking changes to the code as integration tests are added.

ragl is being actively developed and will soon be released; check here for updates.
