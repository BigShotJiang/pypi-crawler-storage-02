import logging

log = logging.getLogger(name='ttkplus')
