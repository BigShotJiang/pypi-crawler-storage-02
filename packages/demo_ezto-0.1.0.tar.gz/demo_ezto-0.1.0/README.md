# Project Setup Tool

Install with `uv pip install demo_ezto`.

Then, in an empty directory, run `demo_ezto create` to set up the FastAPI project.