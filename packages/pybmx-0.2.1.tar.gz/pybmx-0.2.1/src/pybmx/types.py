import ctypes
import typing as t

U8: t.TypeAlias = ctypes.c_uint8
S8: t.TypeAlias = ctypes.c_int8
S16: t.TypeAlias = ctypes.c_int16
U16: t.TypeAlias = ctypes.c_uint16
S32: t.TypeAlias = ctypes.c_int32
U32: t.TypeAlias = ctypes.c_uint32
