class Gb2SeqError(Exception):
    "A gb2seq library error occurred."


__version__ = "0.3.0"
