Some Python3 tools.
