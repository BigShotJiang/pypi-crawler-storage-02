If you want to get in touch we're always open to feedback and suggestions.

## General Contact

Our general contact email for any questions/suggestions for the team:

neptoon-contact@ufz.de