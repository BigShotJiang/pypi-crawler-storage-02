from .hub import CRNSDataHub


VERSION = 'v0.12.1'

__version__ = VERSION
