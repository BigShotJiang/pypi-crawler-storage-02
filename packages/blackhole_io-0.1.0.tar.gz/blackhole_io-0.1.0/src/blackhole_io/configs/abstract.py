from pydantic import BaseModel


class AbstractConfig(BaseModel):
    pass
