# flake8: noqa F401
from .simple_average import DareSimpleAverage
from .task_arithmetic import DareTaskArithmetic
from .ties_merging import DareTiesMerging
