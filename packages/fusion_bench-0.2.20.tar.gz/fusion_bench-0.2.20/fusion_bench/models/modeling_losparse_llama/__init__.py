# flake8: noqa F401
from . import register
from .configuration_losparse_llama import LoSparseLlamaConfig
from .modeling_losparse_llama import LoSparseLlamaForCausalLM, LoSparseLlamaModel
