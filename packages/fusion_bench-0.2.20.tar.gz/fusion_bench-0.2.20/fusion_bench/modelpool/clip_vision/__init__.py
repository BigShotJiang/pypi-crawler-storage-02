from .modelpool import CLIPVisionModelPool
