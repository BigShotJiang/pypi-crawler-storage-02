# Image Classification Dataset Configurations

This folder contains the dataset configuration for image classification tasks.

- Each dataset should have 'image' and 'label' columns.
- If a dataset has no test split, we will use the validation split as the test split and create the validation set from the training set.
