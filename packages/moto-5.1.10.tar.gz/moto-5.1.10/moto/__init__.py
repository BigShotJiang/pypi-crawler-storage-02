from moto.core.decorator import mock_aws as mock_aws

__title__ = "moto"
__version__ = "5.1.10"
