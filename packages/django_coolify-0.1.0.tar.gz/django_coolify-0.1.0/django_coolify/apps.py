from django.apps import AppConfig


class DjangoCoolifyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_coolify"
    verbose_name = "Django Coolify"
