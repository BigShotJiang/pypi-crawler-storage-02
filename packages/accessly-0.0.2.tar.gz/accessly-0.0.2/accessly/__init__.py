# imp the key functions that users will interact with
from .core import configure, register_feature
