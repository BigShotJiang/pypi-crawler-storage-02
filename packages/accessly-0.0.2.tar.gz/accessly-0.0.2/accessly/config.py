# store global settings and feature registry
settings = {}  # user-defined settings like {"colorblind": "protanopia"}
show_hooks = []

registered_features = {}  # maps "feature_name" -> apply_function
