"""app-pytorch: A Flower / PyTorch app."""
