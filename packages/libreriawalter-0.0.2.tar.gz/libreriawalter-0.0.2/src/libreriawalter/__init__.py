from .md import multiplicacion
from .md import division
from .md import potencia
from .sr import suma
from .sr import resta
