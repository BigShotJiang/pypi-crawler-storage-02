import logging

logger = logging.getLogger("netconf_client")
