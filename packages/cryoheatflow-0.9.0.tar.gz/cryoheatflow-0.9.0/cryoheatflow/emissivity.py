

#%% Radiative heat transfer black body

mylar = 0.05
# Emissivities from Ekin Appendix A2.2
Al_polished = 0.03
Al_oxidized = 0.3
Cu_polished = 0.02
Cu_oxidized = 0.6
brass_polished = 0.03
brass_oxidized = 0.6
stainless = 0.07
