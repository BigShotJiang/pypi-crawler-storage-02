Plot 2D histograms
------------------

Gallery of images that are used in the section about plotting 2D histograms.
