Plot 1D histograms
------------------

Gallery of images that are used in the 1D histogram section.
