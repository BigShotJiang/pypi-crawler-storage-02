Model and data
--------------

Gallery of images that are used in the plotting model and data section.
