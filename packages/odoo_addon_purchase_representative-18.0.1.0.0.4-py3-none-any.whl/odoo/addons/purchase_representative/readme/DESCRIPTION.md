This module makes the field *Purchase Representative* in Purchase Orders
default to the user doing a procurement to overcome the known flaw of
Odoo user in the transaction when using SUPERUSER_ID.
