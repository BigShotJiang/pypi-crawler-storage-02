Just set the *Purchase Representative* in the Purchase Order header.
Then when sending the RFQ/PO to the vendor the Purchase Representative
will be the contact person (email from and reply to).
