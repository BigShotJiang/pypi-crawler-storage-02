# Ambassadors

The NATS ambassador program recognizes community members that go above and beyond in their contributions to the community and the ecosystem. Learn more [here](https://nats.io/community#nats-ambassador-program).

- [Maurice van Veen](https://nats.io/community#maurice-van-veen) <contact@mauricevanveen.com>
