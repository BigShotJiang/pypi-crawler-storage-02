"""Singer tap for extracting data from Dune Analytics API."""

__version__ = "0.1.0"