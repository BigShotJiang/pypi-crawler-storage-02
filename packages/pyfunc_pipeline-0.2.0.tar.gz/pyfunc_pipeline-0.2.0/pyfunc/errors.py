class PipelineError(Exception):
    """Custom exception for Pipeline errors."""
    pass
