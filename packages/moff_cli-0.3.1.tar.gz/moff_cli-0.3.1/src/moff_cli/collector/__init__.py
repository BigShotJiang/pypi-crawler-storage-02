"""Collector module for moff-cli."""

from .collector import Collector

__all__ = ["Collector"]
