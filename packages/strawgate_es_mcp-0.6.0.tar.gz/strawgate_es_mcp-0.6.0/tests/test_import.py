def test_import():
    import strawgate_es_mcp

    assert strawgate_es_mcp is not None
