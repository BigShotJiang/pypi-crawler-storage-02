"""External resources for :mod:`curies_processing`."""

from .goc import load_goc_map

__all__ = [
    "load_goc_map",
]
