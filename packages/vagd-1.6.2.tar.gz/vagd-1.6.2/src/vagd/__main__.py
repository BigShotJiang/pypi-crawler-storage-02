import vagd.cli as cli

if __name__ == "__main__":
  cli.start()
