"""Segmenter based on Spacy"""
__version__ = "0.5.168"
