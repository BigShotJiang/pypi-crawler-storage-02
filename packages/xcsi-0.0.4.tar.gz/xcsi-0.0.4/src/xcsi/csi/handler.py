
class Handler:
    def __init__(self, converter, tables, model):
        self._converter = converter
        self._tables = tables
        self._model = model

