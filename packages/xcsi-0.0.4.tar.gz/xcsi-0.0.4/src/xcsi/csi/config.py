
enhancements = [
    {"type": "Frame", "name": 32, "apply": ["Geometry.PDelta"]},
    {"type": "Frame", "name": 33, "apply": ["Geometry.PDelta"]}
]
