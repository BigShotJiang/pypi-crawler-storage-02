"""cmem-plugin-pgvector"""
