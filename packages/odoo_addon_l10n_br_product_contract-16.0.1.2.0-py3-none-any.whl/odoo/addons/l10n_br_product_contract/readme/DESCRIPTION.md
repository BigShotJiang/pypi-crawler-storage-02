This module extends the functionality of product_contact to support
l10n_br_contract and to allow you to create fiscal documents with the
same fiscal configuration of the sale orders.
