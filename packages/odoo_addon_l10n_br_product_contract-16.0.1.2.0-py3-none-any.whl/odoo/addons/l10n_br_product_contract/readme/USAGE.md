To use this module, you need to:

1.  Configure the product type as service.
2.  Configure the products as contracts;
3.  Create a sale order, with this product and confirm.
