Release Notes
=============

Release notes for `openstacksdk` can be found at
https://releases.openstack.org/teams/openstacksdk.html
