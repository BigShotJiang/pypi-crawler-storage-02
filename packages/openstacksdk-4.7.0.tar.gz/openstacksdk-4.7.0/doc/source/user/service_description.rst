ServiceDescription
==================
.. automodule:: openstack.service_description


ServiceDescription object
-------------------------

.. autoclass:: openstack.service_description.ServiceDescription
   :members:
