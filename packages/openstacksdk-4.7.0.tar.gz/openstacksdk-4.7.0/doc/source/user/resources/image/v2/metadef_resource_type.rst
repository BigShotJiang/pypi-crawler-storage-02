openstack.image.v2.metadef_resource_type
========================================

.. automodule:: openstack.image.v2.metadef_resource_type

The MetadefResourceType Class
-----------------------------

The ``MetadefResourceType`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.metadef_resource_type.MetadefResourceType
   :members:


The MetadefResourceTypeAssociation Class
----------------------------------------

The ``MetadefResourceTypeAssociation`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass::
    openstack.image.v2.metadef_resource_type.MetadefResourceTypeAssociation
    :members:
