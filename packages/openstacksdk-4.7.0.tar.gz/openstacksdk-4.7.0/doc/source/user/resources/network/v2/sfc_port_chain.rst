openstack.network.v2.sfc_port_chain
===================================

.. automodule:: openstack.network.v2.sfc_port_chain

The SfcPortChain Class
----------------------

The ``SfcPortChain`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.sfc_port_chain.SfcPortChain
   :members:
