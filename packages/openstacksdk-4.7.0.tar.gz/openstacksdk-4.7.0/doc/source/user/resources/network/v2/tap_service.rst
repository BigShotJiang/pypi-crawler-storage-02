openstack.network.v2.tap_service
================================

.. automodule:: openstack.network.v2.tap_service

The TapService Class
--------------------

The ``TapService`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.tap_service.TapService
   :members:
