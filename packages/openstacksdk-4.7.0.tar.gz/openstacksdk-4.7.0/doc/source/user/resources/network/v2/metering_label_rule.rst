openstack.network.v2.metering_label_rule
========================================

.. automodule:: openstack.network.v2.metering_label_rule

The MeteringLabelRule Class
---------------------------

The ``MeteringLabelRule`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.metering_label_rule.MeteringLabelRule
   :members:
