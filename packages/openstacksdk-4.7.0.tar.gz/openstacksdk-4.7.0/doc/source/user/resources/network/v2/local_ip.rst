openstack.network.v2.local_ip
=============================

.. automodule:: openstack.network.v2.local_ip

The LocalIP Class
-----------------

The ``LocalIP`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.local_ip.LocalIP
   :members:
