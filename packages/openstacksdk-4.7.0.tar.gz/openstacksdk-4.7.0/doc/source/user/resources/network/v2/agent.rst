openstack.network.v2.agent
==========================

.. automodule:: openstack.network.v2.agent

The Agent Class
---------------

The ``Agent`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.agent.Agent
   :members:
