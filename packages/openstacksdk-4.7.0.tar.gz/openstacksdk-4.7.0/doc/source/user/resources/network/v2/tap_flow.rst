openstack.network.v2.tap_flow
=============================

.. automodule:: openstack.network.v2.tap_flow

The TapFlow Class
-----------------

The ``TapFlow`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.tap_flow.TapFlow
   :members:
