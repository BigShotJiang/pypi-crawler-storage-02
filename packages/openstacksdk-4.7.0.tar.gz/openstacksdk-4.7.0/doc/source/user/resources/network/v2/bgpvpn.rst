openstack.network.v2.bgpvpn
=============================

.. automodule:: openstack.network.v2.bgpvpn

The BgpVpn Class
-----------------

The ``BgpVpn`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.bgpvpn.BgpVpn
   :members:
