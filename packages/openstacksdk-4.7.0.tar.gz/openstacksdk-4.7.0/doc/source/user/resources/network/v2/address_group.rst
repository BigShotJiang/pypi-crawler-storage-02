openstack.network.v2.address_group
==================================

.. automodule:: openstack.network.v2.address_group

The AddressGroup Class
----------------------

The ``AddressGroup`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.address_group.AddressGroup
   :members:
