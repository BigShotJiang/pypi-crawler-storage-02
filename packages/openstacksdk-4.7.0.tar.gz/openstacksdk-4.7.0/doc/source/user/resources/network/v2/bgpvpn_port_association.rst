openstack.network.v2.bgpvpn_port_association
============================================

.. automodule:: openstack.network.v2.bgpvpn_port_association

The BgpVpnPortAssociation Class
-------------------------------

The ``BgpVpnPortAssociation`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.bgpvpn_port_association.BgpVpnPortAssociation
   :members:
