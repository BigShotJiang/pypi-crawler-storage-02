openstack.network.v2.sfc_flow_classifier
========================================

.. automodule:: openstack.network.v2.sfc_flow_classifier

The SfcFlowClassifier Class
---------------------------

The ``SfcFlowClassifier`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.sfc_flow_classifier.SfcFlowClassifier
   :members:
