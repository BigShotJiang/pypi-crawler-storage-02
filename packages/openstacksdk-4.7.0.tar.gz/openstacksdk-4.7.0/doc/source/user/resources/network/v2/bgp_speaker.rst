openstack.network.v2.bgp_speaker
================================

.. automodule:: openstack.network.v2.bgp_speaker

The BgpSpeaker Class
--------------------

The ``BgpSpeaker`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.bgp_speaker.BgpSpeaker
   :members:
