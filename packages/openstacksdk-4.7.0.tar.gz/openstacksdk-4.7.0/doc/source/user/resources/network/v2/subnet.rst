openstack.network.v2.subnet
===========================

.. automodule:: openstack.network.v2.subnet

The Subnet Class
----------------

The ``Subnet`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.subnet.Subnet
   :members:
