openstack.network.v2.vpn_ike_policy
===================================

.. automodule:: openstack.network.v2.vpn_ike_policy

The VpnIkePolicy Class
----------------------

The ``VpnIkePolicy`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.vpn_ike_policy.VpnIkePolicy
   :members:
