openstack.network.v2.qos_packet_rate_limit_rule
===============================================

.. automodule:: openstack.network.v2.qos_packet_rate_limit_rule

The QoSPacketRateLimitRule Class
----------------------------------

The ``QoSPacketRateLimitRule`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.qos_packet_rate_limit_rule.QoSPacketRateLimitRule
   :members:
