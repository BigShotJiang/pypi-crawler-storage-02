openstack.network.v2.router
===========================

.. automodule:: openstack.network.v2.router

The Router Class
----------------

The ``Router`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.router.Router
   :members:
