openstack.network.v2.bgpvpn_network_association
===============================================

.. automodule:: openstack.network.v2.bgpvpn_network_association

The BgpVpnNetworkAssociation Class
----------------------------------

The ``BgpVpnNetworkAssociation`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.bgpvpn_network_association.BgpVpnNetworkAssociation
   :members:
