openstack.network.v2.sfc_port_pair_group
========================================

.. automodule:: openstack.network.v2.sfc_port_pair_group

The SfcPortPairGroup Class
--------------------------

The ``SfcPortPairGroup`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.sfc_port_pair_group.SfcPortPairGroup
   :members:
