openstack.network.v2.address_scope
==================================

.. automodule:: openstack.network.v2.address_scope

The AddressScope Class
----------------------

The ``AddressScope`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.address_scope.AddressScope
   :members:
