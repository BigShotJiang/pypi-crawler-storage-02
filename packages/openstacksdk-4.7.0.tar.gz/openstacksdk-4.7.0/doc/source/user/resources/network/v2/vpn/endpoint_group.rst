openstack.network.v2.vpn_endpoint_group
=======================================

.. automodule:: openstack.network.v2.vpn_endpoint_group

The VpnEndpointGroup Class
--------------------------

The ``VpnEndpointGroup`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.vpn_endpoint_group.VpnEndpointGroup
   :members:
