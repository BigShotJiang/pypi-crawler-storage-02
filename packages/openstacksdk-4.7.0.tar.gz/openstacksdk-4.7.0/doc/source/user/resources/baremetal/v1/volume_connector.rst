openstack.baremetal.v1.volume_connector
=======================================

.. automodule:: openstack.baremetal.v1.volume_connector

The VolumeConnector Class
-------------------------

The ``VolumeConnector`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.volume_connector.VolumeConnector
   :members:
