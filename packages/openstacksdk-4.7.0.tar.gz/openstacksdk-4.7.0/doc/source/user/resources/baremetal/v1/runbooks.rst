openstack.baremetal.v1.runbooks
===============================

.. automodule:: openstack.baremetal.v1.runbooks

The Runbook Class
-----------------

The ``Runbook`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.runbooks.Runbook
   :members:
