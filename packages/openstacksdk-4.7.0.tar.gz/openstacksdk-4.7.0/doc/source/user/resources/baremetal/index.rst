Baremetal Resources
===================

.. toctree::
   :maxdepth: 1

   v1/driver
   v1/chassis
   v1/node
   v1/port
   v1/port_group
   v1/allocation
   v1/volume_connector
   v1/volume_target
   v1/deploy_templates
   v1/conductor
   v1/runbooks
   v1/inspection_rules
