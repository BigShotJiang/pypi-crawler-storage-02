openstack.placement.v1.resource_provider_inventory
==================================================

.. automodule:: openstack.placement.v1.resource_provider_inventory

The ResourceProviderInventory Class
-----------------------------------

The ``ResourceProviderInventory`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.placement.v1.resource_provider_inventory.ResourceProviderInventory
   :members:
