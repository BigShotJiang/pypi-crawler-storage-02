openstack.placement.v1.resource_class
=====================================

.. automodule:: openstack.placement.v1.resource_class

The ResourceClass Class
-----------------------

The ``ResourceClass`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.placement.v1.resource_class.ResourceClass
   :members:
