openstack.dns.v2.zone_share
===========================

.. automodule:: openstack.dns.v2.zone_share

The ZoneShare Class
-------------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.zone_share.ZoneShare
   :members:
