openstack.dns.v2.floating_ip
============================

.. automodule:: openstack.dns.v2.floating_ip

The FloatingIP Class
--------------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.floating_ip.FloatingIP
   :members:
