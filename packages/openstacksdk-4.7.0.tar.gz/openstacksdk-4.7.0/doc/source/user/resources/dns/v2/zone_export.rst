openstack.dns.v2.zone_export
============================

.. automodule:: openstack.dns.v2.zone_export

The ZoneExport Class
--------------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.zone_export.ZoneExport
   :members:
