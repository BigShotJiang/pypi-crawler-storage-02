openstack.dns.v2.zone_transfer
==============================

.. automodule:: openstack.dns.v2.zone_transfer

The ZoneTransferRequest Class
-----------------------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.zone_transfer.ZoneTransferRequest
   :members:

The ZoneTransferAccept Class
----------------------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.zone_transfer.ZoneTransferAccept
   :members:
