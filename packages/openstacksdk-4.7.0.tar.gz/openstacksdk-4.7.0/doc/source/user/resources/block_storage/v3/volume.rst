openstack.block_storage.v3.volume
=================================

.. automodule:: openstack.block_storage.v3.volume

The Volume Class
----------------

The ``Volume`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.volume.Volume
   :members:
