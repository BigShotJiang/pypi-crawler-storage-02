openstack.block_storage.v3.group_type
=====================================

.. automodule:: openstack.block_storage.v3.group_type

The GroupType Class
-------------------

The ``GroupType`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.group_type.GroupType
   :members:
