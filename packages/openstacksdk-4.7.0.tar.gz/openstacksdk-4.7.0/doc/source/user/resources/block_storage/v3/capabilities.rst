openstack.block_storage.v3.capabilities
=======================================

.. automodule:: openstack.block_storage.v3.capabilities

The Capabilities Class
----------------------

The ``Capabilities`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.capabilities.Capabilities
   :members:
