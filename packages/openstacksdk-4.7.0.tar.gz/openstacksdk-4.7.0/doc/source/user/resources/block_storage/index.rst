Block Storage Resources
=======================

Block Storage v2 Resources
--------------------------

.. toctree::
   :maxdepth: 1
   :glob:

   v2/*

Block Storage v3 Resources
--------------------------

.. toctree::
   :maxdepth: 1
   :glob:

   v3/*
