openstack.block_storage.v3.availability_zone
============================================

.. automodule:: openstack.block_storage.v3.availability_zone

The AvailabilityZone Class
--------------------------

The ``AvailabilityZone`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.availability_zone.AvailabilityZone
   :members:
