openstack.block_storage.v3.transfer
===================================

.. automodule:: openstack.block_storage.v3.transfer

The Volume Transfer Class
-------------------------

The ``Volume Transfer`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.transfer.Transfer
   :members:
