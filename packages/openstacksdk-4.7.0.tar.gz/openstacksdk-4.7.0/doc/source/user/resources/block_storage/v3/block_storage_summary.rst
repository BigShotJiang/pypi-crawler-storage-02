openstack.block_storage.v3.block_storage_summary
================================================

.. automodule:: openstack.block_storage.v3.block_storage_summary

The Block Storage Summary Class
-------------------------------

The ``Block Storage Summary`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.block_storage_summary.BlockStorageSummary
   :members:

