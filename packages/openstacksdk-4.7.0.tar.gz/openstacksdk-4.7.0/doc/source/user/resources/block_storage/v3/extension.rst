openstack.block_storage.v3.extension
====================================

.. automodule:: openstack.block_storage.v3.extension

The Extension Class
-------------------

The ``Extension`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v3.extension.Extension
   :members:
