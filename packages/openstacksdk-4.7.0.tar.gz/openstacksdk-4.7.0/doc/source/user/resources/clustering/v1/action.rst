openstack.clustering.v1.action
==============================

.. automodule:: openstack.clustering.v1.action

The Action Class
----------------

The ``Action`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.clustering.v1.action.Action
   :members:
