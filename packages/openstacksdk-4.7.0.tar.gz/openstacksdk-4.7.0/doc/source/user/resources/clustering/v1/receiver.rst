openstack.clustering.v1.receiver
================================

.. automodule:: openstack.clustering.v1.receiver

The Receiver Class
------------------

The ``Receiver`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.clustering.v1.receiver.Receiver
   :members:
