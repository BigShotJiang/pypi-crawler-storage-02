openstack.clustering.v1.Cluster
===============================

.. automodule:: openstack.clustering.v1.cluster

The Cluster Class
-----------------

The ``Cluster`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.clustering.v1.cluster.Cluster
   :members:
