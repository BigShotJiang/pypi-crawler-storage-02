openstack.shared_file_system.v2.share_network
=============================================

.. automodule:: openstack.shared_file_system.v2.share_network

The ShareNetwork Class
----------------------

The ``ShareNetwork`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_network.ShareNetwork
   :members:
