openstack.shared_file_system.v2.availability_zone
=================================================

.. automodule:: openstack.shared_file_system.v2.availability_zone

The AvailabilityZone Class
--------------------------

The ``AvailabilityZone`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.availability_zone.AvailabilityZone
   :members:
