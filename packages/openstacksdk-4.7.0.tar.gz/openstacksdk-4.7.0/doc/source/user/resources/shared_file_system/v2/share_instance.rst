openstack.shared_file_system.v2.share_instance
==============================================

.. automodule:: openstack.shared_file_system.v2.share_instance

The ShareInstance Class
-----------------------

The ``ShareInstance`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_instance.ShareInstance
   :members:
