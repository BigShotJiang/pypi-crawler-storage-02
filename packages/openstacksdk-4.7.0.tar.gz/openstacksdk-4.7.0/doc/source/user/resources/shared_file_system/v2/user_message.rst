openstack.shared_file_system.v2.user_message
============================================

.. automodule:: openstack.shared_file_system.v2.user_message

The UserMessage Class
---------------------

The ``UserMessage`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.user_message.UserMessage
   :members:
