openstack.shared_file_system.v2.share_access_rule
=================================================

.. automodule:: openstack.shared_file_system.v2.share_access_rule

The ShareAccessRule Class
-------------------------

The ``ShareAccessRule`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_access_rule.ShareAccessRule
   :members:
