openstack.shared_file_system.v2.quota_class_set
===============================================

.. automodule:: openstack.shared_file_system.v2.quota_class_set

The QuotaClassSet Class
-----------------------

The ``QuotaClassSet`` class inherits from
:class:`~openstack.resource.Resource` and can be used to query quota class

.. autoclass:: openstack.shared_file_system.v2.quota_class_set.QuotaClassSet
    :members:
