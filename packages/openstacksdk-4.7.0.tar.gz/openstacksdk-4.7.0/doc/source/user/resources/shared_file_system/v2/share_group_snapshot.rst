openstack.shared_file_system.v2.share_group_snapshot
====================================================

.. automodule:: openstack.shared_file_system.v2.share_group_snapshot

The ShareGroupSnapshot Class
----------------------------

The ``ShareGroupSnapshot`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share_group_snapshot.ShareGroupSnapshot
   :members:
