openstack.shared_file_system.v2.limit
=====================================

.. automodule:: openstack.shared_file_system.v2.limit

The Limit Class
---------------

The ``Limit`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.limit.Limit
   :members:
