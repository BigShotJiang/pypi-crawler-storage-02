openstack.shared_file_system.v2.share
=====================================

.. automodule:: openstack.shared_file_system.v2.share

The Share Class
---------------

The ``Share`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.share.Share
   :members:
