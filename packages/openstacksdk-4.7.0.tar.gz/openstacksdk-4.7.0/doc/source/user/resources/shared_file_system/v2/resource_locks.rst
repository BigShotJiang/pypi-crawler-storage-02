openstack.shared_file_system.v2.resource_locks
==============================================

.. automodule:: openstack.shared_file_system.v2.resource_locks

The Resource Locks Class
------------------------

The ``ResourceLock`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.shared_file_system.v2.resource_locks.ResourceLock
   :members:
