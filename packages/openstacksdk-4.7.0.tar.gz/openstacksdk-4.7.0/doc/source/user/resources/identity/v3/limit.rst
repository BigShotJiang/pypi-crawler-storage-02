openstack.identity.v3.limit
===========================

.. automodule:: openstack.identity.v3.limit

The Limit Class
---------------

The ``Limit`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.limit.Limit
   :members:
