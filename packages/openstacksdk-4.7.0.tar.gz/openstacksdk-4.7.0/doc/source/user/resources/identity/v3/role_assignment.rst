openstack.identity.v3.role_assignment
=====================================

.. automodule:: openstack.identity.v3.role_assignment

The RoleAssignment Class
------------------------

The ``RoleAssignment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.role_assignment.RoleAssignment
   :members:
