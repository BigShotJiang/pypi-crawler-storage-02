openstack.identity.v3.system
============================

.. automodule:: openstack.identity.v3.system

The System Class
----------------

The ``System`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.system.System
   :members:
