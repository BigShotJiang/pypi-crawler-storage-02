openstack.identity.v3.identity_provider
=======================================

.. automodule:: openstack.identity.v3.identity_provider

The IdentityProvider Class
--------------------------

The ``IdentityProvider`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.identity_provider.IdentityProvider
   :members:
