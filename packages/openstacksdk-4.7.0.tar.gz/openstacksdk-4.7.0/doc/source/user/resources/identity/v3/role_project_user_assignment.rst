openstack.identity.v3.role_project_user_assignment
==================================================

.. automodule:: openstack.identity.v3.role_project_user_assignment

The RoleProjectUserAssignment Class
-----------------------------------

The ``RoleProjectUserAssignment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.role_project_user_assignment.RoleProjectUserAssignment
   :members:
