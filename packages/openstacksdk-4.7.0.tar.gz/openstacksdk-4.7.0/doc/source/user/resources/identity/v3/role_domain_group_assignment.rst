openstack.identity.v3.role_domain_group_assignment
==================================================

.. automodule:: openstack.identity.v3.role_domain_group_assignment

The RoleDomainGroupAssignment Class
-----------------------------------

The ``RoleDomainGroupAssignment`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.role_domain_group_assignment.RoleDomainGroupAssignment
   :members:
