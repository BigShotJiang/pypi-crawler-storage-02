openstack.compute.v2.quota_set
==============================

.. automodule:: openstack.compute.v2.quota_set

The QuotaSet Class
------------------

The ``QuotaSet`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.quota_set.QuotaSet
   :members:
