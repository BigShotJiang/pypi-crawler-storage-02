openstack.compute.v2.hypervisor
===============================

.. automodule:: openstack.compute.v2.hypervisor

The Hypervisor Class
--------------------

The ``Hypervisor`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.hypervisor.Hypervisor
   :members:
