openstack.compute.v2.migration
==============================

.. automodule:: openstack.compute.v2.migration

The Migration Class
-------------------

The ``Migration`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.migration.Migration
   :members:
