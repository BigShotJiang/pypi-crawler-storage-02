openstack.compute.v2.server_action
==================================

.. automodule:: openstack.compute.v2.server_action

The ServerAction Class
----------------------

The ``ServerAction`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_action.ServerAction
   :members:

The ServerActionEvent Class
---------------------------

The ``ServerActionEvent`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_action.ServerActionEvent
   :members:
