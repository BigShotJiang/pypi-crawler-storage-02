openstack.compute.version
=========================

.. automodule:: openstack.compute.version

The Version Class
-----------------

The ``Version`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.version.Version
   :members:
