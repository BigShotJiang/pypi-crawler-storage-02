openstack.compute.v2.availability_zone
======================================

.. automodule:: openstack.compute.v2.availability_zone

The AvailabilityZone Class
--------------------------

The ``AvailabilityZone`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.availability_zone.AvailabilityZone
   :members:
