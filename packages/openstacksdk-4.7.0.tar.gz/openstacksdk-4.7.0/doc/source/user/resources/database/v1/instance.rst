openstack.database.v1.instance
==============================

.. automodule:: openstack.database.v1.instance

The Instance Class
------------------

The ``Instance`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.database.v1.instance.Instance
   :members:
