openstack.baremetal_introspection.v1.introspection_rule
========================================================

.. automodule:: openstack.baremetal_introspection.v1.introspection_rule

The IntrospectionRule Class
----------------------------

The ``IntrospectionRule`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal_introspection.v1.introspection_rule.IntrospectionRule
   :members:
