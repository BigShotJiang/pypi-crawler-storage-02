openstack.container_infrastructure_management.v1.cluster_template
=================================================================

.. automodule:: openstack.container_infrastructure_management.v1.cluster_template

The Cluster Template Class
--------------------------

The ``ClusterTemplate`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.container_infrastructure_management.v1.cluster_template.ClusterTemplate
   :members:
