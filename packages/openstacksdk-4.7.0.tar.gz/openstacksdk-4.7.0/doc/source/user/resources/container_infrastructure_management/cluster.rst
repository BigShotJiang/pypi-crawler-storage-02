openstack.container_infrastructure_management.v1.cluster
========================================================

.. automodule:: openstack.container_infrastructure_management.v1.cluster

The Cluster Class
------------------

The ``Cluster`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.container_infrastructure_management.v1.cluster.Cluster
   :members:
