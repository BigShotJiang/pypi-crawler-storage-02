openstack.orchestration.v1.stack_event
======================================

.. automodule:: openstack.orchestration.v1.stack_event

The StackEvent Class
--------------------

The ``StackEvent`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.orchestration.v1.stack_event.StackEvent
   :members:
