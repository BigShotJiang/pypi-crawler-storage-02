openstack.orchestration.v1.template
===================================

.. automodule:: openstack.orchestration.v1.template

The Template Class
------------------

The ``Template`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.orchestration.v1.template.Template
   :members:
