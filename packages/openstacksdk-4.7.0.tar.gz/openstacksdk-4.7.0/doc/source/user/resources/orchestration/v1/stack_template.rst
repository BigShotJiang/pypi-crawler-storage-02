openstack.orchestration.v1.stack_template
=========================================

.. automodule:: openstack.orchestration.v1.stack_template

The StackTemplate Class
-----------------------

The ``StackTemplate`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.orchestration.v1.stack_template.StackTemplate
   :members:
