openstack.accelerator.v2.attribute
==================================

.. automodule:: openstack.accelerator.v2.attribute

The Attribute Class
-------------------

The ``Attribute`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.accelerator.v2.attribute.Attribute
   :members:
