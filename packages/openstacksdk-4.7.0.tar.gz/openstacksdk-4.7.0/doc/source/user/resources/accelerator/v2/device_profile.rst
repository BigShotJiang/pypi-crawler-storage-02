openstack.accelerator.v2.device_profile
=======================================

.. automodule:: openstack.accelerator.v2.device_profile

The DeviceProfile Class
-----------------------

The ``DeviceProfile`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.accelerator.v2.device_profile.DeviceProfile
   :members:

