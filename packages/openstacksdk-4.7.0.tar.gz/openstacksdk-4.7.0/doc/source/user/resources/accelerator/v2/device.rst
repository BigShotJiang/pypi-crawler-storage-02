openstack.accelerator.v2.device
===============================

.. automodule:: openstack.accelerator.v2.device

The Device Class
----------------

The ``Device`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.accelerator.v2.device.Device
   :members:

