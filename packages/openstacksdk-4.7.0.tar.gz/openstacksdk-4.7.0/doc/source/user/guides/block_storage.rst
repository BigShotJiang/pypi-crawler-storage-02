Using OpenStack Block Storage
=============================

Before working with the Block Storage service, you'll need to create a
connection to your OpenStack cloud by following the :doc:`connect` user
guide. This will provide you with the ``conn`` variable used in the examples
below.

.. TODO(thowe): Implement this guide
