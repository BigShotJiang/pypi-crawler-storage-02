# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from openstack import resource


class AvailabilityZone(resource.Resource):
    resource_key = ""
    resources_key = "availabilityZoneInfo"
    base_path = "/os-availability-zone"

    # capabilities
    allow_list = True

    #: Properties
    #: Name of availability zone
    name = resource.Body("zoneName", type=str)
    #: State of availability zone, "available" is usual key
    state = resource.Body("zoneState", type=dict)
