from setuptools import setup

setup(
    name='android-mobile-mcp',
    version='2.0.0',
    author='erichung0906',
    author_email='rthung96@gmail.com',
    description='Android Mobile MCP',
    url='https://github.com/erichung9060/Android-Mobile-MCP',
    keywords=['android', "mobile", "mcp", "mobile-mcp", "android-mcp"],
)