from lgtm_ai.ai.schemas import SupportedAIModels

DEFAULT_AI_MODEL: SupportedAIModels = "gemini-2.0-flash"
