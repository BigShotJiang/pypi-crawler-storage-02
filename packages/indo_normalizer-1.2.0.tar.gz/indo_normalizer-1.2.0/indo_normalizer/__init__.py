# __init__.py

# Metadata
__version__ = '0.1.0'
__author__ = 'Drestanto Muhammad Dyasputro'
__author_email__ = 'dyas@live.com'
__license__ = 'MIT'

from .Normalizer import Normalizer