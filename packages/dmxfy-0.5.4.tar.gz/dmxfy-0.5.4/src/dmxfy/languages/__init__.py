# src/dmxfy/languages/__init__.py
from .languages import LANGUAGES

__all__ = ["LANGUAGES"]
