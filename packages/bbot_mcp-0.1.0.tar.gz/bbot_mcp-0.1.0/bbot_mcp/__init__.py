"""BBOT MCP Server - MCP server for BBOT security scanner"""

__version__ = "0.1.0"
__author__ = "Vlatko Kosturjak"
__email__ = "vlatko.kosturjak@marlink.com"