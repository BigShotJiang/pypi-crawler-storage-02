Module blaxel.core.client.api.knowledgebases
============================================

Sub-modules
-----------
* blaxel.core.client.api.knowledgebases.create_knowledgebase
* blaxel.core.client.api.knowledgebases.delete_knowledgebase
* blaxel.core.client.api.knowledgebases.get_knowledgebase
* blaxel.core.client.api.knowledgebases.list_knowledgebase_revisions
* blaxel.core.client.api.knowledgebases.list_knowledgebases
* blaxel.core.client.api.knowledgebases.update_knowledgebase