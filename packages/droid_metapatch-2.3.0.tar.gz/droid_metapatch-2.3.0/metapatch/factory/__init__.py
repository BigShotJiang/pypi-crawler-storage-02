"""Template sub-module."""

from .boilerplate import generate_snippet, generate_boilerplate


__all__ = ["generate_boilerplate", "generate_snippet"]
