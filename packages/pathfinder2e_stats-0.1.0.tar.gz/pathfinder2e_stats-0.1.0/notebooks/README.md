# Tutorial notebooks

This is a collection of demo Jupyter notebooks that show off the power of
`pathfinder2e_stats`.

You can find a pre-rendered version
[in the documentation](https://pathfinder2e-stats.readthedocs.io/en/latest/notebooks/index.html).
