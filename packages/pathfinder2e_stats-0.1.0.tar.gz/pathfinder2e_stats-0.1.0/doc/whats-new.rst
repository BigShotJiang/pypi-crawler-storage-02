.. currentmodule:: pathfinder2e_stats

What's New
==========

.. _whats-new.0.1.0:

v0.1.0 (2025-08-08)
-------------------

Initial release.
