from cyclopts import App

mlflow_app = App(
    help="Debug with MLflow",
)
