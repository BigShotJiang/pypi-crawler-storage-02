"""Template generators for scaffolding."""
