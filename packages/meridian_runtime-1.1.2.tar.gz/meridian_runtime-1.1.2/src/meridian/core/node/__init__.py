from __future__ import annotations

from .base import Node

__all__ = ["Node"]
