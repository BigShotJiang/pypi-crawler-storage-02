from __future__ import annotations

from .definition import Edge

__all__ = ["Edge"]
