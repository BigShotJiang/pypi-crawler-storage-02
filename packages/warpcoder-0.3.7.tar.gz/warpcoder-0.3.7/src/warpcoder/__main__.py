#!/usr/bin/env python3
"""
Allow running warpcoder as a module: python -m warpcoder
"""

from .main import main

if __name__ == "__main__":
    main()