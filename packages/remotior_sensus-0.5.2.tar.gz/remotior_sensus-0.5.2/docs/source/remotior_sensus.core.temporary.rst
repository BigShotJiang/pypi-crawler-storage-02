remotior\_sensus.core.temporary module
======================================

.. automodule:: remotior_sensus.core.temporary
   :members:
   :undoc-members:
   :show-inheritance:
