remotior\_sensus.core.table\_manager module
===========================================

.. automodule:: remotior_sensus.core.table_manager
   :members:
   :undoc-members:
   :show-inheritance:
