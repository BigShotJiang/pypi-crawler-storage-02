remotior\_sensus.core.spectral\_signatures module
=================================================

.. automodule:: remotior_sensus.core.spectral_signatures
   :members:
   :undoc-members:
   :show-inheritance:
