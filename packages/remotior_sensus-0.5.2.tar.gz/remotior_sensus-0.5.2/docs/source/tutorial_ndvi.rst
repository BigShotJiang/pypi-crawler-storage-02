Download Sentinel-2 Data and Calculate NDVI
===========================================

.. raw:: html

    <script src="https://gist.github.com/semiautomaticgit/e20479e1cbfbf76f078bfb4f211f23fa.js"></script>

Link to the guide:
https://colab.research.google.com/gist/semiautomaticgit/e20479e1cbfbf76f078bfb4f211f23fa/download_sentinel-2_data_and_calculate_ndvi.ipynb
