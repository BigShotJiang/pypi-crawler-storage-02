remotior\_sensus.tools.band\_erosion module
===========================================

.. automodule:: remotior_sensus.tools.band_erosion
   :members:
   :undoc-members:
   :show-inheritance:
