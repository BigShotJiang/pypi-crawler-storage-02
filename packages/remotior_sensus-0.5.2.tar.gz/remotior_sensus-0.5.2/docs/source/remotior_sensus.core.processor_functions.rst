remotior\_sensus.core.processor\_functions module
=================================================

.. automodule:: remotior_sensus.core.processor_functions
   :members:
   :undoc-members:
   :show-inheritance:
