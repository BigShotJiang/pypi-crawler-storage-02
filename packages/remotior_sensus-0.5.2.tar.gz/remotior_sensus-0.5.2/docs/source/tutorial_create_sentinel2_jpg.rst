Create Sentinel-2 jpg file
===========================================

.. raw:: html

    <script src="https://gist.github.com/semiautomaticgit/0eb0a3e0e9794b66f162a46455b8a00d.js"></script>

Link to the guide:
https://colab.research.google.com/gist/semiautomaticgit/0eb0a3e0e9794b66f162a46455b8a00d/create_sentinel2_jpg.ipynb