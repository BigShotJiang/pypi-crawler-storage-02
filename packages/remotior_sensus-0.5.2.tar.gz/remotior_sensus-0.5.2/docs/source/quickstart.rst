Quickstart
===========================================

Following the video of the tutorial.

https://www.youtube.com/watch?v=uv264j_oclU

.. raw:: html

    <iframe allowfullscreen="" frameborder="0" height="360" src="https://www.youtube.com/embed/uv264j_oclU?rel=0" width="100%"></iframe>


.. raw:: html

    <script src="https://gist.github.com/semiautomaticgit/0fdb7c2c5c0b3b990cf342d226b8ee43.js"></script>

Link to the guide:
https://colab.research.google.com/gist/semiautomaticgit/0fdb7c2c5c0b3b990cf342d226b8ee43/quickstart.ipynb
