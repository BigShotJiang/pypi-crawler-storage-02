remotior\_sensus.core.configurations module
===========================================

.. automodule:: remotior_sensus.core.configurations
   :members:
   :undoc-members:
   :show-inheritance:
