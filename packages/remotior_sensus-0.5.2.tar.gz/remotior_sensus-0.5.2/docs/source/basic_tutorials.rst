Basic Tutorials
===========================================

The following tutorials are available.


.. toctree::
   :maxdepth: 1
   :titlesonly:

   quickstart.rst
   tutorial_ndvi.rst
   tutorial_random_forest.rst