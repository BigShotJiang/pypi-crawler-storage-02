remotior\_sensus.core.multiprocess\_manager module
==================================================

.. automodule:: remotior_sensus.core.multiprocess_manager
   :members:
   :undoc-members:
   :show-inheritance:
