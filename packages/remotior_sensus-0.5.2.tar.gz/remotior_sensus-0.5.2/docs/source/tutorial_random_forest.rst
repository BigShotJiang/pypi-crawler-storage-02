Random Forest Classification
===========================================

Following the video of the tutorial.

https://www.youtube.com/watch?v=Rc61lSWOgt4

.. raw:: html

    <iframe allowfullscreen="" frameborder="0" height="360" src="https://www.youtube.com/embed/Rc61lSWOgt4?rel=0" width="100%"></iframe>


.. raw:: html

    <script src="https://gist.github.com/semiautomaticgit/5b3c6dca89b3764a69cf083cf3d0674f.js"></script>

Link to the guide:
https://colab.research.google.com/gist/semiautomaticgit/5b3c6dca89b3764a69cf083cf3d0674f/random_forest_classification.ipynb
