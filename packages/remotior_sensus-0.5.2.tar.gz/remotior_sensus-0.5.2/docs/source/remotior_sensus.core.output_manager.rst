remotior\_sensus.core.output\_manager module
============================================

.. automodule:: remotior_sensus.core.output_manager
   :members:
   :undoc-members:
   :show-inheritance:
