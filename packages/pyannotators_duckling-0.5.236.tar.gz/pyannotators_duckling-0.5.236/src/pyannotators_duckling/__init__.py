"""Annotator based on Facebook Duckling"""
__version__ = "0.5.236"
