# Utility functions will be added here in the future
