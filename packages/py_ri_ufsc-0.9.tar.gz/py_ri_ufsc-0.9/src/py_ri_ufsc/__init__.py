from .main import RIUFSC
# from .common.for_files import setup_dirs
# setup_dirs()
