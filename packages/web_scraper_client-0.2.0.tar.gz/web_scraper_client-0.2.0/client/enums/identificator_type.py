from enum import Enum

class ElementIdentification(Enum):
    CSS_SELECTOR = 'css_selector'
    ID = 'id'
    XPATH = 'xpath'