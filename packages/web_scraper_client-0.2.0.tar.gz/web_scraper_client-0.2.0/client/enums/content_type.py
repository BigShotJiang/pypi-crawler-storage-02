from enum import Enum

class ContentType(Enum):
    PAGE_SOURCE = 'page_source'
    XHR = 'xhr'