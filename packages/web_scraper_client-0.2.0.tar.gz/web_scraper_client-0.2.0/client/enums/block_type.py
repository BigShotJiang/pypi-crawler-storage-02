from enum import Enum

class BlockType(Enum):
    END = 'end'
    START = 'start'