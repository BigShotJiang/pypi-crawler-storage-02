# Publications mentioning `xdggs`

```{bibliography} publications.bib
---
all: true
list: bullet
style: alpha
---
```
