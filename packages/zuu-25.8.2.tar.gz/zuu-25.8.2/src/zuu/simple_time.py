import time

def unix_timestamp():
    return int(time.time() * 1000)