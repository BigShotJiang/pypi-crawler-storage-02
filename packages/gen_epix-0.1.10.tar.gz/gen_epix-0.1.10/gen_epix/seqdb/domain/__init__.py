from gen_epix.fastapp import Domain

DOMAIN = Domain("seqdb")
