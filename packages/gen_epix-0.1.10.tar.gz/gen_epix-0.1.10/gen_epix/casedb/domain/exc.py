# pylint: disable=wildcard-import, unused-wildcard-import
# because this is a package, and imported as such in other modules

from gen_epix.fastapp.api.exc import *
from gen_epix.fastapp.exc import *
