from gen_epix.casedb.domain.service import BaseOntologyService


class OntologyService(BaseOntologyService):
    pass
