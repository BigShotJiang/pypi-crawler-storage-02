
# EcoDev Front

This library is a reduced and opinionated version of Dash Mantine Components [DMC](https://www.dash-mantine-components.com/), itself a simplified version of the React Mantine library. It includes some basic functionalities such as
customisable components, navbar menus and customised component builders.

Full documentation of the library can be found [here](https://ecodev-doc.lcabox.com/libraries/front/)
