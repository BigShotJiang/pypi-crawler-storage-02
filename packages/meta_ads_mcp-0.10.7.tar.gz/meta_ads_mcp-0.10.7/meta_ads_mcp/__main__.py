"""
Meta Ads MCP - Main Entry Point

This module allows the package to be executed directly via `python -m meta_ads_mcp`
"""

from meta_ads_mcp.core.server import main

if __name__ == "__main__":
    main() 