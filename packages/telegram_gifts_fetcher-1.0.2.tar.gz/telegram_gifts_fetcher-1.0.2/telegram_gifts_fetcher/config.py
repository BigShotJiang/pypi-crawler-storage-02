import os
from typing import Optional
from loguru import logger
import sys
from dotenv import load_dotenv

""" --- LOGURU CONFIGURATION --- """
logger.remove()
logger.add(
    sys.stdout,
    format="| <magenta>{time:YYYY-MM-DD HH:mm:ss}</magenta> | <cyan><level>{level: <8}</level></cyan> | {message}\n",
    level="INFO",
    colorize=True,
)

load_dotenv()


""" --- CONFIG --- """

class Config:    
    def __init__(self, api_id: Optional[int] = None, api_hash: Optional[str] = None, session_name: Optional[str] = None):
        self.api_id: Optional[int] = api_id or self._get_env_int('API_ID')
        self.api_hash: Optional[str] = api_hash or self._get_env_str('API_HASH')
        self.session_name: str = session_name or self._get_env_str('SESSION_NAME') or 'account'
        
        if not self.api_id or not self.api_hash:
            self._prompt_for_credentials()
    
    def _get_env_int(self, key: str) -> Optional[int]:
        value = os.getenv(key)
        if value:
            value = value.strip('"\'')
            try:
                return int(value)
            except ValueError:
                logger.error(f"❌ Invalid integer value for {key}: {value}")
                return None
        return None
    
    def _get_env_str(self, key: str) -> Optional[str]:
        value = os.getenv(key)
        if value:
            return value.strip('"\'')
        return None
    
    def _prompt_for_credentials(self) -> None:
        logger.error("\n❌ Telegram API credentials not found!")
        logger.info("📋 Please add your API credentials to the .env file or pass them as parameters.")
        logger.info("🔗 Get your credentials from: https://my.telegram.org/apps")
        logger.info("\nExample .env file:")
        logger.info("API_ID=12345678")
        logger.info("API_HASH=abcdef1234567890abcdef1234567890")
        logger.info("SESSION_NAME=account")
        logger.info("")
        raise ValueError("API credentials are required but not provided")
    
    @property
    def is_valid(self) -> bool:
        return all([
            self.api_id,
            self.api_hash,
            self.session_name
        ])


config = None

def get_config(api_id: Optional[int] = None, api_hash: Optional[str] = None, session_name: Optional[str] = None) -> Config:
    global config
    if config is None or api_id or api_hash or session_name:
        config = Config(api_id=api_id, api_hash=api_hash, session_name=session_name)
    return config