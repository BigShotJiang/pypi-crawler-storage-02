"""Data models for Telegram gifts."""

from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime


@dataclass
class Gift:
    """Represents a Telegram gift."""
    
    name: str
    slug: str
    type: str
    message: Optional[str] = None
    received_date: Optional[int] = None
    name_hidden: bool = False
    can_upgrade: bool = False
    pinned_to_top: bool = False
    transfer_stars: int = 0
    user_convert_stars: int = 0
    
    @property
    def received_datetime(self) -> Optional[datetime]:
        """Convert received_date timestamp to datetime object."""
        if self.received_date:
            return datetime.fromtimestamp(self.received_date)
        return None


@dataclass
class GiftsResponse:
    """Response containing gifts data."""
    
    gifts: List[Gift]
    count_gifts: int
    
    def __post_init__(self):
        """Ensure count_gifts matches actual gifts count."""
        self.count_gifts = len(self.gifts)