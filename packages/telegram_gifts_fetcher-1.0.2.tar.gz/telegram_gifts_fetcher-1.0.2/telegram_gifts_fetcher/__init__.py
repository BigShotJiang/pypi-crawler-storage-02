"""Telegram Gifts Fetcher - A Python library to fetch Telegram gifts data."""

__version__ = "1.0.0"
__author__ = "Th3ryks"
__license__ = "MIT"

from .client import TelegramGiftsClient
from .models import Gift, GiftsResponse

__all__ = [
    "TelegramGiftsClient",
    "Gift",
    "GiftsResponse",
]