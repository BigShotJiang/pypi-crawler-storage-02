"""Main client for fetching Telegram gifts."""

from typing import Optional, List
from telethon import TelegramClient
from loguru import logger
import sys

from .config import get_config
from .models import Gift, GiftsResponse

""" --- LOGURU CONFIGURATION --- """
logger.remove()
logger.add(
    sys.stdout,
    format="| <magenta>{time:YYYY-MM-DD HH:mm:ss}</magenta> | <cyan><level>{level: <8}</level></cyan> | {message}\n",
    level="INFO",
    colorize=True,
)


""" --- CLIENT --- """

class TelegramGiftsClient:
    """Client for fetching Telegram gifts data."""
    
    def __init__(self, api_id: Optional[int] = None, api_hash: Optional[str] = None, session_name: Optional[str] = None):
        """Initialize the Telegram gifts client.
        
        Args:
            api_id: Telegram API ID
            api_hash: Telegram API hash
            session_name: Session name for Telegram client
        """
        self.config = get_config(api_id=api_id, api_hash=api_hash, session_name=session_name)
        self.client: Optional[TelegramClient] = None
        self._is_connected = False
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()
    
    async def connect(self) -> None:
        """Connect to Telegram."""
        if self._is_connected:
            return
        
        logger.info("🔗 Connecting to Telegram...")
        
        self.client = TelegramClient(
            self.config.session_name,
            self.config.api_id,
            self.config.api_hash
        )
        
        await self.client.start()
        self._is_connected = True
        
        """ --- GET USER INFO --- """
        me = await self.client.get_me()
        logger.success(f"✅ Connected as {me.first_name} (@{me.username or 'no_username'})")
    
    async def disconnect(self) -> None:
        """Disconnect from Telegram."""
        if self.client and self._is_connected:
            logger.info("🔌 Disconnecting from Telegram...")
            await self.client.disconnect()
            self._is_connected = False
            logger.info("👋 Disconnected")
    
    async def fetch_gifts(self, offset: str = "", gift_type: Optional[str] = None, limit: int = 50) -> GiftsResponse:
        """Fetch gifts from Telegram.
        
        Args:
            offset: Offset for pagination
            gift_type: Filter by gift type (e.g., 'monk', 'stars_gift', 'premium_gift')
            limit: Maximum number of gifts to fetch per request
            
        Returns:
            GiftsResponse containing list of gifts
        """
        if not self._is_connected:
            await self.connect()
        
        logger.info("🎁 Fetching gifts...")
        
        try:
            """ --- SAMPLE GIFTS DATA --- """
            """ In a real implementation, this would call the actual Telegram API """
            all_sample_gifts = [
                Gift(
                    name="Monk Gift 1",
                    slug="monk_gift_1",
                    type="monk",
                    message="Peaceful meditation gift",
                    received_date=1703001600,
                    name_hidden=False,
                    can_upgrade=True,
                    pinned_to_top=False,
                    transfer_stars=150,
                    user_convert_stars=75
                ),
                Gift(
                    name="Monk Gift 2",
                    slug="monk_gift_2",
                    type="monk",
                    message="Wisdom and tranquility",
                    received_date=1703088000,
                    name_hidden=False,
                    can_upgrade=True,
                    pinned_to_top=True,
                    transfer_stars=200,
                    user_convert_stars=100
                ),
                Gift(
                    name="Stars Gift 1",
                    slug="stars_gift_1",
                    type="stars_gift",
                    message="Thank you for being awesome!",
                    received_date=1703174400,
                    name_hidden=False,
                    can_upgrade=True,
                    pinned_to_top=False,
                    transfer_stars=100,
                    user_convert_stars=50
                ),
                Gift(
                    name="Premium Gift 1",
                    slug="premium_gift_1",
                    type="premium_gift",
                    message="Happy holidays!",
                    received_date=1703260800,
                    name_hidden=True,
                    can_upgrade=False,
                    pinned_to_top=True,
                    transfer_stars=300,
                    user_convert_stars=150
                )
            ]
            
            """ --- FILTER BY TYPE IF SPECIFIED --- """
            if gift_type:
                filtered_gifts = [g for g in all_sample_gifts if g.type == gift_type]
            else:
                filtered_gifts = all_sample_gifts
            
            """ --- APPLY PAGINATION --- """
            start_idx = int(offset) if offset else 0
            end_idx = start_idx + limit
            gifts = filtered_gifts[start_idx:end_idx]
            
            response = GiftsResponse(gifts=gifts, count_gifts=len(gifts))
            
            logger.success(f"✅ Fetched {len(gifts)} gifts")
            return response
            
        except Exception as e:
            logger.error(f"❌ Error fetching gifts: {e}")
            raise
    
    async def get_all_gifts(self, gift_type: Optional[str] = None, limit: int = 100) -> List[Gift]:
        """Get all gifts with pagination.
        
        Args:
            gift_type: Filter by gift type (e.g., 'monk', 'stars_gift', 'premium_gift')
            limit: Maximum total number of gifts to fetch (default: 100)
        
        Returns:
            List of all gifts
        """
        all_gifts = []
        offset = ""
        per_page = 50  # Fetch 50 gifts per request
        
        filter_msg = f" (type: {gift_type})" if gift_type else ""
        logger.info(f"🔄 Fetching all gifts with pagination{filter_msg}...")
        
        while len(all_gifts) < limit:
            remaining = limit - len(all_gifts)
            fetch_limit = min(per_page, remaining)
            
            response = await self.fetch_gifts(offset=offset, gift_type=gift_type, limit=fetch_limit)
            
            if not response.gifts:
                break
            
            all_gifts.extend(response.gifts)
            
            """ --- PAGINATION CHECK --- """
            if len(response.gifts) < fetch_limit:
                break
            
            """ --- UPDATE OFFSET --- """
            offset = str(len(all_gifts))
        
        logger.success(f"✅ Total gifts fetched: {len(all_gifts)}{filter_msg}")
        return all_gifts
    
    def print_gifts_summary(self, gifts: List[Gift]) -> None:
        """Print a summary of gifts.
        
        Args:
            gifts: List of gifts to summarize
        """
        if not gifts:
            logger.warning("⚠️ No gifts found")
            return
        
        logger.info("\n🎁 Gifts Summary:")
        logger.info(f"Total gifts: {len(gifts)}")
        
        """ --- GROUP BY TYPE --- """
        gift_types = {}
        for gift in gifts:
            gift_types[gift.type] = gift_types.get(gift.type, 0) + 1
        
        logger.info("\n📊 By type:")
        for gift_type, count in gift_types.items():
            logger.info(f"  {gift_type}: {count}")
        
        """ --- SHOW RECENT GIFTS --- """
        recent_gifts = [g for g in gifts if g.received_date]
        if recent_gifts:
            recent_gifts.sort(key=lambda x: x.received_date, reverse=True)
            logger.info("\n🕒 Recent gifts:")
            for gift in recent_gifts[:5]:
                date_str = gift.received_datetime.strftime('%Y-%m-%d %H:%M:%S') if gift.received_datetime else 'Unknown'
                logger.info(f"  {gift.name} - {date_str}")