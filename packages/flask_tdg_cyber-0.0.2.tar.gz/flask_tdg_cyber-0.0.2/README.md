# flask_tdg_cyber

A simple package to print "hello".

## Usage

```python
from flask_tdg_cyber import hello
hello()  # prints "hello" ^_^