"""Command line interface for the vantage6 infrastructure."""

from ._version import version_info, __version__  # noqa: F401
