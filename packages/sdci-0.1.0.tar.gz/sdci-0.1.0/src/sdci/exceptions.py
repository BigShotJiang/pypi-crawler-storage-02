class SDCIException(Exception):
    pass


class SDCIServerException(SDCIException):
    pass
