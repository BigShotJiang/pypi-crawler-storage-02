(license)=

# License

```{eval-rst}
.. include:: ../LICENSE.txt
```
