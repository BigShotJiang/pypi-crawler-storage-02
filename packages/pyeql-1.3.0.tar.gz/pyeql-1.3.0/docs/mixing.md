(module-functions)=

# Mixing Functions

`pyEQL` contains several mixing and equilibration functions that take `Solution` as arguments.

```{eval-rst}
.. automodule:: pyEQL.functions
   :members:
   :inherited-members:
   :member-order: bysource
```
