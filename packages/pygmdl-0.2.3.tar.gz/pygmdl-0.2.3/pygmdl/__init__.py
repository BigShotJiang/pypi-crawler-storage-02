# pylint: disable=missing-module-docstring
from pygmdl.downloader import save_image
