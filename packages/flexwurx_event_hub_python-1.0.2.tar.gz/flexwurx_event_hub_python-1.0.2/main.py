def main():
    print("Hello from event-hub-python!")


if __name__ == "__main__":
    main()
