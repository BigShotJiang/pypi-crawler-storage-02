import sys

from .mcp_server import main

sys.exit(main())