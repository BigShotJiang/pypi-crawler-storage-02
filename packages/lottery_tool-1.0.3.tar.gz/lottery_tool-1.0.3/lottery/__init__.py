"""lottery: Weighted random allocation library."""

from core import lottery

__version__ = "1.0.3"
__all__ = ["lottery"]
