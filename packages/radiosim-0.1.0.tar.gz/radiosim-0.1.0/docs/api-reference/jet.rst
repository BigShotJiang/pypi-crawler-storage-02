.. _jet:

*************************
Jet (:mod:`radiosim.jet`)
*************************

.. currentmodule:: radiosim.jet

Jet module.


Reference/API
=============

.. automodapi:: radiosim.jet
    :inherited-members:
