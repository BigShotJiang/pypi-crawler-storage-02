.. _ppdisks:

**********************************************
Protoplanetary Disks (:mod:`radiosim.ppdisks`)
**********************************************

.. currentmodule:: radiosim.ppdisks

Protoplanetary disks module.


Reference/API
=============

.. automodapi:: radiosim.ppdisks
    :inherited-members:
