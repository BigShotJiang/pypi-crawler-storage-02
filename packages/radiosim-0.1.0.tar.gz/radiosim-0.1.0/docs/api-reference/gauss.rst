.. _gauss:

*****************************
Gauss (:mod:`radiosim.gauss`)
*****************************

.. currentmodule:: radiosim.gauss

Gauss module.


Reference/API
=============

.. automodapi:: radiosim.gauss
    :inherited-members:
