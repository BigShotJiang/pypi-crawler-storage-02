# deltaapply
Change Data Capture (CDC) mit automatischem Anwenden von Inserts, Updates und Deletes
