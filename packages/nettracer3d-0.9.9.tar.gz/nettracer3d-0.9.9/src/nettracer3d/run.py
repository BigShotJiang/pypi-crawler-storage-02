from nettracer3d import nettracer_gui


def main():
    nettracer_gui.run_gui()


if __name__ == '__main__':
    main()