## 2025.8.11.20250813 (2025-08-13)

[yt-dlp] Update to 2025.8.11 ([#14564](https://github.com/python/typeshed/pull/14564))

## 2025.7.21.20250728 (2025-07-28)

Fully annotate `yt-dlp` (#14481)

## 2025.7.21.20250727 (2025-07-27)

Add yt-dlp stubs (#14216)

