enum test
