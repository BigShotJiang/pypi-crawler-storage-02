from setuptools import setup, find_packages

setup(
    name="SIGNERTIKTOKT",
    version="0.1.0",
    packages=find_packages(),
    description="zalos SIGNER TIKTOK",
    author="zalos",
    author_email="ssssssssssry@sssssss.com",
    install_requires=[
        "requests"
    ],
    python_requires='>=3.6',
)
