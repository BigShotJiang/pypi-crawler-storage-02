"""
Icon subsystem for django-includecontents.

Provides dynamic generation, caching, and usage of SVG icon sprite sheets
from Iconify-compatible icon names.
"""