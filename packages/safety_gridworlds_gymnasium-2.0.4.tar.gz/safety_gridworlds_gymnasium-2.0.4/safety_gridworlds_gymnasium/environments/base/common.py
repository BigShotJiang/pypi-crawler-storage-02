Walls = {
    (0, 1),
}