from maleo_soma.mixins.timestamp import Duration


class GenerateDifferentialDiagnosesMetadataSchema(Duration):
    pass
