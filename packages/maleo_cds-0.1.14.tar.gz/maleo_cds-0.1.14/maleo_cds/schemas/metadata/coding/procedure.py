from maleo_soma.mixins.timestamp import Duration


class GenerateRecommendationMetadataSchema(Duration):
    pass
