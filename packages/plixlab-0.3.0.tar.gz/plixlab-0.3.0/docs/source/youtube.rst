Youtube
========

Youtube videos are included with the tag ``youtube``

.. code-block:: python

 from plixlab import Slide

 Slide().youtube('zDtx6Z9g4xA').show()

.. import_example:: youtube

| where the video ID can be easily obtained from the URL.


