Shape Generation
================

Tools for creating geometric shapes as PNG images for presentations.

.. automodule:: plixlab.shape
   :members:
