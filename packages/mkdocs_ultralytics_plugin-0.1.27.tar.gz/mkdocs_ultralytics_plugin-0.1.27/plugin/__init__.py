# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license

__version__ = "0.1.27"

from .main import MetaPlugin

__all__ = ["MetaPlugin", "__version__"]
