## cdf 

### Added

- [alpha] The `cdf migrate prepare` now populates default view mappings.

## templates

No changes.