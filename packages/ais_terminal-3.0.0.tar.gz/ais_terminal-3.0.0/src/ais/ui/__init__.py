"""AIS UI组件模块。"""

from .panels import AISPanels, panels

__all__ = ["AISPanels", "panels"]
