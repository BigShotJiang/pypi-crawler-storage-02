# Osiric - Data Extraction

A package for extracting data from any kind of source.