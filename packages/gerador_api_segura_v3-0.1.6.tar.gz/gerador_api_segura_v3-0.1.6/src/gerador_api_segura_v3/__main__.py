from .cli import main
from .cli import main
raise SystemExit(main())
