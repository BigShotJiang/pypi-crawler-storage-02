# Installation

To install ESSimaging and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install essimaging
```
````
````{tab-item} conda
```sh
conda install -c conda-forge essimaging
```
````
`````
