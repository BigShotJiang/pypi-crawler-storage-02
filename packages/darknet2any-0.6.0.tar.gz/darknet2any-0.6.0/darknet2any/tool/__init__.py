
"""
tools used by darknet2any programs/modules
"""
