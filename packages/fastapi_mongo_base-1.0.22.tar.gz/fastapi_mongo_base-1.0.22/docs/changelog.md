# Changelog

All notable changes to this project will be documented here.

## 0.12.12
- Initial documentation structure
- Improved developer onboarding
- Added Docker and boilerplate guides 