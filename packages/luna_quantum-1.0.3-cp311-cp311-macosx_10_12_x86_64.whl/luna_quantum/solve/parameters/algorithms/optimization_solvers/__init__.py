from .scip import SCIP

__all__ = ["SCIP"]
