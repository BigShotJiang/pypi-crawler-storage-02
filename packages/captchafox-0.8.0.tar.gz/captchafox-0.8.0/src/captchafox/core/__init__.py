from .paths import PATH_DIR, PATH_DATA_DIR


__all__ = ["PATH_DIR", "PATH_DATA_DIR"]
