from pathlib import Path


PATH_DIR = Path(__file__).parent.parent.parent.parent

PATH_DATA_DIR = PATH_DIR / "data"
