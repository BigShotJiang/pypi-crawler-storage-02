from typing import Tuple


def generate_webgl_config() -> Tuple[str, str]:
    ...