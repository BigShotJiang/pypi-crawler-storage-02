# ElgatoWavePy, control WaveLink with Python

ElgatoWavePy is a Python package designed to control the Elgato WaveLink application using simple commands. 
For comprehensive documentation, refer to the [Wiki](https://github.com/Steepy12/ElgatoWavePy/wiki) pages of the repository.


If a feature is not included, feel free to ask about it.


Thanks to [@TheLtWilson](https://github.com/TheLtWilson) for sharing his code! :)