"""Dim-to-Layer maps for different dimensions.

This file is part of Chuchichaestli.

Chuchichaestli is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Chuchichaestli is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Chuchichaestli.  If not, see <http://www.gnu.org/licenses/>.

Developed by the Intelligent Vision Systems Group at ZHAW.
"""

from torch import nn


DIM_TO_CONV_MAP = {
    1: nn.Conv1d,
    2: nn.Conv2d,
    3: nn.Conv3d,
}

DIM_TO_CONV_FN_MAP = {
    1: nn.functional.conv1d,
    2: nn.functional.conv2d,
    3: nn.functional.conv3d,
}

DIM_TO_CONVT_MAP = {
    1: nn.ConvTranspose1d,
    2: nn.ConvTranspose2d,
    3: nn.ConvTranspose3d,
}

UPSAMPLE_MODE = {
    1: "linear",
    2: "bilinear",
    3: "trilinear",
}
