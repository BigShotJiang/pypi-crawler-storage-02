"""finq legacy package placeholder (module deprecated)."""
__all__: list[str] = []
