This module was created to meet the need of providing
the customer with products that are not transformed
into something new, but rather require a simple
preparation process. Example: Scaling a fish
