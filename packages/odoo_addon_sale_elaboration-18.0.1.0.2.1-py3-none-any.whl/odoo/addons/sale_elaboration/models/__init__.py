# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
from . import product
from . import product_category
from . import product_elaboration
from . import product_elaboration_mixin
from . import product_elaboration_profile
from . import product_template
from . import res_config_settings
from . import sale_order
from . import stock_move
from . import stock_picking
from . import stock_rule
