# payconpy - Funcoes para automatizar criação de sistemas Python

## pip install payconpy | NECESSARIO PYTHON 3.10

Aqui voce achara funcoes produzidas para ter maior agilidade nos desenvolvimentos nas tecnologias abaixo:

* Selenium
* Tesseract
* Python
* OpenAI

## Instalacao

pip install payconpy em seu ambiente virtual e pronto!

Powered By: [Paycon Automações](https://github.com/Paycon-Automacoes)

# Current Version -> 2.1.0
