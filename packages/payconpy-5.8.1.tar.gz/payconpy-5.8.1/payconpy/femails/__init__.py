"""
Funções para envio de e-mails
"""
