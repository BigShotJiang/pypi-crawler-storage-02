"""
Funções Python
"""
