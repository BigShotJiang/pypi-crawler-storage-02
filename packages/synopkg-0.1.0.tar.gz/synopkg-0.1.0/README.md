## 一个适用于群晖NAS的包管理器(好吧他并不能算传统意义上的包管理器)
### A Package Manager For Synology by Python3