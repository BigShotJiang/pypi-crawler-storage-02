''' A profile that uses biojupies' theme for fields and stylesheets.
'''