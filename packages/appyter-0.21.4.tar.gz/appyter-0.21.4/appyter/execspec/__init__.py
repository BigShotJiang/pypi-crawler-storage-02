''' An fsspec analog for platform agnostic executor protocols.

Executors are used specifically for launching appyter jobs.
'''