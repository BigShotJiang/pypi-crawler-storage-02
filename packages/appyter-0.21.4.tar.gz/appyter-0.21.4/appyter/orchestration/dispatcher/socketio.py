from appyter.ext.socketio import AsyncServer

socketio = AsyncServer(async_mode='aiohttp')
