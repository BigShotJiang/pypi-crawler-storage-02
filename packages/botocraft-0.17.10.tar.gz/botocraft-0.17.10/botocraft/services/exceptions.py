class NotUpdatableError(Exception):
    """Exception raised when a resource is not updatable."""
