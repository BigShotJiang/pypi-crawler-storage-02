# 采用以下形式将所有.py 模块导入到mode 目录下

# from . import sig_coverage
# from . import LocSig
# from . import is_sig
# from .spatbiasFS import *

from .significance import mean_estimate