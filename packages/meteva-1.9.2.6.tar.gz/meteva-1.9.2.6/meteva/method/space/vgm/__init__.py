# 采用以下形式将所有.py 模块导入到vgm 目录下
from .structurogram import vgm_sta,vgm_sta_box
from .structurogram_matrix import vgm_grd_mesh,vgm_grd
