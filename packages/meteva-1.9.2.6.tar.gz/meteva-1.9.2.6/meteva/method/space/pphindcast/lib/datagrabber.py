def datagrabber(object, **args):
    return {"X": object['X'], "Xhat": object['Xhat']}