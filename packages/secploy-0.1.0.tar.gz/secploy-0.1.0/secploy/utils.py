
def log(message, debug):
    if debug:
        print(f"[Secploy] {message}")

