# LVM REST API

![Versions](https://img.shields.io/badge/python->=3.11-blue)
[![Test](https://github.com/sdss/lvmapi/actions/workflows/test.yml/badge.svg)](https://github.com/sdss/lvmapi/actions/workflows/test.yml)
[![codecov](https://codecov.io/gh/sdss/lvmapi/branch/main/graph/badge.svg)](https://codecov.io/gh/sdss/lvmapi)

REST API for LVM operations.
