"""Define enumeration of different kinds of justifications of predicates."""
