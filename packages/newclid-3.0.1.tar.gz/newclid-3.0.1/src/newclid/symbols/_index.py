from enum import Enum


class SymbolType(Enum):
    LINE = "line"
    CIRCLE = "circle"
