"""Build problem setup from JGEX clauses."""
