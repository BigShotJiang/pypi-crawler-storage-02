"""Newclid geometric symbolic solver package"""

from newclid.api import GeometricSolver, GeometricSolverBuilder

__all__ = ["GeometricSolver", "GeometricSolverBuilder"]
