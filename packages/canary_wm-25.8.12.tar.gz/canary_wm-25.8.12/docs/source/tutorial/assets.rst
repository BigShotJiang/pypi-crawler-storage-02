.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _tutorial-assets:

Test asset management
=====================

.. toctree::
    :maxdepth: 1

    Copy files into the test's working directory <assets.copy>
    Link files into the test's working directory <assets.link>
