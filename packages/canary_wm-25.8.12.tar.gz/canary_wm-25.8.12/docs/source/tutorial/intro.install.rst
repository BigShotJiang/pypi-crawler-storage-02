.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

Installing canary
=================

.. code-block:: console

    python3 -m venv venv
    source venv/bin/activate
    python3 -m pip install canary-wm
