.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _intro-getting-help:

Getting help
============

``canary`` has several :ref:`subcommands <canary>`.  To get the list of subcommands, issue

.. command-output:: canary -h


To get help on an individual subcommand, issue, for example:

.. command-output:: canary run -h
