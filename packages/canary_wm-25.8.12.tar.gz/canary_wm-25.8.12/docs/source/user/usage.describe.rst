.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _usage-describe:

Describing a test file
======================

``canary describe`` can print information about a test file and/or test case.

Basic usage
-----------

.. command-output:: canary describe execute_and_analyze/execute_and_analyze.pyt
   :cwd: /examples
