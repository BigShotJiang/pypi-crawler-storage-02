.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _presentation-technical-plugin:

Plugin system
=============

- Modular design allowing flexible extensions.
- Examples of built-in and custom plugins.
