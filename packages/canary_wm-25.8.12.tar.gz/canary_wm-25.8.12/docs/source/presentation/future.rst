.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _presentation-future:

Future work and roadmap
=======================

Upcoming features
-----------------

- Enhanced reporting and visualization tools.
- Expanded support for additional tools and schedulers.

Long-term vision
----------------

- Making canary the go-to testing framework for diverse scientific and software environments.
