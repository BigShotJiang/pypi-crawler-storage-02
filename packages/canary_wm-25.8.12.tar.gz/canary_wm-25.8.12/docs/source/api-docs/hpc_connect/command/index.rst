.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

command
=======

.. toctree::
   :maxdepth: 1

   config
   launch
   submit
