.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


singleton
=========

.. automodule:: _canary.util.singleton
   :members:
   :undoc-members:
   :show-inheritance:
