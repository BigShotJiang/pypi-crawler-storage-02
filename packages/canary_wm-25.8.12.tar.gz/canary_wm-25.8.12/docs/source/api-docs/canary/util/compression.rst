.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


compression
===========

.. automodule:: _canary.util.compression
   :members:
   :undoc-members:
   :show-inheritance:
