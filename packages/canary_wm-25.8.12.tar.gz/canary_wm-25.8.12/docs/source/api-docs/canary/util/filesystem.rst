.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


filesystem
==========

.. automodule:: _canary.util.filesystem
   :members:
   :undoc-members:
   :show-inheritance:
