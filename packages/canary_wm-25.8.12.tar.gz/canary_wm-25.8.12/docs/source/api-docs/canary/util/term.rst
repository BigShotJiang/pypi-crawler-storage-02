.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


term
====

.. automodule:: _canary.util.term
   :members:
   :undoc-members:
   :show-inheritance:
