.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


misc
====

.. automodule:: _canary.util.misc
   :members:
   :undoc-members:
   :show-inheritance:
