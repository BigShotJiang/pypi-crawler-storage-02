.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


time
====

.. automodule:: _canary.util.time
   :members:
   :undoc-members:
   :show-inheritance:
