.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


autodoc
=======

.. automodule:: _canary.plugins.subcommands.autodoc
   :members:
   :undoc-members:
   :show-inheritance:
