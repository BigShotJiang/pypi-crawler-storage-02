.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


gitlab_issue_generator
======================

.. automodule:: _canary.plugins.builtin.cdash.gitlab_issue_generator
   :members:
   :undoc-members:
   :show-inheritance:
