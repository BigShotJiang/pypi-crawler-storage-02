.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


xml_generator
=============

.. automodule:: _canary.plugins.builtin.cdash.xml_generator
   :members:
   :undoc-members:
   :show-inheritance:
