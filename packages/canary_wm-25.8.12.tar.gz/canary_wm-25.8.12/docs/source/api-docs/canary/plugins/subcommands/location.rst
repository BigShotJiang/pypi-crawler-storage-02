.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


location
========

.. automodule:: _canary.plugins.subcommands.location
   :members:
   :undoc-members:
   :show-inheritance:
