.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


runtests
========

.. automodule:: _canary.plugins.builtin.runtests
   :members:
   :undoc-members:
   :show-inheritance:
