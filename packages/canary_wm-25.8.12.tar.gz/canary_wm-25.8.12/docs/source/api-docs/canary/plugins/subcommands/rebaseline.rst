.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


rebaseline
==========

.. automodule:: _canary.plugins.subcommands.rebaseline
   :members:
   :undoc-members:
   :show-inheritance:
