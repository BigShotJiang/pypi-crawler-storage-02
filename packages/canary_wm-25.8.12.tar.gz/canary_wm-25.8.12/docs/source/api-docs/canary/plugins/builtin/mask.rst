.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


mask
====

.. automodule:: _canary.plugins.builtin.mask
   :members:
   :undoc-members:
   :show-inheritance:
