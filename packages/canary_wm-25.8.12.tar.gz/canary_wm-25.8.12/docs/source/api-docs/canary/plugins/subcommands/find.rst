.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


find
====

.. automodule:: _canary.plugins.subcommands.find
   :members:
   :undoc-members:
   :show-inheritance:
