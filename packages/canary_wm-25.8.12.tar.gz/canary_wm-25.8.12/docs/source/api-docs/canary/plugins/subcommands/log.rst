.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


log
===

.. automodule:: _canary.plugins.subcommands.log
   :members:
   :undoc-members:
   :show-inheritance:
