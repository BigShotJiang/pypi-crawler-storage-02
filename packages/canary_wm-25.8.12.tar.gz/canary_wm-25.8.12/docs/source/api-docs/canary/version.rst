.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


version
=======

.. automodule:: _canary.version
   :members:
   :undoc-members:
   :show-inheritance:
