.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


finder
======

.. automodule:: _canary.finder
   :members:
   :undoc-members:
   :show-inheritance:
