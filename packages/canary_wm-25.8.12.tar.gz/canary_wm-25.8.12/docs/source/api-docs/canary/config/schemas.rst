.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


schemas
=======

.. automodule:: _canary.config.schemas
   :members:
   :undoc-members:
   :show-inheritance:
