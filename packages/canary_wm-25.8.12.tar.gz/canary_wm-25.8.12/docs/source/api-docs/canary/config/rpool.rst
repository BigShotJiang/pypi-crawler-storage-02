.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


rpool
=====

.. automodule:: _canary.config.rpool
   :members:
   :undoc-members:
   :show-inheritance:
