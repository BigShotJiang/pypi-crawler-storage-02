.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


queues
======

.. automodule:: _canary.queues
   :members:
   :undoc-members:
   :show-inheritance:
