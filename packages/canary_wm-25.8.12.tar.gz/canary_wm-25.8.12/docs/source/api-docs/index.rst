.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

API reference
=============

All modules and packages live in the ``_canary`` namespace.

.. toctree::
   :maxdepth: 1

   canary/index
   hpc_connect/index
