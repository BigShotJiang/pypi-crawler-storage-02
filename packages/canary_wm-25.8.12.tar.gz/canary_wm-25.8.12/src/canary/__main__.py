# Copyright NTESS. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: MIT

from _canary.main import console_main

if __name__ == "__main__":
    raise SystemExit(console_main())
