"""Output formatting and display functions"""
