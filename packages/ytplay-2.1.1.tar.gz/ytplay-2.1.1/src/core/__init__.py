"""Core business logic and API interactions"""
