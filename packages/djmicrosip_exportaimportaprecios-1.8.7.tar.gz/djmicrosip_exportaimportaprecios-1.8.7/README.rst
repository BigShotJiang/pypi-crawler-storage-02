djmicrosip_exportaimportaprecios
==========================

Install or update
-------

### latest version ###
```
pip install --upgrade djmicrosip_exportaimportaprecios
```
### An specific release version ###
```
pip install --upgrade djmicrosip_exportaimportaprecios=[version]
```