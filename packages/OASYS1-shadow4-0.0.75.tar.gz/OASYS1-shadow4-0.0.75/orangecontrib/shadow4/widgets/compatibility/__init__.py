

NAME = "Compatibility 3<->4"

DESCRIPTION = "Tools for compatibility between Shadow3 and Shadow 4"

BACKGROUND = "#b9d47a"

ICON = "icons/compatibility.png"

PRIORITY = 1099
