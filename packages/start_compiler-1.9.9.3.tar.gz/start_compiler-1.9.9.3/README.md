# start_compiler
This is a Python module to compile and run the language START. START is intended for use in CS first year eduction to learn programming and programming concepts. It focuses on easy to learn syntax, and, clear expression of programming concepts such as types, variables, combined types, strings, dealing with memory and assignment and simple algorithms. It is not intended to build large programs in.

It is developed by Joost Broekens & Jonne Goedhart at LIACS Leiden University. For questions email: Joost.broekens@gmail.com

## Compiler
You can compile the language with the following command:
```bash
python -m start_compiler.compile <FileName>.start 
```

## Run File 
You can run the file after compiling it with:
```bash
python <FileName>.py
```
