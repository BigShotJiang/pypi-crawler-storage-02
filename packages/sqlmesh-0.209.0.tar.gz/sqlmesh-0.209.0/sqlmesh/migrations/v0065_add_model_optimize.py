"""Add the optimize_query model attribute."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
