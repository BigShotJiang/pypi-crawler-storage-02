MODEL (
  name bronze.b
);

SELECT
  *
FROM bronze.a
