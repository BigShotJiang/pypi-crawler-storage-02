MODEL (
  name sqlmesh_repo.b
);

SELECT
  col_a, col_b
FROM sqlmesh_repo.a
