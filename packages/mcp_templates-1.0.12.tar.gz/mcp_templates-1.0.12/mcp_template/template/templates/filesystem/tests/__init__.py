"""
Tests for Filesystem template.
"""
