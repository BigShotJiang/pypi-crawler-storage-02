# Available Templates

This page lists all available MCP server templates.

## [Demo Hello MCP Server](demo/index.md)

A simple demonstration MCP server that provides greeting tools

**Template ID:** `demo`

**Version:** latest

**Author:** Unknown

---
