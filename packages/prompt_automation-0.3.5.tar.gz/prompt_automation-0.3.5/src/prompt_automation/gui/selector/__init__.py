"""Hierarchical template selection widgets and controller."""
from .controller import open_template_selector

__all__ = ["open_template_selector"]
