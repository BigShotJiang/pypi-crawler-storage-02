# tests package initializer
