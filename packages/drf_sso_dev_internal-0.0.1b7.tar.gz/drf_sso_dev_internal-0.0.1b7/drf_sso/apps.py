from django.apps import AppConfig

class DrfSsoConfig(AppConfig):
    name = 'drf_sso'
    verbose_name = "Drango REST Framework - Single Sign On"