## cdf 

### Added

- [alpha] Added support for storing mapping between asset-centric
resources and views in configurations with the new resource type
`ViewSource`.

## templates

No changes.