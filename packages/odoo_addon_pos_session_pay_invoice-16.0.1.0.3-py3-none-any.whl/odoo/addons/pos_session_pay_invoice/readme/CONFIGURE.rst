#.  Go to *Point of Sale / Configuration / Payment Methods* 
    and ensure that at least one payment method with a journal type "cash" 
    is created (or create one if it does not exist).

#.  Go to *Point of Sale / Configuration / Settings* 
    Select a Point of Sale and ensure than in the payment methods section, 
    at least one payment method has a journal type "cash"
