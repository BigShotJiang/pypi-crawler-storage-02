from . import discriminators

__all__ = ["discriminators"]
