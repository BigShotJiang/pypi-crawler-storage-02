# **Pyinitor** CLI utility - python project starter.
Creates new python project 


Usage:

- Install library `pip install pyinitor`
- Run with args `pyinitor 3.10 /path/to/new_project` (put needed version of python and path to desired project)

Pyinitor will create project directory with venv, python version and files 
Then it opens project with vscode...

---

- Files in project (You may set it own):
    - venv
    - main.py
    - .env
    - .dockerignore
    - .gitignore
    - requirements.txt

---

# Pyinitor

**Pyinitor** — CLI-утилита для быстрого старта Python-проектов.  
Cоздаёт новую директорию проекта, инициализирует виртуальное окружение под нужную версию Python и добавляет базовый набор файлов.

---

- Установка `pip install pyinitor`
- Запуск с аргументами `pyinitor 3.10 /path/to/new_project` (требуемая версия, директория проекта)


- Автоматическое создание проекта с пакетом файлов:
  - `.env`
  - `README.md`
  - `.gitignore`
  - `.dockerignore`
  - `requirements.txt`
  - `main.py`


---




