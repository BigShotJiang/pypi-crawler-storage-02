#!/usr/bin/env python3
import sys
import os
import subprocess
from pathlib import Path


def main():
    if len(sys.argv) != 3:
        print("Usage : pyinitor <python_version> <project_path>")
        sys.exit(1)

    py_version = sys.argv[1]
    project_path = Path(sys.argv[2]).expanduser().resolve()

    os.makedirs(project_path, exist_ok=True)
    os.chdir(project_path)

    # virtualenv should be installed before running script !
    subprocess.run(["virtualenv", "-p", f"python{py_version}", "venv"], check=True)

    # Create basic files
    (project_path / ".env").write_text("# Environment variables\n")
    (project_path / "README.md").write_text(f"# {project_path.name}\n\nDefault readme.\n")
    (project_path / ".gitignore").write_text("__pycache__/\n*.pyc\nvenv/\n.env\n.DS_Store\n")
    (project_path / ".dockerignore").write_text("__pycache__/\n*.pyc\nvenv/\n.env\n.DS_Store\n")
    (project_path / "requirements.txt").write_text("")
    (project_path / "main.py").write_text(
        'def main():\n    print("Hello, world!")\n\n\nif __name__ == "__main__":\n    main()\n'
    )

    print(f"Starter Python project is created: {project_path}")
    subprocess.run(["cd", f"{project_path}", "&&", "code", "."], check=True)


if __name__ == "__main__":
    main()
