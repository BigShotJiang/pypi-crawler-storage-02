import numpy as np

def func1(data):
    """对数据做一些常见的预处理"""
    return np.array(data)  # 举例：将数据转为numpy数组

def func2(a, b):
    """计算两个数的加和"""
    return a + b
