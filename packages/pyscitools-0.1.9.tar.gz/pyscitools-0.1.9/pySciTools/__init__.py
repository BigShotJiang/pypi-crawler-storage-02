# __version__ = "0.1.0"
from .utils import func1, func2  # 导入常用函数
