"""Shared services for CLI and MCP functionality."""
