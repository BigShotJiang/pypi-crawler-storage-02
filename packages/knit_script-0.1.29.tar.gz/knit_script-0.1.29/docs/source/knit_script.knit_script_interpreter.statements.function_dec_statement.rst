knit\_script.knit\_script\_interpreter.statements.function\_dec\_statement module
=================================================================================

.. automodule:: knit_script.knit_script_interpreter.statements.function_dec_statement
   :members:
   :undoc-members:
   :show-inheritance:
