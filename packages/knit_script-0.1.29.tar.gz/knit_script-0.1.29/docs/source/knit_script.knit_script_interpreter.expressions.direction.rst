knit\_script.knit\_script\_interpreter.expressions.direction module
===================================================================

.. automodule:: knit_script.knit_script_interpreter.expressions.direction
   :members:
   :undoc-members:
   :show-inheritance:
