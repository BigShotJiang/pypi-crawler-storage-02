knit\_script.knit\_script\_interpreter.expressions.Gauge\_Expression module
===========================================================================

.. automodule:: knit_script.knit_script_interpreter.expressions.Gauge_Expression
   :members:
   :undoc-members:
   :show-inheritance:
