knit\_script.knit\_script\_interpreter.expressions.needle\_expression module
============================================================================

.. automodule:: knit_script.knit_script_interpreter.expressions.needle_expression
   :members:
   :undoc-members:
   :show-inheritance:
