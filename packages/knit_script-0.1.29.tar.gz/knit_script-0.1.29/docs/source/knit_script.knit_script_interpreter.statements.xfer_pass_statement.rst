knit\_script.knit\_script\_interpreter.statements.xfer\_pass\_statement module
==============================================================================

.. automodule:: knit_script.knit_script_interpreter.statements.xfer_pass_statement
   :members:
   :undoc-members:
   :show-inheritance:
