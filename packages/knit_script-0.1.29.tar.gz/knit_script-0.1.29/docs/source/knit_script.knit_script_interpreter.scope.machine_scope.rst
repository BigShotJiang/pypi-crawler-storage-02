knit\_script.knit\_script\_interpreter.scope.machine\_scope module
==================================================================

.. automodule:: knit_script.knit_script_interpreter.scope.machine_scope
   :members:
   :undoc-members:
   :show-inheritance:
