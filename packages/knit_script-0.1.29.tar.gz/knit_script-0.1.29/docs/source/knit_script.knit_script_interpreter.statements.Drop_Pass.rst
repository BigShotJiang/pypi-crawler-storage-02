knit\_script.knit\_script\_interpreter.statements.Drop\_Pass module
===================================================================

.. automodule:: knit_script.knit_script_interpreter.statements.Drop_Pass
   :members:
   :undoc-members:
   :show-inheritance:
