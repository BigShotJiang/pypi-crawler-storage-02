from emoji_bars.emoji_surround import get_emoji_surrounder

print(
    get_emoji_surrounder("🌟", "This is cool!")
)  # Example usage of get_emoji_surrounder function
