import os


def test_display_urls():
    os.system("python -m kui.routing example:app")
