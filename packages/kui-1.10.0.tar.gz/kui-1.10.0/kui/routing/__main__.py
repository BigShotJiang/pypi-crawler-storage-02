from .commands import display_urls

if __name__ == "__main__":
    display_urls()
