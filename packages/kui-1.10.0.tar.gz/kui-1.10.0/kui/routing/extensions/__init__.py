from .file import FileRoutes
from .multimethod import MultimethodRoutes

__all__ = [
    "FileRoutes",
    "MultimethodRoutes",
]
