def test_imports():
    """Test that main modules can be imported."""
    from miamcpdoc import main  # noqa
    from miamcpdoc import cli  # noqa
    from miamcpdoc import langgraph  # noqa

    assert True
