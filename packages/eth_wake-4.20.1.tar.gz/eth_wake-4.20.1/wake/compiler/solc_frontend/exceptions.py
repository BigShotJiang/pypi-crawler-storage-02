class SolcCompilationError(Exception):
    pass
