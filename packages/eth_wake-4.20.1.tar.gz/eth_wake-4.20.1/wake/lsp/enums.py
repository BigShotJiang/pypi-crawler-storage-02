from wake.utils import StrEnum


class TraceValueEnum(StrEnum):
    OFF = "off"
    MESSAGES = "messages"
    VERBOSE = "verbose"
