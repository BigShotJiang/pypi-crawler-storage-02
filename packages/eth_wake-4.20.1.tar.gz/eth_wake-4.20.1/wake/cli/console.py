from rich import get_console

console = get_console()
