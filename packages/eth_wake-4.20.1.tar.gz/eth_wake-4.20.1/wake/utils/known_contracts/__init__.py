from .known_contracts import KNOWN_CONTRACTS, KnownContract, compute_code_checksum
