import pathlib
import os
APP_LOCATE = str(pathlib.Path(os.path.abspath(__file__)).parent)
DATA_PATH = APP_LOCATE + '/data/'
MID_BASE_URL = "http://jixunet.top/jxdm_zyrisk"