# This is a shim for back-compat.
from .table import *  # noqa: F401, F403
