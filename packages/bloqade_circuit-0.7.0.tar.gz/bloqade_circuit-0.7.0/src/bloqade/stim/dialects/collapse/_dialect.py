from kirin import ir

dialect = ir.Dialect("stim.collapse")
