#!/usr/bin/env python3
"""Convenience script to run the Claude API proxy."""

from src.claude_proxy.main import main

if __name__ == "__main__":
    main()