from eptr2.tutorials.demo import run_demo_app
from eptr2.tutorials.calc import run_calc_app
from .composite import run_composite_app
