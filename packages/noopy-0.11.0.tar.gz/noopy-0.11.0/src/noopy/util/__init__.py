#!/home/twinkle/venv/bin/python
# -*- encoding: utf-8 -*-

######################################################################
# MAIN
if __name__ == "__main__":
    print(f"[{__name__}]")
    print(__doc__)

#=====================================================================
# ALL - Make it directly accessible from the top level of the package
__all__ = []

""" __DATA__

__END__ """
