# noopy

For singleton dimension(same flatten) tiny simple `list` `str` and `array`(array.array) extender library. This module could be transpose and flip on like 2D singleton dims as result of list extends. This module useful if limited ext modules(numpy, torch, and others) and also passes values to those modules.


## lispy

Based on list `lispy` this class suite, almight for any data.

## strpy

Based on str `strpy` therefore this class suite for treat `str` as like tensor, ndarray.

## arrpy

Based on array.array `arrpy` therefore few memory cost and process speed more than lispy. On the other hand, this library is not suite for treat `str`.

---

## Features

  * **Processing on Basic Module**: Only!
  * **Splitter**:Array splitter have get of best split position function and others.
  * **Transpose**: Transposer is  equivalent 2D free transpose on 1D it's make as possible for `str` array too.
  * **Flip**: Flipper is  equivalent 2D free Flip on 1D it's make as possible for `str` array too.

---

## Installation

You can install `noopy` directly from PyPI:

```bash
pip install noopy
````

-----

## Quick Start

Get started with `lispy` in just a few lines of code:

```python
import noopy as np
from noopy import dumpxh

import noopy.lst as lp
from noopy.lst import lispy
import noopy.arr as ap
from noopy.arr import arrpy
import noopy.str as sp
from noopy.str import strpy

my_lst = lispy([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
my_arr = arrpy('i', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
my_str = strpy(sp.flatten([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))
# 0123456789
#print(my_str)

moji = strpy("0123456789abcdefghijklmnopqrstuvwxyz")
retu = lispy(lp.flatten(moji))
#gyou = arrpy('L', lp.linspace(100, 136, 36, 'i'))
gyou = arrpy('u', u"0123456789abcdefghijklmnopqrstuvwxyz")
```

-----

## Basic Usage

Impremented Features.

## API Reference

### `noopy` Module Methods

  * **is_spl(arr:list, n:int)** Check could be split specified value count.
      * `arr`: (list) Target list.
      * `n`:    (int) This value specified for check availability of split count.
  * **splpos(arr:list)** Get could can be split positions as list(e.g. [2 ,4 ,6 ,8...]).
      * `arr`: (list) Target list.
  * **splmax(arr:list, n:int)** Get first upper split positions from `splpos` function resusts list.
      * `arr`: (list) Target list.
      * `n`:    (int) Search start index.
  * **splmin(arr:list, n:int)** Get first under split positions from `splpos` function resusts list.
      * `arr`: (list) Target list.
      * `n`:    (int) Search start index.
  * **lispy = splist(arr:list, n:int, r:bool)**
      * `arr`: (list) Target list.
      * `n`:    (int) between separation of array split, raise error not match like dimensions.
      * `r`:   (bool) Reverse split elements, default is `False`.

### Common `noopy.lst, noopy.str, noopy.arr` Methods

  suited any moduled type.

  * **zeros(n:int, t:str)**
      * `n`: number of count
      * `t`: type of (`i(int)`, `f(float)`, `s(str)`, `b(byte)`, `u(unicode)`) or specifies `typecode` on arrpy. strpy is only str.
  * **ones(n:int, t:str))**
      * `n`: number of count
      * `t`: type of (`i(int)`, `f(float)`, `s(str)`, `b(byte)`, `u(unicode)`) or specifies `typecode` on arrpy, strpy is only str.
  * **nones(arr:list)**
      * `Not Implemented` (array.array is always 1D, anytime)
      * `arr`: (list) Target list.
  * **linspace(s:float, e:float, n:int, t:str)**
      * `s`: start.
      * `e`: end.
      * `n`: number of count.
      * `t`: type of (`i(int)`, `f(float)`, `s(str)`, `b(byte)`, `u(unicode)`) or specifies `typecode` on arrpy, strpy is only str.
  * **flatten(arr:list)**
      * `arr`: (list) Target list.
  * **transpose(arr:list, x:int, y:int)** Get Split Positions.
      * `arr`: (list) Target list.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(arr:list=None, x:int, y:int, z:str)** Get Split Positions.
      * `arr`: (list) Target list.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full flip).

### `lispy` Class Methods

Still not feature as similar torch functions, not be self update (self) values.

```
# e.g.
ny_list = ny_list.flatten()
```

  * **concat(arr_a:list, arr_b:list)**
      * `arr_a`:    (list) default list.
      * `arr_b`:    (list) concat to.
  * **flatten()**
      * no arguments, return self flattened list.
  * **transpose(x:int, y:int)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(x:int, y:int, z:str)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full flip).

### `strpy` Class Methods

Same above(listpy)

  * **flatten()**
      * no arguments, return self.
      * `Not Implemented` (str is always 1D, anytime)
  * **transpose(x:int, y:int)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(x:int, y:int, z:str)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full fli

### `arrpy` Class Methods

Same above(listpy)

  * **flatten()**
      * no arguments, return self.
      * `Not Implemented` (array.array is always 1D, anytime)
  * **transpose(x:int, y:int)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
  * **flip(x:int, y:int, z:str)** Get Split Positions.
      * `x`:    (int) strict of X direction, raise error not match like dimensions.
      * `y`:    (int) strict of Y direction, raise error not match like dimensions.
      * `z`:    (str) specified direction `x` or `y` or `z`(full fli

#### See Officials:
[array — Efficient arrays of numeric values](https://docs.python.org/3.13/library/array.html)
[(JP)](https://docs.python.org/ja/3.13/library/array.html)

| Type code | C Type             | Python Type       | Minimum size in bytes | Notes | numpy,torch  |
| ---       | ---                | ---               | ---                   | ---   | ---          |
| 'b'       | signed char        | int               | 1                     |       | int8         |
| 'B'       | unsigned char      | int               | 1                     |       | uint8        |
| 'u'       | wchar_t            | Unicode character | 2                     | (1)   | str          |
| 'w'       | Py_UCS4            | Unicode character | 4                     | (2)   | ucs          |
| 'h'       | signed short       | int               | 2                     |       | short8, fp16 |
| 'H'       | unsigned short     | int               | 2                     |       | ushort16     |
| 'i'       | signed int         | int               | 2                     |       | int16        |
| 'I'       | unsigned int       | int               | 2                     |       | uint16       |
| 'l'       | signed long        | int               | 4                     |       | int32        |
| 'L'       | unsigned long      | int               | 4                     |       | uint32       |
| 'q'       | signed long long   | int               | 8                     |       | int64        |
| 'Q'       | unsigned long long | int               | 8                     |       | uint64       |
| 'f'       | float              | float             | 4                     |       | float32      |
| 'd'       | double             | float             | 8                     |       | loat64       |

-----

## Command Line Usage

`noopy` includes a simple command-line interface for testing its console output capabilities.

To run the test, simply execute:

```bash
python -m noopy
==============================
[[lispy]]
import noopy.lst as lp
from noopy.lst import lispy
------------------------------
By the first, this is original list.
0, 1, 2, 3, 4, 5, 
6, 7, 8, 9, a, b, 
c, d, e, f, g, h, 
i, j, k, l, m, n, 
o, p, q, r, s, t, 
u, v, w, x, y, z, 
------------------------------
[ Transpose (6x6) ]
retu.transpose(6, 6)
0, 6, c, i, o, u, 
1, 7, d, j, p, v, 
2, 8, e, k, q, w, 
3, 9, f, l, r, x, 
4, a, g, m, s, y, 
5, b, h, n, t, z, 
[ Flip LR (6x6) ]
retu.flip(6, 6, "x")
5, 4, 3, 2, 1, 0, 
b, a, 9, 8, 7, 6, 
h, g, f, e, d, c, 
n, m, l, k, j, i, 
t, s, r, q, p, o, 
z, y, x, w, v, u, 
[ Flip UD (6x6) ]
retu.flip(6, 6, "y")
u, v, w, x, y, z, 
o, p, q, r, s, t, 
i, j, k, l, m, n, 
c, d, e, f, g, h, 
6, 7, 8, 9, a, b, 
0, 1, 2, 3, 4, 5, 
[ Flip XY (6x6) ]
retu.flip(6, 6, "z")
z, y, x, w, v, u, 
t, s, r, q, p, o, 
n, m, l, k, j, i, 
h, g, f, e, d, c, 
b, a, 9, 8, 7, 6, 
5, 4, 3, 2, 1, 0, 
------------------------------
[Zeros]
lp.zeros(36)
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
[Ones]
lp.ones(36)
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
[ Linspace ]
lp.linspace(40, 80, 36, 'i')
40, 41, 42, 43, 44, 45, 
46, 48, 49, 50, 51, 52, 
53, 54, 56, 57, 58, 59, 
60, 61, 62, 64, 65, 66, 
67, 68, 69, 70, 72, 73, 
74, 75, 76, 77, 78, 80, 
------------------------------
[ Transpose (3x3) ]
lp.transpose(retu, 3, 3)
0, 3, 6, 
1, 4, 7, 
2, 5, 8, 
9, c, f, 
a, d, g, 
b, e, h, 
i, l, o, 
j, m, p, 
k, n, q, 
r, u, x, 
s, v, y, 
t, w, z, 
[ Flip LR (3x3) ]
lp.flip(retu, 3, 3, "z")
2, 1, 0, 
5, 4, 3, 
8, 7, 6, 
b, a, 9, 
e, d, c, 
h, g, f, 
k, j, i, 
n, m, l, 
q, p, o, 
t, s, r, 
w, v, u, 
z, y, x, 
[ Flip UD (3x3) ]
lp.flip(retu, 3, 3, "z")
6, 7, 8, 
3, 4, 5, 
0, 1, 2, 
f, g, h, 
c, d, e, 
9, a, b, 
o, p, q, 
l, m, n, 
i, j, k, 
x, y, z, 
u, v, w, 
r, s, t, 
[ Flip XY (3x3) ]
lp.flip(retu, 3, 3, "z")
8, 7, 6, 
5, 4, 3, 
2, 1, 0, 
h, g, f, 
e, d, c, 
b, a, 9, 
q, p, o, 
n, m, l, 
k, j, i, 
z, y, x, 
w, v, u, 
t, s, r, 

==============================
[[hookpy]]
By the first, this is original [int] array.
tesa = lp.linspace(100, 200, 36, 'i')
100, 102, 105, 108, 111, 114, 
117, 120, 122, 125, 128, 131, 
134, 137, 140, 142, 145, 148, 
151, 154, 157, 160, 162, 165, 
168, 171, 174, 177, 180, 182, 
185, 188, 191, 194, 197, 200, 
tesb = lp.linspace(50, 150, 36, 'i')
50, 52, 55, 58, 61, 64, 
67, 70, 72, 75, 78, 81, 
84, 87, 90, 92, 95, 98, 
101, 104, 107, 110, 112, 115, 
118, 121, 124, 127, 130, 132, 
135, 138, 141, 144, 147, 150, 
------------------------------
[concat]
print(lp.concat(tesa, tesb))
100, 102, 105, 108, 111, 114, 
117, 120, 122, 125, 128, 131, 
134, 137, 140, 142, 145, 148, 
151, 154, 157, 160, 162, 165, 
168, 171, 174, 177, 180, 182, 
185, 188, 191, 194, 197, 200, 
50, 52, 55, 58, 61, 64, 
67, 70, 72, 75, 78, 81, 
84, 87, 90, 92, 95, 98, 
101, 104, 107, 110, 112, 115, 
118, 121, 124, 127, 130, 132, 
135, 138, 141, 144, 147, 150, 
print(tesa.concat(tesb))
100, 102, 105, 108, 111, 114, 
117, 120, 122, 125, 128, 131, 
134, 137, 140, 142, 145, 148, 
151, 154, 157, 160, 162, 165, 
168, 171, 174, 177, 180, 182, 
185, 188, 191, 194, 197, 200, 
50, 52, 55, 58, 61, 64, 
67, 70, 72, 75, 78, 81, 
84, 87, 90, 92, 95, 98, 
101, 104, 107, 110, 112, 115, 
118, 121, 124, 127, 130, 132, 
135, 138, 141, 144, 147, 150, 
------------------------------
print(tesa + tesb)
__add__
150, 154, 160, 166, 172, 178, 
184, 190, 194, 200, 206, 212, 
218, 224, 230, 234, 240, 246, 
252, 258, 264, 270, 274, 280, 
286, 292, 298, 304, 310, 314, 
320, 326, 332, 338, 344, 350, 
print(1 + tesb)
__radd__
51, 53, 56, 59, 62, 65, 
68, 71, 73, 76, 79, 82, 
85, 88, 91, 93, 96, 99, 
102, 105, 108, 111, 113, 116, 
119, 122, 125, 128, 131, 133, 
136, 139, 142, 145, 148, 151, 
tesa += tesb
__iadd__
150, 154, 160, 166, 172, 178, 
184, 190, 194, 200, 206, 212, 
218, 224, 230, 234, 240, 246, 
252, 258, 264, 270, 274, 280, 
286, 292, 298, 304, 310, 314, 
320, 326, 332, 338, 344, 350, 
tesa -= tesb
__isub__
100, 102, 105, 108, 111, 114, 
117, 120, 122, 125, 128, 131, 
134, 137, 140, 142, 145, 148, 
151, 154, 157, 160, 162, 165, 
168, 171, 174, 177, 180, 182, 
185, 188, 191, 194, 197, 200, 
print(tesa - tesb)
__sub__
50, 50, 50, 50, 50, 50, 
50, 50, 50, 50, 50, 50, 
50, 50, 50, 50, 50, 50, 
50, 50, 50, 50, 50, 50, 
50, 50, 50, 50, 50, 50, 
50, 50, 50, 50, 50, 50, 
print(tesa * 2)
__mul__
200, 204, 210, 216, 222, 228, 
234, 240, 244, 250, 256, 262, 
268, 274, 280, 284, 290, 296, 
302, 308, 314, 320, 324, 330, 
336, 342, 348, 354, 360, 364, 
370, 376, 382, 388, 394, 400, 
print(tesa / tesb)
__truediv__
2.0, 1.9615384615384615, 1.9090909090909092, 1.8620689655172413, 1.819672131147541, 1.78125, 
1.7462686567164178, 1.7142857142857142, 1.6944444444444444, 1.6666666666666667, 1.641025641025641, 1.617283950617284, 
1.5952380952380953, 1.5747126436781609, 1.5555555555555556, 1.5434782608695652, 1.5263157894736843, 1.510204081632653, 
1.495049504950495, 1.4807692307692308, 1.4672897196261683, 1.4545454545454546, 1.4464285714285714, 1.434782608695652, 
1.423728813559322, 1.4132231404958677, 1.403225806451613, 1.3937007874015748, 1.3846153846153846, 1.378787878787879, 
1.3703703703703705, 1.3623188405797102, 1.3546099290780143, 1.3472222222222223, 1.3401360544217686, 1.3333333333333333, 
print(tesa ** 2)
__pow__
10000, 10404, 11025, 11664, 12321, 12996, 
13689, 14400, 14884, 15625, 16384, 17161, 
17956, 18769, 19600, 20164, 21025, 21904, 
22801, 23716, 24649, 25600, 26244, 27225, 
28224, 29241, 30276, 31329, 32400, 33124, 
34225, 35344, 36481, 37636, 38809, 40000, 
print(tesa // tesb)
__floordiv__
2, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
print(tesa & tesb)
__and__
32, 36, 33, 40, 45, 64, 
65, 64, 72, 73, 0, 1, 
4, 1, 8, 12, 17, 0, 
5, 8, 9, 32, 32, 33, 
32, 41, 44, 49, 128, 132, 
129, 136, 141, 128, 129, 128, 
print(tesa | tesb)
__or__
118, 118, 127, 126, 127, 114, 
119, 126, 122, 127, 206, 211, 
214, 223, 222, 222, 223, 246, 
247, 250, 255, 238, 242, 247, 
254, 251, 254, 255, 182, 182, 
191, 190, 191, 210, 215, 222, 
print(tesa ^ tesb)
__xor__
86, 82, 94, 86, 82, 50, 
54, 62, 50, 54, 206, 210, 
210, 222, 214, 210, 206, 246, 
242, 242, 246, 206, 210, 214, 
222, 210, 210, 206, 54, 50, 
62, 54, 50, 82, 86, 94, 
print(tesa << tesb)
__lshift__
112589990684262400, 459367161991790592, 3783023686991216640, 31128880624384868352, 255948574022720028672, 2102928824402888884224, 
17266152452992140312576, 141670994486089356410880, 576128710910096716070912, 4722366482869645213696000, 38685626227668133590597632, 316738564739032843773018112, 
2591936957253764950570041344, 21199723172762137207647502336, 173311605499953238485877391360, 703149942314095996142702559232, 5744041782284164475531936399360, 46903072208444487855378018598912, 
382830481268925279252004368023552, 3123491078962357245287876698046464, 25474706462186498052477747615236096, 207691874341393105141219853168803840, 841152091082642075821940405333655552, 6853831853265972469660255154570526720, 
55827575822966466661959896531774472192, 454595974558441228533102014615877844992, 3700570740265205790164198855820479299584, 30114989472503054016508652757711486713856, 245003304183075693693629717350873112248320, 990902252473772805605346856841309031759872, 
8057886448687822814812710703984271247278080, 65508439020683705478261172425904561923817472, 532430291614918627504165273759479630955282432, 4326344568514940889457929344893782132160200704, 35145974432884262071060291997693817733425135616, 285449538541191976211657193889899027276549324800, 
print(tesa >> tesb)
__rshift__
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 

==============================
[[mathpy]]
By the first, this is original [int] array.
tesp = lp.linspace(100, 200, 36, 'i')
100, 102, 105, 108, 111, 114, 
117, 120, 122, 125, 128, 131, 
134, 137, 140, 142, 145, 148, 
151, 154, 157, 160, 162, 165, 
168, 171, 174, 177, 180, 182, 
185, 188, 191, 194, 197, 200, 
tesm = lp.linspace(-100, 100, 36, 'i')
-100, -94, -88, -82, -77, -71, 
-65, -60, -54, -48, -42, -37, 
-31, -25, -20, -14, -8, -2, 
2, 8, 14, 20, 25, 31, 
37, 42, 48, 54, 60, 65, 
71, 77, 82, 88, 94, 100, 
------------------------------
[ mm (6x6) ]
lp.mm(6, 6)
-10000, -6630, -3255, 216, 4107, 8094, 
-10998, -7200, -3050, 1000, 5376, 10087, 
-11792, -7398, -2800, 1988, 6960, 12136, 
-12382, -7392, -2198, 3200, 8748, 14520, 
-12936, -7182, -1392, 4425, 10800, 17108, 
-13135, -6956, -382, 6014, 12805, 20000, 
------------------------------
print(tesp.pi)
3.141592653589793
print(tesp.pih)
1.5707963267948966
------------------------------
[ sign ]
print(tesm.sign())
['-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1']
[ sqrt ]
print(tesp.sqrt())
['10.0', '10.099504938362077', '10.246950765959598', '10.392304845413264', '10.535653752852738', '10.677078252031311', '10.816653826391969', '10.954451150103322', '11.045361017187261', '11.180339887498949', '11.313708498984761', '11.445523142259598', '11.575836902790225', '11.704699910719626', '11.832159566199232', '11.916375287812984', '12.041594578792296', '12.165525060596439', '12.288205727444508', '12.409673645990857', '12.529964086141668', '12.649110640673518', '12.727922061357855', '12.84523257866513', '12.96148139681572', '13.076696830622021', '13.19090595827292', '13.30413469565007', '13.416407864998739', '13.490737563232042', '13.601470508735444', '13.711309200802088', '13.820274961085254', '13.92838827718412', '14.035668847618199', '14.142135623730951']
[ sqrtpi ]
print(tesp.sqrtpi())
['17.72453850905516', '17.900906420239142', '18.162247345164317', '18.419880743036792', '18.673960066050988', '18.924628464232434', '19.172019728500327', '19.41625912555699', '19.577392669555227', '19.816636488030053', '20.053026197048002', '20.286661569126224', '20.517636695804715', '20.74604043044845', '20.97195678763837', '21.121225267719453', '21.343170682223388', '21.56283174194172', '21.780277562328234', '21.99557384231719', '22.208783096189613', '22.419964865591716', '22.559654471679004', '22.767581949832', '22.97362761522623', '23.177841654559955', '23.38027206267335', '23.580964774270655', '23.779963785636067', '23.91170974550633', '24.107978781185942', '24.302662793917897', '24.495799575348638', '24.687425438802236', '24.877575298995463', '25.066282746310005']
[ signed_sqrt ]
print(tesm.signed_sqrt())
['-10.0', '-9.695359714832659', '-9.38083151964686', '-9.055385138137417', '-8.774964387392123', '-8.426149773176359', '-8.06225774829855', '-7.745966692414834', '-7.3484692283495345', '-6.928203230275509', '-6.48074069840786', '-6.082762530298219', '-5.5677643628300215', '-5.0', '-4.47213595499958', '-3.7416573867739413', '-2.8284271247461903', '-1.4142135623730951', '1.4142135623730951', '2.8284271247461903', '3.7416573867739413', '4.47213595499958', '5.0', '5.5677643628300215', '6.082762530298219', '6.48074069840786', '6.928203230275509', '7.3484692283495345', '7.745966692414834', '8.06225774829855', '8.426149773176359', '8.774964387392123', '9.055385138137417', '9.38083151964686', '9.695359714832659', '10.0']
[ signed_sqrtpi ]
print(tesm.signed_sqrtpi())
['-17.72453850905516', '-17.18457766246935', '-16.62709095169392', '-16.050252259524243', '-15.55321941999193', '-14.934961613773078', '-14.289979792964598', '-13.729368492956533', '-13.024822582048817', '-12.279920495357862', '-11.486813807613116', '-10.78141587097086', '-9.868605385832568', '-8.86226925452758', '-7.926654595212022', '-6.631915043956542', '-5.0132565492620005', '-2.5066282746310002', '2.5066282746310002', '5.0132565492620005', '6.631915043956542', '7.926654595212022', '8.86226925452758', '9.868605385832568', '10.78141587097086', '11.486813807613116', '12.279920495357862', '13.024822582048817', '13.729368492956533', '14.289979792964598', '14.934961613773078', '15.55321941999193', '16.050252259524243', '16.62709095169392', '17.18457766246935', '17.72453850905516']

==============================
[[strpy]]
import noopy.str as sp
from noopy.str import strpy
------------------------------
By the first, this is original [str] array.
0123456789abcdefghijklmnopqrstuvwxyz 6
------------------------------
[ Transpose (6x6) ]
moji.transpose(6, 6)
0, 6, c, i, o, u, 
1, 7, d, j, p, v, 
2, 8, e, k, q, w, 
3, 9, f, l, r, x, 
4, a, g, m, s, y, 
5, b, h, n, t, z, 
[ Flip LR (6x6) ]
moji.flip(6, 6, "x")
543210ba9876hgfedcnmlkjitsrqpozyxwvu
5, 4, 3, 2, 1, 0, 
b, a, 9, 8, 7, 6, 
h, g, f, e, d, c, 
n, m, l, k, j, i, 
t, s, r, q, p, o, 
z, y, x, w, v, u, 
[ Flip UD (6x6) ]
moji.flip(6, 6, "y")
uvwxyzopqrstijklmncdefgh6789ab012345
u, v, w, x, y, z, 
o, p, q, r, s, t, 
i, j, k, l, m, n, 
c, d, e, f, g, h, 
6, 7, 8, 9, a, b, 
0, 1, 2, 3, 4, 5, 
[ Flip XY (6x6) ]
moji.flip(6, 6, "z")
zyxwvutsrqponmlkjihgfedcba9876543210
z, y, x, w, v, u, 
t, s, r, q, p, o, 
n, m, l, k, j, i, 
h, g, f, e, d, c, 
b, a, 9, 8, 7, 6, 
5, 4, 3, 2, 1, 0, 
[ mm (6x6) * can be calc as (u)int8, can get numeric value from ord ]
sp.mm(6, 6)
	


*-(*-0*-03*-037-037:
	, 
, , , , , 

, 
  , , , *, -, 
, , (, *, -, 0, 
, , *, -, 0, 3, 
, *, -, 0, 3, 7, 
, -, 0, 3, 7, :, 
------------------------------
[ Zeros ]
sp.zeros(36)
000000000000000000000000000000000000
[ Ones ]
sp.ones(36)
111111111111111111111111111111111111
[ Linspace (fake dummy string) ]
sp.linspace(40, 80, 36, 'f')
40.0,41.14,42.29,43.43,44.57,45.71,46.86,48.0,49.14,50.29,51.43,52.57,53.71,54.86,56.0,57.14,58.29,59.43,60.57,61.71,62.86,64.0,65.14,66.29,67.43,68.57,69.71,70.86,72.0,73.14,74.29,75.43,76.57,77.71,78.86,80.0,
------------------------------
[ Transpose (3x3) ]
sp.transpose(moji, 3, 3)
0361472589cfadgbehilojmpknqruxsvytwz
0, 3, 6, 
1, 4, 7, 
2, 5, 8, 
9, c, f, 
a, d, g, 
b, e, h, 
i, l, o, 
j, m, p, 
k, n, q, 
r, u, x, 
s, v, y, 
t, w, z, 
[ Flip XY (3x3) ]
sp.flip(moji, 3, 3, "z")
876543210hgfedcba9qponmlkjizyxwvutsr
8, 7, 6, 
5, 4, 3, 
2, 1, 0, 
h, g, f, 
e, d, c, 
b, a, 9, 
q, p, o, 
n, m, l, 
k, j, i, 
z, y, x, 
w, v, u, 
t, s, r, 

[[noopy fetaures]]
Available split positions.
np.splpos(moji)
[2, 3, 6, 9, 18]
Available split to 9(9x4)?
np.is_spl(moji, 9)
True
Split to 9(9x4).
splt = np.splist(moji, 9)
['012345678', '9abcdefgh', 'ijklmnopq', 'rstuvwxyz']
(** Str to List)
<class 'noopy.str.strpy'>  ->  <class 'noopy.lst.lispy'>
------------------------------
[ Flatten (strpy) ]
fltn = sp.flatten(splt)
0123456789abcdefghijklmnopqrstuvwxyz
(** List to Str
<class 'noopy.lst.lispy'>  ->  <class 'noopy.str.strpy'>
[ Flatten (lispy) ]
lp.flatten(splt)
['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

==============================
[[arrpy]]
import noopy.arr as ap
from noopy.arr import arrpy
------------------------------
typecodes: bBuhHiIlLqQfd
------------------------------
By the first, this is original [unicode 'u'] array.
0, 1, 2, 3, 4, 5, 
6, 7, 8, 9, a, b, 
c, d, e, f, g, h, 
i, j, k, l, m, n, 
o, p, q, r, s, t, 
u, v, w, x, y, z, 
------------------------------
[ Transpose (6x6) ]
gyou.transpose(6, 6)
0, 6, c, i, o, u, 
1, 7, d, j, p, v, 
2, 8, e, k, q, w, 
3, 9, f, l, r, x, 
4, a, g, m, s, y, 
5, b, h, n, t, z, 
[ Flip LR (6x6) ]
gyou.flip(6, 6, "x")
5, 4, 3, 2, 1, 0, 
b, a, 9, 8, 7, 6, 
h, g, f, e, d, c, 
n, m, l, k, j, i, 
t, s, r, q, p, o, 
z, y, x, w, v, u, 
[ Flip UD (6x6) ]
gyou.flip(6, 6, "y")
u, v, w, x, y, z, 
o, p, q, r, s, t, 
i, j, k, l, m, n, 
c, d, e, f, g, h, 
6, 7, 8, 9, a, b, 
0, 1, 2, 3, 4, 5, 
[ Flip XY (6x6) ]
gyou.flip(6, 6, "z")
z, y, x, w, v, u, 
t, s, r, q, p, o, 
n, m, l, k, j, i, 
h, g, f, e, d, c, 
b, a, 9, 8, 7, 6, 
5, 4, 3, 2, 1, 0, 
------------------------------
[Zeros]
ap.zeros(36)
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 
[Ones]
ap.ones(36)
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 
[ Linspace ]
ap.linspace(40, 80, 36, 'i')
40, 41, 42, 43, 44, 45, 
46, 48, 49, 50, 51, 52, 
53, 54, 56, 57, 58, 59, 
60, 61, 62, 64, 65, 66, 
67, 68, 69, 70, 72, 73, 
74, 75, 76, 77, 78, 80, 
------------------------------
[ Transpose (3x3) ]
ap.transpose(gyou, 3, 3)
0, 3, 6, 
1, 4, 7, 
2, 5, 8, 
9, c, f, 
a, d, g, 
b, e, h, 
i, l, o, 
j, m, p, 
k, n, q, 
r, u, x, 
s, v, y, 
t, w, z, 
[ Flip LR (3x3) ]
ap.flip(gyou, 3, 3, "z")
2, 1, 0, 
5, 4, 3, 
8, 7, 6, 
b, a, 9, 
e, d, c, 
h, g, f, 
k, j, i, 
n, m, l, 
q, p, o, 
t, s, r, 
w, v, u, 
z, y, x, 
[ Flip UD (3x3) ]
ap.flip(gyou, 3, 3, "z")
6, 7, 8, 
3, 4, 5, 
0, 1, 2, 
f, g, h, 
c, d, e, 
9, a, b, 
o, p, q, 
l, m, n, 
i, j, k, 
x, y, z, 
u, v, w, 
r, s, t, 
[ Flip XY (3x3) ]
ap.flip(gyou, 3, 3, "z")
8, 7, 6, 
5, 4, 3, 
2, 1, 0, 
h, g, f, 
e, d, c, 
b, a, 9, 
q, p, o, 
n, m, l, 
k, j, i, 
z, y, x, 
w, v, u, 
t, s, r, 
```

-----

## Contributing

We welcome contributions to `noopy`\! If you find a bug, have a feature request, or would like to contribute code, please check out our GitHub repository and open an issue or pull request.

-----

## License

`noopy` is licensed under the GPLv3 AND LicenseRef-RPTv1.
