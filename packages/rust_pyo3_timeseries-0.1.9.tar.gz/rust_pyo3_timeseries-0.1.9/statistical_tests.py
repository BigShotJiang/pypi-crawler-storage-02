# runtime shim; types in .pyi
