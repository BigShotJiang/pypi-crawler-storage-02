# shim so editors & type-checkers can find the compiled extension
from . import statistical_tests  # type: ignore
