## cdf 

### Fixed

- When running command `cdf dump group` you can now select multiple
groups.

## templates

No changes.