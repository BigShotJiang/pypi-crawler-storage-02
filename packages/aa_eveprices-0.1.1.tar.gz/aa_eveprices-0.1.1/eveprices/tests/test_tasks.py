from django.test import TestCase


class TestTasks(TestCase):
    def test_should_run_task(self):
        # given
        ...
        # when
        ...
        # then
        ...
