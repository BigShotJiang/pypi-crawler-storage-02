from libhans import HansRobot

robot = HansRobot()

# 打印版本信息
print(robot.version())