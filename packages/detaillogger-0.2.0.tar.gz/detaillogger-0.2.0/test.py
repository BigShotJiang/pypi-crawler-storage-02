import detaillogger
from detaillogger import main

main()