#include "libadic/zp.h"

namespace libadic {

// All implementation is in the header for now

} // namespace libadic