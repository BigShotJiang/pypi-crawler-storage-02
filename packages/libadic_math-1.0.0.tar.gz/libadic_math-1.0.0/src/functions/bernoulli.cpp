#include "libadic/bernoulli.h"

namespace libadic {

// Implementation is in header for now due to templates and static members

} // namespace libadic