#include "libadic/gmp_wrapper.h"

namespace libadic {

// All implementation is in the header for inline optimization

} // namespace libadic