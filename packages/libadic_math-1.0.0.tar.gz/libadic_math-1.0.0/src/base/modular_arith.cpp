#include "libadic/modular_arith.h"

namespace libadic {

// All implementation is in the header for inline optimization

} // namespace libadic