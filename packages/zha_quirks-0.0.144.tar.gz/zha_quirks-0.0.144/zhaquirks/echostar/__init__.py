"""Module for Echostar quirks implementations."""
