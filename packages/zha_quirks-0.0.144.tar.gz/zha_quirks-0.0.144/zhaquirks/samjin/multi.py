"""Samjin Multi Quirk."""
# <SimpleDescriptor endpoint=1 profile=260 device_type=1026
# device_version=0
# input_clusters=[0, 1, 3, 32, 1026, 1280, 64514]
# output_clusters=[3, 25]>
