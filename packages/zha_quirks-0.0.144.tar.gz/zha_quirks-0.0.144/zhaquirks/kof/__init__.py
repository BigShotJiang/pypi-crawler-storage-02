"""Module for King of Fans devices."""
