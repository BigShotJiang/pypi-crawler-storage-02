"""Quirks for Heiman devices."""

HEIMAN = "Heiman"
