"""Module for Visonic quirks implementations."""
