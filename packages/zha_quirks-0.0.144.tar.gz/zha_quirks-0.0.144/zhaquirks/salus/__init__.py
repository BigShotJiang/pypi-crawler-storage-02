"""Salus quirks elements."""

COMPUTIME = "Computime"
