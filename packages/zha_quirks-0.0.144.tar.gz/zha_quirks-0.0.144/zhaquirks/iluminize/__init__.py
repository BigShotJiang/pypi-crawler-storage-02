"""Module for iluminize devices."""

ILUMINIZE = "iluminize"
