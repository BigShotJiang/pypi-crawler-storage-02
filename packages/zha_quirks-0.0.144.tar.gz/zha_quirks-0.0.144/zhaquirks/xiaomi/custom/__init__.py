"""Module for Xiaomi custom firmware quirks implementations."""
