"""version file for tagny_mcp_server package."""

__version__ = "0.1.1"
