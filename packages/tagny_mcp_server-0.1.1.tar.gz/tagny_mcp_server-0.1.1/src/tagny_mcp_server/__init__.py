"""main package for tagny-mcp-server"""

from tagny_mcp_server.__version__ import __version__

__all__ = ["__version__"]
