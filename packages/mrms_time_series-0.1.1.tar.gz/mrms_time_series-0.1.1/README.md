## Acknowledgments
This software allows users to input coordinates and a date range to automatically download time series of rainfall or streamflow data from the MRMS archive available at https://mtarchive.geol.iastate.edu/, including QPE rainfall and FLASH streamflow products.

This package was developed by Gonzalo Forero Buitrago under the supervision of Dr. Humberto Vergara Arrieta at the University of Iowa, as part of the Advanced Hydrology and Warning Applications research at IIHR – Hydroscience & Engineering.

Special thanks to Dr. Humberto Vergara Arrieta for his guidance and support during the development of this software, and to Ruben Molina for generously sharing his knowledge.




