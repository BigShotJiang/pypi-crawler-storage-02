from ...segtypes.segment import Segment, SegmentType


class CommonSegment(Segment):
    pass
