# Title

## Status

<!--What is the status? -->

{ Proposed - Accepted - Rejected - Deprecated - Superseded by {ADR-NUM} } - DD/MM/YYYY

## Context

<!--What is the issue that we are seeing that is motivating this decision or change?-->

## Decision

<!--Describe the change that you are proposing.-->

## Scope of Change

<!--Specify which Anemoi packages/modules will be affected by this decision.-->

## Consequences

<!--Discuss the impact of this decision, including benefits, trade-offs, and potential technical debt.-->

## Alternatives Considered [Optional]

<!--List alternative solutions and why they were not chosen.-->

## References [Optional]

<!--Links to relevant discussions, documentation, or external resources.-->
