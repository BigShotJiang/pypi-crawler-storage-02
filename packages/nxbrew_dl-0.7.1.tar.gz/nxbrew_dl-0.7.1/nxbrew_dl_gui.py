from nxbrew_dl import run_nxbrew_gui

if __name__ == "__main__":
    run_nxbrew_gui()
