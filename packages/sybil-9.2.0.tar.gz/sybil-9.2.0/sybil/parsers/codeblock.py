# THIS MODULE IS FOR BACKWARDS COMPATIBILITY ONLY!

from .rest import CodeBlockParser, PythonCodeBlockParser

__all__ = ['CodeBlockParser', 'PythonCodeBlockParser']
