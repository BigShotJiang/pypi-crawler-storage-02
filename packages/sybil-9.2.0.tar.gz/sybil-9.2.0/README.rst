Sybil
=====

|CircleCI|_ |Docs|_

.. |CircleCI| image:: https://circleci.com/gh/simplistix/sybil/tree/master.svg?style=shield
.. _CircleCI: https://circleci.com/gh/simplistix/sybil/tree/master

.. |Docs| image:: https://readthedocs.org/projects/sybil/badge/?version=latest
.. _Docs: http://sybil.readthedocs.org/en/latest/


This library provides a way to check examples in your code and documentation by parsing
them from their source and evaluating the parsed examples as part of
your normal test run. Integration is provided for the main Python test
runners.

The `documentation <https://sybil.readthedocs.io/>`__ is the best place to start.
