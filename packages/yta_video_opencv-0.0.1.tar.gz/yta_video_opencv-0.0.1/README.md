# Youtube Autonomous Video OpenCV Module

The way to handle video handling with OpenCV.