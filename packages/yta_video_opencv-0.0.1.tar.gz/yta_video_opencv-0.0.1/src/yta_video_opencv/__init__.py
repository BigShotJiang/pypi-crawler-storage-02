"""
Module to include video handling with the
OpenCV library.
"""