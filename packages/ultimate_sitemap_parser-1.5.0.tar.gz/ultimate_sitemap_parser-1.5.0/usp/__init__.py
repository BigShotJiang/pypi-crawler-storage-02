from importlib.metadata import version

__version__ = version("ultimate-sitemap-parser")

__all__ = ["tree", "__version__"]
