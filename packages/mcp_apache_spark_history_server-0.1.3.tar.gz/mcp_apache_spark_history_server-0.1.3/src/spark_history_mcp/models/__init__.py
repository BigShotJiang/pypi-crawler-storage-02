"""Data models for Spark History Server MCP."""
