# Copyright: Contributors to the sts project
# SPDX-License-Identifier: GPL-3.0-or-later

"""iSCSI management.

This module provides functionality for managing iSCSI.
"""
