ENGINE_PREFIX: str = "engine"
HUB_PREFIX: str = "engine/hub"

DEFAULT_COLLECTION = "default"
DEFAULT_SORT_FIELD = "timestamp"
