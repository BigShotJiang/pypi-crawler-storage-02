# FixedAssetPlugin

Add Fixed Asset Parameter to every new Part created

## Installation

### InvenTree Plugin Manager

... todo ...

### Command Line 

To install manually via the command line, run the following command:

```bash
pip install fixed-asset-plugin
```

## Configuration

... todo ...

## Usage

... todo ...
