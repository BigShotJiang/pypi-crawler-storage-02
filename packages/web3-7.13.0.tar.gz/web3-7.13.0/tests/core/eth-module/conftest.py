import pytest


@pytest.fixture
def account_password():
    return "this-is-not-a-secure-password"
