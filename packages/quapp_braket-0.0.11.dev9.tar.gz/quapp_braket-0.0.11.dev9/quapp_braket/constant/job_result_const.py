#  Quapp Platform Project
#  job_result_const.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.

CREATED_AT = 'createdAt'
ENDED_AT = 'endedAt'
TASK_METADATA = 'task_metadata'
SHOTS = 'shots'
MEAS = 'meas'
OUTPUT_S3_DIRECTORY = 'outputS3Directory'
OUTPUT_S3_BUCKET = 'outputS3Bucket'
METADATA = 'taskMetadata'
MEASUREMENTS = 'measurements'
RESULTS_JSON = 'results.json'
