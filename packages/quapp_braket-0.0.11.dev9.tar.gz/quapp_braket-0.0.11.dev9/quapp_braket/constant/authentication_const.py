#  Quapp Platform Project
#  authentication_const.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.

ACCESS_KEY = 'accessKey'
ACCESS_TOKEN = 'accessToken'
REGION_NAME = 'regionName'
SECRET_KEY = 'secretKey'
URL = 'url'
BUCKET_NAME = 'bucketName'
PREFIX = 'prefix'
