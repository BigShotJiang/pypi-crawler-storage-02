from oarepo_runtime.services.service import SearchAllRecordsService


class CommonService(SearchAllRecordsService):
    """CommonRecord service."""
