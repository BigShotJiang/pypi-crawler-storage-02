# module initialization
from .adapta_test import main as test
