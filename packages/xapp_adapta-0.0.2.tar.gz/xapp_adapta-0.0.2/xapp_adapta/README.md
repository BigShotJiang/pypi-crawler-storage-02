# A python module using `libadapta`

This is the `PyPI` readme. Included commands can be used for effect. Add
any commands to the `pyproject.toml` in the source linked below.

Are you sure you've changed any `xapp_adapta` references to be unique?
Please check `pyproject.toml` and rename the module directory from `xapp_adapta`.

Included commands (add more):

- `./bin/test` the basic original python demo of `libadapta`.
- ...

Thanks

[Template Source](https://github.com/jackokring/mint-python-adapta)
