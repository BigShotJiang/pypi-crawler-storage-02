from . import cli


def _main():
    cli.main()
 

if __name__ == '__main__':
    _main()
