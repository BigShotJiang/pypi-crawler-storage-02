(mpi0^2*(Sqrt[2]*thetaALP + thetaprALP + 
   cg*kappad*(Sqrt[3] + deltaI*(Sqrt[3] + 2*Sqrt[2]*thetapi - thetaprpi)) + 
   cg*kappau*(Sqrt[3] + deltaI*(-Sqrt[3] - 2*Sqrt[2]*thetapi + thetaprpi)) - Sqrt[3]*deltaI*thpiALP - 
   2*Sqrt[2]*deltaI*thetapi*thpiALP + deltaI*thetaprpi*thpiALP))/(3*F0^2)