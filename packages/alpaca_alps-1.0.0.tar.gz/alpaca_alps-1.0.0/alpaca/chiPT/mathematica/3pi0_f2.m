(gT^2*(3*cg*(kappad - kappau) + deltaI*(Sqrt[3]*cg*(kappad + kappau) + thetaprALP)*
    (Sqrt[2]*thetapi + thetaprpi) + deltaI*thetaALP*(2*thetapi + Sqrt[2]*thetaprpi) - 3*thpiALP)*
  (((-6*m23^2*mf2^4 + m12^2*(mf2^2 - 2*mpi0^2)*(ma^2 - mf2^2 + mpi0^2) + 6*m23*mf2^4*(ma^2 + 3*mpi0^2) - 
      4*mf2^2*mpi0^2*(ma^4 + 2*mf2^2*mpi0^2 + mpi0^4 + 2*ma^2*(mf2^2 - mpi0^2)) + 
      m12*(-6*m23*mf2^4 + 3*mf2^4*mpi0^2 + mf2^2*mpi0^4 + 2*mpi0^6 - ma^4*(mf2^2 - 2*mpi0^2) + 
        ma^2*(mf2^4 + 4*mf2^2*mpi0^2 - 4*mpi0^4)))*UnitStep[m12 - (Gammaf2 - mf2)^2])/
    (-4*m12 + 4*mf2*((-I)*Gammaf2 + mf2)) + 
   ((-6*m12^2*mf2^4 + m23^2*(mf2^2 - 2*mpi0^2)*(ma^2 - mf2^2 + mpi0^2) + 6*m12*mf2^4*(ma^2 + 3*mpi0^2) - 
      4*mf2^2*mpi0^2*(ma^4 + 2*mf2^2*mpi0^2 + mpi0^4 + 2*ma^2*(mf2^2 - mpi0^2)) + 
      m23*(-6*m12*mf2^4 + 3*mf2^4*mpi0^2 + mf2^2*mpi0^4 + 2*mpi0^6 - ma^4*(mf2^2 - 2*mpi0^2) + 
        ma^2*(mf2^4 + 4*mf2^2*mpi0^2 - 4*mpi0^4)))*UnitStep[m23 - (Gammaf2 - mf2)^2])/
    (-4*m23 + 4*mf2*((-I)*Gammaf2 + mf2)) + 
   ((m12^2*(mf2^2 - 2*mpi0^2)*(ma^2 - mf2^2 + mpi0^2) + m23^2*(mf2^2 - 2*mpi0^2)*
       (ma^2 - mf2^2 + mpi0^2) - 2*mpi0^2*(4*mf2^4*mpi0^2 - 13*mf2^2*mpi0^4 + 6*mpi0^6 - 
        3*ma^4*(mf2^2 - 2*mpi0^2) + 4*ma^2*(mf2^4 - 6*mf2^2*mpi0^2 + 5*mpi0^4)) + 
      m23*(3*mf2^4*mpi0^2 - 19*mf2^2*mpi0^4 + 10*mpi0^6 - ma^4*(mf2^2 - 2*mpi0^2) + 
        ma^2*(mf2^4 - 16*mf2^2*mpi0^2 + 20*mpi0^4)) + m12*(3*mf2^4*mpi0^2 - 19*mf2^2*mpi0^4 + 
        10*mpi0^6 - ma^4*(mf2^2 - 2*mpi0^2) + ma^2*(mf2^4 - 16*mf2^2*mpi0^2 + 20*mpi0^4) + 
        2*m23*(2*mf2^4 + 3*mf2^2*mpi0^2 - 2*mpi0^4 + ma^2*(mf2^2 - 2*mpi0^2))))*
     UnitStep[-m12 - m23 + ma^2 - (Gammaf2 - mf2)^2 + 3*mpi0^2])/
    (4*(m12 + m23 - ma^2 - I*Gammaf2*mf2 + mf2^2 - 3*mpi0^2))))/(36*mf2^4)