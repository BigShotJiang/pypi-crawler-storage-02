((m23 - ma^2 - meta^2)*(m23 - 2*mpiplus^2)*(Sqrt[2]*(CoefA - CoefB)*Cos[thetas] + 2*CoefB*Sin[thetas])*
  (2*(3*Sqrt[2]*CoefB*thetaALP - Sqrt[2]*CoefC*thetaALP + Sqrt[2]*CoefD*thetaALP + 
     cg*(2*Sqrt[3]*CoefD + 2*Sqrt[3]*CoefA*kappad - Sqrt[3]*CoefC*kappad + 2*Sqrt[3]*CoefA*kappau - 
       Sqrt[3]*CoefC*kappau + 3*Sqrt[2]*CoefA*deltaI*kappad*thetapi - 3*Sqrt[2]*CoefA*deltaI*kappau*
        thetapi + CoefB*(-2*Sqrt[3] + 4*Sqrt[3]*kappad + 4*Sqrt[3]*kappau - 
         3*Sqrt[2]*deltaI*kappad*thetapi + 3*Sqrt[2]*deltaI*kappau*thetapi)) - CoefC*thetaprALP + 
     4*CoefD*thetaprALP + 3*Sqrt[2]*CoefB*deltaI*thetapi*thpiALP + 
     CoefA*(2*Sqrt[2]*thetaALP + 2*thetaprALP - 3*Sqrt[2]*deltaI*thetapi*thpiALP))*Cos[thetas] + 
   (8*CoefA*thetaALP - 12*CoefB*thetaALP - 4*CoefC*thetaALP - 4*CoefD*thetaALP + 
     cg*(2*Sqrt[6]*CoefA*(-2 + 3*kappad + 3*kappau) - Sqrt[6]*(4*CoefD + CoefC*(2 + kappad + kappau)) - 
       4*CoefB*(-Sqrt[6] + 2*Sqrt[6]*kappad + 2*Sqrt[6]*kappau - 3*deltaI*kappad*thetapi + 
         3*deltaI*kappau*thetapi)) - 2*Sqrt[2]*CoefA*thetaprALP - 5*Sqrt[2]*CoefC*thetaprALP - 
     8*Sqrt[2]*CoefD*thetaprALP - 12*CoefB*deltaI*thetapi*thpiALP)*Sin[thetas])*
  UnitStep[-m23 + 4*mKplus^2])/(24*(m23 + I*(Gammasigma + I*msigma)*msigma))