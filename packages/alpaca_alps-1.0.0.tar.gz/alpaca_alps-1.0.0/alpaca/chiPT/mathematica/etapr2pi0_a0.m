((deltaI*(m23 - ma^2 - metap^2)*(m23 - 2*mpi0^2)*(2*Sqrt[2]*CoefA*thetapi + Sqrt[2]*CoefC*thetapi - 
     4*CoefA*thetaprpi + 4*CoefC*thetaprpi)*
    (2*cg*(CoefC*(-2*Sqrt[3]*kappad + 2*Sqrt[3]*kappau + 3*deltaI*thetaprpi) + 
       2*CoefA*(-(Sqrt[3]*kappau) - 3*deltaI*thetaprpi + 3*deltaI*kappau*thetaprpi + 
         kappad*(Sqrt[3] + 3*deltaI*thetaprpi))) + 
     Sqrt[3]*(2*CoefA*deltaI*(Sqrt[2]*thetaALP - 2*thetaprALP)*thetaprpi + 
       CoefC*deltaI*(Sqrt[2]*thetaALP + 4*thetaprALP)*thetaprpi - 4*CoefA*thpiALP + 4*CoefC*thpiALP)))/
   (m23 + I*(Gammaa0 + I*ma0)*ma0) + (2*(CoefA - CoefC)*(m12 - ma^2 - mpi0^2)*(m12 - metap^2 - mpi0^2)*
    (cg*(CoefC*(6 + Sqrt[3]*deltaI*(kappad - kappau)*(Sqrt[2]*thetapi + 4*thetaprpi)) + 
       2*CoefA*(-6 + kappad*(6 + Sqrt[6]*deltaI*thetapi - 2*Sqrt[3]*deltaI*thetaprpi) + 
         kappau*(6 - Sqrt[6]*deltaI*thetapi + 2*Sqrt[3]*deltaI*thetaprpi))) + 
     Sqrt[3]*(2*CoefA*(Sqrt[2]*thetaALP - 2*thetaprALP + deltaI*(-(Sqrt[2]*thetapi) + 2*thetaprpi)*
          thpiALP) + CoefC*(Sqrt[2]*thetaALP + 4*thetaprALP - deltaI*(Sqrt[2]*thetapi + 4*thetaprpi)*
          thpiALP))))/(m12 + I*(Gammaa0 + I*ma0)*ma0) - 
  (2*(CoefA - CoefC)*(m12 + m23 - ma^2 - mpi0^2)*(m12 + m23 - metap^2 - mpi0^2)*
    (cg*(CoefC*(6 + Sqrt[3]*deltaI*(kappad - kappau)*(Sqrt[2]*thetapi + 4*thetaprpi)) + 
       2*CoefA*(-6 + kappad*(6 + Sqrt[6]*deltaI*thetapi - 2*Sqrt[3]*deltaI*thetaprpi) + 
         kappau*(6 - Sqrt[6]*deltaI*thetapi + 2*Sqrt[3]*deltaI*thetaprpi))) + 
     Sqrt[3]*(2*CoefA*(Sqrt[2]*thetaALP - 2*thetaprALP + deltaI*(-(Sqrt[2]*thetapi) + 2*thetaprpi)*
          thpiALP) + CoefC*(Sqrt[2]*thetaALP + 4*thetaprALP - deltaI*(Sqrt[2]*thetapi + 4*thetaprpi)*
          thpiALP))))/(m12 + m23 - ma^2 - I*Gammaa0*ma0 + ma0^2 - metap^2 - 2*mpi0^2))/(24*Sqrt[3])