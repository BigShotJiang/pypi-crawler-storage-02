-1/64*((m12^2*m23 + ma^4*mpiplus^2 + m12*(m23^2 - ma^2*mpiplus^2 + mpiplus^4 - m23*(ma^2 + 2*mpiplus^2)))*
   mrhoplus^4*(4*cg^2*(kappad + 2*kappau)^2 + 6*thetaALP^2 + 6*Sqrt[2]*thetaALP*thetaprALP + 
    3*thetaprALP^2 + 2*Sqrt[6]*thetaALP*thpiALP + 2*Sqrt[3]*thetaprALP*thpiALP + thpiALP^2 + 
    4*cg*(kappad + 2*kappau)*(Sqrt[6]*thetaALP + Sqrt[3]*thetaprALP + thpiALP))*alphaEM)/
  (F0^6*(m12^2 + Gammarho^2*mrho^2 - 2*m12*mrho^2 + mrho^4)*Pi^3)