-1/432*(deltaI*gT^2*(6*m23^2*mf2^4 - 6*m23*meta^2*mf2^4 - 6*m23*meta^2*mf2^2*mpi0^2 + 
    5*meta^4*mf2^2*mpi0^2 - 12*m23*mf2^4*mpi0^2 + 7*meta^2*mf2^4*mpi0^2 + meta^4*mpi0^4 + 
    6*m23*mf2^2*mpi0^4 + meta^2*mf2^2*mpi0^4 + mf2^4*mpi0^4 - 2*meta^2*mpi0^6 - 2*mf2^2*mpi0^6 + 
    mpi0^8 + m12^2*(ma^2 - mf2^2 + mpi0^2)*(meta^2 - mf2^2 + mpi0^2) + 
    ma^4*(meta^4 + 5*mf2^2*mpi0^2 + mpi0^4 - meta^2*(mf2^2 + 2*mpi0^2)) + 
    ma^2*(7*mf2^4*mpi0^2 + mf2^2*mpi0^4 - 2*mpi0^6 - 6*m23*mf2^2*(-meta^2 + mf2^2 + mpi0^2) - 
      meta^4*(mf2^2 + 2*mpi0^2) + meta^2*(mf2^4 - 8*mf2^2*mpi0^2 + 4*mpi0^4)) - 
    m12*(-6*m23*mf2^4 + meta^4*(-mf2^2 + mpi0^2) + ma^4*(meta^2 - mf2^2 + mpi0^2) + 
      2*(-(mf2^2*mpi0) + mpi0^3)^2 + meta^2*(mf2^4 + 6*mf2^2*mpi0^2 - mpi0^4) + 
      ma^2*(meta^4 + mf2^4 + 6*mf2^2*mpi0^2 - mpi0^4 - 2*meta^2*(mf2^2 + 2*mpi0^2))))*
   (thetapi - Sqrt[2]*thetaprpi)*(deltaI*(2*thetaALP*thetapi + Sqrt[2]*thetapi*thetaprALP + 
      Sqrt[2]*thetaALP*thetaprpi + thetaprALP*thetaprpi) + 
    cg*kappau*(-3 + Sqrt[3]*deltaI*(Sqrt[2]*thetapi + thetaprpi)) + 
    cg*kappad*(3 + Sqrt[3]*deltaI*(Sqrt[2]*thetapi + thetaprpi)) - 3*thpiALP)*
   UnitStep[m12 - (Gammaf2 - mf2)^2])/(mf2^4*(-m12 + mf2*((-I)*Gammaf2 + mf2)))-1/144*(gT^2*(m23^2*(ma^2 + meta^2 - mf2^2)*(mf2^2 - 2*mpi0^2) - 
    2*mf2^2*(3*m12^2*mf2^2 + 2*ma^4*mpi0^2 - 3*m12*mf2^2*(ma^2 + meta^2 + 2*mpi0^2) + 
      mpi0^2*(2*meta^4 + meta^2*mf2^2 + 3*mf2^2*mpi0^2) + 
      ma^2*(mf2^2*mpi0^2 + meta^2*(3*mf2^2 - 4*mpi0^2))) + 
    m23*(-(ma^4*(mf2^2 - 2*mpi0^2)) - meta^4*(mf2^2 - 2*mpi0^2) + 2*mf2^4*(-3*m12 + mpi0^2) + 
      meta^2*(mf2^4 + 2*mf2^2*mpi0^2) + ma^2*(mf2^4 + 2*mf2^2*mpi0^2 + 2*meta^2*(mf2^2 - 2*mpi0^2))))*
   (2*thetaALP + cg*kappad*(Sqrt[6] - 3*deltaI*thetapi) + cg*kappau*(Sqrt[6] + 3*deltaI*thetapi) + 
    Sqrt[2]*thetaprALP + 3*deltaI*thetapi*thpiALP)*UnitStep[m23 - (Gammaf2 - mf2)^2])/
  (mf2^4*(-m23 + mf2*((-I)*Gammaf2 + mf2)))-1/432*(deltaI*gT^2*((m12 + m23 - meta^2 - mpi0^2)*(4*meta^2*mpi0^2*(meta^2 - 2*mf2^2 + mpi0^2) + 
      (m12 + m23 - ma^2 - mpi0^2)^2*(meta^2 - mf2^2 + mpi0^2) + (-m12 - m23 + ma^2 + mpi0^2)*
       (meta^4 + 2*mf2^4 - 3*mf2^2*mpi0^2 + mpi0^4 - 3*meta^2*(mf2^2 - 2*mpi0^2))) - 
    (-m12 + ma^2 + mpi0^2)*((m12 - meta^2 - mpi0^2)*(-(meta^2*(m12 + m23 - ma^2 + 3*mf2^2 - 5*mpi0^2)) + 
        (mf2^2 - mpi0^2)*(m12 + m23 - ma^2 + 3*mf2^2 - mpi0^2)) + 
      (m23 - 2*mpi0^2)*(-(meta^2*(m12 + m23 - ma^2 + 6*mf2^2 - 5*mpi0^2)) + 
        (-m12 - m23 + ma^2 + mpi0^2)*(-mf2^2 + mpi0^2))) - (-m23 + ma^2 + meta^2)*
     ((m23 - 2*mpi0^2)*(-(meta^2*(m12 + m23 - ma^2 + 3*mf2^2 - 5*mpi0^2)) + 
        (mf2^2 - mpi0^2)*(m12 + m23 - ma^2 + 3*mf2^2 - mpi0^2)) + (m12 - meta^2 - mpi0^2)*
       (2*(2*meta^2 - 3*mf2^2)*mpi0^2 + (-m12 - m23 + ma^2 + mpi0^2)*(meta^2 - mf2^2 + mpi0^2))))*
   (-thetapi + Sqrt[2]*thetaprpi)*(3*cg*(kappad - kappau) + 
    deltaI*(Sqrt[3]*cg*(kappad + kappau) + thetaprALP)*(Sqrt[2]*thetapi + thetaprpi) + 
    deltaI*thetaALP*(2*thetapi + Sqrt[2]*thetaprpi) - 3*thpiALP)*
   UnitStep[-m12 - m23 + ma^2 + meta^2 - (Gammaf2 - mf2)^2 + 2*mpi0^2])/
  (mf2^4*(-m12 - m23 + ma^2 + meta^2 + I*Gammaf2*mf2 - mf2^2 + 2*mpi0^2))