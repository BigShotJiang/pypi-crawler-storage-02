-1/144*(gTf2^2*(m23^2*(ma^2 + meta^2 - mf2^2)*(mf2^2 - 2*mpiplus^2) - 
    2*mf2^2*(3*m12^2*mf2^2 + 2*ma^4*mpiplus^2 - 3*m12*mf2^2*(ma^2 + meta^2 + 2*mpiplus^2) + 
      mpiplus^2*(2*meta^4 + meta^2*mf2^2 + 3*mf2^2*mpiplus^2) + 
      ma^2*(mf2^2*mpiplus^2 + meta^2*(3*mf2^2 - 4*mpiplus^2))) + 
    m23*(-(ma^4*(mf2^2 - 2*mpiplus^2)) - meta^4*(mf2^2 - 2*mpiplus^2) + 2*mf2^4*(-3*m12 + mpiplus^2) + 
      meta^2*(mf2^4 + 2*mf2^2*mpiplus^2) + ma^2*(mf2^4 + 2*mf2^2*mpiplus^2 + 
        2*meta^2*(mf2^2 - 2*mpiplus^2))))*(2*thetaALP + cg*kappad*(Sqrt[6] - 3*deltaI*thetapi) + 
    cg*kappau*(Sqrt[6] + 3*deltaI*thetapi) + Sqrt[2]*thetaprALP + 3*deltaI*thetapi*thpiALP)*
   UnitStep[m23 - (Gammaf2 - mf2)^2])/(mf2^4*(-m23 + mf2*((-I)*Gammaf2 + mf2)))