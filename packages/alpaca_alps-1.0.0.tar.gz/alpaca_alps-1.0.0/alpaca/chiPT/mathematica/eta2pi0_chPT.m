(mpi0^2*(2*thetaALP + Sqrt[2]*thetaprALP + 
   cg*kappau*(Sqrt[6] - deltaI*(Sqrt[6] + thetapi + 2*Sqrt[2]*thetaprpi)) + 
   cg*kappad*(Sqrt[6] + deltaI*(Sqrt[6] + thetapi + 2*Sqrt[2]*thetaprpi)) - Sqrt[6]*deltaI*thpiALP - 
   deltaI*thetapi*thpiALP - 2*Sqrt[2]*deltaI*thetaprpi*thpiALP))/(3*F0^2)