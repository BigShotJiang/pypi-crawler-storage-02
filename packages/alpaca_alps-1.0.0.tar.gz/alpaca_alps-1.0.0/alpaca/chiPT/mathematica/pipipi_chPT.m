-1/18*(Sqrt[kfact]*(cuhat*(-9*m12 + 3*ma^2 + 9*mpi0^2) + cdhat*(9*m12 - 3*(ma^2 + 3*mpi0^2)) + 
    2*deltaI*mpi0^2*(thetaprALP*(Sqrt[3] + 3*Sqrt[2]*thetapi + 3*thetaprpi) + 
      thetaALP*(Sqrt[6] + 6*thetapi + 3*Sqrt[2]*thetaprpi)) + 
    6*cg*mpi0^2*(kappau*(-1 + deltaI + Sqrt[6]*deltaI*thetapi + Sqrt[3]*deltaI*thetaprpi) + 
      kappad*(1 + deltaI + Sqrt[6]*deltaI*thetapi + Sqrt[3]*deltaI*thetaprpi)) + 
    6*(-3*m12 + ma^2 + 2*mpi0^2)*thpiALP)*UnitStep[-ma + metap])/F0^2