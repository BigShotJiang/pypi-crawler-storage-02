# AI agent
This module implements all the AI functions such as:
- LLM calls
- Multimodal calls for image description and image generation
- Agent tools for chat facts and image generation
