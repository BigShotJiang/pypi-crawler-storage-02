# -*- encoding: utf-8 -*-

from .inject_implementation import inject_implementation
from .inject_init import inject_init
