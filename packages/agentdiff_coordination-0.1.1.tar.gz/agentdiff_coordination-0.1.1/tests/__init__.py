"""
AgentDiff Coordination Tests

Unit tests for core coordination functionality.
"""