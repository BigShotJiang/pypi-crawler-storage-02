"""Asciinema player widget for Textual."""

from .player import AsciinemaPlayer

__all__ = ["AsciinemaPlayer"]
