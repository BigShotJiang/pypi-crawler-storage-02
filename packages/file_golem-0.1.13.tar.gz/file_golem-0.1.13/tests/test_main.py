import unittest
from tests.path_logic_tests import PathLogicUnitTest

if __name__ == '__main__':
    unittest.main()
