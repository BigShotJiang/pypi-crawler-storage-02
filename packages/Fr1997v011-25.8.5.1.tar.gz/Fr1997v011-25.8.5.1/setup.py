from setuptools import setup

setup(
    name='Fr1997v011',
    version='25.8.5.1',
    description='fr1997 all func',
    url='',
    author='fr1997',
    author_email='3084447185@qq.com',
    license='MIT',
    packages=[
        'fr1997_mode',
        'fr1997_mode.mode_func',
        'fr1997_mode.mode_static'
    ],
    zip_safe=False
)
