"""Core library components for NetGraph."""
