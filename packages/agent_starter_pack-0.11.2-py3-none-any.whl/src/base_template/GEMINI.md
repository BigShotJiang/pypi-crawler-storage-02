Coding Agent guidance:
{%- if "adk" in cookiecutter.tags %}
{{ cookiecutter.adk_cheatsheet }}
{%- endif %}
{{ cookiecutter.llm_txt }}