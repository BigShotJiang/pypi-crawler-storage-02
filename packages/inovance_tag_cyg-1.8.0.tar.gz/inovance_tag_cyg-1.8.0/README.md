# inovance_tag_cyg
汇川plc标签通讯


# 安装 inovance_tag_cyg
* python版本必须 >=3.7,<3.13
```shell
pip install inovance_tag_cyg
```
