from ._colors import *

from .sequential import sequential_colors, get_sequential_color_list
from .diverging import diverging_colors, get_diverging_color_list
