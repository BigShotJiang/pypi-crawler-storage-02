from wexample_helpers.const.types import Scalar, StringsList

CommandLineArgumentsList = StringsList
ResponsePrintable = Scalar
