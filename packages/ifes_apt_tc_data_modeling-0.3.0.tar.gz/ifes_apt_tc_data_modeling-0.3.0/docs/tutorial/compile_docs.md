# Compile the documentation

Provided `ifes_apt_tc_data_modeling` library was installed with the optional dependency `docs`
the documentation can be compiled locally using the mkdocs:

```shell
mkdocs build
mkdocs serve
```
