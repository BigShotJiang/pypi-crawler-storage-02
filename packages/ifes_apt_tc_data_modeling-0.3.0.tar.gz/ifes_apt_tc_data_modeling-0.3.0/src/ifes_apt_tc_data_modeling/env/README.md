## Getting started
GPM/Rouen group and C. Hatzeglou's (NTNU Trondheim) ENV file format as communicated at the FAU/Erlangen Atom Probe School in 2020
and the example offered by C. Hatzeglou for his NAPA Matlab software toolbox for atom probe.