## Getting started
CSV reader assuming CSV is formatted like a POS file.