## Getting started
The classical e(xtended) POS(isition) file format used in atom probe.