# **Link Solution Component Peers**
>	This command can be used to link or unlink wires between components.

## **Component1**
>	**Input Required**: True

>	**Description**: The  first component to link.

>	**Alternative Labels**: Solution Component 1; Comp 1


## **Component2**
>	**Input Required**: True

>	**Description**: The  second component to link.

>	**Alternative Labels**: Solution Component 2; Comp 2


## **Wire Label**
>	**Input Required**: False

>	**Description**: Labels the link between two components.

>	**Alternative Labels**: Label


## **Description**
>	**Input Required**: False

>	**Description**: A description of the wire.

