# pyasjp
Programmatic access to data in ASJP's text format

[![Build Status](https://github.com/shh-dlce/pyasjp/workflows/tests/badge.svg)](https://github.com/shh-dlce/pyasjp/actions?query=workflow%3Atests)
[![PyPI](https://img.shields.io/pypi/v/pyasjp.svg)](https://pypi.org/project/pyasjp)

