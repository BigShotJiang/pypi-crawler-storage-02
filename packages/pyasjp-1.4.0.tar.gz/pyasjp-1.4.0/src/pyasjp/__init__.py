#
from pyasjp.api import ASJP  # noqa: F401

__version__ = '1.4.0'
