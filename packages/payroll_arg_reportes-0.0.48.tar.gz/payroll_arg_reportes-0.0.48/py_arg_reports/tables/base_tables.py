
TABLA_TIPO_LIQUIDACIONES = {
    # Ver si es estrictamente necesario usar tablas fijas
}
