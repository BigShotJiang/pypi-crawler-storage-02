# flake8: noqa: F401


from py_arg_reports.reporters.acreditaciones.base import AcreditacionFile, AcreditacionesHeadDetailTrailerFile
