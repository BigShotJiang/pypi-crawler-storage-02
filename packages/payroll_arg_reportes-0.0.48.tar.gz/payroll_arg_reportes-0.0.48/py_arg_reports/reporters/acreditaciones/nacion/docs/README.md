Banco nacion publica los detalles de su archivo aquí: https://www.bna.com.ar/Downloads/pagosgt.pdf  

![bna](detalle-registro.png)
