Ver /docs/acreditaciones-galicia.md
