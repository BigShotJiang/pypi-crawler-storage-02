
config_constants = {
    # Recibos
    'FONT_FAMILY': 'Helvetica',
    'FONT_FAMILY_BOLD': 'Helvetica-Bold',
    'FONT_SIZE_MAIN': 9,
    'FONT_SIZE_HEADER': 12,
    'FONT_SIZE_BODY': 8,

    # Excel
    'EXCEL_FONT_FAMILY': 'Arial',
    'EXCEL_FONT_SIZE': 8,
}
