DEFAULT_MODEL = "gpt-4o"
USER_DATA_DIR = ".pd-ai-agents"
