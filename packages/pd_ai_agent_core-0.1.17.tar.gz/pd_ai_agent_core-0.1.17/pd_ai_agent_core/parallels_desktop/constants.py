PRLCTL_COMMAND = "prlctl"
PRLSRVCTL_COMMAND = "prlsrvctl"
