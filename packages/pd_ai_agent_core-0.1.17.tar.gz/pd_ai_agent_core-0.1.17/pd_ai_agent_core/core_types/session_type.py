from enum import Enum


class SessionType(Enum):
    CHAT = "chat"
    COMMAND = "command"
