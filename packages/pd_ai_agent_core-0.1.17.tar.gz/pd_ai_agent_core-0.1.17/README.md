# pd-ai-agent-core

A core library for AI agent functionality

## Installation

```bash
pip install pd-ai-agent-core
```

## Usage

```python
from pd_ai_agent_core import ParallelsAiChatAgent

```
