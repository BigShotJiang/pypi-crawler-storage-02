"""Test suite for GPU Benchmark Tool.

This package contains comprehensive tests for all implemented features.
"""
