from .simple_sediment_landslider import SimpleSedimentLandslider

__all__ = ["SimpleSedimentLandslider"]
