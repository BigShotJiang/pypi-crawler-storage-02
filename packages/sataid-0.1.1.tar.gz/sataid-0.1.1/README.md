# sataid

Library pembacaan file SAT-AID berformat kabur.

## Cara penggunaan:

```python
import sataid
sat = sataid.read_sataid("namafile")
```