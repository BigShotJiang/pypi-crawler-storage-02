"""Docling remote provider package."""

from docler.converters.docling_remote_provider.provider import DoclingRemoteConverter

__all__ = ["DoclingRemoteConverter"]
