"""Docling provider package."""

from docler.converters.docling_provider.provider import DoclingConverter

__all__ = ["DoclingConverter"]
