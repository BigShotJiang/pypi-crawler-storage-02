from __future__ import annotations


def test_nothing():
    pass
