# Helper functions

def preprocess_image(image_path):
    pass  # TODO: Implement preprocessing
