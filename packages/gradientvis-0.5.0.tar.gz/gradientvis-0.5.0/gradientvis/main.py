# Entry point for GradientVis

def main():
    print("GradientVis initialized!")

if __name__ == "__main__":
    main()
