from .Stacked import StackedRNN
from .Singular import SingularRNN