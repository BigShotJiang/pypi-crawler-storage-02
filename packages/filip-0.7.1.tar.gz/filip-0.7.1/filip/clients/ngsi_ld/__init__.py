"""
This package will contain HTTP clients for FIWARE's NGSI-LD APIs
"""
