"""
MQTT client for streaming data via FIWARE's IoT-Agent
"""

from .client import IoTAMQTTClient
