from .global_service_fastapi_pkg import *
