from bluer_objects import README


def test_README_build():
    assert README.build_me()
