"""Plone Distribution support."""

import logging


PACKAGE_NAME = "plone.exportimport"

logger = logging.getLogger(PACKAGE_NAME)
