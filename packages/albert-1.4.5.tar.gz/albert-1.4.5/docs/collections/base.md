::: albert.collections.base.BaseCollection
