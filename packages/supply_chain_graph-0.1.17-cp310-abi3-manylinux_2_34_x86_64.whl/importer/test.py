print("Hello World")

from supply import PyResource, PySKU



