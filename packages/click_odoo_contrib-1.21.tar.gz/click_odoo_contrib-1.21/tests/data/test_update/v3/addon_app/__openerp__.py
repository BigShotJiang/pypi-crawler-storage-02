{
    "name": "addon_app",
    "application": True,
    "version": "3.0",
    "depends": ["addon_d1", "addon_d2"],
    "description": "Add two dependencie.",
}
