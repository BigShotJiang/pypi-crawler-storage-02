{
    "name": "addon_app",
    "application": True,
    "version": "7.0",
    "depends": ["addon_d1"],
    "data": ["no_exists.xml"],
    "description": "Invalid date, test update fails.",
}
