{
    "name": "addon_app",
    "application": True,
    "version": "4.0",
    "depends": ["addon_d1"],
    "description": "Remove addon_d2 but do not uninstall it.",
}
