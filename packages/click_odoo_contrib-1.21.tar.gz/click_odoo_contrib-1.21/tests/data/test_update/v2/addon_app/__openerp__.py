{
    "name": "addon_app",
    "application": True,
    "version": "2.0",
    "description": "Bump version.",
}
