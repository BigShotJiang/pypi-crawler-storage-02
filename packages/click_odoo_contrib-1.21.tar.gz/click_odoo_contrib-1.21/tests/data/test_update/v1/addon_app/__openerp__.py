{
    "name": "addon_app",
    "application": True,
    "version": "1.0",
    "description": "First version.",
}
