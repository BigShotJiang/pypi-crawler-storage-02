{
    "name": "addon_app",
    "application": True,
    "version": "3.1",
    "depends": ["addon_d1"],
    "description": "Add two dependencie.",
}
