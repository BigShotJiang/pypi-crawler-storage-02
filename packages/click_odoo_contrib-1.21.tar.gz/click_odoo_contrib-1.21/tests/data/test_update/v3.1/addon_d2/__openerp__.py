{
    "name": "addon_d2",
    "version": "3.0",
    "installable": False,
    "data": ["doesnotexist.xml"],
}
