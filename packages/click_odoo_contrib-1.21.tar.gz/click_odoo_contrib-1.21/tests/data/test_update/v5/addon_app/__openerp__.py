{
    "name": "addon_app",
    "application": True,
    "version": "5.0",
    "depends": ["addon_d1"],
    "description": "Uninstall addon_d2 with a migration.",
}
