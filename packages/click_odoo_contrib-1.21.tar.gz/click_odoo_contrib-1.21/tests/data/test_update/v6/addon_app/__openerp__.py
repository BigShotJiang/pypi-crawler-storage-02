{
    "name": "addon_app",
    "application": True,
    "version": "6.0",
    "depends": ["addon_d1"],
    "description": "Add field to res_users.",
}
