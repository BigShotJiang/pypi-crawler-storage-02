# must be __openerp__.py, for compatibility with 8, 9 tests
{"name": "addon 1"}
