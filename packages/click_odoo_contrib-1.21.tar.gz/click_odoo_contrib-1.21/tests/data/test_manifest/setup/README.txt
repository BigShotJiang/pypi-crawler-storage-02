This directory is not an Odoo addon.
