{"name": "addon uninstallable", "installable": False}
