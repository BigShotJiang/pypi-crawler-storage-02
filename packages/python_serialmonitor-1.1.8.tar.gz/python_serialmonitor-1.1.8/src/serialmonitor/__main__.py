if __name__ == '__main__':
    import sys
    from serialmonitor.run import main

    sys.exit(main())
