from textual.color import Color


class StatusColor:
    RED = Color.parse('#b30000')
    GREEN = Color.parse('#006600')
    BLUE = Color.parse('#0000b3')
    ORANGE = Color.parse('#e65c00')
