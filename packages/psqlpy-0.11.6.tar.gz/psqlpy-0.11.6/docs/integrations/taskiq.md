---
title: Integration with TaskIQ
---

# TaskIQ-PSQLPy

There is integration with [TaskIQ](https://github.com/taskiq-python/taskiq-psqlpy).
You can use PSQLPy for result backend.
