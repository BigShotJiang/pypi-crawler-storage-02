import pkg_resources

DAFNI_CLI_VERSION = pkg_resources.get_distribution("dafni-cli").version
