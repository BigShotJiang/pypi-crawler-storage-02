TEST_WORKFLOW_METADATA: dict = {
    "description": "Test workflow",
    "display_name": "A Workflow",
    "name": "test-workflow-name",
    "publisher": "Joel Davies",
    "summary": "Test workflow created to learn about DAFNI",
    "contact_point_name": "Lorem Ipsum",
    "contact_point_email": "lorem.ipsum@example.com",
    "licence": "https://creativecommons.org/licenses/by/4.0/",
    "rights": "Open",
}
