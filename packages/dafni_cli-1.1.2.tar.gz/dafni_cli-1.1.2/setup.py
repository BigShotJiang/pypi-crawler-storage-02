"""
This file is needed only for legacy compatibility for allowing editable
installs - see
https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html
"""

from setuptools import setup

setup()
