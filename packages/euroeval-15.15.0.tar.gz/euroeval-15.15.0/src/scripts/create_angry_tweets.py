"""Create the AngryTweets-mini sentiment dataset and upload it to the HF Hub."""
