"""Unit tests for the `fresh` module."""
