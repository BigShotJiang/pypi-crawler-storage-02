__title__ = "eeclient"
__summary__ = "A client for Google Earth Engine"
__version__ = "2.1.0"

__author__ = "Daniel Guerrero"
__email__ = "dfgm2006@gmail.com"

__license__ = "MIT"
