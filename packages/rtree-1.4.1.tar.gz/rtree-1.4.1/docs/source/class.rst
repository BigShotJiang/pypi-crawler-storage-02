.. _class:

Class Documentation
------------------------------------------------------------------------------

.. autoclass:: rtree.index.Index
    :members: __init__, insert, intersection, intersection_v, nearest, nearest_v, delete, bounds, count, close, dumps, loads

.. autoclass:: rtree.index.Property
    :members:

.. autoclass:: rtree.index.Item
    :members:  __init__, bbox, object
