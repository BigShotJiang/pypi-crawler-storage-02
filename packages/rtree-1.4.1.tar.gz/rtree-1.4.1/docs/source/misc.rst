.. _misc:

Miscellaneous Documentation
------------------------------------------------------------------------------

Exceptions
==========

.. autoexception:: rtree.exceptions.RTreeError
    :members:

Finder module
=============

.. automodule:: rtree.finder
    :members:
