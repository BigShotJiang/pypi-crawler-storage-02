"""Init params."""

from llama_index.finetuning.openai.base import OpenAIFinetuneEngine

__all__ = ["OpenAIFinetuneEngine"]
