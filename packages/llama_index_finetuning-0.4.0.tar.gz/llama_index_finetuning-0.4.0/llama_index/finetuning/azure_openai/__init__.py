"""Init params."""

from llama_index.finetuning.azure_openai.base import AzureOpenAIFinetuneEngine

__all__ = ["AzureOpenAIFinetuneEngine"]
