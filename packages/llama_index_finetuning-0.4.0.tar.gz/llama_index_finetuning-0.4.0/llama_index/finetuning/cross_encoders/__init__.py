"""Init params."""

from llama_index.finetuning.cross_encoders.cross_encoder import (
    CrossEncoderFinetuneEngine,
)

__all__ = ["CrossEncoderFinetuneEngine"]
