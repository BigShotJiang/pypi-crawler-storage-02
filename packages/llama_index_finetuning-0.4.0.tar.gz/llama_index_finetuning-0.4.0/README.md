# LlamaIndex Finetuning

A LlamaIndex extension package that contains classes and features for carrying
out finetuning of OpenAI LLMs and Embedding models.
