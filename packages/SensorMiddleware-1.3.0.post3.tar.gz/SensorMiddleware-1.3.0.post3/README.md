# SensorMiddleware

O "SensorMiddleware" é responsável por controlar todo o fluxo dos Scanners EcoTrust, e fazer upload do resultado para o S3 Bucket.
