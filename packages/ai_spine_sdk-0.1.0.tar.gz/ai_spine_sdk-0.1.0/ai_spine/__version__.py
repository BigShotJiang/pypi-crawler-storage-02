"""Version information for AI Spine SDK."""

__version__ = "0.1.0"