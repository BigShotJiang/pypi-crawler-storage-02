"""
Logging setup and shared logger for the cf_edr package.
"""

import logging

# Set up a shared logger for the cf_edr package
logger = logging.getLogger("cf_edr")
