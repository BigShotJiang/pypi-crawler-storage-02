"""
Package for geometry related functionality
"""
