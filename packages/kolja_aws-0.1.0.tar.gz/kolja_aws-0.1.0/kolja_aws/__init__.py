"""
Kolja AWS CLI Tool

A powerful CLI tool for managing AWS SSO sessions and profiles.
"""

__version__ = "0.1.0"
__author__ = "Kolja Huang"