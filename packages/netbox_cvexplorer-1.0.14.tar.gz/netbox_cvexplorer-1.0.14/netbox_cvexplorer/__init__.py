from .plugin import CVExplorerConfig as config
from .navigation import menu_items