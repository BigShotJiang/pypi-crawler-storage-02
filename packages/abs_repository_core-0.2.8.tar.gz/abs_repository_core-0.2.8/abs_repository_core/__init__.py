"""
Repository Core package initialization.
"""

__version__ = "0.2.0" 