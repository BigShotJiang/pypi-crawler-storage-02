"""A package that defines mixins for different kinds (i.e., file formats)."""
