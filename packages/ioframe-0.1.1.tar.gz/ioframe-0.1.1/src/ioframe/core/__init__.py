"""Core package of the :py:mod:`ioframe` library to handle a registry of backends."""

from __future__ import annotations
