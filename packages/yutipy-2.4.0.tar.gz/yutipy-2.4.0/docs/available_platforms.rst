=========================
Available Music Platforms
=========================

Right now, the following music platforms are available in yutipy for searching music. New platforms will be added in the future.
Feel free to request any music platform you would like me to add by opening an issue on `GitHub <https://github.com/CheapNightbot/yutipy/issues>`_ or by emailing me.


- ``Deezer``: https://www.deezer.com
- ``iTunes``: https://music.apple.com
- ``KKBOX``: https://www.kkbox.com
- ``Lastfm``: https://last.fm
- ``ListenBrainz``: https://listenbrainz.org
- ``Spotify``: https://spotify.com
- ``YouTube Music``: https://music.youtube.com
