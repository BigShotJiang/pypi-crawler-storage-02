## Aliyun ROS ESS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```python
import * as ESS from '@alicloud/ros-cdk-ess';
```
