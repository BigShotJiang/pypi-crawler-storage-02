"""
Python API for Mendix Studio Pro.
"""

__version__ = "0.1.0"

__import__('pkg_resources').declare_namespace(__name__)
