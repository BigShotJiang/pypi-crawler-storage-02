from ._image_parts import ImageGridHandler

class GridImage(ImageGridHandler):
    pass

GridImage.__doc__ = ImageGridHandler.__doc__