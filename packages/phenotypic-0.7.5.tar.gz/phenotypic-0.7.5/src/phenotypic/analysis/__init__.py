"""
The analysis module contains classes for performing data
analytics and cleaning on ImageSets.
"""