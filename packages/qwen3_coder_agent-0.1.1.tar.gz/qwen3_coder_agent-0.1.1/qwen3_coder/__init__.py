"""Qwen3-Coder Terminal Agent

A powerful terminal interface for interacting with the Qwen3-Coder model,
featuring secure API key management, rate limiting, and token management.
"""

__version__ = "0.1.1"
