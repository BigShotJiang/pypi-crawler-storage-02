from pathlib import Path

QA_PROMPT_DIR_PATH = Path(__file__).parent
