ontogpt extract -t ibd.IBDAnnotations PMC6386158_fig2_legend.txt > PMC6386158_fig2_legend.yaml
