"""Entry point for genpass CLI application."""

from .cli import genpass

if __name__ == "__main__":
    genpass()
