"""
SwarmFlow Core

Core modules for the SwarmFlow multi-agent orchestration framework.
"""

# This file makes the core directory a Python package
