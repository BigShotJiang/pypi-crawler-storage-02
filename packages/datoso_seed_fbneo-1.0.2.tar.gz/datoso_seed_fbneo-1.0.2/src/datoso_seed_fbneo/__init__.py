"""Initialize seed variables."""
__all__ = ['__author__', '__description__', '__version__']
__version__ = '1.0.2'
__author__ = 'Lacides Miranda'
__description__ = 'Emulator for Arcade Games & Select Consoles.'
__prefix__ = 'fbneo'
