# RichPrint

A clean wrapper for Rich that lets you print with color, background, style, or presets using a chainable syntax.

## Install

```bash
pip install richprint
```
