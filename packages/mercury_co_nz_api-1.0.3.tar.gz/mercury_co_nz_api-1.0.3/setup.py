#!/usr/bin/env python3
"""
Fallback setup.py for compatibility with older tools.
The main configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
