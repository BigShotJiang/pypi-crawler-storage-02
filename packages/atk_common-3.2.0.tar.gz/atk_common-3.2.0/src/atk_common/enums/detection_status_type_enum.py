from enum import Enum
 
class DetectionStatusType(Enum):
    OK = 1
    FAILED = 2
