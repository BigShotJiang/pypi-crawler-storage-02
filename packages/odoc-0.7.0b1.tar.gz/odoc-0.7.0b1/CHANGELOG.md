

0.7.0b1  Fixed DataStyle-maps when used in office-styles.
