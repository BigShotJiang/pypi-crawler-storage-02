"""Shared test fixtures and utilities."""
