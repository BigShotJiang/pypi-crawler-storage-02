from .BrowserUI import BrowserUI
from .types import EventType