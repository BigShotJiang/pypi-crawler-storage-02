def render_string(tmpl, context):
    return tmpl.format(**context)
