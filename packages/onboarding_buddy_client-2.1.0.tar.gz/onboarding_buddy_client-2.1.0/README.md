# Get started with the OnboardingBuddyClient

## 1 Create an OnboardingBuddy account 

If you have not already, proceed to create an account on the Onboarding Buddy website at https://www.onboardingbuddy.co.  

## 2 Getting started
For instructions on getting started integrating with the OnboardingBuddy Python SDK <a href="https://github.com/onboarding-buddy/getting-started/tree/main/python">click here</a> to go to our getting started guide. 

## 3 Questions and Help

If you have any questions or need any assistance please email us at support@onboardingbuddy.co