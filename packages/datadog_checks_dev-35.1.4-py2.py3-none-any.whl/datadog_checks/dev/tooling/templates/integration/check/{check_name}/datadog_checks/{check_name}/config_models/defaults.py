{license_header}

{documentation}


def instance_empty_default_hostname():
    return False


def instance_min_collection_interval():
    return 15
