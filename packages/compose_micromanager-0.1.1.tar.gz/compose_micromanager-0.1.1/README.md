# micromanager
CLI appliaction to manage microservices with docker-compose
