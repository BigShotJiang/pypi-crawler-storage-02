When salesmen set a delivery date there's nothing disallowing them to set it before
the expected date computed according to the order lead times. That can cause great issues
with deliveries schedules, as those lead times are set to ensure that the orders are
delivered on time.
