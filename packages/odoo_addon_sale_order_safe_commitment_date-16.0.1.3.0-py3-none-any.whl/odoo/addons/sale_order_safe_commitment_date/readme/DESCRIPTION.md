This module allows to avoid that the salesmen set a delivery date before the minimum
expected date.
