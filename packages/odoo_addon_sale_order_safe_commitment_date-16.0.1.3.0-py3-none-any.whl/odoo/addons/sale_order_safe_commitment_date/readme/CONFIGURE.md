If you want to view the delivery date in the top of the sale order form, you should
unarchive the `view_order_form_commitment_date_ux` view, which is archived by default.
