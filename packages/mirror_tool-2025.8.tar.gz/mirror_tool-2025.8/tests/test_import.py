def test_can_import():
    """Trivial test, to be removed once real tests are implemented."""
    from mirror_tool import cmd
