This module allows you to print cash and bank statement report for one
day or a period.
