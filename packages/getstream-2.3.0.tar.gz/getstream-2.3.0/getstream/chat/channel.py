class Channel:
    pass
