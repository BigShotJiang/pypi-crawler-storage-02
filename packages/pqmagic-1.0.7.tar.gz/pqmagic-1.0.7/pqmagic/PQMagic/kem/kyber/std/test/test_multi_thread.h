#ifndef _TEST_MULTI_THREAD_H_
#define _TEST_MULTI_THREAD_H_

// #define DEBUG_MULTITHREAD

#include <stdio.h>
#include <pthread.h>
extern FILE* fp_list[8];
extern pthread_t th[8];

#endif