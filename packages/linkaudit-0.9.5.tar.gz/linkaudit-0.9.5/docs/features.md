# Features

This `linkaudit` tool has the following features:
* Shows all *external* links (aka URLs) for a Shpinx or JupyterBook. Output is saved.
* Validate status of all discoverd *external* links for a Sphinx or Jupyterbook document. Output is saved.


