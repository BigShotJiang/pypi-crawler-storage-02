"""HTML export module for RichTreeCLI."""
