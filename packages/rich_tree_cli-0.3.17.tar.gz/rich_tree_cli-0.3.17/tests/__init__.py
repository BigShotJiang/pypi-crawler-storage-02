"""Unit tests for the RichTreeCLI."""
