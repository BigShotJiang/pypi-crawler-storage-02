# Rajouter encapsulation de fichier Orange
# A faire.