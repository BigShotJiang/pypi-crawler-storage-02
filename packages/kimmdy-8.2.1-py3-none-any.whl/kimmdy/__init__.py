"""
Welcome to KIMMDY!
"""

from __future__ import annotations
