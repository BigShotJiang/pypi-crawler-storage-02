"""API clients for interacting with Spark History Server."""
