""" A simple log facility for yacv_server """

import logging

logger = logging.getLogger('yacv_server')


