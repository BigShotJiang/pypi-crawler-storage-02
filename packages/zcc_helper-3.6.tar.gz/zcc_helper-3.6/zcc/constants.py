"""Constants for ZCC."""

import logging

LEVEL_BY_VERBOSITY = [logging.WARNING, logging.INFO, logging.DEBUG]

APP_NAME = "HomeControl"
APP_ID = "ZvWqWJQB"
APP_TOKEN = "3422ecbb-cf6a-404c-b3dc-2023dd213535"

NAME = "zcc_helper"
VERSION = "3.6"
