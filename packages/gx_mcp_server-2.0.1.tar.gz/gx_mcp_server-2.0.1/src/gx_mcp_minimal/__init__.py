"""
Minimal GX MCP Server - Fast startup version
"""