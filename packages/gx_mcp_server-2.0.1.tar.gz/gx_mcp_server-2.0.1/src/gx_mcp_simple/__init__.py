# Simple GX MCP Server
