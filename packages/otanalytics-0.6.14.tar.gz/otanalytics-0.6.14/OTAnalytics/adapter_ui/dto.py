from typing import TypedDict


class DateRangeDto(TypedDict):
    start_date: str
    end_date: str
