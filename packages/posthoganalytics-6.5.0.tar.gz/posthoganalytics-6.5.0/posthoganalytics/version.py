VERSION = "6.5.0"

if __name__ == "__main__":
    print(VERSION, end="")  # noqa: T201
