ATEF Framework
**************

Checkout Structure
^^^^^^^^^^^^^^^^^^

To expand on:
- Serializability
- Prepared variants
    - Prepared holds transient information (results)
- Passive Checkout Groups
- Active Checkout Verify control flow
