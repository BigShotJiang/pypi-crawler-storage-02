from .bin.main import main

main()
