"""
Widgets used for Passive Checkout run-mode
"""
