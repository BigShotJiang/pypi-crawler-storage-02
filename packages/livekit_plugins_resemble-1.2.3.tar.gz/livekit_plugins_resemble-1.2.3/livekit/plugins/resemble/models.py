from enum import Enum


class Precision(str, Enum):
    PCM_16 = "PCM_16"
