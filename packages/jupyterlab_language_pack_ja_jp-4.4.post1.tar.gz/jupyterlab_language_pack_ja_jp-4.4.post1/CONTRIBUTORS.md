# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
* Hisashi Shimoji ([@hisa-shimoji](https://crowdin.com/profile/hisa-shimoji))
* ShigeoSakai ([@ShigeoSakai](https://crowdin.com/profile/ShigeoSakai))
* O-hiron ([@O-hiron](https://crowdin.com/profile/O-hiron))
* koichi.ozasa ([@koichi.ozasa](https://crowdin.com/profile/koichi.ozasa))
* motty ([@motty.mio2](https://crowdin.com/profile/motty.mio2))
* shibadog ([@shibadog](https://crowdin.com/profile/shibadog))
* non name ([@nanashi918ww](https://crowdin.com/profile/nanashi918ww))
