# Jupyterlab Japanese (Japan) Language Pack

Japanese (Japan) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-ja-JP
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-ja-JP
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
