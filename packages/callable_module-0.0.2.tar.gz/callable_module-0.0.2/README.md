# callable_module

Make callables into modules.
