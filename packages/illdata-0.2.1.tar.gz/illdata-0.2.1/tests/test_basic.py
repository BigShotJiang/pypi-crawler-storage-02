def test_import():
    from illdata import IllSftp
    assert IllSftp is not None
