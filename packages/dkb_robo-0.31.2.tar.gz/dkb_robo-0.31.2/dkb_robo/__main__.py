# pylint: disable=c0114, e0401
import cli  # pragma: no cover

cli.main()  # pragma: no cover
