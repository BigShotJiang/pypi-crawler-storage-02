"""init"""

from importlib.metadata import version

from .dkb_robo import DKBRobo, DKBRoboError

__author__ = "GrindSa"
__version__ = version("dkb_robo")
