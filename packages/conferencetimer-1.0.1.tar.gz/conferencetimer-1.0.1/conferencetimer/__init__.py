from .Timer import * 
from .Remote import *

if __name__ == '__main__':
	start_timer()