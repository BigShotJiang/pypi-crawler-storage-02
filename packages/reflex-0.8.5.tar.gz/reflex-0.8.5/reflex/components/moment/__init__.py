"""Moment.js component."""

from .moment import Moment, MomentDelta

moment = Moment.create
