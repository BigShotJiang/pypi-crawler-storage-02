from .main import check_rules

__all__ = ["check_rules"]
