# Variation


::: pbi_corecore.ssas.model_tables.variation.Variation