# Data Source


::: pbi_corecorecorecorecorecore.ssas.model_tables.data_source.DataSource