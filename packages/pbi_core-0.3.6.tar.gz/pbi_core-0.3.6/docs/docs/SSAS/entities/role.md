# Role


::: pbi_corecorecore.ssas.model_tables.role.Role