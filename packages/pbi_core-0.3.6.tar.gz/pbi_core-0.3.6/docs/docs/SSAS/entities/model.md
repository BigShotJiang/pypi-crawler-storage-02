# Model


::: pbi_corecorecorecore.ssas.model_tables.model.Model