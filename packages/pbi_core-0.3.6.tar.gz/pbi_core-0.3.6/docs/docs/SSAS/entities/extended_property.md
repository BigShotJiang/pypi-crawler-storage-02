# Extended Property


::: pbi_corecorecorecorecore.ssas.model_tables.extended_property.ExtendedProperty