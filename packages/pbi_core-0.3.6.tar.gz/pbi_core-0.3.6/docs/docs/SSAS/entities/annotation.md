# Annotation
::: pbi_corecorecore.ssas.model_tables.annotation.Annotation