# Perspective


:::pbi_corecorecorecore.ssas.model_tables.perspective.Perspective