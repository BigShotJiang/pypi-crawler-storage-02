# Partition


::: pbi_corecore.ssas.model_tables.partition.Partition