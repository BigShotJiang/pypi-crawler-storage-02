# Related Column Detail


::: pbi_corecorecore.ssas.model_tables.related_column_detail.RelatedColumnDetail