# Level


::: pbi_corecorecorecorecore.ssas.model_tables.level.Level