# Calculation Item


::: pbi_corecorecorecorecore.ssas.model_tables.calculation_item.CalculationItem