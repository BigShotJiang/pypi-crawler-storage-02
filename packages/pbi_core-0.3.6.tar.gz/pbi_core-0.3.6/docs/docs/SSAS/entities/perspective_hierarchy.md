# Perspective Hierarchy


::: pbi_corecorecore.ssas.model_tables.perspective_hierarchy.PerspectiveHierarchy