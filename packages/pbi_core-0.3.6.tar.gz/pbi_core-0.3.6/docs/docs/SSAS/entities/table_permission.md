# Table Permission


::: pbi_corecore.ssas.model_tables.table_permission.TablePermission