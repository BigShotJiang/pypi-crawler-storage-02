__all__ = ("AnthropicException",)


class AnthropicException(Exception):
    pass
