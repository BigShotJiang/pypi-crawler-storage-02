"""Grid converter models and controls."""
