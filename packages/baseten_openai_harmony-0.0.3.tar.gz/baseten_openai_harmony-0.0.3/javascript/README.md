# @openai/harmony

This version is still in active development and not currently published.

If you want to use it for demo purposes you can run:

```bash
make javascript
```
