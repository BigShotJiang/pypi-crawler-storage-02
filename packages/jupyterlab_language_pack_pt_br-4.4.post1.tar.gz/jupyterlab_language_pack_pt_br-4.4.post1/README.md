# Jupyterlab Portuguese (Brazil) Language Pack

Portuguese (Brazil) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-pt-BR
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-pt-BR
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
