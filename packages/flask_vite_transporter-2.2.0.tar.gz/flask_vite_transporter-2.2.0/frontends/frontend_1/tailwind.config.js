/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        'index.css',
        '__router__.jsx',
        'index.jsx',
        'index.html',
    ],
    theme: {
        extend: {},
    },
    plugins: [],
}