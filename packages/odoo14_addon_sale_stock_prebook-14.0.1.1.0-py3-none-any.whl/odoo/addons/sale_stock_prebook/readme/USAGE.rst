On the sale.order view you will find two new buttons "Reserve Stock" and "Release reservation"
which are only shown if the state is in "Quotation" or "Quotation Sent".

The reservation creates the picking/moves via a procurement run by placing a real move.
