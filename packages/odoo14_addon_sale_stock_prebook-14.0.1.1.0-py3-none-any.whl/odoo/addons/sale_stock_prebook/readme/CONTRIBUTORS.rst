* Michael Tietz (MT Software) <mtietz@mt-software.de>
* Laurent Mignon <laurent.mignon@acsone.eu> (https://www.acsone.eu/)
