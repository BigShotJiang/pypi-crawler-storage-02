Add process to prebook a sale order's stock before confirming it
