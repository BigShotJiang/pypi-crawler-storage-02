r'''## Here bin "executables"!

Set of python scripts to run from the command line:
  * script_pmtarray
  * script_pmtunit
'''