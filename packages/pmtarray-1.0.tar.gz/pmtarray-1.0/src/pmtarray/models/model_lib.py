""" Model library for PMTArray
 This was supposed to be a .json file but I couldn't get it to work with the
 python packaging, so now it's a simple python dictionary. Done.
"""

model_lib = {
    '3"' :  'R11410',
    '3in':  'R11410',
    '2"' :  'R12699',
    '2in':  'R12699',
    }