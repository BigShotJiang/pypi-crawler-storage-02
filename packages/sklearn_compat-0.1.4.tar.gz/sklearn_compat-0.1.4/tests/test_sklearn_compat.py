def test__sklearn_compat():
    # smoke test to trigger the import
    from sklearn_compat import _sklearn_compat
