from sklearn_compat._sklearn_compat import (
    _approximate_mode,  # noqa: F401
    safe_sqr,  # noqa: F401
)
