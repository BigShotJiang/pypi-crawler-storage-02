Documentation
=============

.. automodule:: plumed_bench_pp
   :members:
   :show-inheritance:
   :special-members:
   :private-members:

.. autosummary::
   :recursive:
   :toctree: generated

   parser
   tabulate
   plot
   types
   constants
   utils
