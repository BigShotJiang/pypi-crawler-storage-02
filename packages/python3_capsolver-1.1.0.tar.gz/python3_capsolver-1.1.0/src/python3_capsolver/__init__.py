from python3_capsolver.__version__ import __version__  # noqa
