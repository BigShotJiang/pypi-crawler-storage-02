reversed({1, 2, 3, 4})  # [bad-reversed-sequence]
