print("%s %z" % ("hello", "world"))  # [bad-format-character]
