This error was raised when we encountered an unexpected value type in a toml
configuration between pylint 2.12 and pylint 2.14 (before the argparse refactor).
