try:
    import platform_specific_module
except ImportError:
    platform_specific_module = None
