import datetime

if datetime.time():  # [boolean-datetime]
    print("It is time.")


if datetime.datetime.now().time():  # [boolean-datetime]
    print("Now or never.")
