class Animal:
    pass


class Tree:
    pass


class Cat(Animal):
    def __init__(self):
        super(Animal, self).__init__()
