"Hello World".strip("Helo")
# >>> ' World'
