numbers = list(map(lambda x: 2 * x, [1, 2, 3]))  # [bad-builtin]
print(numbers)
