try:
    1 / 0
except ZeroDivisionError or ValueError:  # [binary-op-exception]
    pass
