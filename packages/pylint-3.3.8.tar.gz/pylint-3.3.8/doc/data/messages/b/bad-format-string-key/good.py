print("%(one)d, %(two)d" % {"one": 1, "two": 2})
