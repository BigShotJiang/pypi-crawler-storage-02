from typing import Callable, Optional


def func() -> Optional[Callable[[int], None]]: ...
