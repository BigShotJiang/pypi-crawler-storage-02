class Apples:
    def __init__(self):
        pass

    def hello(self):
        print("hello")
