For example, you're trying to import a library with required system dependencies and you catch
everything instead of only import errors, you will miss the error message telling you, that
your code could work if you had installed the system dependencies.
