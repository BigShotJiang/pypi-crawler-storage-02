class Klass:
    @classmethod
    def get_instance(cls):
        return cls()
