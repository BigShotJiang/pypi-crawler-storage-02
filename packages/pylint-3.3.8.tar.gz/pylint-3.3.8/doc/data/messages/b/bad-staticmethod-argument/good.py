class Wolf:
    @staticmethod
    def eat(sheep):
        pass
