class Student:
    __slots__ = ("name",)

    name: str
    surname: str  # [declare-non-slot]
