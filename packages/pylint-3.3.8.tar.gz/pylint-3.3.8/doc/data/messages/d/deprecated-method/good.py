import logging

logging.warning("I'm coming, world !")
