import typing

item_to_number_of_item: typing.Dict[str, int]  # [deprecated-typing-alias]
