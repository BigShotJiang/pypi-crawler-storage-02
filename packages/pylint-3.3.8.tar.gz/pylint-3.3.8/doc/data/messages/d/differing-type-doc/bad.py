def add(x: int, y: int):  # [differing-type-doc]
    """Add two numbers.

    :param int xy: x value.
    :param str y: y value.
    """

    return x + y
