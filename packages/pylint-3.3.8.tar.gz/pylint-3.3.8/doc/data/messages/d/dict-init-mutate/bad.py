fruit_prices = {}  # [dict-init-mutate]
fruit_prices["apple"] = 1
fruit_prices["banana"] = 10
