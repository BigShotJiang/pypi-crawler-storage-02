import distutils  # [deprecated-module]

import whatever_you_want  # [deprecated-module]
