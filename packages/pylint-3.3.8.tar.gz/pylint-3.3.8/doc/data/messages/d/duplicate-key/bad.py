test_score = {"Mathematics": 85, "Biology": 90, "Mathematics": 75}  # [duplicate-key]
