def print_fruit():
    print("apples")
