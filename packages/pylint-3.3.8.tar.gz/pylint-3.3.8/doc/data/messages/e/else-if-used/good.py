if input():
    pass
elif len(input()) >= 10:
    pass
else:
    pass
