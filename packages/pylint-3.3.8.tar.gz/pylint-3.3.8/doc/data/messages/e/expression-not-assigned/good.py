are_equal: bool = str(42) == "42"
