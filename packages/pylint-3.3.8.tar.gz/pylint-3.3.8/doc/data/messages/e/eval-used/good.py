from ast import literal_eval

literal_eval("[1, 2, 3]")
