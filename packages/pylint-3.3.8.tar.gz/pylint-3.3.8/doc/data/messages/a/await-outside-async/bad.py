import asyncio


def main():
    await asyncio.sleep(1)  # [await-outside-async]
