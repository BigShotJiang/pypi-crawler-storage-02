def function():
    return None


f = function() if function() else 1
