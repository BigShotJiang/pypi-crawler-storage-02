Directly asserting a string literal will always pass. The solution is to
test something that could fail, or not assert at all.

For ``unittest`` assertions there is the similar :ref:`redundant-unittest-assert` message.
