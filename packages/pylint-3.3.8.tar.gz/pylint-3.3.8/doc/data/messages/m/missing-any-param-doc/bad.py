def puppies(head, tail):  # [missing-any-param-doc]
    """Print puppy's details."""
    print(head, tail)
