def puppies(head: str, tail: str):
    """Print puppy's details.

    :param head: description of the head of the dog
    :param tail: description of the tail of the dog
    """
    print(head, tail)
