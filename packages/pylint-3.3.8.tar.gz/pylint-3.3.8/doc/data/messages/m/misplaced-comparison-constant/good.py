def compare_apples(apples=20):
    for i in range(10):
        if i >= 5:
            pass
        if i == 1:
            pass
        if len(apples) > 20:
            pass
