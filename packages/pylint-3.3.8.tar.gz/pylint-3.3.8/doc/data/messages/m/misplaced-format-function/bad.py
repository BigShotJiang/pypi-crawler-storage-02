print("Value: {}").format("Car")  # [misplaced-format-function]
