print("Value: {}".format("Car"))
