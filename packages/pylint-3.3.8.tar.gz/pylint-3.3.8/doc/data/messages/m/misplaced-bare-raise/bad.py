def validate_positive(x):
    if x <= 0:
        raise  # [misplaced-bare-raise]
