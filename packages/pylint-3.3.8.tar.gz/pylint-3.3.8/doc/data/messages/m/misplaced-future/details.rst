A bare raise statement will re-raise the last active exception in the current scope. If the ``raise`` statement is not in an ``except`` or ``finally`` block, a RuntimeError will be raised instead.
