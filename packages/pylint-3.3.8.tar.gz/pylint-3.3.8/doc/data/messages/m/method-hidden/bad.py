class Fruit:
    def __init__(self, vitamins):
        self.vitamins = vitamins

    def vitamins(self):  # [method-hidden]
        pass
