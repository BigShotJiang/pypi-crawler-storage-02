def update_tomato():
    global TOMATO  # [global-variable-undefined]
    TOMATO = "moneymaker"
