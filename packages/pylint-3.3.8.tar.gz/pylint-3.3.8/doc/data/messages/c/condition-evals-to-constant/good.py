def is_a_fruit(fruit):
    return fruit in {"apple", "orange"}
