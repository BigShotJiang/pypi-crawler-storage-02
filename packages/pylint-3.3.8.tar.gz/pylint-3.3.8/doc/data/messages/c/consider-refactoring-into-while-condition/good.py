fruit_basket = ["apple", "orange", "banana", "cherry", "guava"]

while len(fruit_basket) != 0:
    fruit = fruit_basket.pop()
    print(f"We removed {fruit} from the basket")
