with open("file.txt", "w") as fh1, fh2:  # [confusing-with-statement]
    pass
