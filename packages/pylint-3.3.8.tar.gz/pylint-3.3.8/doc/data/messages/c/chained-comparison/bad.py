a = int(input())
b = int(input())
c = int(input())
if a < b and b < c:  # [chained-comparison]
    pass
