while True:
    try:
        pass
    finally:
        continue  # [continue-in-finally]
