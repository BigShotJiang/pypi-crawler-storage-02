print(max(1, 2))
