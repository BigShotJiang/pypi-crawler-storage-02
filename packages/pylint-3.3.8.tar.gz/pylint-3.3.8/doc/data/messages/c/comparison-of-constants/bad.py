def is_the_answer() -> bool:
    return 42 == 42  # [comparison-of-constants]
