cats: int | str
