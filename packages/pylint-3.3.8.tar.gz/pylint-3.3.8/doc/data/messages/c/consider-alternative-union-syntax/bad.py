from typing import Union

cats: Union[int, str]  # [consider-alternative-union-syntax]
