import typing

cats: typing.Dict[str, int]  # [consider-using-alias]
