FRUITS = {"apple": 1, "pear": 5, "peach": 10}


for fruit in FRUITS:
    print(fruit)
