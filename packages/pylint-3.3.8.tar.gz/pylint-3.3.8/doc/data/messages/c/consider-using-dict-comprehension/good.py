NUMBERS = [1, 2, 3]

DOUBLED_NUMBERS = {number: number * 2 for number in NUMBERS}
