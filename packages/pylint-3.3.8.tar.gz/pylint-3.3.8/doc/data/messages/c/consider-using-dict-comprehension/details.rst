pyupgrade_ or ruff_ can fix this issue automatically.

.. _pyupgrade: https://github.com/asottile/pyupgrade
.. _ruff: https://docs.astral.sh/ruff/
