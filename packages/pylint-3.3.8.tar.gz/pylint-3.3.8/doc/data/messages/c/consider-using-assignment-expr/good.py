if apples := 2:
    print("God apples!")
