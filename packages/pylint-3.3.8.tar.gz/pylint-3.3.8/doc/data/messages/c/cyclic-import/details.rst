The good code is just an example. There are various strategies to resolving
cyclic imports and the best choice relies heavily on the context of the code
and the affected modules.
