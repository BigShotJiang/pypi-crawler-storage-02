def wizard_spells(spell_book):
    for spell in spell_book:
        print(f"Abracadabra! {spell}.")


spell_list = ["Levitation", "Invisibility", "Fireball", "Teleportation"]
wizard_spells(spell_list)
