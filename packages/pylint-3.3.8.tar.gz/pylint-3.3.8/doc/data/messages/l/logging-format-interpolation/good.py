import logging
import sys

logging.error("Python version: %s", sys.version)
