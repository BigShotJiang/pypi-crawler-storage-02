import logging
import sys

logging.error(f"Python version: {sys.version}")  # [logging-fstring-interpolation]
