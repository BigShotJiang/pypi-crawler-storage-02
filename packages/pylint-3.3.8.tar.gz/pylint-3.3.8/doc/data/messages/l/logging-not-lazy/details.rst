Another reasonable option is to use f-strings. If you want to do that, you need to enable
``logging-not-lazy`` and disable ``logging-fstring-interpolation``.
