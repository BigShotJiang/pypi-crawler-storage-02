__all__ = ["Fruit", "Worm"]


class Fruit:
    pass


class Worm:
    pass
