class Apple:
    pass


class RedDelicious:
    pass


Apple.__class__ = RedDelicious
