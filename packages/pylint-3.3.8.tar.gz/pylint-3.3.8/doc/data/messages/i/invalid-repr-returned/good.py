class CustomRepr:
    """__repr__ returns <type 'str'>"""

    def __repr__(self):
        return "apples"
