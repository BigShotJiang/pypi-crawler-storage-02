import os

env = os.getenv("SECRET_KEY", 1)  # [invalid-envvar-default]
