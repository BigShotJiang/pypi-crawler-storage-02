isinstance("apples and oranges", str)
