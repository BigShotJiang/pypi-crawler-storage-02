STRING = "Invalid character zero-width-space ​"  # [invalid-character-zero-width-space]
