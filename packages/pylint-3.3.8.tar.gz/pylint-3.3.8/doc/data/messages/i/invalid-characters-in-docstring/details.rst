This is a message linked to an internal problem in enchant. There's nothing to change in your code,
but maybe in pylint's configuration or the way you installed the 'enchant' system library.
