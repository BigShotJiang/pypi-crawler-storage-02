class Fruit:
    def __bool__(self):
        pass
