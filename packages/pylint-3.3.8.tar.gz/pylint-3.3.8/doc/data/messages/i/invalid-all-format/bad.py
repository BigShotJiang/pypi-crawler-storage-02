__all__ = "CONST"  # [invalid-all-format]

CONST = 42
