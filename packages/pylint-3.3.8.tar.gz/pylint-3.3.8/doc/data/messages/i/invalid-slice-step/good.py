LETTERS = ["a", "b", "c", "d"]

LETTERS[::2]
