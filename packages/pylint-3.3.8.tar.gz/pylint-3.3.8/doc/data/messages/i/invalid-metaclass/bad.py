class Apple(metaclass=int):  # [invalid-metaclass]
    pass
