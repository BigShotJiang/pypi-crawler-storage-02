class Plant:
    pass


class Apple(Plant):
    pass
