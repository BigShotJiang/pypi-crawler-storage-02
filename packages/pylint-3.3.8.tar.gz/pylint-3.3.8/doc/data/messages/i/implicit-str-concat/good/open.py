with open("hello.txt", "r") as f:
    print(f.read())
