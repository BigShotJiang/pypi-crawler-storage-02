Be careful with ``[True]`` or ``[False]`` as sequence index, since ``True`` and ``False`` will respectively
be evaluated as ``1`` and ``0`` and will bring the second element of the list and the first without erroring.
