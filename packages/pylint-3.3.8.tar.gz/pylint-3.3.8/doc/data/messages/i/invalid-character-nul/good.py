STRING = "Valid nul terminator: \x00"
