def get_the_answer(value: str) -> str | None:
    if value:
        return value
    return None
