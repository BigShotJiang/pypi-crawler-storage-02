def func(*args, x=None):
    return [*args, x]
