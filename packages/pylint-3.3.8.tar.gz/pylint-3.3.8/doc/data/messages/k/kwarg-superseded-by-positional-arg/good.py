def print_name(name="Sarah", /, **kwds):
    print(name)


print_name("Jacob")
# Will print "Jacob"
