You can use regular expressions and the ``notes-rgx`` option to create some constraints for this message.
See `the following issue <https://github.com/pylint-dev/pylint/issues/2874>`_ for some examples.
