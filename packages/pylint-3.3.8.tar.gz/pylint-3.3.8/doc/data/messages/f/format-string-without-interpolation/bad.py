print("number".format(1))  # [format-string-without-interpolation]
