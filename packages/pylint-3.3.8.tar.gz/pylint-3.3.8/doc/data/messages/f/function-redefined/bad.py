def get_email():
    pass


def get_email():  # [function-redefined]
    pass
