x = 1
y = 2
print(f"x + y = x + y")  # [f-string-without-interpolation]
