from .entrypoint import app

__all__ = ["app"]
