class SkipMessageError(Exception):
    pass
