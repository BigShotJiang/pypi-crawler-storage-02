from binnakle import Binnakle

logger = Binnakle(prefix='(liebre) ')
