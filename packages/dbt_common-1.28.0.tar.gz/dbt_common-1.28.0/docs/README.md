## Documentation

The documentation is divided into the following sub-folders:
* arch: Architecture Decision Records (ADRs) which explain and justify major architectural decisions
* guides: Informal documents which describe the code or our development practices at a high level
