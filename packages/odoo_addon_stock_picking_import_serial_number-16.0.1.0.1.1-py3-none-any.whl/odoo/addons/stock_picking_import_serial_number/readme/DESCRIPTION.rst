This module extends the functionality of stock module to allow import serial numbers
from an excel file.
