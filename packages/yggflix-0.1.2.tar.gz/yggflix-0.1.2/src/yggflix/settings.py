YGGFLIX_URL="https://yggflix.fr"
YGG_PASSKEY=""