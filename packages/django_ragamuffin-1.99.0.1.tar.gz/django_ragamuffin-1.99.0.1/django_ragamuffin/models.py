from django.db import models
from openai import OpenAI
from pathlib import Path
from django.db import transaction
import random, string
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
import shutil
from .mathpix import mathpix
from .remote_calls import run_remote_query

import logging
import time
import tiktoken
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import hashlib
import openai
from django.db.models.signals import m2m_changed, pre_delete, post_delete
from django.dispatch import receiver
from openai._exceptions import NotFoundError
import re

import os
logger = logging.getLogger(__name__)

upload_storage = FileSystemStorage(settings.OPENAI_UPLOAD_STORAGE, base_url=settings.MEDIA_URL )

from openai import OpenAIError, RateLimitError, APIError, Timeout

def randstring(tag, length=8):
    characters = string.ascii_letters + string.digits  # A-Z, a-z, 0-9
    return tag + '-' + ''.join(random.choices(characters, k=length))


def dump_remote_vector_stores(s='') :
    logger.error(f"DUMP REMOTE_VECTOR_STORES {s}\nvvvvvv")
    remote_vector_stores = RemoteVectorStore.objects.all();
    for remote_vector_store in remote_vector_stores :
        logger.error(f"REMOTE_VECTOR_STORE = cs={remote_vector_store.checksum} id={remote_vector_store.vector_store_id} pks={remote_vector_store.vector_stores_pks()}")
    logger.error(f"^^^^^^")


def remote_wait_for_vector_store_delete(vector_store_id, timeout=settings.MAXWAIT, interval=2):
    logger.error(f"WAIT_FOR_VECTOR_STORE_DELETE {vector_store_id}")
    client = OpenAIClient()
    start_time = time.time()
    while time.time() - start_time < timeout:
        logger.error(f"WAITIN DELETE")
        try:
            client.vector_stores.retrieve(vector_store_id)
        except NotFoundError:
            return
        time.sleep(interval)

    raise TimeoutError(f"Vector store {vector_store_id} deletion not confirmed within timeout.")



def remote_wait_for_vector_store_ready(client, vector_store_id, timeout=settings.MAXWAIT):
    logger.error(f"WAIT_FOR_VECTOR_STORE_READY {vector_store_id}")
    start_time = time.time()
    client = OpenAIClient()
    i = 0;
    while True:
        i = i + 1;
        print(f"WATING1 {i}")
        vs = client.vector_stores.retrieve(vector_store_id=vector_store_id)
        print(f"STATUS = {vs.status}")
        if vs.status == "completed":
            return vs
        elif vs.status == "failed":
            raise RuntimeError("❌ Vector store creation failed.")
        elif time.time() - start_time > timeout:
            raise TimeoutError("⏱️ Timeout: Vector store not ready in time.")
        time.sleep(10)
    i = 0;
    imax = settings.MAXWAIT / interval;
    while i < imax :
        print(f"I2 = {i}")
        file_list = client.vector_stores.files.list(vector_store_id=vector_store_id)
        statuses = [file.status for file in file_list.data]
        if all(status == "completed" for status in statuses):
            break
        elif any(status == "failed" for status in statuses):
            raise Exception(f"❌ Some files failed to process! {statuses}")
        else:
            time.sleep(5)  # Wait before polling again
        i = i + 1 ;
    assert i < imax , "VECTOR STORE READY TIMED OUT"


def validate_file_extension(value):
    ext = os.path.splitext(value.name)[-1].lower()
    if ext not in ['.md','.txt','.pdf','.tex']:
        raise ValidationError(f"Unsupported file extension '{ext}'.")

def hashed_upload_to(instance, filename):
    dirname = '.'.join( instance.file.name.split('.')[:-1] )
    os.makedirs(os.path.join( settings.OPENAI_UPLOAD_STORAGE, dirname ) ,  exist_ok=True)
    return os.path.join( dirname, instance.file.name )

def create_or_retrieve_vector_store( name , files) :
    vs = VectorStore.objects.filter(name=name).all()
    if not vs :
        vs = VectorStore(name=name)
        vs.save();
        vs.files.set(files)
        vs.save()
    else :
        vs = vs[0]
    return vs

def create_or_retrieve_assistant( name , vs ):
    assistants  = Assistant.objects.filter(name=name).all()
    model = settings.AI_MODELS['default']
    if not assistants :
        assistant = Assistant(name=name,model=model)
        assistant.save()
    else :
        assistant = assistants[0]
    assistant.vector_stores.add(vs)
    assistant.save();
    return assistant

def create_or_retrieve_thread( assistant, name, user ) :
    if user.pk :
        threads = Thread.objects.filter(name=name,user=user)
    else :
        user = None
    threads = Thread.objects.filter(name=name,user=user)
    if not threads :
        thread = Thread(name=name,user=user)
    else :
        thread = threads[0]
    thread.save()
    thread.assistant = assistant
    thread.save()
    return thread







def upload_or_retrieve_openai_file( name ,src ):
    os.makedirs( os.path.join( settings.OPENAI_UPLOAD_STORAGE, name ), exist_ok=True )
    dst = os.path.join(os.path.join( settings.OPENAI_UPLOAD_STORAGE, name ), src)
    name = dst.split('/')[-1];
    ts = OpenAIFile.objects.filter(name=name)
    if not ts :
        if not src == dst :
            shutil.copy2(src, dst)
        t1 = OpenAIFile(file=dst)
        t1.name = name
        t1.save();
    else :
        t1 = ts[0]
    return t1

def split_long_chunks(chunks, max_len=800):
    new_chunks = []
    for chunk in chunks:
        words = chunk["content"].split()
        for i in range(0, len(words), max_len):
            part = ' '.join(words[i:i+max_len])
            new_chunks.append({
                "heading": chunk["heading"],
                "content": part
            })
    return new_chunks

def chunk_mmd(linestring):
    chunks = []
    current_chunk = []
    current_heading = ''
    lines  = linestring.splitlines()

    for line in lines:
        if re.match(r'^#{1,6} ', line) or line == ''  or re.match(r'\\section', line ) :
            if re.match(r'\\section',line) :
                current_heading = line.strip() 
            if current_chunk:
                chunks.append({
                    "heading": current_heading,
                    "content": ''.join(current_chunk).strip()
                })
            current_chunk = []
        else:
            current_chunk.append(line)

    if current_chunk:
        chunks.append({
            "heading": current_heading,
            "content": ''.join(current_chunk).strip()
        })

    s = f"{chunks}"
    chunks = split_long_chunks( chunks );
    s = re.sub(r"},","},\n",s)
    return s.encode('utf-8')




class QUser(models.Model ):
    username = models.CharField(max_length=255,blank=True)
    is_staff = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.username}"



class OpenAIClient( OpenAI ):



    def __init__(self, **kwargs):
        super().__init__(api_key=settings.AI_KEY, **kwargs)

    def get_or_update_remote_vector_store(self, vs , old_checksum=None,old_file_ids=[]):
        logger.error(f"OLD_CHECKSUM = {old_checksum} NEW_CHECKSUM={vs.checksum} ")
        new_checksum = vs.get_checksum();
        #if old_checksum :
        #    old_remote_vector_stores = RemoteVectorStore.objects.filter(checksum=old_checksum)
        #    if old_remote_vector_stores:
        #        old_remote_vector_store = old_remote_vector_stores[0]
        #        old_remote_vector_store.vector_stores.remove( vs.pk )
        checksum = vs.get_checksum()
        new_checksum = checksum
        #print(f"OLD_CHECKSUM = {old_checksum} NEW_CHECKSUM={vs.checksum} ")
        new_file_ids =  [i[0] for i in  vs.files.values_list('file_ids', flat=True)  ]
        #print(f"OLD_IDS = {old_file_ids} NEW_IDS={new_file_ids} ")
        pks = [ i.pk for i in vs.files.all() ]
        #print(f"NEW_FILE_PKS = {pks}")
        remote_vector_stores = RemoteVectorStore.objects.filter(checksum=new_checksum).all()
        if remote_vector_stores :
            remote_vector_store = remote_vector_stores[0]
            new_vector_store_id = remote_vector_store.vector_store_id
            vs.remote_vector_store = remote_vector_stores[0]
            new_vector_store_id =    remote_vector_store.vector_store_id
            vs.vsid = new_vector_store_id
            vs.remote_vector_store = remote_vector_store
            vs.save();
            return new_vector_store_id
            #remote_vector_store.vector_stores.add(vs)
        else :
            remote_vector_stores = RemoteVectorStore.objects.filter(checksum=old_checksum).all()
            if  False and remote_vector_stores :
                remote_vector_store = remote_vector_stores[0]
                vector_store_id = remote_vector_store.vector_store_id
                deleted_files = list( set( old_file_ids) - set( new_file_ids) )
                #print(f" FILES TO BE DELETED {deleted_files}");
                for f in deleted_files:
                    try :
                        self.vector_stores.files.delete(vector_store_id=vector_store_id, file_id=f)
                        remote_wait_for_vector_store_ready(self, vector_store_id, timeout=settings.MAXWAIT)
                    except openai.NotFoundError as e:
                        logger.error(f"File {f} not found in vector store {vector_store_id}: {e}")
                        continue
                added_files = list( set( new_file_ids) - set( old_file_ids) )
                #print(f"Files to be added = {added_files}")
                #print(f"VECTOR_STORE_ID = {vector_store_id}")
                #print(f"VS NAME = {vs.name}")
                vs.checksum = new_checksum
                if not added_files == []:
                    self.vector_stores.file_batches.create( vector_store_id=vector_store_id, file_ids=added_files, 
                        metadata={"api_app" : settings.API_APP, "api_key": settings.AI_KEY[-8:] , "checksum" : new_checksum } )
                    remote_wait_for_vector_store_ready(self, vector_store_id, timeout=settings.MAXWAIT)
                #print(f"NEW_CHECKSUM = {new_checksum}")
                remote_vector_store.checksum = new_checksum;
                new_vector_store_id = remote_vector_store.vector_store_id
                remote_vector_store.save();

            else :
                #print(f"OLD CHECKSUM DOES NOT EXIST")
                #LIST VS: vss-23bCXLC0 vs_6866fd6acd5c8191ad163e2abb73c68c {'api_key': '9c_BWB8A', 'api_app': 'test', 'checksum': 'd41d8cd98f00b204e9800998ecf8427e'}
                # LIST VS: vss-KfSfYb46 vs_6866fcd6361c8191ad97ffc17aaebe29 {'api_key': '9c_BWB8A', 'api_app': 'test', 'checksum': 'd41d8cd98f00b204e9800998ecf8427e'}
                #name = randstring('vss')
                name = checksum
                #print(f"CREATING {name} with FILE_IDS = {new_file_ids}")
                new_remote_vector_store = self.vector_stores.create(name=name,file_ids=new_file_ids , 
                    metadata={"api_app" : settings.API_APP, "api_key": settings.AI_KEY[-8:] , "checksum" : new_checksum } )
                remote_wait_for_vector_store_ready(self, new_remote_vector_store.id, timeout=settings.MAXWAIT)
                rvs = new_remote_vector_store
                #logger.error(f"CREATE NEW REMOTE_VECTOR_STORE WITH {checksum} {new_vector_store_id}")
                #new_remote_vector_stores =  RemoteVectorStore.objects.filter(checksum=checksum).all()
                #if new_remote_vector_stores :
                #    new_remote_vector_store = new_remote_vector_stores[0]
                #    new_remote_vector_store.vector_store_id = new_vector_store_id
                #else :
                new_remote_vector_store, created   = RemoteVectorStore.objects.get_or_create(checksum=checksum,vector_store_id=rvs.id);
                new_remote_vector_store.save();
                #print(f"CREATED_NEW_VECTOR_STORE {new_remote_vector_store} {new_remote_vector_store.checksum} {new_remote_vector_store.vector_store_id}")
                vs.vector_store_id = rvs.id
                vs.remote_vector_store = new_remote_vector_store
                vs.vsid = rvs.id
                vs.save()
                new_vector_store_id = rvs.id
        #print(f"FINISHED CREATING VS CHECKSUM = {vs.name} {vs.checksum} {vs.remote_vector_store}")
        return new_vector_store_id


    def delete_vector_store(self, vs, vector_store_id) :
        assert vs.get_vector_store_id() == vector_store_id, "FAIL1"
        try:
            vector_store_id = vs.get_vector_store_id()
        except AttributeError as e:
            logger.error(f"Failed to get vector_store_id: {e}")
            raise
        checksum = vs.get_checksum()
        return True


    def vector_stores_retrieve(self, vs, vector_store_id) :
        #assert vs.get_vector_store_id() == vector_store_id, "FAIL2"
        vector_store_id = vs.get_vector_store_id()
        checksum = vs.get_checksum()
        return self.vector_stores.retrieve(vector_store_id)


    def vector_stores_files_list(  self, vs, vector_store_id ):
        assert vs.get_vector_store_id() == vector_store_id, "FAIL3"
        vector_store_id = vs.get_vector_store_id()
        checksum = vs.get_checksum()
        vector_store_files = self.vector_stores.files.list( vector_store_id=vector_store_id)
        assert checksum == vs.get_checksum() , "FAIL3b"
        return vector_store_files

    def vector_stores_create( self,  name, metadata ):
        name = randstring('vs' + name )
        vector_store = self.vector_stores.create(name=name,metadata=metadata )
        remote_wait_for_vector_store_ready( self, vector_store.id )
        return vector_store

    def delete_file_from_vs( self,  vs, vector_store_id, file_id ):
        assert vs.get_vector_store_id() == vector_store_id, "FAIL4"
        vector_store_id = vs.get_vector_store_id()
        checksum = vs.get_checksum()
        try :
            self.vector_stores.files.delete(vector_store_id=vector_store_id,file_id=file_id)
            remote_wait_for_vector_store_ready(self, vector_store_id, timeout=settings.MAXWAIT)
        except  openai.NotFoundError as e: 
            return False
        try :
            self.files.delete( file_id )
        except  openai.NotFoundError as e: 
            return False
        assert checksum == vs.get_checksum() , "FAIL4b"
        return True

    def delete_file_globally( self , file_id ):
        try :
            logger.error(f"DELETE GLOBALLY {file_id}")
            self.files.delete(file_id)
            return True
        except Exception as err :
            logger.error(f"GLOBAL DELETION ERROR {str(err)}")
            return False

    def vector_stores_files_delete( self, vs, vector_store_id, file_id ):
        assert vs.get_vector_store_id() == vector_store_id, "FAIL5"
        checksum = vs.get_checksum()
        vector_store_id = vs.get_vector_store_id()
        self.vector_stores.files.delete( vector_store_id=vector_store_id , file_id=file_id)
        remote_wait_for_vector_store_ready(self, vector_store_id, timeout=settings.MAXWAIT)
        assert checksum == vs.get_checksum() , "FAIL5b"
        return vector_store_id

    def vector_stores_files_create( self, vs, vector_store_id , file_id ):
        assert vs.get_vector_store_id() == vector_store_id, "FAIL6"
        checksum = vs.get_checksum()
        vector_store_id = vs.get_vector_store_id()
        self.vector_stores.files.create( vector_store_id=vector_store_id , file_id=file_id , 
             metadata={"api_app" : settings.API_APP, "api_key": settings.AI_KEY[-8:] , "checksum" : new_checksum }  )
        remote_wait_for_vector_store_ready(self, vector_store_id=vector_store_id, timeout=settings.MAXWAIT)
        assert checksum == vs.get_checksum() , "FAIL6b"
        return vector_store_id





class OpenAIFile(models.Model) :
    date = models.DateTimeField(auto_now=True)
    checksum = models.CharField(blank=True, max_length=255)
    name = models.CharField(max_length=255,blank=True)
    path = models.CharField(max_length=255,blank=True)
    file_ids = models.JSONField(default=list, null=True, blank=True)
    file = models.FileField( max_length=512, upload_to=hashed_upload_to, storage=upload_storage, validators=[validate_file_extension] )
    ntokens = models.IntegerField(default=0,null=True, blank=True)
    

    def __str__(self):
        return f"{self.name}"



    def save( self, *args, **kwargs ):
        is_new = self._state.adding  and not self.pk
        name =  f"{self.file}".split('/')[-1]
        super().save(*args, **kwargs)  # Save first, so file is processed
        if ( is_new and self.file ):
            fn = self.file.name 
            self.name = self.file.name.split('/')[-1]
            src = self.file.path
            extension = src.split('.')[-1];
            if extension == 'pdf' :
                txt = mathpix( src ,format_out='mmd')
            else :
                txt = ( open(src,'rb').read() ).decode('utf-8')
            if extension == 'pdf' :
                chunks = chunk_mmd(txt)
            else :
                chunks = txt.encode()
            chunkdir = os.path.join( os.path.dirname( src ), 'chunks')
            os.makedirs( chunkdir, exist_ok=True )
            srcbase = Path( os.path.basename(src) )
            if extension == 'pdf' :
                jbase = srcbase.with_suffix('.json')
            else :
                jbase = srcbase.with_suffix('.' + extension )
            dst = os.path.join( chunkdir, jbase )
            if chunks :
                open( dst, "wb").write( chunks)
            else :
                shutil.copy2(src, dst)
            data = self.file.read()
            self.checksum = hashlib.md5(data).hexdigest()
            uploaded_file = openai.files.create( file=open( dst, "rb"), purpose="assistants"  )
            self.file_ids = [uploaded_file.id ]
            self.path = os.path.dirname( self.file.path )

            def get_ntokens( file_path):
                valid_text = ''
                encoding = tiktoken.encoding_for_model(settings.AI_MODELS['staff'])
                with open(file_path, "rb") as f:
                    for line in f:
                        try:
                            decoded = line.decode("utf-8")
                            valid_text += decoded
                        except UnicodeDecodeError:
                            continue  # Skip invalid lines
                tokens = encoding.encode(valid_text)
                return len( tokens )



            self.ntokens = get_ntokens( dst )
            self.name = name
            super().save(*args, **kwargs) # Then update with true hashed path



@receiver(pre_delete, sender=OpenAIFile)
def custom_delete_openaifile(sender, instance, **kwargs):
    logger.error(f"CUSTOM_DELETE_OPENAIFILE")
    pk = instance.pk
    #vst = VectorStore.objects.filter(files=instance).all();
    vst = instance.vector_stores.all();
    logger.error(f"VST_INITIALL = {vst}")
    client = OpenAIClient()
    if hasattr( instance, "file_ids") :
        file_ids = instance.file_ids
        for file_id in file_ids :
            o = OpenAIFile.objects.get(file_ids=[file_id])
            for vs in vst :
                vector_store_id = vs.get_vector_store_id()
                old_checksum = vs.checksum
                vs.files.remove( o )
                vs.save(update_fields=['checksum'] );
                vs.checksum = vs.get_checksum();
                vsid =  client.get_or_update_remote_vector_store( vs )
                vs.vsid = vsid
                vs.save()
                new_checksum = vs.checksum
                logger.error(f"NEW_CHECKSUM = {new_checksum} OLD = {old_checksum}")
                assert not new_checksum == old_checksum, f'CHECKSUMS UNCHANGED {old_checksum} for {vector_store_id}'
        #for file_id in file_ids:
        #    try :
        #        client.vector_stores_files_delete( vector_store_id=vector_store_id, file_id=file_id,)
        #        #remote_wait_for_vector_store_ready(client, vsid, timeout=settings.MAXWAIT)
        #        #response = client.files.delete(file_id )
        #        #vector_store_files = client.vector_stores.files.list(vector_store_id=vector_store_id)
        #        #vsfiles = [ i.id for i in vector_store_files]
        #    except Exception as e :
        #        logger.error(f"DELETE ERROR {str(e)}")

    #vst = instance.vector_stores.all();
    #logger.error(f"VST FINALLY = {vst}")
    #for vs in vst :
    #    vsid =  client.get_or_update_remote_vector_store( vs )
    #    logger.error(f"VSID TEST {vs.vsid} == {vsid}")
    try :
        client.delete_file_globally( file_id )
        shutil.rmtree(instance.path)
    except Exception as e:
        logger.error(f" FILE/ {instance.path} DOES NOT EXIST")
        return



class RemoteVectorStore( models.Model ) :
    checksum = models.CharField(blank=True, max_length=255,unique=True)
    vector_store_id  =  models.CharField(blank=True, max_length=255 )

    def vector_stores_pks(self ):
        pks = [ i.pk for i in self.vector_stores.all() ]
        return pks
    def slow_file_names(self):
        client = OpenAIClient()
        vs_files = client.vector_stores.files.list(vector_store_id=self.vector_store_id)
        names = [];
        for vs_file in vs_files.data:
            file_id = vs_file.id
            file_obj = client.files.retrieve(file_id)
            names.append(file_obj.filename)
        return names

    def file_names(self):
        vss = VectorStore.objects.filter(checksum=self.checksum).all();
        names = [];
        for v in vss :
            names.extend( v.file_names() );
        return names





class VectorStore( models.Model ):
    checksum = models.CharField(blank=True, max_length=255)
    vsid = models.CharField(max_length=255,blank=True)
    name =  models.CharField(max_length=255 ) # ,unique=True)
    files = models.ManyToManyField( OpenAIFile , related_name='vector_stores')
    remote_vector_store = models.ForeignKey( 
        RemoteVectorStore ,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='vector_stores',
        )




    def __str__(self):
        return f"{self.name}"

    def get_vector_store_id( self ):
        return self.remote_vector_store.vector_store_id


    def clone( self, newname, *args, **kwargs):
        vector_stores = VectorStore.objects.filter( name=newname).all();
        if vector_stores :
            vector_store = vector_stores[0]
        else :
            vector_store = VectorStore(name=newname)
            vector_store.save();
        vector_store.files.set(self.files.all() )
        vector_store.remote_vector_store = self.remote_vector_store
        vector_store.checksum = self.checksum
        vector_store.save();
        return vector_store;


    def file_ids(self, *args, **kwargs ):
        files = self.files
        ids = []
        for f in files.all():
            ids.extend( f.file_ids )
        return ids

    def file_names(self, *args, **kwargs ):
        files = self.files
        n = []
        for f in files.all():
            n.append( f.name)
        return n


    def ntokens( self, *args, **kwargs ):
        files = self.files
        n = 0;
        for f in files.all():
            n = n + f.ntokens
        return n



    def file_pks(self, *args, **kwargs ):
        pks = []
        files = self.files
        for f in files.all():
            pks.append(f.pk)
        return pks

    def file_checksums(self, *args, **kwargs ):
        files = self.files
        if not files :
            return [];
        checksums = []
        for f in files.all():
            checksums.append(f.checksum)
        checksums = list( set( checksums) )
        checksums.sort()
        return checksums

    def old_save(self, *args, **kwargs):
        is_new = not self.pk
        if is_new :
            super().save(*args, **kwargs)
        checksum = self.get_checksum()
        client = OpenAIClient()
        if is_new:
            try:
                vector_store_id = client.get_or_update_remote_vector_store(self)
                self.vsid = vector_store_id
            except openai.OpenAIError as e:
                logger.error(f"OpenAIError in get_or_update_remote_vector_store: {e}")
                raise
            except Exception as e:
                logger.error(f"Unexpected error in get_or_update_remote_vector_store: {e}")
                raise
        super().save(*args, **kwargs)

    def save(self, *args, **kwargs):
        is_new = self._state.adding and not self.pk

        if is_new:
            print(f"SELF = {self}")
            print(f"ARGS = {args}")
            print(f"KWARGS = {kwargs}")

        self.checksum = self.get_checksum()
        client = OpenAIClient()

        if is_new:
            vector_store_id = client.get_or_update_remote_vector_store(self)
            self.vsid = vector_store_id

        super().save(*args, **kwargs)


    def get_checksum(self):
        cksums = self.file_checksums();
        ckstring = ''.join(cksums).encode()
        checksum = hashlib.md5(ckstring).hexdigest()
        return checksum

    def files_ok( self, *args, **kwargs) :
        vs = VectorStore.objects.get(pk=self.pk)
        file_ids = vs.file_ids()
        vector_store_id = vs.get_vector_store_id()
        client = OpenAIClient()
        vector_store_files = client.vector_stores.files.list( vector_store_id=vector_store_id)
        remote_ids = []
        logger.error(f"FILES OK CHECK VECTOR_STORE_ID = {vector_store_id}")
        for f in vector_store_files:
            remote_ids.append( f.id)
        #print(f"FILESOK for { vs.get_vector_store_id()} ? LOCAL={file_ids} == REMOTE={remote_ids}")
        return set( file_ids) == set( remote_ids) 

    def save( self, *args, **kwargs ):
        is_new = self._state.adding and not self.pk
        if is_new :
            print(f"SELF = {self}")
            print(f"ARGS = {args}")
            print(f"KWARGS = {kwargs}")
            super().save(*args,**kwargs)
        checksum = self.get_checksum();
        client = OpenAIClient()
        if is_new :
            vector_store_id = client.get_or_update_remote_vector_store( self )
            self.vsid = vector_store_id
        super().save(*args,**kwargs)



@receiver(pre_delete, sender=RemoteVectorStore)
def custom_delete_remote_vector_store(sender, instance, **kwargs):
    client = OpenAIClient();
    vector_store_id = instance.vector_store_id
    logger.error(f"DELETE REMOTE_VECTOR_STORE_ID {vector_store_id}")
    try :
        logger.error(f"A1 {vector_store_id}")
        client.vector_stores.delete( vector_store_id )
        logger.error(f"A2 {vector_store_id}")
        remote_wait_for_vector_store_delete(vector_store_id, timeout=settings.MAXWAIT, interval=2)
        logger.error(f"A3 {vector_store_id}")
    except Exception as e :
        logger.error(f"FAILED REMOTE_VECTOR_STORE_CLIENT_DELETE {vector_store_id} {str(e)} ")
        pass




def get_current_model( user=None ):
    if user == None :
        model = settings.AI_MODELS['default']
    elif user.is_staff: 
        model = settings.AI_MODELS['staff']
    else :
        model = settings.AI_MODELS['default']
    return model


DEFAULT_INSTRUCTIONS = """Answer only questions about the enclosed document. 
    Do not offer helpful answers to questions that do not refer to the document. 
    Be concise. 
    If the question is irrelevant, answer with "That is not a question that is relevant to the document." \n 
    For images use created by mathpix, not the sandbox link created by openai. 
    Since it is visible, dont  say something like "You can view the picture ... ". 
    If a link does not exist, just say that such an image does not exist. '
    """


class Assistant( models.Model ):
    name =   models.CharField(max_length=255,blank=True)
    instructions = models.TextField(blank=True,null=True)
    vector_stores = models.ManyToManyField( VectorStore ,blank=True)
    assistant_id = models.CharField(max_length=255,blank=True, null=True)
    json_field = models.JSONField( default=dict ,  blank=True, null=True)
    model = models.CharField(max_length=255,blank=True,null=True)
    temperature = models.FloatField(null=True, blank=True)


    #class Meta:
    #    constraints = [
    #        models.UniqueConstraint(fields=['name', 'model'], name='unique_name_model')
    #    ]

    def __str__(self):
        return f"{self.name}"


    def path(self) :
        p = '/'.join( self.name.split('.') )
        return p


    def add_file(self,  filename, uploaded_file ):
        print(f"ADD_FILE")
        name = '.'.join( filename.split('.')[:-1])
        filename = f"{name}/{filename}"
        upload_storage.save(filename , uploaded_file)
        file_url = settings.MEDIA_URL + upload_storage.url(filename)
        src = settings.OPENAI_UPLOAD_STORAGE + '/' + filename
        print(f"SRC = {src}")
        t1 = upload_or_retrieve_openai_file( name, src )
        print(f"file_url = {file_url}")
        self.add_raw_file( t1 )
        return file_url

    def add_raw_files(self,  t1 ):
        print(f"ADD_RAW_FILES")
        vss = self.vector_stores.all();
        if len( vss ) == 0 :
            vs = VectorStore( name=self.name);
            vs.save();
            self.vector_stores.add(vs)
        else :
            vs = vss[0]
        for t in t1 :
            self.add_raw_file( t )
        return 


    def add_raw_file(self, t1):
        print(f"ADD_RAW_FILE")
        vss = self.vector_stores.all()
        if len(vss) == 0:
            vs = VectorStore(name=self.name)
            vs.save(using='django_ragamuffin')
            self.vector_stores.add(vs)
            self.save(using='django_ragamuffin')
        else:
            vs = vss[0]
            logger.error(f"VSOLD = {vs.get_vector_store_id()}")
            try:
                vs.files.add(t1)
                logger.error(f"B SAVE")
                vs.save()
                logger.error(f"C SAVED")
                self.vector_stores.set([vs])
                self.save()
            except Exception as err:
                dump_remote_vector_stores("ERROR IN ADD_RAW_FILE")
        logger.error(f"VSNEW = {vs.get_vector_store_id()}")
        logger.error("D")
        assistant_id = self.assistant_id
        logger.error(f"E")
        client = OpenAIClient()
        client.beta.assistants.update(
            assistant_id=assistant_id,
            tool_resources={
                "file_search": {
                    "vector_store_ids": [vs.get_vector_store_id()],
                }
            }
        )
        logger.error(f"F")
        self.save();
        logger.error(f"G")
        return 

    def delete_raw_file( self, file ):
        vs = self.vector_stores.all()[0];
        vs.files.remove(file)
        vs.save();
        self.vector_stores.set([vs])
        assistant_id = self.assistant_id 
        client = OpenAIClient()
        client.beta.assistants.update(
            assistant_id=assistant_id,
            tool_resources={
                "file_search": {
                    "vector_store_ids": [vs.get_vector_store_id()],
                }
            }
        )
        self.save();
        return




    def delete_file( self, deletion ):
        deletion = int( deletion )
        vs = self.vector_stores.all()[0];
        file = OpenAIFile.objects.get(pk=deletion);
        vs.files.remove(file)

    def parent( self ):
        name = '.'.join( self.name.split('.')[:-1] )
        assistants = Assistant.objects.filter(name=name);
        if assistants :
            return assistants[0]
        else :
            return None

    def children( self ):
        name  = self.name;
        pattern = r'^%s\.[^.]+$' % name
        children = Assistant.objects.filter(name__regex=pattern).only('pk','name')
        res = [ {obj.pk : obj.name} for obj in children ]
        return res

    def get_instructions( self ): # GET THE LAST INSTRUCTIONS IN THE TREE
        if self.instructions :
            self.instructions = self.instructions.strip();
        appended = ''
        instructions = ''
        if self.instructions :
            do_append = self.instructions.split()[0].strip().rstrip(':').lower()  == 'append'
            if do_append :
                appended = ''.join( re.split(r'(\s+)', self.instructions)[1:] )
                instructions = ''
            else :
                instructions = self.instructions
        a = self;
        p = a.parent();
        if p :
            i = 0;
            while not p.parent() == None and instructions == ''  and i < 4 :
                p = p.parent();
                instructions = p.get_instructions();
                i = i + 1 ;
        if instructions == '':
            instructions = DEFAULT_INSTRUCTIONS 
        if appended :
            instructions = instructions + "\n" + appended
        return instructions
            

    def save( self, *args, **kwargs ):
        print(f"SAVE ASSISTANT")
        is_new = self._state.adding and not self.pk
        client = OpenAIClient()
        try :
            if not self.model :
                self.model = get_current_model( )
        except :
            pass
        if self.pk :
            old = Assistant.objects.get(pk=self.pk)
            old_instructions = old.get_instructions()
            old_temperature = old.temperature
            old_model = self.model
        else :
            old_instructions = None
        if self.temperature :
            temperature = self.temperature
        else :
            temperature = settings.DEFAULT_TEMPERATURE
        super().save(*args,**kwargs)
        vs_empty = False;
        instructions = self.get_instructions();
        if is_new :
            assistant = client.beta.assistants.create( name=self.name,
                instructions=instructions, 
                model=self.model,
                temperature=temperature,
                tools=[{"type": "file_search"}],
                metadata={"api_app" : settings.API_APP, "api_key": settings.AI_KEY[-8:] }
                )
            self.assistant_id = assistant.id
            super().save(update_fields=['assistant_id'])
            print(f"DOES NOT EXIST")
            vss = VectorStore.objects.filter( name=self.name);
            if vss :
                vs = vss[0]
            else :
                vs = VectorStore(name=self.name)
            print(f"VS NEW  = {vs}")
            vs.save();
            print(f"VS SAVED")
            self.vector_stores.set([vs])
            print(f"NOEW ADD TO VECTOR_STORES {vs} ")
            self.save();
            print("DONE SAVEING")
            transaction.on_commit(self.save ) 
            print(f"SELF = {self}")

        else :
            print(f"IS NOT NEW")
            #super().save( *args, **kwargs)


            assistant_id = self.assistant_id
            if not old_instructions  ==  instructions :
                client.beta.assistants.update(assistant_id, instructions=instructions)
            if not old_temperature ==  temperature :
                client.beta.assistants.update(assistant_id, temperature=temperature)
            if not old_model ==  self.model :
                logger.error("OLD_MODEL {old_model} != {self.model}")
                client.beta.assistants.update(assistant_id, model=self.model)


    #def oldclone( self, newname, *args, **kwargs):
    #    assistants = Assistant.objects.filter( name=newname).all();
    #    assert  len( assistants) == 0 , f"CREATE ASSISTANT WITH NAME {newname} ; ASSISTANT ALREADY EXISTS"
    #    model = settings.AI['default']
    #    assistant = Assistant(name=newname,model=model)
    #    assistant.instructions = self.instructions;
    #    assistant.json_field = self.json_field;
    #    assistant.model = self.model
    #    assistant.temperature = self.temperature;
    #    assistant.save();
    #    i = 0;
    #    for v in self.vector_stores.all() :
    #        vnew  = v;
    #        assistant.vector_stores.add(vnew )
    #        i = i + 1;
    #    assistant.save();
    #    return assistant;

    def clone( self, newname, model=None ):
        print(f"CLONE ASSISTANT {newname}")
        if model == None :
            model = self.model
        logger.error(f"CLONE_ASSISTANT {self.name} into {newname}")
        vss = self.vector_stores.all();
        logger.error(f"\n\n\n VSS = {vss}")
        if vss :
            vs = vss[0]
            logger.error(f"NOW VECTOR_STORE_CLONE {vs.name} into {newname}")
            vnew  = vs.clone( newname )
            logger.error(f"VECTOR_STORE {vnew} was created from {vs}")
        else :
            vsnews = VectorStore.objects.filter(name=newname).all()
            if vsnews :
                vnew = vsnews[0]
            else :
                vnew = VectorStore(name=newname)
                vnew.save();
        assistants = Assistant.objects.filter( name=newname )
        #for assistant in assistants :
        vals = list( set( list( settings.AI_MODELS.values() ) ) )
        for m in vals :
            assistant , created = Assistant.objects.get_or_create(name=newname,model=m)
            assistant.instructions = self.instructions;
            assistant.json_field = self.json_field;
            assistant.temperature = self.temperature;
            assistant.save();
            assistant.vector_stores.set([vnew.pk])
            assistant.save();
        logger.error(f"RETURNING CLONED ASSISTANT")
        return assistant;

    
        #
        # LEAVE THIS BLOCK AS COMMENTED OUT
        # THIS CLONE IS NOT EFFICIENT SINCE m2m is used to update 
        # vector_stores in assistant 
        # 
        #def clone_remote_assistant( old, new_name ):
        #    old_id = old.assistant_id 
        #    logger.error(f"\n\n CLONE_REMOTE_ASSISTANT {old_id} into {new_name} \n\n")
        #    client = OpenAIClient()
        #    old_vs  = client.beta.assistants.retrieve(old_id)
        #    tools=[{"type": "file_search"}]
        #    remote_assistant = client.beta.assistants.create(
        #        name=new_name,
        #        instructions=old_vs.instructions,
        #        model=old_vs.model,
        #        temperature=old_vs.temperature,
        #        tools=old_vs.tools,
        #        tool_resources=old_vs.tool_resources,
        #        metadata=old_vs.metadata,
        #    )
        #    return remote_assistant.id
        
        #assistant.assistant_id = clone_remote_assistant( self, newname )









    def ntokens( self, *args, **kwargs ):
        vs = self.vector_stores.all()
        n = 0;
        for v in vs :
            for vf in v.files.all():
                n = n + vf.ntokens 
        return n


    def file_pks( self, *args, **kwargs ):
        vs = self.vector_stores.all()
        f = []
        for v in vs :
            for vf in v.files.all():
                f.append( vf.pk )
        f = list( set( f) )
        return f

    def file_ids(self, *args, **kwargs ):
        vs = self.vector_stores.all()
        f = []
        for v in vs :
            for vf in v.files.all():
                f.extend( vf.file_ids )
        f = list( set( f) )
        return f

    def files( self, *args, **kwargs ):
        vs = self.vector_stores.all()
        f = []
        for v in vs :
            for vf in v.files.all():
                f.append( ( vf.pk , vf.name ) )
        return f





    def file_names( self, *args, **kwargs ):
        vs = self.vector_stores.all()
        f = []
        for v in vs :
            for vf in v.files.all():
                f.append( vf.name )
        f = list( set( f) )
        return f

    def remote_files( self, *args, **kwargs ) :
        client = OpenAIClient()
        assistant = self
        vss = self.vector_stores.all();
        for vs in vss :
            logger.error(f"ASSISTANT VS = {vs}")
        assistant_id = assistant.assistant_id
        remote_assistant = openai.beta.assistants.retrieve(assistant_id)
        tool_resources = remote_assistant.tool_resources
        remote_ids = [];
        vector_store_ids = tool_resources.file_search.vector_store_ids
        logger.error(f"VECTOR_STORE_IDS = {vector_store_ids}")
        for vector_store_id in vector_store_ids :
            vector_store_files = client.vector_stores.files.list( vector_store_id=vector_store_id)
            for f in vector_store_files:
                remote_ids.append( f.id)
        logger.error(f"REMOTE_IDS= {remote_ids}")
        return remote_ids


        

    def files_ok( self,*args, **kwargs):
        assistant = self
        vss = assistant.vector_stores.all();
        file_ids = assistant.file_ids();
        remote_ids = assistant.remote_files();
        return set( remote_ids) == set( file_ids )




class Thread(models.Model) :
    name = models.CharField(max_length=255)
    date = models.DateTimeField(auto_now=True)
    thread_id = models.CharField(max_length=255,blank=True)
    messages = models.JSONField( default=dict ,  blank=True, null=True)
    assistant = models.ForeignKey(Assistant, on_delete=models.SET_NULL, null=True, related_name="threads")
    user = models.ForeignKey(QUser, null=True, blank=True, on_delete=models.SET_NULL)
    max_tokens = models.IntegerField( blank=True, null=True)

    #class Meta:
    #    constraints = [
    #        models.UniqueConstraint(fields=['name', 'user'], name='unique_thread')
    #    ]
    

    def __str__(self):
        return f"{self.name}"




    def save( self, *args, **kwargs ):
        is_new = self._state.adding  and not self.pk
        self.messages = self.messages
        client = OpenAIClient();
        super().save(*args, **kwargs)  # Save first, so file is processed
        if is_new  :
            thread = client.beta.threads.create(); 
            thread_id = thread.id
            self.thread_id = thread_id
            self.messages = []
            super().save(*args, **kwargs) # Then update with true hashed path
        elif 'update_fields' in kwargs :
            thread_id = self.thread_id
            old_thread_id = thread_id
            new_thread =  client.beta.threads.create(); 
            new_thread_id = new_thread.id
            if self.messages :
                for msg in self.messages:
                    for role in ['user','assistant'] :
                        openai.beta.threads.messages.create(
                            thread_id=new_thread_id,
                            role=role,
                            content=msg[role]
                        )
                        
            self.thread_id = new_thread_id
            self.messages = self.messages
            super().save(*args, **kwargs)



    def run_query( self, *args, **kwargs  ):
        last_messages = kwargs.get('last_messages',settings.LAST_MESSAGES)
        max_num_results = kwargs.get('max_num_results',settings.MAX_NUM_RESULTS)
        query= kwargs['query']
        now = time.time();
    
        """ last_messages is either None for auto or an integer for length of thread history to keep at OpenAI. 
        The entire history is kept in the local database"""
        assistant = self.assistant
        if not assistant.model == get_current_model( self.user ):
            assistant.model = get_current_model( self.user )
            assistant.save();
        assistant_id = assistant.assistant_id
        model = assistant.model
        thread = self
        thread_id = thread.thread_id
    
        encoding = tiktoken.encoding_for_model(settings.AI_MODELS['staff'])
        if thread.max_tokens :
            max_tokens = thread.max_tokens
        else :
            max_tokens = settings.MAX_TOKENS
        timeout = settings.MAXWAIT
        context = {'openai' : openai, 'thread_id': thread_id, 'assistant_id' : assistant_id, 'query': query, 'last_messages' : last_messages, 'max_num_results' : max_num_results}
        msg = run_remote_query( context)
        if 'timed out' in msg['assistant'] :
            logger.error(f"TIMED OUT SO RETRY")
            msg = run_remote_query( context)
        thread.messages.append(msg) 
        thread.save()
        return msg






@receiver(pre_delete, sender=Assistant)
def custom_delete_assistant(sender, instance, **kwargs):
    pk = instance.pk
    client = OpenAIClient();
    try :
        assistant_id = instance.assistant_id
        assistant = openai.beta.assistants.retrieve(assistant_id)
        tool_resources = assistant.tool_resources
        vector_store_ids = tool_resources.file_search.vector_store_ids
        client = OpenAIClient()
        if vector_store_ids :
            vs = VectorStore.objects.get(name=instance.name)
            vector_store_id = vector_store_ids[0];
            vector_store =  client.vector_stores_retrieve(vs,vector_store_id)
            if vector_store.name == assistant.id : # THIS IS HERE BECAUSE MULTIPL VECTOR STORES CAN'T BE USED BY AN ASSISTANT
                client.delete_vector_store( vector_store_id)
        res = client.beta.assistants.delete(assistant_id)
    except Exception as err :
        logger.error(f"ERROR = {str(err)}")

@receiver(post_delete, sender=Assistant)
def post_delete_assistant(sender, instance, **kwargs):
    assistants = Assistant.objects.filter(name=instance.name ).all();
    for assistant in assistants :
        assistant.delete();




@receiver(m2m_changed, sender=Assistant.vector_stores.through)
def handle_assistants_changed(sender, instance, action, **kwargs):
    logger.error(f"HANDLE_SENDER_ASSISTANT action={action}")
    dontcontinue =  getattr(instance, '_updating_from_m2m', False)
    logger.error(f"DONT_CONTINUE = {dontcontinue}")
    if getattr(instance, '_updating_from_m2m', False):
        return
    instance._updating_from_m2m = True
    try :
        instance._count = instance._count + 1 
    except :
        instance._count = 0 
    if instance._count > 1 :
        return

    assistant = instance
    assistant_id = instance.assistant_id
    logger.error(f"ASSISTANT =  {action} {assistant} {assistant.vector_stores.all()} ")
    for vs in assistant.vector_stores.all():
        logger.error(f"     VS = {vs} FILES= {vs.files.all()}")
    client = OpenAIClient()
    rebuild = False
    if action == "post_remove":
        logger.error(f"POST_REMOVE")
        vector_stores = instance.vector_stores.all();
        assistant_id = instance.assistant_id
        assistant = openai.beta.assistants.retrieve(assistant_id)
        tool_resources = assistant.tool_resources
        try :
            if vector_stores :
                vs = vector_stores[0]
                vector_store_id = tool_resources.file_search.vector_store_ids[0]
                vector_store =  client.vector_stores_retrieve(vs, vector_store_id)
                if vector_store.name == assistant.name:
                    client.vector_store_delete( vector_store_id)
        except  Exception as err :
            logger.error(f" VECTOR_STORE ERROR DELTING ON POST_REMOVE")
            pass
        rebuild = True

    if action == "post_add" or action == 'post_remove' : # rebuild:
        logger.error(f"ACTION = {action}")
        pks = [];
        ids = [];
        file_ids = [];
        file_pks = []
        for v in instance.vector_stores.all() :
            logger.error(f"V NAME = {v.name} ")
            file_ids.extend( v.file_ids() )
            file_pks.extend( v.file_pks() )
            pks.append( v.pk )
            ids.append( v.get_vector_store_id() );
        file_ids = list( set( file_ids ) )
        file_ids.sort() 
        file_pks = list( set( file_pks ) )
        vsname = instance.name
        vss = VectorStore.objects.filter(name=vsname).all().order_by('-id')
        if vss :
            print(f"VSS = {vss}")
            vs = vss[0]
        else :
            vs = VectorStore(name=vsname)
            vs.save()
        vs.files.set(file_pks)
        logger.error(f"SAVED FILE_PKS {file_pks}")
        vs.save();
        logger.error(f"VS NAME = {vs.name}")
        vector_store_id = vs.get_vector_store_id()
        logger.error(f"VS VECTTOR_STORE_ID {vector_store_id}")
        instance.vector_stores.set([vs.pk])
        try :
            assistant = client.beta.assistants.update(
                assistant_id=assistant_id,
                tool_resources={"file_search": {"vector_store_ids": [ vector_store_id ] }},
                metadata={"api_key": settings.AI_KEY[-8:] } 
                )
        except Exception as e:
            logger.error(f"CLIENT CANNOT UPDATE ASSISTANT {str(e)}")

    print(f"SAVE {instance}")
    instance.save()
    print(f"SAVED {instance}")
    del instance._updating_from_m2m


DELETE_REMOTE_VECTOR_STORE_ON_EMPTY = False


@receiver(m2m_changed, sender=VectorStore.files.through)
def handle_files_changed(sender, instance, action, reverse, model, pk_set, **kwargs):
    logger.error(f"HANDLE_SENDER_VECTOR_STORE action={action}")
    if getattr(instance, '_updating_from_m2m', False):
        return
    client = OpenAIClient()
    if action in {"pre_add", "pre_remove", "pre_clear"}:
        instance._old_file_ids =  instance.file_ids() # [i[0] for i in instance.files.values_list('file_ids', flat=True)  ]
        instance._old_checksum = instance.get_checksum();
        pass

    elif action == "post_add" or action == 'post_remove' :
        old_file_ids  =  getattr(instance, '_old_file_ids', [] )
        old_checksum  =  getattr(instance, '_old_checksum', None);
        instance.checksum = instance.get_checksum();
        #new_file_ids =  [i[0] for i in  instance.files.values_list('file_ids', flat=True)  ]
        instance._updating_from_m2m = True
        instance.vsid = client.get_or_update_remote_vector_store( instance , old_checksum,old_file_ids)
        #instance.save(update_fields=['checksum','vsid']);
        instance.save();
        del instance._updating_from_m2m

def delete_remote_vector_stores():
    remote_vector_stores = RemoteVectorStore.objects.all();
    for remote_vector_store in remote_vector_stores :
        remote_vector_store.delete();

#def dump_remote_vector_stores_(s='') :
#    remote_vector_stores = RemoteVectorStore.objects.all();
#    logger.error(f"{s}\nvvvvvv")
#    for remote_vector_store in remote_vector_stores :
#        logger.error(f"REMOTE_VECTOR_STORE = cs={remote_vector_store.checksum} id={remote_vector_store.vector_store_id} pks={remote_vector_store.vector_stores_pks()}")
#    logger.error(f"^^^^^^")


