from sqlalchemy.engine.row import Row
from typing_extensions import TypeAlias

RowType: TypeAlias = Row
