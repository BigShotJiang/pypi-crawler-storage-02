# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)

from . import res_company
from . import res_config_settings
from . import product
from . import personal_income_tax
from . import withholding_tax_cert
from . import account
from . import account_move_tax_invoice
from . import account_move
from . import account_partial_reconcile
from . import account_payment
from . import account_withholding_tax
from . import account_withholding_move
from . import account_tax
from . import res_partner
