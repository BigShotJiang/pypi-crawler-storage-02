# SPDX-FileCopyrightText: 2024-present Peter Bowen <peter@bowenfamily.org>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.0"
