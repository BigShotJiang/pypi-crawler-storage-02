# Jupyterlab Italian (Italy) Language Pack

Italian (Italy) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-it-IT
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-it-IT
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
