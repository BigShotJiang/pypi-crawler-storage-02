# Contributors

* JupyterLab Bot ([@jupyterlab-bot](https://crowdin.com/profile/jupyterlab-bot))
* GiorgioHerbie ([@GiorgioHerbie](https://crowdin.com/profile/GiorgioHerbie))
* Steven Silvester ([@blink1073](https://crowdin.com/profile/blink1073))
* Roberto Panai ([@robertopanai](https://crowdin.com/profile/robertopanai))
* Giuseppe Cunsolo ([@giuseppecunsolo](https://crowdin.com/profile/giuseppecunsolo))
* Xemnas0 ([@Xemnas0](https://crowdin.com/profile/Xemnas0))
