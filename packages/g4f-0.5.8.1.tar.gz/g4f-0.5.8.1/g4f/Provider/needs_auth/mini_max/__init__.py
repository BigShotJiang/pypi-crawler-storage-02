from .HailuoAI import HailuoAI
from .MiniMax import MiniMax