#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Query Rewrite - A Python library for query rewriting using LLMs and other methods."""

__version__ = "0.1.0"
__author__ = "CrissChan"
__email__ = "can101208@gmail.com"