# Changelog

- Cardinality-adaptive reservoir; statistical guarantees unchanged.

