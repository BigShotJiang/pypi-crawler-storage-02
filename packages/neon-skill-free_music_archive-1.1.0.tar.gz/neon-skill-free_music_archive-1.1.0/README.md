# <img src='https://freemusicarchive.org/legacy/fma-smaller.jpg' card_color="#FF8600" width="50" style="vertical-align:center">Free Music Archive
## Summary
[OCP](https://github.com/OpenVoiceOS/ovos-ocp-audio-plugin) skill to play royalty free music
from [Free Music Archive](https://freemusicarchive.org/).

## Description
Search and play royalty free music from [Free Music Archive](https://freemusicarchive.org/).

## Examples
- Play jazz.
- Play classical music.
- Play electronic music.
- Play Mozart.

## Contact Support
Use the [link](https://neongecko.com/ContactUs) or [submit an issue on GitHub](https://help.github.com/en/articles/creating-an-issue)

## Credits

[NeonGeckoCom](https://github.com/NeonGeckoCom)
[NeonDaniel](https://github.com/NeonDaniel)

## Category
**Music**

## Tags
#music
#Royalty Free
#Free Music Archive
#NeonAI
#NeonGecko Original
#OCP
#Common Play