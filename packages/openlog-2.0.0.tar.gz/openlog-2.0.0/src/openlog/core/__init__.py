"""Core components for the OpenLog library."""
