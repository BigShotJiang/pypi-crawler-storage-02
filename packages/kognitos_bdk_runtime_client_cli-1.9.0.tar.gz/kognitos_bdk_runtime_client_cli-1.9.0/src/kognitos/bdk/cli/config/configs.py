DEFAULT_ENDPOINT = "lambda://bdk_library/2.6.3"
