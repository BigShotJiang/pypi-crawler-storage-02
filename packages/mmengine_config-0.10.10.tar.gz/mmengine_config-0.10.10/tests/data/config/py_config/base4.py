# Copyright (c) OpenMMLab. All rights reserved.
item5 = dict(a=0, b=1)
item6 = [dict(a=0), dict(b=1)]
item7 = dict(a=[0, 1, 2], b=dict(c=[3.1, 4.2, 5.3]))
