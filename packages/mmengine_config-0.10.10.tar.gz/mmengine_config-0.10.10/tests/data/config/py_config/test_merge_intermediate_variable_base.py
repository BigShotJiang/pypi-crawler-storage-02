# Copyright (c) OpenMMLab. All rights reserved.
item1 = [1, 2]
item2 = {'a': 0}
item3 = True
item4 = 'test'
item_cfg = {'b': 1}
item5 = {'cfg': item_cfg}
item6 = {'cfg': item_cfg}
