# Copyright (c) OpenMMLab. All rights reserved.
import os

os.environ['TEST_VALUE'] = 'test'
