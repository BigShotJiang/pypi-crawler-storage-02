# Copyright (c) OpenMMLab. All rights reserved.
_base_ = 'mmdet::faster_rcnn/faster-rcnn_r50_fpn_1x_coco.py'
