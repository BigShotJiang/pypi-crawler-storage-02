# Copyright (c) OpenMMLab. All rights reserved.
_base_ = [
    './base1.py',
    'simple_config.py'
]
item3 = False
item4 = 'test'
