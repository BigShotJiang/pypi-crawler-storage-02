# Copyright (c) OpenMMLab. All rights reserved.
test_int = 1
test_list = [1, 2, 3]
# include type, optimizer can be initiated by build_from_cfg
optimizer = dict(type='SGD', lr=0.1, momentum=0.9, weight_decay=0.0001)
