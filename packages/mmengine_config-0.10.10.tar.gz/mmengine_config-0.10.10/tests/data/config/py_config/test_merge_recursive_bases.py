# Copyright (c) OpenMMLab. All rights reserved.
_base_ = './test_merge_from_base_single.py'
item4 = 'test_recursive_bases'
