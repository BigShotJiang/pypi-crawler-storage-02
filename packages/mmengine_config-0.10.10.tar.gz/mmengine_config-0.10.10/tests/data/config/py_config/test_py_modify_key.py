# Copyright (c) OpenMMLab. All rights reserved.
# Support modify value in config.
item1 = dict()
item1['a'] = 1
