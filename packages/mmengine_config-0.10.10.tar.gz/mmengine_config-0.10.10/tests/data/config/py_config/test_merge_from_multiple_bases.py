# Copyright (c) OpenMMLab. All rights reserved.
_base_ = [
    './base1.py',
    './base4.py'
]
item3 = False
item4 = 'test'
item_bool = True
item_float = 1.0
