# Copyright (c) OpenMMLab. All rights reserved.
class A:
    ...

item_a = dict(a=A)
