# Copyright (c) OpenMMLab. All rights reserved.
_base_ = './test_merge_intermediate_variable_base.py'
item_cfg = {'b': 2}
item6 = {'cfg': item_cfg}
