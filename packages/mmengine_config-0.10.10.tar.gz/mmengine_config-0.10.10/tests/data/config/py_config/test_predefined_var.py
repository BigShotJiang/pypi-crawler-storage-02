# Copyright (c) OpenMMLab. All rights reserved.
item1 = '{{fileBasename}}'
item2 = '{{ fileDirname}}'
item3 = 'abc_{{ fileBasenameNoExtension }}'
