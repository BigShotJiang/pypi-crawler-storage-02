# Copyright (c) OpenMMLab. All rights reserved.
item = [{'a': 0}, {'b': 0, 'c': 0}]
