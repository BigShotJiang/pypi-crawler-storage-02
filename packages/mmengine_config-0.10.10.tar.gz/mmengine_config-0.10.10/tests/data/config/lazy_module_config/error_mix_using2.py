# Copyright (c) OpenMMLab. All rights reserved.
from mme.config import read_base

with read_base():
    from ...config.py_config.test_base_variables import *
