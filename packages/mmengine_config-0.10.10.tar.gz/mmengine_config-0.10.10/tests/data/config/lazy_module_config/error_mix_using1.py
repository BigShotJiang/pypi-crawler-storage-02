# Copyright (c) OpenMMLab. All rights reserved.
_base_ = './error_mix_using3.py'
