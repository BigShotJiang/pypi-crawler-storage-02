x = 1
y = (2, 3)
z = "hello"
dict_x = {"x": x, "y": y}
dict_y = dict(x=dict_x)
