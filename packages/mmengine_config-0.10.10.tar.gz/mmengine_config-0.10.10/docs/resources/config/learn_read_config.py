test_int = 1
test_list = [1, 2, 3]
test_dict = dict(key1='value1', key2=0.1)
