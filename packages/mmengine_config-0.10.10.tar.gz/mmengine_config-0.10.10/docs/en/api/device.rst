.. role:: hidden
    :class: hidden-section

mmengine.device
===================================

.. currentmodule:: mmengine.device

.. autosummary::
   :toctree: generated
   :nosignatures:

   get_device
   get_max_cuda_memory
   is_cuda_available
   is_npu_available
   is_mlu_available
   is_mps_available
