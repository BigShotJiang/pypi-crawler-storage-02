# Copyright (c) OpenMMLab. All rights reserved.

from .config import Config, DictAction

__version__ = "0.10.10"

__all__ = ["Config", "DictAction"]
