Built-in Filters
================

.. autoclass:: webgrid.filters.TextFilter
    :members:

.. autoclass:: webgrid.filters.IntFilter
    :members:

.. autoclass:: webgrid.filters.AggregateIntFilter
    :members:

.. autoclass:: webgrid.filters.NumberFilter
    :members:

.. autoclass:: webgrid.filters.AggregateNumberFilter
    :members:

.. autoclass:: webgrid.filters.DateFilter
    :members:

.. autoclass:: webgrid.filters.DateTimeFilter
    :members:

.. autoclass:: webgrid.filters.TimeFilter
    :members:

.. autoclass:: webgrid.filters.YesNoFilter
    :members:

.. autoclass:: webgrid.filters.OptionsEnumFilter
    :members:
