Built-in Specialized Columns
============================

.. autoclass:: webgrid.LinkColumnBase
    :members:

.. autoclass:: webgrid.BoolColumn
    :members:

.. autoclass:: webgrid.YesNoColumn
    :members:

.. autoclass:: webgrid.DateColumnBase
    :members:

.. autoclass:: webgrid.DateColumn
    :members:

.. autoclass:: webgrid.DateTimeColumn
    :members:

.. autoclass:: webgrid.TimeColumn
    :members:

.. autoclass:: webgrid.NumericColumn
    :members:

.. autoclass:: webgrid.EnumColumn
    :members:
