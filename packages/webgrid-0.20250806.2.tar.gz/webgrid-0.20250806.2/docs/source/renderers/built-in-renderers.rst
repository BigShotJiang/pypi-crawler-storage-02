Built-in Renderers
==================

.. autoclass:: webgrid.renderers.HTML
    :members:
    :inherited-members:

.. autoclass:: webgrid.renderers.JSON
    :members:
    :inherited-members:

.. autoclass:: webgrid.renderers.XLSX
    :members:
    :inherited-members:

.. autoclass:: webgrid.renderers.CSV
    :members:
    :inherited-members:
