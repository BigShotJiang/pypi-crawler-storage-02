# Copyright (C) 2025 Embedl AB

from setuptools import setup

setup()
