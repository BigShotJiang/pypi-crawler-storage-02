from .base import TradeXRocketObject


class LastTradesResponse(TradeXRocketObject):
    success: bool
    """Indicate if request is successful"""
