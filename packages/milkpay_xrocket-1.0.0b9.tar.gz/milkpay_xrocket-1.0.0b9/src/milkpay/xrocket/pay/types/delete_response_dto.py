from .base import PayXRocketObject


class DeleteResponseDto(PayXRocketObject):
    success: bool
