"""
Definition of the various Classes and in which Modules they may be found.
"""

from .waxdata import WaxData
