"""
Contains all basic block functions for leafwaxtools
"""

from .validate_data import *
