"""Markdown Mermaid Data URI extension."""

from .extension import MermaidExtension, makeExtension

__all__ = ['MermaidExtension', 'makeExtension']
