# Copyright (c) 2024, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid files namespace

"""

from .app import files_app

__all__ = ["files_app"]
