# Copyright (c) 2024, qBraid Development Team
# All rights reserved.

"""
Module defining the qbraid account namespace

"""

from .app import account_app

__all__ = ["account_app"]
