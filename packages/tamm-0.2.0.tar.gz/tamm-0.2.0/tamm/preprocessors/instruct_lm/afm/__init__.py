from tamm.preprocessors.instruct_lm.afm.afm_v6 import AFMChatTemplateV6Preprocessor

__all__ = [
    "AFMChatTemplateV6Preprocessor",
]
