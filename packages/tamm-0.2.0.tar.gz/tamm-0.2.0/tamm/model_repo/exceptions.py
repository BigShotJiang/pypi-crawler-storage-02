class UnrecognizedModelIdentifierError(Exception):
    """
    Raise when ModelRepo cannot handle model identifier
    """
