"""
This module enables usage of tamm models in the Hugging Face ecosystem.
"""
