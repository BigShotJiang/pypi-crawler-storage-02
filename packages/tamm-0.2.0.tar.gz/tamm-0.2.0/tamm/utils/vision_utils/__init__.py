from tamm.utils.vision_utils._load import load_image
