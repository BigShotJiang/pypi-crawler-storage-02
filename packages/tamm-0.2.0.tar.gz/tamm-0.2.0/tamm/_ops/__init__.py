"""
Operators
=========

.. autofunction:: tamm._ops.segment_matmul

"""
from tamm._ops.segment_matmul import segment_matmul

__all__ = [
    "segment_matmul",
]
