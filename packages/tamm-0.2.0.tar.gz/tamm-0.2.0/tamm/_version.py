"""
Provides the tamm version string
"""

__version__ = "0.2.0"
