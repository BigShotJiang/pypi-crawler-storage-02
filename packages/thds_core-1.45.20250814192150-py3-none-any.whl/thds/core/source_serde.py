# deprecated alias for source.serde
from .source.serde import from_json, from_unknown_user_path, to_json, write_to_json_file  # noqa: F401
