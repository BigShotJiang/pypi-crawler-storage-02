from mcp_seniverse_weather_demo import main

main()