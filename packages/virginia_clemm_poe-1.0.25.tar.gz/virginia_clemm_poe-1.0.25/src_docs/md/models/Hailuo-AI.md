# [Hailuo-AI](https://poe.com/Hailuo-AI){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Video Output | 14167 points / message |
| Initial Points Cost | Variable points |

**Last Checked:** 2025-08-05 23:26:03.811511


## Bot Information

**Creator:** @fal

**Description:** Best-in-class text and image to video model by MiniMax.

**Extra:** Powered by a server managed by @fal. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** video

**Modality:** text->video


## Technical Details

**Model ID:** `Hailuo-AI`

**Object Type:** model

**Created:** 1729194728486

**Owned By:** poe

**Root:** Hailuo-AI
