# this_file: src/virginia_clemm_poe/utils/__init__.py
"""Utilities package for Virginia Clemm Poe.

This package provides shared utilities following the PlaywrightAuthor
architecture pattern.
"""
