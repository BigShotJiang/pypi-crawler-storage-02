class GatewayError(Exception):
    """Base exception for gateway errors."""
    pass
