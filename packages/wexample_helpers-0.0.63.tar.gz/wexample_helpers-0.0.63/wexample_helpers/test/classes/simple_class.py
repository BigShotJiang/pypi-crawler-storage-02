class SimpleClass:
    def __init__(self, name="default"):
        self.name = name
