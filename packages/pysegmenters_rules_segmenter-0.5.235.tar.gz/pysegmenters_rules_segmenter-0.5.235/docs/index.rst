.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Contents:

   CHANGELOG
   reference/pysegmenters_rules_segmenter
