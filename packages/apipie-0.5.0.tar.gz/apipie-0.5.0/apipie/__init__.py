"""
apipie - A simple API proxy with rate limiting and API key support.
"""

__version__ = "0.4.4"
__author__ = "kokorocks"

# Optionally expose your main entry point here
from .main import main
