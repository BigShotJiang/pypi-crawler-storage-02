![image](./media/apipielogo.svg)

ever wished that apis where easy to use, ever wished that private apis could be used publicly, ever wished you could force people to not ddos attack you again, well this is (somewhat) the perfect thing for you