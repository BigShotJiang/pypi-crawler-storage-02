[documentation]: https://icostate.readthedocs.io

[![API Documentation](https://img.shields.io/readthedocs/icostate?label=Documentation)][documentation]

Please take a look at the [documentation][] for more information.
