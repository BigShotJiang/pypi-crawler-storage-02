# yxmb_compatlib
支持原地升级的宇信慢病兼容库
