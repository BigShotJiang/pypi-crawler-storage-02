from platformdirs import user_cache_dir

CACHE_DIR = user_cache_dir("mobisurvstd")
