#
# Root of the sodium-ion models module.
#
from .basic_dfn import BasicDFN

__all__ = ['basic_dfn']
