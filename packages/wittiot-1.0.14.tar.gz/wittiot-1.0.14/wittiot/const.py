"""Define package constants."""
import logging

LOGGER = logging.getLogger(__package__)

DEFAULT_API_VERSION = 1


