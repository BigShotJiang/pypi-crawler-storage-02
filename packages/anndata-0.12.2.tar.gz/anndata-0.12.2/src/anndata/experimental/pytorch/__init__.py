from __future__ import annotations

from ._annloader import AnnLoader

__all__ = ["AnnLoader"]
