.. sidebar:: Key Contributors

   * `Isaac Virshup`_: anndata >= 0.7, diverse contributions
   * Sergei Rybakov: diverse contributions
   * `Alex Wolf`_: initial conception/development
   * Philipp Angerer: initial conception/development, software quality

.. _contributions graph: https://github.com/scverse/anndata/graphs/contributors
.. _Isaac Virshup: https://twitter.com/ivirshup
.. _Alex Wolf: https://twitter.com/falexwolf
