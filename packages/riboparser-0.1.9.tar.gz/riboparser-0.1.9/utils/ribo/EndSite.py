#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@Project      : RiboParser
@Script       : EndSite.py
@Environment  : python 3.12
@Version      : 1.0
@Author       : Rensc
@Time         : 2025/06/09 10:56:32
@E-mail       : rensc0718@163.com
@License      : (C)Copyright 2023-2025, Ren Shuchao
'''


# import pandas as pd
# import polars as pl
# import numpy as np
# from collections import OrderedDict
# from Bio import SeqIO
# import argparse
