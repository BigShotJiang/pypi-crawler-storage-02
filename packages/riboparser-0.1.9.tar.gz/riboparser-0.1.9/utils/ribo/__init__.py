#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @time    : 2021/4/19 8:29
# @Project : riboParser
# @Author  : Rensc
# @E-mail  : rensc0718@163.com
