from importlib.metadata import version

__package_name__ = "hafnia"
__version__ = version(__package_name__)
