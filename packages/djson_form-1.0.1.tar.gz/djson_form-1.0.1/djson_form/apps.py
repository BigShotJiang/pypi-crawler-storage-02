from django.apps import AppConfig


class DjangoFormgenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djson_form'
