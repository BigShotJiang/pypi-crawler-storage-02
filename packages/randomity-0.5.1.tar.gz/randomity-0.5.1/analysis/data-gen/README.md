## Data Generation

This directory contains scripts for generating random number sequences using various algorithms and approaches. The generated data can be accessed through the [data](/analysis/data/) directory.