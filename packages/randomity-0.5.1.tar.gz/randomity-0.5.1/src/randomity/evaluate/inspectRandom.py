def inspectRandom(sequence):
    """
    Returns a report, scoring different aspects of the randomness of a given number sequence.
    """
    # TODO