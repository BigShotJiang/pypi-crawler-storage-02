## `randomity` source

In this directory you can find the main functions of the [randomity](https://pypi.org/project/randomity/) package: [generate](/src/randomity/generate/) and [evaluate](/src/randomity/evaluate/).