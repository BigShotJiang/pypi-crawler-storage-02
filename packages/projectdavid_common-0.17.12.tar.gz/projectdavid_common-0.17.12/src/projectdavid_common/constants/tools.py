PLATFORM_TOOLS = [
    "code_interpreter",
    "web_search",
    "vector_store_search",
    "computer",
    "file_search",
]

TOOLS_ID_MAP = {
    "code_interpreter": "tool_79YkQEz5cDwpJjnR7oJ80D",
    "web_search": "tool_BiIwycpLo1n5Dh6BHN01v8",
    "vector_store_search": "tool_MCaJpXJU3eW6vaMUybEf6i",
    "computer": "tool_PJQ6VcnkmRCMankObjtRcn",
}

SPECIAL_CASE_TOOL_HANDLING = ["computer", "code_interpreter"]
