FORMAT_MAP = {
    'class': 'campaign_class',
    'billing_cycle': 'bc_inferred',
    'creditCardType': 'cc_type',
    'cc_first_8': 'iin',
    'cc_first_6': 'iin'
}