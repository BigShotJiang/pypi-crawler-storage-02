"""End-to-end CLI command tests for Lackey."""
