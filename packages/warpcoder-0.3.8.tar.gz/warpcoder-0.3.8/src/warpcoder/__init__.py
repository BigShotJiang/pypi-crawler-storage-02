"""
WarpCoder - Universal BDD Project Generator for Claude Code
"""

__version__ = "0.3.8"
__author__ = "Warpcoders LLC"
__email__ = "starshipagentic@gmail.com"

from .main import main

__all__ = ["main"]