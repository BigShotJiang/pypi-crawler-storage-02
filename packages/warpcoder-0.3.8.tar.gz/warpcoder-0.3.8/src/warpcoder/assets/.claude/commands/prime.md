# Context Window Prime

RUN:
    git ls-files

READ:
    README.md
    ai_docs/claude_code_fresh_tutorials.md