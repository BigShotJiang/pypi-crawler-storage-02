"""Utils for Python code reflection."""
