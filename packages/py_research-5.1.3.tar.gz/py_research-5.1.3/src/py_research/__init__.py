"""Collection of utilities for R&D coding in Python."""
