# flake8: noqa

# These have to be synced with the stdlib.pxi
import asyncio
import collections
import concurrent.futures
import errno
import functools
import gc
import inspect
import itertools
import os
import signal
import socket
import ssl
import stat
import subprocess
import sys
import threading
import time
import traceback
import warnings
import weakref
