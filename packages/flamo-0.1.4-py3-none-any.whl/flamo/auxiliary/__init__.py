from .minimize import * 
from .eq import *