- Guewen Baconnier \<<guewen.baconnier@camptocamp.com>\>
- Simone Orsi \<<simahawk@gmail.com>\>
- Sébastien Alix \<<sebastien.alix@camptocamp.com>\>
- Alexandre Fayolle \<<alexandre.fayolle@camptocamp.com>\>
- Benoit Guillot \<<benoit.guillot@akretion.com>\>
- Thierry Ducrest \<<thierry.ducrest@camptocamp.com>\>
- Michael Tietz (MT Software) \<<mtietz@mt-software.de>\>
- Denis Roussel \<<denis.roussel@acsone.eu\>
- Laurent Mignon \<<laurent.mignon@acsone.eu\>

## Design

- Joël Grand-Guillaume \<<joel.grandguillaume@camptocamp.com>\>
- Jacques-Etienne Baudoux \<<je@bcim.be>\>
