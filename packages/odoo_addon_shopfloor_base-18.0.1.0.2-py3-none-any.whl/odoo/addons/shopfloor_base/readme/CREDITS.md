**Financial support**

- Cosanum
- Camptocamp R&D
- Akretion R&D
- ACSONE R&D

**Icons**

- Tablet app icon by Gregor Cresnar from the Noun Project
