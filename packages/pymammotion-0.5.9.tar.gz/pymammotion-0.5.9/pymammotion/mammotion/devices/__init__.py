"""mqtt init."""

from .mammotion import MammotionBaseBLEDevice

__all__ = ["MammotionBaseBLEDevice"]
