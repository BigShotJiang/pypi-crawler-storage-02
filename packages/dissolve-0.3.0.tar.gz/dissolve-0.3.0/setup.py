#!/usr/bin/env python3
"""Simple setup script for dissolve Python package."""

from setuptools import setup

setup()
