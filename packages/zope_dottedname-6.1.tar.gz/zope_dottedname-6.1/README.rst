``zope.dottedname``
===================
    
.. image:: https://img.shields.io/pypi/v/zope.dottedname.svg
        :target: https://pypi.python.org/pypi/zope.dottedname/
        :alt: Latest release

.. image:: https://github.com/zopefoundation/zope.dottedname/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.dottedname/actions/workflows/tests.yml

.. image:: https://readthedocs.org/projects/zopedottedname/badge/?version=latest
        :target: http://zopedottedname.readthedocs.org/en/latest/
        :alt: Documentation Status

Resolve strings containing dotted names into the appropriate Python object.

- `Read documentation <https://zopedottedname.readthedocs.io/>`__
