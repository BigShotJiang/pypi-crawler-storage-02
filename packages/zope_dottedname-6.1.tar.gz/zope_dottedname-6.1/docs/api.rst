:mod:`zope.dottedname` API
==========================

.. automodule:: zope.dottedname.resolve
   
   .. autofunction:: resolve

