from malduck.extractor import Extractor

__author__ = "doomedraven"
__version__ = "1.0.0"


class TEST_MALDUCK(Extractor):
    """
    TEST Configuration Extractor
    """

    family = "TEST_MALDUCK"

    def TEST_MALDUCK(self):
        pass
