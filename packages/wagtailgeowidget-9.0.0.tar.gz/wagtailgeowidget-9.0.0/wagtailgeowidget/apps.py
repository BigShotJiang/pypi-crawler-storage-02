from django.apps import AppConfig


class WagtailgeowidgetConfig(AppConfig):
    name = "wagtailgeowidget"
