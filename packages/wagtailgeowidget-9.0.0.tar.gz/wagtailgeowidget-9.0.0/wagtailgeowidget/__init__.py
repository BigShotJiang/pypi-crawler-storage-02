#!/usr/bin/env python

"""
wagtailgeowidget
----------
Wagtail-Geo-Widget is the complete map solution for your Wagtail site.
"""

__title__ = "wagtailgeowidget"
__version__ = "9.0.0"
__build__ = 900
__author__ = "Martin Sandström"
__license__ = "MIT"
__copyright__ = "Copyright 2015-Present Fröjd Interactive"
