from typing import Dict

EMBEDDING_HANDLE_OVERRIDES: Dict[str, Dict[str, str]] = {}
