DEFAULT_AA_GAP_CHARS = ["-", "?", "*", "X", "x"]
DEFAULT_NT_GAP_CHARS = ["-", "?", "*", "X", "x", "N", "n"]
