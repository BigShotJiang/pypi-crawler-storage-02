"""clipkit.__main__: executed when clipkit is called as script"""
import sys

from .clipkit import main

main(sys.argv[1:])
