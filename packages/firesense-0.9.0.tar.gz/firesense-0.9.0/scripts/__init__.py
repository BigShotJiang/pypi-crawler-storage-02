"""Scripts package for Gemma 3N project utilities."""
