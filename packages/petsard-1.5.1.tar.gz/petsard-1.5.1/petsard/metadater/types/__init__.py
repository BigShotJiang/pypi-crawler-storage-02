"""Core type definitions"""

from petsard.metadater.types.data_types import DataType, LogicalType

__all__ = [
    "DataType",
    "LogicalType",
]
