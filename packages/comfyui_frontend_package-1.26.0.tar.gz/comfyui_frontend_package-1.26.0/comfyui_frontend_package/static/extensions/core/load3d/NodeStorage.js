// Shim for extensions/core/load3d/NodeStorage.ts
export const NodeStorage = window.comfyAPI.NodeStorage.NodeStorage;
