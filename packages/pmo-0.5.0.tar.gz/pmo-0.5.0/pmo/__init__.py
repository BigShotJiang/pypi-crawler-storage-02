"""
PMO - A simple process management tool.
"""

__version__ = "0.1.0"