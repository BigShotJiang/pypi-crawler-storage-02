# AirChat

![PyPI version](https://img.shields.io/pypi/v/airchat.svg)
[![Documentation Status](https://readthedocs.org/projects/airchat/badge/?version=latest)](https://airchat.readthedocs.io/en/latest/?version=latest)

A sample chat app for Air

* PyPI package: https://pypi.org/project/airchat/
* Free software: MIT License
* Documentation: https://airchat.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
