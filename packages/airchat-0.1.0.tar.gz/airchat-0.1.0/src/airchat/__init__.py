"""Top-level package for AirChat."""

__author__ = """Daniel Roy Greenfeld"""
__email__ = 'daniel@feldroy.com'
