# Usage

To use AirChat in a project:

```python
import airchat
```
