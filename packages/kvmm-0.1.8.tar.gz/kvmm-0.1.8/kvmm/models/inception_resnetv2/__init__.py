from kvmm.models.inception_resnetv2.inceptionresnetv2_model import (
    InceptionResNetV2,
)
