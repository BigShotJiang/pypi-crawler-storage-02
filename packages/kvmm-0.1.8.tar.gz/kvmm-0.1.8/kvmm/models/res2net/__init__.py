from kvmm.models.res2net.res2net_model import (
    Res2Net50_14w_8s,
    Res2Net50_26w_4s,
    Res2Net50_26w_6s,
    Res2Net50_26w_8s,
    Res2Net50_48w_2s,
    Res2Net101_26w_4s,
)
