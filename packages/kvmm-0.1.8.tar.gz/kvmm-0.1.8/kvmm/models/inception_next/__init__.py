from kvmm.models.inception_next.inception_next_model import (
    InceptionNeXtAtto,
    InceptionNeXtBase,
    InceptionNeXtSmall,
    InceptionNeXtTiny,
)
