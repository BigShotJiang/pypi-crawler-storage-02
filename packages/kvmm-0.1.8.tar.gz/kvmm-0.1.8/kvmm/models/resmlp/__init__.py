from kvmm.models.resmlp.resmlp_model import (
    ResMLP12,
    ResMLP24,
    ResMLP36,
    ResMLPBig24,
)
