from kvmm.models.mobilenetv2.mobilenetv2_model import (
    MobileNetV2WM50,
    MobileNetV2WM100,
    MobileNetV2WM110,
    MobileNetV2WM120,
    MobileNetV2WM140,
)
