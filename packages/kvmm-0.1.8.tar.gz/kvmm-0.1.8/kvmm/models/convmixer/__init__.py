from kvmm.models.convmixer.convmixer_model import (
    ConvMixer768D32,
    ConvMixer1024D20,
    ConvMixer1536D20,
)
