from kvmm.models.resnext.resnext_model import (
    ResNeXt50_32x4d,
    ResNeXt101_32x4d,
    ResNeXt101_32x8d,
    ResNeXt101_32x16d,
    ResNeXt101_32x32d,
)
