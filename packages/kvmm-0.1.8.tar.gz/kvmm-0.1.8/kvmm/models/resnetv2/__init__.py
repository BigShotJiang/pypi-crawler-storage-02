from kvmm.models.resnetv2.resnetv2_model import (
    ResNetV2_50x1,
    ResNetV2_50x3,
    ResNetV2_101x1,
    ResNetV2_101x3,
    ResNetV2_152x2,
    ResNetV2_152x4,
)
