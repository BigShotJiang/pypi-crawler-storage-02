from kvmm.models.deit.deit_model import (
    DEiT3Base16,
    DEiT3Huge14,
    DEiT3Large16,
    DEiT3Medium16,
    DEiT3Small16,
    DEiTBase16,
    DEiTBaseDistilled16,
    DEiTSmall16,
    DEiTSmallDistilled16,
    DEiTTiny16,
    DEiTTinyDistilled16,
)
