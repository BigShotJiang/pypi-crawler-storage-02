__version__ = "0.1.8"


def version():
    return __version__
