"""Jaclang Overriden Cores."""
