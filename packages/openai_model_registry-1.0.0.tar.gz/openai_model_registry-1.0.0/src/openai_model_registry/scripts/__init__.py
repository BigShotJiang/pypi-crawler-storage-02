"""Scripts for the openai-model-registry package."""
