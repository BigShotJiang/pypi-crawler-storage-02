"""Configuration files for the model registry."""
