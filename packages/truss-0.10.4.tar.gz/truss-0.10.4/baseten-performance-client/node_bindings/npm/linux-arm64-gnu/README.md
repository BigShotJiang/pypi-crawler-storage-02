# `@basetenlabs/performance-client-linux-arm64-gnu`

This is the **aarch64-unknown-linux-gnu** binary for `@basetenlabs/performance-client`
