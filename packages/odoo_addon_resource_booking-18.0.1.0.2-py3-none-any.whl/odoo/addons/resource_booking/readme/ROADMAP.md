- Allow combination auto-assignment based on least used combination.
- Allow customer to choose combination.
- Some error messages would be a bit more helpful if they specify the
  schedule impossibility reason, but that should be done without
  affecting performance.
- Optimize `_calendar_event_busy_intervals()` to make it work in batch.
