import {PortalHomeCounters} from "@portal/js/portal";

PortalHomeCounters.include({
    /**
     * @override
     */
    _getCountersAlwaysDisplayed() {
        return this._super(...arguments).concat(["booking_count"]);
    },
});
