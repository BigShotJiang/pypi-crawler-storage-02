# version
__version__ = '2025.8.13.1.0'

# global import attribute
__all__ = ['__version__']