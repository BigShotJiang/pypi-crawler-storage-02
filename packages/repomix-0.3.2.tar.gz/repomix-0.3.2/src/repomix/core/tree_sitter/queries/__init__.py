"""Tree-sitter queries for different programming languages."""
