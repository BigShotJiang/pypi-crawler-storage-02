"""Tree-sitter integration module for code compression and parsing."""
