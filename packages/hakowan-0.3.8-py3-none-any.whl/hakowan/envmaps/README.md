## Environment maps

This page documents the author, source and license for each environment maps in this folder.

| name | Author | Source | License |
|------|--------|--------|---------|
| museum | Bernhard Vogl | http://dativ.at/lightprobes/20060807_wells6_hd.jpg | Free, non-commercial |
