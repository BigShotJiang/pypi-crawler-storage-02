""" Hakowan-specific exceptions. """


class InvalidSetting(Exception):
    """Invalid setting or combination of visualization."""
