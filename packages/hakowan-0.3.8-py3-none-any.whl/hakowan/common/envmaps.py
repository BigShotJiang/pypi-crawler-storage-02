from pathlib import Path

envmaps_dir = Path(__file__).parents[1] / "envmaps"

envmaps = {
    "museum": envmaps_dir / "museum.exr",
}
