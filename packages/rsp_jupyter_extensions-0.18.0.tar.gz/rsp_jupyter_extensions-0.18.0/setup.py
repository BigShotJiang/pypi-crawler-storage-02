"""cf. pyproject.toml."""

__import__("setuptools").setup()
