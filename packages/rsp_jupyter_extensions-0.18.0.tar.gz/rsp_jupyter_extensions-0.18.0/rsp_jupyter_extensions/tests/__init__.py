"""Python unit tests for rsp_jupyter_extensions."""
