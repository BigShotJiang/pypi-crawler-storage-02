[![Build Status](https://github.com/y-crdt/pycrdt/actions/workflows/test.yml/badge.svg?query=branch%3Amain++)](https://github.com/y-crdt/pycrdt/actions/workflows/test.yml/badge.svg?query=branch%3Amain++)
[![Code Coverage](https://img.shields.io/badge/coverage-100%25-green)](https://img.shields.io/badge/coverage-100%25-green)

# pycrdt

CRDTs based on [Yrs](https://github.com/y-crdt/y-crdt/tree/main/yrs).

Documentation is available [here](https://y-crdt.github.io/pycrdt).
