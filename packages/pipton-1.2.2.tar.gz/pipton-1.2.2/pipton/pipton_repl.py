from pipton.repl import start_repl

if __name__ == "__main__":
    start_repl()
