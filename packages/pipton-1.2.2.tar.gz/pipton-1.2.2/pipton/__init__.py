__version__ = "1.0.0"
__author__ = "Amirhossein Khazaei"
__email__ = "amirhossinpython03@gmail.com"
__license__ = "MIT"
