# cocorum.servicephp

The primary use from this module is the `ServicePHP` class, a wrapper for Rumble's internal service.php API. Login is performed via this API, as well as most Rumble functions other than chat messaging and video upload.
All other classes are supporting sub-classes.

::: cocorum.servicephp

S.D.G.
