# cocorum.utils

This module provides various functions that stand by themselves and are used by a lot of different classes in the package.
While most of these functions aren't usually meant to be used directly, you might find some of them handy. At least one function is not currently used by the rest of the package at all, but I figured it might be useful in the future.

::: cocorum.utils

S.D.G.
