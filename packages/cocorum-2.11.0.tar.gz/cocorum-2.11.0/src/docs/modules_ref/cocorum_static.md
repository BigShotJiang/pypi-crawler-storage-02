# cocorum.static

This module provides static global data for use across the package, organized as class attributes. You may very well find a lot of these values useful directly as well.

::: cocorum.static

S.D.G.
