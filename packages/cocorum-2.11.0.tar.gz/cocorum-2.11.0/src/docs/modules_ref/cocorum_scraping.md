# cocorum.scraping

The primary use from this module is the `Scraper` class, used for getting data from Rumble web pages, or iun the rare case where HTML is passed by one of the APIs' endpoints. You must first create an instance of `cocorum.servicephp.ServicePHP()`, and then pass it to this class upon initialization.
All other classes are supporting sub-classes.

::: cocorum.scraping

S.D.G.
