import { I as f } from "./Index-DTyJKQrk.js";
export {
  f as default
};
