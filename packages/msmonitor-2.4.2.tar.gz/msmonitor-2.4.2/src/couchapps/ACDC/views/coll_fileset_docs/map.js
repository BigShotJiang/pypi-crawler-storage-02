function(doc) {
  emit([doc.collection_name, doc.fileset_name], null);
}