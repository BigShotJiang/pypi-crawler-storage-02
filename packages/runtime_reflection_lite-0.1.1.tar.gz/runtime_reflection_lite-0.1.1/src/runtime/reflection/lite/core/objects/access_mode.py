from enum import Enum

class AccessMode(Enum):
    PUBLIC = 1
    PROTECTED = 2
    PRIVATE = 3