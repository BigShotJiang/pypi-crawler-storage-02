var Uo = Object.defineProperty;
var wa = (a) => {
  throw TypeError(a);
};
var Go = (a, e, t) => e in a ? Uo(a, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : a[e] = t;
var J = (a, e, t) => Go(a, typeof e != "symbol" ? e + "" : e, t), Vo = (a, e, t) => e.has(a) || wa("Cannot " + t);
var ya = (a, e, t) => e.has(a) ? wa("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(a) : e.set(a, t);
var vn = (a, e, t) => (Vo(a, e, "access private method"), t);
function Gi() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let St = Gi();
function Hl(a) {
  St = a;
}
const Ul = /[&<>"']/, jo = new RegExp(Ul.source, "g"), Gl = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Wo = new RegExp(Gl.source, "g"), Zo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ka = (a) => Zo[a];
function Re(a, e) {
  if (e) {
    if (Ul.test(a))
      return a.replace(jo, ka);
  } else if (Gl.test(a))
    return a.replace(Wo, ka);
  return a;
}
const Yo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Xo(a) {
  return a.replace(Yo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Ko = /(^|[^\[])\^/g;
function K(a, e) {
  let t = typeof a == "string" ? a : a.source;
  e = e || "";
  const n = {
    replace: (i, l) => {
      let o = typeof l == "string" ? l : l.source;
      return o = o.replace(Ko, "$1"), t = t.replace(i, o), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function $a(a) {
  try {
    a = encodeURI(a).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return a;
}
const tn = { exec: () => null };
function Fa(a, e) {
  const t = a.replace(/\|/g, (l, o, r) => {
    let s = !1, u = o;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function bn(a, e, t) {
  const n = a.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && a.charAt(n - i - 1) === e; )
    i++;
  return a.slice(0, n - i);
}
function Qo(a, e) {
  if (a.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < a.length; n++)
    if (a[n] === "\\")
      n++;
    else if (a[n] === e[0])
      t++;
    else if (a[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Ea(a, e, t, n) {
  const i = e.href, l = e.title ? Re(e.title) : null, o = a[1].replace(/\\([\[\]])/g, "$1");
  if (a[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: i,
      title: l,
      text: o,
      tokens: n.inlineTokens(o)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: l,
    text: Re(o)
  };
}
function Jo(a, e) {
  const t = a.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const l = i.match(/^\s+/);
    if (l === null)
      return i;
    const [o] = l;
    return o.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class Mn {
  // set by the lexer
  constructor(e) {
    J(this, "options");
    J(this, "rules");
    // set by the lexer
    J(this, "lexer");
    this.options = e || St;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : bn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = Jo(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = bn(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = bn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const l = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: l,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, l = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const o = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = o.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let f = t[2].split(`
`, 1)[0].replace(/^\t+/, ($) => " ".repeat(3 * $.length)), d = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, s = f.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, s = f.slice(h), h += t[1].length);
        let p = !1;
        if (!f && /^ *$/.test(d) && (r += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const $ = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), g = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), D = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const y = e.split(`
`, 1)[0];
            if (d = y, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || D.test(d) || $.test(d) || g.test(e))
              break;
            if (d.search(/[^ ]/) >= h || !d.trim())
              s += `
` + d.slice(h);
            else {
              if (p || f.search(/[^ ]/) >= 4 || _.test(f) || D.test(f) || g.test(f))
                break;
              s += `
` + d;
            }
            !p && !d.trim() && (p = !0), r += y + `
`, e = e.substring(y.length + 1), f = d.slice(h);
          }
        }
        l.loose || (u ? l.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let b = null, v;
        this.options.gfm && (b = /^\[[ xX]\] /.exec(s), b && (v = b[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), l.items.push({
          type: "list_item",
          raw: r,
          task: !!b,
          checked: v,
          loose: !1,
          text: s,
          tokens: []
        }), l.raw += r;
      }
      l.items[l.items.length - 1].raw = r.trimEnd(), l.items[l.items.length - 1].text = s.trimEnd(), l.raw = l.raw.trimEnd();
      for (let c = 0; c < l.items.length; c++)
        if (this.lexer.state.top = !1, l.items[c].tokens = this.lexer.blockTokens(l.items[c].text, []), !l.loose) {
          const f = l.items[c].tokens.filter((h) => h.type === "space"), d = f.length > 0 && f.some((h) => /\n.*\n/.test(h.raw));
          l.loose = d;
        }
      if (l.loose)
        for (let c = 0; c < l.items.length; c++)
          l.items[c].loose = !0;
      return l;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", l = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: l
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Fa(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), l = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const r of i)
        /^ *-+: *$/.test(r) ? o.align.push("right") : /^ *:-+: *$/.test(r) ? o.align.push("center") : /^ *:-+ *$/.test(r) ? o.align.push("left") : o.align.push(null);
      for (const r of n)
        o.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of l)
        o.rows.push(Fa(r, o.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return o;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Re(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const o = bn(n.slice(0, -1), "\\");
        if ((n.length - o.length) % 2 === 0)
          return;
      } else {
        const o = Qo(t[2], "()");
        if (o > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + o;
          t[2] = t[2].substring(0, o), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], l = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        o && (i = o[1], l = o[3]);
      } else
        l = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), Ea(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: l && l.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), l = t[i.toLowerCase()];
      if (!l) {
        const o = n[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return Ea(n, l, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const o = [...i[0]].length - 1;
      let r, s, u = o, c = 0;
      const f = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (f.lastIndex = 0, t = t.slice(-1 * e.length + o); (i = f.exec(t)) != null; ) {
        if (r = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !r)
          continue;
        if (s = [...r].length, i[3] || i[4]) {
          u += s;
          continue;
        } else if ((i[5] || i[6]) && o % 3 && !((o + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...i[0]][0].length, h = e.slice(0, o + i.index + d + s);
        if (Math.min(o, s) % 2) {
          const b = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: b,
            tokens: this.lexer.inlineTokens(b)
          };
        }
        const p = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), l = /^ /.test(n) && / $/.test(n);
      return i && l && (n = n.substring(1, n.length - 1)), n = Re(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = Re(t[1]), i = "mailto:" + n) : (n = Re(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, l;
      if (t[2] === "@")
        i = Re(t[0]), l = "mailto:" + i;
      else {
        let o;
        do
          o = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (o !== t[0]);
        i = Re(t[0]), t[1] === "www." ? l = "http://" + t[0] : l = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: l,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Re(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const er = /^(?: *(?:\n|$))+/, tr = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, nr = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, cn = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, ir = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Vl = /(?:[*+-]|\d{1,9}[.)])/, jl = K(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Vl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Vi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ar = /^[^\n]+/, ji = /(?!\s*\])(?:\\.|[^\[\]\\])+/, lr = K(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", ji).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), or = K(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Vl).getRegex(), Wn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Wi = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, rr = K("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Wi).replace("tag", Wn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Wl = K(Vi).replace("hr", cn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Wn).getRegex(), sr = K(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Wl).getRegex(), Zi = {
  blockquote: sr,
  code: tr,
  def: lr,
  fences: nr,
  heading: ir,
  hr: cn,
  html: rr,
  lheading: jl,
  list: or,
  newline: er,
  paragraph: Wl,
  table: tn,
  text: ar
}, Ca = K("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", cn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Wn).getRegex(), ur = {
  ...Zi,
  table: Ca,
  paragraph: K(Vi).replace("hr", cn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Ca).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Wn).getRegex()
}, cr = {
  ...Zi,
  html: K(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Wi).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: tn,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: K(Vi).replace("hr", cn).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", jl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Zl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, _r = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Yl = /^( {2,}|\\)\n(?!\s*$)/, dr = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, _n = "\\p{P}\\p{S}", fr = K(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, _n).getRegex(), hr = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, pr = K(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, _n).getRegex(), mr = K("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, _n).getRegex(), gr = K("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, _n).getRegex(), vr = K(/\\([punct])/, "gu").replace(/punct/g, _n).getRegex(), br = K(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Dr = K(Wi).replace("(?:-->|$)", "-->").getRegex(), wr = K("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Dr).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Nn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, yr = K(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Nn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Xl = K(/^!?\[(label)\]\[(ref)\]/).replace("label", Nn).replace("ref", ji).getRegex(), Kl = K(/^!?\[(ref)\](?:\[\])?/).replace("ref", ji).getRegex(), kr = K("reflink|nolink(?!\\()", "g").replace("reflink", Xl).replace("nolink", Kl).getRegex(), Yi = {
  _backpedal: tn,
  // only used for GFM url
  anyPunctuation: vr,
  autolink: br,
  blockSkip: hr,
  br: Yl,
  code: _r,
  del: tn,
  emStrongLDelim: pr,
  emStrongRDelimAst: mr,
  emStrongRDelimUnd: gr,
  escape: Zl,
  link: yr,
  nolink: Kl,
  punctuation: fr,
  reflink: Xl,
  reflinkSearch: kr,
  tag: wr,
  text: dr,
  url: tn
}, $r = {
  ...Yi,
  link: K(/^!?\[(label)\]\((.*?)\)/).replace("label", Nn).getRegex(),
  reflink: K(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Nn).getRegex()
}, Si = {
  ...Yi,
  escape: K(Zl).replace("])", "~|])").getRegex(),
  url: K(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Fr = {
  ...Si,
  br: K(Yl).replace("{2,}", "*").getRegex(),
  text: K(Si.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Dn = {
  normal: Zi,
  gfm: ur,
  pedantic: cr
}, Zt = {
  normal: Yi,
  gfm: Si,
  breaks: Fr,
  pedantic: $r
};
class lt {
  constructor(e) {
    J(this, "tokens");
    J(this, "options");
    J(this, "state");
    J(this, "tokenizer");
    J(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || St, this.options.tokenizer = this.options.tokenizer || new Mn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Dn.normal,
      inline: Zt.normal
    };
    this.options.pedantic ? (t.block = Dn.pedantic, t.inline = Zt.pedantic) : this.options.gfm && (t.block = Dn.gfm, this.options.breaks ? t.inline = Zt.breaks : t.inline = Zt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Dn,
      inline: Zt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new lt(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new lt(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, i, l, o;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (l = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(l))) {
          i = t[t.length - 1], o && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), o = l.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, l, o = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, r.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, o, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const f = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((h) => {
            d = h.call({ lexer: this }, f), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (l = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(l)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Pn {
  constructor(e) {
    J(this, "options");
    this.options = e || St;
  }
  code(e, t, n) {
    var l;
    const i = (l = (t || "").match(/^\S*/)) == null ? void 0 : l[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + Re(i) + '">' + (n ? e : Re(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Re(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", l = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + l + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = $a(e);
    if (i === null)
      return n;
    e = i;
    let l = '<a href="' + e + '"';
    return t && (l += ' title="' + t + '"'), l += ">" + n + "</a>", l;
  }
  image(e, t, n) {
    const i = $a(e);
    if (i === null)
      return n;
    e = i;
    let l = `<img src="${e}" alt="${n}"`;
    return t && (l += ` title="${t}"`), l += ">", l;
  }
  text(e) {
    return e;
  }
}
class Xi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class ot {
  constructor(e) {
    J(this, "options");
    J(this, "renderer");
    J(this, "textRenderer");
    this.options = e || St, this.options.renderer = this.options.renderer || new Pn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Xi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new ot(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new ot(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const l = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const o = l, r = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          n += r || "";
          continue;
        }
      }
      switch (l.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = l;
          n += this.renderer.heading(this.parseInline(o.tokens), o.depth, Xo(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = l;
          n += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = l;
          let r = "", s = "";
          for (let c = 0; c < o.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(o.header[c].tokens), { header: !0, align: o.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < o.rows.length; c++) {
            const f = o.rows[c];
            s = "";
            for (let d = 0; d < f.length; d++)
              s += this.renderer.tablecell(this.parseInline(f[d].tokens), { header: !1, align: o.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const o = l, r = this.parse(o.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const o = l, r = o.ordered, s = o.start, u = o.loose;
          let c = "";
          for (let f = 0; f < o.items.length; f++) {
            const d = o.items[f], h = d.checked, p = d.task;
            let b = "";
            if (d.task) {
              const v = this.renderer.checkbox(!!h);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = v + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = v + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: v + " "
              }) : b += v + " ";
            }
            b += this.parse(d.tokens, u), c += this.renderer.listitem(b, p, !!h);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const o = l;
          n += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = l;
          n += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = l, r = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            o = e[++i], r += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const o = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const l = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(l.type)) {
          n += o || "";
          continue;
        }
      }
      switch (l.type) {
        case "escape": {
          const o = l;
          n += t.text(o.text);
          break;
        }
        case "html": {
          const o = l;
          n += t.html(o.text);
          break;
        }
        case "link": {
          const o = l;
          n += t.link(o.href, o.title, this.parseInline(o.tokens, t));
          break;
        }
        case "image": {
          const o = l;
          n += t.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = l;
          n += t.strong(this.parseInline(o.tokens, t));
          break;
        }
        case "em": {
          const o = l;
          n += t.em(this.parseInline(o.tokens, t));
          break;
        }
        case "codespan": {
          const o = l;
          n += t.codespan(o.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const o = l;
          n += t.del(this.parseInline(o.tokens, t));
          break;
        }
        case "text": {
          const o = l;
          n += t.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
}
class nn {
  constructor(e) {
    J(this, "options");
    this.options = e || St;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
J(nn, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var At, Ti, Ql;
class Er {
  constructor(...e) {
    ya(this, At);
    J(this, "defaults", Gi());
    J(this, "options", this.setOptions);
    J(this, "parse", vn(this, At, Ti).call(this, lt.lex, ot.parse));
    J(this, "parseInline", vn(this, At, Ti).call(this, lt.lexInline, ot.parseInline));
    J(this, "Parser", ot);
    J(this, "Renderer", Pn);
    J(this, "TextRenderer", Xi);
    J(this, "Lexer", lt);
    J(this, "Tokenizer", Mn);
    J(this, "Hooks", nn);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, l;
    let n = [];
    for (const o of e)
      switch (n = n.concat(t.call(this, o)), o.type) {
        case "table": {
          const r = o;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = o;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = o;
          (l = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && l[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((l) => {
        if (!l.name)
          throw new Error("extension name required");
        if ("renderer" in l) {
          const o = t.renderers[l.name];
          o ? t.renderers[l.name] = function(...r) {
            let s = l.renderer.apply(this, r);
            return s === !1 && (s = o.apply(this, r)), s;
          } : t.renderers[l.name] = l.renderer;
        }
        if ("tokenizer" in l) {
          if (!l.level || l.level !== "block" && l.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = t[l.level];
          o ? o.unshift(l.tokenizer) : t[l.level] = [l.tokenizer], l.start && (l.level === "block" ? t.startBlock ? t.startBlock.push(l.start) : t.startBlock = [l.start] : l.level === "inline" && (t.startInline ? t.startInline.push(l.start) : t.startInline = [l.start]));
        }
        "childTokens" in l && l.childTokens && (t.childTokens[l.name] = l.childTokens);
      }), i.extensions = t), n.renderer) {
        const l = this.defaults.renderer || new Pn(this.defaults);
        for (const o in n.renderer) {
          if (!(o in l))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const r = o, s = n.renderer[r], u = l[r];
          l[r] = (...c) => {
            let f = s.apply(l, c);
            return f === !1 && (f = u.apply(l, c)), f || "";
          };
        }
        i.renderer = l;
      }
      if (n.tokenizer) {
        const l = this.defaults.tokenizer || new Mn(this.defaults);
        for (const o in n.tokenizer) {
          if (!(o in l))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const r = o, s = n.tokenizer[r], u = l[r];
          l[r] = (...c) => {
            let f = s.apply(l, c);
            return f === !1 && (f = u.apply(l, c)), f;
          };
        }
        i.tokenizer = l;
      }
      if (n.hooks) {
        const l = this.defaults.hooks || new nn();
        for (const o in n.hooks) {
          if (!(o in l))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const r = o, s = n.hooks[r], u = l[r];
          nn.passThroughHooks.has(o) ? l[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(l, c)).then((d) => u.call(l, d));
            const f = s.call(l, c);
            return u.call(l, f);
          } : l[r] = (...c) => {
            let f = s.apply(l, c);
            return f === !1 && (f = u.apply(l, c)), f;
          };
        }
        i.hooks = l;
      }
      if (n.walkTokens) {
        const l = this.defaults.walkTokens, o = n.walkTokens;
        i.walkTokens = function(r) {
          let s = [];
          return s.push(o.call(this, r)), l && (s = s.concat(l.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return lt.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return ot.parse(e, t ?? this.defaults);
  }
}
At = new WeakSet(), Ti = function(e, t) {
  return (n, i) => {
    const l = { ...i }, o = { ...this.defaults, ...l };
    this.defaults.async === !0 && l.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const r = vn(this, At, Ql).call(this, !!o.silent, !!o.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(n) : n).then((s) => e(s, o)).then((s) => o.hooks ? o.hooks.processAllTokens(s) : s).then((s) => o.walkTokens ? Promise.all(this.walkTokens(s, o.walkTokens)).then(() => s) : s).then((s) => t(s, o)).then((s) => o.hooks ? o.hooks.postprocess(s) : s).catch(r);
    try {
      o.hooks && (n = o.hooks.preprocess(n));
      let s = e(n, o);
      o.hooks && (s = o.hooks.processAllTokens(s)), o.walkTokens && this.walkTokens(s, o.walkTokens);
      let u = t(s, o);
      return o.hooks && (u = o.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, Ql = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + Re(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Ct = new Er();
function W(a, e) {
  return Ct.parse(a, e);
}
W.options = W.setOptions = function(a) {
  return Ct.setOptions(a), W.defaults = Ct.defaults, Hl(W.defaults), W;
};
W.getDefaults = Gi;
W.defaults = St;
W.use = function(...a) {
  return Ct.use(...a), W.defaults = Ct.defaults, Hl(W.defaults), W;
};
W.walkTokens = function(a, e) {
  return Ct.walkTokens(a, e);
};
W.parseInline = Ct.parseInline;
W.Parser = ot;
W.parser = ot.parse;
W.Renderer = Pn;
W.TextRenderer = Xi;
W.Lexer = lt;
W.lexer = lt.lex;
W.Tokenizer = Mn;
W.Hooks = nn;
W.parse = W;
W.options;
W.setOptions;
W.use;
W.walkTokens;
W.parseInline;
ot.parse;
lt.lex;
const {
  HtmlTagHydration: Jl,
  SvelteComponent: Cr,
  append_hydration: Ne,
  attr: Ke,
  children: yt,
  claim_element: gt,
  claim_html_tag: eo,
  claim_space: xn,
  claim_text: to,
  detach: Qe,
  element: vt,
  get_svelte_dataset: Ar,
  init: Sr,
  insert_hydration: Ki,
  listen: xi,
  noop: Aa,
  run_all: Tr,
  safe_not_equal: xr,
  set_data: no,
  set_style: zn,
  space: Bn,
  text: io,
  toggle_class: Sa
} = window.__gradio__svelte__internal, { createEventDispatcher: Br } = window.__gradio__svelte__internal;
function Ta(a) {
  let e, t, n, i = (
    /*selectedHighlight*/
    (a[2].title || /*selectedHighlight*/
    a[2].term || "Highlighted Text") + ""
  ), l, o, r, s = "×", u, c, f, d, h, p, b, v = (
    /*selectedHighlight*/
    a[2].category && xa(a)
  );
  return {
    c() {
      e = vt("div"), t = vt("div"), n = vt("h3"), l = io(i), o = Bn(), r = vt("button"), r.textContent = s, u = Bn(), c = vt("div"), v && v.c(), f = Bn(), d = vt("div"), h = new Jl(!1), this.h();
    },
    l($) {
      e = gt($, "DIV", { class: !0, style: !0 });
      var g = yt(e);
      t = gt(g, "DIV", { class: !0 });
      var _ = yt(t);
      n = gt(_, "H3", { class: !0 });
      var D = yt(n);
      l = to(D, i), D.forEach(Qe), o = xn(_), r = gt(_, "BUTTON", { class: !0, "data-svelte-h": !0 }), Ar(r) !== "svelte-1klfhb2" && (r.textContent = s), _.forEach(Qe), u = xn(g), c = gt(g, "DIV", { class: !0 });
      var y = yt(c);
      v && v.l(y), f = xn(y), d = gt(y, "DIV", { class: !0 });
      var k = yt(d);
      h = eo(k, !1), k.forEach(Qe), y.forEach(Qe), g.forEach(Qe), this.h();
    },
    h() {
      Ke(n, "class", "svelte-lwvfz"), Ke(r, "class", "close-btn svelte-lwvfz"), Ke(t, "class", "panel-header svelte-lwvfz"), h.a = null, Ke(d, "class", "content-text svelte-lwvfz"), Ke(c, "class", "panel-content svelte-lwvfz"), Ke(e, "class", "side-panel svelte-lwvfz"), zn(
        e,
        "width",
        /*panel_width*/
        a[1]
      );
    },
    m($, g) {
      Ki($, e, g), Ne(e, t), Ne(t, n), Ne(n, l), Ne(t, o), Ne(t, r), Ne(e, u), Ne(e, c), v && v.m(c, null), Ne(c, f), Ne(c, d), h.m(
        /*panelContent*/
        a[4],
        d
      ), p || (b = xi(
        r,
        "click",
        /*closeSidePanel*/
        a[7]
      ), p = !0);
    },
    p($, g) {
      g & /*selectedHighlight*/
      4 && i !== (i = /*selectedHighlight*/
      ($[2].title || /*selectedHighlight*/
      $[2].term || "Highlighted Text") + "") && no(l, i), /*selectedHighlight*/
      $[2].category ? v ? v.p($, g) : (v = xa($), v.c(), v.m(c, f)) : v && (v.d(1), v = null), g & /*panelContent*/
      16 && h.p(
        /*panelContent*/
        $[4]
      ), g & /*panel_width*/
      2 && zn(
        e,
        "width",
        /*panel_width*/
        $[1]
      );
    },
    d($) {
      $ && Qe(e), v && v.d(), p = !1, b();
    }
  };
}
function xa(a) {
  let e, t = (
    /*selectedHighlight*/
    a[2].category + ""
  ), n;
  return {
    c() {
      e = vt("div"), n = io(t), this.h();
    },
    l(i) {
      e = gt(i, "DIV", { class: !0, style: !0 });
      var l = yt(e);
      n = to(l, t), l.forEach(Qe), this.h();
    },
    h() {
      Ke(e, "class", "category-badge svelte-lwvfz"), zn(
        e,
        "background-color",
        /*selectedHighlight*/
        a[2].color || "#e3f2fd"
      );
    },
    m(i, l) {
      Ki(i, e, l), Ne(e, n);
    },
    p(i, l) {
      l & /*selectedHighlight*/
      4 && t !== (t = /*selectedHighlight*/
      i[2].category + "") && no(n, t), l & /*selectedHighlight*/
      4 && zn(
        e,
        "background-color",
        /*selectedHighlight*/
        i[2].color || "#e3f2fd"
      );
    },
    d(i) {
      i && Qe(e);
    }
  };
}
function Rr(a) {
  let e, t, n, i, l, o, r = (
    /*show_side_panel*/
    a[0] && /*selectedHighlight*/
    a[2] && Ta(a)
  );
  return {
    c() {
      e = vt("div"), t = vt("div"), n = new Jl(!1), i = Bn(), r && r.c(), this.h();
    },
    l(s) {
      e = gt(s, "DIV", { class: !0 });
      var u = yt(e);
      t = gt(u, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var c = yt(t);
      n = eo(c, !1), c.forEach(Qe), i = xn(u), r && r.l(u), u.forEach(Qe), this.h();
    },
    h() {
      n.a = null, Ke(t, "class", "markdown-content svelte-lwvfz"), Ke(t, "role", "document"), Ke(t, "aria-label", "Markdown content with interactive highlights"), Ke(e, "class", "markdown-container svelte-lwvfz"), Sa(
        e,
        "with-panel",
        /*show_side_panel*/
        a[0] && /*selectedHighlight*/
        a[2]
      );
    },
    m(s, u) {
      Ki(s, e, u), Ne(e, t), n.m(
        /*processedHtml*/
        a[3],
        t
      ), Ne(e, i), r && r.m(e, null), l || (o = [
        xi(
          t,
          "click",
          /*handleTermClick*/
          a[5]
        ),
        xi(
          t,
          "keydown",
          /*handleKeydown*/
          a[6]
        )
      ], l = !0);
    },
    p(s, [u]) {
      u & /*processedHtml*/
      8 && n.p(
        /*processedHtml*/
        s[3]
      ), /*show_side_panel*/
      s[0] && /*selectedHighlight*/
      s[2] ? r ? r.p(s, u) : (r = Ta(s), r.c(), r.m(e, null)) : r && (r.d(1), r = null), u & /*show_side_panel, selectedHighlight*/
      5 && Sa(
        e,
        "with-panel",
        /*show_side_panel*/
        s[0] && /*selectedHighlight*/
        s[2]
      );
    },
    i: Aa,
    o: Aa,
    d(s) {
      s && Qe(e), r && r.d(), l = !1, Tr(o);
    }
  };
}
function Ir(a) {
  return a.includes(`
#`) || // Header boundaries
  a.includes(`

`) || // Paragraph boundaries  
  a.includes(`
-`) || // List boundaries
  a.includes(`
*`) || // List boundaries
  a.includes(`
1.`) || // Numbered list boundaries
  a.includes(`
>`) || // Blockquote boundaries
  a.includes("\n```") || // Code block boundaries
  a.includes(`
|`) || // Table boundaries
  !!a.match(/^\s*#/) || // Starts with header
  !!a.match(/\n\s*#/);
}
function Lr(a) {
  return a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Ba(a) {
  return `background-color: ${a}; cursor: pointer; padding: 2px 2px; border-radius: 3px; transition: all 0.2s; padding-left: 4px;`;
}
function Or(a, e, t) {
  var n = this && this.__awaiter || function(_, D, y, k) {
    function F(T) {
      return T instanceof y ? T : new y(function(A) {
        A(T);
      });
    }
    return new (y || (y = Promise))(function(T, A) {
      function B(S) {
        try {
          P(k.next(S));
        } catch (te) {
          A(te);
        }
      }
      function R(S) {
        try {
          P(k.throw(S));
        } catch (te) {
          A(te);
        }
      }
      function P(S) {
        S.done ? T(S.value) : F(S.value).then(B, R);
      }
      P((k = k.apply(_, D || [])).next());
    });
  };
  let { markdown_content: i = "" } = e, { highlights: l = [] } = e, { show_side_panel: o = !0 } = e, { panel_width: r = "300px" } = e;
  const s = Br();
  let u = null, c = "", f = "";
  function d() {
    return n(this, void 0, void 0, function* () {
      const _ = l.filter((F) => F.position && F.position.length === 2), D = l.filter((F) => F.term && F.term.trim());
      let y = h(i, _), k = yield W(y);
      k = p(k, _), D.forEach((F) => {
        if (F.term && F.term.trim()) {
          const T = l.indexOf(F), A = new RegExp(`\\b${Lr(F.term)}\\b`, "gi");
          k = k.replace(A, (B) => {
            const R = F.color || "#e3f2fd";
            return `<span class="highlight-term" 
								data-index="${T}" 
								data-term="${F.term}"
								style="${Ba(R)}"
								role="button" 
								tabindex="0" 
								aria-label="Highlighted term: ${F.term}">
							${B}
						</span>`;
          });
        }
      }), t(3, c = k);
    });
  }
  function h(_, D) {
    const y = [...D].sort((F, T) => T.position[0] - F.position[0]);
    let k = _;
    return y.forEach((F) => {
      const [T, A] = F.position;
      if (T >= 0 && A <= k.length && T < A) {
        const B = k.substring(T, A), R = l.indexOf(F);
        if (Ir(B)) {
          console.warn(`Position highlight [${T}, ${A}] crosses markdown boundary, skipping`);
          return;
        }
        const P = `|||POSHL_START_${R}|||`, S = `|||POSHL_END_${R}|||`;
        k = k.substring(0, T) + P + B + S + k.substring(A);
      }
    }), k;
  }
  function p(_, D) {
    return D.forEach((y) => {
      const [k, F] = y.position;
      if (k >= 0 && F <= i.length && k < F) {
        const T = i.substring(k, F), A = y.color || "#e3f2fd", B = l.indexOf(y), R = new RegExp(`\\|\\|\\|POSHL_START_${B}\\|\\|\\|(.*?)\\|\\|\\|POSHL_END_${B}\\|\\|\\|`, "g");
        _ = _.replace(R, (P, S) => `<span class="highlight-position" 
						data-index="${B}" 
						data-text="${encodeURIComponent(T)}"
						style="${Ba(A)}"
						role="button" 
						tabindex="0" 
						aria-label="Highlighted text: ${T.replace(/"/g, "&quot;")}">
						${S}
					</span>`);
      }
    }), _;
  }
  function b() {
    return n(this, void 0, void 0, function* () {
      u && t(4, f = yield W(u.content || "No additional information available."));
    });
  }
  function v(_) {
    const D = _.target;
    if (D.classList.contains("highlight-term") || D.classList.contains("highlight-position")) {
      const y = parseInt(D.dataset.index || "0"), k = l[y];
      k && (t(2, u = k), s("select", { index: y, value: k }));
    }
  }
  function $(_) {
    const D = _.target;
    (_.key === "Enter" || _.key === " ") && (D.classList.contains("highlight-term") || D.classList.contains("highlight-position")) && (_.preventDefault(), v(_));
  }
  function g() {
    t(2, u = null);
  }
  return a.$$set = (_) => {
    "markdown_content" in _ && t(8, i = _.markdown_content), "highlights" in _ && t(9, l = _.highlights), "show_side_panel" in _ && t(0, o = _.show_side_panel), "panel_width" in _ && t(1, r = _.panel_width);
  }, a.$$.update = () => {
    a.$$.dirty & /*markdown_content*/
    256 && i && d(), a.$$.dirty & /*selectedHighlight*/
    4 && u && b();
  }, [
    o,
    r,
    u,
    c,
    f,
    v,
    $,
    g,
    i,
    l
  ];
}
class qr extends Cr {
  constructor(e) {
    super(), Sr(this, e, Or, Rr, xr, {
      markdown_content: 8,
      highlights: 9,
      show_side_panel: 0,
      panel_width: 1
    });
  }
}
const {
  SvelteComponent: t_,
  append_hydration: n_,
  attr: i_,
  children: a_,
  claim_svg_element: l_,
  detach: o_,
  init: r_,
  insert_hydration: s_,
  noop: u_,
  safe_not_equal: c_,
  svg_element: __
} = window.__gradio__svelte__internal, {
  SvelteComponent: d_,
  append_hydration: f_,
  attr: h_,
  children: p_,
  claim_svg_element: m_,
  detach: g_,
  init: v_,
  insert_hydration: b_,
  noop: D_,
  safe_not_equal: w_,
  svg_element: y_
} = window.__gradio__svelte__internal, {
  SvelteComponent: k_,
  append_hydration: $_,
  attr: F_,
  children: E_,
  claim_svg_element: C_,
  detach: A_,
  init: S_,
  insert_hydration: T_,
  noop: x_,
  safe_not_equal: B_,
  svg_element: R_
} = window.__gradio__svelte__internal, {
  SvelteComponent: I_,
  append_hydration: L_,
  attr: O_,
  children: q_,
  claim_svg_element: M_,
  detach: N_,
  init: P_,
  insert_hydration: z_,
  noop: H_,
  safe_not_equal: U_,
  svg_element: G_
} = window.__gradio__svelte__internal, {
  SvelteComponent: V_,
  append_hydration: j_,
  attr: W_,
  children: Z_,
  claim_svg_element: Y_,
  detach: X_,
  init: K_,
  insert_hydration: Q_,
  noop: J_,
  safe_not_equal: ed,
  svg_element: td
} = window.__gradio__svelte__internal, {
  SvelteComponent: nd,
  append_hydration: id,
  attr: ad,
  children: ld,
  claim_svg_element: od,
  detach: rd,
  init: sd,
  insert_hydration: ud,
  noop: cd,
  safe_not_equal: _d,
  svg_element: dd
} = window.__gradio__svelte__internal, {
  SvelteComponent: fd,
  append_hydration: hd,
  attr: pd,
  children: md,
  claim_svg_element: gd,
  detach: vd,
  init: bd,
  insert_hydration: Dd,
  noop: wd,
  safe_not_equal: yd,
  svg_element: kd
} = window.__gradio__svelte__internal, {
  SvelteComponent: $d,
  append_hydration: Fd,
  attr: Ed,
  children: Cd,
  claim_svg_element: Ad,
  detach: Sd,
  init: Td,
  insert_hydration: xd,
  noop: Bd,
  safe_not_equal: Rd,
  svg_element: Id
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ld,
  append_hydration: Od,
  attr: qd,
  children: Md,
  claim_svg_element: Nd,
  detach: Pd,
  init: zd,
  insert_hydration: Hd,
  noop: Ud,
  safe_not_equal: Gd,
  svg_element: Vd
} = window.__gradio__svelte__internal, {
  SvelteComponent: jd,
  append_hydration: Wd,
  attr: Zd,
  children: Yd,
  claim_svg_element: Xd,
  detach: Kd,
  init: Qd,
  insert_hydration: Jd,
  noop: ef,
  safe_not_equal: tf,
  svg_element: nf
} = window.__gradio__svelte__internal, {
  SvelteComponent: af,
  append_hydration: lf,
  attr: of,
  children: rf,
  claim_svg_element: sf,
  detach: uf,
  init: cf,
  insert_hydration: _f,
  noop: df,
  safe_not_equal: ff,
  svg_element: hf
} = window.__gradio__svelte__internal, {
  SvelteComponent: pf,
  append_hydration: mf,
  attr: gf,
  children: vf,
  claim_svg_element: bf,
  detach: Df,
  init: wf,
  insert_hydration: yf,
  noop: kf,
  safe_not_equal: $f,
  svg_element: Ff
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mr,
  append_hydration: li,
  attr: je,
  children: wn,
  claim_svg_element: yn,
  detach: Yt,
  init: Nr,
  insert_hydration: Pr,
  noop: oi,
  safe_not_equal: zr,
  set_style: nt,
  svg_element: kn
} = window.__gradio__svelte__internal;
function Hr(a) {
  let e, t, n, i;
  return {
    c() {
      e = kn("svg"), t = kn("g"), n = kn("path"), i = kn("path"), this.h();
    },
    l(l) {
      e = yn(l, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var o = wn(e);
      t = yn(o, "g", { transform: !0 });
      var r = wn(t);
      n = yn(r, "path", { d: !0, style: !0 }), wn(n).forEach(Yt), r.forEach(Yt), i = yn(o, "path", { d: !0, style: !0 }), wn(i).forEach(Yt), o.forEach(Yt), this.h();
    },
    h() {
      je(n, "d", "M18,6L6.087,17.913"), nt(n, "fill", "none"), nt(n, "fill-rule", "nonzero"), nt(n, "stroke-width", "2px"), je(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), je(i, "d", "M4.364,4.364L19.636,19.636"), nt(i, "fill", "none"), nt(i, "fill-rule", "nonzero"), nt(i, "stroke-width", "2px"), je(e, "width", "100%"), je(e, "height", "100%"), je(e, "viewBox", "0 0 24 24"), je(e, "version", "1.1"), je(e, "xmlns", "http://www.w3.org/2000/svg"), je(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), je(e, "xml:space", "preserve"), je(e, "stroke", "currentColor"), nt(e, "fill-rule", "evenodd"), nt(e, "clip-rule", "evenodd"), nt(e, "stroke-linecap", "round"), nt(e, "stroke-linejoin", "round");
    },
    m(l, o) {
      Pr(l, e, o), li(e, t), li(t, n), li(e, i);
    },
    p: oi,
    i: oi,
    o: oi,
    d(l) {
      l && Yt(e);
    }
  };
}
class Ur extends Mr {
  constructor(e) {
    super(), Nr(this, e, null, Hr, zr, {});
  }
}
const {
  SvelteComponent: Ef,
  append_hydration: Cf,
  attr: Af,
  children: Sf,
  claim_svg_element: Tf,
  detach: xf,
  init: Bf,
  insert_hydration: Rf,
  noop: If,
  safe_not_equal: Lf,
  svg_element: Of
} = window.__gradio__svelte__internal, {
  SvelteComponent: qf,
  append_hydration: Mf,
  attr: Nf,
  children: Pf,
  claim_svg_element: zf,
  detach: Hf,
  init: Uf,
  insert_hydration: Gf,
  noop: Vf,
  safe_not_equal: jf,
  svg_element: Wf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zf,
  append_hydration: Yf,
  attr: Xf,
  children: Kf,
  claim_svg_element: Qf,
  detach: Jf,
  init: eh,
  insert_hydration: th,
  noop: nh,
  safe_not_equal: ih,
  svg_element: ah
} = window.__gradio__svelte__internal, {
  SvelteComponent: lh,
  append_hydration: oh,
  attr: rh,
  children: sh,
  claim_svg_element: uh,
  detach: ch,
  init: _h,
  insert_hydration: dh,
  noop: fh,
  safe_not_equal: hh,
  svg_element: ph
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gr,
  append_hydration: Ra,
  attr: it,
  children: ri,
  claim_svg_element: si,
  detach: $n,
  init: Vr,
  insert_hydration: jr,
  noop: ui,
  safe_not_equal: Wr,
  svg_element: ci
} = window.__gradio__svelte__internal;
function Zr(a) {
  let e, t, n;
  return {
    c() {
      e = ci("svg"), t = ci("path"), n = ci("path"), this.h();
    },
    l(i) {
      e = si(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        color: !0,
        "aria-hidden": !0,
        width: !0,
        height: !0
      });
      var l = ri(e);
      t = si(l, "path", { fill: !0, d: !0 }), ri(t).forEach($n), n = si(l, "path", { fill: !0, d: !0 }), ri(n).forEach($n), l.forEach($n), this.h();
    },
    h() {
      it(t, "fill", "currentColor"), it(t, "d", "M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"), it(n, "fill", "currentColor"), it(n, "d", "M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"), it(e, "xmlns", "http://www.w3.org/2000/svg"), it(e, "viewBox", "0 0 33 33"), it(e, "color", "currentColor"), it(e, "aria-hidden", "true"), it(e, "width", "100%"), it(e, "height", "100%");
    },
    m(i, l) {
      jr(i, e, l), Ra(e, t), Ra(e, n);
    },
    p: ui,
    i: ui,
    o: ui,
    d(i) {
      i && $n(e);
    }
  };
}
class Qi extends Gr {
  constructor(e) {
    super(), Vr(this, e, null, Zr, Wr, {});
  }
}
const {
  SvelteComponent: mh,
  append_hydration: gh,
  attr: vh,
  children: bh,
  claim_svg_element: Dh,
  detach: wh,
  init: yh,
  insert_hydration: kh,
  noop: $h,
  safe_not_equal: Fh,
  svg_element: Eh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ch,
  append_hydration: Ah,
  attr: Sh,
  children: Th,
  claim_svg_element: xh,
  detach: Bh,
  init: Rh,
  insert_hydration: Ih,
  noop: Lh,
  safe_not_equal: Oh,
  svg_element: qh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mh,
  append_hydration: Nh,
  attr: Ph,
  children: zh,
  claim_svg_element: Hh,
  detach: Uh,
  init: Gh,
  insert_hydration: Vh,
  noop: jh,
  safe_not_equal: Wh,
  svg_element: Zh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yh,
  append_hydration: Xh,
  attr: Kh,
  children: Qh,
  claim_svg_element: Jh,
  detach: ep,
  init: tp,
  insert_hydration: np,
  noop: ip,
  safe_not_equal: ap,
  svg_element: lp
} = window.__gradio__svelte__internal, {
  SvelteComponent: op,
  append_hydration: rp,
  attr: sp,
  children: up,
  claim_svg_element: cp,
  detach: _p,
  init: dp,
  insert_hydration: fp,
  noop: hp,
  safe_not_equal: pp,
  svg_element: mp
} = window.__gradio__svelte__internal, {
  SvelteComponent: gp,
  append_hydration: vp,
  attr: bp,
  children: Dp,
  claim_svg_element: wp,
  detach: yp,
  init: kp,
  insert_hydration: $p,
  noop: Fp,
  safe_not_equal: Ep,
  svg_element: Cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ap,
  append_hydration: Sp,
  attr: Tp,
  children: xp,
  claim_svg_element: Bp,
  detach: Rp,
  init: Ip,
  insert_hydration: Lp,
  noop: Op,
  safe_not_equal: qp,
  svg_element: Mp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Np,
  append_hydration: Pp,
  attr: zp,
  children: Hp,
  claim_svg_element: Up,
  detach: Gp,
  init: Vp,
  insert_hydration: jp,
  noop: Wp,
  safe_not_equal: Zp,
  svg_element: Yp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xp,
  append_hydration: Kp,
  attr: Qp,
  children: Jp,
  claim_svg_element: em,
  detach: tm,
  init: nm,
  insert_hydration: im,
  noop: am,
  safe_not_equal: lm,
  svg_element: om
} = window.__gradio__svelte__internal, {
  SvelteComponent: rm,
  append_hydration: sm,
  attr: um,
  children: cm,
  claim_svg_element: _m,
  detach: dm,
  init: fm,
  insert_hydration: hm,
  noop: pm,
  safe_not_equal: mm,
  svg_element: gm
} = window.__gradio__svelte__internal, {
  SvelteComponent: vm,
  append_hydration: bm,
  attr: Dm,
  children: wm,
  claim_svg_element: ym,
  detach: km,
  init: $m,
  insert_hydration: Fm,
  noop: Em,
  safe_not_equal: Cm,
  svg_element: Am
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sm,
  append_hydration: Tm,
  attr: xm,
  children: Bm,
  claim_svg_element: Rm,
  detach: Im,
  init: Lm,
  insert_hydration: Om,
  noop: qm,
  safe_not_equal: Mm,
  svg_element: Nm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pm,
  append_hydration: zm,
  attr: Hm,
  children: Um,
  claim_svg_element: Gm,
  detach: Vm,
  init: jm,
  insert_hydration: Wm,
  noop: Zm,
  safe_not_equal: Ym,
  svg_element: Xm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Km,
  append_hydration: Qm,
  attr: Jm,
  children: eg,
  claim_svg_element: tg,
  detach: ng,
  init: ig,
  insert_hydration: ag,
  noop: lg,
  safe_not_equal: og,
  svg_element: rg
} = window.__gradio__svelte__internal, {
  SvelteComponent: sg,
  append_hydration: ug,
  attr: cg,
  children: _g,
  claim_svg_element: dg,
  detach: fg,
  init: hg,
  insert_hydration: pg,
  noop: mg,
  safe_not_equal: gg,
  svg_element: vg
} = window.__gradio__svelte__internal, {
  SvelteComponent: bg,
  append_hydration: Dg,
  attr: wg,
  children: yg,
  claim_svg_element: kg,
  detach: $g,
  init: Fg,
  insert_hydration: Eg,
  noop: Cg,
  safe_not_equal: Ag,
  svg_element: Sg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tg,
  append_hydration: xg,
  attr: Bg,
  children: Rg,
  claim_svg_element: Ig,
  detach: Lg,
  init: Og,
  insert_hydration: qg,
  noop: Mg,
  safe_not_equal: Ng,
  svg_element: Pg
} = window.__gradio__svelte__internal, {
  SvelteComponent: zg,
  append_hydration: Hg,
  attr: Ug,
  children: Gg,
  claim_svg_element: Vg,
  detach: jg,
  init: Wg,
  insert_hydration: Zg,
  noop: Yg,
  safe_not_equal: Xg,
  svg_element: Kg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qg,
  append_hydration: Jg,
  attr: e0,
  children: t0,
  claim_svg_element: n0,
  detach: i0,
  init: a0,
  insert_hydration: l0,
  noop: o0,
  safe_not_equal: r0,
  svg_element: s0
} = window.__gradio__svelte__internal, {
  SvelteComponent: u0,
  append_hydration: c0,
  attr: _0,
  children: d0,
  claim_svg_element: f0,
  detach: h0,
  init: p0,
  insert_hydration: m0,
  noop: g0,
  safe_not_equal: v0,
  svg_element: b0
} = window.__gradio__svelte__internal, {
  SvelteComponent: D0,
  append_hydration: w0,
  attr: y0,
  children: k0,
  claim_svg_element: $0,
  detach: F0,
  init: E0,
  insert_hydration: C0,
  noop: A0,
  safe_not_equal: S0,
  svg_element: T0
} = window.__gradio__svelte__internal, {
  SvelteComponent: x0,
  append_hydration: B0,
  attr: R0,
  children: I0,
  claim_svg_element: L0,
  detach: O0,
  init: q0,
  insert_hydration: M0,
  noop: N0,
  safe_not_equal: P0,
  svg_element: z0
} = window.__gradio__svelte__internal, {
  SvelteComponent: H0,
  append_hydration: U0,
  attr: G0,
  children: V0,
  claim_svg_element: j0,
  detach: W0,
  init: Z0,
  insert_hydration: Y0,
  noop: X0,
  safe_not_equal: K0,
  svg_element: Q0
} = window.__gradio__svelte__internal, {
  SvelteComponent: J0,
  append_hydration: e1,
  attr: t1,
  children: n1,
  claim_svg_element: i1,
  detach: a1,
  init: l1,
  insert_hydration: o1,
  noop: r1,
  safe_not_equal: s1,
  svg_element: u1
} = window.__gradio__svelte__internal, {
  SvelteComponent: c1,
  append_hydration: _1,
  attr: d1,
  children: f1,
  claim_svg_element: h1,
  detach: p1,
  init: m1,
  insert_hydration: g1,
  noop: v1,
  safe_not_equal: b1,
  svg_element: D1
} = window.__gradio__svelte__internal, {
  SvelteComponent: w1,
  append_hydration: y1,
  attr: k1,
  children: $1,
  claim_svg_element: F1,
  detach: E1,
  init: C1,
  insert_hydration: A1,
  noop: S1,
  safe_not_equal: T1,
  svg_element: x1
} = window.__gradio__svelte__internal, {
  SvelteComponent: B1,
  append_hydration: R1,
  attr: I1,
  children: L1,
  claim_svg_element: O1,
  detach: q1,
  init: M1,
  insert_hydration: N1,
  noop: P1,
  safe_not_equal: z1,
  svg_element: H1
} = window.__gradio__svelte__internal, {
  SvelteComponent: U1,
  append_hydration: G1,
  attr: V1,
  children: j1,
  claim_svg_element: W1,
  detach: Z1,
  init: Y1,
  insert_hydration: X1,
  noop: K1,
  safe_not_equal: Q1,
  svg_element: J1
} = window.__gradio__svelte__internal, {
  SvelteComponent: ev,
  append_hydration: tv,
  attr: nv,
  children: iv,
  claim_svg_element: av,
  detach: lv,
  init: ov,
  insert_hydration: rv,
  noop: sv,
  safe_not_equal: uv,
  svg_element: cv
} = window.__gradio__svelte__internal, {
  SvelteComponent: _v,
  append_hydration: dv,
  attr: fv,
  children: hv,
  claim_svg_element: pv,
  detach: mv,
  init: gv,
  insert_hydration: vv,
  noop: bv,
  safe_not_equal: Dv,
  set_style: wv,
  svg_element: yv
} = window.__gradio__svelte__internal, {
  SvelteComponent: kv,
  append_hydration: $v,
  attr: Fv,
  children: Ev,
  claim_svg_element: Cv,
  detach: Av,
  init: Sv,
  insert_hydration: Tv,
  noop: xv,
  safe_not_equal: Bv,
  svg_element: Rv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iv,
  append_hydration: Lv,
  attr: Ov,
  children: qv,
  claim_svg_element: Mv,
  detach: Nv,
  init: Pv,
  insert_hydration: zv,
  noop: Hv,
  safe_not_equal: Uv,
  svg_element: Gv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vv,
  append_hydration: jv,
  attr: Wv,
  children: Zv,
  claim_svg_element: Yv,
  detach: Xv,
  init: Kv,
  insert_hydration: Qv,
  noop: Jv,
  safe_not_equal: eb,
  svg_element: tb
} = window.__gradio__svelte__internal, {
  SvelteComponent: nb,
  append_hydration: ib,
  attr: ab,
  children: lb,
  claim_svg_element: ob,
  detach: rb,
  init: sb,
  insert_hydration: ub,
  noop: cb,
  safe_not_equal: _b,
  svg_element: db
} = window.__gradio__svelte__internal, {
  SvelteComponent: fb,
  append_hydration: hb,
  attr: pb,
  children: mb,
  claim_svg_element: gb,
  detach: vb,
  init: bb,
  insert_hydration: Db,
  noop: wb,
  safe_not_equal: yb,
  svg_element: kb
} = window.__gradio__svelte__internal, {
  SvelteComponent: $b,
  append_hydration: Fb,
  attr: Eb,
  children: Cb,
  claim_svg_element: Ab,
  detach: Sb,
  init: Tb,
  insert_hydration: xb,
  noop: Bb,
  safe_not_equal: Rb,
  svg_element: Ib
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lb,
  append_hydration: Ob,
  attr: qb,
  children: Mb,
  claim_svg_element: Nb,
  detach: Pb,
  init: zb,
  insert_hydration: Hb,
  noop: Ub,
  safe_not_equal: Gb,
  svg_element: Vb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yr,
  append_hydration: Ia,
  attr: xe,
  children: _i,
  claim_svg_element: di,
  detach: Fn,
  init: Xr,
  insert_hydration: Kr,
  noop: fi,
  safe_not_equal: Qr,
  svg_element: hi
} = window.__gradio__svelte__internal;
function Jr(a) {
  let e, t, n;
  return {
    c() {
      e = hi("svg"), t = hi("path"), n = hi("path"), this.h();
    },
    l(i) {
      e = di(i, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        "aria-hidden": !0,
        role: !0,
        class: !0,
        width: !0,
        height: !0,
        preserveAspectRatio: !0,
        viewBox: !0
      });
      var l = _i(e);
      t = di(l, "path", { fill: !0, d: !0 }), _i(t).forEach(Fn), n = di(l, "path", { fill: !0, d: !0 }), _i(n).forEach(Fn), l.forEach(Fn), this.h();
    },
    h() {
      xe(t, "fill", "currentColor"), xe(t, "d", "M12 15H5a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h5V5a1 1 0 0 0-1-1H3V2h6a3 3 0 0 1 3 3zM5 9a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h5V9zm15 14v2a1 1 0 0 0 1 1h5v-4h-5a1 1 0 0 0-1 1z"), xe(n, "fill", "currentColor"), xe(n, "d", "M2 30h28V2Zm26-2h-7a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h5v-2a1 1 0 0 0-1-1h-6v-2h6a3 3 0 0 1 3 3Z"), xe(e, "xmlns", "http://www.w3.org/2000/svg"), xe(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), xe(e, "aria-hidden", "true"), xe(e, "role", "img"), xe(e, "class", "iconify iconify--carbon"), xe(e, "width", "100%"), xe(e, "height", "100%"), xe(e, "preserveAspectRatio", "xMidYMid meet"), xe(e, "viewBox", "0 0 32 32");
    },
    m(i, l) {
      Kr(i, e, l), Ia(e, t), Ia(e, n);
    },
    p: fi,
    i: fi,
    o: fi,
    d(i) {
      i && Fn(e);
    }
  };
}
class ao extends Yr {
  constructor(e) {
    super(), Xr(this, e, null, Jr, Qr, {});
  }
}
const {
  SvelteComponent: jb,
  append_hydration: Wb,
  attr: Zb,
  children: Yb,
  claim_svg_element: Xb,
  claim_text: Kb,
  detach: Qb,
  init: Jb,
  insert_hydration: eD,
  noop: tD,
  safe_not_equal: nD,
  svg_element: iD,
  text: aD
} = window.__gradio__svelte__internal, {
  SvelteComponent: lD,
  append_hydration: oD,
  attr: rD,
  children: sD,
  claim_svg_element: uD,
  detach: cD,
  init: _D,
  insert_hydration: dD,
  noop: fD,
  safe_not_equal: hD,
  svg_element: pD
} = window.__gradio__svelte__internal, {
  SvelteComponent: mD,
  append_hydration: gD,
  attr: vD,
  children: bD,
  claim_svg_element: DD,
  detach: wD,
  init: yD,
  insert_hydration: kD,
  noop: $D,
  safe_not_equal: FD,
  svg_element: ED
} = window.__gradio__svelte__internal, {
  SvelteComponent: CD,
  append_hydration: AD,
  attr: SD,
  children: TD,
  claim_svg_element: xD,
  detach: BD,
  init: RD,
  insert_hydration: ID,
  noop: LD,
  safe_not_equal: OD,
  svg_element: qD
} = window.__gradio__svelte__internal, {
  SvelteComponent: MD,
  append_hydration: ND,
  attr: PD,
  children: zD,
  claim_svg_element: HD,
  detach: UD,
  init: GD,
  insert_hydration: VD,
  noop: jD,
  safe_not_equal: WD,
  svg_element: ZD
} = window.__gradio__svelte__internal, {
  SvelteComponent: YD,
  append_hydration: XD,
  attr: KD,
  children: QD,
  claim_svg_element: JD,
  detach: ew,
  init: tw,
  insert_hydration: nw,
  noop: iw,
  safe_not_equal: aw,
  svg_element: lw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ow,
  append_hydration: rw,
  attr: sw,
  children: uw,
  claim_svg_element: cw,
  detach: _w,
  init: dw,
  insert_hydration: fw,
  noop: hw,
  safe_not_equal: pw,
  svg_element: mw
} = window.__gradio__svelte__internal, {
  SvelteComponent: gw,
  append_hydration: vw,
  attr: bw,
  children: Dw,
  claim_svg_element: ww,
  detach: yw,
  init: kw,
  insert_hydration: $w,
  noop: Fw,
  safe_not_equal: Ew,
  svg_element: Cw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Aw,
  append_hydration: Sw,
  attr: Tw,
  children: xw,
  claim_svg_element: Bw,
  claim_text: Rw,
  detach: Iw,
  init: Lw,
  insert_hydration: Ow,
  noop: qw,
  safe_not_equal: Mw,
  svg_element: Nw,
  text: Pw
} = window.__gradio__svelte__internal, {
  SvelteComponent: zw,
  append_hydration: Hw,
  attr: Uw,
  children: Gw,
  claim_svg_element: Vw,
  claim_text: jw,
  detach: Ww,
  init: Zw,
  insert_hydration: Yw,
  noop: Xw,
  safe_not_equal: Kw,
  svg_element: Qw,
  text: Jw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ey,
  append_hydration: ty,
  attr: ny,
  children: iy,
  claim_svg_element: ay,
  claim_text: ly,
  detach: oy,
  init: ry,
  insert_hydration: sy,
  noop: uy,
  safe_not_equal: cy,
  svg_element: _y,
  text: dy
} = window.__gradio__svelte__internal, {
  SvelteComponent: fy,
  append_hydration: hy,
  attr: py,
  children: my,
  claim_svg_element: gy,
  detach: vy,
  init: by,
  insert_hydration: Dy,
  noop: wy,
  safe_not_equal: yy,
  svg_element: ky
} = window.__gradio__svelte__internal, {
  SvelteComponent: $y,
  append_hydration: Fy,
  attr: Ey,
  children: Cy,
  claim_svg_element: Ay,
  detach: Sy,
  init: Ty,
  insert_hydration: xy,
  noop: By,
  safe_not_equal: Ry,
  svg_element: Iy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ly,
  append_hydration: Oy,
  attr: qy,
  children: My,
  claim_svg_element: Ny,
  detach: Py,
  init: zy,
  insert_hydration: Hy,
  noop: Uy,
  safe_not_equal: Gy,
  svg_element: Vy
} = window.__gradio__svelte__internal, {
  SvelteComponent: jy,
  append_hydration: Wy,
  attr: Zy,
  children: Yy,
  claim_svg_element: Xy,
  detach: Ky,
  init: Qy,
  insert_hydration: Jy,
  noop: ek,
  safe_not_equal: tk,
  svg_element: nk
} = window.__gradio__svelte__internal, {
  SvelteComponent: ik,
  append_hydration: ak,
  attr: lk,
  children: ok,
  claim_svg_element: rk,
  detach: sk,
  init: uk,
  insert_hydration: ck,
  noop: _k,
  safe_not_equal: dk,
  svg_element: fk
} = window.__gradio__svelte__internal, {
  SvelteComponent: hk,
  append_hydration: pk,
  attr: mk,
  children: gk,
  claim_svg_element: vk,
  detach: bk,
  init: Dk,
  insert_hydration: wk,
  noop: yk,
  safe_not_equal: kk,
  svg_element: $k
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fk,
  append_hydration: Ek,
  attr: Ck,
  children: Ak,
  claim_svg_element: Sk,
  detach: Tk,
  init: xk,
  insert_hydration: Bk,
  noop: Rk,
  safe_not_equal: Ik,
  svg_element: Lk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ok,
  append_hydration: qk,
  attr: Mk,
  children: Nk,
  claim_svg_element: Pk,
  detach: zk,
  init: Hk,
  insert_hydration: Uk,
  noop: Gk,
  safe_not_equal: Vk,
  svg_element: jk
} = window.__gradio__svelte__internal, {
  HtmlTagHydration: Zn,
  SvelteComponent: es,
  append_hydration: V,
  attr: O,
  check_outros: an,
  children: ie,
  claim_component: Ji,
  claim_element: Z,
  claim_html_tag: Yn,
  claim_space: Fe,
  claim_text: lo,
  create_component: ea,
  destroy_component: ta,
  detach: U,
  element: Y,
  empty: Hn,
  get_svelte_dataset: $t,
  group_outros: ln,
  init: ts,
  insert_hydration: we,
  listen: ue,
  mount_component: na,
  noop: sn,
  run_all: Tt,
  safe_not_equal: ns,
  set_data: oo,
  set_input_value: Un,
  set_style: Gn,
  space: Ee,
  text: ro,
  toggle_class: at,
  transition_in: De,
  transition_out: Ie
} = window.__gradio__svelte__internal, { createEventDispatcher: is } = window.__gradio__svelte__internal;
function La(a) {
  let e, t, n, i, l, o, r, s = (
    /*interactive*/
    a[2] && Oa(a)
  );
  return i = new Qi({}), {
    c() {
      e = Y("div"), s && s.c(), t = Ee(), n = Y("button"), ea(i.$$.fragment), this.h();
    },
    l(u) {
      e = Z(u, "DIV", { class: !0 });
      var c = ie(e);
      s && s.l(c), t = Fe(c), n = Z(c, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-roledescription": !0
      });
      var f = ie(n);
      Ji(i.$$.fragment, f), f.forEach(U), c.forEach(U), this.h();
    },
    h() {
      O(n, "class", "copy-btn svelte-x24fyc"), O(n, "aria-label", "Copy"), O(n, "aria-roledescription", "Copy text"), O(e, "class", "edit-controls svelte-x24fyc");
    },
    m(u, c) {
      we(u, e, c), s && s.m(e, null), V(e, t), V(e, n), na(i, n, null), l = !0, o || (r = ue(
        n,
        "click",
        /*copyToClipboard*/
        a[19]
      ), o = !0);
    },
    p(u, c) {
      /*interactive*/
      u[2] ? s ? s.p(u, c) : (s = Oa(u), s.c(), s.m(e, t)) : s && (s.d(1), s = null);
    },
    i(u) {
      l || (De(i.$$.fragment, u), l = !0);
    },
    o(u) {
      Ie(i.$$.fragment, u), l = !1;
    },
    d(u) {
      u && U(e), s && s.d(), ta(i), o = !1, r();
    }
  };
}
function Oa(a) {
  let e, t = "✏️ Edit", n, i;
  return {
    c() {
      e = Y("button"), e.textContent = t, this.h();
    },
    l(l) {
      e = Z(l, "BUTTON", { class: !0, "data-svelte-h": !0 }), $t(e) !== "svelte-n56vpj" && (e.textContent = t), this.h();
    },
    h() {
      O(e, "class", "edit-btn svelte-x24fyc");
    },
    m(l, o) {
      we(l, e, o), n || (i = ue(
        e,
        "click",
        /*startEditing*/
        a[14]
      ), n = !0);
    },
    p: sn,
    d(l) {
      l && U(e), n = !1, i();
    }
  };
}
function qa(a) {
  let e, t, n = "💾 Save", i, l, o = "❌ Cancel", r, s, u, c, f = (
    /*edit_mode*/
    a[3] === "tabs" && Ma(a)
  );
  return {
    c() {
      e = Y("div"), t = Y("button"), t.textContent = n, i = Ee(), l = Y("button"), l.textContent = o, r = Ee(), f && f.c(), this.h();
    },
    l(d) {
      e = Z(d, "DIV", { class: !0 });
      var h = ie(e);
      t = Z(h, "BUTTON", { class: !0, "data-svelte-h": !0 }), $t(t) !== "svelte-1gd1bpi" && (t.textContent = n), i = Fe(h), l = Z(h, "BUTTON", { class: !0, "data-svelte-h": !0 }), $t(l) !== "svelte-1h9521n" && (l.textContent = o), r = Fe(h), f && f.l(h), h.forEach(U), this.h();
    },
    h() {
      O(t, "class", "save-btn svelte-x24fyc"), O(l, "class", "cancel-btn svelte-x24fyc"), O(e, "class", "edit-controls svelte-x24fyc");
    },
    m(d, h) {
      we(d, e, h), V(e, t), V(e, i), V(e, l), V(e, r), f && f.m(e, null), s = !0, u || (c = [
        ue(
          t,
          "click",
          /*saveChanges*/
          a[15]
        ),
        ue(
          l,
          "click",
          /*cancelEditing*/
          a[16]
        )
      ], u = !0);
    },
    p(d, h) {
      /*edit_mode*/
      d[3] === "tabs" ? f ? (f.p(d, h), h[0] & /*edit_mode*/
      8 && De(f, 1)) : (f = Ma(d), f.c(), De(f, 1), f.m(e, null)) : f && (ln(), Ie(f, 1, 1, () => {
        f = null;
      }), an());
    },
    i(d) {
      s || (De(f), s = !0);
    },
    o(d) {
      Ie(f), s = !1;
    },
    d(d) {
      d && U(e), f && f.d(), u = !1, Tt(c);
    }
  };
}
function Ma(a) {
  let e, t, n = "Edit", i, l, o = "Preview", r, s, u, c, f, d;
  return u = new Qi({}), {
    c() {
      e = Y("div"), t = Y("button"), t.textContent = n, i = Ee(), l = Y("button"), l.textContent = o, r = Ee(), s = Y("button"), ea(u.$$.fragment), this.h();
    },
    l(h) {
      e = Z(h, "DIV", { class: !0 });
      var p = ie(e);
      t = Z(p, "BUTTON", { class: !0, "data-svelte-h": !0 }), $t(t) !== "svelte-1a32n6r" && (t.textContent = n), i = Fe(p), l = Z(p, "BUTTON", { class: !0, "data-svelte-h": !0 }), $t(l) !== "svelte-cybavr" && (l.textContent = o), r = Fe(p), s = Z(p, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-roledescription": !0
      });
      var b = ie(s);
      Ji(u.$$.fragment, b), b.forEach(U), p.forEach(U), this.h();
    },
    h() {
      O(t, "class", "tab-btn svelte-x24fyc"), at(
        t,
        "active",
        /*currentTab*/
        a[10] === "edit"
      ), O(l, "class", "tab-btn svelte-x24fyc"), at(
        l,
        "active",
        /*currentTab*/
        a[10] === "preview"
      ), O(s, "class", "copy-btn svelte-x24fyc"), O(s, "aria-label", "Copy"), O(s, "aria-roledescription", "Copy text"), O(e, "class", "tab-controls svelte-x24fyc");
    },
    m(h, p) {
      we(h, e, p), V(e, t), V(e, i), V(e, l), V(e, r), V(e, s), na(u, s, null), c = !0, f || (d = [
        ue(
          t,
          "click",
          /*click_handler*/
          a[23]
        ),
        ue(
          l,
          "click",
          /*click_handler_1*/
          a[24]
        ),
        ue(
          s,
          "click",
          /*copyToClipboard*/
          a[19]
        )
      ], f = !0);
    },
    p(h, p) {
      (!c || p[0] & /*currentTab*/
      1024) && at(
        t,
        "active",
        /*currentTab*/
        h[10] === "edit"
      ), (!c || p[0] & /*currentTab*/
      1024) && at(
        l,
        "active",
        /*currentTab*/
        h[10] === "preview"
      );
    },
    i(h) {
      c || (De(u.$$.fragment, h), c = !0);
    },
    o(h) {
      Ie(u.$$.fragment, h), c = !1;
    },
    d(h) {
      h && U(e), ta(u), f = !1, Tt(d);
    }
  };
}
function as(a) {
  let e, t, n, i;
  return {
    c() {
      e = Y("div"), t = new Zn(!1), this.h();
    },
    l(l) {
      e = Z(l, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var o = ie(e);
      t = Yn(o, !1), o.forEach(U), this.h();
    },
    h() {
      t.a = null, O(e, "class", "markdown-content svelte-x24fyc"), O(e, "role", "document"), O(e, "aria-label", "Markdown content with interactive highlights");
    },
    m(l, o) {
      we(l, e, o), t.m(
        /*processedHtml*/
        a[8],
        e
      ), n || (i = [
        ue(
          e,
          "click",
          /*handleTermClick*/
          a[11]
        ),
        ue(
          e,
          "keydown",
          /*handleKeydown*/
          a[12]
        )
      ], n = !0);
    },
    p(l, o) {
      o[0] & /*processedHtml*/
      256 && t.p(
        /*processedHtml*/
        l[8]
      );
    },
    i: sn,
    o: sn,
    d(l) {
      l && U(e), n = !1, Tt(i);
    }
  };
}
function ls(a) {
  let e, t, n, i;
  const l = [rs, os], o = [];
  function r(s, u) {
    return (
      /*edit_mode*/
      s[3] === "split" ? 0 : (
        /*edit_mode*/
        s[3] === "tabs" ? 1 : -1
      )
    );
  }
  return ~(e = r(a)) && (t = o[e] = l[e](a)), {
    c() {
      t && t.c(), n = Hn();
    },
    l(s) {
      t && t.l(s), n = Hn();
    },
    m(s, u) {
      ~e && o[e].m(s, u), we(s, n, u), i = !0;
    },
    p(s, u) {
      let c = e;
      e = r(s), e === c ? ~e && o[e].p(s, u) : (t && (ln(), Ie(o[c], 1, 1, () => {
        o[c] = null;
      }), an()), ~e ? (t = o[e], t ? t.p(s, u) : (t = o[e] = l[e](s), t.c()), De(t, 1), t.m(n.parentNode, n)) : t = null);
    },
    i(s) {
      i || (De(t), i = !0);
    },
    o(s) {
      Ie(t), i = !1;
    },
    d(s) {
      s && U(n), ~e && o[e].d(s);
    }
  };
}
function os(a) {
  let e;
  function t(l, o) {
    if (
      /*currentTab*/
      l[10] === "edit"
    ) return us;
    if (
      /*currentTab*/
      l[10] === "preview"
    ) return ss;
  }
  let n = t(a), i = n && n(a);
  return {
    c() {
      e = Y("div"), i && i.c(), this.h();
    },
    l(l) {
      e = Z(l, "DIV", { class: !0 });
      var o = ie(e);
      i && i.l(o), o.forEach(U), this.h();
    },
    h() {
      O(e, "class", "tab-content svelte-x24fyc");
    },
    m(l, o) {
      we(l, e, o), i && i.m(e, null);
    },
    p(l, o) {
      n === (n = t(l)) && i ? i.p(l, o) : (i && i.d(1), i = n && n(l), i && (i.c(), i.m(e, null)));
    },
    i: sn,
    o: sn,
    d(l) {
      l && U(e), i && i.d();
    }
  };
}
function rs(a) {
  let e, t, n, i = "Markdown Editor", l, o, r, s, u, c, f, d, h, p;
  r = new Qi({});
  let b = (
    /*show_preview*/
    a[4] && Na(a)
  );
  return {
    c() {
      e = Y("div"), t = Y("div"), n = Y("h4"), n.textContent = i, l = Ee(), o = Y("button"), ea(r.$$.fragment), s = Ee(), u = Y("textarea"), c = Ee(), b && b.c(), f = Hn(), this.h();
    },
    l(v) {
      e = Z(v, "DIV", { class: !0 });
      var $ = ie(e);
      t = Z($, "DIV", { class: !0 });
      var g = ie(t);
      n = Z(g, "H4", { class: !0, "data-svelte-h": !0 }), $t(n) !== "svelte-1nsb0do" && (n.textContent = i), l = Fe(g), o = Z(g, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-roledescription": !0
      });
      var _ = ie(o);
      Ji(r.$$.fragment, _), _.forEach(U), g.forEach(U), s = Fe($), u = Z($, "TEXTAREA", {
        class: !0,
        placeholder: !0,
        spellcheck: !0
      }), ie(u).forEach(U), $.forEach(U), c = Fe(v), b && b.l(v), f = Hn(), this.h();
    },
    h() {
      O(n, "class", "svelte-x24fyc"), O(o, "class", "copy-btn svelte-x24fyc"), O(o, "aria-label", "Copy"), O(o, "aria-roledescription", "Copy text"), O(t, "class", "editor-header svelte-x24fyc"), O(u, "class", "markdown-editor svelte-x24fyc"), O(u, "placeholder", "Enter your markdown content..."), O(u, "spellcheck", "false"), O(e, "class", "editor-section svelte-x24fyc");
    },
    m(v, $) {
      we(v, e, $), V(e, t), V(t, n), V(t, l), V(t, o), na(r, o, null), V(e, s), V(e, u), Un(
        u,
        /*editingContent*/
        a[7]
      ), we(v, c, $), b && b.m(v, $), we(v, f, $), d = !0, h || (p = [
        ue(
          o,
          "click",
          /*copyToClipboard*/
          a[19]
        ),
        ue(
          u,
          "input",
          /*textarea_input_handler*/
          a[25]
        ),
        ue(
          u,
          "input",
          /*handleTextareaInput*/
          a[17]
        )
      ], h = !0);
    },
    p(v, $) {
      $[0] & /*editingContent*/
      128 && Un(
        u,
        /*editingContent*/
        v[7]
      ), /*show_preview*/
      v[4] ? b ? b.p(v, $) : (b = Na(v), b.c(), b.m(f.parentNode, f)) : b && (b.d(1), b = null);
    },
    i(v) {
      d || (De(r.$$.fragment, v), d = !0);
    },
    o(v) {
      Ie(r.$$.fragment, v), d = !1;
    },
    d(v) {
      v && (U(e), U(c), U(f)), ta(r), b && b.d(v), h = !1, Tt(p);
    }
  };
}
function ss(a) {
  let e, t, n, i;
  return {
    c() {
      e = Y("div"), t = new Zn(!1), this.h();
    },
    l(l) {
      e = Z(l, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var o = ie(e);
      t = Yn(o, !1), o.forEach(U), this.h();
    },
    h() {
      t.a = null, O(e, "class", "markdown-content preview svelte-x24fyc"), O(e, "role", "document"), O(e, "aria-label", "Markdown preview with interactive highlights");
    },
    m(l, o) {
      we(l, e, o), t.m(
        /*processedHtml*/
        a[8],
        e
      ), n || (i = [
        ue(
          e,
          "click",
          /*handleTermClick*/
          a[11]
        ),
        ue(
          e,
          "keydown",
          /*handleKeydown*/
          a[12]
        )
      ], n = !0);
    },
    p(l, o) {
      o[0] & /*processedHtml*/
      256 && t.p(
        /*processedHtml*/
        l[8]
      );
    },
    d(l) {
      l && U(e), n = !1, Tt(i);
    }
  };
}
function us(a) {
  let e, t, n;
  return {
    c() {
      e = Y("textarea"), this.h();
    },
    l(i) {
      e = Z(i, "TEXTAREA", {
        class: !0,
        placeholder: !0,
        spellcheck: !0
      }), ie(e).forEach(U), this.h();
    },
    h() {
      O(e, "class", "markdown-editor fullwidth svelte-x24fyc"), O(e, "placeholder", "Enter your markdown content..."), O(e, "spellcheck", "false");
    },
    m(i, l) {
      we(i, e, l), Un(
        e,
        /*editingContent*/
        a[7]
      ), t || (n = [
        ue(
          e,
          "input",
          /*textarea_input_handler_1*/
          a[26]
        ),
        ue(
          e,
          "input",
          /*handleTextareaInput*/
          a[17]
        )
      ], t = !0);
    },
    p(i, l) {
      l[0] & /*editingContent*/
      128 && Un(
        e,
        /*editingContent*/
        i[7]
      );
    },
    d(i) {
      i && U(e), t = !1, Tt(n);
    }
  };
}
function Na(a) {
  let e, t, n = '<h4 class="svelte-x24fyc">Live Preview</h4>', i, l, o, r, s;
  return {
    c() {
      e = Y("div"), t = Y("div"), t.innerHTML = n, i = Ee(), l = Y("div"), o = new Zn(!1), this.h();
    },
    l(u) {
      e = Z(u, "DIV", { class: !0 });
      var c = ie(e);
      t = Z(c, "DIV", { class: !0, "data-svelte-h": !0 }), $t(t) !== "svelte-10am53t" && (t.innerHTML = n), i = Fe(c), l = Z(c, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var f = ie(l);
      o = Yn(f, !1), f.forEach(U), c.forEach(U), this.h();
    },
    h() {
      O(t, "class", "preview-header svelte-x24fyc"), o.a = null, O(l, "class", "markdown-content preview svelte-x24fyc"), O(l, "role", "document"), O(l, "aria-label", "Markdown preview with interactive highlights"), O(e, "class", "preview-section svelte-x24fyc");
    },
    m(u, c) {
      we(u, e, c), V(e, t), V(e, i), V(e, l), o.m(
        /*processedHtml*/
        a[8],
        l
      ), r || (s = [
        ue(
          l,
          "click",
          /*handleTermClick*/
          a[11]
        ),
        ue(
          l,
          "keydown",
          /*handleKeydown*/
          a[12]
        )
      ], r = !0);
    },
    p(u, c) {
      c[0] & /*processedHtml*/
      256 && o.p(
        /*processedHtml*/
        u[8]
      );
    },
    d(u) {
      u && U(e), r = !1, Tt(s);
    }
  };
}
function Pa(a) {
  let e, t, n, i = (
    /*selectedHighlight*/
    (a[5].title || /*selectedHighlight*/
    a[5].term || "Highlighted Text") + ""
  ), l, o, r, s = "×", u, c, f, d, h, p, b, v = (
    /*selectedHighlight*/
    a[5].category && za(a)
  );
  return {
    c() {
      e = Y("div"), t = Y("div"), n = Y("h3"), l = ro(i), o = Ee(), r = Y("button"), r.textContent = s, u = Ee(), c = Y("div"), v && v.c(), f = Ee(), d = Y("div"), h = new Zn(!1), this.h();
    },
    l($) {
      e = Z($, "DIV", { class: !0, style: !0 });
      var g = ie(e);
      t = Z(g, "DIV", { class: !0 });
      var _ = ie(t);
      n = Z(_, "H3", { class: !0 });
      var D = ie(n);
      l = lo(D, i), D.forEach(U), o = Fe(_), r = Z(_, "BUTTON", { class: !0, "data-svelte-h": !0 }), $t(r) !== "svelte-1klfhb2" && (r.textContent = s), _.forEach(U), u = Fe(g), c = Z(g, "DIV", { class: !0 });
      var y = ie(c);
      v && v.l(y), f = Fe(y), d = Z(y, "DIV", { class: !0 });
      var k = ie(d);
      h = Yn(k, !1), k.forEach(U), y.forEach(U), g.forEach(U), this.h();
    },
    h() {
      O(n, "class", "svelte-x24fyc"), O(r, "class", "close-btn svelte-x24fyc"), O(t, "class", "panel-header svelte-x24fyc"), h.a = null, O(d, "class", "content-text svelte-x24fyc"), O(c, "class", "panel-content svelte-x24fyc"), O(e, "class", "side-panel svelte-x24fyc"), Gn(
        e,
        "width",
        /*panel_width*/
        a[1]
      );
    },
    m($, g) {
      we($, e, g), V(e, t), V(t, n), V(n, l), V(t, o), V(t, r), V(e, u), V(e, c), v && v.m(c, null), V(c, f), V(c, d), h.m(
        /*panelContent*/
        a[9],
        d
      ), p || (b = ue(
        r,
        "click",
        /*closeSidePanel*/
        a[13]
      ), p = !0);
    },
    p($, g) {
      g[0] & /*selectedHighlight*/
      32 && i !== (i = /*selectedHighlight*/
      ($[5].title || /*selectedHighlight*/
      $[5].term || "Highlighted Text") + "") && oo(l, i), /*selectedHighlight*/
      $[5].category ? v ? v.p($, g) : (v = za($), v.c(), v.m(c, f)) : v && (v.d(1), v = null), g[0] & /*panelContent*/
      512 && h.p(
        /*panelContent*/
        $[9]
      ), g[0] & /*panel_width*/
      2 && Gn(
        e,
        "width",
        /*panel_width*/
        $[1]
      );
    },
    d($) {
      $ && U(e), v && v.d(), p = !1, b();
    }
  };
}
function za(a) {
  let e, t = (
    /*selectedHighlight*/
    a[5].category + ""
  ), n;
  return {
    c() {
      e = Y("div"), n = ro(t), this.h();
    },
    l(i) {
      e = Z(i, "DIV", { class: !0, style: !0 });
      var l = ie(e);
      n = lo(l, t), l.forEach(U), this.h();
    },
    h() {
      O(e, "class", "category-badge svelte-x24fyc"), Gn(
        e,
        "background-color",
        /*selectedHighlight*/
        a[5].color || "#e3f2fd"
      );
    },
    m(i, l) {
      we(i, e, l), V(e, n);
    },
    p(i, l) {
      l[0] & /*selectedHighlight*/
      32 && t !== (t = /*selectedHighlight*/
      i[5].category + "") && oo(n, t), l[0] & /*selectedHighlight*/
      32 && Gn(
        e,
        "background-color",
        /*selectedHighlight*/
        i[5].color || "#e3f2fd"
      );
    },
    d(i) {
      i && U(e);
    }
  };
}
function cs(a) {
  let e, t, n, i, l, o, r, s, u = !/*isEditing*/
  a[6] && La(a), c = (
    /*isEditing*/
    a[6] && qa(a)
  );
  const f = [ls, as], d = [];
  function h(b, v) {
    return (
      /*isEditing*/
      b[6] ? 0 : 1
    );
  }
  l = h(a), o = d[l] = f[l](a);
  let p = (
    /*show_side_panel*/
    a[0] && /*selectedHighlight*/
    a[5] && Pa(a)
  );
  return {
    c() {
      e = Y("div"), u && u.c(), t = Ee(), c && c.c(), n = Ee(), i = Y("div"), o.c(), r = Ee(), p && p.c(), this.h();
    },
    l(b) {
      e = Z(b, "DIV", { class: !0 });
      var v = ie(e);
      u && u.l(v), t = Fe(v), c && c.l(v), n = Fe(v), i = Z(v, "DIV", { class: !0 });
      var $ = ie(i);
      o.l($), $.forEach(U), r = Fe(v), p && p.l(v), v.forEach(U), this.h();
    },
    h() {
      O(i, "class", "content-area svelte-x24fyc"), at(
        i,
        "split-mode",
        /*edit_mode*/
        a[3] === "split" && /*isEditing*/
        a[6]
      ), O(e, "class", "markdown-container svelte-x24fyc"), at(
        e,
        "editing",
        /*isEditing*/
        a[6]
      ), at(
        e,
        "with-panel",
        /*show_side_panel*/
        a[0] && /*selectedHighlight*/
        a[5]
      );
    },
    m(b, v) {
      we(b, e, v), u && u.m(e, null), V(e, t), c && c.m(e, null), V(e, n), V(e, i), d[l].m(i, null), V(e, r), p && p.m(e, null), s = !0;
    },
    p(b, v) {
      /*isEditing*/
      b[6] ? u && (ln(), Ie(u, 1, 1, () => {
        u = null;
      }), an()) : u ? (u.p(b, v), v[0] & /*isEditing*/
      64 && De(u, 1)) : (u = La(b), u.c(), De(u, 1), u.m(e, t)), /*isEditing*/
      b[6] ? c ? (c.p(b, v), v[0] & /*isEditing*/
      64 && De(c, 1)) : (c = qa(b), c.c(), De(c, 1), c.m(e, n)) : c && (ln(), Ie(c, 1, 1, () => {
        c = null;
      }), an());
      let $ = l;
      l = h(b), l === $ ? d[l].p(b, v) : (ln(), Ie(d[$], 1, 1, () => {
        d[$] = null;
      }), an(), o = d[l], o ? o.p(b, v) : (o = d[l] = f[l](b), o.c()), De(o, 1), o.m(i, null)), (!s || v[0] & /*edit_mode, isEditing*/
      72) && at(
        i,
        "split-mode",
        /*edit_mode*/
        b[3] === "split" && /*isEditing*/
        b[6]
      ), /*show_side_panel*/
      b[0] && /*selectedHighlight*/
      b[5] ? p ? p.p(b, v) : (p = Pa(b), p.c(), p.m(e, null)) : p && (p.d(1), p = null), (!s || v[0] & /*isEditing*/
      64) && at(
        e,
        "editing",
        /*isEditing*/
        b[6]
      ), (!s || v[0] & /*show_side_panel, selectedHighlight*/
      33) && at(
        e,
        "with-panel",
        /*show_side_panel*/
        b[0] && /*selectedHighlight*/
        b[5]
      );
    },
    i(b) {
      s || (De(u), De(c), De(o), s = !0);
    },
    o(b) {
      Ie(u), Ie(c), Ie(o), s = !1;
    },
    d(b) {
      b && U(e), u && u.d(), c && c.d(), d[l].d(), p && p.d();
    }
  };
}
function _s(a) {
  return a.includes(`
#`) || // Header boundaries
  a.includes(`

`) || // Paragraph boundaries  
  a.includes(`
-`) || // List boundaries
  a.includes(`
*`) || // List boundaries
  a.includes(`
1.`) || // Numbered list boundaries
  a.includes(`
>`) || // Blockquote boundaries
  a.includes("\n```") || // Code block boundaries
  a.includes(`
|`) || // Table boundaries
  !!a.match(/^\s*#/) || // Starts with header
  !!a.match(/\n\s*#/);
}
function ds(a) {
  return a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Ha(a) {
  return `background-color: ${a}; cursor: pointer; padding: 2px 2px; border-radius: 3px; transition: all 0.2s; padding-left: 4px;`;
}
function fs(a, e, t) {
  var n = this && this.__awaiter || function(w, q, z, H) {
    function E(N) {
      return N instanceof z ? N : new z(function(ne) {
        ne(N);
      });
    }
    return new (z || (z = Promise))(function(N, ne) {
      function fe(re) {
        try {
          ke(H.next(re));
        } catch (qe) {
          ne(qe);
        }
      }
      function ye(re) {
        try {
          ke(H.throw(re));
        } catch (qe) {
          ne(qe);
        }
      }
      function ke(re) {
        re.done ? N(re.value) : E(re.value).then(fe, ye);
      }
      ke((H = H.apply(w, q || [])).next());
    });
  };
  let { markdown_content: i = "" } = e, { highlights: l = [] } = e, { show_side_panel: o = !0 } = e, { panel_width: r = "300px" } = e, { interactive: s = !1 } = e, { edit_mode: u = "split" } = e, { show_preview: c = !0 } = e;
  const f = "textarea", d = is();
  let h = null, p = "", b = "", v = !1, $ = "", g = "", _ = "edit";
  function D(w) {
    return n(this, void 0, void 0, function* () {
      const q = l.filter((N) => N.position && N.position.length === 2), z = l.filter((N) => N.term && N.term.trim());
      let H = w;
      w === i && (H = y(w, q));
      let E = yield W(H);
      w === i && (E = k(E, q)), z.forEach((N) => {
        if (N.term && N.term.trim()) {
          const ne = l.indexOf(N), fe = new RegExp(`\\b${ds(N.term)}\\b`, "gi");
          E = E.replace(fe, (ye) => {
            const ke = N.color || "#e3f2fd";
            return `<span class="highlight-term" 
								data-index="${ne}" 
								data-term="${N.term}"
								style="${Ha(ke)}"
								role="button" 
								tabindex="0" 
								aria-label="Highlighted term: ${N.term}">
							${ye}
						</span>`;
          });
        }
      }), t(8, p = E);
    });
  }
  function y(w, q) {
    const z = [...q].sort((E, N) => N.position[0] - E.position[0]);
    let H = w;
    return z.forEach((E) => {
      const [N, ne] = E.position;
      if (N >= 0 && ne <= H.length && N < ne) {
        const fe = H.substring(N, ne), ye = l.indexOf(E);
        if (_s(fe)) {
          console.warn(`Position highlight [${N}, ${ne}] crosses markdown boundary, skipping`);
          return;
        }
        const ke = `|||POSHL_START_${ye}|||`, re = `|||POSHL_END_${ye}|||`;
        H = H.substring(0, N) + ke + fe + re + H.substring(ne);
      }
    }), H;
  }
  function k(w, q) {
    return q.forEach((z) => {
      const [H, E] = z.position;
      if (H >= 0 && E <= i.length && H < E) {
        const N = i.substring(H, E), ne = z.color || "#e3f2fd", fe = l.indexOf(z), ye = new RegExp(`\\|\\|\\|POSHL_START_${fe}\\|\\|\\|(.*?)\\|\\|\\|POSHL_END_${fe}\\|\\|\\|`, "g");
        w = w.replace(ye, (ke, re) => `<span class="highlight-position" 
						data-index="${fe}" 
						data-text="${encodeURIComponent(N)}"
						style="${Ha(ne)}"
						role="button" 
						tabindex="0" 
						aria-label="Highlighted text: ${N.replace(/"/g, "&quot;")}">
						${re}
					</span>`);
      }
    }), w;
  }
  function F() {
    return n(this, void 0, void 0, function* () {
      h && t(9, b = yield W(h.content || "No additional information available."));
    });
  }
  function T(w) {
    const q = w.target;
    if (q.classList.contains("highlight-term") || q.classList.contains("highlight-position")) {
      const z = parseInt(q.dataset.index || "0"), H = l[z];
      H && (t(5, h = H), d("select", { index: z, value: H }));
    }
  }
  function A(w) {
    const q = w.target;
    (w.key === "Enter" || w.key === " ") && (q.classList.contains("highlight-term") || q.classList.contains("highlight-position")) && (w.preventDefault(), T(w));
  }
  function B() {
    t(5, h = null);
  }
  function R() {
    t(6, v = !0), t(7, $ = i), g = i, d("edit", { markdown_content: i, highlights: l });
  }
  function P() {
    t(20, i = $), t(6, v = !1), d("save", { markdown_content: i, highlights: l }), d("change", { markdown_content: i, highlights: l });
  }
  function S() {
    t(7, $ = g), t(6, v = !1), d("cancel", {
      markdown_content: g,
      highlights: l
    });
  }
  function te(w) {
    const q = w.target;
    t(7, $ = q.value);
  }
  function he(w) {
    t(10, _ = w);
  }
  function ce() {
    return n(this, void 0, void 0, function* () {
      try {
        const w = v ? $ : i;
        if (navigator.clipboard && window.isSecureContext)
          yield navigator.clipboard.writeText(w);
        else {
          const q = document.createElement("textarea");
          q.value = w, q.style.position = "fixed", q.style.left = "-999999px", q.style.top = "-999999px", document.body.appendChild(q), q.focus(), q.select(), document.execCommand("copy"), q.remove();
        }
      } catch (w) {
        console.error("Failed to copy text: ", w);
      }
    });
  }
  const Oe = () => he("edit"), Q = () => he("preview");
  function oe() {
    $ = this.value, t(7, $);
  }
  function pe() {
    $ = this.value, t(7, $);
  }
  return a.$$set = (w) => {
    "markdown_content" in w && t(20, i = w.markdown_content), "highlights" in w && t(21, l = w.highlights), "show_side_panel" in w && t(0, o = w.show_side_panel), "panel_width" in w && t(1, r = w.panel_width), "interactive" in w && t(2, s = w.interactive), "edit_mode" in w && t(3, u = w.edit_mode), "show_preview" in w && t(4, c = w.show_preview);
  }, a.$$.update = () => {
    if (a.$$.dirty[0] & /*isEditing, markdown_content*/
    1048640 && (v || (g = i)), a.$$.dirty[0] & /*isEditing, edit_mode, show_preview, editingContent, markdown_content*/
    1048792) {
      const w = v && u === "split" && c ? $ : i;
      w && D(w);
    }
    a.$$.dirty[0] & /*selectedHighlight*/
    32 && h && F();
  }, [
    o,
    r,
    s,
    u,
    c,
    h,
    v,
    $,
    p,
    b,
    _,
    T,
    A,
    B,
    R,
    P,
    S,
    te,
    he,
    ce,
    i,
    l,
    f,
    Oe,
    Q,
    oe,
    pe
  ];
}
class hs extends es {
  constructor(e) {
    super(), ts(
      this,
      e,
      fs,
      cs,
      ns,
      {
        markdown_content: 20,
        highlights: 21,
        show_side_panel: 0,
        panel_width: 1,
        interactive: 2,
        edit_mode: 3,
        show_preview: 4,
        markdown_editor: 22
      },
      null,
      [-1, -1]
    );
  }
  get markdown_editor() {
    return this.$$.ctx[22];
  }
}
const {
  SvelteComponent: ps,
  append_hydration: Bi,
  assign: ms,
  attr: be,
  binding_callbacks: gs,
  children: on,
  claim_element: so,
  claim_space: uo,
  claim_svg_element: pi,
  create_slot: vs,
  detach: rt,
  element: co,
  empty: Ua,
  get_all_dirty_from_scope: bs,
  get_slot_changes: Ds,
  get_spread_update: ws,
  init: ys,
  insert_hydration: un,
  listen: ks,
  noop: $s,
  safe_not_equal: Fs,
  set_dynamic_element_data: Ga,
  set_style: X,
  space: _o,
  svg_element: mi,
  toggle_class: de,
  transition_in: fo,
  transition_out: ho,
  update_slot_base: Es
} = window.__gradio__svelte__internal;
function Va(a) {
  let e, t, n, i, l;
  return {
    c() {
      e = mi("svg"), t = mi("line"), n = mi("line"), this.h();
    },
    l(o) {
      e = pi(o, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = on(e);
      t = pi(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), on(t).forEach(rt), n = pi(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), on(n).forEach(rt), r.forEach(rt), this.h();
    },
    h() {
      be(t, "x1", "1"), be(t, "y1", "9"), be(t, "x2", "9"), be(t, "y2", "1"), be(t, "stroke", "gray"), be(t, "stroke-width", "0.5"), be(n, "x1", "5"), be(n, "y1", "9"), be(n, "x2", "9"), be(n, "y2", "5"), be(n, "stroke", "gray"), be(n, "stroke-width", "0.5"), be(e, "class", "resize-handle svelte-239wnu"), be(e, "xmlns", "http://www.w3.org/2000/svg"), be(e, "viewBox", "0 0 10 10");
    },
    m(o, r) {
      un(o, e, r), Bi(e, t), Bi(e, n), i || (l = ks(
        e,
        "mousedown",
        /*resize*/
        a[27]
      ), i = !0);
    },
    p: $s,
    d(o) {
      o && rt(e), i = !1, l();
    }
  };
}
function Cs(a) {
  var f;
  let e, t, n, i, l;
  const o = (
    /*#slots*/
    a[31].default
  ), r = vs(
    o,
    a,
    /*$$scope*/
    a[30],
    null
  );
  let s = (
    /*resizable*/
    a[19] && Va(a)
  ), u = [
    { "data-testid": (
      /*test_id*/
      a[11]
    ) },
    { id: (
      /*elem_id*/
      a[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((f = a[7]) == null ? void 0 : f.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      a[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = ms(c, u[d]);
  return {
    c() {
      e = co(
        /*tag*/
        a[25]
      ), r && r.c(), t = _o(), s && s.c(), this.h();
    },
    l(d) {
      e = so(
        d,
        /*tag*/
        (a[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = on(e);
      r && r.l(h), t = uo(h), s && s.l(h), h.forEach(rt), this.h();
    },
    h() {
      Ga(
        /*tag*/
        a[25]
      )(e, c), de(
        e,
        "hidden",
        /*visible*/
        a[14] === !1
      ), de(
        e,
        "padded",
        /*padding*/
        a[10]
      ), de(
        e,
        "flex",
        /*flex*/
        a[1]
      ), de(
        e,
        "border_focus",
        /*border_mode*/
        a[9] === "focus"
      ), de(
        e,
        "border_contrast",
        /*border_mode*/
        a[9] === "contrast"
      ), de(e, "hide-container", !/*explicit_call*/
      a[12] && !/*container*/
      a[13]), de(
        e,
        "fullscreen",
        /*fullscreen*/
        a[0]
      ), de(
        e,
        "animating",
        /*fullscreen*/
        a[0] && /*preexpansionBoundingRect*/
        a[24] !== null
      ), de(
        e,
        "auto-margin",
        /*scale*/
        a[17] === null
      ), X(
        e,
        "height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*height*/
            a[2]
          )
        )
      ), X(
        e,
        "min-height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*min_height*/
            a[3]
          )
        )
      ), X(
        e,
        "max-height",
        /*fullscreen*/
        a[0] ? void 0 : (
          /*get_dimension*/
          a[26](
            /*max_height*/
            a[4]
          )
        )
      ), X(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].top}px` : "0px"
      ), X(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].left}px` : "0px"
      ), X(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].width}px` : "0px"
      ), X(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        a[24] ? `${/*preexpansionBoundingRect*/
        a[24].height}px` : "0px"
      ), X(
        e,
        "width",
        /*fullscreen*/
        a[0] ? void 0 : typeof /*width*/
        a[5] == "number" ? `calc(min(${/*width*/
        a[5]}px, 100%))` : (
          /*get_dimension*/
          a[26](
            /*width*/
            a[5]
          )
        )
      ), X(
        e,
        "border-style",
        /*variant*/
        a[8]
      ), X(
        e,
        "overflow",
        /*allow_overflow*/
        a[15] ? (
          /*overflow_behavior*/
          a[16]
        ) : "hidden"
      ), X(
        e,
        "flex-grow",
        /*scale*/
        a[17]
      ), X(e, "min-width", `calc(min(${/*min_width*/
      a[18]}px, 100%))`), X(e, "border-width", "var(--block-border-width)");
    },
    m(d, h) {
      un(d, e, h), r && r.m(e, null), Bi(e, t), s && s.m(e, null), a[32](e), l = !0;
    },
    p(d, h) {
      var p;
      r && r.p && (!l || h[0] & /*$$scope*/
      1073741824) && Es(
        r,
        o,
        d,
        /*$$scope*/
        d[30],
        l ? Ds(
          o,
          /*$$scope*/
          d[30],
          h,
          null
        ) : bs(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, h) : (s = Va(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Ga(
        /*tag*/
        d[25]
      )(e, c = ws(u, [
        (!l || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!l || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!l || h[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((p = d[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!l || h[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: i }
      ])), de(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), de(
        e,
        "padded",
        /*padding*/
        d[10]
      ), de(
        e,
        "flex",
        /*flex*/
        d[1]
      ), de(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), de(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), de(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), de(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), de(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), de(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && X(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && X(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && X(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && X(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && X(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && X(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && X(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && X(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), h[0] & /*variant*/
      256 && X(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && X(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && X(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), h[0] & /*min_width*/
      262144 && X(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      l || (fo(r, d), l = !0);
    },
    o(d) {
      ho(r, d), l = !1;
    },
    d(d) {
      d && rt(e), r && r.d(d), s && s.d(), a[32](null);
    }
  };
}
function ja(a) {
  let e;
  return {
    c() {
      e = co("div"), this.h();
    },
    l(t) {
      e = so(t, "DIV", { class: !0 }), on(e).forEach(rt), this.h();
    },
    h() {
      be(e, "class", "placeholder svelte-239wnu"), X(
        e,
        "height",
        /*placeholder_height*/
        a[22] + "px"
      ), X(
        e,
        "width",
        /*placeholder_width*/
        a[23] + "px"
      );
    },
    m(t, n) {
      un(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && X(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && X(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && rt(e);
    }
  };
}
function As(a) {
  let e, t, n, i = (
    /*tag*/
    a[25] && Cs(a)
  ), l = (
    /*fullscreen*/
    a[0] && ja(a)
  );
  return {
    c() {
      i && i.c(), e = _o(), l && l.c(), t = Ua();
    },
    l(o) {
      i && i.l(o), e = uo(o), l && l.l(o), t = Ua();
    },
    m(o, r) {
      i && i.m(o, r), un(o, e, r), l && l.m(o, r), un(o, t, r), n = !0;
    },
    p(o, r) {
      /*tag*/
      o[25] && i.p(o, r), /*fullscreen*/
      o[0] ? l ? l.p(o, r) : (l = ja(o), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null);
    },
    i(o) {
      n || (fo(i, o), n = !0);
    },
    o(o) {
      ho(i, o), n = !1;
    },
    d(o) {
      o && (rt(e), rt(t)), i && i.d(o), l && l.d(o);
    }
  };
}
function Ss(a, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: l = void 0 } = e, { min_height: o = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: f = "solid" } = e, { border_mode: d = "base" } = e, { padding: h = !0 } = e, { type: p = "normal" } = e, { test_id: b = void 0 } = e, { explicit_call: v = !1 } = e, { container: $ = !0 } = e, { visible: g = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: D = "auto" } = e, { scale: y = null } = e, { min_width: k = 0 } = e, { flex: F = !1 } = e, { resizable: T = !1 } = e, { rtl: A = !1 } = e, { fullscreen: B = !1 } = e, R = B, P, S = p === "fieldset" ? "fieldset" : "div", te = 0, he = 0, ce = null;
  function Oe(w) {
    B && w.key === "Escape" && t(0, B = !1);
  }
  const Q = (w) => {
    if (w !== void 0) {
      if (typeof w == "number")
        return w + "px";
      if (typeof w == "string")
        return w;
    }
  }, oe = (w) => {
    let q = w.clientY;
    const z = (E) => {
      const N = E.clientY - q;
      q = E.clientY, t(21, P.style.height = `${P.offsetHeight + N}px`, P);
    }, H = () => {
      window.removeEventListener("mousemove", z), window.removeEventListener("mouseup", H);
    };
    window.addEventListener("mousemove", z), window.addEventListener("mouseup", H);
  };
  function pe(w) {
    gs[w ? "unshift" : "push"](() => {
      P = w, t(21, P);
    });
  }
  return a.$$set = (w) => {
    "height" in w && t(2, l = w.height), "min_height" in w && t(3, o = w.min_height), "max_height" in w && t(4, r = w.max_height), "width" in w && t(5, s = w.width), "elem_id" in w && t(6, u = w.elem_id), "elem_classes" in w && t(7, c = w.elem_classes), "variant" in w && t(8, f = w.variant), "border_mode" in w && t(9, d = w.border_mode), "padding" in w && t(10, h = w.padding), "type" in w && t(28, p = w.type), "test_id" in w && t(11, b = w.test_id), "explicit_call" in w && t(12, v = w.explicit_call), "container" in w && t(13, $ = w.container), "visible" in w && t(14, g = w.visible), "allow_overflow" in w && t(15, _ = w.allow_overflow), "overflow_behavior" in w && t(16, D = w.overflow_behavior), "scale" in w && t(17, y = w.scale), "min_width" in w && t(18, k = w.min_width), "flex" in w && t(1, F = w.flex), "resizable" in w && t(19, T = w.resizable), "rtl" in w && t(20, A = w.rtl), "fullscreen" in w && t(0, B = w.fullscreen), "$$scope" in w && t(30, i = w.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && B !== R && (t(29, R = B), B ? (t(24, ce = P.getBoundingClientRect()), t(22, te = P.offsetHeight), t(23, he = P.offsetWidth), window.addEventListener("keydown", Oe)) : (t(24, ce = null), window.removeEventListener("keydown", Oe))), a.$$.dirty[0] & /*visible*/
    16384 && (g || t(1, F = !1));
  }, [
    B,
    F,
    l,
    o,
    r,
    s,
    u,
    c,
    f,
    d,
    h,
    b,
    v,
    $,
    g,
    _,
    D,
    y,
    k,
    T,
    A,
    P,
    te,
    he,
    ce,
    S,
    Q,
    oe,
    p,
    R,
    i,
    n,
    pe
  ];
}
class Ts extends ps {
  constructor(e) {
    super(), ys(
      this,
      e,
      Ss,
      As,
      Fs,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
const xs = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Bs = Object.hasOwnProperty;
class po {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = Rs(e, t === !0);
    const l = i;
    for (; Bs.call(n.occurrences, i); )
      n.occurrences[l]++, i = l + "-" + n.occurrences[l];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Rs(a, e) {
  return typeof a != "string" ? "" : (e || (a = a.toLowerCase()), a.replace(xs, "").replace(/ /g, "-"));
}
new po();
var Wa = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Is = { exports: {} };
(function(a) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, l = 0, o = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function g(_) {
          return _ instanceof s ? new s(_.type, g(_.content), _.alias) : Array.isArray(_) ? _.map(g) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(g) {
          return Object.prototype.toString.call(g).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(g) {
          return g.__id || Object.defineProperty(g, "__id", { value: ++l }), g.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function g(_, D) {
          D = D || {};
          var y, k;
          switch (r.util.type(_)) {
            case "Object":
              if (k = r.util.objId(_), D[k])
                return D[k];
              y = /** @type {Record<string, any>} */
              {}, D[k] = y;
              for (var F in _)
                _.hasOwnProperty(F) && (y[F] = g(_[F], D));
              return (
                /** @type {any} */
                y
              );
            case "Array":
              return k = r.util.objId(_), D[k] ? D[k] : (y = [], D[k] = y, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(T, A) {
                y[A] = g(T, D);
              }), /** @type {any} */
              y);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(g) {
          for (; g; ) {
            var _ = i.exec(g.className);
            if (_)
              return _[1].toLowerCase();
            g = g.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(g, _) {
          g.className = g.className.replace(RegExp(i, "gi"), ""), g.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (y) {
            var g = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(y.stack) || [])[1];
            if (g) {
              var _ = document.getElementsByTagName("script");
              for (var D in _)
                if (_[D].src == g)
                  return _[D];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(g, _, D) {
          for (var y = "no-" + _; g; ) {
            var k = g.classList;
            if (k.contains(_))
              return !0;
            if (k.contains(y))
              return !1;
            g = g.parentElement;
          }
          return !!D;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(g, _) {
          var D = r.util.clone(r.languages[g]);
          for (var y in _)
            D[y] = _[y];
          return D;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(g, _, D, y) {
          y = y || /** @type {any} */
          r.languages;
          var k = y[g], F = {};
          for (var T in k)
            if (k.hasOwnProperty(T)) {
              if (T == _)
                for (var A in D)
                  D.hasOwnProperty(A) && (F[A] = D[A]);
              D.hasOwnProperty(T) || (F[T] = k[T]);
            }
          var B = y[g];
          return y[g] = F, r.languages.DFS(r.languages, function(R, P) {
            P === B && R != g && (this[R] = F);
          }), F;
        },
        // Traverse a language definition with Depth First Search
        DFS: function g(_, D, y, k) {
          k = k || {};
          var F = r.util.objId;
          for (var T in _)
            if (_.hasOwnProperty(T)) {
              D.call(_, T, _[T], y || T);
              var A = _[T], B = r.util.type(A);
              B === "Object" && !k[F(A)] ? (k[F(A)] = !0, g(A, D, null, k)) : B === "Array" && !k[F(A)] && (k[F(A)] = !0, g(A, D, T, k));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(g, _) {
        r.highlightAllUnder(document, g, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(g, _, D) {
        var y = {
          callback: D,
          container: g,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", y), y.elements = Array.prototype.slice.apply(y.container.querySelectorAll(y.selector)), r.hooks.run("before-all-elements-highlight", y);
        for (var k = 0, F; F = y.elements[k++]; )
          r.highlightElement(F, _ === !0, y.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(g, _, D) {
        var y = r.util.getLanguage(g), k = r.languages[y];
        r.util.setLanguage(g, y);
        var F = g.parentElement;
        F && F.nodeName.toLowerCase() === "pre" && r.util.setLanguage(F, y);
        var T = g.textContent, A = {
          element: g,
          language: y,
          grammar: k,
          code: T
        };
        function B(P) {
          A.highlightedCode = P, r.hooks.run("before-insert", A), A.element.innerHTML = A.highlightedCode, r.hooks.run("after-highlight", A), r.hooks.run("complete", A), D && D.call(A.element);
        }
        if (r.hooks.run("before-sanity-check", A), F = A.element.parentElement, F && F.nodeName.toLowerCase() === "pre" && !F.hasAttribute("tabindex") && F.setAttribute("tabindex", "0"), !A.code) {
          r.hooks.run("complete", A), D && D.call(A.element);
          return;
        }
        if (r.hooks.run("before-highlight", A), !A.grammar) {
          B(r.util.encode(A.code));
          return;
        }
        if (_ && n.Worker) {
          var R = new Worker(r.filename);
          R.onmessage = function(P) {
            B(P.data);
          }, R.postMessage(JSON.stringify({
            language: A.language,
            code: A.code,
            immediateClose: !0
          }));
        } else
          B(r.highlight(A.code, A.grammar, A.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(g, _, D) {
        var y = {
          code: g,
          grammar: _,
          language: D
        };
        if (r.hooks.run("before-tokenize", y), !y.grammar)
          throw new Error('The language "' + y.language + '" has no grammar.');
        return y.tokens = r.tokenize(y.code, y.grammar), r.hooks.run("after-tokenize", y), s.stringify(r.util.encode(y.tokens), y.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(g, _) {
        var D = _.rest;
        if (D) {
          for (var y in D)
            _[y] = D[y];
          delete _.rest;
        }
        var k = new f();
        return d(k, k.head, g), c(g, k, _, k.head, 0), p(k);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(g, _) {
          var D = r.hooks.all;
          D[g] = D[g] || [], D[g].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(g, _) {
          var D = r.hooks.all[g];
          if (!(!D || !D.length))
            for (var y = 0, k; k = D[y++]; )
              k(_);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(g, _, D, y) {
      this.type = g, this.content = _, this.alias = D, this.length = (y || "").length | 0;
    }
    s.stringify = function g(_, D) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var y = "";
        return _.forEach(function(B) {
          y += g(B, D);
        }), y;
      }
      var k = {
        type: _.type,
        content: g(_.content, D),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: D
      }, F = _.alias;
      F && (Array.isArray(F) ? Array.prototype.push.apply(k.classes, F) : k.classes.push(F)), r.hooks.run("wrap", k);
      var T = "";
      for (var A in k.attributes)
        T += " " + A + '="' + (k.attributes[A] || "").replace(/"/g, "&quot;") + '"';
      return "<" + k.tag + ' class="' + k.classes.join(" ") + '"' + T + ">" + k.content + "</" + k.tag + ">";
    };
    function u(g, _, D, y) {
      g.lastIndex = _;
      var k = g.exec(D);
      if (k && y && k[1]) {
        var F = k[1].length;
        k.index += F, k[0] = k[0].slice(F);
      }
      return k;
    }
    function c(g, _, D, y, k, F) {
      for (var T in D)
        if (!(!D.hasOwnProperty(T) || !D[T])) {
          var A = D[T];
          A = Array.isArray(A) ? A : [A];
          for (var B = 0; B < A.length; ++B) {
            if (F && F.cause == T + "," + B)
              return;
            var R = A[B], P = R.inside, S = !!R.lookbehind, te = !!R.greedy, he = R.alias;
            if (te && !R.pattern.global) {
              var ce = R.pattern.toString().match(/[imsuy]*$/)[0];
              R.pattern = RegExp(R.pattern.source, ce + "g");
            }
            for (var Oe = R.pattern || R, Q = y.next, oe = k; Q !== _.tail && !(F && oe >= F.reach); oe += Q.value.length, Q = Q.next) {
              var pe = Q.value;
              if (_.length > g.length)
                return;
              if (!(pe instanceof s)) {
                var w = 1, q;
                if (te) {
                  if (q = u(Oe, oe, g, S), !q || q.index >= g.length)
                    break;
                  var N = q.index, z = q.index + q[0].length, H = oe;
                  for (H += Q.value.length; N >= H; )
                    Q = Q.next, H += Q.value.length;
                  if (H -= Q.value.length, oe = H, Q.value instanceof s)
                    continue;
                  for (var E = Q; E !== _.tail && (H < z || typeof E.value == "string"); E = E.next)
                    w++, H += E.value.length;
                  w--, pe = g.slice(oe, H), q.index -= oe;
                } else if (q = u(Oe, 0, pe, S), !q)
                  continue;
                var N = q.index, ne = q[0], fe = pe.slice(0, N), ye = pe.slice(N + ne.length), ke = oe + pe.length;
                F && ke > F.reach && (F.reach = ke);
                var re = Q.prev;
                fe && (re = d(_, re, fe), oe += fe.length), h(_, re, w);
                var qe = new s(T, P ? r.tokenize(ne, P) : ne, he, ne);
                if (Q = d(_, re, qe), ye && d(_, Q, ye), w > 1) {
                  var bt = {
                    cause: T + "," + B,
                    reach: ke
                  };
                  c(g, _, D, Q.prev, oe, bt), F && bt.reach > F.reach && (F.reach = bt.reach);
                }
              }
            }
          }
        }
    }
    function f() {
      var g = { value: null, prev: null, next: null }, _ = { value: null, prev: g, next: null };
      g.next = _, this.head = g, this.tail = _, this.length = 0;
    }
    function d(g, _, D) {
      var y = _.next, k = { value: D, prev: _, next: y };
      return _.next = k, y.prev = k, g.length++, k;
    }
    function h(g, _, D) {
      for (var y = _.next, k = 0; k < D && y !== g.tail; k++)
        y = y.next;
      _.next = y, y.prev = _, g.length -= k;
    }
    function p(g) {
      for (var _ = [], D = g.head.next; D !== g.tail; )
        _.push(D.value), D = D.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(g) {
        var _ = JSON.parse(g.data), D = _.language, y = _.code, k = _.immediateClose;
        n.postMessage(r.highlight(y, r.languages[D], D)), k && n.close();
      }, !1)), r;
    var b = r.util.currentScript();
    b && (r.filename = b.src, b.hasAttribute("data-manual") && (r.manual = !0));
    function v() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var $ = document.readyState;
      $ === "loading" || $ === "interactive" && b && b.defer ? document.addEventListener("DOMContentLoaded", v) : window.requestAnimationFrame ? window.requestAnimationFrame(v) : window.setTimeout(v, 16);
    }
    return r;
  }(e);
  a.exports && (a.exports = t), typeof Wa < "u" && (Wa.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, l) {
      var o = {};
      o["language-" + l] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[l]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      r["language-" + l] = {
        pattern: /[\s\S]+/,
        inside: t.languages[l]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var l = n.languages.markup;
    l && (l.tag.addInlined("style", "css"), l.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(b, v) {
      return "✖ Error " + b + " while fetching file: " + v;
    }, l = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", f = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function d(b, v, $) {
      var g = new XMLHttpRequest();
      g.open("GET", b, !0), g.onreadystatechange = function() {
        g.readyState == 4 && (g.status < 400 && g.responseText ? v(g.responseText) : g.status >= 400 ? $(i(g.status, g.statusText)) : $(l));
      }, g.send(null);
    }
    function h(b) {
      var v = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(b || "");
      if (v) {
        var $ = Number(v[1]), g = v[2], _ = v[3];
        return g ? _ ? [$, Number(_)] : [$, void 0] : [$, $];
      }
    }
    t.hooks.add("before-highlightall", function(b) {
      b.selector += ", " + f;
    }), t.hooks.add("before-sanity-check", function(b) {
      var v = (
        /** @type {HTMLPreElement} */
        b.element
      );
      if (v.matches(f)) {
        b.code = "", v.setAttribute(r, s);
        var $ = v.appendChild(document.createElement("CODE"));
        $.textContent = n;
        var g = v.getAttribute("data-src"), _ = b.language;
        if (_ === "none") {
          var D = (/\.(\w+)$/.exec(g) || [, "none"])[1];
          _ = o[D] || D;
        }
        t.util.setLanguage($, _), t.util.setLanguage(v, _);
        var y = t.plugins.autoloader;
        y && y.loadLanguages(_), d(
          g,
          function(k) {
            v.setAttribute(r, u);
            var F = h(v.getAttribute("data-range"));
            if (F) {
              var T = k.split(/\r\n?|\n/g), A = F[0], B = F[1] == null ? T.length : F[1];
              A < 0 && (A += T.length), A = Math.max(0, Math.min(A - 1, T.length)), B < 0 && (B += T.length), B = Math.max(0, Math.min(B, T.length)), k = T.slice(A, B).join(`
`), v.hasAttribute("data-start") || v.setAttribute("data-start", String(A + 1));
            }
            $.textContent = k, t.highlightElement($);
          },
          function(k) {
            v.setAttribute(r, c), $.textContent = k;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(v) {
        for (var $ = (v || document).querySelectorAll(f), g = 0, _; _ = $[g++]; )
          t.highlightElement(_);
      }
    };
    var p = !1;
    t.fileHighlight = function() {
      p || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), p = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Is);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(a) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  a.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, a.languages.tex = a.languages.latex, a.languages.context = a.languages.latex;
})(Prism);
(function(a) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  a.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = a.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], l = n.variable[1].inside, o = 0; o < i.length; o++)
    l[i[o]] = a.languages.bash[i[o]];
  a.languages.sh = a.languages.bash, a.languages.shell = a.languages.bash;
})(Prism);
new po();
const Ls = (a) => {
  const e = {};
  for (let t = 0, n = a.length; t < n; t++) {
    const i = a[t];
    for (const l in i)
      e[l] ? e[l] = e[l].concat(i[l]) : e[l] = i[l];
  }
  return e;
}, Os = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], qs = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Ms = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
Ls([
  Object.fromEntries(Os.map((a) => [a, ["*"]])),
  Object.fromEntries(qs.map((a) => [a, ["svg:*"]])),
  Object.fromEntries(Ms.map((a) => [a, ["math:*"]]))
]);
const {
  HtmlTagHydration: Wk,
  SvelteComponent: Zk,
  attr: Yk,
  binding_callbacks: Xk,
  children: Kk,
  claim_element: Qk,
  claim_html_tag: Jk,
  detach: e2,
  element: t2,
  init: n2,
  insert_hydration: i2,
  noop: a2,
  safe_not_equal: l2,
  toggle_class: o2
} = window.__gradio__svelte__internal, { afterUpdate: r2, tick: s2, onMount: u2 } = window.__gradio__svelte__internal, {
  SvelteComponent: c2,
  attr: _2,
  children: d2,
  claim_component: f2,
  claim_element: h2,
  create_component: p2,
  destroy_component: m2,
  detach: g2,
  element: v2,
  init: b2,
  insert_hydration: D2,
  mount_component: w2,
  safe_not_equal: y2,
  transition_in: k2,
  transition_out: $2
} = window.__gradio__svelte__internal, {
  SvelteComponent: F2,
  attr: E2,
  check_outros: C2,
  children: A2,
  claim_component: S2,
  claim_element: T2,
  claim_space: x2,
  create_component: B2,
  create_slot: R2,
  destroy_component: I2,
  detach: L2,
  element: O2,
  empty: q2,
  get_all_dirty_from_scope: M2,
  get_slot_changes: N2,
  group_outros: P2,
  init: z2,
  insert_hydration: H2,
  mount_component: U2,
  safe_not_equal: G2,
  space: V2,
  toggle_class: j2,
  transition_in: W2,
  transition_out: Z2,
  update_slot_base: Y2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ns,
  append_hydration: gi,
  attr: zt,
  children: Za,
  claim_component: Ps,
  claim_element: Ya,
  claim_space: zs,
  claim_text: Hs,
  create_component: Us,
  destroy_component: Gs,
  detach: vi,
  element: Xa,
  init: Vs,
  insert_hydration: js,
  mount_component: Ws,
  safe_not_equal: Zs,
  set_data: Ys,
  space: Xs,
  text: Ks,
  toggle_class: Dt,
  transition_in: Qs,
  transition_out: Js
} = window.__gradio__svelte__internal;
function eu(a) {
  let e, t, n, i, l, o, r;
  return n = new /*Icon*/
  a[1]({}), {
    c() {
      e = Xa("label"), t = Xa("span"), Us(n.$$.fragment), i = Xs(), l = Ks(
        /*label*/
        a[0]
      ), this.h();
    },
    l(s) {
      e = Ya(s, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var u = Za(e);
      t = Ya(u, "SPAN", { class: !0 });
      var c = Za(t);
      Ps(n.$$.fragment, c), c.forEach(vi), i = zs(u), l = Hs(
        u,
        /*label*/
        a[0]
      ), u.forEach(vi), this.h();
    },
    h() {
      zt(t, "class", "svelte-13ao5pu"), zt(e, "for", ""), zt(e, "data-testid", "block-label"), zt(e, "dir", o = /*rtl*/
      a[5] ? "rtl" : "ltr"), zt(e, "class", "svelte-13ao5pu"), Dt(e, "hide", !/*show_label*/
      a[2]), Dt(e, "sr-only", !/*show_label*/
      a[2]), Dt(
        e,
        "float",
        /*float*/
        a[4]
      ), Dt(
        e,
        "hide-label",
        /*disable*/
        a[3]
      );
    },
    m(s, u) {
      js(s, e, u), gi(e, t), Ws(n, t, null), gi(e, i), gi(e, l), r = !0;
    },
    p(s, [u]) {
      (!r || u & /*label*/
      1) && Ys(
        l,
        /*label*/
        s[0]
      ), (!r || u & /*rtl*/
      32 && o !== (o = /*rtl*/
      s[5] ? "rtl" : "ltr")) && zt(e, "dir", o), (!r || u & /*show_label*/
      4) && Dt(e, "hide", !/*show_label*/
      s[2]), (!r || u & /*show_label*/
      4) && Dt(e, "sr-only", !/*show_label*/
      s[2]), (!r || u & /*float*/
      16) && Dt(
        e,
        "float",
        /*float*/
        s[4]
      ), (!r || u & /*disable*/
      8) && Dt(
        e,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      r || (Qs(n.$$.fragment, s), r = !0);
    },
    o(s) {
      Js(n.$$.fragment, s), r = !1;
    },
    d(s) {
      s && vi(e), Gs(n);
    }
  };
}
function tu(a, e, t) {
  let { label: n = null } = e, { Icon: i } = e, { show_label: l = !0 } = e, { disable: o = !1 } = e, { float: r = !0 } = e, { rtl: s = !1 } = e;
  return a.$$set = (u) => {
    "label" in u && t(0, n = u.label), "Icon" in u && t(1, i = u.Icon), "show_label" in u && t(2, l = u.show_label), "disable" in u && t(3, o = u.disable), "float" in u && t(4, r = u.float), "rtl" in u && t(5, s = u.rtl);
  }, [n, i, l, o, r, s];
}
class nu extends Ns {
  constructor(e) {
    super(), Vs(this, e, tu, eu, Zs, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: iu,
  append_hydration: Rn,
  attr: pt,
  bubble: au,
  check_outros: lu,
  children: Ri,
  claim_component: ou,
  claim_element: Ii,
  claim_space: Ka,
  claim_text: ru,
  construct_svelte_component: Qa,
  create_component: Ja,
  create_slot: su,
  destroy_component: el,
  detach: rn,
  element: Li,
  get_all_dirty_from_scope: uu,
  get_slot_changes: cu,
  group_outros: _u,
  init: du,
  insert_hydration: mo,
  listen: fu,
  mount_component: tl,
  safe_not_equal: hu,
  set_data: pu,
  set_style: En,
  space: nl,
  text: mu,
  toggle_class: ve,
  transition_in: bi,
  transition_out: Di,
  update_slot_base: gu
} = window.__gradio__svelte__internal;
function il(a) {
  let e, t;
  return {
    c() {
      e = Li("span"), t = mu(
        /*label*/
        a[1]
      ), this.h();
    },
    l(n) {
      e = Ii(n, "SPAN", { class: !0 });
      var i = Ri(e);
      t = ru(
        i,
        /*label*/
        a[1]
      ), i.forEach(rn), this.h();
    },
    h() {
      pt(e, "class", "svelte-qgco6m");
    },
    m(n, i) {
      mo(n, e, i), Rn(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && pu(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && rn(e);
    }
  };
}
function vu(a) {
  let e, t, n, i, l, o, r, s, u = (
    /*show_label*/
    a[2] && il(a)
  );
  var c = (
    /*Icon*/
    a[0]
  );
  function f(p, b) {
    return {};
  }
  c && (i = Qa(c, f()));
  const d = (
    /*#slots*/
    a[14].default
  ), h = su(
    d,
    a,
    /*$$scope*/
    a[13],
    null
  );
  return {
    c() {
      e = Li("button"), u && u.c(), t = nl(), n = Li("div"), i && Ja(i.$$.fragment), l = nl(), h && h.c(), this.h();
    },
    l(p) {
      e = Ii(p, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var b = Ri(e);
      u && u.l(b), t = Ka(b), n = Ii(b, "DIV", { class: !0 });
      var v = Ri(n);
      i && ou(i.$$.fragment, v), l = Ka(v), h && h.l(v), v.forEach(rn), b.forEach(rn), this.h();
    },
    h() {
      pt(n, "class", "svelte-qgco6m"), ve(
        n,
        "x-small",
        /*size*/
        a[4] === "x-small"
      ), ve(
        n,
        "small",
        /*size*/
        a[4] === "small"
      ), ve(
        n,
        "large",
        /*size*/
        a[4] === "large"
      ), ve(
        n,
        "medium",
        /*size*/
        a[4] === "medium"
      ), e.disabled = /*disabled*/
      a[7], pt(
        e,
        "aria-label",
        /*label*/
        a[1]
      ), pt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        a[8]
      ), pt(
        e,
        "title",
        /*label*/
        a[1]
      ), pt(e, "class", "svelte-qgco6m"), ve(
        e,
        "pending",
        /*pending*/
        a[3]
      ), ve(
        e,
        "padded",
        /*padded*/
        a[5]
      ), ve(
        e,
        "highlight",
        /*highlight*/
        a[6]
      ), ve(
        e,
        "transparent",
        /*transparent*/
        a[9]
      ), En(e, "color", !/*disabled*/
      a[7] && /*_color*/
      a[11] ? (
        /*_color*/
        a[11]
      ) : "var(--block-label-text-color)"), En(e, "--bg-color", /*disabled*/
      a[7] ? "auto" : (
        /*background*/
        a[10]
      ));
    },
    m(p, b) {
      mo(p, e, b), u && u.m(e, null), Rn(e, t), Rn(e, n), i && tl(i, n, null), Rn(n, l), h && h.m(n, null), o = !0, r || (s = fu(
        e,
        "click",
        /*click_handler*/
        a[15]
      ), r = !0);
    },
    p(p, [b]) {
      if (/*show_label*/
      p[2] ? u ? u.p(p, b) : (u = il(p), u.c(), u.m(e, t)) : u && (u.d(1), u = null), b & /*Icon*/
      1 && c !== (c = /*Icon*/
      p[0])) {
        if (i) {
          _u();
          const v = i;
          Di(v.$$.fragment, 1, 0, () => {
            el(v, 1);
          }), lu();
        }
        c ? (i = Qa(c, f()), Ja(i.$$.fragment), bi(i.$$.fragment, 1), tl(i, n, l)) : i = null;
      }
      h && h.p && (!o || b & /*$$scope*/
      8192) && gu(
        h,
        d,
        p,
        /*$$scope*/
        p[13],
        o ? cu(
          d,
          /*$$scope*/
          p[13],
          b,
          null
        ) : uu(
          /*$$scope*/
          p[13]
        ),
        null
      ), (!o || b & /*size*/
      16) && ve(
        n,
        "x-small",
        /*size*/
        p[4] === "x-small"
      ), (!o || b & /*size*/
      16) && ve(
        n,
        "small",
        /*size*/
        p[4] === "small"
      ), (!o || b & /*size*/
      16) && ve(
        n,
        "large",
        /*size*/
        p[4] === "large"
      ), (!o || b & /*size*/
      16) && ve(
        n,
        "medium",
        /*size*/
        p[4] === "medium"
      ), (!o || b & /*disabled*/
      128) && (e.disabled = /*disabled*/
      p[7]), (!o || b & /*label*/
      2) && pt(
        e,
        "aria-label",
        /*label*/
        p[1]
      ), (!o || b & /*hasPopup*/
      256) && pt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        p[8]
      ), (!o || b & /*label*/
      2) && pt(
        e,
        "title",
        /*label*/
        p[1]
      ), (!o || b & /*pending*/
      8) && ve(
        e,
        "pending",
        /*pending*/
        p[3]
      ), (!o || b & /*padded*/
      32) && ve(
        e,
        "padded",
        /*padded*/
        p[5]
      ), (!o || b & /*highlight*/
      64) && ve(
        e,
        "highlight",
        /*highlight*/
        p[6]
      ), (!o || b & /*transparent*/
      512) && ve(
        e,
        "transparent",
        /*transparent*/
        p[9]
      ), b & /*disabled, _color*/
      2176 && En(e, "color", !/*disabled*/
      p[7] && /*_color*/
      p[11] ? (
        /*_color*/
        p[11]
      ) : "var(--block-label-text-color)"), b & /*disabled, background*/
      1152 && En(e, "--bg-color", /*disabled*/
      p[7] ? "auto" : (
        /*background*/
        p[10]
      ));
    },
    i(p) {
      o || (i && bi(i.$$.fragment, p), bi(h, p), o = !0);
    },
    o(p) {
      i && Di(i.$$.fragment, p), Di(h, p), o = !1;
    },
    d(p) {
      p && rn(e), u && u.d(), i && el(i), h && h.d(p), r = !1, s();
    }
  };
}
function bu(a, e, t) {
  let n, { $$slots: i = {}, $$scope: l } = e, { Icon: o } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: f = !0 } = e, { highlight: d = !1 } = e, { disabled: h = !1 } = e, { hasPopup: p = !1 } = e, { color: b = "var(--block-label-text-color)" } = e, { transparent: v = !1 } = e, { background: $ = "var(--block-background-fill)" } = e;
  function g(_) {
    au.call(this, a, _);
  }
  return a.$$set = (_) => {
    "Icon" in _ && t(0, o = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, f = _.padded), "highlight" in _ && t(6, d = _.highlight), "disabled" in _ && t(7, h = _.disabled), "hasPopup" in _ && t(8, p = _.hasPopup), "color" in _ && t(12, b = _.color), "transparent" in _ && t(9, v = _.transparent), "background" in _ && t(10, $ = _.background), "$$scope" in _ && t(13, l = _.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : b);
  }, [
    o,
    r,
    s,
    u,
    c,
    f,
    d,
    h,
    p,
    v,
    $,
    n,
    b,
    l,
    i,
    g
  ];
}
class Du extends iu {
  constructor(e) {
    super(), du(this, e, bu, vu, hu, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: wu,
  append_hydration: yu,
  attr: wi,
  binding_callbacks: ku,
  children: al,
  claim_element: ll,
  create_slot: $u,
  detach: yi,
  element: ol,
  get_all_dirty_from_scope: Fu,
  get_slot_changes: Eu,
  init: Cu,
  insert_hydration: Au,
  safe_not_equal: Su,
  toggle_class: wt,
  transition_in: Tu,
  transition_out: xu,
  update_slot_base: Bu
} = window.__gradio__svelte__internal;
function Ru(a) {
  let e, t, n;
  const i = (
    /*#slots*/
    a[5].default
  ), l = $u(
    i,
    a,
    /*$$scope*/
    a[4],
    null
  );
  return {
    c() {
      e = ol("div"), t = ol("div"), l && l.c(), this.h();
    },
    l(o) {
      e = ll(o, "DIV", { class: !0, "aria-label": !0 });
      var r = al(e);
      t = ll(r, "DIV", { class: !0 });
      var s = al(t);
      l && l.l(s), s.forEach(yi), r.forEach(yi), this.h();
    },
    h() {
      wi(t, "class", "icon svelte-3w3rth"), wi(e, "class", "empty svelte-3w3rth"), wi(e, "aria-label", "Empty value"), wt(
        e,
        "small",
        /*size*/
        a[0] === "small"
      ), wt(
        e,
        "large",
        /*size*/
        a[0] === "large"
      ), wt(
        e,
        "unpadded_box",
        /*unpadded_box*/
        a[1]
      ), wt(
        e,
        "small_parent",
        /*parent_height*/
        a[3]
      );
    },
    m(o, r) {
      Au(o, e, r), yu(e, t), l && l.m(t, null), a[6](e), n = !0;
    },
    p(o, [r]) {
      l && l.p && (!n || r & /*$$scope*/
      16) && Bu(
        l,
        i,
        o,
        /*$$scope*/
        o[4],
        n ? Eu(
          i,
          /*$$scope*/
          o[4],
          r,
          null
        ) : Fu(
          /*$$scope*/
          o[4]
        ),
        null
      ), (!n || r & /*size*/
      1) && wt(
        e,
        "small",
        /*size*/
        o[0] === "small"
      ), (!n || r & /*size*/
      1) && wt(
        e,
        "large",
        /*size*/
        o[0] === "large"
      ), (!n || r & /*unpadded_box*/
      2) && wt(
        e,
        "unpadded_box",
        /*unpadded_box*/
        o[1]
      ), (!n || r & /*parent_height*/
      8) && wt(
        e,
        "small_parent",
        /*parent_height*/
        o[3]
      );
    },
    i(o) {
      n || (Tu(l, o), n = !0);
    },
    o(o) {
      xu(l, o), n = !1;
    },
    d(o) {
      o && yi(e), l && l.d(o), a[6](null);
    }
  };
}
function Iu(a, e, t) {
  let n, { $$slots: i = {}, $$scope: l } = e, { size: o = "small" } = e, { unpadded_box: r = !1 } = e, s;
  function u(f) {
    var d;
    if (!f) return !1;
    const { height: h } = f.getBoundingClientRect(), { height: p } = ((d = f.parentElement) === null || d === void 0 ? void 0 : d.getBoundingClientRect()) || { height: h };
    return h > p + 2;
  }
  function c(f) {
    ku[f ? "unshift" : "push"](() => {
      s = f, t(2, s);
    });
  }
  return a.$$set = (f) => {
    "size" in f && t(0, o = f.size), "unpadded_box" in f && t(1, r = f.unpadded_box), "$$scope" in f && t(4, l = f.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty & /*el*/
    4 && t(3, n = u(s));
  }, [o, r, s, n, l, i, c];
}
class Lu extends wu {
  constructor(e) {
    super(), Cu(this, e, Iu, Ru, Su, { size: 0, unpadded_box: 1 });
  }
}
const Ou = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], rl = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Ou.reduce(
  (a, { color: e, primary: t, secondary: n }) => ({
    ...a,
    [e]: {
      primary: rl[e][t],
      secondary: rl[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: X2,
  claim_component: K2,
  create_component: Q2,
  destroy_component: J2,
  init: e$,
  mount_component: t$,
  safe_not_equal: n$,
  transition_in: i$,
  transition_out: a$
} = window.__gradio__svelte__internal, { createEventDispatcher: l$ } = window.__gradio__svelte__internal, {
  SvelteComponent: o$,
  append_hydration: r$,
  attr: s$,
  check_outros: u$,
  children: c$,
  claim_component: _$,
  claim_element: d$,
  claim_space: f$,
  claim_text: h$,
  create_component: p$,
  destroy_component: m$,
  detach: g$,
  element: v$,
  empty: b$,
  group_outros: D$,
  init: w$,
  insert_hydration: y$,
  mount_component: k$,
  safe_not_equal: $$,
  set_data: F$,
  space: E$,
  text: C$,
  toggle_class: A$,
  transition_in: S$,
  transition_out: T$
} = window.__gradio__svelte__internal, {
  SvelteComponent: x$,
  attr: B$,
  children: R$,
  claim_element: I$,
  create_slot: L$,
  detach: O$,
  element: q$,
  get_all_dirty_from_scope: M$,
  get_slot_changes: N$,
  init: P$,
  insert_hydration: z$,
  safe_not_equal: H$,
  toggle_class: U$,
  transition_in: G$,
  transition_out: V$,
  update_slot_base: j$
} = window.__gradio__svelte__internal, {
  SvelteComponent: W$,
  append_hydration: Z$,
  attr: Y$,
  check_outros: X$,
  children: K$,
  claim_component: Q$,
  claim_element: J$,
  claim_space: eF,
  create_component: tF,
  destroy_component: nF,
  detach: iF,
  element: aF,
  empty: lF,
  group_outros: oF,
  init: rF,
  insert_hydration: sF,
  listen: uF,
  mount_component: cF,
  safe_not_equal: _F,
  space: dF,
  toggle_class: fF,
  transition_in: hF,
  transition_out: pF
} = window.__gradio__svelte__internal, {
  SvelteComponent: mF,
  attr: gF,
  children: vF,
  claim_element: bF,
  create_slot: DF,
  detach: wF,
  element: yF,
  get_all_dirty_from_scope: kF,
  get_slot_changes: $F,
  init: FF,
  insert_hydration: EF,
  null_to_empty: CF,
  safe_not_equal: AF,
  transition_in: SF,
  transition_out: TF,
  update_slot_base: xF
} = window.__gradio__svelte__internal, {
  SvelteComponent: BF,
  check_outros: RF,
  claim_component: IF,
  create_component: LF,
  destroy_component: OF,
  detach: qF,
  empty: MF,
  group_outros: NF,
  init: PF,
  insert_hydration: zF,
  mount_component: HF,
  noop: UF,
  safe_not_equal: GF,
  transition_in: VF,
  transition_out: jF
} = window.__gradio__svelte__internal, { createEventDispatcher: WF } = window.__gradio__svelte__internal;
function Ut(a) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; a > 1e3 && t < e.length - 1; )
    a /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(a) ? a : a.toFixed(1)) + n;
}
function In() {
}
const go = typeof window < "u";
let sl = go ? () => window.performance.now() : () => Date.now(), vo = go ? (a) => requestAnimationFrame(a) : In;
const Gt = /* @__PURE__ */ new Set();
function bo(a) {
  Gt.forEach((e) => {
    e.c(a) || (Gt.delete(e), e.f());
  }), Gt.size !== 0 && vo(bo);
}
function qu(a) {
  let e;
  return Gt.size === 0 && vo(bo), { promise: new Promise((t) => {
    Gt.add(e = { c: a, f: t });
  }), abort() {
    Gt.delete(e);
  } };
}
const Ht = [];
function Mu(a, e = In) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(o) {
    if (s = o, ((r = a) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (a = o, t)) {
      const u = !Ht.length;
      for (const c of n) c[1](), Ht.push(c, a);
      if (u) {
        for (let c = 0; c < Ht.length; c += 2) Ht[c][0](Ht[c + 1]);
        Ht.length = 0;
      }
    }
    var r, s;
  }
  function l(o) {
    i(o(a));
  }
  return { set: i, update: l, subscribe: function(o, r = In) {
    const s = [o, r];
    return n.add(s), n.size === 1 && (t = e(i, l) || In), o(a), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ul(a) {
  return Object.prototype.toString.call(a) === "[object Date]";
}
function Oi(a, e, t, n) {
  if (typeof t == "number" || ul(t)) {
    const i = n - t, l = (t - e) / (a.dt || 1 / 60), o = (l + (a.opts.stiffness * i - a.opts.damping * l) * a.inv_mass) * a.dt;
    return Math.abs(o) < a.opts.precision && Math.abs(i) < a.opts.precision ? n : (a.settled = !1, ul(t) ? new Date(t.getTime() + o) : t + o);
  }
  if (Array.isArray(t)) return t.map((i, l) => Oi(a, e[l], t[l], n[l]));
  if (typeof t == "object") {
    const i = {};
    for (const l in t) i[l] = Oi(a, e[l], t[l], n[l]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function cl(a, e = {}) {
  const t = Mu(a), { stiffness: n = 0.15, damping: i = 0.8, precision: l = 0.01 } = e;
  let o, r, s, u = a, c = a, f = 1, d = 0, h = !1;
  function p(v, $ = {}) {
    c = v;
    const g = s = {};
    return a == null || $.hard || b.stiffness >= 1 && b.damping >= 1 ? (h = !0, o = sl(), u = v, t.set(a = c), Promise.resolve()) : ($.soft && (d = 1 / (60 * ($.soft === !0 ? 0.5 : +$.soft)), f = 0), r || (o = sl(), h = !1, r = qu((_) => {
      if (h) return h = !1, r = null, !1;
      f = Math.min(f + d, 1);
      const D = { inv_mass: f, opts: b, settled: !0, dt: 60 * (_ - o) / 1e3 }, y = Oi(D, u, a, c);
      return o = _, u = a, t.set(a = y), D.settled && (r = null), !D.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        g === s && _();
      });
    }));
  }
  const b = { set: p, update: (v, $) => p(v(c, a), $), subscribe: t.subscribe, stiffness: n, damping: i, precision: l };
  return b;
}
const {
  SvelteComponent: Nu,
  append_hydration: We,
  attr: j,
  children: Me,
  claim_element: Pu,
  claim_svg_element: Ze,
  component_subscribe: _l,
  detach: Be,
  element: zu,
  init: Hu,
  insert_hydration: Uu,
  noop: dl,
  safe_not_equal: Gu,
  set_style: Cn,
  svg_element: Ye,
  toggle_class: fl
} = window.__gradio__svelte__internal, { onMount: Vu } = window.__gradio__svelte__internal;
function ju(a) {
  let e, t, n, i, l, o, r, s, u, c, f, d;
  return {
    c() {
      e = zu("div"), t = Ye("svg"), n = Ye("g"), i = Ye("path"), l = Ye("path"), o = Ye("path"), r = Ye("path"), s = Ye("g"), u = Ye("path"), c = Ye("path"), f = Ye("path"), d = Ye("path"), this.h();
    },
    l(h) {
      e = Pu(h, "DIV", { class: !0 });
      var p = Me(e);
      t = Ze(p, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var b = Me(t);
      n = Ze(b, "g", { style: !0 });
      var v = Me(n);
      i = Ze(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Me(i).forEach(Be), l = Ze(v, "path", { d: !0, fill: !0, class: !0 }), Me(l).forEach(Be), o = Ze(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Me(o).forEach(Be), r = Ze(v, "path", { d: !0, fill: !0, class: !0 }), Me(r).forEach(Be), v.forEach(Be), s = Ze(b, "g", { style: !0 });
      var $ = Me(s);
      u = Ze($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Me(u).forEach(Be), c = Ze($, "path", { d: !0, fill: !0, class: !0 }), Me(c).forEach(Be), f = Ze($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Me(f).forEach(Be), d = Ze($, "path", { d: !0, fill: !0, class: !0 }), Me(d).forEach(Be), $.forEach(Be), b.forEach(Be), p.forEach(Be), this.h();
    },
    h() {
      j(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), j(i, "fill", "#FF7C00"), j(i, "fill-opacity", "0.4"), j(i, "class", "svelte-43sxxs"), j(l, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), j(l, "fill", "#FF7C00"), j(l, "class", "svelte-43sxxs"), j(o, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), j(o, "fill", "#FF7C00"), j(o, "fill-opacity", "0.4"), j(o, "class", "svelte-43sxxs"), j(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), j(r, "fill", "#FF7C00"), j(r, "class", "svelte-43sxxs"), Cn(n, "transform", "translate(" + /*$top*/
      a[1][0] + "px, " + /*$top*/
      a[1][1] + "px)"), j(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), j(u, "fill", "#FF7C00"), j(u, "fill-opacity", "0.4"), j(u, "class", "svelte-43sxxs"), j(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), j(c, "fill", "#FF7C00"), j(c, "class", "svelte-43sxxs"), j(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), j(f, "fill", "#FF7C00"), j(f, "fill-opacity", "0.4"), j(f, "class", "svelte-43sxxs"), j(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), j(d, "fill", "#FF7C00"), j(d, "class", "svelte-43sxxs"), Cn(s, "transform", "translate(" + /*$bottom*/
      a[2][0] + "px, " + /*$bottom*/
      a[2][1] + "px)"), j(t, "viewBox", "-1200 -1200 3000 3000"), j(t, "fill", "none"), j(t, "xmlns", "http://www.w3.org/2000/svg"), j(t, "class", "svelte-43sxxs"), j(e, "class", "svelte-43sxxs"), fl(
        e,
        "margin",
        /*margin*/
        a[0]
      );
    },
    m(h, p) {
      Uu(h, e, p), We(e, t), We(t, n), We(n, i), We(n, l), We(n, o), We(n, r), We(t, s), We(s, u), We(s, c), We(s, f), We(s, d);
    },
    p(h, [p]) {
      p & /*$top*/
      2 && Cn(n, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), p & /*$bottom*/
      4 && Cn(s, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), p & /*margin*/
      1 && fl(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: dl,
    o: dl,
    d(h) {
      h && Be(e);
    }
  };
}
function Wu(a, e, t) {
  let n, i;
  var l = this && this.__awaiter || function(h, p, b, v) {
    function $(g) {
      return g instanceof b ? g : new b(function(_) {
        _(g);
      });
    }
    return new (b || (b = Promise))(function(g, _) {
      function D(F) {
        try {
          k(v.next(F));
        } catch (T) {
          _(T);
        }
      }
      function y(F) {
        try {
          k(v.throw(F));
        } catch (T) {
          _(T);
        }
      }
      function k(F) {
        F.done ? g(F.value) : $(F.value).then(D, y);
      }
      k((v = v.apply(h, p || [])).next());
    });
  };
  let { margin: o = !0 } = e;
  const r = cl([0, 0]);
  _l(a, r, (h) => t(1, n = h));
  const s = cl([0, 0]);
  _l(a, s, (h) => t(2, i = h));
  let u;
  function c() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function f() {
    return l(this, void 0, void 0, function* () {
      yield c(), u || f();
    });
  }
  function d() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), f();
    });
  }
  return Vu(() => (d(), () => u = !0)), a.$$set = (h) => {
    "margin" in h && t(0, o = h.margin);
  }, [o, n, i, r, s];
}
class Zu extends Nu {
  constructor(e) {
    super(), Hu(this, e, Wu, ju, Gu, { margin: 0 });
  }
}
const {
  SvelteComponent: Yu,
  append_hydration: Et,
  attr: et,
  binding_callbacks: hl,
  check_outros: qi,
  children: st,
  claim_component: Do,
  claim_element: ut,
  claim_space: ze,
  claim_text: ae,
  create_component: wo,
  create_slot: yo,
  destroy_component: ko,
  destroy_each: $o,
  detach: L,
  element: ct,
  empty: Ue,
  ensure_array_like: Vn,
  get_all_dirty_from_scope: Fo,
  get_slot_changes: Eo,
  group_outros: Mi,
  init: Xu,
  insert_hydration: M,
  mount_component: Co,
  noop: Ni,
  safe_not_equal: Ku,
  set_data: Ge,
  set_style: kt,
  space: He,
  text: le,
  toggle_class: Pe,
  transition_in: Je,
  transition_out: _t,
  update_slot_base: Ao
} = window.__gradio__svelte__internal, { tick: Qu } = window.__gradio__svelte__internal, { onDestroy: Ju } = window.__gradio__svelte__internal, { createEventDispatcher: ec } = window.__gradio__svelte__internal, tc = (a) => ({}), pl = (a) => ({}), nc = (a) => ({}), ml = (a) => ({});
function gl(a, e, t) {
  const n = a.slice();
  return n[40] = e[t], n[42] = t, n;
}
function vl(a, e, t) {
  const n = a.slice();
  return n[40] = e[t], n;
}
function ic(a) {
  let e, t, n, i, l = (
    /*i18n*/
    a[1]("common.error") + ""
  ), o, r, s;
  t = new Du({
    props: {
      Icon: Ur,
      label: (
        /*i18n*/
        a[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    a[32]
  );
  const u = (
    /*#slots*/
    a[30].error
  ), c = yo(
    u,
    a,
    /*$$scope*/
    a[29],
    pl
  );
  return {
    c() {
      e = ct("div"), wo(t.$$.fragment), n = He(), i = ct("span"), o = le(l), r = He(), c && c.c(), this.h();
    },
    l(f) {
      e = ut(f, "DIV", { class: !0 });
      var d = st(e);
      Do(t.$$.fragment, d), d.forEach(L), n = ze(f), i = ut(f, "SPAN", { class: !0 });
      var h = st(i);
      o = ae(h, l), h.forEach(L), r = ze(f), c && c.l(f), this.h();
    },
    h() {
      et(e, "class", "clear-status svelte-17v219f"), et(i, "class", "error svelte-17v219f");
    },
    m(f, d) {
      M(f, e, d), Co(t, e, null), M(f, n, d), M(f, i, d), Et(i, o), M(f, r, d), c && c.m(f, d), s = !0;
    },
    p(f, d) {
      const h = {};
      d[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      f[1]("common.clear")), t.$set(h), (!s || d[0] & /*i18n*/
      2) && l !== (l = /*i18n*/
      f[1]("common.error") + "") && Ge(o, l), c && c.p && (!s || d[0] & /*$$scope*/
      536870912) && Ao(
        c,
        u,
        f,
        /*$$scope*/
        f[29],
        s ? Eo(
          u,
          /*$$scope*/
          f[29],
          d,
          tc
        ) : Fo(
          /*$$scope*/
          f[29]
        ),
        pl
      );
    },
    i(f) {
      s || (Je(t.$$.fragment, f), Je(c, f), s = !0);
    },
    o(f) {
      _t(t.$$.fragment, f), _t(c, f), s = !1;
    },
    d(f) {
      f && (L(e), L(n), L(i), L(r)), ko(t), c && c.d(f);
    }
  };
}
function ac(a) {
  let e, t, n, i, l, o, r, s, u, c = (
    /*variant*/
    a[8] === "default" && /*show_eta_bar*/
    a[18] && /*show_progress*/
    a[6] === "full" && bl(a)
  );
  function f(_, D) {
    if (
      /*progress*/
      _[7]
    ) return rc;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return oc;
    if (
      /*queue_position*/
      _[2] === 0
    ) return lc;
  }
  let d = f(a), h = d && d(a), p = (
    /*timer*/
    a[5] && yl(a)
  );
  const b = [_c, cc], v = [];
  function $(_, D) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(l = $(a)) && (o = v[l] = b[l](a));
  let g = !/*timer*/
  a[5] && Sl(a);
  return {
    c() {
      c && c.c(), e = He(), t = ct("div"), h && h.c(), n = He(), p && p.c(), i = He(), o && o.c(), r = He(), g && g.c(), s = Ue(), this.h();
    },
    l(_) {
      c && c.l(_), e = ze(_), t = ut(_, "DIV", { class: !0 });
      var D = st(t);
      h && h.l(D), n = ze(D), p && p.l(D), D.forEach(L), i = ze(_), o && o.l(_), r = ze(_), g && g.l(_), s = Ue(), this.h();
    },
    h() {
      et(t, "class", "progress-text svelte-17v219f"), Pe(
        t,
        "meta-text-center",
        /*variant*/
        a[8] === "center"
      ), Pe(
        t,
        "meta-text",
        /*variant*/
        a[8] === "default"
      );
    },
    m(_, D) {
      c && c.m(_, D), M(_, e, D), M(_, t, D), h && h.m(t, null), Et(t, n), p && p.m(t, null), M(_, i, D), ~l && v[l].m(_, D), M(_, r, D), g && g.m(_, D), M(_, s, D), u = !0;
    },
    p(_, D) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, D) : (c = bl(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = f(_)) && h ? h.p(_, D) : (h && h.d(1), h = d && d(_), h && (h.c(), h.m(t, n))), /*timer*/
      _[5] ? p ? p.p(_, D) : (p = yl(_), p.c(), p.m(t, null)) : p && (p.d(1), p = null), (!u || D[0] & /*variant*/
      256) && Pe(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || D[0] & /*variant*/
      256) && Pe(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let y = l;
      l = $(_), l === y ? ~l && v[l].p(_, D) : (o && (Mi(), _t(v[y], 1, 1, () => {
        v[y] = null;
      }), qi()), ~l ? (o = v[l], o ? o.p(_, D) : (o = v[l] = b[l](_), o.c()), Je(o, 1), o.m(r.parentNode, r)) : o = null), /*timer*/
      _[5] ? g && (Mi(), _t(g, 1, 1, () => {
        g = null;
      }), qi()) : g ? (g.p(_, D), D[0] & /*timer*/
      32 && Je(g, 1)) : (g = Sl(_), g.c(), Je(g, 1), g.m(s.parentNode, s));
    },
    i(_) {
      u || (Je(o), Je(g), u = !0);
    },
    o(_) {
      _t(o), _t(g), u = !1;
    },
    d(_) {
      _ && (L(e), L(t), L(i), L(r), L(s)), c && c.d(_), h && h.d(), p && p.d(), ~l && v[l].d(_), g && g.d(_);
    }
  };
}
function bl(a) {
  let e, t = `translateX(${/*eta_level*/
  (a[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = ct("div"), this.h();
    },
    l(n) {
      e = ut(n, "DIV", { class: !0 }), st(e).forEach(L), this.h();
    },
    h() {
      et(e, "class", "eta-bar svelte-17v219f"), kt(e, "transform", t);
    },
    m(n, i) {
      M(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && kt(e, "transform", t);
    },
    d(n) {
      n && L(e);
    }
  };
}
function lc(a) {
  let e;
  return {
    c() {
      e = le("processing |");
    },
    l(t) {
      e = ae(t, "processing |");
    },
    m(t, n) {
      M(t, e, n);
    },
    p: Ni,
    d(t) {
      t && L(e);
    }
  };
}
function oc(a) {
  let e, t = (
    /*queue_position*/
    a[2] + 1 + ""
  ), n, i, l, o;
  return {
    c() {
      e = le("queue: "), n = le(t), i = le("/"), l = le(
        /*queue_size*/
        a[3]
      ), o = le(" |");
    },
    l(r) {
      e = ae(r, "queue: "), n = ae(r, t), i = ae(r, "/"), l = ae(
        r,
        /*queue_size*/
        a[3]
      ), o = ae(r, " |");
    },
    m(r, s) {
      M(r, e, s), M(r, n, s), M(r, i, s), M(r, l, s), M(r, o, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && Ge(n, t), s[0] & /*queue_size*/
      8 && Ge(
        l,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (L(e), L(n), L(i), L(l), L(o));
    }
  };
}
function rc(a) {
  let e, t = Vn(
    /*progress*/
    a[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = wl(vl(a, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = Ue();
    },
    l(i) {
      for (let l = 0; l < n.length; l += 1)
        n[l].l(i);
      e = Ue();
    },
    m(i, l) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(i, l);
      M(i, e, l);
    },
    p(i, l) {
      if (l[0] & /*progress*/
      128) {
        t = Vn(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const r = vl(i, t, o);
          n[o] ? n[o].p(r, l) : (n[o] = wl(r), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && L(e), $o(n, i);
    }
  };
}
function Dl(a) {
  let e, t = (
    /*p*/
    a[40].unit + ""
  ), n, i, l = " ", o;
  function r(c, f) {
    return (
      /*p*/
      c[40].length != null ? uc : sc
    );
  }
  let s = r(a), u = s(a);
  return {
    c() {
      u.c(), e = He(), n = le(t), i = le(" | "), o = le(l);
    },
    l(c) {
      u.l(c), e = ze(c), n = ae(c, t), i = ae(c, " | "), o = ae(c, l);
    },
    m(c, f) {
      u.m(c, f), M(c, e, f), M(c, n, f), M(c, i, f), M(c, o, f);
    },
    p(c, f) {
      s === (s = r(c)) && u ? u.p(c, f) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), f[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Ge(n, t);
    },
    d(c) {
      c && (L(e), L(n), L(i), L(o)), u.d(c);
    }
  };
}
function sc(a) {
  let e = Ut(
    /*p*/
    a[40].index || 0
  ) + "", t;
  return {
    c() {
      t = le(e);
    },
    l(n) {
      t = ae(n, e);
    },
    m(n, i) {
      M(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = Ut(
        /*p*/
        n[40].index || 0
      ) + "") && Ge(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function uc(a) {
  let e = Ut(
    /*p*/
    a[40].index || 0
  ) + "", t, n, i = Ut(
    /*p*/
    a[40].length
  ) + "", l;
  return {
    c() {
      t = le(e), n = le("/"), l = le(i);
    },
    l(o) {
      t = ae(o, e), n = ae(o, "/"), l = ae(o, i);
    },
    m(o, r) {
      M(o, t, r), M(o, n, r), M(o, l, r);
    },
    p(o, r) {
      r[0] & /*progress*/
      128 && e !== (e = Ut(
        /*p*/
        o[40].index || 0
      ) + "") && Ge(t, e), r[0] & /*progress*/
      128 && i !== (i = Ut(
        /*p*/
        o[40].length
      ) + "") && Ge(l, i);
    },
    d(o) {
      o && (L(t), L(n), L(l));
    }
  };
}
function wl(a) {
  let e, t = (
    /*p*/
    a[40].index != null && Dl(a)
  );
  return {
    c() {
      t && t.c(), e = Ue();
    },
    l(n) {
      t && t.l(n), e = Ue();
    },
    m(n, i) {
      t && t.m(n, i), M(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].index != null ? t ? t.p(n, i) : (t = Dl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && L(e), t && t.d(n);
    }
  };
}
function yl(a) {
  let e, t = (
    /*eta*/
    a[0] ? `/${/*formatted_eta*/
    a[19]}` : ""
  ), n, i;
  return {
    c() {
      e = le(
        /*formatted_timer*/
        a[20]
      ), n = le(t), i = le("s");
    },
    l(l) {
      e = ae(
        l,
        /*formatted_timer*/
        a[20]
      ), n = ae(l, t), i = ae(l, "s");
    },
    m(l, o) {
      M(l, e, o), M(l, n, o), M(l, i, o);
    },
    p(l, o) {
      o[0] & /*formatted_timer*/
      1048576 && Ge(
        e,
        /*formatted_timer*/
        l[20]
      ), o[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      l[0] ? `/${/*formatted_eta*/
      l[19]}` : "") && Ge(n, t);
    },
    d(l) {
      l && (L(e), L(n), L(i));
    }
  };
}
function cc(a) {
  let e, t;
  return e = new Zu({
    props: { margin: (
      /*variant*/
      a[8] === "default"
    ) }
  }), {
    c() {
      wo(e.$$.fragment);
    },
    l(n) {
      Do(e.$$.fragment, n);
    },
    m(n, i) {
      Co(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i[0] & /*variant*/
      256 && (l.margin = /*variant*/
      n[8] === "default"), e.$set(l);
    },
    i(n) {
      t || (Je(e.$$.fragment, n), t = !0);
    },
    o(n) {
      _t(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ko(e, n);
    }
  };
}
function _c(a) {
  let e, t, n, i, l, o = `${/*last_progress_level*/
  a[15] * 100}%`, r = (
    /*progress*/
    a[7] != null && kl(a)
  );
  return {
    c() {
      e = ct("div"), t = ct("div"), r && r.c(), n = He(), i = ct("div"), l = ct("div"), this.h();
    },
    l(s) {
      e = ut(s, "DIV", { class: !0 });
      var u = st(e);
      t = ut(u, "DIV", { class: !0 });
      var c = st(t);
      r && r.l(c), c.forEach(L), n = ze(u), i = ut(u, "DIV", { class: !0 });
      var f = st(i);
      l = ut(f, "DIV", { class: !0 }), st(l).forEach(L), f.forEach(L), u.forEach(L), this.h();
    },
    h() {
      et(t, "class", "progress-level-inner svelte-17v219f"), et(l, "class", "progress-bar svelte-17v219f"), kt(l, "width", o), et(i, "class", "progress-bar-wrap svelte-17v219f"), et(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      M(s, e, u), Et(e, t), r && r.m(t, null), Et(e, n), Et(e, i), Et(i, l), a[31](l);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = kl(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && o !== (o = `${/*last_progress_level*/
      s[15] * 100}%`) && kt(l, "width", o);
    },
    i: Ni,
    o: Ni,
    d(s) {
      s && L(e), r && r.d(), a[31](null);
    }
  };
}
function kl(a) {
  let e, t = Vn(
    /*progress*/
    a[7]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = Al(gl(a, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = Ue();
    },
    l(i) {
      for (let l = 0; l < n.length; l += 1)
        n[l].l(i);
      e = Ue();
    },
    m(i, l) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(i, l);
      M(i, e, l);
    },
    p(i, l) {
      if (l[0] & /*progress_level, progress*/
      16512) {
        t = Vn(
          /*progress*/
          i[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const r = gl(i, t, o);
          n[o] ? n[o].p(r, l) : (n[o] = Al(r), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && L(e), $o(n, i);
    }
  };
}
function $l(a) {
  let e, t, n, i, l = (
    /*i*/
    a[42] !== 0 && dc()
  ), o = (
    /*p*/
    a[40].desc != null && Fl(a)
  ), r = (
    /*p*/
    a[40].desc != null && /*progress_level*/
    a[14] && /*progress_level*/
    a[14][
      /*i*/
      a[42]
    ] != null && El()
  ), s = (
    /*progress_level*/
    a[14] != null && Cl(a)
  );
  return {
    c() {
      l && l.c(), e = He(), o && o.c(), t = He(), r && r.c(), n = He(), s && s.c(), i = Ue();
    },
    l(u) {
      l && l.l(u), e = ze(u), o && o.l(u), t = ze(u), r && r.l(u), n = ze(u), s && s.l(u), i = Ue();
    },
    m(u, c) {
      l && l.m(u, c), M(u, e, c), o && o.m(u, c), M(u, t, c), r && r.m(u, c), M(u, n, c), s && s.m(u, c), M(u, i, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? o ? o.p(u, c) : (o = Fl(u), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = El(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = Cl(u), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (L(e), L(t), L(n), L(i)), l && l.d(u), o && o.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function dc(a) {
  let e;
  return {
    c() {
      e = le(" /");
    },
    l(t) {
      e = ae(t, " /");
    },
    m(t, n) {
      M(t, e, n);
    },
    d(t) {
      t && L(e);
    }
  };
}
function Fl(a) {
  let e = (
    /*p*/
    a[40].desc + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    l(n) {
      t = ae(n, e);
    },
    m(n, i) {
      M(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Ge(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function El(a) {
  let e;
  return {
    c() {
      e = le("-");
    },
    l(t) {
      e = ae(t, "-");
    },
    m(t, n) {
      M(t, e, n);
    },
    d(t) {
      t && L(e);
    }
  };
}
function Cl(a) {
  let e = (100 * /*progress_level*/
  (a[14][
    /*i*/
    a[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = le(e), n = le("%");
    },
    l(i) {
      t = ae(i, e), n = ae(i, "%");
    },
    m(i, l) {
      M(i, t, l), M(i, n, l);
    },
    p(i, l) {
      l[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && Ge(t, e);
    },
    d(i) {
      i && (L(t), L(n));
    }
  };
}
function Al(a) {
  let e, t = (
    /*p*/
    (a[40].desc != null || /*progress_level*/
    a[14] && /*progress_level*/
    a[14][
      /*i*/
      a[42]
    ] != null) && $l(a)
  );
  return {
    c() {
      t && t.c(), e = Ue();
    },
    l(n) {
      t && t.l(n), e = Ue();
    },
    m(n, i) {
      t && t.m(n, i), M(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, i) : (t = $l(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && L(e), t && t.d(n);
    }
  };
}
function Sl(a) {
  let e, t, n, i;
  const l = (
    /*#slots*/
    a[30]["additional-loading-text"]
  ), o = yo(
    l,
    a,
    /*$$scope*/
    a[29],
    ml
  );
  return {
    c() {
      e = ct("p"), t = le(
        /*loading_text*/
        a[9]
      ), n = He(), o && o.c(), this.h();
    },
    l(r) {
      e = ut(r, "P", { class: !0 });
      var s = st(e);
      t = ae(
        s,
        /*loading_text*/
        a[9]
      ), s.forEach(L), n = ze(r), o && o.l(r), this.h();
    },
    h() {
      et(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      M(r, e, s), Et(e, t), M(r, n, s), o && o.m(r, s), i = !0;
    },
    p(r, s) {
      (!i || s[0] & /*loading_text*/
      512) && Ge(
        t,
        /*loading_text*/
        r[9]
      ), o && o.p && (!i || s[0] & /*$$scope*/
      536870912) && Ao(
        o,
        l,
        r,
        /*$$scope*/
        r[29],
        i ? Eo(
          l,
          /*$$scope*/
          r[29],
          s,
          nc
        ) : Fo(
          /*$$scope*/
          r[29]
        ),
        ml
      );
    },
    i(r) {
      i || (Je(o, r), i = !0);
    },
    o(r) {
      _t(o, r), i = !1;
    },
    d(r) {
      r && (L(e), L(n)), o && o.d(r);
    }
  };
}
function fc(a) {
  let e, t, n, i, l;
  const o = [ac, ic], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(a)) && (n = r[t] = o[t](a)), {
    c() {
      e = ct("div"), n && n.c(), this.h();
    },
    l(u) {
      e = ut(u, "DIV", { class: !0 });
      var c = st(e);
      n && n.l(c), c.forEach(L), this.h();
    },
    h() {
      et(e, "class", i = "wrap " + /*variant*/
      a[8] + " " + /*show_progress*/
      a[6] + " svelte-17v219f"), Pe(e, "hide", !/*status*/
      a[4] || /*status*/
      a[4] === "complete" || /*show_progress*/
      a[6] === "hidden" || /*status*/
      a[4] == "streaming"), Pe(
        e,
        "translucent",
        /*variant*/
        a[8] === "center" && /*status*/
        (a[4] === "pending" || /*status*/
        a[4] === "error") || /*translucent*/
        a[11] || /*show_progress*/
        a[6] === "minimal"
      ), Pe(
        e,
        "generating",
        /*status*/
        a[4] === "generating" && /*show_progress*/
        a[6] === "full"
      ), Pe(
        e,
        "border",
        /*border*/
        a[12]
      ), kt(
        e,
        "position",
        /*absolute*/
        a[10] ? "absolute" : "static"
      ), kt(
        e,
        "padding",
        /*absolute*/
        a[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      M(u, e, c), ~t && r[t].m(e, null), a[33](e), l = !0;
    },
    p(u, c) {
      let f = t;
      t = s(u), t === f ? ~t && r[t].p(u, c) : (n && (Mi(), _t(r[f], 1, 1, () => {
        r[f] = null;
      }), qi()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = o[t](u), n.c()), Je(n, 1), n.m(e, null)) : n = null), (!l || c[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && et(e, "class", i), (!l || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Pe(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!l || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Pe(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!l || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Pe(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!l || c[0] & /*variant, show_progress, border*/
      4416) && Pe(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && kt(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && kt(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      l || (Je(n), l = !0);
    },
    o(u) {
      _t(n), l = !1;
    },
    d(u) {
      u && L(e), ~t && r[t].d(), a[33](null);
    }
  };
}
var hc = function(a, e, t, n) {
  function i(l) {
    return l instanceof t ? l : new t(function(o) {
      o(l);
    });
  }
  return new (t || (t = Promise))(function(l, o) {
    function r(c) {
      try {
        u(n.next(c));
      } catch (f) {
        o(f);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (f) {
        o(f);
      }
    }
    function u(c) {
      c.done ? l(c.value) : i(c.value).then(r, s);
    }
    u((n = n.apply(a, e || [])).next());
  });
};
let An = [], ki = !1;
const pc = typeof window < "u", So = pc ? window.requestAnimationFrame : (a) => {
};
function mc(a) {
  return hc(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (An.push(e), !ki) ki = !0;
      else return;
      yield Qu(), So(() => {
        let n = [0, 0];
        for (let i = 0; i < An.length; i++) {
          const o = An[i].getBoundingClientRect();
          (i === 0 || o.top + window.scrollY <= n[0]) && (n[0] = o.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), ki = !1, An = [];
      });
    }
  });
}
function gc(a, e, t) {
  let n, { $$slots: i = {}, $$scope: l } = e;
  const o = ec();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: f } = e, { scroll_to_output: d = !1 } = e, { timer: h = !0 } = e, { show_progress: p = "full" } = e, { message: b = null } = e, { progress: v = null } = e, { variant: $ = "default" } = e, { loading_text: g = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: D = !1 } = e, { border: y = !1 } = e, { autoscroll: k } = e, F, T = !1, A = 0, B = 0, R = null, P = null, S = 0, te = null, he, ce = null, Oe = !0;
  const Q = () => {
    t(0, s = t(27, R = t(19, w = null))), t(25, A = performance.now()), t(26, B = 0), T = !0, oe();
  };
  function oe() {
    So(() => {
      t(26, B = (performance.now() - A) / 1e3), T && oe();
    });
  }
  function pe() {
    t(26, B = 0), t(0, s = t(27, R = t(19, w = null))), T && (T = !1);
  }
  Ju(() => {
    T && pe();
  });
  let w = null;
  function q(E) {
    hl[E ? "unshift" : "push"](() => {
      ce = E, t(16, ce), t(7, v), t(14, te), t(15, he);
    });
  }
  const z = () => {
    o("clear_status");
  };
  function H(E) {
    hl[E ? "unshift" : "push"](() => {
      F = E, t(13, F);
    });
  }
  return a.$$set = (E) => {
    "i18n" in E && t(1, r = E.i18n), "eta" in E && t(0, s = E.eta), "queue_position" in E && t(2, u = E.queue_position), "queue_size" in E && t(3, c = E.queue_size), "status" in E && t(4, f = E.status), "scroll_to_output" in E && t(22, d = E.scroll_to_output), "timer" in E && t(5, h = E.timer), "show_progress" in E && t(6, p = E.show_progress), "message" in E && t(23, b = E.message), "progress" in E && t(7, v = E.progress), "variant" in E && t(8, $ = E.variant), "loading_text" in E && t(9, g = E.loading_text), "absolute" in E && t(10, _ = E.absolute), "translucent" in E && t(11, D = E.translucent), "border" in E && t(12, y = E.border), "autoscroll" in E && t(24, k = E.autoscroll), "$$scope" in E && t(29, l = E.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = R), s != null && R !== s && (t(28, P = (performance.now() - A) / 1e3 + s), t(19, w = P.toFixed(1)), t(27, R = s))), a.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, S = P === null || P <= 0 || !B ? null : Math.min(B / P, 1)), a.$$.dirty[0] & /*progress*/
    128 && v != null && t(18, Oe = !1), a.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (v != null ? t(14, te = v.map((E) => {
      if (E.index != null && E.length != null)
        return E.index / E.length;
      if (E.progress != null)
        return E.progress;
    })) : t(14, te = null), te ? (t(15, he = te[te.length - 1]), ce && (he === 0 ? t(16, ce.style.transition = "0", ce) : t(16, ce.style.transition = "150ms", ce))) : t(15, he = void 0)), a.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? Q() : pe()), a.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && F && d && (f === "pending" || f === "complete") && mc(F, k), a.$$.dirty[0] & /*status, message*/
    8388624, a.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = B.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    f,
    h,
    p,
    v,
    $,
    g,
    _,
    D,
    y,
    F,
    te,
    he,
    ce,
    S,
    Oe,
    w,
    n,
    o,
    d,
    b,
    k,
    A,
    B,
    R,
    P,
    l,
    i,
    q,
    z,
    H
  ];
}
class vc extends Yu {
  constructor(e) {
    super(), Xu(
      this,
      e,
      gc,
      fc,
      Ku,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: To,
  setPrototypeOf: Tl,
  isFrozen: bc,
  getPrototypeOf: Dc,
  getOwnPropertyDescriptor: wc
} = Object;
let {
  freeze: Ce,
  seal: Ve,
  create: xo
} = Object, {
  apply: Pi,
  construct: zi
} = typeof Reflect < "u" && Reflect;
Ce || (Ce = function(e) {
  return e;
});
Ve || (Ve = function(e) {
  return e;
});
Pi || (Pi = function(e, t, n) {
  return e.apply(t, n);
});
zi || (zi = function(e, t) {
  return new e(...t);
});
const Sn = Ae(Array.prototype.forEach), yc = Ae(Array.prototype.lastIndexOf), xl = Ae(Array.prototype.pop), Xt = Ae(Array.prototype.push), kc = Ae(Array.prototype.splice), Ln = Ae(String.prototype.toLowerCase), $i = Ae(String.prototype.toString), Bl = Ae(String.prototype.match), Kt = Ae(String.prototype.replace), $c = Ae(String.prototype.indexOf), Fc = Ae(String.prototype.trim), Xe = Ae(Object.prototype.hasOwnProperty), $e = Ae(RegExp.prototype.test), Qt = Ec(TypeError);
function Ae(a) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
      n[i - 1] = arguments[i];
    return Pi(a, e, n);
  };
}
function Ec(a) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return zi(a, t);
  };
}
function G(a, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Ln;
  Tl && Tl(a, null);
  let n = e.length;
  for (; n--; ) {
    let i = e[n];
    if (typeof i == "string") {
      const l = t(i);
      l !== i && (bc(e) || (e[n] = l), i = l);
    }
    a[i] = !0;
  }
  return a;
}
function Cc(a) {
  for (let e = 0; e < a.length; e++)
    Xe(a, e) || (a[e] = null);
  return a;
}
function mt(a) {
  const e = xo(null);
  for (const [t, n] of To(a))
    Xe(a, t) && (Array.isArray(n) ? e[t] = Cc(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = mt(n) : e[t] = n);
  return e;
}
function Jt(a, e) {
  for (; a !== null; ) {
    const n = wc(a, e);
    if (n) {
      if (n.get)
        return Ae(n.get);
      if (typeof n.value == "function")
        return Ae(n.value);
    }
    a = Dc(a);
  }
  function t() {
    return null;
  }
  return t;
}
const Rl = Ce(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Fi = Ce(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Ei = Ce(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Ac = Ce(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Ci = Ce(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Sc = Ce(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Il = Ce(["#text"]), Ll = Ce(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Ai = Ce(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Ol = Ce(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Tn = Ce(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Tc = Ve(/\{\{[\w\W]*|[\w\W]*\}\}/gm), xc = Ve(/<%[\w\W]*|[\w\W]*%>/gm), Bc = Ve(/\$\{[\w\W]*/gm), Rc = Ve(/^data-[\-\w.\u00B7-\uFFFF]+$/), Ic = Ve(/^aria-[\-\w]+$/), Bo = Ve(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Lc = Ve(/^(?:\w+script|data):/i), Oc = Ve(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Ro = Ve(/^html$/i), qc = Ve(/^[a-z][.\w]*(-[.\w]+)+$/i);
var ql = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Ic,
  ATTR_WHITESPACE: Oc,
  CUSTOM_ELEMENT: qc,
  DATA_ATTR: Rc,
  DOCTYPE_NAME: Ro,
  ERB_EXPR: xc,
  IS_ALLOWED_URI: Bo,
  IS_SCRIPT_OR_DATA: Lc,
  MUSTACHE_EXPR: Tc,
  TMPLIT_EXPR: Bc
});
const en = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Mc = function() {
  return typeof window > "u" ? null : window;
}, Nc = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const i = "data-tt-policy-suffix";
  t && t.hasAttribute(i) && (n = t.getAttribute(i));
  const l = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(l, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + l + " could not be created."), null;
  }
}, Ml = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Io() {
  let a = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Mc();
  const e = (I) => Io(I);
  if (e.version = "3.2.6", e.removed = [], !a || !a.document || a.document.nodeType !== en.document || !a.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = a;
  const n = t, i = n.currentScript, {
    DocumentFragment: l,
    HTMLTemplateElement: o,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = a.NamedNodeMap || a.MozNamedAttrMap,
    HTMLFormElement: f,
    DOMParser: d,
    trustedTypes: h
  } = a, p = s.prototype, b = Jt(p, "cloneNode"), v = Jt(p, "remove"), $ = Jt(p, "nextSibling"), g = Jt(p, "childNodes"), _ = Jt(p, "parentNode");
  if (typeof o == "function") {
    const I = t.createElement("template");
    I.content && I.content.ownerDocument && (t = I.content.ownerDocument);
  }
  let D, y = "";
  const {
    implementation: k,
    createNodeIterator: F,
    createDocumentFragment: T,
    getElementsByTagName: A
  } = t, {
    importNode: B
  } = n;
  let R = Ml();
  e.isSupported = typeof To == "function" && typeof _ == "function" && k && k.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: P,
    ERB_EXPR: S,
    TMPLIT_EXPR: te,
    DATA_ATTR: he,
    ARIA_ATTR: ce,
    IS_SCRIPT_OR_DATA: Oe,
    ATTR_WHITESPACE: Q,
    CUSTOM_ELEMENT: oe
  } = ql;
  let {
    IS_ALLOWED_URI: pe
  } = ql, w = null;
  const q = G({}, [...Rl, ...Fi, ...Ei, ...Ci, ...Il]);
  let z = null;
  const H = G({}, [...Ll, ...Ai, ...Ol, ...Tn]);
  let E = Object.seal(xo(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), N = null, ne = null, fe = !0, ye = !0, ke = !1, re = !0, qe = !1, bt = !0, Ft = !1, Xn = !1, Kn = !1, Lt = !1, dn = !1, fn = !1, ia = !0, aa = !1;
  const Lo = "user-content-";
  let Qn = !0, Vt = !1, Ot = {}, qt = null;
  const la = G({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let oa = null;
  const ra = G({}, ["audio", "video", "img", "source", "image", "track"]);
  let Jn = null;
  const sa = G({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), hn = "http://www.w3.org/1998/Math/MathML", pn = "http://www.w3.org/2000/svg", dt = "http://www.w3.org/1999/xhtml";
  let Mt = dt, ei = !1, ti = null;
  const Oo = G({}, [hn, pn, dt], $i);
  let mn = G({}, ["mi", "mo", "mn", "ms", "mtext"]), gn = G({}, ["annotation-xml"]);
  const qo = G({}, ["title", "style", "font", "a", "script"]);
  let jt = null;
  const Mo = ["application/xhtml+xml", "text/html"], No = "text/html";
  let _e = null, Nt = null;
  const Po = t.createElement("form"), ua = function(m) {
    return m instanceof RegExp || m instanceof Function;
  }, ni = function() {
    let m = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Nt && Nt === m)) {
      if ((!m || typeof m != "object") && (m = {}), m = mt(m), jt = // eslint-disable-next-line unicorn/prefer-includes
      Mo.indexOf(m.PARSER_MEDIA_TYPE) === -1 ? No : m.PARSER_MEDIA_TYPE, _e = jt === "application/xhtml+xml" ? $i : Ln, w = Xe(m, "ALLOWED_TAGS") ? G({}, m.ALLOWED_TAGS, _e) : q, z = Xe(m, "ALLOWED_ATTR") ? G({}, m.ALLOWED_ATTR, _e) : H, ti = Xe(m, "ALLOWED_NAMESPACES") ? G({}, m.ALLOWED_NAMESPACES, $i) : Oo, Jn = Xe(m, "ADD_URI_SAFE_ATTR") ? G(mt(sa), m.ADD_URI_SAFE_ATTR, _e) : sa, oa = Xe(m, "ADD_DATA_URI_TAGS") ? G(mt(ra), m.ADD_DATA_URI_TAGS, _e) : ra, qt = Xe(m, "FORBID_CONTENTS") ? G({}, m.FORBID_CONTENTS, _e) : la, N = Xe(m, "FORBID_TAGS") ? G({}, m.FORBID_TAGS, _e) : mt({}), ne = Xe(m, "FORBID_ATTR") ? G({}, m.FORBID_ATTR, _e) : mt({}), Ot = Xe(m, "USE_PROFILES") ? m.USE_PROFILES : !1, fe = m.ALLOW_ARIA_ATTR !== !1, ye = m.ALLOW_DATA_ATTR !== !1, ke = m.ALLOW_UNKNOWN_PROTOCOLS || !1, re = m.ALLOW_SELF_CLOSE_IN_ATTR !== !1, qe = m.SAFE_FOR_TEMPLATES || !1, bt = m.SAFE_FOR_XML !== !1, Ft = m.WHOLE_DOCUMENT || !1, Lt = m.RETURN_DOM || !1, dn = m.RETURN_DOM_FRAGMENT || !1, fn = m.RETURN_TRUSTED_TYPE || !1, Kn = m.FORCE_BODY || !1, ia = m.SANITIZE_DOM !== !1, aa = m.SANITIZE_NAMED_PROPS || !1, Qn = m.KEEP_CONTENT !== !1, Vt = m.IN_PLACE || !1, pe = m.ALLOWED_URI_REGEXP || Bo, Mt = m.NAMESPACE || dt, mn = m.MATHML_TEXT_INTEGRATION_POINTS || mn, gn = m.HTML_INTEGRATION_POINTS || gn, E = m.CUSTOM_ELEMENT_HANDLING || {}, m.CUSTOM_ELEMENT_HANDLING && ua(m.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (E.tagNameCheck = m.CUSTOM_ELEMENT_HANDLING.tagNameCheck), m.CUSTOM_ELEMENT_HANDLING && ua(m.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (E.attributeNameCheck = m.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), m.CUSTOM_ELEMENT_HANDLING && typeof m.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (E.allowCustomizedBuiltInElements = m.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), qe && (ye = !1), dn && (Lt = !0), Ot && (w = G({}, Il), z = [], Ot.html === !0 && (G(w, Rl), G(z, Ll)), Ot.svg === !0 && (G(w, Fi), G(z, Ai), G(z, Tn)), Ot.svgFilters === !0 && (G(w, Ei), G(z, Ai), G(z, Tn)), Ot.mathMl === !0 && (G(w, Ci), G(z, Ol), G(z, Tn))), m.ADD_TAGS && (w === q && (w = mt(w)), G(w, m.ADD_TAGS, _e)), m.ADD_ATTR && (z === H && (z = mt(z)), G(z, m.ADD_ATTR, _e)), m.ADD_URI_SAFE_ATTR && G(Jn, m.ADD_URI_SAFE_ATTR, _e), m.FORBID_CONTENTS && (qt === la && (qt = mt(qt)), G(qt, m.FORBID_CONTENTS, _e)), Qn && (w["#text"] = !0), Ft && G(w, ["html", "head", "body"]), w.table && (G(w, ["tbody"]), delete N.tbody), m.TRUSTED_TYPES_POLICY) {
        if (typeof m.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Qt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof m.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Qt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        D = m.TRUSTED_TYPES_POLICY, y = D.createHTML("");
      } else
        D === void 0 && (D = Nc(h, i)), D !== null && typeof y == "string" && (y = D.createHTML(""));
      Ce && Ce(m), Nt = m;
    }
  }, ca = G({}, [...Fi, ...Ei, ...Ac]), _a = G({}, [...Ci, ...Sc]), zo = function(m) {
    let C = _(m);
    (!C || !C.tagName) && (C = {
      namespaceURI: Mt,
      tagName: "template"
    });
    const x = Ln(m.tagName), ee = Ln(C.tagName);
    return ti[m.namespaceURI] ? m.namespaceURI === pn ? C.namespaceURI === dt ? x === "svg" : C.namespaceURI === hn ? x === "svg" && (ee === "annotation-xml" || mn[ee]) : !!ca[x] : m.namespaceURI === hn ? C.namespaceURI === dt ? x === "math" : C.namespaceURI === pn ? x === "math" && gn[ee] : !!_a[x] : m.namespaceURI === dt ? C.namespaceURI === pn && !gn[ee] || C.namespaceURI === hn && !mn[ee] ? !1 : !_a[x] && (qo[x] || !ca[x]) : !!(jt === "application/xhtml+xml" && ti[m.namespaceURI]) : !1;
  }, tt = function(m) {
    Xt(e.removed, {
      element: m
    });
    try {
      _(m).removeChild(m);
    } catch {
      v(m);
    }
  }, Pt = function(m, C) {
    try {
      Xt(e.removed, {
        attribute: C.getAttributeNode(m),
        from: C
      });
    } catch {
      Xt(e.removed, {
        attribute: null,
        from: C
      });
    }
    if (C.removeAttribute(m), m === "is")
      if (Lt || dn)
        try {
          tt(C);
        } catch {
        }
      else
        try {
          C.setAttribute(m, "");
        } catch {
        }
  }, da = function(m) {
    let C = null, x = null;
    if (Kn)
      m = "<remove></remove>" + m;
    else {
      const se = Bl(m, /^[\r\n\t ]+/);
      x = se && se[0];
    }
    jt === "application/xhtml+xml" && Mt === dt && (m = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + m + "</body></html>");
    const ee = D ? D.createHTML(m) : m;
    if (Mt === dt)
      try {
        C = new d().parseFromString(ee, jt);
      } catch {
      }
    if (!C || !C.documentElement) {
      C = k.createDocument(Mt, "template", null);
      try {
        C.documentElement.innerHTML = ei ? y : ee;
      } catch {
      }
    }
    const me = C.body || C.documentElement;
    return m && x && me.insertBefore(t.createTextNode(x), me.childNodes[0] || null), Mt === dt ? A.call(C, Ft ? "html" : "body")[0] : Ft ? C.documentElement : me;
  }, fa = function(m) {
    return F.call(
      m.ownerDocument || m,
      m,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, ii = function(m) {
    return m instanceof f && (typeof m.nodeName != "string" || typeof m.textContent != "string" || typeof m.removeChild != "function" || !(m.attributes instanceof c) || typeof m.removeAttribute != "function" || typeof m.setAttribute != "function" || typeof m.namespaceURI != "string" || typeof m.insertBefore != "function" || typeof m.hasChildNodes != "function");
  }, ha = function(m) {
    return typeof r == "function" && m instanceof r;
  };
  function ft(I, m, C) {
    Sn(I, (x) => {
      x.call(e, m, C, Nt);
    });
  }
  const pa = function(m) {
    let C = null;
    if (ft(R.beforeSanitizeElements, m, null), ii(m))
      return tt(m), !0;
    const x = _e(m.nodeName);
    if (ft(R.uponSanitizeElement, m, {
      tagName: x,
      allowedTags: w
    }), bt && m.hasChildNodes() && !ha(m.firstElementChild) && $e(/<[/\w!]/g, m.innerHTML) && $e(/<[/\w!]/g, m.textContent) || m.nodeType === en.progressingInstruction || bt && m.nodeType === en.comment && $e(/<[/\w]/g, m.data))
      return tt(m), !0;
    if (!w[x] || N[x]) {
      if (!N[x] && ga(x) && (E.tagNameCheck instanceof RegExp && $e(E.tagNameCheck, x) || E.tagNameCheck instanceof Function && E.tagNameCheck(x)))
        return !1;
      if (Qn && !qt[x]) {
        const ee = _(m) || m.parentNode, me = g(m) || m.childNodes;
        if (me && ee) {
          const se = me.length;
          for (let Se = se - 1; Se >= 0; --Se) {
            const ht = b(me[Se], !0);
            ht.__removalCount = (m.__removalCount || 0) + 1, ee.insertBefore(ht, $(m));
          }
        }
      }
      return tt(m), !0;
    }
    return m instanceof s && !zo(m) || (x === "noscript" || x === "noembed" || x === "noframes") && $e(/<\/no(script|embed|frames)/i, m.innerHTML) ? (tt(m), !0) : (qe && m.nodeType === en.text && (C = m.textContent, Sn([P, S, te], (ee) => {
      C = Kt(C, ee, " ");
    }), m.textContent !== C && (Xt(e.removed, {
      element: m.cloneNode()
    }), m.textContent = C)), ft(R.afterSanitizeElements, m, null), !1);
  }, ma = function(m, C, x) {
    if (ia && (C === "id" || C === "name") && (x in t || x in Po))
      return !1;
    if (!(ye && !ne[C] && $e(he, C))) {
      if (!(fe && $e(ce, C))) {
        if (!z[C] || ne[C]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(ga(m) && (E.tagNameCheck instanceof RegExp && $e(E.tagNameCheck, m) || E.tagNameCheck instanceof Function && E.tagNameCheck(m)) && (E.attributeNameCheck instanceof RegExp && $e(E.attributeNameCheck, C) || E.attributeNameCheck instanceof Function && E.attributeNameCheck(C)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            C === "is" && E.allowCustomizedBuiltInElements && (E.tagNameCheck instanceof RegExp && $e(E.tagNameCheck, x) || E.tagNameCheck instanceof Function && E.tagNameCheck(x)))
          ) return !1;
        } else if (!Jn[C]) {
          if (!$e(pe, Kt(x, Q, ""))) {
            if (!((C === "src" || C === "xlink:href" || C === "href") && m !== "script" && $c(x, "data:") === 0 && oa[m])) {
              if (!(ke && !$e(Oe, Kt(x, Q, "")))) {
                if (x)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, ga = function(m) {
    return m !== "annotation-xml" && Bl(m, oe);
  }, va = function(m) {
    ft(R.beforeSanitizeAttributes, m, null);
    const {
      attributes: C
    } = m;
    if (!C || ii(m))
      return;
    const x = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: z,
      forceKeepAttr: void 0
    };
    let ee = C.length;
    for (; ee--; ) {
      const me = C[ee], {
        name: se,
        namespaceURI: Se,
        value: ht
      } = me, Wt = _e(se), ai = ht;
      let ge = se === "value" ? ai : Fc(ai);
      if (x.attrName = Wt, x.attrValue = ge, x.keepAttr = !0, x.forceKeepAttr = void 0, ft(R.uponSanitizeAttribute, m, x), ge = x.attrValue, aa && (Wt === "id" || Wt === "name") && (Pt(se, m), ge = Lo + ge), bt && $e(/((--!?|])>)|<\/(style|title)/i, ge)) {
        Pt(se, m);
        continue;
      }
      if (x.forceKeepAttr)
        continue;
      if (!x.keepAttr) {
        Pt(se, m);
        continue;
      }
      if (!re && $e(/\/>/i, ge)) {
        Pt(se, m);
        continue;
      }
      qe && Sn([P, S, te], (Da) => {
        ge = Kt(ge, Da, " ");
      });
      const ba = _e(m.nodeName);
      if (!ma(ba, Wt, ge)) {
        Pt(se, m);
        continue;
      }
      if (D && typeof h == "object" && typeof h.getAttributeType == "function" && !Se)
        switch (h.getAttributeType(ba, Wt)) {
          case "TrustedHTML": {
            ge = D.createHTML(ge);
            break;
          }
          case "TrustedScriptURL": {
            ge = D.createScriptURL(ge);
            break;
          }
        }
      if (ge !== ai)
        try {
          Se ? m.setAttributeNS(Se, se, ge) : m.setAttribute(se, ge), ii(m) ? tt(m) : xl(e.removed);
        } catch {
          Pt(se, m);
        }
    }
    ft(R.afterSanitizeAttributes, m, null);
  }, Ho = function I(m) {
    let C = null;
    const x = fa(m);
    for (ft(R.beforeSanitizeShadowDOM, m, null); C = x.nextNode(); )
      ft(R.uponSanitizeShadowNode, C, null), pa(C), va(C), C.content instanceof l && I(C.content);
    ft(R.afterSanitizeShadowDOM, m, null);
  };
  return e.sanitize = function(I) {
    let m = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, C = null, x = null, ee = null, me = null;
    if (ei = !I, ei && (I = "<!-->"), typeof I != "string" && !ha(I))
      if (typeof I.toString == "function") {
        if (I = I.toString(), typeof I != "string")
          throw Qt("dirty is not a string, aborting");
      } else
        throw Qt("toString is not a function");
    if (!e.isSupported)
      return I;
    if (Xn || ni(m), e.removed = [], typeof I == "string" && (Vt = !1), Vt) {
      if (I.nodeName) {
        const ht = _e(I.nodeName);
        if (!w[ht] || N[ht])
          throw Qt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (I instanceof r)
      C = da("<!---->"), x = C.ownerDocument.importNode(I, !0), x.nodeType === en.element && x.nodeName === "BODY" || x.nodeName === "HTML" ? C = x : C.appendChild(x);
    else {
      if (!Lt && !qe && !Ft && // eslint-disable-next-line unicorn/prefer-includes
      I.indexOf("<") === -1)
        return D && fn ? D.createHTML(I) : I;
      if (C = da(I), !C)
        return Lt ? null : fn ? y : "";
    }
    C && Kn && tt(C.firstChild);
    const se = fa(Vt ? I : C);
    for (; ee = se.nextNode(); )
      pa(ee), va(ee), ee.content instanceof l && Ho(ee.content);
    if (Vt)
      return I;
    if (Lt) {
      if (dn)
        for (me = T.call(C.ownerDocument); C.firstChild; )
          me.appendChild(C.firstChild);
      else
        me = C;
      return (z.shadowroot || z.shadowrootmode) && (me = B.call(n, me, !0)), me;
    }
    let Se = Ft ? C.outerHTML : C.innerHTML;
    return Ft && w["!doctype"] && C.ownerDocument && C.ownerDocument.doctype && C.ownerDocument.doctype.name && $e(Ro, C.ownerDocument.doctype.name) && (Se = "<!DOCTYPE " + C.ownerDocument.doctype.name + `>
` + Se), qe && Sn([P, S, te], (ht) => {
      Se = Kt(Se, ht, " ");
    }), D && fn ? D.createHTML(Se) : Se;
  }, e.setConfig = function() {
    let I = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    ni(I), Xn = !0;
  }, e.clearConfig = function() {
    Nt = null, Xn = !1;
  }, e.isValidAttribute = function(I, m, C) {
    Nt || ni({});
    const x = _e(I), ee = _e(m);
    return ma(x, ee, C);
  }, e.addHook = function(I, m) {
    typeof m == "function" && Xt(R[I], m);
  }, e.removeHook = function(I, m) {
    if (m !== void 0) {
      const C = yc(R[I], m);
      return C === -1 ? void 0 : kc(R[I], C, 1)[0];
    }
    return xl(R[I]);
  }, e.removeHooks = function(I) {
    R[I] = [];
  }, e.removeAllHooks = function() {
    R = Ml();
  }, e;
}
Io();
const {
  HtmlTagHydration: ZF,
  SvelteComponent: YF,
  add_render_callback: XF,
  append_hydration: KF,
  attr: QF,
  bubble: JF,
  check_outros: eE,
  children: tE,
  claim_component: nE,
  claim_element: iE,
  claim_html_tag: aE,
  claim_space: lE,
  claim_text: oE,
  create_component: rE,
  create_in_transition: sE,
  create_out_transition: uE,
  destroy_component: cE,
  detach: _E,
  element: dE,
  get_svelte_dataset: fE,
  group_outros: hE,
  init: pE,
  insert_hydration: mE,
  listen: gE,
  mount_component: vE,
  run_all: bE,
  safe_not_equal: DE,
  set_data: wE,
  space: yE,
  stop_propagation: kE,
  text: $E,
  toggle_class: FE,
  transition_in: EE,
  transition_out: CE
} = window.__gradio__svelte__internal, { createEventDispatcher: AE, onMount: SE } = window.__gradio__svelte__internal, {
  SvelteComponent: TE,
  append_hydration: xE,
  attr: BE,
  bubble: RE,
  check_outros: IE,
  children: LE,
  claim_component: OE,
  claim_element: qE,
  claim_space: ME,
  create_animation: NE,
  create_component: PE,
  destroy_component: zE,
  detach: HE,
  element: UE,
  ensure_array_like: GE,
  fix_and_outro_and_destroy_block: VE,
  fix_position: jE,
  group_outros: WE,
  init: ZE,
  insert_hydration: YE,
  mount_component: XE,
  noop: KE,
  safe_not_equal: QE,
  set_style: JE,
  space: eC,
  transition_in: tC,
  transition_out: nC,
  update_keyed_each: iC
} = window.__gradio__svelte__internal, {
  SvelteComponent: aC,
  attr: lC,
  children: oC,
  claim_element: rC,
  detach: sC,
  element: uC,
  empty: cC,
  init: _C,
  insert_hydration: dC,
  noop: fC,
  safe_not_equal: hC,
  set_style: pC
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pc,
  assign: zc,
  check_outros: Hi,
  claim_component: xt,
  claim_space: Nl,
  create_component: Bt,
  destroy_component: Rt,
  detach: On,
  empty: jn,
  get_spread_object: Hc,
  get_spread_update: Uc,
  group_outros: Ui,
  init: Gc,
  insert_hydration: qn,
  mount_component: It,
  safe_not_equal: Vc,
  space: Pl,
  transition_in: Te,
  transition_out: Le
} = window.__gradio__svelte__internal;
function zl(a) {
  let e, t;
  return e = new nu({
    props: {
      Icon: ao,
      label: (
        /*label*/
        a[11]
      ),
      float: !1,
      disable: (
        /*container*/
        a[12] === !1
      ),
      show_label: (
        /*show_label*/
        a[15]
      ),
      rtl: (
        /*rtl*/
        a[16]
      )
    }
  }), {
    c() {
      Bt(e.$$.fragment);
    },
    l(n) {
      xt(e.$$.fragment, n);
    },
    m(n, i) {
      It(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*label*/
      2048 && (l.label = /*label*/
      n[11]), i & /*container*/
      4096 && (l.disable = /*container*/
      n[12] === !1), i & /*show_label*/
      32768 && (l.show_label = /*show_label*/
      n[15]), i & /*rtl*/
      65536 && (l.rtl = /*rtl*/
      n[16]), e.$set(l);
    },
    i(n) {
      t || (Te(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Le(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Rt(e, n);
    }
  };
}
function jc(a) {
  let e, t;
  return e = new Lu({
    props: {
      $$slots: { default: [Zc] },
      $$scope: { ctx: a }
    }
  }), {
    c() {
      Bt(e.$$.fragment);
    },
    l(n) {
      xt(e.$$.fragment, n);
    },
    m(n, i) {
      It(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*$$scope*/
      67108864 && (l.$$scope = { dirty: i, ctx: n }), e.$set(l);
    },
    i(n) {
      t || (Te(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Le(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Rt(e, n);
    }
  };
}
function Wc(a) {
  let e, t, n, i;
  const l = [Xc, Yc], o = [];
  function r(s, u) {
    return (
      /*interactive*/
      s[10] ? 0 : 1
    );
  }
  return e = r(a), t = o[e] = l[e](a), {
    c() {
      t.c(), n = jn();
    },
    l(s) {
      t.l(s), n = jn();
    },
    m(s, u) {
      o[e].m(s, u), qn(s, n, u), i = !0;
    },
    p(s, u) {
      let c = e;
      e = r(s), e === c ? o[e].p(s, u) : (Ui(), Le(o[c], 1, 1, () => {
        o[c] = null;
      }), Hi(), t = o[e], t ? t.p(s, u) : (t = o[e] = l[e](s), t.c()), Te(t, 1), t.m(n.parentNode, n));
    },
    i(s) {
      i || (Te(t), i = !0);
    },
    o(s) {
      Le(t), i = !1;
    },
    d(s) {
      s && On(n), o[e].d(s);
    }
  };
}
function Zc(a) {
  let e, t;
  return e = new ao({}), {
    c() {
      Bt(e.$$.fragment);
    },
    l(n) {
      xt(e.$$.fragment, n);
    },
    m(n, i) {
      It(e, n, i), t = !0;
    },
    i(n) {
      t || (Te(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Le(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Rt(e, n);
    }
  };
}
function Yc(a) {
  let e, t;
  return e = new qr({
    props: {
      markdown_content: (
        /*value*/
        a[0].markdown_content
      ),
      highlights: (
        /*value*/
        a[0].highlights || []
      ),
      show_side_panel: (
        /*show_side_panel*/
        a[5]
      ),
      panel_width: (
        /*panel_width*/
        a[6]
      )
    }
  }), e.$on(
    "select",
    /*select_handler_1*/
    a[25]
  ), {
    c() {
      Bt(e.$$.fragment);
    },
    l(n) {
      xt(e.$$.fragment, n);
    },
    m(n, i) {
      It(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*value*/
      1 && (l.markdown_content = /*value*/
      n[0].markdown_content), i & /*value*/
      1 && (l.highlights = /*value*/
      n[0].highlights || []), i & /*show_side_panel*/
      32 && (l.show_side_panel = /*show_side_panel*/
      n[5]), i & /*panel_width*/
      64 && (l.panel_width = /*panel_width*/
      n[6]), e.$set(l);
    },
    i(n) {
      t || (Te(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Le(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Rt(e, n);
    }
  };
}
function Xc(a) {
  let e, t;
  return e = new hs({
    props: {
      markdown_content: (
        /*value*/
        a[0].markdown_content
      ),
      highlights: (
        /*value*/
        a[0].highlights || []
      ),
      show_side_panel: (
        /*show_side_panel*/
        a[5]
      ),
      panel_width: (
        /*panel_width*/
        a[6]
      ),
      edit_mode: (
        /*edit_mode*/
        a[7]
      ),
      show_preview: (
        /*show_preview*/
        a[8]
      ),
      markdown_editor: (
        /*markdown_editor*/
        a[9]
      ),
      interactive: (
        /*interactive*/
        a[10]
      )
    }
  }), e.$on(
    "select",
    /*select_handler*/
    a[20]
  ), e.$on(
    "change",
    /*change_handler*/
    a[21]
  ), e.$on(
    "edit",
    /*edit_handler*/
    a[22]
  ), e.$on(
    "save",
    /*save_handler*/
    a[23]
  ), e.$on(
    "cancel",
    /*cancel_handler*/
    a[24]
  ), {
    c() {
      Bt(e.$$.fragment);
    },
    l(n) {
      xt(e.$$.fragment, n);
    },
    m(n, i) {
      It(e, n, i), t = !0;
    },
    p(n, i) {
      const l = {};
      i & /*value*/
      1 && (l.markdown_content = /*value*/
      n[0].markdown_content), i & /*value*/
      1 && (l.highlights = /*value*/
      n[0].highlights || []), i & /*show_side_panel*/
      32 && (l.show_side_panel = /*show_side_panel*/
      n[5]), i & /*panel_width*/
      64 && (l.panel_width = /*panel_width*/
      n[6]), i & /*edit_mode*/
      128 && (l.edit_mode = /*edit_mode*/
      n[7]), i & /*show_preview*/
      256 && (l.show_preview = /*show_preview*/
      n[8]), i & /*markdown_editor*/
      512 && (l.markdown_editor = /*markdown_editor*/
      n[9]), i & /*interactive*/
      1024 && (l.interactive = /*interactive*/
      n[10]), e.$set(l);
    },
    i(n) {
      t || (Te(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Le(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Rt(e, n);
    }
  };
}
function Kc(a) {
  let e, t, n, i, l, o, r;
  const s = [
    { autoscroll: (
      /*gradio*/
      a[1].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      a[1].i18n
    ) },
    /*loading_status*/
    a[17]
  ];
  let u = {};
  for (let p = 0; p < s.length; p += 1)
    u = zc(u, s[p]);
  e = new vc({ props: u }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    a[19]
  );
  let c = (
    /*label*/
    a[11] && /*show_label*/
    a[15] && zl(a)
  );
  const f = [Wc, jc], d = [];
  function h(p, b) {
    return (
      /*value*/
      p[0] && /*value*/
      p[0].markdown_content ? 0 : 1
    );
  }
  return i = h(a), l = d[i] = f[i](a), {
    c() {
      Bt(e.$$.fragment), t = Pl(), c && c.c(), n = Pl(), l.c(), o = jn();
    },
    l(p) {
      xt(e.$$.fragment, p), t = Nl(p), c && c.l(p), n = Nl(p), l.l(p), o = jn();
    },
    m(p, b) {
      It(e, p, b), qn(p, t, b), c && c.m(p, b), qn(p, n, b), d[i].m(p, b), qn(p, o, b), r = !0;
    },
    p(p, b) {
      const v = b & /*gradio, loading_status*/
      131074 ? Uc(s, [
        b & /*gradio*/
        2 && { autoscroll: (
          /*gradio*/
          p[1].autoscroll
        ) },
        b & /*gradio*/
        2 && { i18n: (
          /*gradio*/
          p[1].i18n
        ) },
        b & /*loading_status*/
        131072 && Hc(
          /*loading_status*/
          p[17]
        )
      ]) : {};
      e.$set(v), /*label*/
      p[11] && /*show_label*/
      p[15] ? c ? (c.p(p, b), b & /*label, show_label*/
      34816 && Te(c, 1)) : (c = zl(p), c.c(), Te(c, 1), c.m(n.parentNode, n)) : c && (Ui(), Le(c, 1, 1, () => {
        c = null;
      }), Hi());
      let $ = i;
      i = h(p), i === $ ? d[i].p(p, b) : (Ui(), Le(d[$], 1, 1, () => {
        d[$] = null;
      }), Hi(), l = d[i], l ? l.p(p, b) : (l = d[i] = f[i](p), l.c()), Te(l, 1), l.m(o.parentNode, o));
    },
    i(p) {
      r || (Te(e.$$.fragment, p), Te(c), Te(l), r = !0);
    },
    o(p) {
      Le(e.$$.fragment, p), Le(c), Le(l), r = !1;
    },
    d(p) {
      p && (On(t), On(n), On(o)), Rt(e, p), c && c.d(p), d[i].d(p);
    }
  };
}
function Qc(a) {
  let e, t;
  return e = new Ts({
    props: {
      variant: "solid",
      test_id: "markdown-label",
      visible: (
        /*visible*/
        a[4]
      ),
      elem_id: (
        /*elem_id*/
        a[2]
      ),
      elem_classes: (
        /*elem_classes*/
        a[3]
      ),
      padding: !1,
      container: (
        /*container*/
        a[12]
      ),
      scale: (
        /*scale*/
        a[13]
      ),
      min_width: (
        /*min_width*/
        a[14]
      ),
      rtl: (
        /*rtl*/
        a[16]
      ),
      $$slots: { default: [Kc] },
      $$scope: { ctx: a }
    }
  }), {
    c() {
      Bt(e.$$.fragment);
    },
    l(n) {
      xt(e.$$.fragment, n);
    },
    m(n, i) {
      It(e, n, i), t = !0;
    },
    p(n, [i]) {
      const l = {};
      i & /*visible*/
      16 && (l.visible = /*visible*/
      n[4]), i & /*elem_id*/
      4 && (l.elem_id = /*elem_id*/
      n[2]), i & /*elem_classes*/
      8 && (l.elem_classes = /*elem_classes*/
      n[3]), i & /*container*/
      4096 && (l.container = /*container*/
      n[12]), i & /*scale*/
      8192 && (l.scale = /*scale*/
      n[13]), i & /*min_width*/
      16384 && (l.min_width = /*min_width*/
      n[14]), i & /*rtl*/
      65536 && (l.rtl = /*rtl*/
      n[16]), i & /*$$scope, value, show_side_panel, panel_width, edit_mode, show_preview, markdown_editor, interactive, gradio, label, container, show_label, rtl, loading_status*/
      67346403 && (l.$$scope = { dirty: i, ctx: n }), e.$set(l);
    },
    i(n) {
      t || (Te(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Le(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Rt(e, n);
    }
  };
}
function Jc(a, e, t) {
  let { gradio: n } = e, { elem_id: i = "" } = e, { elem_classes: l = [] } = e, { visible: o = !0 } = e, { value: r = null } = e, s, { show_side_panel: u = !0 } = e, { panel_width: c = "300px" } = e, { edit_mode: f = "split" } = e, { show_preview: d = !0 } = e, { markdown_editor: h = "textarea" } = e, { interactive: p = !1 } = e, { label: b = n.i18n("markdown_label.markdown_label") } = e, { container: v = !0 } = e, { scale: $ = null } = e, { min_width: g = void 0 } = e, { show_label: _ = !0 } = e, { rtl: D = !1 } = e, { loading_status: y } = e;
  const k = () => n.dispatch("clear_status", y), F = ({ detail: S }) => n.dispatch("select", S), T = ({ detail: S }) => {
    t(0, r = S), n.dispatch("change");
  }, A = ({ detail: S }) => n.dispatch("edit", S), B = ({ detail: S }) => {
    t(0, r = S), n.dispatch("submit", S);
  }, R = ({ detail: S }) => n.dispatch("clear", S), P = ({ detail: S }) => n.dispatch("select", S);
  return a.$$set = (S) => {
    "gradio" in S && t(1, n = S.gradio), "elem_id" in S && t(2, i = S.elem_id), "elem_classes" in S && t(3, l = S.elem_classes), "visible" in S && t(4, o = S.visible), "value" in S && t(0, r = S.value), "show_side_panel" in S && t(5, u = S.show_side_panel), "panel_width" in S && t(6, c = S.panel_width), "edit_mode" in S && t(7, f = S.edit_mode), "show_preview" in S && t(8, d = S.show_preview), "markdown_editor" in S && t(9, h = S.markdown_editor), "interactive" in S && t(10, p = S.interactive), "label" in S && t(11, b = S.label), "container" in S && t(12, v = S.container), "scale" in S && t(13, $ = S.scale), "min_width" in S && t(14, g = S.min_width), "show_label" in S && t(15, _ = S.show_label), "rtl" in S && t(16, D = S.rtl), "loading_status" in S && t(17, y = S.loading_status);
  }, a.$$.update = () => {
    a.$$.dirty & /*value, old_value, gradio*/
    262147 && r !== s && (t(18, s = r), n.dispatch("change"));
  }, [
    r,
    n,
    i,
    l,
    o,
    u,
    c,
    f,
    d,
    h,
    p,
    b,
    v,
    $,
    g,
    _,
    D,
    y,
    s,
    k,
    F,
    T,
    A,
    B,
    R,
    P
  ];
}
class mC extends Pc {
  constructor(e) {
    super(), Gc(this, e, Jc, Qc, Vc, {
      gradio: 1,
      elem_id: 2,
      elem_classes: 3,
      visible: 4,
      value: 0,
      show_side_panel: 5,
      panel_width: 6,
      edit_mode: 7,
      show_preview: 8,
      markdown_editor: 9,
      interactive: 10,
      label: 11,
      container: 12,
      scale: 13,
      min_width: 14,
      show_label: 15,
      rtl: 16,
      loading_status: 17
    });
  }
}
export {
  hs as BaseEditableMarkdownRenderer,
  qr as BaseMarkdownRenderer,
  mC as default
};
