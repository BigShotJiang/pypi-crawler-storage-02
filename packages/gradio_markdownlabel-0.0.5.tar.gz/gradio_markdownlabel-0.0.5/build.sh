#!/bin/bash

gradio cc build --no-generate-docs --bump-version
