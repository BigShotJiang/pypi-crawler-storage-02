function(keys, values, rereduce) {
  return null;
}