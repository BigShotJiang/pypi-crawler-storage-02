"""Models defined in fabricatio-diff."""
