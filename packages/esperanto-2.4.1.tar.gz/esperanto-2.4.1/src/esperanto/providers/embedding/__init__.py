"""Embedding providers module."""

from esperanto.providers.embedding.base import EmbeddingModel

__all__ = ["EmbeddingModel"]
