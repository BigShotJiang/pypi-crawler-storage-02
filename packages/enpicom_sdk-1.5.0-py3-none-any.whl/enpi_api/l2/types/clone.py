from typing import NewType

CloneId = NewType("CloneId", str)
"""The unique identifier of a clone"""
