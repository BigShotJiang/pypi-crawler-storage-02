"""@private
Nothing in this module is useful for customers to invoke directly, hide it from the docs.
"""
