from . import settings
from .cosem_interface_classes import collection
from importlib.metadata import version
from .pardata import ParData

__version__ = version("DLMS_SPODES")
