# fastnn/__init__.py
from .DataLoader import NNPrinter

__all__ = ["NNPrinter"]
