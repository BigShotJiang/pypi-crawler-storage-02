// src/domain/interpolation/mod.rs
pub mod errors;
pub mod interface;
