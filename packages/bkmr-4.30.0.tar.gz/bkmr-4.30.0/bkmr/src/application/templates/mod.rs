// src/application/templates/mod.rs
pub mod bookmark_template;
