class ToolProviderCredentialValidationError(Exception):
    pass


class ToolProviderOAuthError(Exception):
    pass
