from midil.cli.main import cli

__all__ = ["cli"]
