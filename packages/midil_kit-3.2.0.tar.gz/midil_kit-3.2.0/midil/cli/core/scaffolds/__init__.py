from midil.cli.core.scaffolds.factory import scaffold_project

__all__ = ["scaffold_project"]
