from rich.console import Console

console = Console()

__all__ = ["console"]
