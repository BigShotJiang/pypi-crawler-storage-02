"""
AllianceAuth Incursion Tools
"""

__version__ = "1.0.23b"
__title__ = "AAIncursions"
# __branch__ = "stable"
__branch__ = "dev"
__url__ = "https://gitlab.com/tactical-supremacy/aa-incursions"
