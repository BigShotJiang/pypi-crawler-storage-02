
class GAutomatorException(Exception):
    pass


class NoSuchElementException(GAutomatorException):
    pass


class NotImplementedException(GAutomatorException):
    pass
