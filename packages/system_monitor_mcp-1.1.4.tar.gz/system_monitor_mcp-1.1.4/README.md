# System Monitor MCP

System Monitor MCP 是一个基于 Model Context Protocol (MCP) 的系统监控服务，可以提供系统资源信息，包括 CPU、内存、磁盘、网络和进程等。

## 版本更新 (v1.1.3)

- 🐛 修复了内存信息获取功能中的 `cached` 和 `buffers` 属性错误
- ✅ 优化了内存监控的兼容性，支持不同操作系统
- 🔧 改进了错误处理机制
- 📊 所有功能已通过完整测试验证

## 功能特点

- 实时监控系统资源使用情况
- 提供 CPU 详细信息，包括使用率、频率等
- 提供内存详细信息，包括物理内存和交换内存
- 提供磁盘详细信息，包括分区和 I/O 统计
- 提供网络详细信息，包括接口和流量统计
- 提供进程详细信息，包括 CPU 使用率、内存使用率等
- 支持资源监控，定期返回资源数据

## 安装

```bash
pip install system-monitor-mcp
```

## 使用方法

### 作为 MCP 服务器

在 AI 助手配置中添加以下 MCP 服务器配置：

```json
{
  "mcpServers": {
    "system-monitor-mcp": {
      "timeout": 60,
      "type": "stdio",
      "command": "python",
      "args": [
        "-m",
        "system_monitor_mcp"
      ]
    }
  }
}
```

### 可用工具

- `get_system_info`: 获取系统基本信息，包括 CPU、内存、操作系统等
- `get_cpu_info`: 获取 CPU 详细信息，包括使用率、频率等
- `get_memory_info`: 获取内存详细信息，包括物理内存和交换内存
- `get_disk_info`: 获取磁盘详细信息，包括分区和 I/O 统计
- `get_network_info`: 获取网络详细信息，包括接口和流量统计
- `get_processes_info`: 获取进程详细信息，包括 CPU 使用率、内存使用率等
- `monitor_resource`: 监控系统资源使用情况，定期返回资源数据

## 示例

### 获取系统信息

```python
# 使用 MCP 工具获取系统信息
result = await use_mcp_tool(
    server_name="system-monitor-mcp",
    tool_name="get_system_info",
    arguments={}
)
print(result)
```

### 监控 CPU 使用率

```python
# 监控 CPU 使用率，每 2 秒采集一次，持续 30 秒
result = await use_mcp_tool(
    server_name="system-monitor-mcp",
    tool_name="monitor_resource",
    arguments={
        "resource_type": "cpu",
        "interval": 2,
        "duration": 30
    }
)
print(result)
```

## 依赖

- Python >= 3.8
- psutil >= 5.9.0
- mcp >= 1.0.0
- pydantic >= 2.0.0

## 更新日志

### v1.1.3 (2024-12-19)
- 修复内存信息获取功能的兼容性问题
- 优化了 Windows 系统下的内存监控
- 改进了错误处理和异常捕获
- 完善了测试覆盖率

### v1.1.2
- 基础功能实现
- 支持系统、CPU、内存、磁盘、网络、进程监控

## 许可证

MIT