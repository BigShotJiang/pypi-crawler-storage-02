.. _rampfit-algorithm-like:

Likelihood Fitting
==================

There is a new algorithm available for testing in ramp fitting, which is the
likelihood algorithm.  It is selected by setting ``--ramp_fitting.algorithm=likely``.
The details are in the ``stcal`` documentation at
:ref:`Likelihood Algorithm Details <stcal:likelihood_algo>`.
