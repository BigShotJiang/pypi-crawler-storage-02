Reference File Types
====================

The ``linearity`` step uses a LINEARITY reference file.

.. include:: ../references_general/linearity_reffile.inc
