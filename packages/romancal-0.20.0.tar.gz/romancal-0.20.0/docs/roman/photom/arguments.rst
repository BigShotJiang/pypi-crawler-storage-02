Step Arguments
==============

The photometric calibration step has one step-specific argument:

*  ``--photom``

If the ``photom`` argument is given with a filename for its value,
the photometric calibrated data that are created within the step will be
saved to that file.
