Reference Files
===============
The ``photom`` step uses :ref:`PHOTOM <photom_reffile>`
reference files.

.. include:: ../references_general/photom_reffile.inc
