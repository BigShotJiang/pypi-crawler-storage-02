Reference Files
===============
The ``flat_field`` step uses a FLAT reference file.

.. include:: ../references_general/flat_reffile.inc
