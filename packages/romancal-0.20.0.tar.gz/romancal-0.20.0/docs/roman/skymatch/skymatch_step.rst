=============
skymatch_step
=============

The ``skymatch_step`` function (class name ``SkyMatchStep``)
is the top-level function used to call the skymatch operation
from the Roman calibration pipeline.

.. currentmodule:: romancal.skymatch.skymatch_step

.. automodule:: romancal.skymatch.skymatch_step
   :members:
   :undoc-members:
