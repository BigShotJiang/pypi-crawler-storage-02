:orphan:

.. _gain_selectors:

.. include:: ../references_general/gain_selection.inc
