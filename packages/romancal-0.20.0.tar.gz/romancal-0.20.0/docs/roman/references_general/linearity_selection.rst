:orphan:

.. _linearity_selectors:

.. include:: ../references_general/linearity_selection.inc
