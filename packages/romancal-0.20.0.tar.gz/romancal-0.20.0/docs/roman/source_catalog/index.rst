.. _source_catalog_step:

==============
Source Catalog
==============

.. toctree::
   :maxdepth: 2

   main.rst
   psf.rst
   arguments.rst

.. automodapi:: romancal.source_catalog
