Step Arguments
==============

The dark current step has one step-specific argument:

*  ``--dark_output``

If the ``dark_output`` argument is given with a filename for its value,
the frame-averaged dark data that are created within the step will be
saved to that file.
