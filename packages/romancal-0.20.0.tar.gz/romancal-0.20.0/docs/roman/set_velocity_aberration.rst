.. _set_velocity_aberration:

===================
Velocity Aberration
===================

.. automodapi:: romancal.scripts.set_velocity_aberration

Command
-------
The following command to update velocity aberration information is as follows. Use the ``-h`` option for more details

roman_set_velocity_aberration
    Update the velocity aberration information in Roman uncal data.
