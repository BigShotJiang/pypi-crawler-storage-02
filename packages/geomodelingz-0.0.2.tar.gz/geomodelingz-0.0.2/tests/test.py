from GeoModelingZ import say_hello, get_current_time_str

print(say_hello("测试"))
print(get_current_time_str())