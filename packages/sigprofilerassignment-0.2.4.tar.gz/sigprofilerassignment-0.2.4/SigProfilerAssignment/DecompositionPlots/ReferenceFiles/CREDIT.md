Accolade_fermante.png is Vieux têtard's work. It has been rotated 180 degrees.

The license is located here: https://creativecommons.org/licenses/by-sa/3.0/deed.en
