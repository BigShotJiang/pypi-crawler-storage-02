
# THIS FILE IS GENERATED FROM SigProfilerAssignment SETUP.PY
short_version = '0.2.4'
version = '0.2.4'
Update = 'v0.2.4:  Add rn7 and mm39 reference signatures'

    