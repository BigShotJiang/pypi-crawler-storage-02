from enum import Enum


class ChatTypeEnum(Enum):
    CHAT_TYPE_QUESTION = 0
    CHAT_TYPE_ANSWER = 1
