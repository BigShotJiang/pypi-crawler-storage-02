from protollm.raw_data_processing.docs_parsers.parsers.word_doc.xml.xml_processing import (
    process_paragraph_body,
)
