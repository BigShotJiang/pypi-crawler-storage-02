## نصب
```bash
pip install jafrt
```

## استفاده
from jafrt import hello, add, multiply



## خروجی
