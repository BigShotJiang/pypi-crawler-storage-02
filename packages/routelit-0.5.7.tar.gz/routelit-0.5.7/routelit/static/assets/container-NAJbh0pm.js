import{j as n}from"./app--5U4-9K0.js";function e({children:t,...r}){return n.jsx("div",{...r,children:t})}export{e as default};
