from setuptools import setup, find_packages
setup(
    name = 'azpytools',
    version = '1.1.10',
    author = 'AndyZhu',
    author_email = 'andyzhu@live.com',  
    description='Tools for Python development',  
    # packages = ['azpytools'],
    packages=find_packages(),
)
