"""
Client
"""

from ucloud.core.client._cfg import Config
from ucloud.core.client._client import Client

__all__ = ["Config", "Client"]
