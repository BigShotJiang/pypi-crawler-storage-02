from .protein import to_alanine
from .link import get_link_atom
