import mcol  # https://github.com/mwinokan/MPyTools
import mout  # https://github.com/mwinokan/MPyTools
import copy


class Connectivity:

    def __init__(self, system):
        self.parent_system = system


class Interaction:

    def __init__(self, n_bodies):
        self.n_bodies = n_bodies
