#include <stdio.h>

int
print(char *s)
{
    printf("%s\n", s);
    return 0;
}
