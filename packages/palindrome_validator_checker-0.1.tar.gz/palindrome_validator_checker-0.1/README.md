# Palindrome Validator Checker
A Python library to validate if a string is a palindrome, ignoring case and non-alphanumeric characters.

## Usage

```python
from palindrome_validator_checker import is_palindrome

print(is_palindrome('Racecar'))
print(is_palindrome('hello world'))
```
