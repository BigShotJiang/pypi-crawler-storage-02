from .checker import is_palindrome
