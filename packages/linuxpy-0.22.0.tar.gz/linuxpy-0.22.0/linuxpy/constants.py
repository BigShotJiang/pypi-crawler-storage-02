#
# This file is part of the linuxpy project
#
# Copyright (c) 2023 Tiago Coutinho
# Distributed under the GPLv3 license. See LICENSE for more info.


MICROSEC_PER_SEC = 1_000_000
NANOSEC_PER_MICROSEC = 1_000
