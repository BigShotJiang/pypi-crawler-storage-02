from .wlgamepad import *

name = "wlgamepad"