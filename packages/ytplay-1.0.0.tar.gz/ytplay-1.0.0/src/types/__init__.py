"""Type definitions for the application"""
