from enum import Enum


class ReportFormat(str, Enum):
    text = "text"
    markdown = "markdown"
