# A parameterization plugin for GraPPA for KIMMDY

[![test latest release](https://github.com/graeter-group/kimmdy-grappa/actions/workflows/tests.yml/badge.svg?branch=release-please--branches--main)](https://github.com/graeter-group/kimmdy-grappa/actions/workflows/tests.yml/?branch=release-please--branches--main)

## Scaling with random aminoacids on a Intel Xeon Gold 6230 CPU with 96GB RAM

![benchmark_all_cascade](https://github.com/hits-mbm-dev/kimmdy-grappa/assets/69237857/b27aa217-9c4c-45f9-8425-dacff58b7058)

