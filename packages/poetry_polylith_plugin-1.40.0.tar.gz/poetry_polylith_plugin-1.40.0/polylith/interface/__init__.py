from polylith.interface.interfaces import create_interface

__all__ = ["create_interface"]
