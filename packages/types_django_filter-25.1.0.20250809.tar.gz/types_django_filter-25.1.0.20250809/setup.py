
from setuptools import setup

setup(package_data={'django_filters-stubs': ['__init__.pyi', 'compat.pyi', 'conf.pyi', 'constants.pyi', 'exceptions.pyi', 'fields.pyi', 'filters.pyi', 'filterset.pyi', 'rest_framework/__init__.pyi', 'rest_framework/backends.pyi', 'rest_framework/filters.pyi', 'rest_framework/filterset.pyi', 'utils.pyi', 'views.pyi', 'widgets.pyi', 'METADATA.toml', 'py.typed']})
