## 25.1.0.20250809 (2025-08-09)

[django-filter] Add type stubs (#14540)

