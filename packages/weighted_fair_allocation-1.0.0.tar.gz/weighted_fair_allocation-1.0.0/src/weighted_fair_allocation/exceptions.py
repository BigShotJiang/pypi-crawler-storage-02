class ValuationError(Exception):
    def __init__(self, *args):
        super().__init__(*args)

class InstanceError(Exception):
    def __init__(self, *args):
        super().__init__(*args)

class SequenceError(Exception):
    def __init__(self, *args):
        super().__init__(*args)