# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .rule_create_params import RuleCreateParams as RuleCreateParams
from .rule_replace_params import RuleReplaceParams as RuleReplaceParams
