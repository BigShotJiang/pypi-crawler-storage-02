# terminatex/__init__.py

from .core import display, display_from_url
