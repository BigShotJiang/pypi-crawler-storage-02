def consent_input_token(consent_url):
    print('Visit the following url to give consent:')
    print(consent_url)

    return input('Paste the authenticated url here:\n')
