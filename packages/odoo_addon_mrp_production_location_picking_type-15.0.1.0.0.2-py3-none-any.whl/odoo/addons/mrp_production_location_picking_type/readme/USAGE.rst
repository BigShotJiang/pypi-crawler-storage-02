To use this module:

1. Go to Inventory > Configuration > Operation Types
2. Select a operation type of type Manufacturing
3. Set the "Production Location" field to your desired production location
4. When creating manufacturing orders with this operation type, the production location will be automatically set to the configured location

