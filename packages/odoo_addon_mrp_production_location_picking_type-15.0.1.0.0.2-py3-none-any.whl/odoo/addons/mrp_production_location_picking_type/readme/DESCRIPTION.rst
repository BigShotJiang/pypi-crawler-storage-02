This module adds a production location field to stock picking types, allowing you to define specific production locations for manufacturing operations.

When a manufacturing order (MRP Production) is created with a picking type that has a production location configured, that location will override the default production location computation.
