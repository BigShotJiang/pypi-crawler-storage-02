export const config = {
  userContextURL: "mocked-url" // Mock value
  // Add other mock configurations as needed
};

export const getApiUrl = (endpoint: string) => `mocked-api-url/${endpoint}`;
