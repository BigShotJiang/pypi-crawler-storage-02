export async function getAccessToken(): Promise<string | null> {
  return "mocked-access-token";
}
