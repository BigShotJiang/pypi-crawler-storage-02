export declare const corsHeaders: {
    "Access-Control-Allow-Origin": string;
    "Access-Control-Allow-Headers": string;
};
