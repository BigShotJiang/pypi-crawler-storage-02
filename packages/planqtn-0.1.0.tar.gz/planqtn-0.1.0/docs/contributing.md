# Contributing

PlanqTN is an open source project, and we would love to see contributions from
you!

To get started with contributions, check out
[good first issues](https://github.com/planqtn/planqtn/issues?q=is%3Aissue%20state%3Aopen%20label%3A%22good%20first%20issue%22),
and follow the
[DEVELOPMENT.md](https://github.com/planqtn/planqtn/blob/main/DEVELOPMENT.md)
for setup, developer workflows, and design concepts.
