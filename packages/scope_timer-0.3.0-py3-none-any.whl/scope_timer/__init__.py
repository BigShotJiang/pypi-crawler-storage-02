from scope_timer.core import ScopeTimer
from scope_timer.version import __version__
