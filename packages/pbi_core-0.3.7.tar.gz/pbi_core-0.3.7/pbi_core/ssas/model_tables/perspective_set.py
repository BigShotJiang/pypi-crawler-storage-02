from .base import SsasTable


class PerspectiveSet(SsasTable):
    """TBD.

    SSAS spec:
    """
