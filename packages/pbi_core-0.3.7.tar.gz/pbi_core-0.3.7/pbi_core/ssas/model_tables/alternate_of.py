from .base import SsasReadonlyRecord


class AlternateOf(SsasReadonlyRecord):
    """TBD.

    SSAS spec:
    """
