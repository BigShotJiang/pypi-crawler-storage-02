from .base import SsasRenameRecord


class GroupByColumn(SsasRenameRecord):
    """TBD.

    SSAS spec:
    """
