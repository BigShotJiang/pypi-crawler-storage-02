from .base import SsasTable


class Set(SsasTable):
    """TBD.

    SSAS spec:
    """
