# Ruff Rule Groups

| Group Name | Rule Count |
| ---------- | :--------: |
| DAX Formatting Rules | [5](rule_groups/DAX_Formatting_Rules.md) |
| DAX Performance Rules | [1](rule_groups/DAX_Performance_Rules.md) |
| Layout Rules | [2](rule_groups/Layout_Rules.md) |
| Section Rules | [3](rule_groups/Section_Rules.md) |
| Theme Rules | [4](rule_groups/Theme_Rules.md) |
| Visual Rules | [1](rule_groups/Visual_Rules.md) |
