.. _modules-edge_builder:

##############
 Edge builder
##############

.. automodule:: anemoi.graphs.edges.builder
   :members:
   :exclude-members: BaseEdgeBuilder,BaseDistanceEdgeBuilders,NodeMaskingMixin
   :no-undoc-members:
   :show-inheritance:
