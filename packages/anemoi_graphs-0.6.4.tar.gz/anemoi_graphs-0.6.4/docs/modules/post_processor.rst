.. _modules-post_processor:

################
 Post processor
################

.. automodule:: anemoi.graphs.processors.post_process
   :members:
   :no-undoc-members:
   :show-inheritance:
   :exclude-members: PostProcessor,BaseMaskingProcessor
