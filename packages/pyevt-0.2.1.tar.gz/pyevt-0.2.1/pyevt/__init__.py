"""Python module to communicate with EVT-2 devices."""

__version__ = '0.2.0'

from .pyevt import EventExchanger
