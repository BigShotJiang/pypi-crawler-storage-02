VERSION = "0.2.2"

# this will be templated during the build
GIT_COMMIT = "740106ef9e67ae17393d081580f5c1493db372a1"
