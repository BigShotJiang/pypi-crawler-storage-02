# ohana
Observational H2RG Anomaly Noise Analyzer
