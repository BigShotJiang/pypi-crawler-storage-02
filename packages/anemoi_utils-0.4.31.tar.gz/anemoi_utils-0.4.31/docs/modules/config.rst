########
 config
########

.. automodule:: anemoi.utils.config
   :members:
   :no-undoc-members:
   :show-inheritance:
