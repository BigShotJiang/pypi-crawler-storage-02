
from setuptools import setup

setup(package_data={'boltons-stubs': ['__init__.pyi', 'cacheutils.pyi', 'debugutils.pyi', 'deprutils.pyi', 'dictutils.pyi', 'easterutils.pyi', 'ecoutils.pyi', 'excutils.pyi', 'fileutils.pyi', 'formatutils.pyi', 'funcutils.pyi', 'gcutils.pyi', 'ioutils.pyi', 'iterutils.pyi', 'jsonutils.pyi', 'listutils.pyi', 'mathutils.pyi', 'mboxutils.pyi', 'namedutils.pyi', 'pathutils.pyi', 'queueutils.pyi', 'setutils.pyi', 'socketutils.pyi', 'statsutils.pyi', 'strutils.pyi', 'tableutils.pyi', 'tbutils.pyi', 'timeutils.pyi', 'typeutils.pyi', 'urlutils.pyi', 'METADATA.toml', 'py.typed']})
