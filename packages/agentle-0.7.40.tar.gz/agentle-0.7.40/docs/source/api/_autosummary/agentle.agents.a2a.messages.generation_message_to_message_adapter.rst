agentle.agents.a2a.messages.generation\_message\_to\_message\_adapter
=====================================================================

.. automodule:: agentle.agents.a2a.messages.generation_message_to_message_adapter

   
   .. rubric:: Classes

   .. autosummary::
   
      Adapter
      AssistantMessage
      GenerationMessageToMessageAdapter
      GenerationPartToAgentPartAdapter
      Message
      UserMessage
   