from .base import StrLiteral


class YLoc(StrLiteral):
    ...
