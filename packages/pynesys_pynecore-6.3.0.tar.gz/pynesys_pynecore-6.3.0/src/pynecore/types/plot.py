from .base import IntEnum


class PlotEnum(IntEnum):
    ...


class Plot:
    ...
