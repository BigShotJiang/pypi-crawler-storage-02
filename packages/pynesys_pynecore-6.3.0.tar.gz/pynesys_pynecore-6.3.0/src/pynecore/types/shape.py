from ..types.base import IntEnum


class Shape(IntEnum):
    ...
