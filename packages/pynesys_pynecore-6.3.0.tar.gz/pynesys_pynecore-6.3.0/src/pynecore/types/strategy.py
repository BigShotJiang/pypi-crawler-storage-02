from .base import StrLiteral


class QtyType(StrLiteral):
    ...


class Direction(StrLiteral):
    ...


class Commission(StrLiteral):
    ...


class Oca(StrLiteral):
    ...
