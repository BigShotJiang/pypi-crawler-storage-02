from .base import StrLiteral


class XLoc(StrLiteral):
    ...
