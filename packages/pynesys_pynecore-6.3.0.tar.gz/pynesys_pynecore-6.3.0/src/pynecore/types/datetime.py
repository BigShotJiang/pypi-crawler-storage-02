from .base import IntEnum


class DayOfWeek(IntEnum):
    ...
