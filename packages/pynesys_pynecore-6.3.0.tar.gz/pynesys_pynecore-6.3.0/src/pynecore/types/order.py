from ..types.base import IntEnum


class Order(IntEnum):
    ...
