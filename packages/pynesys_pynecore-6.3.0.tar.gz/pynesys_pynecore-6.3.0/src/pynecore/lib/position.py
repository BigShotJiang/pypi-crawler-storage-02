from ..types.position import Position

#
# Constants
#

bottom_center = Position()
bottom_left = Position()
bottom_right = Position()
middle_center = Position()
middle_left = Position()
middle_right = Position()
top_center = Position()
top_left = Position()
top_right = Position()