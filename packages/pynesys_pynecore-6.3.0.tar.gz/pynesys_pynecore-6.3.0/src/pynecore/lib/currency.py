from ..types.currency import Currency

#
# Constants
#

AUD = Currency()
BTC = Currency()
CAD = Currency()
CHF = Currency()
ETH = Currency()
EUR = Currency()
GBP = Currency()
HKD = Currency()
JPY = Currency()
KRW = Currency()
MYR = Currency()
NOK = Currency()
NONE = Currency()
NZD = Currency()
RUB = Currency()
SEK = Currency()
SGD = Currency()
TRY = Currency()
USD = Currency()
USDT = Currency()
ZAR = Currency()
