from django.apps import AppConfig


class DjAdminDetailViewConfig(AppConfig):
    name = "djadmin_detail_view"
