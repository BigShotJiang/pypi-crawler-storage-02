"""Audio routes for the Percolate API."""

from .router import router