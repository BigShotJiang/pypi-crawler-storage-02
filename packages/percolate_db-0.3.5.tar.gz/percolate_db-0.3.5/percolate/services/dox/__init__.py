"""percolate has many providers for dealing with document types"""
