class EmbeddingProviders:
    embedding_text_embedding_ada_002 = "text-embedding-ada-002"