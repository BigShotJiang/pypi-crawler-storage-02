from setuptools import setup, find_packages

setup(
    # name="python-tracer",
    # version="0.1.0",
    # description="Python Tracer and Performance Monitoring Tool with HTML Reports",
    # author="Gaurao Bharambe",
    # packages=find_packages(),
    # install_requires=[],
    # python_requires=">=3.7",
)