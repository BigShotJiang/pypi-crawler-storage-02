# [Llama-3-70B-FP16](https://poe.com/Llama-3-70B-FP16){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 200 points/message |
| Initial Points Cost | 200 points |

**Last Checked:** 2025-08-05 23:29:17.314299


## Bot Information

**Creator:** @hyperbolic

**Description:** A highly efficient and powerful model designed for a veriety of tasks with 128K context length.

**Extra:** Powered by a server managed by @hyperbolic. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Llama-3-70B-FP16`

**Object Type:** model

**Created:** 1724034563488

**Owned By:** poe

**Root:** Llama-3-70B-FP16
