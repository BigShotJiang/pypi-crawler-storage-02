# [Llama-3.1-8B-FP16](https://poe.com/Llama-3.1-8B-FP16){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 50 points/message |
| Initial Points Cost | 50 points |

**Last Checked:** 2025-08-05 23:31:08.466479


## Bot Information

**Creator:** @hyperbolic

**Description:** The smallest and fastest member of the Llama 3.1 family, offering exceptional efficiency and rapid response times with 128K context length.

**Extra:** Powered by a server managed by @hyperbolic. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Llama-3.1-8B-FP16`

**Object Type:** model

**Created:** 1724034517400

**Owned By:** poe

**Root:** Llama-3.1-8B-FP16
