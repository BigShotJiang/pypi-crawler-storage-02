# charmcraftlocal

Pack charms with local Python package dependencies
