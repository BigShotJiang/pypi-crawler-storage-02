import typer

app = typer.Typer(help="Pack charms with local Python package dependencies")
