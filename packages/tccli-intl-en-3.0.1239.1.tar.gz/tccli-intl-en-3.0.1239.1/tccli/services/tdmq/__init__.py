# -*- coding: utf-8 -*-

from tccli.services.tdmq.tdmq_client import action_caller
    