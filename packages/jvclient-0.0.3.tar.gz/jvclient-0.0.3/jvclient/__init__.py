"""
jvclient package initialization.

This package provides a library of utils and components for action ui development.
"""

__version__ = "0.0.3"
__supported__jivas__versions__ = ["2.0.0"]
