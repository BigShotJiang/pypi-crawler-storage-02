from signer.argus  import *
from signer.ladon  import *
from signer.gorgon import *
from hashlib       import md5