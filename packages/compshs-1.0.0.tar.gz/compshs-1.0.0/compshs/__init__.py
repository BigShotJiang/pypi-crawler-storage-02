# -*- coding: utf-8 -*-

"""Top-level package for CompSHS."""

__author__ = """CompSHS team"""
__email__ = 'simon.delarue@telecom-paris.fr'
__version__ = '1.0.0'
