To configure this module, you need to:

1.  Go to *Settings \> Technical \> Tier Validations \> Tier
    Definition*.
2.  Create as many tiers as you want for Transfer model.
