This module extends the functionality of Transfers to support a tier
validation process.
