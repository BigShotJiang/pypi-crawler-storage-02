"""
Package implementing an object model for ERC-7730 input descriptors.

This model is directly serializable back the original JSON document.
"""
