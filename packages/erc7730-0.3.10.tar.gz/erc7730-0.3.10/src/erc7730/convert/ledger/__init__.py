"""
Conversions between ERC-7730 descriptors and Ledger specific descriptors.
"""
