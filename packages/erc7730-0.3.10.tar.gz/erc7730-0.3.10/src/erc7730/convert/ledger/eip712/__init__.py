"""
Conversions between ERC-7730 descriptors and Ledger specific EIP-712 descriptors.
"""
