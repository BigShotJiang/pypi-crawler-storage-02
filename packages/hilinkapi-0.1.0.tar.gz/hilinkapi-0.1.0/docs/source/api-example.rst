API functionality Example
=========================

Following is the example code from **apiTest.py** which can be used to test API compatibility of your modem.
Here an array of modems using with authentication and without authentication. 

.. literalinclude:: ../../apiTest.py
   :language: python
   :emphasize-lines: 11-12


