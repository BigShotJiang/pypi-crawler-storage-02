# File: __init__.py
# Project: databases
# Author: Jan Range
# License: BSD-2 clause
# Copyright (c) 2022 Institute of Biochemistry and Technical Biochemistry Stuttgart

from .dataverse import uploadToDataverse


__all__ = ["uploadToDataverse"]
