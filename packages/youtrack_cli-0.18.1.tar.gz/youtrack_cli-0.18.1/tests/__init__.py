"""Tests for the YouTrack CLI."""
