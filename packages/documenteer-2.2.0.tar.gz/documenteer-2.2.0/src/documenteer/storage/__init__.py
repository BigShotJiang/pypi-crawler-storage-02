"""Data storage interfaces."""
