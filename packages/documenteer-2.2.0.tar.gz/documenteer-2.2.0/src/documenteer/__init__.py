"""Rubin Observatory / LSST Sphinx documentation tools, extensions, and
configurations.
"""

__all__ = ["__version__", "version_info"]

from .version import __version__, version_info
