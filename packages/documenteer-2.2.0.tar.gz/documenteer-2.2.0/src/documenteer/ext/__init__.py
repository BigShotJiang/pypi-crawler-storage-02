"""Sphinx extensions (activate each extension individually from its module)."""
