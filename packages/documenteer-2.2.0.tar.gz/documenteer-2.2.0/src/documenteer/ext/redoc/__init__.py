"""Embed a Redoc site into the Sphinx documentation."""

from ._redoc import setup

__all__ = ["setup"]
