###############
documenteer.ext
###############

.. automodapi:: documenteer.ext.bibtex
   :no-inherited-members:
   :no-inheritance-diagram:

.. automodapi:: documenteer.ext.githubbibcache

.. automodapi:: documenteer.ext.jira
   :no-inheritance-diagram:

.. automodapi:: documenteer.ext.lsstdocushare
   :no-inheritance-diagram:

.. automodapi:: documenteer.ext.mockcoderefs
   :no-inheritance-diagram:

.. automodapi:: documenteer.ext.openapi

.. automodapi:: documenteer.ext.remotecodeblock

.. automodapi:: documenteer.ext.robots
