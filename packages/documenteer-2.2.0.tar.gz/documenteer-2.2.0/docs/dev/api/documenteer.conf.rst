################
documenteer.conf
################

.. automodapi:: documenteer.conf

.. automodapi:: documenteer.conf._toml
   :skip: DocumenteerConfig
