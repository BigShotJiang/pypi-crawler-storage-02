#############################
Theming architecture overview
#############################

One of Documenteer's roles for Rubin Observatory's Sphinx documentation is customizing and branding Sphinx themes.
Documenteer uses two base Sphinx themes: pydata-sphinx-theme_ for user guides and Technote_ for technotes.
These pages provide an overview of how these these themes are customized by Documenteer.

.. toctree::

   theme-assets
   html-templates
