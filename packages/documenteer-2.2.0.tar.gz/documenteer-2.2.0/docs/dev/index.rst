###########
Development
###########

.. toctree::
   :maxdepth: 2
   :caption: Guides

   development
   release

.. toctree::
   :maxdepth: 2
   :caption: Architecture

   theme

.. toctree::
   :maxdepth: 2
   :caption: Reference

   api/index
