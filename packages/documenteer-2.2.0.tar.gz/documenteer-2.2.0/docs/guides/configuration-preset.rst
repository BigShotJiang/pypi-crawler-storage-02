###############################################
The documenteer.conf.guide configuration preset
###############################################

This module, ``documenteer.conf.guide`` contains Sphinx configuration presets for Rubin observatory user guides.
See :doc:`how-to for using this configuration in your project <configuration>`.

.. literalinclude:: ../../src/documenteer/conf/guide.py
