Demo package with no manifest.yaml file.
