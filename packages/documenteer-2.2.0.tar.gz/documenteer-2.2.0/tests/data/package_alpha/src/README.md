Simulated src directory
