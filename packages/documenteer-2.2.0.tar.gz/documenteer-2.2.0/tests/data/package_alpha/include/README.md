Simulated include directory
