###################
Robots Sitemap Test
###################

This is a test site for the robots extension with sitemap generation enabled.

.. toctree::
   :maxdepth: 2

   page1
   page2
