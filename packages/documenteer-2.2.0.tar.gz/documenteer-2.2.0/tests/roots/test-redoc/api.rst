##################
API Docs Stub Page
##################

This is replaced by ``documenteer.ext.redoc``.
