######################
Robots No Sitemap Test
######################

This is a test site for the robots extension without sitemap generation.

.. toctree::
   :maxdepth: 2

   page1
