This directory contains third-party license information for projects that Documenteer is derived from or has adapted code from.
See individual source files for specific attribution.

See ../LICENSE for Documenteer's main license information.

- sphinx.txt — https://www.sphinx-doc.org
- sphinx-issue.txt — https://github.com/sloria/sphinx-issues
- astropy-helpers - https://github.com/astropy/astropy-helpers
- sphinxcontrib-redoc - https://sphinxcontrib-redoc.readthedocs.io/
