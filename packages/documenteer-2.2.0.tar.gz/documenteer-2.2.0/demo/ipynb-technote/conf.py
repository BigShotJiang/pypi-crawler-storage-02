from documenteer.conf.technote import *  # noqa F401 F403
