Thanks for contributing to Documenteer.

Since Documenteer is intended for internal use by LSST, community contributions can only be accepted if they align with LSST's aims.
For that reason, it's a good idea to propose changes with a new GitHub issue before investing time in making a pull request.

For more information about developing Documenteer, see https://documenteer.lsst.io/dev/development.html.
