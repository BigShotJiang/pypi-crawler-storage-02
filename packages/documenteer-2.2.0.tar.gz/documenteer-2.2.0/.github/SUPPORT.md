Here are some ways to get help with Documenteer:

- [Documentation](https://documenteer.lsst.io)
- [Ask a question in #square-docs-support (for Rubin staff)](https://rubin-obs.slack.com/archives/C07QK9N14BY)
- [Post a GitHub issue](https://github.com/lsst-sqre/documenteer/issues/new)
