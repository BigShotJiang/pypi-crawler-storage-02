from typing import TypedDict


class GraphState(TypedDict):
    messages: list
