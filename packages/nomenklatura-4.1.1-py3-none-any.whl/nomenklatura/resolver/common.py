class ResolverLogicError(Exception):
    pass
