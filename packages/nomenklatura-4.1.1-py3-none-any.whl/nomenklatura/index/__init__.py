from nomenklatura.index.index import Index
from nomenklatura.index.common import BaseIndex


__all__ = ["BaseIndex", "Index"]
