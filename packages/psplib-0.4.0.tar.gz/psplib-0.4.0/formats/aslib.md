# ASLIB

ASLIB files contain two parts (A) and (B).
See https://www.projectmanagement.ugent.be/research/project_scheduling/rcpspas for details.
The `psplib` library expects a single file which includes the merged parts of (A) and (B).
