## Reference
https://www.klayout.org/downloads/pymod/doc-qt5/code/index.html