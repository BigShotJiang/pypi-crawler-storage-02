"""Main entry point for hanzo-mcp when run as a module."""

from hanzo_mcp.cli import main

if __name__ == "__main__":
    main()
