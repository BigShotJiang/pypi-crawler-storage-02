"""Test suite for haidra_core using pytest."""
