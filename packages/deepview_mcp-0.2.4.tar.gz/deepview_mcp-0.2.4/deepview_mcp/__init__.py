"""
DeepView MCP - A Model Context Protocol server for analyzing large codebases using Gemini 1.5 Pro
"""

__version__ = "0.1.0"
