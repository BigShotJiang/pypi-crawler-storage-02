def run_debate():
    """
    Run a debate between two agents.
    """

    pass 
