"""Output formatting for CLI display."""
