class BuildInfo:  # pylint: disable=too-few-public-methods
    python_version = '3.12.3'
    os_name = 'posix:ubuntu'
    version = '0.2.0'
    git_sha = '136a863c8a56e1bc81afecaf42777225f02d2fa3'
    git_branch = 'master'
    git_uncommitted = [
    ]
    git_unpushed = [
    ]
