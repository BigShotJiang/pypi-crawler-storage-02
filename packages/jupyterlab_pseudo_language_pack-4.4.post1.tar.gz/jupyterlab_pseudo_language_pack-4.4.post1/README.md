# Jupyterlab pseudo-language Pack

pseudo-language pack for the JupyterLab ecosystem.

This package purpose is to allow translation of strings directly
within JupyterLab using the [_in-context_ Crowdin feature](https://developer.crowdin.com/in-context-localization/). You should
not install it explicitly.

## Install

### pip

```bash
pip install jupyterlab-pseudo-language-pack
```
