from pyamaxkit import amaxapi, wallet
amaxapi.set_node('https://api.eosn.io')

#import your account private key here
wallet.import_key('5K463ynhZoCDDa4RDcr63cUwWLTnKqmdcoTKTHBjqoKfv4u5V7p')

payer = 'testaccount1'
receiver = 'testaccount2'
args = {"payer":payer,"receiver":receiver,"bytes":10*1024}
amaxapi.push_action('eosio', 'buyrambytes', args, {payer:'active'})
