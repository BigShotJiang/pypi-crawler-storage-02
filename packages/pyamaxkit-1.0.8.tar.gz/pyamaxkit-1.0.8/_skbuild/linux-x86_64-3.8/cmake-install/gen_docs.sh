docsify init ./docs
handsdown pysrc --external https://github.com/AMAX-DAO-DEV/pyamaxkit
