from abc import ABC


class BaseTenderProvider(ABC):
    ...
    # @abstractmethod
    # async def get_by_code(self, code: str) -> Tender: ...

    # @abstractmethod
    # async def get_by_month(self, when: str) -> list[Tender]: ...
