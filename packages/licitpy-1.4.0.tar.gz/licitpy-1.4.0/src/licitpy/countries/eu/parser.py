from licitpy.core.parser.base import BaseParser


class EUTenderParser(BaseParser): ...
