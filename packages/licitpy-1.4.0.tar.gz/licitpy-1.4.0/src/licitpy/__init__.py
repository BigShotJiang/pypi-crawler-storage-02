from licitpy.licitpy import Licitpy

__version__ = "1.4.0"
__all__ = ["Licitpy"]
