"""
Integrations with popular AI/LLM frameworks.
"""
