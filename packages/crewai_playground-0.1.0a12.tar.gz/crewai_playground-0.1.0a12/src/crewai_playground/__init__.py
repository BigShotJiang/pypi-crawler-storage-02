"""CrewAI Playground - Web UI for CrewAI chat functionality."""

__version__ = "0.1.0-alpha.12"
