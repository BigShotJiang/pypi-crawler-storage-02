# -*- coding: utf-8 -*-

import os
import sys

current_dir = os.getcwd()
sys.path.append(current_dir)