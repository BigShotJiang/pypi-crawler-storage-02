""" Protección DoS """
# GuardianUnivalle_Benito_Yucra/dos_protection.py

def rate_limiter():
    """Simulación de limitador de peticiones"""
    print("✅ Rate limiter activo")
