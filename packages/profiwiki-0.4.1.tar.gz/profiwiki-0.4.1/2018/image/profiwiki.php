<?php
 // local ProfiWiki home page
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>ProfiWiki</title>
  <body>
    <h1>ProfiWiki</h1>
  </body>
</html>
