"""
aimu - AI Model Utilities

A Python package containing tools for working with various language models and AI services.
"""

__version__ = "0.1.5"
