def test_imports():
    import bulkllm  # noqa
