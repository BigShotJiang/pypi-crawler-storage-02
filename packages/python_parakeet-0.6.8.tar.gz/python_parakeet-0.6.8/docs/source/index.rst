.. parakeet documentation master file, created by
   sphinx-quickstart on Fri Feb 25 09:31:39 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to parakeet's documentation!
====================================

.. image:: images/parakeet_logo.png
   :width: 300

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   api
   configuration
   tutorial
   publications


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
