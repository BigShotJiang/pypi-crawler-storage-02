## This workflow run was built with the following packages:
<br>

| Name | Version | Notes | Target SHA | URL |
| :-- | :-- | :-- | :-- | :-- |
| amalgam | {amalgam-version} | {amalgam-notes} | {amalgam-sha} | {amalgam-url} |
| howso-engine | {howso-engine-version} | {howso-engine-notes} | {howso-engine-sha} | {howso-engine-url} |
| amalgam-lang-py | {amalgam-lang-py-version} | {amalgam-lang-py-notes} | {amalgam-lang-py-sha} | {amalgam-lang-py-url} |
| howso-engine-py | {howso-engine-py-version} | {howso-engine-py-notes} | {howso-engine-py-sha} | {howso-engine-py-url} |