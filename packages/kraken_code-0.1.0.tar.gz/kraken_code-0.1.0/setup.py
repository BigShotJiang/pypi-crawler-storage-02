from setuptools import setup, find_packages

setup(
    name='kraken-code',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'pyTelegramBotAPI'
    ],
    author='Anonymous Developer',
    description='Telegram Bot API with anonymity features',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/NEFORCEO',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
)