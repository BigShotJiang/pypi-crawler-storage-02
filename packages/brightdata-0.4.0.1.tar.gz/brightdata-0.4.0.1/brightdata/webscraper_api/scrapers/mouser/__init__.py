# brightdata/scrapers/mouser/__init__.py
from .scraper import MouserScraper   # ← adjust the filename if needed

__all__ = ["MouserScraper"]
