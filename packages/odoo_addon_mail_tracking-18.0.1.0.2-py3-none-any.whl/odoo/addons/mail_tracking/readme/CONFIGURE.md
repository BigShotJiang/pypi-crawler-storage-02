As there can be scenarios where sending a tracking img in the email body
is not desired, there is a global system parameter
"mail_tracking.tracking_img_disabled" that can be set to True to remove
the tracking img from all outgoing emails. Note that the **Opened**
status will not be available in this case.
