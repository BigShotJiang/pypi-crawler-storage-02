"""Tests for genai_processors_url_fetch."""
