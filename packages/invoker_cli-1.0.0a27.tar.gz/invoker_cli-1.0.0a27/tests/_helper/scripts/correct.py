def do_something():
    print('do something')

def invoke():
    do_something()