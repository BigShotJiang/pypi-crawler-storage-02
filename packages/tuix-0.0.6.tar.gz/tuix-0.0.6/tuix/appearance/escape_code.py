escape = 27 | 0x1b | 0o33 | 0b11011
ESCAPE = chr(escape)
