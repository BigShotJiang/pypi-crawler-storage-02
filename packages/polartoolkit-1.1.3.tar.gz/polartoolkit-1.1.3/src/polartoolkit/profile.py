MSG = (
    "The PolarToolkit module 'profile' has been renamed to 'profiles'. "
    "Please change any imports to the new name."
)

raise ImportError(MSG)
