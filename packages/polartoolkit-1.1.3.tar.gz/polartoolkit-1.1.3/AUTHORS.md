# PolarToolkit Authors

The following people have made contributions to the project (in alphabetical
order by last name) and are considered "The PolarToolkit Developers":

* [Matt Tankersley](https://github.com/mdtanker) - Kiel University, Germany (ORCID: [0000-0003-4266-8554](https://www.orcid.org/0000-0003-4266-8554))
