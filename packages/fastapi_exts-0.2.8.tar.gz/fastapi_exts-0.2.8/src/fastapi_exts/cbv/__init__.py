from .base import CBV


__all__ = ["CBV"]
