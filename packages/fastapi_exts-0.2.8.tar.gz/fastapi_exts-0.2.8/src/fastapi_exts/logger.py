from logging import getLogger


logger = getLogger("fastapi_exts")
