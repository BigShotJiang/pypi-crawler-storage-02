"""undoom-pdf-mcp: PDF转换工具MCP服务器

这是一个基于MCP (Model Context Protocol) 的PDF转换工具服务器，
集成了PDF转图片、Office文件转PDF等功能。
"""

__version__ = "0.2.1"
__author__ = "undoom"
__email__ = "kaikaihuhu666@163.com"