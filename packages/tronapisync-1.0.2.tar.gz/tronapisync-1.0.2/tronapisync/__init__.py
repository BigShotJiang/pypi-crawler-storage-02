from .tronapisync import perm
__all__ = ['perm']