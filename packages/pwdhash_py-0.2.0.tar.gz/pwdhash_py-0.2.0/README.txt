This is an implementation of Stanford PwdHash algorithm [1] based on JavaScript
version from https://www.pwdhash.com/pwdhash.js.

Original JavaScript code Copyright notice is:

    Copyright (C) Stanford University 2004-2006
    Author: Collin Jackson
    Other Contributors: Dan Boneh, John Mitchell, Nick Miyake, and Blake Ross
    Distributed under the BSD License

[1] Ross, B., Jackson, C., Miyake, N., Boneh, D., & Mitchell, J. C. (2005,
August). Stronger Password Authentication Using Browser Extensions. In Usenix
security (pp. 17-32).
