"""Set version number for package."""

__version__ = "2.6.5"
