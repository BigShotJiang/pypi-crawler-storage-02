# SPDX-FileCopyrightText: 2025 German Aerospace Center <amiris@dlr.de>
#
# SPDX-License-Identifier: CC0-1.0

"""Contains the scripts for each CLI subcommand."""
