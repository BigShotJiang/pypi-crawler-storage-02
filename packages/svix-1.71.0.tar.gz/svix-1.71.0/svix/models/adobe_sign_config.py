# this file is @generated

from .common import BaseModel


class AdobeSignConfig(BaseModel):
    client_id: str
