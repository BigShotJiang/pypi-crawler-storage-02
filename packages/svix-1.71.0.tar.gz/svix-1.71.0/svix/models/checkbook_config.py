# this file is @generated

from .common import BaseModel


class CheckbookConfig(BaseModel):
    secret: str
