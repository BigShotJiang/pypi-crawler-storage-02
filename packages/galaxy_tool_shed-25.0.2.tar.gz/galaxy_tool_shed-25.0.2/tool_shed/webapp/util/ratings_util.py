import logging

from galaxy.model.item_attrs import UsesItemRatings

log = logging.getLogger(__name__)


class ItemRatings(UsesItemRatings):
    """Overrides rate_item method since we also allow for comments"""

    def rate_item(self, trans, user, item, rating, comment=""):
        """Rate an item. Return type is <item_class>RatingAssociation."""
        item_rating = self.get_user_item_rating(trans.sa_session, user, item, webapp_model=trans.model)
        if not item_rating:
            # User has not yet rated item; create rating.
            item_rating_assoc_class = self._get_item_rating_assoc_class(item, webapp_model=trans.model)
            item_rating = item_rating_assoc_class()
            item_rating.user = trans.user
            item_rating.set_item(item)
            item_rating.rating = rating
            item_rating.comment = comment
            trans.sa_session.add(item_rating)
            trans.sa_session.commit()
        elif item_rating.rating != rating or item_rating.comment != comment:
            # User has previously rated item; update rating.
            item_rating.rating = rating
            item_rating.comment = comment
            trans.sa_session.add(item_rating)
            trans.sa_session.commit()
        return item_rating
