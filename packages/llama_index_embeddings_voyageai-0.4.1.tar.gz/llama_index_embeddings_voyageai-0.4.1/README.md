# LlamaIndex Embeddings Integration: Voyageai
