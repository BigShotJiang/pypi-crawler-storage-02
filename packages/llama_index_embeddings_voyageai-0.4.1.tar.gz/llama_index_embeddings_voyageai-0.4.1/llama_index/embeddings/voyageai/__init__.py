from llama_index.embeddings.voyageai.base import VoyageEmbedding

__all__ = ["VoyageEmbedding"]
