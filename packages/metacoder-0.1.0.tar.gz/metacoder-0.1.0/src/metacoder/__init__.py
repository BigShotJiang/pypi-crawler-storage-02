def main() -> None:
    print("Hello from metacoder!")
