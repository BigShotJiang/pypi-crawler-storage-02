# $run(project_name.in.py)

$run(project_home_page.in.py)  
© $run(author.in.py) <$run(email.in.py)>  

$run(project_name.in.py) is $run(description.in.py).


## Installation

Install with `pip`: `pip install $run(project_module.in.py)`.


## Copyright and Disclaimer

$run(project_name.in.py) is copyright $run(author.in.py), and is
free software, licensed under the GNU Public License version 3, or, at your
option, any later version. See the file COPYING.
