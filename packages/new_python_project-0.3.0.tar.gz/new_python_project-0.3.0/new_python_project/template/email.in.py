#!/usr/bin/env python3

import os


print(os.environ["EMAIL"], end="")
