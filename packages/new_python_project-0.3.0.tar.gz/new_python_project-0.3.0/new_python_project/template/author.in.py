#!/usr/bin/env python3

import os


print(os.environ["AUTHOR"], end="")
