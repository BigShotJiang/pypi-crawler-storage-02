#!/usr/bin/env python3

from datetime import datetime


print(datetime.now().year, end="")
