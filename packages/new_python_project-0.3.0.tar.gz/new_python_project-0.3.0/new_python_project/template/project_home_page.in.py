#!/usr/bin/env python3

import os


print(os.environ['PROJECT_HOME_PAGE'], end="")
