# Тесты для библиотеки mcsrvstatus
