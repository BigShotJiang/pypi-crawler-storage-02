from .parsedb import main


def parsedb_command(args, logger):
    return main(args, logger)




