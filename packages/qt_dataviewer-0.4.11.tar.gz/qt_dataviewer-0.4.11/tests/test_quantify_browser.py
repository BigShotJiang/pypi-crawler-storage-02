
from qt_dataviewer.quantify.data_browser import QuantifyDataBrowser

browser = QuantifyDataBrowser(r"test_data\quantify")
# browser = QuantifyDataBrowser(gui_style="dark")
