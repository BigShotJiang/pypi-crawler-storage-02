
__version__ = "0.4.11"

from qt_dataviewer.dataset_viewer import DatasetViewer

# TODO: remove import?
from qt_dataviewer.abstract.dataset_list import DatasetList
