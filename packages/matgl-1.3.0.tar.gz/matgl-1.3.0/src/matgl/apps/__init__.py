"""This package implements specific applications of matgl models. An example is their use for fitting interatomic
potentials parameterizing the potential energy surface (PES).
"""
