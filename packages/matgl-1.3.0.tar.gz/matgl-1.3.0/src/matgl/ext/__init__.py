"""This package implements interfaces to external packages such as Pymatgen and the Atomic Simulation Environment."""
