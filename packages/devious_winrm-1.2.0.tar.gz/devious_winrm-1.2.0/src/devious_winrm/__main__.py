"""Main entry point for the devious_winrm package."""
if __name__ == "__main__":
    from devious_winrm.cli import app
    app()
