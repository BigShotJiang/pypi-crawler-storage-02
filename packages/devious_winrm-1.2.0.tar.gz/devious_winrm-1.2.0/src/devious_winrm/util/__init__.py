"""Utilites for Devious-WinRM."""
