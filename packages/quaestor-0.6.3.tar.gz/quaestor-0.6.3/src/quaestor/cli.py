"""Main CLI entry point - delegates to modular structure."""

from quaestor.cli.app import app

__all__ = ["app"]
