"""Quaestor template files."""
