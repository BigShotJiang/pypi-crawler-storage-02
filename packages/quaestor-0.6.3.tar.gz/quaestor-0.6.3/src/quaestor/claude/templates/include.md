<!-- QUAESTOR CONFIG START -->
[!IMPORTANT]
**Claude:** This project uses Quaestor for AI context management.
Please read the following files in order:
@.quaestor/CONTEXT.md - Complete AI development context and rules
@.quaestor/ARCHITECTURE.md - System design and structure (if available)
@.quaestor/RULES.md
@.quaestor/specs/active/ - Active specifications and implementation details
<!-- QUAESTOR CONFIG END -->

<!-- Your custom content below -->