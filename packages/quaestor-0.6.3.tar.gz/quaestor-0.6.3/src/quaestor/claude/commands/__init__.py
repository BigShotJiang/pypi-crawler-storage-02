"""Claude command templates."""
