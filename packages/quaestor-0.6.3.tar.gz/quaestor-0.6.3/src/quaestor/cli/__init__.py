"""Modular CLI for Quaestor."""

from quaestor.cli.app import app

__all__ = ["app"]
