# XAI Component Library Template

A good component library should come with readme that helps their users to understand their component workflow.


## Installation

Add this section if the component library requires additional setup aside from the packages in requirements.txt

## Common Errors

Add this section if there's a gotcha! somewhere in your compoent.


## Datasets

If you use an external dataset to test out your components, feel free to list them down.