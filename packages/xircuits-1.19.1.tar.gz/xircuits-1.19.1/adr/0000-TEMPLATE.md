# ADR Name / Title

## Status
PROPOSED (change to ACCEPTED or REJECTED later + add date)

Proposed by: FirstName LastName (DD/MM/YYYY)

Discussed with: Name1, Name2, Name3, ...

## Context
< A little background about the ADR >

## Proposal
< Design Proposal; phrased in a direct way; prefer "we implement X" over "we can implement X" or "we will implement X" >


## Consequences

### Advantages
< Advantages we'll see have after implementing the proposal >

### Disadvantages
< Disadvantages we'll have after implementing the proposal >

## Discussion
< Questions/Answers and suggestions based on the above proposed items during discussion that do not fit into the above sections >