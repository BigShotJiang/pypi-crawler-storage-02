#include "libadic/qp.h"

namespace libadic {

// All implementation is in the header for now

} // namespace libadic