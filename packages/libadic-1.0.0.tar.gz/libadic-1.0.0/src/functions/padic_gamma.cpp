#include "libadic/padic_gamma.h"

namespace libadic {

// All implementation is in the header

} // namespace libadic