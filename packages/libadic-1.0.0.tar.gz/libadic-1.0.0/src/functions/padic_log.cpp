#include "libadic/padic_log.h"

namespace libadic {

// All implementation is in the header

} // namespace libadic