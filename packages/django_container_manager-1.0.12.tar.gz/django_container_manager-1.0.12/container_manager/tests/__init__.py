# Import all test modules for discovery
from .test_models_and_integration import *  # noqa: F403
from .test_simple_factory import *  # noqa: F403
