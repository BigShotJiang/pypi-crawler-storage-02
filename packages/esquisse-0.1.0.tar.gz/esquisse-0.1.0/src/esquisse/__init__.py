def hello() -> str:
    return "Hello from esquisse!"
