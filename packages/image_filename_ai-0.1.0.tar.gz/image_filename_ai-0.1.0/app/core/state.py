# Global dictionary to store app state like the initialized model
app_state = {}
