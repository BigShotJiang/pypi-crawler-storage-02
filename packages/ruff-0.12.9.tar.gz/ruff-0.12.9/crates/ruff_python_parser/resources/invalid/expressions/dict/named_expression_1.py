# Unparenthesized named expression not allowed in value

{x: y := 1, z: a := 2}

x + y