# parse_options: { "target-version": "3.8" }
(x := 1)
