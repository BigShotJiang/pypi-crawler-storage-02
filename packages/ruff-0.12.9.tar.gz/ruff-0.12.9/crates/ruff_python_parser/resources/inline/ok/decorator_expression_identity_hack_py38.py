# parse_options: { "target-version": "3.8" }
def _(x): return x
@_(buttons[0].clicked.connect)
def spam(): ...
