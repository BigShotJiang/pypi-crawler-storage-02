type X[**P =] = int
type X[**P =, T2] = int
