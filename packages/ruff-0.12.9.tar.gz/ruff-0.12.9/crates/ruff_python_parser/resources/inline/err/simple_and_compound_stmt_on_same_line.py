a; if b: pass; b
