# The comma between the first two elements is expected in `parse_list_expression`.
[0, 1 2]
