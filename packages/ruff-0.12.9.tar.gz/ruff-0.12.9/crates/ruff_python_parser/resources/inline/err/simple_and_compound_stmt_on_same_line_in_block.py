if True: pass if False: pass
if True: pass; if False: pass
