if x:
    pass
elif *x:
    pass
elif yield x:
    pass
