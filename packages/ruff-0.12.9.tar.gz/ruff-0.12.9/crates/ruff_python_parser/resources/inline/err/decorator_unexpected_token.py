@foo
async with x: ...
@foo
x = 1
