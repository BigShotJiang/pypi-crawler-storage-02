# parse_options: { "target-version": "3.8" }
async def foo():
    @await bar
    def baz(): ...
