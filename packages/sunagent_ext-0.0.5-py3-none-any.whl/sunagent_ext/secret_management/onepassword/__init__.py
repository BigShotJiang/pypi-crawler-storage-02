from ._onepassword_client import OnePasswordManager

__all__ = [
    "OnePasswordManager",
]
