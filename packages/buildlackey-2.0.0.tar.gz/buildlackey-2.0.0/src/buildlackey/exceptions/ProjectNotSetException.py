
class ProjectNotSetException(Exception):
    pass
