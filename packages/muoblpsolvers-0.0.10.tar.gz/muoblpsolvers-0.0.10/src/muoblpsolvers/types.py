from typing import TypeAlias

Utility: TypeAlias = int
Cost: TypeAlias = float
TotalBudget: TypeAlias = float
CandidateId: TypeAlias = str
VoterId: TypeAlias = str
