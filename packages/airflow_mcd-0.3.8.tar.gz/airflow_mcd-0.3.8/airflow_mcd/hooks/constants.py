MCD_GATEWAY_CONNECTION_TYPE = "mcd_gateway"
MCD_GATEWAY_SCOPE = "AirflowCallbacks"
MCD_GATEWAY_HOSTS = [
    "integrations.getmontecarlo.com",
    "integrations.dev.getmontecarlo.com",
]
