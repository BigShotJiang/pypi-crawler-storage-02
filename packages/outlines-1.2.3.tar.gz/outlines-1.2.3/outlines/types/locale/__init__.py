"""Locale-specific regex patterns."""

from . import us
