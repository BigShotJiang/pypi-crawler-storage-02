from spektralwerk_scpi_client.devices.spektralwerk_core import SpektralwerkCore

__all__ = ["SpektralwerkCore"]
