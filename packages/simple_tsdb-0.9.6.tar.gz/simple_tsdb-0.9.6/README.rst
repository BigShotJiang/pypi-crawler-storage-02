simple_tsdb
===========
This package provides a library for interacting with a simple_tsdb server to
fetch and write points.
