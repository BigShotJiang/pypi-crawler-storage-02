from pathlib import Path

from ..config import *
from .helpers import criar_pasta

def gerar_js(resetar: bool = False):
    pass
