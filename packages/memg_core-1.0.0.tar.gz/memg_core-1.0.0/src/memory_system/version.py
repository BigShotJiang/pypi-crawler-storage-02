"""Version information for Personal Memory System"""

__version__ = "0.4.0"
