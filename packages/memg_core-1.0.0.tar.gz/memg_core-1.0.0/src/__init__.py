"""Personal Memory System - Qdrant + Kuzu + Google Gemini"""

__version__ = "0.1.0"
