# Authors

Contributors to pyconverters_pubmedfetcher include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
