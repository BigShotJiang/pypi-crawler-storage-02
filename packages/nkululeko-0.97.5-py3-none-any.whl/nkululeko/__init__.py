from nkululeko.constants import VERSION

__version__ = VERSION
