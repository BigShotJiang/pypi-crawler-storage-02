__version__ = "0.0.1"


def hello() -> str:
    return "Hello from SpectrumLab!"
