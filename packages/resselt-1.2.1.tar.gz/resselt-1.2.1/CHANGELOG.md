## 1.1.0

### Minor Changes

- [#16](https://github.com/rewaifu/resselt/pull/16) [`ad697d6`](https://github.com/rewaifu/resselt/pull/16/commits/ad697d629f433ab134e61f034e6999ff6b50f546) from [@umzi2](https://github.com/umzi2) — `arch/gaterv3`: support attention parameter.

## 1.0.1

### Patch Changes

- [`2799383`](https://github.com/rewaifu/resselt/commit/2799383f144dbb7ac45b463dbd7587c2f754460e) from [@sekiju](https://github.com/sekiju) — Package extras: `cu128`, `cu126`, `cu124`, `cu118`
