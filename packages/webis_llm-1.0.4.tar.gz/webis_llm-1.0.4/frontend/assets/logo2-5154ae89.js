const c=(t,r)=>{const o=t.__vccOpts||t;for(const[s,e]of r)o[s]=e;return o},_=""+new URL("logo2-c8390092.svg",import.meta.url).href;export{c as _,_ as a};
