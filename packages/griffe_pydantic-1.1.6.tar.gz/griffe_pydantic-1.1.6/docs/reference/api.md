---
title: API reference
hide:
- navigation
---

# ::: griffe_pydantic
    options:
        show_submodules: true
