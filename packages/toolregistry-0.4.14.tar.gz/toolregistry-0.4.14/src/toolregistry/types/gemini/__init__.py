"""Gemini API types for toolregistry."""

# TODO: Implement Gemini-specific types when adding Gemini support

__all__ = []
