"""Anthropic API types for toolregistry."""

# TODO: Implement Anthropic-specific types when adding Anthropic support

__all__ = []
