from docassemble.base.util import DAObject


class Halibut(DAObject):
    pass


class Food(DAObject):
    pass
