from enum import Enum


class OrderDirectionType(str, Enum):
    ASC = "ASC"
    DESC = "DESC"
