from enum import Enum


class YesOrNoResponse(str, Enum):
    YES = "y"
    NO = "n"

