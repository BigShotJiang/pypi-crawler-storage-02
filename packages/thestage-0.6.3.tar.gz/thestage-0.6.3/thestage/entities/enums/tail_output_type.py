from enum import Enum


class TailOutputType(str, Enum):
    YES = '1'
    NO = '0'
