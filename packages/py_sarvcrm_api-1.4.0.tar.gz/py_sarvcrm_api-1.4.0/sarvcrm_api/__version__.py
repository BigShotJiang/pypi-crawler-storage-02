__version__ = '1.4.0'

def get_version():
    return __version__

__all__ = [
    'get_version',
]