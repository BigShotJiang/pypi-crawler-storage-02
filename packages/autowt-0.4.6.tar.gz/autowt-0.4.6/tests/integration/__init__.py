"""Integration tests for cross-layer functionality."""
