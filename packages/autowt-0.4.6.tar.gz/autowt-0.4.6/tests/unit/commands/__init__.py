"""Tests for command layer functionality."""
