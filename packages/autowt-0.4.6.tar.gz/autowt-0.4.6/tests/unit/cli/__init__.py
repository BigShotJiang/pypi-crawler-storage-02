"""Tests for CLI layer functionality."""
