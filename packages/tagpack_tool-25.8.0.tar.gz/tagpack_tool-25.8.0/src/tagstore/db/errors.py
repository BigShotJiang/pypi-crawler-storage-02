class TagAlreadyExistsException(Exception):
    """Tag with the same key already exists"""
