"""Invokes dynamicio cli."""

# Application Imports
from dynamicio.cli import run

run()
