#! src/projectdavid/_version.py

SDK_VERSION = "0.3.0"
MIN_COMPATIBLE_API_VERSION = "0.3.0-alpha.1"
