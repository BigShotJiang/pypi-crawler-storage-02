Developing cdflib
=================

Documentation
-------------
To build the documentation you will need to install the documentation
requirements using::

  pip install .[docs]

This will install cdflib and all the packages need to make the documenation.

Versioning
----------
The package version is automatically determined using `setuptools_scm <https://github.com/pypa/setuptools_scm>`__, so does not need to be manually incremented when doing a new release.
