.. _dataclasses:

Dataclasses
===========
These classes store information returned from reading a CDF file.

.. automodule:: cdflib.dataclasses
   :members:
