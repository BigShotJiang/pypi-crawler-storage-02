API Reference
=============

.. toctree::
   :maxdepth: 1

   cdfread
   cdfwrite
   cdfepoch
   dataclasses
   xarray
