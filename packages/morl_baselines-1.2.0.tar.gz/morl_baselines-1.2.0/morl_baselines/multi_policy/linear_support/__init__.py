"""Linear support algorithm."""
