"""SER Algorithms."""
