"""MORL-Baselines contains various MORL algorithms and utility functions."""

__version__ = "1.2.0"
