from .about import __author__, __email__, __summary__, __title__, __version__
from .core import *
