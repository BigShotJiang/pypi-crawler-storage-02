This module was written to configure check digits on sequences added on
the end. It is useful as a control of the number on visual validation.

It is useful when some manual checks are required or on integrations.
The implemented codes can avoid modification of one character and flip
of two consecutive characters.
