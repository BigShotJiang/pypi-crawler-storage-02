mammos-analysis
===============

``mammos-analysis`` contains a collection of post-processing tools. The
:doc:`quickstart` notebook provides an overview of the available functionality.

.. toctree::
   :maxdepth: 1

   quickstart
