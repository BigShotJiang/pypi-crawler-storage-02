from printcolumn import print_column_row
from printcolumn import get_colors
from printcolumn import main



main()