from ..SWING.TriangularSWING import TriangularSWING

class TriangularPointAllocation(TriangularSWING):
    """
    This class is a direct alias of TriangularSWING for Point Allocation method.
    """
    pass
