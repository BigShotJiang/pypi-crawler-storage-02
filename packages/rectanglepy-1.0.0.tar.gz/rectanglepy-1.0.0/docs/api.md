# API

## Rectangle

```{eval-rst}
.. currentmodule:: rectanglepy

.. autosummary::
    :toctree: generated

    rectangle
    pp.build_rectangle_signatures
    tl.deconvolution
    pp.RectangleSignatureResult
```
