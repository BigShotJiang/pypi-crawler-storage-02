# Tutorials

Here you can find tutorials on how to use `rectanglepy`.

```{toctree}
:caption: Tutorials

notebooks/example
```

```

```
