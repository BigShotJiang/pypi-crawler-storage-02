"""Constants package for ByGoD."""
