"""Core package for ByGoD."""
