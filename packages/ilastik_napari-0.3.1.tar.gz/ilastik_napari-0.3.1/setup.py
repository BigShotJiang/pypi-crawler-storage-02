from setuptools import setup
from setuptools_scm import get_version

setup(version=get_version(), include_package_data=True)
