::: distproc.hwconfig
