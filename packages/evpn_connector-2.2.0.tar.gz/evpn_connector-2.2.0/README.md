# evpn-connector

The main task of this daemon is to interact with the gobgp and ovs to provide a connection using the EVPN protocol
