.. The main task of this daemon is to interact with the gobgp and ovs to provide a connection using the EVPN protocol's documentation master file, created by
   sphinx-quickstart on 2022-10-27 11:36:33.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Welcome to The main task of this daemon is to interact with the gobgp and ovs to provide a connection using the EVPN protocol's documentation!
==============================================================================================================================================

The main task of this daemon is to interact with the gobgp and ovs to provide a connection using the EVPN protocol

.. toctree::
    :maxdepth: 2

    config_docs/config_doc.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
