from importlib.metadata import version

print(version("pandas"))
print(version("matplotlib"))