My statistics base utils for my other projects.

It will be used by my projects `spotify-stats`, `Dayone-stats` and `rubik-stats`.

It contains the following features:
* my custom quantile calculation (that looks like the hazen method)
* 7 other functions for quantiles, including reversed function, based on n, and complimentary
* A method to calculate the trimmed mean with interpolation or not
* My own rolling function that includes the trimmed mean