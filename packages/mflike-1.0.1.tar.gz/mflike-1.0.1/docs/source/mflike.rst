``LAT_MFLike`` – LAT MultiFrequency Likelihood
==============================================

.. automodule:: mflike.mflike

``MFLike`` class content
------------------------

.. autoclass:: mflike.mflike._MFLike
    :exclude-members: initialize
    :members:
    :private-members:
    :show-inheritance:
    :member-order: bysource
