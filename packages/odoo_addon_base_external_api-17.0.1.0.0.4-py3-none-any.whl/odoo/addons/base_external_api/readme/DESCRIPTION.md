This module provides tools for other modules to use the requests library for making external API calls.

With this module, you can:

- Create an external API record and configure its URL and authentication_method parameters
- Log every API call
- Make asynchronous calls
