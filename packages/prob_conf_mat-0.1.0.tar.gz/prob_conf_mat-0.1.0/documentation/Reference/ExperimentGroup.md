<!-- LTeX: enabled=false -->
# Experiment Group

::: prob_conf_mat.experiment_group.ExperimentGroup
    options:
        members:
            - num_experiments

## Configuration

::: prob_conf_mat.experiment_group.ExperimentGroup.add_experiment
    options:
        heading_level: 3

::: prob_conf_mat.experiment_group.ExperimentGroup.__getitem__
    options:
        heading_level: 3

::: prob_conf_mat.experiment_group.ExperimentGroupResult
