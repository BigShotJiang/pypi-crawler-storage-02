from django.contrib import admin
# from .models import SomeModel

# Register your models here to have them show up in the django admin.
# NOTE: This is not useful for access.caltech apps outside of dev, though, as django admin uses URLs that depend on
# the models' IDs, which doesn't fly with CIT_AUTH. So the django admin feature may just not be useful for an app.
# admin.site.register(SomeModel)
