from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'demo.users'
    label = 'users'
