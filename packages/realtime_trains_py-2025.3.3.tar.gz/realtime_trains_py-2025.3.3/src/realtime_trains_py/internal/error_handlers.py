## Coming soon

# This file will contain error handlers for realtime-trains-py.