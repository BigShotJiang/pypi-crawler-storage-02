from dcicutils.project_utils import C4ProjectRegistry

app_project = C4ProjectRegistry.app_project_maker()
