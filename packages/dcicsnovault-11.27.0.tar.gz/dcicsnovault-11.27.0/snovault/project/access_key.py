class SnovaultProjectAccessKey:
    def access_key_has_expiration_date(self):
        return True
