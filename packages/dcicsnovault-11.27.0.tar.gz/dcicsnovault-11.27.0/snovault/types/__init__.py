def includeme(config):
    """include me method."""
    config.scan()
