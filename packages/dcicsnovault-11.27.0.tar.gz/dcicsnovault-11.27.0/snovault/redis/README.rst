************
REDIS README
************

This file contains notes on the Redis implementation.

