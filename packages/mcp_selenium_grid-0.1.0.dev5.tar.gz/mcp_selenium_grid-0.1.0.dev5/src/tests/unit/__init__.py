"""Unit tests for MCP Server components."""
