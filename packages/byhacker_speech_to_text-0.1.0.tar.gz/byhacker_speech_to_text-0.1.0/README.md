# Selenium Speech Listener

A Python package that uses Selenium to capture live speech-to-text from a hosted web app.

## Installation
```bash
pip install selenium-speech-listener

Usage:

from selenium_speech_listener import start_speech_listener

start_speech_listener()
