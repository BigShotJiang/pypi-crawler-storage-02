---
title: textual_fspicker.path_filters
---

::: textual_fspicker.path_filters

[//]: # (path_filters.md ends here)
