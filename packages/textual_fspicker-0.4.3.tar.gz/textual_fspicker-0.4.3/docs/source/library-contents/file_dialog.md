---
title: textual_fspicker.file_dialog
---

::: textual_fspicker.file_dialog

[//]: # (file_dialog.md ends here)
