---
title: textual_fspicker.base_dialog
---

::: textual_fspicker.base_dialog

[//]: # (base_dialog.md ends here)
