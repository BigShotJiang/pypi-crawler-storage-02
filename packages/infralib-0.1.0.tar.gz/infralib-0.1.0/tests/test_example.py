def test_import():
    import infralib

    assert infralib is not None


def test_basic():
    assert 1 + 1 == 2
