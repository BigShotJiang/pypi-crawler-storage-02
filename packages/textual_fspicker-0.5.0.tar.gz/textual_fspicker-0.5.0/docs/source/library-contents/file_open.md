---
title: textual_fspicker.file_open
---

::: textual_fspicker.file_open

[//]: # (file_open.md ends here)
