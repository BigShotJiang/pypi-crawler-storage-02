---
title: textual_fspicker.select_directory
---

::: textual_fspicker.select_directory

[//]: # (select_directory.md ends here)
