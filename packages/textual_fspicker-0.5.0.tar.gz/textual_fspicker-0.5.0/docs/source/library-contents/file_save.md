---
title: textual_fspicker.file_save
---

::: textual_fspicker.file_save

[//]: # (file_save.md ends here)
