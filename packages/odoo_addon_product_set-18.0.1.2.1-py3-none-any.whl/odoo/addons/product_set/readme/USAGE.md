To use this module, you need to install subsequent modules like
sale_product_set and check their instructions.
