A **product set** is a list of products which are usually used together.

This module aims to help defining several products under a name, for
later being added in a quick way into other document.

After a *product set* is added, each line can be updated or removed as
any other lines.

This differs from packing products as you don't follow *product set* are
not linked to sale order other project once they are added.
