# jupyterlab-project-extension

jupyterLab 项目插件，用于编辑和展示 项目步骤
适用版本 jupyterLab=4.4.0

