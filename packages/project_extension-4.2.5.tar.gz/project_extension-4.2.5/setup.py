from setuptools import setup, find_packages
with open('README.md', encoding='utf-8') as f:
  long_description=f.read()
setup()
 