from .logo import start_animations
from .logo import start_animations, clear, print_logo, rainbow_logo_loop
