ALTER TABLE bookmarks DROP COLUMN file_path;
ALTER TABLE bookmarks DROP COLUMN file_mtime;
ALTER TABLE bookmarks DROP COLUMN file_hash;
