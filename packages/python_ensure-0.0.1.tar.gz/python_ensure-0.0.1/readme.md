# Python functions used to ensure something.

## Installation

You can install from [pypi](https://pypi.org/project/python-ensure/)

```console
pip install -U python-ensure
```

## Usage

```python
import ensure
```
