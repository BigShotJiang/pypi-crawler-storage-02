# pixalate-open-mcp

[![Release](https://img.shields.io/github/v/release/pixalate/pixalate-open-mcp)](https://img.shields.io/github/v/release/pixalate/pixalate-open-mcp)
[![Build status](https://img.shields.io/github/actions/workflow/status/pixalate/pixalate-open-mcp/main.yml?branch=main)](https://github.com/pixalate/pixalate-open-mcp/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/pixalate/pixalate-open-mcp)](https://img.shields.io/github/commit-activity/m/pixalate/pixalate-open-mcp)
[![License](https://img.shields.io/github/license/pixalate/pixalate-open-mcp)](https://img.shields.io/github/license/pixalate/pixalate-open-mcp)

Pixalate Open MCP Server
