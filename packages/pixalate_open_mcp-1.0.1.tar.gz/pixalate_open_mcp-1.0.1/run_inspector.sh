npx @modelcontextprotocol/inspector --config mcp.json
