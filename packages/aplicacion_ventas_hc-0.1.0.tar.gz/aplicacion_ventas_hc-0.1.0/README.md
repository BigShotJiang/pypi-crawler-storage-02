"""
Se usa un # para indicar la descripcion que aparecera en pypi.org
Se usa ## para indicar la segunda descripcion en pypi.org"""

# Aplicacion de Ventas HC
Este paquete proporciona funcionalidades para gestionar ventas, tales como calculo de precios con impuestos y descuentos

## Instalacion

Puedes instalarlo usando
'''bash
pip install .
"
