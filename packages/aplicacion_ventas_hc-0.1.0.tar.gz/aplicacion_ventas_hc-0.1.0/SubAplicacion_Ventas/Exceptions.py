class ImpuestoInvalidoError(Exception):
    pass
class DescuentoInvalidoError(Exception):
    pass

