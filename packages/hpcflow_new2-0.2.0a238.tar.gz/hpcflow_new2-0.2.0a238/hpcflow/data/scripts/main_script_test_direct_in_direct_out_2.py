def main_script_test_direct_in_direct_out_2(p2):
    # process
    p3 = p2 + 100

    # return outputs
    return {"p3": p3}
