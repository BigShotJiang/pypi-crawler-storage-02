def main_script_test_json_out_FAIL(_output_files):
    pass
    # don't generate a JSON output file!
