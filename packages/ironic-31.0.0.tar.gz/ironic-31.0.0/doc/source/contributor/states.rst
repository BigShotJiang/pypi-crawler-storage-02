======================
Ironic's State Machine
======================

The content has been migrated, please see :doc:`/user/states`.
