Create user images for the Bare Metal service
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The content has been migrated, please see :doc:`/user/creating-images`.
