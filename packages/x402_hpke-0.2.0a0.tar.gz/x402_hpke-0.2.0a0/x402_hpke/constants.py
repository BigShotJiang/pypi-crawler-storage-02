CanonicalHeaders = {
    "X_PAYMENT": "X-PAYMENT",
    "X_PAYMENT_RESPONSE": "X-PAYMENT-RESPONSE",
}


