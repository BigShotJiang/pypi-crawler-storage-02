"""
Just define the package version in one place
"""

__version__ = "0.4.0"
