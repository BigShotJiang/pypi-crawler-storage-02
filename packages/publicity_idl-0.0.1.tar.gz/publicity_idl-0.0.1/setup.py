class Demo:
    def __init__(self, number):
        self.number = number

    def demo_add_one(self):
        return self.number + 1

def add_one(number):
    return number + 1
