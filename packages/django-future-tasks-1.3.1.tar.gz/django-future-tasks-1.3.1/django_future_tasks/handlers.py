from django.dispatch import Signal

future_task_signal = Signal()
