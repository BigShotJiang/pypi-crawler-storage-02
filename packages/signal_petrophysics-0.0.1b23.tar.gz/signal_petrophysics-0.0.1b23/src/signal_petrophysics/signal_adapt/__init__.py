# src/signal_petrophysics/signal_adapt/__init__.py

from .signal_adapt import (
    adjust_signal_length
)

__all__ = [
    'adjust_signal_length'
]
