from enum import Enum


class ZoneEnum(Enum):
    AFRIQUE = "afrique"
    BELGIQUE = "belgique"
    CANADA = "canada"
    FRANCE = "france"
    LUXEMBOURG = "luxembourg"
    ROMAIN = "romain"
    SUISSE = "suisse"
    MONACO = "monaco"
