from enum import Enum


class ColorEnum(Enum):
    BLANC = "blanc"
    ROSE = "rose"
    ROUGE = "rouge"
    NOIR = "noir"
    VERT = "vert"
    VIOLET = "violet"
