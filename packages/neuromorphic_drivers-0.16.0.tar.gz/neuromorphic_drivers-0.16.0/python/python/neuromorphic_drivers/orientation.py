class Davis346Orientation:
    dvs_invert_xy: bool
    aps_flip_x: bool
    aps_flip_y: bool
    aps_invert_xy: bool
    imu_flip_x: bool
    imu_flip_y: bool
    imu_flip_z: bool


class DvxplorerOrientation:
    dvs_flip_x: bool
    dvs_flip_y: bool
    dvs_invert_xy: bool
    imu_flip_x: bool
    imu_flip_y: bool
    imu_flip_z: bool
