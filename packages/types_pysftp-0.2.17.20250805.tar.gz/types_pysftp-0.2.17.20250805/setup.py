
from setuptools import setup

setup(package_data={'pysftp-stubs': ['__init__.pyi', 'exceptions.pyi', 'helpers.pyi', 'METADATA.toml', 'py.typed']})
