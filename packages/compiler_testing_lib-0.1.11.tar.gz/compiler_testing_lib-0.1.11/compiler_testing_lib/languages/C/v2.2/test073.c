{
  // Incompatible Types
  bool w = 1>true;
}