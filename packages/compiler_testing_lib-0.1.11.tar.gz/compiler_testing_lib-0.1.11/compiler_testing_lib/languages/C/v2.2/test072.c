{
  // Incompatible Types
  bool q = 5>"a";
}