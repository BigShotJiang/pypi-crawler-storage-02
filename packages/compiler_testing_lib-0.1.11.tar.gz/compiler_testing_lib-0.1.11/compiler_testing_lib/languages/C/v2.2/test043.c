{
  // Unexpected EOF (Missing CLOSE_BRA)
  int b = 1;
  if (b == 1) {
    b = 2;
  } else {
    b = 3;
}