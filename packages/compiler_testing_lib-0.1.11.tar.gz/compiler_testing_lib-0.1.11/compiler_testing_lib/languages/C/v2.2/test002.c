{
  // Unexpected token EOL
  int h = 7+;
}