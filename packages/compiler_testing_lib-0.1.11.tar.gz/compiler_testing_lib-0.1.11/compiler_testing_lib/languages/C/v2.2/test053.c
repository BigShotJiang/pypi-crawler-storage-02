{
  // Missing OPEN_PAR
  int k = scanf;
}