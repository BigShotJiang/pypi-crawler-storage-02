{
  // Variable Already Declared
  int n;
  str n;
}