{
  // Unexpected token MULT
  int y = 2**9;
}