{
  // Unexpected token EOL
  int f = 6/;
}