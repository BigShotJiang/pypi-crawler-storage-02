{
  // Incompatible Types
  bool h = "a"||9;
}