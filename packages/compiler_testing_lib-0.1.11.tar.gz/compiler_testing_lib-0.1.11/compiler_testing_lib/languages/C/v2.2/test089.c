{
  // Incompatible Types
  int h = true||false;
}