{
  // Incompatible types
  int f = true;
}