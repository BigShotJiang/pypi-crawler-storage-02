{
  // Unexpected token MULT
  int n = 7/*7;
}