{
  // Unexpected token IDEN
  int L = 1;
  int j = 3 L;
}