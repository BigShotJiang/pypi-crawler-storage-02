{
  // Unexpected token CLOSE_BRA (expected EOF)
  int s = 7;
}
}