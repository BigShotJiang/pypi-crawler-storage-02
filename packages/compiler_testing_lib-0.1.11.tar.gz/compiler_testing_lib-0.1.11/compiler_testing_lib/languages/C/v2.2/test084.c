{
  // Incompatible Types
  int o = true-1;
}