{
  // Incompatible types
  bool p = "a";
}