{
  // Incompatible Types
  bool r = "a"."b";
}