{
  // Unexpected EOF
  str y = "a;
}