{
  // Unexpected token MULT
  int r = *;
}