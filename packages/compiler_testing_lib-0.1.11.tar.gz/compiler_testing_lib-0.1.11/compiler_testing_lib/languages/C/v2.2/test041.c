{
  // Unexpected EOF (Missing CLOSE_BRA)
  int k = 1;
  if (k == 1) {
}