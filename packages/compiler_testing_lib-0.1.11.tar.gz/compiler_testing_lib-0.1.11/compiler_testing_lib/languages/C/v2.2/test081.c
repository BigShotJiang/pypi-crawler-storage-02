{
  // Incompatible Types
  int t = 1+true;
}