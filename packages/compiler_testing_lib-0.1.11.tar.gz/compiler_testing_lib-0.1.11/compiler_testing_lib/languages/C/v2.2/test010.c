{
  // Unexpected token DIV
  int k = /3;
}