{
  // Incompatible Types
  bool v = "a"<true;
}