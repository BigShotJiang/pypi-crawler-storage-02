{
  // Unexpected token EOL
  int s = +;
}