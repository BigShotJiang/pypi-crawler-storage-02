{
  // Unexpected OPEN_BRA
  int z = 1;
  if (z == 1) {
    z = 2;
  }
  {
    z = 3;
  }
}