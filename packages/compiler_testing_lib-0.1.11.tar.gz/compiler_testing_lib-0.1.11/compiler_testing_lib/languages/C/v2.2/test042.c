{
  // Missing OPEN_BRA
  int d = 1;
  if (d == 1)
    d = 2;
  }
}