{
  // Unexpected token EOF (expected CLOSE_BRA)
  int y = 7;