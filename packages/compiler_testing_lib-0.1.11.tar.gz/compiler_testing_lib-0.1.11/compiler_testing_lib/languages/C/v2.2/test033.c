{
  {
    // Unexpected token OPEN_BRA
    int u = 7;
  }
}