int q = 6;
void main() {
  // Function not found
  printf(q(1));
}