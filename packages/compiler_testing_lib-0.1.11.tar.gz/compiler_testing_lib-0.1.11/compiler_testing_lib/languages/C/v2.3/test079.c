void main() {
  // Incompatible Types
  bool w = "a"||9;
}