void main() {
  // Incompatible Types
  bool a = 3<"a";
}