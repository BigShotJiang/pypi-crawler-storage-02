void main() {
  // Unexpected token MULT
  int z = 2**7;
}