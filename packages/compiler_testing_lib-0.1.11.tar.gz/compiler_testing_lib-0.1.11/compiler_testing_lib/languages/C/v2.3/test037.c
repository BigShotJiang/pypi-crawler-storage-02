void main() {
  // Unexpected token IDEN
  int 1x = 5;
  printf(1x);
}