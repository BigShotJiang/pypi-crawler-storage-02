void main() {
  // Incompatible Types
  int z = 1*true;
}