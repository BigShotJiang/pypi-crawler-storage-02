void main() {
  // Unexpected token EOL
  int v = 6*;
}