void main() {
  // Unexpected token IDEN
  int L = 1;
  int e = 5 L;
}