void main() {
  // Missing OPEN_BRA
  int w = 1;
  if (w == 1)
    w = 2;
  }
}