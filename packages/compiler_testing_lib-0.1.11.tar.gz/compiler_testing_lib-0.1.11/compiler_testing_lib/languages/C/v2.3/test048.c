void main() {
  // Unexpected ELSE
  int n = 1;
  if (n == 1) {
    n = 2;
  } else {
    n = 3;
  } else {
    n = 4;
  }
}