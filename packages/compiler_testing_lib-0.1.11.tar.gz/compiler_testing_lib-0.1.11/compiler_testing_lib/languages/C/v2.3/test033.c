void main() {
  void main() {
    // Unexpected token FUNC or OPEN_PAR
    int p = 5;
  }
}