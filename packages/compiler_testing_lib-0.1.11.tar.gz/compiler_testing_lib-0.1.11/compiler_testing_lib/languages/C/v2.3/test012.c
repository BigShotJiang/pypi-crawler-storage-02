void main() {
  // Unexpected token EOL
  int c = 4/;
}