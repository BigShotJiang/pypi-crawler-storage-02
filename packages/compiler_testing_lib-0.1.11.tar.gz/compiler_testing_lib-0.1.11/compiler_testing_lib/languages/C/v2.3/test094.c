main() {
  // Missing function type
}