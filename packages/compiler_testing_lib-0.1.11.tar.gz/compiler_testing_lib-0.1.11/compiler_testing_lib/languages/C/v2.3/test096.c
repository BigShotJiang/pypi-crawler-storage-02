int test(int x,) {
  // Missing second arg
  return 8;
}
void main() {
  printf(test(5));
}