void main() {
  // Unexpected token CLOSE_BRA (expected EOF)
  int m = 7;
}
}