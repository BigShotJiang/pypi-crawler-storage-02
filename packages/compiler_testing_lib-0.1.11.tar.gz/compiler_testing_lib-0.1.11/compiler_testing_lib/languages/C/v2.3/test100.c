bool test(bool x) {
  return x;
}
void main() {
  // Wrong arg type
  printf(test(3));
}