void main() {
  // Incompatible Types
  bool h = 1>"a";
}