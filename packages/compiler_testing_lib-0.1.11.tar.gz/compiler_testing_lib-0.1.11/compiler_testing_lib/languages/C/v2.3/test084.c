void main() {
  // Incompatible Types
  int t = true-1;
}