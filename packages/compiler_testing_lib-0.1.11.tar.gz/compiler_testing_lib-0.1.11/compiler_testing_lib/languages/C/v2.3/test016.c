void main() {
  // Unexpected token DIV
  int q = 6+/9;
}