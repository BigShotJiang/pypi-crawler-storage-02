void main() {
  // Incompatible Types
  int f = true/1;
}