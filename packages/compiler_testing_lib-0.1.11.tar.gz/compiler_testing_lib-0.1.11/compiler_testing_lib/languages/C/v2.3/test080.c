void main() {
  // Incompatible Types
  bool f = !1;
}