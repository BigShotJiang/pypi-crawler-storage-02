void main() {
  // Unexpected token DIV
  int b = 9*/2;
}