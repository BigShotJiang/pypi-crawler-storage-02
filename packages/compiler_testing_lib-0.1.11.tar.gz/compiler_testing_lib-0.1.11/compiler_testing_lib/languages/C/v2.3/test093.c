void main() {
  // Incompatible Types 2
  while (0+0) {
  }
}