void main() {
  // Unexpected EOF
  str b = "a;
}