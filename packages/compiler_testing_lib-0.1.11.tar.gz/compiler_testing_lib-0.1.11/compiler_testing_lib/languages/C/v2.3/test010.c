void main() {
  // Unexpected token DIV
  int k = /4;
}