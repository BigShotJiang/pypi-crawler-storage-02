void main() {
  // Incompatible types
  str f = 9;
}