void main() {
  // Incompatible Types
  int a = true||false;
}