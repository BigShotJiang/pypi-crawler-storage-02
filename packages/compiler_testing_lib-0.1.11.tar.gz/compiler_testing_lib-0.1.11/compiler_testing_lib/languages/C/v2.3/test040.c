void main() {
  // Unexpected token INT
  3 = 4 + 3;
}