void main() {
  // Unexpected token EOL
  int y = +;
}