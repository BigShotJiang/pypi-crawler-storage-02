void main() {
  // Incompatible Types
  bool x = 2=="a";
}