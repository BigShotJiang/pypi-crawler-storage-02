void main() {
  // Unexpected token MULT
  int m = *;
}