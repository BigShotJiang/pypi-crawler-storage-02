void main() {
  // Incompatible Types
  int p = 1+true;
}