void main() {
  // Unexpected token MULT
  int z = *6;
}