{
  // Unexpected token MULT
  b = *;
}