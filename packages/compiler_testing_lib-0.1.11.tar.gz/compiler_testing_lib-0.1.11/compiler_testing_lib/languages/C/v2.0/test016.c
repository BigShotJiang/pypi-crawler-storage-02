{
  // Unexpected token DIV
  q = 9+/1;
}