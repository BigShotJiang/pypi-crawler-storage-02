{
  // Unexpected token CLOSE_BRA
  r = //7;
}