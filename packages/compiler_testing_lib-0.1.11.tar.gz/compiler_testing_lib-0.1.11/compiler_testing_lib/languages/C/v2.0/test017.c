{
  // Unexpected token MULT
  y = 3**8;
}