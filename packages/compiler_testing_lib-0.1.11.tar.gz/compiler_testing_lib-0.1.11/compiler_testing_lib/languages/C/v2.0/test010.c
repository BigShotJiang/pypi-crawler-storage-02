{
  // Unexpected token DIV
  x = /2;
}