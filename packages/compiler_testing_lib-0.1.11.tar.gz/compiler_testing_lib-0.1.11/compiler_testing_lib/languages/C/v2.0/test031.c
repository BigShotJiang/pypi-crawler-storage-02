{
  // Unexpected token EOF (expected CLOSE_BRA)
  f = 8;