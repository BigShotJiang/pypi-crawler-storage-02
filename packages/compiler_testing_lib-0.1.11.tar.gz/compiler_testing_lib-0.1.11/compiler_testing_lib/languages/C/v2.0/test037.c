{
  // Unexpected token IDEN
  1x = 5;
  printf(1x);
}