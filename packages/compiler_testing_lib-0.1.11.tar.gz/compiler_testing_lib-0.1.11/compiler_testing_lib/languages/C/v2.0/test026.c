{
  // Unexpected token IDEN
  X = 1;
  s = 7 X;
}