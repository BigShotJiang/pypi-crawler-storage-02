{
  {
    // Unexpected token OPEN_BRA
    o = 2;
  }
}