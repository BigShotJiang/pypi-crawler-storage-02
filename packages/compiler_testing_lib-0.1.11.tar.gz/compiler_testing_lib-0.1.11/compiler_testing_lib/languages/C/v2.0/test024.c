{
  // Unexpected token CLOSE_PAR
  f = (5));
}