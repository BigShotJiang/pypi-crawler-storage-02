{
  // Missing CLOSE_PAR
  d = (6;
}