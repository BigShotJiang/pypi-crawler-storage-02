{
  // Unexpected token ASSIGN (expected OPEN_PAR)
  printf = g;
}