{
  // Unexpected token OPEN_BRA (expected EOF)
  r = 2;
}
{
}