{
  // Unexpected token EOL
  x = -;
}