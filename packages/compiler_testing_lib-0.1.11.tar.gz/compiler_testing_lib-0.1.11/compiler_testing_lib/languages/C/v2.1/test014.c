{
  // Unexpected token DIV
  w = /;
}