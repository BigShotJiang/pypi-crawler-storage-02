{
  // Unexpected EOF (Missing CLOSE_BRA)
  q = 1;
  if (q == 1) {
}