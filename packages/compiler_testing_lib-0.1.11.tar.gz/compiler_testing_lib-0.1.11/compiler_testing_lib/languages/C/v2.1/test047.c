{
  // Unexpected OPEN_BRA
  o = 1;
  if (o == 1) {
    o = 2;
  }
  {
    o = 3;
  }
}