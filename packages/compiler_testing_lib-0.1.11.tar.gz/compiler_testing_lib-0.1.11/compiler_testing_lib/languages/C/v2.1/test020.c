{
  // Unexpected token MULT
  g = 2/*7;
}