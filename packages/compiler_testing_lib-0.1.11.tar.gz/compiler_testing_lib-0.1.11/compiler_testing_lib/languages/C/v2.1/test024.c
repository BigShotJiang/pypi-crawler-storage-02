{
  // Unexpected token CLOSE_PAR
  i = (2));
}