{
  // Unexpected token INT (expected EOL)
  u = 1 7;
}