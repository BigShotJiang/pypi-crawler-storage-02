{
  // Missing OPEN_BRA
  t = 1;
  if (t == 1) {
    t = 2;
  } else
    t = 3;
  }
}