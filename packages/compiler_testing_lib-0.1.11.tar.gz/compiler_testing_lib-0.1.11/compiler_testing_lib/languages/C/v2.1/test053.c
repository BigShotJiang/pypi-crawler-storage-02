{
  // Missing OPEN_PAR
  i = scanf;
}