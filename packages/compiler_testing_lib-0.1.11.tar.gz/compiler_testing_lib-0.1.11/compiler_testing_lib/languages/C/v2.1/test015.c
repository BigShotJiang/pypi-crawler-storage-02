{
  // Unexpected token MULT
  x = 7+*5;
}