{
  // Unexpected ELSE
  c = 1;
  if (c == 1) {
    c = 2;
  } else {
    c = 3;
  } else {
    c = 4;
  }
}