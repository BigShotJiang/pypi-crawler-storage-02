{
  // Missing CLOSE_PAR
  x = (2;
}