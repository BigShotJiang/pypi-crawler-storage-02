// Unexpected token IDEN (expected OPEN_BRA)
o = 3;