{
  // Unexpected token IDEN
  X = 1;
  h = 9 X;
}