{
  // Unexpected token EOL
  s = 6+;
}