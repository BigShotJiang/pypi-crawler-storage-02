MechanismType = list[dict[str, int]]
