def main():
    print("Hello from clio!")


if __name__ == "__main__":
    main()
