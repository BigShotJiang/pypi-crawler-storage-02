from lino_xl.lib.cal.fixtures.demo2 import objects
