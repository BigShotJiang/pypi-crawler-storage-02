.. _amici.specs:

=====
Specs
=====

Technical specifications for :ref:`amici`.


.. toctree::
   :maxdepth: 1

   overview
   misc
