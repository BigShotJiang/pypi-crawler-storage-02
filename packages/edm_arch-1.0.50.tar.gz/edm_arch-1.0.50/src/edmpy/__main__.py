import edmpy.edm as edm

if __name__ == '__main__':
    edm.EDMApp().run()
