
**Manual Building**


**Run the command**
sphinx-build -M html ./source ./build