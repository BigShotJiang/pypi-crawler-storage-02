CSA o86-19, Annex B Fire Design
===============================

Limitstates currently contains code for working with glulam and CLT.
Objects also exist for representing fire portection, and burning sections according to Annex B of csa o86.



.. automodule:: limitstates.design.csa.o86.c19.fireportection
	:members: GypusmFlatCSA19, GypusmRectangleCSA19

.. automodule:: limitstates.design.csa.o86.c19.annexB
   :members:
   :undoc-members:
   :show-inheritance: