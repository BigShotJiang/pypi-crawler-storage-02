CSA o86-19 Glulam Design - Shear
================================

The following functions are provided for checking shear of a glulam element.


   
.. automodule:: limitstates.design.csa.o86.c19.glulam
	:members: checkVrGlulamBeamSimple, checkWrGlulamBeamSimple, checkGlulamShearSimple, checkGlulamWr
