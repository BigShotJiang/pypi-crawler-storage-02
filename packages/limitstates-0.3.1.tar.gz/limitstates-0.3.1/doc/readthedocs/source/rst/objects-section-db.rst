.. _section-db:

Section Databases
=================

The following section databases are part of limitstates:
 - :download:`csa clt, prg320_2019 <sectionDB/csa/clt/prg320_2019.csv>`.
 - :download:`csa glulam, csa_o86_2019 <sectionDB/csa/glulam/csa_o86_2019.csv>`.
 - :download:`csa glulam, structurlam_beams_22_original <sectionDB/csa/glulam/structurlam_beams_22_original.csv>`.
 - :download:`csa steel, cisc_12_w <sectionDB/csa/steel/cisc_12_w.csv>`.
 - :download:`us steel, aisc_16_si_all <sectionDB/us/steel/aisc_16_si_all.csv>`.
 - :download:`us steel, aisc_16_si_hss <sectionDB/us/steel/aisc_16_si_hss.csv>`.
 - :download:`us steel, aisc_16_si_w <sectionDB/us/steel/aisc_16_si_w.csv>`.
 - :download:`us steel, aisc_16_us_all <sectionDB/us/steel/aisc_16_us_all.csv>`.
 - :download:`us steel, aisc_16_us_hss <sectionDB/us/steel/aisc_16_us_hss.csv>`.
 - :download:`us steel, aisc_16_us_w <sectionDB/us/steel/aisc_16_us_w.csv>`.
