CSA o86-19 Glulam Design - Interaction
========================================

The following functions are provided for checking the moment/compression interaction for a glulam column.
 

.. automodule:: limitstates.design.csa.o86.c19.glulam
	:members: checkPEColumn, checkInterEccPfColumn, checkPE, checkInterEccPf, checkInterTimberGeneric
