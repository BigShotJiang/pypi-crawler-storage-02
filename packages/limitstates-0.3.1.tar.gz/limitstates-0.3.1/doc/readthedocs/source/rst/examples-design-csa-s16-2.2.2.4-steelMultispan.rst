.. _examples-2.2.2.4:

Steel Beam Design Example
=========================


This page is a work in progress. See the full design example below.

.. literalinclude:: ../../../../example/2. Design/2.2 CSA/2.2.2 - s16/Ex 2.2.2.4 - MultiSpan Beam Design.py
