CSA o86-19 Glulam Design - Compression
======================================

The following functions are provided to check compression of an element.



.. automodule:: limitstates.design.csa.o86.c19.glulam
	:members: checkPrGlulamColumn, checkColumnCc, checkKci, checkKzcg, checkGlulamPr
	:no-index:

   