Rectangular Section
===================


.. autoclass:: limitstates.objects.section.section.SectionRectangle
   :members:
   :undoc-members:
   :show-inheritance: