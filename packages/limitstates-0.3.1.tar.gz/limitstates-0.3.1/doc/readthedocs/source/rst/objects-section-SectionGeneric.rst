Generic Section
===============


.. autoclass:: limitstates.objects.section.section.SectionGeneric
   :members:
   :undoc-members:
   :show-inheritance: