CLT Section
===========

The CLT section is a layers section made up of a series of CLT layers, combined into a group.
The CLT section itself is has two section groups, one in the strong axis orientaiton, 
and one in the weak axis orientation.


.. autoclass:: limitstates.objects.section.clt.LayerClt
   :members:
   :undoc-members:
   :show-inheritance:
   

.. autoclass:: limitstates.objects.section.clt.LayerGroupClt
   :members:
   :undoc-members:
   :show-inheritance:
   
.. autoclass:: limitstates.objects.section.clt.SectionCLT
   :members:
   :undoc-members:
   :show-inheritance:
      
