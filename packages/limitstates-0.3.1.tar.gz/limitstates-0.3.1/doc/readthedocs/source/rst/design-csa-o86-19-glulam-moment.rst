CSA o86-19 Glulam Design - Moment
=================================

The following functions can be used to check moment for glulam elements.


.. automodule:: limitstates.design.csa.o86.c19.glulam
	:members: checkCb, checkBeamCb, checkKL, checkKzbg, checkGlulamMr, checkMrGlulamBeamSimple, checkMrGlulamBeamMultiSpan
