CSA o86-19, CLT Design
======================

CLT design checks exist for out of plane CLT loads only.

Beam Column Object
------------------
 
.. autoclass:: limitstates.design.csa.o86.c19.element.DesignPropsClt19
   :members:
   :undoc-members:
   :show-inheritance:
 
.. autoclass:: limitstates.design.csa.o86.c19.element.BeamColumnCltCsa19
   :members:
   :undoc-members:
   :show-inheritance:

 
.. automodule:: limitstates.design.csa.o86.c19.section
	:members: loadCltSections
	:no-index:

   