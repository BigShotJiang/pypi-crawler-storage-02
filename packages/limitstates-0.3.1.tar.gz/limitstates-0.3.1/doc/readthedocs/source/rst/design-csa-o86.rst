CSA o86 - Timber Design
=======================

Code is supported for o86-19. o88-24 is a work in progress.

#. :doc:`design-csa-o86-19`
#. :doc:`design-csa-o86-24`



.. toctree::
   :maxdepth: 6
   :hidden:
   
   design-csa-o86-19.rst
   design-csa-o86-24.rst



