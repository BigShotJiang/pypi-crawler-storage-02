"""
This example shows how a basic glulam element can be checked for comrpession
it is a work in progress!
"""
