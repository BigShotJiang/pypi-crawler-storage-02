extinction
==========

*Fast interstellar dust extinction laws in Python*


![Build Status](https://github.com/kbarbary/extinction/workflows/Python%20package/badge.svg)
[![PyPI](https://img.shields.io/pypi/v/extinction.svg?style=flat-square)](https://pypi.python.org/pypi/extinction)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.804967.svg)](https://doi.org/10.5281/zenodo.804967)

documentation: http://extinction.readthedocs.io/
