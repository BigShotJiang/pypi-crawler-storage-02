def main() -> None:
    print("Hello from cdc-py!")
