from kfinance.integrations.mcp.mcp import run_mcp  # noqa:F401
