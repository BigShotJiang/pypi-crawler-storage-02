"""
Simulation Module
"""

from .agentsociety import AgentSociety

__all__ = [
    "AgentSociety",
]
