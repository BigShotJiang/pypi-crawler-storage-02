from .sesler import omg_kesik, omg_orijinal ,omg_yankili
