# Versioning Rules

Always check the following files for version information:

- **Python Version:** `/.mise.toml`
- **Dependency Versions:** `/requirements.txt` & `/.venv`
