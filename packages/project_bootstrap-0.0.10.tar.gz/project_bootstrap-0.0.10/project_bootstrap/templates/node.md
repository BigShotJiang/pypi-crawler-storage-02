# Versioning Rules

Always check the following files for version information:

- **Node.js & npm Versions:** `/.mise.toml`
- **Dependency Versions:** `/package.json` & `/node_modules`
