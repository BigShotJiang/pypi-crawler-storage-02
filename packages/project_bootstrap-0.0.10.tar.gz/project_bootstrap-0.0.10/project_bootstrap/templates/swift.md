# Versioning Rules

Always check the following files for version information:

- **Swift Version:** `/.mise.toml`
- **Dependency Versions:** `/Package.swift` & `/Package.resolved`
