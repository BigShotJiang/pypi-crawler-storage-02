# CPS Impress

Python publishing module incorporating Wikibase to Jupyter Notebook (WB2JN).

GOTO https://wiki.kewl.org/projects:impress
