from tts_wrapper.ssml import BaseSSMLRoot

UWPSSML = BaseSSMLRoot
