

def main():
    print("Coming to you from the command line!")

if __name__ =='__main__':
   main()
