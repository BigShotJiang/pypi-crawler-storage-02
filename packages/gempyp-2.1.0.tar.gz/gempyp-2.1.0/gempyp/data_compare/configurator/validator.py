class Validator():
    """
    This class will validate the config data provided by user. Minimum/maximum values, input data type etc
    """
    def __init__(self, config_data) -> None:
        self.config_data = config_data
    
    def validate_conf(self):
        """ To be done later"""
        return True