"""Helm Selenium Grid deployment package."""

from scripts.helm.main import app

__all__ = ["app"]
