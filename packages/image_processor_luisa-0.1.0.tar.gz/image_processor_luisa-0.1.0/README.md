# image_processor

Um pacote simples de processamento de imagens com funções para abrir, aplicar blur e salvar imagens.

## Instalação

```bash
pip install image-processor-luisa
