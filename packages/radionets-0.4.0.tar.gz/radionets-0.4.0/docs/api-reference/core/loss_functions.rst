.. _loss_functions:

*****************************************************
Loss Functions (:mod:`radionets.core.loss_functions`)
*****************************************************

.. currentmodule:: radionets.core.loss_functions

Loss functions submodule of :mod:`radionets.core`.


Reference/API
=============

.. automodapi:: radionets.core.loss_functions
    :inherited-members:
