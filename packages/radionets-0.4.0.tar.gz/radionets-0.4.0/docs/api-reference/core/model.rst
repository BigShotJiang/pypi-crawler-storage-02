.. _model:

***********************************
Model (:mod:`radionets.core.model`)
***********************************

.. currentmodule:: radionets.core.model

Model submodule of :mod:`radionets.core`.


Reference/API
=============

.. automodapi:: radionets.core.model
    :inherited-members:
