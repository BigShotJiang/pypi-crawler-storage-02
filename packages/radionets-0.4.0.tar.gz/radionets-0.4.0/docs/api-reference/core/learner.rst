.. _learner:

***************************************
Learner (:mod:`radionets.core.learner`)
***************************************

.. currentmodule:: radionets.core.learner

Learner submodule of :mod:`radionets.core`.


Reference/API
=============

.. automodapi:: radionets.core.learner
    :inherited-members:
