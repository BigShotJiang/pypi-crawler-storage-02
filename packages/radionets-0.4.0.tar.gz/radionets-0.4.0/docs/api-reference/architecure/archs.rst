.. _archs:

***************************************************
Architectures (:mod:`radionets.architecture.archs`)
***************************************************

.. currentmodule:: radionets.architecture.archs

Architectures submodule of :mod:`radionets.architecture`.


Reference/API
=============

.. automodapi:: radionets.architecture.archs
    :inherited-members: Module
