.. _activation:

***************************************************************
Activation Functions (:mod:`radionets.architecture.activation`)
***************************************************************

.. currentmodule:: radionets.architecture.activation

Activation functions submodule of :mod:`radionets.architecture`.


Reference/API
=============

.. automodapi:: radionets.architecture.activation
    :inherited-members: Module
