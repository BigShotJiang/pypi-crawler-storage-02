.. _blob_detection:

***********************************************************
Blob Detection (:mod:`radionets.evaluation.blob_detection`)
***********************************************************

.. currentmodule:: radionets.evaluation.blob_detection

Blob detection submodule of :mod:`radionets.evaluation`.


Reference/API
=============

.. automodapi:: radionets.evaluation.blob_detection
    :inherited-members:
