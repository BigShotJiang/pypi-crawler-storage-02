.. _eval_utils:

*****************************************************
Evaluation Utils (:mod:`radionets.evaluatuion.utils`)
*****************************************************

.. currentmodule:: radionets.evaluation.utils

Evaluation utils submodule of :mod:`radionets.evaluation`.


Reference/API
=============

.. automodapi:: radionets.evaluation.utils
    :inherited-members: numba
