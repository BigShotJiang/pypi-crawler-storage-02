# Tutorials

## Minimal single country model

### Building the model

### Running the optimisation

### Analysing the results

## Multi-region model connected by interconnectors

## Capacity expansion problem
