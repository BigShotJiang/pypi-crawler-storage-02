from arpakitlib.ar_blank_util import BaseBlank


class SimpleBlankTgBot(BaseBlank):
    pass
