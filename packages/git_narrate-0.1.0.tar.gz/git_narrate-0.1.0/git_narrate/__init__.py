"""
Git-Narrate: The Repository Storyteller

A tool that analyzes a git repository and generates a human-readable story of its development.
"""

__version__ = "0.1.0"
__author__ = "Git-Narrate Team"
__email__ = "contact@git-narrate.dev"