# winglet
Excel App pool manager for xlwings, managed by lightweight local daemon
