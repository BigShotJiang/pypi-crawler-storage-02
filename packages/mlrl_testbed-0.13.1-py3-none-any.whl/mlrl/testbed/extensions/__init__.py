"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes for implementing extensions that add functionality to the command line API.
"""
from mlrl.testbed.extensions.extension import Extension
