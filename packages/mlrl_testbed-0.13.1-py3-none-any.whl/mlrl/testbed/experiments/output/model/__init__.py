"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to write models to different sinks.
"""
from mlrl.testbed.experiments.output.model.writer import ModelWriter
