"""Template workflow for multi-step processing."""
