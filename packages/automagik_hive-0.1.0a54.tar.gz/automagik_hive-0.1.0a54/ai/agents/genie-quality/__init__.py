"""Genie Quality Agent - Code Quality Domain Specialist"""

from .agent import get_genie_quality_agent

__all__ = ["get_genie_quality_agent"]
