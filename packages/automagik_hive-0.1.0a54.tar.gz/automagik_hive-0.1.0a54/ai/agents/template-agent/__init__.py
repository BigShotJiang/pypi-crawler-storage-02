# Template Agent - Foundational agent template for specialized agent development
