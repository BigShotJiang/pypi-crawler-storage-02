# 系统信息获取包
from .core import get_disk_info, get_system_info, get_cpu_info, get_memory_info, get_disk_info

__version__ = "0.2.3"
__author__ = "yuanni"
__description__ = "一个获取macOS电脑信息的Python包"