# Provide a minimal setup.py to allow editable installs with older versions of pip.
# Pip v21.3 and later should work without setup.py.

import setuptools

setuptools.setup()
