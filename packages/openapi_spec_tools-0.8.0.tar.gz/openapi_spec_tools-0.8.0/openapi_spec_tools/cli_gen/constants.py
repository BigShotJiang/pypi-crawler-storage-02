"""CLI generation constants."""
GENERATOR_LOG_CLASS = "cli-gen"
