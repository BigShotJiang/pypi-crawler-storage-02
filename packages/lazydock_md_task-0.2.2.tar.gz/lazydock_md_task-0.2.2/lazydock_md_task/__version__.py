'''
Date: 2025-02-01 10:42:25
LastEditors: BHM-Bob 2262029386@qq.com
LastEditTime: 2025-03-02 17:56:11
Description: 
'''


__title__ = "lazydock_md_task"
__description__ = "MD-TASK python package distribution for LazyDock"
__url__ = "https://github.com/BHM-Bob/MD-TASK"
__version__ = "0.2.2"
__build__ = "20250809_1"
__author__ = "BHM-Bob G"
__author_email__ = "bhmfly@foxmail.com"
__license__ = "GPL-3.0 license"