<!--
 * @Date: 2025-02-01 10:35:35
 * @LastEditors: BHM-Bob 2262029386@qq.com
 * @LastEditTime: 2025-02-01 10:45:57
 * @Description: 
-->

# MD-TASK

**forked from RUBi-ZA/MD-TASK**

A suite of Python package that have been developed to analyze molecular dynamics trajectories. Detailed documentation on how to install and use MD-TASK can be found on our [ReadTheDocs](http://md-task.readthedocs.io/en/latest/index.html) site.

## Installation
```bash
pip install lazydock_md_task
```
