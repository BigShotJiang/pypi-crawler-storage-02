
.. image:: https://badge.fury.io/py/galaxy-tours.svg
   :target: https://pypi.org/project/galaxy-tours/


Overview
--------

The Galaxy_ tours backend framework.

This package includes models, utilities for reading tours from disk, and
tour validation scripting.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
