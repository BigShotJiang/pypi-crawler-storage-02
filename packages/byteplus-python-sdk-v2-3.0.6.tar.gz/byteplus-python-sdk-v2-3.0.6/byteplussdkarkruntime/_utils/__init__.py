from ._typing import (
    extract_type_arg as extract_type_arg,
    is_annotated_type as is_annotated_type,
)
