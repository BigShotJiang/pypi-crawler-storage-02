# MQTTNetLyzer
Message Queuing Telemetry Transport (MQTT) Network Traffic Analyzer

MQTTNetLyzer is an open-source Python library developed to extract features from MQTT-based network traffic. It analyzes all MQTT packets of a pcap file and generates a dataset, which is essential for developing an Intrusion Detection System (IDS).

MQTTNetLyzer is a session-based analyzer. In essence, it extracts features at the packet level and aggregates them to generate a session. There are several criteria for the aggregation. All packets in a session must have the same source/destination IP address, source/destination port number, client ID, and pub-sub topic. A session is initiated by a CONNECT packet and ended by either a DISCONNECT packet or implemented constraints like maximum session duration, inactivity timeout, etc. MQTTNetLyzer is a bidirectional session generator where the forward direction is determined by the CONNECT packet. MQTTNetLyzer extracts relevant features from an MQTT packet's Network and Transport layers as well.

Additionally, MQTTNetLyzer calculates new features other than raw features and adds them to the session. It also calculates statistical features for some of the features, like mean, median, variance, skewness, etc., in both directions. It is capable of extracting a total of 321 features from a pcap file.

# Installation

First, clone this repository on your system by running the following command:

	git clone git@github.com:adityaraj218/MQTTNetLyzer.git

To install the MQTTNetLyzer package, it is necessary to have the required libraries installed on your system. 

Navigate to the package directory and run the following command to ensure it:
> Make sure `Python` and `pip` are installed on your system

	pip3 install -r requirements.txt

Depending on your OS, execute the following command to install the MQTTNetLyzer package.

### On Windows

	pip3 install .

### On Linux

	 python3 setup.py install

> To ensure a successful installation, run `mqttnetlyzer --version`.

# Execution

To directly run the analyzer without any configuration file, run the following command:

	mqttnetlyzer -i path/to/pcap_file.pcap
> You can run `mqttnetlyzer -h` for more supported commands

### Configuration file

Since different users may want to run the program differently, users can alternatively use the configuration file to provide the PCAP file address, customise the analyzer parameters, default behaviours, etc.

To use the configuration file, modify the `config.json` file provided in the repository:

config.json
```json
{
  "input_pcap_file": "path/to/pcap_file.pcap",
  "output_csv_file": "path/to/output.csv",
  "label": "normal",
  "batch_size": 10000,
  "display_batch_status": true,
  "display_batch_stats": false,
  "restricted_topics": ["admin", "$SYS"]
}
```
#### Parameters

- `input_pcap_file`: Address of your PCAP file

- `output_csv_file`: Desired address of the output file

- `label`: Type of packets

- `batch_size`: Number of packets to process at once

- `display_batch_status`: Displays the number of the batch being processed currently

- `display_batch_stats`: Displays stats like the total number of packets, number of MQTT packets, and Analyzing rate for each batch

- `restricted_topics`: List of topics to which clients were not supposed to publish or subscribe
> Analyzer will count the number of times a client tried to access restricted topics

To run the analyzer using the `config.json` file, run the following command:

	mqttnetlyzer -c path/to/config.json


# Features

The MQTTNetLyzer can extract up to 321 features per session. Below is the visual representation of those features in the form of a sunburst chart:

### Sunburst Chart
![sunburst](https://github.com/adityaraj218/MQTTNetLyzer/blob/main/assets/sunburst.gif)



### Taxonomy of features

The list of features the analyzer can extract are:
> `fwd`: Forward direction `bwd`: Backward direction
> `mean`: mean `skew`: Skewness `std`: Standard Deviation `var`: Variance `total`: Sum

+ MQTT
  + MQTTMsgLength
    + fwdMQTTMsgLength
      + meanFwdMQTTMsgLength
      + medianFwdMQTTMsgLength
      + varFwdMQTTMsgLength
      + stdFwdMQTTMsgLength
      + skewFwdMQTTMsgLength
      + minFwdMQTTMsgLength
      + maxFwdMQTTMsgLength
      + totalFwdMQTTMsgLength
    + bwdMQTTMsgLength
      + meanBwdMQTTMsgLength
      + medianBwdMQTTMsgLength
      + varBwdMQTTMsgLength
      + stdBwdMQTTMsgLength
      + skewBwdMQTTMsgLength
      + minBwdMQTTMsgLength
      + maxBwdMQTTMsgLength
      + totalBwdMQTTMsgLength
    + MQTTMsgLength
      + meanMQTTMsgLength
      + medianMQTTMsgLength
      + varMQTTMsgLength
      + stdMQTTMsgLength
      + skewMQTTMsgLength
      + minMQTTMsgLength
      + maxMQTTMsgLength
      + totalMQTTMsgLength
  + PublishMsgLen
    + meanPublishMsgLen
    + medianPublishMsgLen
    + varPublishMsgLen
    + stdPublishMsgLen
    + skewPublishMsgLen
    + minPublishMsgLen
    + maxPublishMsgLen
    + totalPublishMsgLen
  + InterPublishTime
    + meanInterPublishTime
    + medianInterPublishTime
    + varInterPublishTime
    + stdInterPublishTime
    + skewInterPublishTime
    + minInterPublishTime
    + maxInterPublishTime
    + totalInterPublishTime
  + InterSubscribeTime
    + meanInterSubscribeTime
    + medianInterSubscribeTime
    + varInterSubscribeTime
    + stdInterSubscribeTime
    + skewInterSubscribeTime
    + minInterSubscribeTime
    + maxInterSubscribeTime
    + totalInterSubscribeTime
  + SubackDelay
    + meanSubackDelay
    + medianSubackDelay
    + varSubackDelay
    + stdSubackDelay
    + skewSubackDelay
    + minSubackDelay
    + maxSubackDelay
    + totalSubackDelay
  + SubscribeDuration
    + meanSubscribeDuration
    + medianSubscribeDuration
    + varSubscribeDuration
    + stdSubscribeDuration
    + skewSubscribeDuration
    + minSubscribeDuration
    + maxSubscribeDuration
    + totalSubscribeDuration
  + QoS
  + DUPFlag
    + fwdDUPFlag
    + bwdDUPFlag
    + DUPFlag
  + topic
  + clientID
  + username
  + isComplete
  + keepAlive
  + cleanSession
  + willFlag
  + willQoS
  + willRetain
  + willmsgLen
  + willtopicLen
  + passwordFlag
  + reserved
  + protocolName
  + protocolNameLength
  + connackSessionPresent
  + connackReturnCode
  + topicLen
  + publishCount
  + pubackNotRecieved
  + subscribeCount
  + subackNotRecieved
  + subscriptionDenied
  + accessRestrictedTopics
  + pingreqCount
  + pingrespCount
+ IP
  + srcIP
  + dstIP
  + srcPort
  + dstPort
  + DFFlag
    + fwdDFFlag
    + bwdDFFlag
    + DFFlag
  + MFFlag
    + fwdMFFlag
    + bwdMFFlag
    + MFFlag
  + RBFlag
    + fwdRBFlag
    + bwdRBFlag
    + RBFlag
  + TTL
    + fwdTTL
      + meanFwdTTL
      + medianFwdTTL
      + varFwdTTL
      + stdFwdTTL
      + skewFwdTTL
      + minFwdTTL
      + maxFwdTTL
      + totalFwdTTL
    + bwdTTL
      + meanBwdTTL
      + medianBwdTTL
      + varBwdTTL
      + stdBwdTTL
      + skewBwdTTL
      + minBwdTTL
      + maxBwdTTL
      + totalBwdTTL
    + TTL
      + meanTTL
      + medianTTL
      + varTTL
      + stdTTL
      + skewTTL
      + minTTL
      + maxTTL
      + totalTTL
  + IPLength
    + fwdIPLength
      + meanFwdIPLength
      + medianFwdIPLength
      + varFwdIPLength
      + stdFwdIPLength
      + skewFwdIPLength
      + minFwdIPLength
      + maxFwdIPLength
      + totalFwdIPLength
    + bwdIPLength
      + meanBwdIPLength
      + medianBwdIPLength
      + varBwdIPLength
      + stdBwdIPLength
      + skewBwdIPLength
      + minBwdIPLength
      + maxBwdIPLength
      + totalBwdIPLength
    + IPLength
      + meanIPLength
      + medianIPLength
      + varIPLength
      + stdIPLength
      + skewIPLength
      + minIPLength
      + maxIPLength
      + totalIPLength
+ TCP
  + WindowSize
    + fwdWindowSize
      + meanFwdWindowSize
      + medianFwdWindowSize
      + varFwdWindowSize
      + stdFwdWindowSize
      + skewFwdWindowSize
      + minFwdWindowSize
      + maxFwdWindowSize
      + totalFwdWindowSize
    + bwdWindowSize
      + meanBwdWindowSize
      + medianBwdWindowSize
      + varBwdWindowSize
      + stdBwdWindowSize
      + skewBwdWindowSize
      + minBwdWindowSize
      + maxBwdWindowSize
      + totalBwdWindowSize
    + WindowSize
      + meanWindowSize
      + medianWindowSize
      + varWindowSize
      + stdWindowSize
      + skewWindowSize
      + minWindowSize
      + maxWindowSize
      + totalWindowSize
  + TCPSegmentLen
    + fwdTCPSegmentLen
      + meanFwdTCPSegmentLen
      + medianFwdTCPSegmentLen
      + varFwdTCPSegmentLen
      + stdFwdTCPSegmentLen
      + skewFwdTCPSegmentLen
      + minFwdTCPSegmentLen
      + maxFwdTCPSegmentLen
      + totalFwdTCPSegmentLen
    + bwdTCPSegmentLen
      + meanBwdTCPSegmentLen
      + medianBwdTCPSegmentLen
      + varBwdTCPSegmentLen
      + stdBwdTCPSegmentLen
      + skewBwdTCPSegmentLen
      + minBwdTCPSegmentLen
      + maxBwdTCPSegmentLen
      + totalBwdTCPSegmentLen
    + TCPSegmentLen
      + meanTCPSegmentLen
      + medianTCPSegmentLen
      + varTCPSegmentLen
      + stdTCPSegmentLen
      + skewTCPSegmentLen
      + minTCPSegmentLen
      + maxTCPSegmentLen
      + totalTCPSegmentLen
  + TCPLength
    + fwdTCPLength
      + meanFwdTCPLength
      + medianFwdTCPLength
      + varFwdTCPLength
      + stdFwdTCPLength
      + skewFwdTCPLength
      + minFwdTCPLength
      + maxFwdTCPLength
      + totalFwdTCPLength
    + bwdTCPLength
      + meanBwdTCPLength
      + medianBwdTCPLength
      + varBwdTCPLength
      + stdBwdTCPLength
      + skewBwdTCPLength
      + minBwdTCPLength
      + maxBwdTCPLength
      + totalBwdTCPLength
    + TCPLength
      + meanTCPLength
      + medianTCPLength
      + varTCPLength
      + stdTCPLength
      + skewTCPLength
      + minTCPLength
      + maxTCPLength
      + totalTCPLength
  + TCPFIN
    + fwdTCPFIN
    + bwdTCPFIN
    + TCPFIN
  + TCPSYN
    + fwdTCPSYN
    + bwdTCPSYN
    + TCPSYN
  + TCPRST
    + fwdTCPRST
    + bwdTCPRST
    + TCPRST
  + TCPPSH
    + fwdTCPPSH
    + bwdTCPPSH
    + TCPPSH
  + TCPACK
    + fwdTCPACK
    + bwdTCPACK
    + TCPACK
  + TCPURG
    + fwdTCPURG
    + bwdTCPURG
    + TCPURG
  + TCPECE
    + fwdTCPECE
    + bwdTCPECE
    + TCPECE
  + TCPCWR
    + fwdTCPCWR
    + bwdTCPCWR
    + TCPCWR
  + TCPReserved
    + fwdTCPReserved
    + bwdTCPReserved
    + TCPReserved

+ Other
  + PacketLength
    + fwdPacketLength
      + meanFwdPacketLength
      + medianFwdPacketLength
      + varFwdPacketLength
      + stdFwdPacketLength
      + skewFwdPacketLength
      + minFwdPacketLength
      + maxFwdPacketLength
      + totalFwdPacketLength
    + bwdPacketLength
      + meanBwdPacketLength
      + medianBwdPacketLength
      + varBwdPacketLength
      + stdBwdPacketLength
      + skewBwdPacketLength
      + minBwdPacketLength
      + maxBwdPacketLength
      + totalBwdPacketLength
    + PacketLength
      + meanPacketLength
      + medianPacketLength
      + varPacketLength
      + stdPacketLength
      + skewPacketLength
      + minPacketLength
      + maxPacketLength
      + totalPacketLength
  + IAT
    + fwdIAT
      + meanFwdIAT
      + medianFwdIAT
      + varFwdIAT
      + stdFwdIAT
      + skewFwdIAT
      + minFwdIAT
      + maxFwdIAT
      + totalFwdIAT
    + bwdIAT
      + meanBwdIAT
      + medianBwdIAT
      + varBwdIAT
      + stdBwdIAT
      + skewBwdIAT
      + minBwdIAT
      + maxBwdIAT
      + totalBwdIAT
    + IAT
      + meanIAT
      + medianIAT
      + varIAT
      + stdIAT
      + skewIAT
      + minIAT
      + maxIAT
      + totalIAT
  + PacketsCount
    + fwdPacketsCount
    + bwdPacketsCount
    + PacketsCount
  + Throughput
    + fwdThroughput
    + bwdThroughput
    + Throughput
  + ID
  + startTime
  + endTime
  + duration
  + label

# Sample Output

> A PCAP file with two sessions was analysed with MQTTNetLyzer

index | ID | srcIP | dstIP | srcPort | dstPort | startTime | endTime | duration | fwdPacketsCount | bwdPacketsCount | packetsCount | topic | clientID | username | isComplete | fwdThroughput | bwdThroughput | throughput | meanFwdWindowSize | medianFwdWindowSize | varFwdWindowSize | stdFwdWindowSize | skewFwdWindowSize | minFwdWindowSize | maxFwdWindowSize | totalFwdWindowSize | meanBwdWindowSize | medianBwdWindowSize | varBwdWindowSize | stdBwdWindowSize | skewBwdWindowSize | minBwdWindowSize | maxBwdWindowSize | totalBwdWindowSize | meanWindowSize | medianWindowSize | varWindowSize | stdWindowSize | skewWindowSize | minWindowSize | maxWindowSize | totalWindowSize | meanFwdPacketLength | medianFwdPacketLength | varFwdPacketLength | stdFwdPacketLength | skewFwdPacketLength | minFwdPacketLength | maxFwdPacketLength | totalFwdPacketLength | meanBwdPacketLength | medianBwdPacketLength | varBwdPacketLength | stdBwdPacketLength | skewBwdPacketLength | minBwdPacketLength | maxBwdPacketLength | totalBwdPacketLength | meanPacketLength | medianPacketLength | varPacketLength | stdPacketLength | skewPacketLength | minPacketLength | maxPacketLength | totalPacketLength | meanFwdTCPSegmentLen | medianFwdTCPSegmentLen | varFwdTCPSegmentLen | stdFwdTCPSegmentLen | skewFwdTCPSegmentLen | minFwdTCPSegmentLen | maxFwdTCPSegmentLen | totalFwdTCPSegmentLen | meanBwdTCPSegmentLen | medianBwdTCPSegmentLen | varBwdTCPSegmentLen | stdBwdTCPSegmentLen | skewBwdTCPSegmentLen | minBwdTCPSegmentLen | maxBwdTCPSegmentLen | totalBwdTCPSegmentLen | meanTCPSegmentLen | medianTCPSegmentLen | varTCPSegmentLen | stdTCPSegmentLen | skewTCPSegmentLen | minTCPSegmentLen | maxTCPSegmentLen | totalTCPSegmentLen | meanFwdIPLength | medianFwdIPLength | varFwdIPLength | stdFwdIPLength | skewFwdIPLength | minFwdIPLength | maxFwdIPLength | totalFwdIPLength | meanBwdIPLength | medianBwdIPLength | varBwdIPLength | stdBwdIPLength | skewBwdIPLength | minBwdIPLength | maxBwdIPLength | totalBwdIPLength | meanIPLength | medianIPLength | varIPLength | stdIPLength | skewIPLength | minIPLength | maxIPLength | totalIPLength | meanFwdTCPLength | medianFwdTCPLength | varFwdTCPLength | stdFwdTCPLength | skewFwdTCPLength | minFwdTCPLength | maxFwdTCPLength | totalFwdTCPLength | meanBwdTCPLength | medianBwdTCPLength | varBwdTCPLength | stdBwdTCPLength | skewBwdTCPLength | minBwdTCPLength | maxBwdTCPLength | totalBwdTCPLength | meanTCPLength | medianTCPLength | varTCPLength | stdTCPLength | skewTCPLength | minTCPLength | maxTCPLength | totalTCPLength | meanFwdMQTTMsgLength | medianFwdMQTTMsgLength | varFwdMQTTMsgLength | stdFwdMQTTMsgLength | skewFwdMQTTMsgLength | minFwdMQTTMsgLength | maxFwdMQTTMsgLength | totalFwdMQTTMsgLength | meanBwdMQTTMsgLength | medianBwdMQTTMsgLength | varBwdMQTTMsgLength | stdBwdMQTTMsgLength | skewBwdMQTTMsgLength | minBwdMQTTMsgLength | maxBwdMQTTMsgLength | totalBwdMQTTMsgLength | meanMQTTMsgLength | medianMQTTMsgLength | varMQTTMsgLength | stdMQTTMsgLength | skewMQTTMsgLength | minMQTTMsgLength | maxMQTTMsgLength | totalMQTTMsgLength | fwdDUPFlag | bwdDUPFlag | DUPFlag | fwdQoS0 | bwdQoS0 | QoS0 | fwdQoS1 | bwdQoS1 | QoS1 | fwdQoS2 | bwdQoS2 | QoS2 | fwdTCPFIN | bwdTCPFIN | TCPFIN | fwdTCPSYN | bwdTCPSYN | TCPSYN | fwdTCPRST | bwdTCPRST | TCPRST | fwdTCPPSH | bwdTCPPSH | TCPPSH | fwdTCPACK | bwdTCPACK | TCPACK | fwdTCPURG | bwdTCPURG | TCPURG | fwdTCPECE | bwdTCPECE | TCPECE | fwdTCPCWR | bwdTCPCWR | TCPCWR | fwdTCPReserved | bwdTCPReserved | TCPReserved | fwdDFFlag | bwdDFFlag | DFFlag | fwdMFFlag | bwdMFFlag | MFFlag | fwdRBFlag | bwdRBFlag | RBFlag | meanFwdTTL | medianFwdTTL | varFwdTTL | stdFwdTTL | skewFwdTTL | minFwdTTL | maxFwdTTL | totalFwdTTL | meanBwdTTL | medianBwdTTL | varBwdTTL | stdBwdTTL | skewBwdTTL | minBwdTTL | maxBwdTTL | totalBwdTTL | meanTTL | medianTTL | varTTL | stdTTL | skewTTL | minTTL | maxTTL | totalTTL | keepAlive | cleanSession | willFlag | willQoS | willRetain | willmsgLen | willtopicLen | passwordFlag | reserved | protocolName | protocolNameLength | connackSessionPresent | connackReturnCode | topicLen | publishCount | pubackNotRecieved | subscribeCount | subackNotRecieved | subscriptionDenied | accessRestrictedTopics | meanPublishMsgLen | medianPublishMsgLen | varPublishMsgLen | stdPublishMsgLen | skewPublishMsgLen | minPublishMsgLen | maxPublishMsgLen | totalPublishMsgLen | meanInterPublishTime | medianInterPublishTime | varInterPublishTime | stdInterPublishTime | skewInterPublishTime | minInterPublishTime | maxInterPublishTime | totalInterPublishTime | meanInterSubscribeTime | medianInterSubscribeTime | varInterSubscribeTime | stdInterSubscribeTime | skewInterSubscribeTime | minInterSubscribeTime | maxInterSubscribeTime | totalInterSubscribeTime | meanSubackDelay | medianSubackDelay | varSubackDelay | stdSubackDelay | skewSubackDelay | minSubackDelay | maxSubackDelay | totalSubackDelay | meanSubscribeDuration | medianSubscribeDuration | varSubscribeDuration | stdSubscribeDuration | skewSubscribeDuration | minSubscribeDuration | maxSubscribeDuration | totalSubscribeDuration | pingreqCount | pingrespCount | meanFwdIAT | medianFwdIAT | varFwdIAT | stdFwdIAT | skewFwdIAT | minFwdIAT | maxFwdIAT | totalFwdIAT | meanBwdIAT | medianBwdIAT | varBwdIAT | stdBwdIAT | skewBwdIAT | minBwdIAT | maxBwdIAT | totalBwdIAT | meanIAT | medianIAT | varIAT | stdIAT | skewIAT | minIAT | maxIAT | totalIAT | label |
------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | ------------- | 
0 | 10.0.1.4_49327_198.41.30.241_1883 | 10.0.1.4 | 198.41.30.241 | 49327 | 1883 | 20-04-2016 16:43:10.509491 | 2016-04-20 16:43:38.150093 | 27.640602 | 6 | 9 | 15 | SampleTopic | paho/34AAE54A75D839566E | nan | False | 16.23885909352207 | 25.10495366712948 | 40.99042415935804 | 8236.333333333334 | 8236.333333333334 | 4.888888888888647 | 2.211083193570212 | -10355104534.500484 | 8235 | 8241 | 49446 | 227.0 | 227.0 | 0.0 | 0.0 | 0.0 | 227 | 227 | 2043 | 3430.733333333333 | 3430.733333333333 | 15395862.862222226 | 3923.7562185006127 | -0.2243861986858099 | 227 | 8241 | 123615 | 74.16666666666667 | 74.16666666666667 | 190.13888888888889 | 13.789085861248704 | -86.15962938711232 | 68 | 105 | 630 | 76.44444444444444 | 76.44444444444444 | 244.91358024691365 | 15.649715021268394 | -60.084938592623125 | 68 | 116 | 1044 | 75.53333333333333 | 75.53333333333333 | 224.24888888888887 | 14.9749420329058 | -63.18400212925722 | 68 | 116 | 1740 | 8.166666666666668 | 8.166666666666668 | 190.1388888888889 | 13.789085861248704 | -2.378362297429703 | 2 | 39 | 234 | 10.444444444444445 | 10.444444444444445 | 244.9135802469136 | 15.649715021268392 | -2.0718956560009487 | 2 | 50 | 450 | 9.533333333333331 | 9.533333333333331 | 224.2488888888889 | 14.9749420329058 | -1.986005192483328 | 2 | 50 | 750 | 60.16666666666666 | 60.16666666666666 | 190.13888888888883 | 13.7890858612487 | -55.33747591380457 | 54 | 91 | 546 | 62.44444444444444 | 62.44444444444444 | 244.9135802469136 | 15.649715021268392 | -38.32972136141836 | 54 | 102 | 918 | 61.53333333333333 | 61.53333333333333 | 224.24888888888887 | 14.9749420329058 | -40.40067867834912 | 54 | 102 | 1530 | 40.16666666666666 | 40.16666666666666 | 190.13888888888889 | 13.789085861248704 | -25.15563575568493 | 34 | 71 | 426 | 42.44444444444444 | 42.44444444444444 | 244.9135802469136 | 15.649715021268392 | -17.496538785484145 | 34 | 82 | 738 | 41.53333333333333 | 41.53333333333333 | 224.2488888888889 | 14.9749420329058 | -18.397257253580747 | 34 | 82 | 1230 | 6.166666666666667 | 6.166666666666667 | 190.1388888888889 | 13.789085861248704 | -1.7173002067198375 | 0 | 37 | 222 | 8.444444444444445 | 8.444444444444445 | 244.9135802469136 | 15.649715021268392 | -1.6001812653022744 | 0 | 48 | 432 | 7.533333333333333 | 7.533333333333333 | 224.2488888888889 | 14.9749420329058 | -1.49401986916982 | 0 | 48 | 720 | 0 | 0 | 0 | 6 | 9 | 15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 6 | 9 | 15 | 6 | 9 | 15 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 6 | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 0 | 64.0 | 64.0 | 0.0 | 0.0 | 0.0 | 64 | 64 | 384 | 41.0 | 41.0 | 0.0 | 0.0 | 0.0 | 41 | 41 | 369 | 50.2 | 50.2 | 126.96 | 11.26765281680262 | -19.534353230222926 | 41 | 64 | 960 | 5 | 1 | 0 | 0 | 0 | nan | nan | 0 | 0 | MQIsdp | 6 | 0 | 0 | 11 | 2 | 2 | 1 | 0 | 0 | 0 | 22.5 | 22.5 | 156.25 | 12.5 | -21.952 | 10 | 35 | 70 | 5.6713 | 5.6713 | 0.0 | 0.0 | 0.0 | 5.6713 | 5.6713 | 5.6713 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 5 | 5 | 5.4806806 | 5.4806806 | 0.0312602614962401 | 0.1768057168087054 | 0.4195721301347275 | 5.290239 | 5.713869 | 28.569345 | 3.9149928571428574 | 3.9149928571428574 | 5.07302216898955 | 2.252337046045629 | -1.1073383243826709 | 0.237773 | 5.433527 | 38.034689 | 2.126200153846153 | 2.126200153846153 | 5.180311004799821 | 2.2760296581547044 | 0.510829291890641 | 0.235652 | 5.005093 | 65.066209 | normal | 
1 | 10.0.1.4_49330_198.41.30.241_1883 | 10.0.1.4 | 198.41.30.241 | 49330 | 1883 | 20-04-2016 16:43:16.653525 | 2016-04-20 16:43:16.882353 | 0.228828 | 2 | 1 | 3 | SampleTopic | paho/DDE4DDAF4108D3E363 | nan | False | 1328859.0604026846 | 0.0 | 1171.1853444508538 | 8241.0 | 8241.0 | 0.0 | 0.0 | 0.0 | 8241 | 8241 | 16482 | 227.0 | 227.0 | 0.0 | 0.0 | 0.0 | 227 | 227 | 227 | 5569.666666666667 | 5569.666666666667 | 14272043.555555554 | 3777.835829619328 | -11.441082831880063 | 227 | 8241 | 24723 | 99.0 | 99.0 | 36.0 | 6.0 | -9083.25 | 93 | 105 | 210 | 70.0 | 70.0 | 0.0 | 0.0 | 0.0 | 70 | 70 | 70 | 89.33333333333333 | 89.33333333333333 | 210.88888888888889 | 14.522013940527977 | -376.8636934752645 | 70 | 105 | 315 | 33.0 | 33.0 | 36.0 | 6.0 | -365.75 | 27 | 39 | 78 | 4.0 | 4.0 | 0.0 | 0.0 | 0.0 | 4 | 4 | 4 | 23.33333333333333 | 23.33333333333333 | 210.88888888888889 | 14.522013940527977 | -13.452560551530402 | 4 | 39 | 117 | 85.0 | 85.0 | 36.0 | 6.0 | -5771.342592592592 | 79 | 91 | 182 | 56.0 | 56.0 | 0.0 | 0.0 | 0.0 | 56 | 56 | 56 | 75.33333333333333 | 75.33333333333333 | 210.88888888888889 | 14.522013940527977 | -232.7417418583915 | 56 | 91 | 273 | 65.0 | 65.0 | 36.0 | 6.0 | -2607.824074074074 | 59 | 71 | 142 | 36.0 | 36.0 | 0.0 | 0.0 | 0.0 | 36 | 36 | 36 | 55.333333333333336 | 55.333333333333336 | 210.88888888888889 | 14.522013940527977 | -100.12595804117156 | 36 | 71 | 213 | 30.0 | 30.0 | 49.0 | 7.0 | -183.14868804664724 | 23 | 37 | 74 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 2 | 2 | 2 | 20.666666666666668 | 20.666666666666668 | 206.88888888888889 | 14.383632673594278 | -10.915034840990293 | 2 | 37 | 111 | 0 | 0 | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 1 | 3 | 2 | 1 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 64.0 | 64.0 | 0.0 | 0.0 | 0.0 | 64 | 64 | 128 | 39.0 | 39.0 | 0.0 | 0.0 | 0.0 | 39 | 39 | 39 | 55.66666666666666 | 55.66666666666666 | 138.88888888888889 | 11.785113019775793 | -179.3351660228887 | 39 | 64 | 192 | 5 | 1 | 0 | 0 | 0 | nan | nan | 0 | 0 | MQIsdp | 6 | 0 | 0 | 11 | 1 | 1 | 0 | 0 | 0 | 0 | 10.0 | 10.0 | 0.0 | 0.0 | 0.0 | 10 | 10 | 10 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | nan | 0 | 0 | 0.000149 | 0.000149 | 0.0 | 0.0 | 0.0 | 0.000149 | 0.000149 | 0.000149 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.1144139999999999 | 0.1144139999999999 | 0.013056490225 | 0.114265 | 2.3255226810463048e-15 | 0.000149 | 0.228679 | 0.457358 | normal | 

# Citation&Copywrite2024 



# ProjectTeamMembers 

* [**Aditya Raj:**](https://github.com/adityaraj218)

