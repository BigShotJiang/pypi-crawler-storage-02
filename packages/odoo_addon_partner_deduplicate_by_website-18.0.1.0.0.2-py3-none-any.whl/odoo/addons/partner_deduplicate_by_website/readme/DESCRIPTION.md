This module extends the criteria to match duplicated contacts using the
field website.
