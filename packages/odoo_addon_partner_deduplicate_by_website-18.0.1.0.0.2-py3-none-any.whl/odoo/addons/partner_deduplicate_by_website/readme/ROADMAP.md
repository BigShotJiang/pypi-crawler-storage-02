  - As is current now website comparasion as is now is need to be
    extrictly the same but all these example of url should be consider
    the same:
    
    www.test-deduplicate.com test-deduplicate.com
    <http://test-deduplicate.com> <https://test-deduplicate.com>
    <http://test-deduplicate.com/> <https://test-deduplicate.com/>
    <http://www.test-deduplicate.com> <https://www.test-deduplicate.com>
    <http://www.test-deduplicate.com/>
    <https://www.test-deduplicate.com/>
