To use this module, you need to:

1.  Go to *Contacts \> Tools \> Deduplicate Contacts*.
2.  Mark "Website" in the section "Search duplicates based on duplicated
    data in".
3.  This criteria will be used for deduplicating.
