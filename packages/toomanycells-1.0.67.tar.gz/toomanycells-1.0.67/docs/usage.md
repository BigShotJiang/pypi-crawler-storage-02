# Usage

To use toomanycells in a project:

```
from toomanycells import TooManyCells as tmc
```
