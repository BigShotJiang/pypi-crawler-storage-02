# Welcome to toomanycells


[![image](https://img.shields.io/pypi/v/toomanycells.svg)](https://pypi.python.org/pypi/toomanycells)


**A python package for spectral clustering**


-   Free software: BSD License
-   Documentation: <https://JRR3.github.io/toomanycells>
    

## Features

-   TODO
