#!/usr/bin/env python

"""Tests for `toomanycells` package."""


import unittest

from toomanycells import toomanycells


class TestToomanycells(unittest.TestCase):
    """Tests for `toomanycells` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
