cd "$PROJECT_DIR"
source ${UV_PROJECT_ENVIRONMENT}/bin/activate && uv pip install -e ".[dev]"
