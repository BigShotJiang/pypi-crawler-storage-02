# Developer Documentation

## Release Process

1. Tag the release commit with the version number (e.g. `v0.1.0`)
2. Push the tag to GitHub. This should upload the source distribution to PyPI.
3. Create a release on GitHub with the tag
