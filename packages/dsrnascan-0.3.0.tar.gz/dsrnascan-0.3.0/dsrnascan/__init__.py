# dsRNAscan package
from .dsRNAscan import main

__version__ = '0.3.0'
__all__ = ['main']