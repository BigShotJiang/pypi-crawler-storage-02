#init
from .main import run
print("Discord chinese bot v1.8.1 ok")
print("by I_am_from_taiwan")
run()