#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   annotaion2labelme.py
@Time    :   2024/11/01 10:23:59
@Author  :   firstElfin 
@Version :   0.1.6
@Desc    :   This script is used to convert the annotation file to labelme format.
'''

