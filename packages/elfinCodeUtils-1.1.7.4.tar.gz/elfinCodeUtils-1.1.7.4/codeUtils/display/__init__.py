#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   __init__.py
@Time    :   2024/09/23 18:11:31
@Author  :   firstElfin 
@Version :   0.1.2
@Desc    :   None
'''


class HistDisplay: ...
