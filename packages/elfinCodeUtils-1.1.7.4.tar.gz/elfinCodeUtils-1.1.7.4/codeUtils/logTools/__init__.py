#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   __init__.py
@Time    :   2024/08/18 19:21:47
@Author  :   firstElfin 
@Version :   1.0
@Desc    :   None
'''

from .logConfig import setup_logger
