# OASIS-API

This Python package contains the API for interacting with the Open Acquisition System for IEPE Sensors (OASIS).
