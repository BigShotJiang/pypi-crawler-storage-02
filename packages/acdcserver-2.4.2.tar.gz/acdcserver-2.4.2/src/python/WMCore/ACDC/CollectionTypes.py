#!/usr/bin/env python
# encoding: utf-8
"""
CollectionTypes.py

Created by Dave Evans on 2010-03-05.
Copyright (c) 2010 Fermilab. All rights reserved.
"""


GenericCollection = "ACDC.CollectionTypes.GenericCollection"
DataCollection = "ACDC.CollectionTypes.DataCollection"
