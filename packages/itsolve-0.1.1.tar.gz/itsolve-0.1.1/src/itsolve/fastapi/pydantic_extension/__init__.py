from .make_partial import make_partial
from .omit import omit

__all__ = ("make_partial", "omit")
