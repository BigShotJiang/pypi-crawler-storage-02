from .dns import dns

class mdns(dns):
    
    # Class variables
    protocol_name = "mdns"  # Protocol name
