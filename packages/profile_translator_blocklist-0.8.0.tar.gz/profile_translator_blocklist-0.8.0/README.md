# profile-translator-blocklist
Translate IoT YAML profiles to NFTables / NFQueue files for a block-list firewall.
