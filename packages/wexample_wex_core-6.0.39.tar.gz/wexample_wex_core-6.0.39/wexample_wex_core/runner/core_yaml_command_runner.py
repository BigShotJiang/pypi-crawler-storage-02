from wexample_app.runner.yaml_command_runner import YamlCommandRunner


class CoreYamlCommandRunner(YamlCommandRunner):
    pass
