from typing import Dict, Any

ParsedArgs = Dict[str, Any]