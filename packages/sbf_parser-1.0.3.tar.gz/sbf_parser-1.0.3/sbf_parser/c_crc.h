/*
# Initial code by Jashandeep Sohi (2013, jashandeep.s.sohi@gmail.com)
# adapted by Marco Job (2019, marco.job@bluewin.ch)
*/
uint16_t crc16(const void *buf, size_t buf_length, uint16_t crc);
