Notebooks
=========

If you've finished :doc:`getting_started`, we can start dissecting some actual complex
problems. Below there are a few examples.

These notebooks are all `available here
<https://github.com/crusaderky/pathfinder2e_stats/tree/main/notebooks>`_
so that you may run and tweak them yourself.

.. toctree::
   :maxdepth: 1

   exacting_strike
   add_injury_to_insult
   bloodrager
   godbreaker
