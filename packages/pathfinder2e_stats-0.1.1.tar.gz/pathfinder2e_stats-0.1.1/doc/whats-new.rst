.. currentmodule:: pathfinder2e_stats

What's New
==========

v0.1.1 (2025-08-11)
-------------------

Minor changes specific to pypi and conda.


v0.1.0 (2025-08-08)
-------------------

Initial release.
