# GYB-Classification-Model
Classification Model

Installation steps
- pip install git+https://github.com/GreenBills/GYB-Classification-Model.git@main

Update Models
- pip install --upgrade build setuptools wheel
- python -m build

