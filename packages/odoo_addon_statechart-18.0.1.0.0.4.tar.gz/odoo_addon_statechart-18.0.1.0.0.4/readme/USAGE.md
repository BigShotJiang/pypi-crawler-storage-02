There is no documentation yet. In the meantime here are the Odoo Experience 2018
[slides](https://docs.google.com/presentation/d/e/2PACX-1vR9VGsSQUnITdnQq5KRiWnY7o-yERCB8YfnqxzhFW5tFcJ8AzMmIQ1CpLTdEgy5Sz9nx-yQlC0BhyGR/pub?start=false&loop=false&delayms=3000)
and [video](https://www.youtube.com/watch?v=ssgl0kraOMc) which should get you started.

See also the [sismic documentation](https://sismic.readthedocs.io/en/latest/).
