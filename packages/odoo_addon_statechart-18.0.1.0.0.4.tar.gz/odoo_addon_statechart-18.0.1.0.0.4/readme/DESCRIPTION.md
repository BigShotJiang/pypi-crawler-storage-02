Add statecharts to Odoo models.
