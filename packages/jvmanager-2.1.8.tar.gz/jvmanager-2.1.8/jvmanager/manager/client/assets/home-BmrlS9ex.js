import{v as r}from"./chunk-QMGIS6GS-CBZUm-7V.js";function o(){return r("/login")}export{o as clientLoader};
