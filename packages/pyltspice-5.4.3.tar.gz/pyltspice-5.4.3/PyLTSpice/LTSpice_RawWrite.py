# -*- coding: utf-8 -*-
"""
*(Deprecated)*
Supporting Legacy import clauses. This will disappear in future versions
"""

print("Deprecation Warning! This will no longer be supported in future versions.\n"
      "Use 'from PyLTSpice import RawWRead' for a direct import of the Raw Write class")

from .raw.raw_write import *