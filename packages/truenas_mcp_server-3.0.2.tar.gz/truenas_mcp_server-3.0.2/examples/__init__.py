# Examples package for TrueNAS MCP Server
