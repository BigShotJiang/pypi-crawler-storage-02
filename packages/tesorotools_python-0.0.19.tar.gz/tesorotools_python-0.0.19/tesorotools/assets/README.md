En esta carpeta se guardarán todos los *assets* del proyecto, como

- [fonts](fonts/): Fuentes (archivos *.otf).
- [plots.yaml](plots.yaml): Archivo de configuración general para los gráficos.
- [tesoro.mplstyle](tesoro.mplstyle): Archivo de estilos *matplotlib* para los gráficos.