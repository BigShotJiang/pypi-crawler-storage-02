from setuptools import setup

setup(
    name='barbara_updater',
    version='4.3.6',
    author='santod',
    description='weather observer',
    py_modules=['barbara3']  # Ensure this contains the actual Python files you want to include
)
