from .Easy import *
from .Medium import *
from .Hard import *
from .Solution import Solution