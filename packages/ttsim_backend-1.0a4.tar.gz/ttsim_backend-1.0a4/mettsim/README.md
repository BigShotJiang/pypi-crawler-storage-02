# The Middle Earth Taxes and Transfers SIMulator

Just exists for testing ttsim.
