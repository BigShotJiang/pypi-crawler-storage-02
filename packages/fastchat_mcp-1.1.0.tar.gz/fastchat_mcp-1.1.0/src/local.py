from fastchat import TerminalChat

chat = TerminalChat()
chat.open()
