from .mcp_manager.client import ClientManagerMCP


class Environment:
    CLIENT_MANAGER_MCP: ClientManagerMCP | None = None
