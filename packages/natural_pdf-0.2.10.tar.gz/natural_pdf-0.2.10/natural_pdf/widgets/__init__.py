# Also provide the original implementation for reference
from .viewer import InteractiveViewerWidget
from .viewer import InteractiveViewerWidget as _OriginalInteractiveViewerWidget
