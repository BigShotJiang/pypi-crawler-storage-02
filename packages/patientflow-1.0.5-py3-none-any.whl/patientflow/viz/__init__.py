"""Visualization module for patient flow analysis.

This module provides various plotting and visualization functions for analyzing
patient flow data, model results, and evaluation metrics.
"""
