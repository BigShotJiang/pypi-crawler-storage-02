
# src\file_conversor\__init__.py

"""
This is the root of the package.
It is used to initialize the package and can contain package-level variables or imports.
"""
