# src\file_conversor\platform\dummy\__init__.py

def reload_user_path():
    """Reload user PATH in current process."""
    # dummy method
    pass
