# Chronolog

Chronolog is a lightweight library to track your microservice version into Redis at startup.

## Install

```bash
pip install chronolog-service