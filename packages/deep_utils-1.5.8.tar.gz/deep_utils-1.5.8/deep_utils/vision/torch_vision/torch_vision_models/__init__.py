try:
    from deep_utils.dummy_objects.vision.torch_vision import TorchVisionModel
    from deep_utils.vision.torch_vision.torch_vision_models.torch_vision_models import (
        TorchVisionModel,
    )
except:
    pass
