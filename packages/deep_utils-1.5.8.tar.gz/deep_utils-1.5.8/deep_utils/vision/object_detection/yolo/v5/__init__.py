# try:
#     from deep_utils.dummy_objects.vision.object_detection import YOLOV5TorchObjectDetector
#     from deep_utils.vision.object_detection.yolo.v5.torch.yolo_v5_torch_object_detection import (
#         YOLOV5TorchObjectDetector,
#     )
# except ModuleNotFoundError:
#     pass
# except Exception as e:
#     raise e
