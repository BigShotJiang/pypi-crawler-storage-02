# try:
#     from deep_utils.dummy_objects.vision.object_detection import YOLOV7TorchObjectDetector
#     from deep_utils.vision.object_detection.yolo.v7.torch.yolo_v7_torch_object_detection import (
#         YOLOV7TorchObjectDetector,
#     )
# except ModuleNotFoundError:
#     pass
# except Exception as e:
#     raise e
