from deep_utils.utils.lib_utils.main_utils import import_module

HaarcascadeCV2FaceDetector = import_module(
    "deep_utils.vision.face_detection.haarcascade.cv2_.haarcascade_cv2_face_detection",
    "HaarcascadeCV2FaceDetector",
)
