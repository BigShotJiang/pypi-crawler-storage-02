try:
    from deep_utils.dummy_objects.callbacks.tf_keras import LRScalar

    from .lr import LRScalar
except:
    pass
