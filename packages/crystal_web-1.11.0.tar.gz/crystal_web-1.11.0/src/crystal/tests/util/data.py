# NOTE: 4.0s is too slow for CI on Windows
MAX_TIME_TO_DOWNLOAD_XKCD_HOME_URL_BODY = 6.0  # seconds

# NOTE: 4.0s is too slow for CI on Windows
MAX_TIME_TO_DOWNLOAD_404_URL = 6.0  # seconds
