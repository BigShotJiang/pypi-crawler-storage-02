from unittest import TestCase

skipTest = TestCase().skipTest
