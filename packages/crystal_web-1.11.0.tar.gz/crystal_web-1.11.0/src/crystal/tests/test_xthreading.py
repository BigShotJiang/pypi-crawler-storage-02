from unittest import skip


@skip('not yet automated')
async def test_given_running_callable_on_foreground_thread_and_callable_runs_for_a_long_time_when_callable_completes_then_slow_foreground_task_warning_is_printed() -> None:
    pass
