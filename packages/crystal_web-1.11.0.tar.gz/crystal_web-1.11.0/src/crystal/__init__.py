__version__ = '1.11.0'

APP_NAME = 'Crystal'
APP_AUTHOR = 'DaFoster'
