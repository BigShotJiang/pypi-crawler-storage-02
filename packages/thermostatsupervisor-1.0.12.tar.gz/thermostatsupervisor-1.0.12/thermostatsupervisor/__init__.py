"""Package identifier file"""

# local imports

# package name
name = "Thermostatsupervisor"
__version__ = "1.0.12"
