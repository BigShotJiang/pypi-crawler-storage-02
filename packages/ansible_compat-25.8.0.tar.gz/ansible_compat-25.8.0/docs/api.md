# API

::: ansible_compat.config

::: ansible_compat.errors

::: ansible_compat.loaders

::: ansible_compat.prerun

::: ansible_compat.runtime

::: ansible_compat.schema
