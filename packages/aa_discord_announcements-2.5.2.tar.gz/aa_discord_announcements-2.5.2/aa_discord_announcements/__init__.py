"""
A couple of variables to use throughout the app
"""

# Django
from django.utils.translation import gettext_lazy as _

__version__ = "2.5.2"
__title__ = _("Discord Announcements")
