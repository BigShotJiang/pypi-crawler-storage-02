[![License: AGPL-3](https://img.shields.io/badge/license-AGPL--3-blue.png)](https://www.gnu.org/licenses/agpl)

Adds user accounts to groups based on rules defined by the
administrator.
