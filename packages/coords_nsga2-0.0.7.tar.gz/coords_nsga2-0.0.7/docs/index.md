# 欢迎使用 coords-nsga2

这是一个基于 Python 实现的针对坐标组合的多目标优化算法库，基于 NSGA-II 方法改进。

## 快速开始

- 安装：请参阅 [安装指南](install.md)
- 使用：详细教程请参阅 [使用指南](usage.md)