# 安装

To install from PyPI:
```bash
pip install coord-nsga2
```

Or install the latest development version from GitHub:
```bash
git clone https://github.com/YourUsername/coord-nsga2.git
cd coord-nsga2
pip install -e .
```