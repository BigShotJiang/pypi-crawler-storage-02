__version__ = "0.9.2"

from .classes import Connection
from .federwiege import Federwiege
