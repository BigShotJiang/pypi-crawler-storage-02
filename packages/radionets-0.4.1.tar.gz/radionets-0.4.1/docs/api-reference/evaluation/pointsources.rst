.. _pointsources:

*********************************************************
Point Sources (:mod:`radionets.evaluatuion.pointsources`)
*********************************************************

.. currentmodule:: radionets.evaluation.pointsources

Point sources evaluation submodule of :mod:`radionets.evaluation`.


Reference/API
=============

.. automodapi:: radionets.evaluation.pointsources
    :inherited-members:
