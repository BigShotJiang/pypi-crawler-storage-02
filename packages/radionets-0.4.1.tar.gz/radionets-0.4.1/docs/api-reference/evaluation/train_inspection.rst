.. _train_inspection:

*******************************************************************
Training Inspection (:mod:`radionets.evaluatuion.train_inspection`)
*******************************************************************

.. currentmodule:: radionets.evaluation.train_inspection

Training inspection submodule of :mod:`radionets.evaluation`.


Reference/API
=============

.. automodapi:: radionets.evaluation.train_inspection
    :inherited-members:
