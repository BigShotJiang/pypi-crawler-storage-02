.. _contour:

**********************************************
Contour (:mod:`radionets.evaluation.contour`)
**********************************************

.. currentmodule:: radionets.evaluation.contour

Contour submodule of :mod:`radionets.evaluation`.


Reference/API
=============

.. automodapi:: radionets.evaluation.contour
    :inherited-members:
