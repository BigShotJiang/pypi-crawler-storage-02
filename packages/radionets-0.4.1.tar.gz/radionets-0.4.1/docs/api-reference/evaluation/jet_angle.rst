.. _jet_angle:

**************************************************
Jet Angle (:mod:`radionets.evaluatuion.jet_angle`)
**************************************************

.. currentmodule:: radionets.evaluation.jet_angle

Jet angle submodule of :mod:`radionets.evaluation`.


Reference/API
=============

.. automodapi:: radionets.evaluation.jet_angle
    :inherited-members:
