.. _jets:

****************************************
Jets (:mod:`radionets.evaluatuion.jets`)
****************************************

.. currentmodule:: radionets.evaluation.jets

Jets submodule of :mod:`radionets.evaluation`.


Reference/API
=============

.. automodapi:: radionets.evaluation.jets
    :inherited-members:
