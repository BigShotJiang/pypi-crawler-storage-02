.. _data:

*********************************
Data (:mod:`radionets.core.data`)
*********************************

.. currentmodule:: radionets.core.data

Data submodule of :mod:`radionets.core`.


Reference/API
=============

.. automodapi:: radionets.core.data
    :inherited-members:
