.. _callbacks:

*******************************************
Callbacks (:mod:`radionets.core.callbacks`)
*******************************************

.. currentmodule:: radionets.core.callbacks

Callbacks submodule of :mod:`radionets.core`.


Reference/API
=============

.. automodapi:: radionets.core.callbacks
    :inherited-members:
