.. _hist:

*******************************************
Histograms (:mod:`radionets.plotting.hist`)
*******************************************

.. currentmodule:: radionets.plotting.hist

Histograms submodule of :mod:`radionets.plotting`.


Reference/API
=============

.. automodapi:: radionets.plotting.hist
    :inherited-members:
