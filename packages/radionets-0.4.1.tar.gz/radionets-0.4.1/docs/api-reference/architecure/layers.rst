.. _layers:

*********************************************
Layers (:mod:`radionets.architecture.layers`)
*********************************************

.. currentmodule:: radionets.architecture.layers

Layers submodule of :mod:`radionets.blocks`.


Reference/API
=============

.. automodapi:: radionets.architecture.layers
    :inherited-members: Module
