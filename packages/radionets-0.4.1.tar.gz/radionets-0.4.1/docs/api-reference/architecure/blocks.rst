.. _blocks:

*********************************************
Blocks (:mod:`radionets.architecture.blocks`)
*********************************************

.. currentmodule:: radionets.architecture.blocks

Blocks submodule of :mod:`radionets.architecture`.


Reference/API
=============

.. automodapi:: radionets.architecture.blocks
    :inherited-members: Module
