.. _unc_archs:

*******************************************************************
Uncertainty Architectures (:mod:`radionets.architecture.unc_archs`)
*******************************************************************

.. currentmodule:: radionets.architecture.unc_archs

Uncertainty Architectures submodule of :mod:`radionets.blocks`.


Reference/API
=============

.. automodapi:: radionets.architecture.unc_archs
    :inherited-members: Module
