# Glossary

:::{glossary}
:sorted:

RIME
   Radio interferometer measurement equation.

NUFFT
   Nonuniform Fast Fourier Transform

FFT
   Fast Fourier Transform
:::
