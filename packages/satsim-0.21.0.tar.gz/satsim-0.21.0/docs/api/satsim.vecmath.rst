satsim.vecmath package
======================

.. automodule:: satsim.vecmath
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

satsim.vecmath.Cartesian2 module
--------------------------------

.. automodule:: satsim.vecmath.Cartesian2
   :members:
   :undoc-members:
   :show-inheritance:

satsim.vecmath.Cartesian3 module
--------------------------------

.. automodule:: satsim.vecmath.Cartesian3
   :members:
   :undoc-members:
   :show-inheritance:

satsim.vecmath.Cartesian4 module
--------------------------------

.. automodule:: satsim.vecmath.Cartesian4
   :members:
   :undoc-members:
   :show-inheritance:

satsim.vecmath.Matrix2 module
-----------------------------

.. automodule:: satsim.vecmath.Matrix2
   :members:
   :undoc-members:
   :show-inheritance:

satsim.vecmath.Matrix3 module
-----------------------------

.. automodule:: satsim.vecmath.Matrix3
   :members:
   :undoc-members:
   :show-inheritance:

satsim.vecmath.Matrix4 module
-----------------------------

.. automodule:: satsim.vecmath.Matrix4
   :members:
   :undoc-members:
   :show-inheritance:

satsim.vecmath.Quaternion module
--------------------------------

.. automodule:: satsim.vecmath.Quaternion
   :members:
   :undoc-members:
   :show-inheritance:
