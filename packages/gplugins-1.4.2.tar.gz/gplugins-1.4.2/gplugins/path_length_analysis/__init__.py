from gplugins.path_length_analysis.path_length_analysis import (
    report_pathlengths,
)

__all__ = [
    "report_pathlengths",
]
