# Copyright 2024 Canonical Ltd.
# See LICENSE file for licensing details.

"""This module exists only to enable templates file discovery."""
