import astropy.units as u
import nested_pandas as npd
import numpy as np
from astropy.visualization.wcsaxes import SphericalCircle, WCSAxes
from hats.catalog import TableProperties
from hats.pixel_math.validators import validate_declination_values, validate_radius
from mocpy import MOC

from lsdb.core.search.abstract_search import AbstractSearch
from lsdb.types import HCCatalogTypeVar


class ConeSearch(AbstractSearch):
    """Perform a cone search to filter the catalog

    Filters to points within radius great circle distance to the point specified by ra and dec in degrees.
    Filters partitions in the catalog to those that have some overlap with the cone.
    """

    def __init__(self, ra: float, dec: float, radius_arcsec: float, fine: bool = True):
        super().__init__(fine)
        validate_radius(radius_arcsec)
        validate_declination_values(dec)
        self.ra = ra
        self.dec = dec
        self.radius_arcsec = radius_arcsec

    def perform_hc_catalog_filter(self, hc_structure: HCCatalogTypeVar) -> MOC:
        """Filters catalog pixels according to the cone"""
        return hc_structure.filter_by_cone(self.ra, self.dec, self.radius_arcsec)

    def search_points(self, frame: npd.NestedFrame, metadata: TableProperties) -> npd.NestedFrame:
        """Determine the search results within a data frame"""
        return cone_filter(frame, self.ra, self.dec, self.radius_arcsec, metadata)

    def _perform_plot(self, ax: WCSAxes, **kwargs):
        kwargs_to_use = {"ec": "tab:red", "fc": "none"}
        kwargs_to_use.update(kwargs)

        circle = SphericalCircle(
            (self.ra * u.deg, self.dec * u.deg),
            self.radius_arcsec * u.arcsec,
            transform=ax.get_transform("icrs"),
            **kwargs_to_use,
        )
        ax.add_patch(circle)


def cone_filter(data_frame: npd.NestedFrame, ra, dec, radius_arcsec, metadata: TableProperties):
    """Filters a dataframe to only include points within the specified cone

    Args:
        data_frame (npd.NestedFrame): DataFrame containing points in the sky
        ra (float): Right Ascension of the center of the cone in degrees
        dec (float): Declination of the center of the cone in degrees
        radius_arcsec (float): Radius of the cone in arcseconds
        metadata (hc.TableProperties): hats `TableProperties` with metadata that matches `data_frame`

    Returns:
        A new DataFrame with the rows from `data_frame` filtered to only the points inside the cone
    """
    ra_rad = np.radians(data_frame[metadata.ra_column].to_numpy())
    dec_rad = np.radians(data_frame[metadata.dec_column].to_numpy())
    ra0 = np.radians(ra)
    dec0 = np.radians(dec)

    cos_angle = np.sin(dec_rad) * np.sin(dec0) + np.cos(dec_rad) * np.cos(dec0) * np.cos(ra_rad - ra0)

    # Clamp to valid range to avoid numerical issues
    cos_separation = np.clip(cos_angle, -1.0, 1.0)

    cos_radius = np.cos(np.radians(radius_arcsec / 3600))
    data_frame = data_frame[cos_separation >= cos_radius]
    return data_frame
