# LlamaIndex Embeddings Integration: Bedrock
