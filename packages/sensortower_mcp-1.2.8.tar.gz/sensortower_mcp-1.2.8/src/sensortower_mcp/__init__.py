"""
Sensor Tower MCP Server - A Model Context Protocol server for Sensor Tower APIs
"""

__version__ = "1.2.0"