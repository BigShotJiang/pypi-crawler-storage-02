# Makes selenium_hub a package for imports
from ._selenium_hub import SeleniumHub

__all__ = ["SeleniumHub"]
