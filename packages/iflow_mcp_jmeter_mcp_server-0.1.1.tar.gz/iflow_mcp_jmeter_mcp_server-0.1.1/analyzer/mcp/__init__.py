"""
MCP interface for the JMeter Test Results Analyzer.

This module provides MCP tools for analyzing JMeter test results.
"""