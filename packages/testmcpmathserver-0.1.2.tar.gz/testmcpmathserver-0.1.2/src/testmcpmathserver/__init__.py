from .mcp_tools import mcp

def main() -> None:
    """
    Main function to run the MCP tools.
    """
    mcp.run()