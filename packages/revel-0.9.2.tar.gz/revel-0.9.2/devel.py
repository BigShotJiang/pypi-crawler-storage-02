import revel
import revel.markup as markup_module
from colorama import init, Fore, Style
import os
import sys

init()


revel.input

