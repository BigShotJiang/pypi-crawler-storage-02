----------------------------------------
Publish documentation using GitLab pages
----------------------------------------

.. literalinclude:: ../../../templates/project-pages/template.yml
   :language: yaml