--------------------------------------
Project settings for nested submodules
--------------------------------------

.. literalinclude:: ../../../templates/project-config/template.yml
   :language: yaml