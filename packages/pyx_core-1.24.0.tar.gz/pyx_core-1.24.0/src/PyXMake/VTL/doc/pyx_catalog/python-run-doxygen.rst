---------------------------
Run a doxygen job in python
---------------------------

.. literalinclude:: ../../../templates/python-run-doxygen/template.yml
   :language: yaml