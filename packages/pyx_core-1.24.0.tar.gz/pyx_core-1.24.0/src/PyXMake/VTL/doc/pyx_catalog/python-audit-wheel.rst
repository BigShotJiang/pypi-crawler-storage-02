---------------------------------
Audit and validate a python wheel
---------------------------------

.. literalinclude:: ../../../templates/python-audit-wheel/template.yml
   :language: yaml