:sd_hide_title:
.. grid:: 1

    .. grid-item-card:: Changelog

        Get a quick overview over all release notes
---------
Changelog
---------
.. include:: ../../../CHANGELOG.md
	:end-before: [ [1.17.2
	:parser: myst_parser.docutils_
.. toctree::
   :hidden:
   
   self