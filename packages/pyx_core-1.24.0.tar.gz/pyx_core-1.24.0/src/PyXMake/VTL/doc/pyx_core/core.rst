.. grid:: 1

    .. grid-item-card:: How to install :fa:`person-running`

        Learn how to download and install `PyXMake`_ from source.

.. include:: ../../../README.md
	:start-line: 7
	:end-before: ## CI/CD Catalog
	:parser: myst_parser.docutils_

.. _PyXMake: https://pypi.org/project/pyxmake