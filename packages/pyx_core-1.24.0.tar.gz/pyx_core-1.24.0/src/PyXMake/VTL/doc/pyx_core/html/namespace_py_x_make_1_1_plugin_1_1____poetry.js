var namespace_py_x_make_1_1_plugin_1_1____poetry =
[
    [ "ApplicationPlugin", "class_py_x_make_1_1_plugin_1_1____poetry_1_1_application_plugin.html", "class_py_x_make_1_1_plugin_1_1____poetry_1_1_application_plugin" ],
    [ "Plugin", "class_py_x_make_1_1_plugin_1_1____poetry_1_1_plugin.html", "class_py_x_make_1_1_plugin_1_1____poetry_1_1_plugin" ],
    [ "build", "namespace_py_x_make_1_1_plugin_1_1____poetry.html#adf4738e2daccb8fc63790177afb7c221", null ],
    [ "install", "namespace_py_x_make_1_1_plugin_1_1____poetry.html#a8998324bee82690c5840bc990bda7760", null ],
    [ "load", "namespace_py_x_make_1_1_plugin_1_1____poetry.html#a0df3f9524e0766562c8f5819ea191f96", null ],
    [ "main", "namespace_py_x_make_1_1_plugin_1_1____poetry.html#af7791bed19cd7734443a742025ea92bd", null ],
    [ "setup", "namespace_py_x_make_1_1_plugin_1_1____poetry.html#a0678635bf99cf4652f99d218227a007e", null ]
];