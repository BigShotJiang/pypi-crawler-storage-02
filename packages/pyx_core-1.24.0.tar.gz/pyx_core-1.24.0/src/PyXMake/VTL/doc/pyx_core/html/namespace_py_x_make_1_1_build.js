var namespace_py_x_make_1_1_build =
[
    [ "__install__", "namespace_py_x_make_1_1_build_1_1____install____.html", [
      [ "main", "namespace_py_x_make_1_1_build_1_1____install____.html#a07b5de4d62db8fd7a62a1b1dcce0ea50", null ]
    ] ],
    [ "Make", "namespace_py_x_make_1_1_build_1_1_make.html", "namespace_py_x_make_1_1_build_1_1_make" ]
];