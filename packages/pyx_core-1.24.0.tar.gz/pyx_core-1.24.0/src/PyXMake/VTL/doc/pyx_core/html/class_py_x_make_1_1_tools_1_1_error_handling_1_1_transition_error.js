var class_py_x_make_1_1_tools_1_1_error_handling_1_1_transition_error =
[
    [ "__init__", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_transition_error.html#a419e06490beb4f2b5e737a63a7a6613c", null ],
    [ "Following", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_transition_error.html#aefac6a146f2291067415c72f04b2f816", null ],
    [ "Message", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_transition_error.html#a15045a92d0ccddf9b08c90b518f8741e", null ],
    [ "Previous", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_transition_error.html#aa4ec4e25cc0c2dd2db00fb930e47423d", null ]
];