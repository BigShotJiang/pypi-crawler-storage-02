# Average earnings

This extension calculates the average earnings of a large population.

```{eval-rst}
.. autofunction:: policyengine.outputs.macro.single.calculate_average_earnings.calculate_average_earnings
```