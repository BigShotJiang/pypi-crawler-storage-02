def test_package_imports():
    from policyengine import Simulation
