from policyengine import Simulation

sim = Simulation(
    country="uk",
    scope="macro",
    reform={},
    model_version="2.0.0",
)
