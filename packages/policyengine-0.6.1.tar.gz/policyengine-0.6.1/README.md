# policyengine.py

PolicyEngine's main user-facing Python package, incorporating country packages and integrating data visualization and analytics. Read the documentation [here](https://policyengine.github.io/policyengine.py).
