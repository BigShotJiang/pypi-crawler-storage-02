"""CASM lattice and structure mapping"""
