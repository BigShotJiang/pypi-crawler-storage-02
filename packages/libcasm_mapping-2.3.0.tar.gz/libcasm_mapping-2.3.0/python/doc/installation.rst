Installation
============


Install from PyPI
-----------------

.. note::

    CASM is built for macOS x86_64 (Intel), macOS arm64 (Apple Silicon), Linux x86_64, and Linux aarch64.

The latest release of libcasm-mapping can be installed with:

    pip install libcasm-mapping


Install from source
-------------------

See the `libcasm contribution guide`_.


For contributors
----------------

See the `libcasm contribution guide`_.


.. _`libcasm  contribution guide`: https://prisms-center.github.io/CASMcode_docs/pages/contributing_to_libcasm_packages/
.. _CASM: https://prisms-center.github.io/CASMcode_docs/
.. _GitHub: https://github.com/prisms-center/CASMcode_mapping/
