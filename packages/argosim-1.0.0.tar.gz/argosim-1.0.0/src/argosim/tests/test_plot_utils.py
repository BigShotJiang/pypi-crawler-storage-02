import numpy as np
import numpy.testing as npt

import argosim.plot_utils as apu

# Skip plotting tests in CI.
