from debug_gym.version import __version__
