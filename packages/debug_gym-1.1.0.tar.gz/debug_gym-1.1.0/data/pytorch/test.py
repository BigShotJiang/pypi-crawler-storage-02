from pytorch_code import prefix_tuning


def check(candidate):
    candidate()


check(prefix_tuning)
