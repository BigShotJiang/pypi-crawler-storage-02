class Constants:
    MAX_OF_RETRIES = 5
