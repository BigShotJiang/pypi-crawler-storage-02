# sutramarathi/__init__.py

from .interpreter import run_sutra_file

__version__ = "1.0.0"
__all__ = ["run_sutra_file"]
