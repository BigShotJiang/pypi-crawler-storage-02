#!/usr/bin/bash
cd /home/kocoadmin/koco_product_sqlmodel
/home/kocoadmin/.rye/shims/rye run server-gunicorn
