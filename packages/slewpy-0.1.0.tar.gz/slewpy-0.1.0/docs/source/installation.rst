============
Installation
============

The recommended way to install slewpy is using `pip <https://pip.pypa.io/en/stable/>`_

.. code-block:: console

    pip install slewpy
