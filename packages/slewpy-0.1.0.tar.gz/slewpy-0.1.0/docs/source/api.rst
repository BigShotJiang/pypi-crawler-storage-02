===
API
===

target
------

.. automodule:: slewpy.target
   :members:

sensor
------

.. automodule:: slewpy.sensor
   :members:


priority
--------

.. automodule:: slewpy.priority
   :members:

schedule
--------

.. automodule:: slewpy.schedule
   :members:

transmission
------------

.. automodule:: slewpy.transmission
   :members:

hub
---

.. automodule:: slewpy.hub
   :members:

serializer
----------

.. automodule:: slewpy.hub
   :members:

utils
-----

.. automodule:: slewpy.utils
   :members:
