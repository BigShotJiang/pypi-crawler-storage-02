FIELDS_ENDPOINT = "/entity/{entity_id}/fields/list"
ENTITIES_ENDPOINT = "/{app_id}/entity/list"