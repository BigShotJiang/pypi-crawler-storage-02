
## query_application_daily_stats

![img_10.png](img_10.png)

![img_11.png](img_11.png)