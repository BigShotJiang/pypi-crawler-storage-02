
## query_rtc_room_stuck_rate

![img_4.png](img_4.png)

![img_5.png](img_5.png)