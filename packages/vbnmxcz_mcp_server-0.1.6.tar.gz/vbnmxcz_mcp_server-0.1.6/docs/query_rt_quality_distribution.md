
## query_rtc_quality_distribution

![img_7.png](img_7.png)