
## query_rtc_room_top_20

![img_6.png](img_6.png)