from yunxin_mcp import server


def main():
    server.main()

if __name__ == "__main__":
    main()