from yunxin_mcp import main

main()