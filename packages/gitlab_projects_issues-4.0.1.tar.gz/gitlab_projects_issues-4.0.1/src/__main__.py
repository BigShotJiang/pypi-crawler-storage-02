# Components
from .cli.main import main

# Entrypoint
main()
