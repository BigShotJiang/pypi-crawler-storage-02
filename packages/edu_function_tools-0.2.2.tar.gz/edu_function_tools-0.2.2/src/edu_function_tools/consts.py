from function_tools.consts import (
    ALL as EDU_ALL,
)