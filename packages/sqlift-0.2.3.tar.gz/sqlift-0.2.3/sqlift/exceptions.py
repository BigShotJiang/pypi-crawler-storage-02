class UnsupportedDatabaseError(Exception):
    pass
