# dynamic_segment_tree/__init__.py
from ._dseg import DynamicSegTree

__all__ = ["DynamicSegTree"]
