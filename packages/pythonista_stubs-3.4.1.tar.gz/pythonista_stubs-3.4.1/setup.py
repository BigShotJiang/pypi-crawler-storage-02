# noqa: D100
from setuptools import setup

setup()
