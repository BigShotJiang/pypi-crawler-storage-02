''' Filters represent python functions that can be called from jinja2 in templates and in an appyter.
'''