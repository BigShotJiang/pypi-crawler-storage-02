''' A profile that uses bootstrap fields and stylesheets.
'''