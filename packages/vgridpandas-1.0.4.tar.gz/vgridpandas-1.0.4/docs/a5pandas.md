# A5Pandas module

::: vgridpandas.a5pandas