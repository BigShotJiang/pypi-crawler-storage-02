# Usage

You can try out vgridpandas by using Goolge Colab [![image](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/opengeoshub/vgridpandas/blob/master) or Binder [![image](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/opengeoshub/vgridpandas/HEAD) without having to install anything on your computer.

## Launch Jupyter Lab

```bash
jupyter lab
```

## Import vgridpandas

```python
import vgridpandas
```
