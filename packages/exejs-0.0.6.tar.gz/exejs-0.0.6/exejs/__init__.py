__version__ = "0.0.6"
__author__ = "UlionTse"

from exejs.runtimes import compile, execute, evaluate
from exejs.runtimes import reset_runtime, find_all_runtime_name_list
from exejs.runtimes import get_current_runtime, get_current_runtime_name
