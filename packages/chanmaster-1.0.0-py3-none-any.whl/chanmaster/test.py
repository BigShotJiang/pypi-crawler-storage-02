import sys
print('aaaa')