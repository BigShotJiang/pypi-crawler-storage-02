#pragma once

#define CISTA_UNUSED_PARAM(param) static_cast<void>(param);
