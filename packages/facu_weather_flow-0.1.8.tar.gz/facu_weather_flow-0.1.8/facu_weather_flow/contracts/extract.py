from abc import ABC, abstractmethod


class extractor(ABC):
    @abstractmethod
    def extract(Self):
        pass
