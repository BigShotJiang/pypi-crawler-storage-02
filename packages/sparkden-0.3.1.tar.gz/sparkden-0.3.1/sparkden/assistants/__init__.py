from .registry import AssistantRegistry

assistants = AssistantRegistry()

__all__ = [
    "assistants",
]
