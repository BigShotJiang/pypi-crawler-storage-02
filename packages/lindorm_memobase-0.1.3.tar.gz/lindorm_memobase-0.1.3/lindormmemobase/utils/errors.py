class ExternalAPIError(Exception):
    pass
