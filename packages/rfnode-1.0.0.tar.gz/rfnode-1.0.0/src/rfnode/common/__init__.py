"""
| Common package used . Package contains common classes used across the application
"""
