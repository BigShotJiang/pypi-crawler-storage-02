def test_broker():
    # broker = DataBroker()
    assert 1 == 1
