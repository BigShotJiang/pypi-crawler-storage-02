def test_device_manager():
    assert 1 == 1
