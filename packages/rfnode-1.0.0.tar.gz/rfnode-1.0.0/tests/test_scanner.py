def test_scanner():
    assert 1 == 1
