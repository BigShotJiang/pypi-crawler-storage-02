model
-----

.. automodule:: rfnode.model
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 2

   model/model
