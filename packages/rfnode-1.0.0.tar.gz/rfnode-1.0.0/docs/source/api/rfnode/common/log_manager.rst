.. automodule:: rfnode.common.log_manager
   :members:
   :undoc-members:
   :show-inheritance:
