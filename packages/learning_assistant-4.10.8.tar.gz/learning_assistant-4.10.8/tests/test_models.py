#!/usr/bin/env python
"""
Tests for the `learning-assistant` models module.
"""
