class FrogmlResourceNotFound(Exception):
    pass
