from .model import ChurnPrediction


def load_model():
    return ChurnPrediction()
