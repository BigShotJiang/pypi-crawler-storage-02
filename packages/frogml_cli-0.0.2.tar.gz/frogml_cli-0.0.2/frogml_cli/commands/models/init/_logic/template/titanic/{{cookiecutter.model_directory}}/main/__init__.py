from .model import TitanicSurvivalPrediction


def load_model():
    return TitanicSurvivalPrediction()
