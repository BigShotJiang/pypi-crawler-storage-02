def test_model():
    """
    Skeleton for a test that will run as part of the build process
    """
    assert True
