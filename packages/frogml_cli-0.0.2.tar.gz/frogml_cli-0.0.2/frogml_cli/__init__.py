# fmt: off
__author__ = '''JFrog Ltd.'''
__version__ = '0.0.2'
__name__ = 'frogml_cli'

from frogml import wire_dependencies

# fmt: on

wire_dependencies()
