from .logger import setup_frogml_logger

__all__ = ["setup_frogml_logger"]
