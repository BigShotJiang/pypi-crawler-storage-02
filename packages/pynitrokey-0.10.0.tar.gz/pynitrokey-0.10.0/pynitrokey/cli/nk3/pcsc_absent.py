# Copyright Nitrokey GmbH
# SPDX-License-Identifier: Apache-2.0 OR MIT

PCSC_ABSENT = "This command requires the pyscard library that is not available on your system. Please consult https://docs.nitrokey.com/nitrokeys/nitrokey3/troubleshooting#pyscard-is-not-available for more information"
