﻿edaflow.ml.create\_model\_report
================================

.. currentmodule:: edaflow.ml

.. autofunction:: create_model_report