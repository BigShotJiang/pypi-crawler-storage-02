__all__ = ['EmptyValue']


class EmptyValue:
    pass
