invalid_latex = {
        '\N{MINUS SIGN}': '-',
        r'\mathdefault': '', # used by matplotlib in latex mode
        }

