
from enum import Enum


class PyutDisplayParameters(Enum):
    """
    """

    WITH_PARAMETERS    = 'DisplayParameters'
    WITHOUT_PARAMETERS = 'DoNotDisplayParameters'
    UNSPECIFIED        = 'Unspecified'
