from pyutmodelv2._version import __version__
