from ._diff import DifferenceClassifier

__all__ = ["DifferenceClassifier"]
