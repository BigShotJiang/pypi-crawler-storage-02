#!/bin/bash
pip install -U pip-tools
pip-compile --extra dev, -o requirements.txt pyproject.toml --resolver=backtracking
pip-sync
