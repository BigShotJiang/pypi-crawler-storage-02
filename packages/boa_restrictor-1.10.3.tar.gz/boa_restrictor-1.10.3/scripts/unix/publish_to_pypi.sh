#!/bin/bash
flit publish --repository testpypi
flit publish
