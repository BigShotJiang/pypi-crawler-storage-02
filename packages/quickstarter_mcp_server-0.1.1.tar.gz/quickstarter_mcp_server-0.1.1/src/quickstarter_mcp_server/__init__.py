__version__ = "0.1.0"

from .detect_language_server import main