print("Hello Laktory!")
