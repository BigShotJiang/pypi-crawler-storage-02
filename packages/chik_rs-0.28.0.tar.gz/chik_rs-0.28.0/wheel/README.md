The `chik_rs` wheel contains python bindings for code from the `chik` crate.
