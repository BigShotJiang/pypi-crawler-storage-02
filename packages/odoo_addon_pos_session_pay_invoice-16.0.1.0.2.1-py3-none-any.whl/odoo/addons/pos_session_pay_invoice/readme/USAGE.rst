#.  Go to *Point of Sale / Dashboard* and create and open or access to an
    already open POS Session.
#.  Open the POS Session form view on the Backend.
#.  Press the button **Pay Supplier** to pay a Supplier Invoice or **Pay Refund** for a Customer
    Refund. It will be paid using Cash.
#.  Select **Get Payment from Invoice** to receive a payment of an
    existing Customer Invoice or a Supplier Refund. You will need to select
    a Journal if the POS Config has defined multiple Payment Methods.
