"""
data is a package that contains data files that support translation functionalities in aotpy.
"""
