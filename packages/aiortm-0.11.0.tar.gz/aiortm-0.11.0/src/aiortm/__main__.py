"""Make the CLI runnable using python -m aiortm."""

from .cli import cli

cli(prog_name="aiortm")
