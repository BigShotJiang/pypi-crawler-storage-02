# pushover-util

Python-based helper library for interacting with the
[Pushover API](https://pushover.net/api).

## Installation

```shell
$ pip install pushover-util
```
