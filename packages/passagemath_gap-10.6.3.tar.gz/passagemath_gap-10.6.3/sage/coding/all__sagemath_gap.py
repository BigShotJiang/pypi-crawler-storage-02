# sage_setup: distribution = sagemath-gap
