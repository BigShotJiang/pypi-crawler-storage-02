from arize.experimental.integrations.whylabs_vanguard_governance.client import (
    IntegrationClient,
)

__all__ = ["IntegrationClient"]
