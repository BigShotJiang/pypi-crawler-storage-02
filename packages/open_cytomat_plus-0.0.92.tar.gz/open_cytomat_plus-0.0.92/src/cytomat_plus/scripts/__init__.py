from .setup_cytomat_plus import post_install

__all__ = ["post_install"]