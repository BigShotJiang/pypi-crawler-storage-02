from django.apps import AppConfig


class AttachmentsTestappConfig(AppConfig):

    name = "tests.testapp"
    label = "attachments_testapp"
