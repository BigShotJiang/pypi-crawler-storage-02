import warnings

warnings.warn(
    "This package is deprecated: please use benchling_sdk.models if using the SDK, "
    "or benchling_api_client.v2.stable.models otherwise.",
    DeprecationWarning,
)
