%  Copyright (c) 2018 IRT-AESE.
%  All rights reserved.
%
%  Contributors:
%     INITIAL AUTHORS - API and implementation and/or documentation
%         :author: Fran�ois Gallard
%
%     OTHER AUTHORS   - MACROSCOPIC CHANGES

% function y = dummy_test(x,y,z)

I'm not a matlab function


I'm not a matlab function


I'm not a matlab function
