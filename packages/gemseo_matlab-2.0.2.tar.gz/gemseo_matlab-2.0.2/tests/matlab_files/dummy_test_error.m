%  Copyright (c) 2018 IRT-AESE.
%  All rights reserved.
%
%  Contributors:
%     INITIAL AUTHORS - API and implementation and/or documentation
%         :author: Fran�ois Gallard
%
%     OTHER AUTHORS   - MACROSCOPIC CHANGES

function y = dummy_test_error(x)
y=x^2;
error;
end
