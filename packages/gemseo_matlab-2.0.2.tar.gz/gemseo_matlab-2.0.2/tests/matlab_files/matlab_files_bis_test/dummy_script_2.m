%  Copyright (c) 2018 IRT-AESE.
%  All rights reserved.
%
%  Contributors:
%     INITIAL AUTHORS - API and implementation and/or documentation
%         :author: Nicolas Roussouly
%
%     OTHER AUTHORS   - MACROSCOPIC CHANGES


%dummy test for the matlab parser
clear all
close all
%test comments
a = 2;
b = 3;
c = [10, 20];
d = 'test_string';
% function test
