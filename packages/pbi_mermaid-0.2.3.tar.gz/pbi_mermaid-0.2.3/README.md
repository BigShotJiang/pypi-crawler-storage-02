# Dev Instructions

`pip install pbi_mermaid`

## Set Up

```shell
python -m venv venv
venv\Scripts\activate
python -m pip install .[dev]
pre-commit install
```