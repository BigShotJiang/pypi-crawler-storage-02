## Array Transformations

:::mismo.arrays.array_shuffle
:::mismo.arrays.array_choice
:::mismo.arrays.array_combinations
:::mismo.arrays.array_filter_isin_other

## Array Aggregations

:::mismo.arrays.array_any
:::mismo.arrays.array_all
:::mismo.arrays.array_min
:::mismo.arrays.array_max
:::mismo.arrays.array_mean
:::mismo.arrays.array_median
:::mismo.arrays.array_sum