# Text API

::: mismo.text.norm_whitespace
::: mismo.text.strip_accents
::: mismo.text.ngrams
::: mismo.text.tokenize
::: mismo.text.double_metaphone
::: mismo.text.levenshtein_ratio
::: mismo.text.damerau_levenshtein
::: mismo.text.damerau_levenshtein_ratio
::: mismo.text.jaro_similarity
::: mismo.text.jaro_winkler_similarity
