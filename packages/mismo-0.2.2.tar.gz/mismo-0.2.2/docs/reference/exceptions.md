# Exceptions

::: mismo.exceptions