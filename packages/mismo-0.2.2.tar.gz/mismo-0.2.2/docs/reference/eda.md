# EDA API

This module contains utilities for cleaning and preparing data for linkage.

::: mismo.eda.distribution_chart
::: mismo.eda.distribution_dashboard