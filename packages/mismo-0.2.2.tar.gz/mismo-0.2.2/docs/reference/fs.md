# Fellegi-Sunter Model

See [the Fellegi-Sunter Concept guide](../concepts/fs.md) for background info.

::: mismo.fs.Weights
::: mismo.fs.ComparerWeights
::: mismo.fs.LevelWeights
::: mismo.fs.train_using_labels
::: mismo.fs.train_using_em
::: mismo.fs.plot_weights