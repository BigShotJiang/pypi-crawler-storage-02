# Play Data

Load some toy datasets for testing and examples.

::: mismo.playdata.load_patents
::: mismo.playdata.load_rldata500
::: mismo.playdata.load_rldata10000
::: mismo.playdata.load_febrl1
::: mismo.playdata.load_febrl2
::: mismo.playdata.load_febrl3
