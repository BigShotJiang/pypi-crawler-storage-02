# Emails API

This contains utilities, blockers, and comparers relevant to email addresses

::: mismo.lib.email.clean_email
::: mismo.lib.email.ParsedEmail
::: mismo.lib.email.match_level
::: mismo.lib.email.EmailMatchLevel
::: mismo.lib.email.EmailsDimension