# Human Names API

This contains utilities, blockers, and comparers relevant to human names

::: mismo.lib.name.normalize_name
::: mismo.lib.name.are_aliases
::: mismo.lib.name.is_nickname_for
::: mismo.lib.name.NameMatchLevel
::: mismo.lib.name.NameComparer
::: mismo.lib.name.NameDimension