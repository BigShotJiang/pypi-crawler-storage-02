# Phones API

This contains utilities, blockers, and comparers relevant to phone numbers

::: mismo.lib.phone.clean_phone_number
::: mismo.lib.phone.match_level
::: mismo.lib.phone.PhoneMatchLevel
::: mismo.lib.phone.PhonesDimension