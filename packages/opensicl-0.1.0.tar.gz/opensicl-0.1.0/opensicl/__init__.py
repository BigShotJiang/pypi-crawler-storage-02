"""OpenSICL package."""

__all__ = ["extractor", "retriever"]

__version__ = "0.1.0"

