from monopoly.log import get_logger

logger = get_logger()
