"""
Radio astronomy image post-processing tools

author - Landman Bester
email  - lbester@sarao.ac.za
date   - 16/06/2022
"""

__version__='0.0.5'

