**Date**: |today|, **Version**: |version|


.. include:: ../../README.rst
    :start-line: 0

.. toctree::
    :hidden:

    theory
    code
    gallery/index
    references