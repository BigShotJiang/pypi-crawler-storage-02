#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .configuration_01x01 import *  # noqa: F401, F403
from .configuration_02x02 import *  # noqa: F401, F403
from .configuration_03x03 import *  # noqa: F401, F403
from .configuration_04x04 import *  # noqa: F401, F403
from .configuration_05x05 import *  # noqa: F401, F403

# -
