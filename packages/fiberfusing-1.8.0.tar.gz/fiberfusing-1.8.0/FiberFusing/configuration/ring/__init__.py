#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .configuration_01x01 import *
from .configuration_02x02 import *
from .configuration_03x03 import *
from .configuration_04x04 import *
from .configuration_05x05 import *
from .configuration_06x06 import *
from .configuration_07x07 import *
from .configuration_10x10 import *
from .configuration_12x12 import *
from .configuration_19x19 import *

# -
