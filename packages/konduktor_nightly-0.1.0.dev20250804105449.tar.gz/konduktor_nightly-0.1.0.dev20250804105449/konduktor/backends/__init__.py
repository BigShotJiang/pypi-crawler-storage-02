"""Batch job backends"""

from konduktor.backends.jobset import JobsetBackend

__all__ = [
    'Backend',
    'JobsetBackend',
]
