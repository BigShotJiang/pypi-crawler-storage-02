install_custom_sql_scripts("addressbook")
