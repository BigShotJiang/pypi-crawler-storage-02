synchronize_eschema("PhoneNumber", ask_confirm=False)
