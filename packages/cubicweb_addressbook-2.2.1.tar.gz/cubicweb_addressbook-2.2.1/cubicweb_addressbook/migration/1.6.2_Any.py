sync_schema_props_perms("latitude")
sync_schema_props_perms("longitude")
