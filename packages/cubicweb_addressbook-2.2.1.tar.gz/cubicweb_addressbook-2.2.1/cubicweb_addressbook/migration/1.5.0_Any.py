add_attribute("PostalAddress", "latitude")
add_attribute("PostalAddress", "longitude")
add_entity_type("IMAddress")
