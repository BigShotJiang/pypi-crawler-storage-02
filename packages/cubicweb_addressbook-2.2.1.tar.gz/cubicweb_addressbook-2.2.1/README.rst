Summary
-------

The addressbook cube adds a phone number, postal address and instant
messenger address (supports icq, msn and jabber) to the schema.

Views description
-----------------
There's only basic entity views in there.
