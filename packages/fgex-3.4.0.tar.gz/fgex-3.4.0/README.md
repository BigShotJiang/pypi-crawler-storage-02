# Firegex python library

Alias of 'firegex' libaray. This library is used to get additional feature of firegex and use the feature of the command 'fgex'.