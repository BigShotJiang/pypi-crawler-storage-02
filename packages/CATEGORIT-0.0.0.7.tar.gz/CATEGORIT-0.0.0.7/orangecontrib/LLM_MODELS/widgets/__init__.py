"""
Widgets from Development workflow category

"""
# ID = "orangecontrib.AAIT"

NAME = "AAIT - MODELS"

# Category icon show in the menu
ICON = "icons/models.png"

BACKGROUND = "light-purple"

DESCRIPTION = ("AAIT - MODELS")



# PRIORITY = 6