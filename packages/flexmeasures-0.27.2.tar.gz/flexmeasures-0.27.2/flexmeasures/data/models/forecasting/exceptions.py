class NotEnoughDataException(Exception):
    pass


class InvalidHorizonException(Exception):
    pass
