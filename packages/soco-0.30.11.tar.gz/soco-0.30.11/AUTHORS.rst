Project Creator
===============
SoCo was created in 2012 at Music Hack Day Sydney by Rahim Sonawalla


Maintainers
===========

* Lawrence Akka
* Stefan Kögl
* Kenneth Nielsen
* David Harding


Contributors
============

(alphabetical)

* Petter Aas
* Murali Allada
* Joel Björkman
* Aaron Daubman
* Johan Elmerfjord
* David Harding
* Jeff Hinrichs
* Jeroen Idserda
* Hugo van Kemenade
* Todd Neal
* nixscripter
* Kenneth Nielsen
* Dave O'Connor
* Dennnis O'Reilly
* phut
* Dan Poirier
* Jason Ting
* Peter Toft (pwt)
* Scott G Waters

