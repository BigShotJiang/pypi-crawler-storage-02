soco.plugins.plex module
=============================

.. automodule:: soco.plugins.plex
    :member-order: bysource
    :members:
