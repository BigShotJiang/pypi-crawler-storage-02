soco.discovery module
=====================

.. automodule:: soco.discovery
    :member-order: bysource
    :members:
