soco.plugins.spotify module
===========================

.. automodule:: soco.plugins.spotify
    :member-order: bysource
    :members:
