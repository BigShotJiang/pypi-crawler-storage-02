soco.data_structures module
===========================

.. automodule:: soco.data_structures
    :member-order: bysource
    :members:
