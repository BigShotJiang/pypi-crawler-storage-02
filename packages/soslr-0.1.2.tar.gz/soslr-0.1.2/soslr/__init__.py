from .sos import train, predict

__version__ = "0.1.2"
__author__ = "Soroush Oskouei"