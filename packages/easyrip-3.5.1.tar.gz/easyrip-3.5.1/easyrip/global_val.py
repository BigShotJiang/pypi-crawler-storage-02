class Global_val:
    PROJECT_NAME = "Easy Rip"
    PROJECT_VERSION = "3.5.1"
    PROJECT_TITLE = f"{PROJECT_NAME} v{PROJECT_VERSION}"
    PROJECT_URL = "https://github.com/op200/EasyRip"
    PROJECT_RELEASE_API = "https://api.github.com/repos/op200/EasyRip/releases/latest"
