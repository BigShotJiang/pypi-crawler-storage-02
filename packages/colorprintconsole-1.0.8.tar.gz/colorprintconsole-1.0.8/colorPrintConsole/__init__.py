from .ColorPrint import ColorPrint

cp = ColorPrint()
