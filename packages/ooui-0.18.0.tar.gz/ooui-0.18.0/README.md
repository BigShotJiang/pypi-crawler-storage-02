# python-ooui
Port of ooui.js to Python

## Testing

```shell
pip install -e .
pip install -r requirements-dev.txt
mamba
```
