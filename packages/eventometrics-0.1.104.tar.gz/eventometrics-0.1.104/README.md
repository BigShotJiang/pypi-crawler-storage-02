# econometrics Package

A framework for forecasting economic events.

This very first version contains only a simple model. 
Created by the author as part of his dissertation work.
The package is hosted on PyPi mainly to reserve the library name. 
The library will evolve as it gains support.

Author: Korablev Yuriy Aleksandrovich

email: yura-korablyov@yandex.ru