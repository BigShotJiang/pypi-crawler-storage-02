from pbi_core.ssas.model_tables.base import SsasTable


class Set(SsasTable):
    """TBD.

    SSAS spec:
    """
