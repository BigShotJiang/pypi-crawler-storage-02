# Calculation Group


::: pbi_core.ssas.model_tables.calculation_group.CalculationGroup