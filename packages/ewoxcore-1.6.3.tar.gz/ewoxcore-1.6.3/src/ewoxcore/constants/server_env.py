class ServerEnv():
    ENVIRONMENT = "APP_ENV"
    PRODUCTION = "production"
    STAGING = "staging"
    DEVELOPMENT = "development"
