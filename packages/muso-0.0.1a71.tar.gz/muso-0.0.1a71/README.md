# muso
A simple, IDE-Friendly async JSON API-Framework based on **M**arshmallow / **U**vicorn / **S**tarlette / **O**rjson.
