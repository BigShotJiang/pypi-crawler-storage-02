"""
Use FFprobe through easy to use function or use flags to get specific data

"""

from .ffprobe import ffprobe

__all__ = ["ffprobe"]
