def main(epochs=2):
    print('Example placeholder run, epochs=', epochs)
if __name__=='__main__': main()
