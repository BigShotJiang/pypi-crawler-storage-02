::: abstract_dataloader.spec
    options:
        heading: "Abstract Dataloader Specifications"
        members:
        - Metadata
        - Sensor
        - Synchronization
        - Trace
        - Dataset
        - Transform
        - Collate
        - Pipeline
