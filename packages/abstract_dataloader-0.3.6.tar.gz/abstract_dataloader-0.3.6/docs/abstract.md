::: abstract_dataloader.abstract
    options:
        heading: "Abstract Base Classes"
        members:
        - Metadata
        - Sensor
        - Synchronization
        - Trace
        - Dataset
        - Transform
        - Collate
        - Pipeline
