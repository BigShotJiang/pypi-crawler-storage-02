::: abstract_dataloader.ext.sample
