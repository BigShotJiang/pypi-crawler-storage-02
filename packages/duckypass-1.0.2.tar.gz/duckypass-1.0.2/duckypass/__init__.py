# This file initializes the DuckyPassAPI module and defines the public interface.

from .duckypass import DuckyPass

__all__ = ['DuckyPass']