# sage_setup: distribution = sagemath-pari

from sage.rings.padics.all__sagemath_flint import *
