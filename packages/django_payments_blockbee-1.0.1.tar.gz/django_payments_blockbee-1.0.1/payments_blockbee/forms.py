from django import forms
from .widgets import BlockBeeCheckoutWidget

class BlockBeeCheckoutForm(forms.Form):
    def __init__(self, payment_url, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["blockbee_checkout"] = forms.CharField(
            widget=BlockBeeCheckoutWidget(payment_url=payment_url),
            required=False
        )
