from django.forms.widgets import Widget
from django.utils.safestring import mark_safe

class BlockBeeCheckoutWidget(Widget):
    def __init__(self, payment_url=None, attrs=None):
        super().__init__(attrs)
        self.payment_url = payment_url

    def render(self, name, value, title='Pay with BlockBee', attrs=None, renderer=None):
        return mark_safe(f'''
            <div class="blockbee-checkout">
                <a href="{self.payment_url}" target="_blank" class="btn btn-primary">
                    {title}
                </a>
            </div>
        ''')