Modelo 115 de la AEAT. Retenciones e ingresos a cuenta. Rentas o
rendimientos procedentes del arrendamiento o subarrendamiento de
inmuebles urbanos.
