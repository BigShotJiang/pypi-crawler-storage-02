Para crear un modelo, por ejemplo de un trimestre del año:

1.  Ir a *Facturación \> Declaraciones AEAT \> Modelo 115*.
2.  Pulsar en el botón "Crear"
3.  Seleccionar el ejercicio fiscal y el tipo de período, los periodos
    incluidos se calculan automáticamente
4.  Seleccionar el tipo de declaración y la cuenta bancaria
5.  Rellenar el teléfono, necesario para la exportacion BOE
6.  Guardar y pulsar en el botón "Calcular"
7.  Cuando los valores sean los correctos, pulsar en el botón
    "Confirmar"
8.  Podemos exportar en formato BOE para presentarlo telemáticamente en
    el portal de la AEAT
