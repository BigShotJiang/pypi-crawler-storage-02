"""Processor based on Nameparser"""
__version__ = "0.5.23"
