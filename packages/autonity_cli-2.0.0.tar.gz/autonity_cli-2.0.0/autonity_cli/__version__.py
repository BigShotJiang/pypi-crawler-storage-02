"""
Module version information.
"""

__version__ = "2.0.0"
