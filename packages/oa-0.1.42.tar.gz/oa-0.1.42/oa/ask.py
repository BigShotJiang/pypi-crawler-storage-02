"""Access to already made prompt functions"""

from oa.tools import PromptFuncs

ai = PromptFuncs()
