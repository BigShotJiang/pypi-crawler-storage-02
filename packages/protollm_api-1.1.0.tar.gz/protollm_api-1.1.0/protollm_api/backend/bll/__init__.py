"""
Buisnes Logic Lyaer
"""