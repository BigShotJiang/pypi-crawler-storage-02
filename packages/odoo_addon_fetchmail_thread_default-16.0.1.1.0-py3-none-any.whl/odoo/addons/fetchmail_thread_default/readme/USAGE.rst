To use this module, you need to:

#. Subscribe to the thread you chose as the *Default mail thread*.
#. You will be notified when a new unbound email lands in that thread.
#. Do what you want with it.
