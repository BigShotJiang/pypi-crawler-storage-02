* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis
  * David Vidal

* `Therp BV <https://www.therp.nl>`_:

  * Giovanni Francesco Capalbo
