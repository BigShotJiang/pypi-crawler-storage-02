from .LinkdAPI import LinkdAPI

__version__ = "1.0.0"
__all__ = ["LinkdAPI"]