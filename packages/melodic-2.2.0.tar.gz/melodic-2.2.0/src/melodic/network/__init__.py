"""Network modules for Melodic."""

from .manager import NetworkManager

__all__ = ["NetworkManager"]
