class Bridge:
    module_name = None

    def execute(self, *args):
        pass

    def log(self):
        pass
