class Bank:
    def supply(self, account, amount):
        pass

    def borrow(self, account, amount):
        pass

    def get_repay_borrow_amount(self, account):
        pass

    def repay_borrow(self, account, amount):
        pass

    def redeem(self, account, amount, token):
        pass

    def get_deposit_amount(self, account, token):
        pass
