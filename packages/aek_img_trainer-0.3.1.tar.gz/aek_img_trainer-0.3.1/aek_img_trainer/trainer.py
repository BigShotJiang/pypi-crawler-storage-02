import os
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.optim.lr_scheduler import StepLR, ReduceLROnPlateau
import numpy as np
import time
import timm
import random


class Preprocessor:
    """
    Handles image augmentation and preprocessing steps including resizing,
    normalization, and conversion to tensor format compatible with PyTorch.
    """

    def __init__(self, img_size=224, augment=False):
        """
        Initialize the Preprocessor.

        Args:
            img_size (int): Target size for image resizing (width and height).
            augment (bool): Whether to apply augmentation in transforms.
        """
        self.img_size = img_size
        self.augment = augment
    
    def random_brightness_contrast(self, img, brightness=0.2, contrast=0.2):
        """
        Apply random brightness and contrast adjustment to the image.

        Args:
            img (np.ndarray): Input image.
            brightness (float): Maximum brightness shift as a fraction.
            contrast (float): Maximum contrast scale factor.
        
        Return:
            np.ndarray: Augmented image.
        """
        beta = random.uniform(-brightness*255, brightness*255)
        alpha = random.uniform(1-contrast, 1+contrast)
        img = img.astype(np.float32) * alpha + beta
        img = np.clip(img, 0, 255).astype(np.uint8)
        return img
    
    def random_rotation(self, img, degrees=15):
        """
        Rotate the image randomly within the specified degree range.

        Args:
            img (np.ndarray): Input image.
            degrees (float): Maximum rotation angle in degrees.
        
        Returns:
            np.ndarray: Rotated image.
        """
        h, w = img.shape[:2]
        angle = random.uniform(-degrees, degrees)
        M = cv2.getRotationMatrix2D((w/2, h/2), angle, 1.0)
        img = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
        return img
    
    def random_affine(self, img, translate=0.1, scale_range=(0.8, 1.2), shear=5):
        """
        Apply random affine transformation including translation, scaling, and shearing.

        Args:
            img (np.ndarray): Input image.
            translate (float): Max translation as a fraction of image dimension.
            scale_range (tuple): Min and max scale factors.
            shear (float): Max shear angle in degrees.
        
        Returns:
            np.ndarray: Affine transformed image.
        """

        h, w = img.shape[:2]
        max_tx = translate * w
        max_ty= translate * h
        tx = random.uniform(-max_tx, max_tx)
        ty = random.uniform(-max_ty, max_ty)
        scale = random.uniform(scale_range[0], scale_range[1])
        shear_angle = random.uniform(-shear, shear)
        shear_rad = np.deg2rad(shear_angle)
        M = np.array([
            [scale, np.tan(shear_rad), tx],
            [0, scale, ty]
        ], dtype=np.float32)
        img = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
        return img
    
    def random_flip(self, img, p_horizontal=0.5, p_vertical=0.1):
        """
        Randomly flip the image horizontally and/or vertically.

        Args:
            img (np.ndarray): Input image.
            p_horizontal (float): Probability of horizontal flip.
            p_vertical (float): Probability of vertical flip.

        Return:
            np.ndarray: Flipped image.
        """
        if random.random() < p_horizontal:
            img = cv2.flip(img, 1)
        if random.random() < p_vertical:
            img = cv2.flip(img, 0)
        return img
    
    def random_perspective(self, img, distortion_scale=0.1, p=0.3):
        """
        Apply random perspective distortion with given probability.

        Args:
            img (np.ndarray): Input image.
            distortion_scale (float): Max distortion as a fraction of image size.
            p (float): Probability to apply perspective transform.

        Returns:
            np.ndarray: Perspective transformed image or original image.
        """
        if random.random() > p:
            return img
        h, w = img.shape[:2]
        pts1 = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
        max_dx = distortion_scale * w
        max_dy = distortion_scale * h
        pts2 = pts1 + np.float32([
            [random.uniform(-max_dx, max_dx), random.uniform(-max_dy, max_dy)],
            [random.uniform(-max_dx, max_dx), random.uniform(-max_dy, max_dy)],
            [random.uniform(-max_dx, max_dx), random.uniform(-max_dy, max_dy)],
            [random.uniform(-max_dx, max_dx), random.uniform(-max_dy, max_dy)],
        ])
        M = cv2.getPerspectiveTransform(pts1, pts2)
        img = cv2.warpPerspective(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
        return img
    
    def apply_augmentations(self, img):
        """
        Apply all augmentation transforms sequentially.

        Args:
            img (np.ndarray): Input image.

        Return:
            np.ndarray: Augmented image.
        """
        img = self.random_brightness_contrast(img)
        img = self.random_rotation(img)
        img = self.random_affine(img)
        img = self.random_flip(img)
        img = self.random_perspective(img)
        return img
    
    def preprocess_image(self, img):
        """
        Preprocess the image: optionally augment, resize, normalize, convert to tensor.

        Args:
            img (np.ndarray): Input image.

        Returns:
            np.ndarray: Preprocessed image blob with shape (3, img_size, img_size).

        """
        if self.augment:
            img = self.apply_augmentations(img)
        blob = cv2.dnn.blobFromImage(
            image=img,
            scalefactor=2.0/255.0,
            size=(self.img_size, self.img_size),
            mean=(1.0, 1.0, 1.0),
            swapRB=True,
            crop=False
        )
        return blob.squeeze(0)

class ImageFolderOpenCV(Dataset):
    """
    Custom PyTorch Dataset to load images using OpenCV with preprocessing support.
    Assumes directory structure with subfolders per class.
    """
    
    def __init__(self, root_dir, preprocessor: Preprocessor):
        """
        Args:
            root_dir (str): Path to dataset root directory.
            preprocessor (Preprocessor): Instance of Preprocessor for augmentation & preprocessing.
        """
        self.root_dir = root_dir
        self.preprocessor = preprocessor
        self.samples = []
        self.class_to_idx = {}

        for idx, class_name in enumerate(sorted(os.listdir(root_dir))):
            class_path = os.path.join(root_dir, class_name)
            if not os.path.isdir(class_path):
                continue
            self.class_to_idx[class_name] = idx
            for fnmae in os.listdir(class_path):
                if fnmae.lower().endswith((".jpg", ".jpeg", ".png")):
                    self.samples.append((os.path.join(class_path, fnmae), idx))
    
    def __len__(self):
        """
        Returns:
            int: Number of samples in the dataset.
        """
        return len(self.samples)
    
    def __getitem__(self, idx):
        """
        Get a sample image tensor and its label.

        Args:
            idx (int): Index of sample.

        Returns:
            tuple: (image_tensor (torch.FloatTensor), label (int))
        """
        img_path, label = self.samples[idx]
        img = cv2.imread(img_path, cv2.IMREAD_COLOR)
        img = self.preprocessor.preprocess_image(img)
        return torch.from_numpy(img).float(), label
    
class Trainer:
    """
    Trainer class encapsulates model creation, training and validation loops,
    checkpoint saving and early stopping based on validation accuracy.
    """

    def __init__(self,
                 train_root,
                 val_root,
                 num_classes=16,
                 img_size=224,
                 batch_size=4,
                 val_reach=0.9999,
                 num_epochs=150,
                 learning_rate=1e-3,
                 checkpoint_path="efficientnet_b0_best_model.pth",
                 model_name = "efficientnet_b0",
                 device=None,
                 augment=True,
                 scheduler=None,
                 scheduler_params=None,
                 pretrained=True):
        """
        Initialize Trainer with datasets, model, loss, optimizer, and loaders.

        Args:
            train_root (str): Path to training dataset root directory.
            val_root (str): Path to validation dataset root directory.
            num_classes (int): Number of target classes.
            img_size (int): Image size (width and height) for resizing.
            batch_size (int): Batch size for traning and validation.
            num_epochs (int): Number of epochs to train.
            learning_rate (float): Learning rate for optimizer.
            checkpoint_path (str): File path to save the best model weights.
            model_name (str): Model name to create with timm
            device (torch.device or None): Device to train on, defaults to CUDA if available.
            augment (bool): Whether to apply augmentations on training data.
        """

        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.num_classes = num_classes
        self.img_size = img_size
        self.batch_size = batch_size
        self.num_epochs = num_epochs
        self.learning_rate = learning_rate
        self.checkpoint_path = checkpoint_path
        self.model_name = model_name
        self.pretrained = pretrained
        self.val_reach = val_reach

        self.train_preproc = Preprocessor(img_size=img_size, augment=augment)
        self.val_preproc = Preprocessor(img_size=img_size, augment=False)

        self.train_dataset = ImageFolderOpenCV(train_root, self.train_preproc)
        self.val_dataset = ImageFolderOpenCV(val_root, self.val_preproc)

        self.train_loader = DataLoader(self.train_dataset, batch_size=batch_size, shuffle=True)
        self.val_loader = DataLoader(self.val_dataset, batch_size=batch_size, shuffle=False)

        self.model = timm.create_model(model_name, pretrained=self.pretrained)
        self.model = self._replace_classifier(self.model, self.num_classes)
        self.model.to(self.device)

        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = optim.AdamW(self.model.parameters(), lr=learning_rate)

        if scheduler is not None:
            self.scheduler = scheduler(self.optimizer, **(scheduler_params or {}))
        else:
            self.scheduler = None

        self.best_val_loss = float("inf")

    def _replace_classifier(self, model, num_classes):
        """
        Replace the classification head of timm model to match the number of classes.

        This method handles common classifier attribute names used in timm models such as:
        - 'classifier'
        - 'fc'
        - 'head'

        Args:
            model (torch.nn.Module): The pre-trained model instance.
            num_classes (int): Number of target output classes.

        Returns:
            torch.nn.Module: The model with the replaced classification head.

        Raises:
            AttributeError: If no known classifier attribute is found in the model.
        """
        if hasattr(model, "classifier") and isinstance(model.classifier, nn.Linear):
            in_features = model.classifier.in_features
            model.classifier = nn.Linear(in_features, num_classes)
        elif hasattr(model, "fc") and isinstance(model.fc, nn.Linear):
            in_features = model.fc.in_features
            model.fc = nn.Linear(in_features, num_classes)
        elif hasattr(model, "head") and isinstance(model.head, nn.Linear):
            in_features = model.head.in_features
            model.head = nn.Linear(in_features, num_classes)
        else:
            raise AttributeError("No known classifier layer found in the model to replace.")
        return model

    def evaluate(self):
        """
        Evaluate the model on the validation dataset.

        Returns:
            tuple: (avg_val_loss (float), val_accuracy (float))
        """
        self.model.eval()
        total_loss = 0.0
        correct = 0
        total = 0

        with torch.no_grad():
            for inputs, labels in self.val_loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                outputs = self.model(inputs)
                loss = self.criterion(outputs, labels)

                total_loss += loss.item() * inputs.size(0)
                _, preds = torch.max(outputs, 1)
                correct += (preds == labels).sum().item()
                total += labels.size(0)

        avg_loss = total_loss / total
        accuracy = correct / total
        return avg_loss, accuracy
    
    def train(self):
        """
        Run the training and validation loop for the specified number of epochs.
        Saves the best model based on validation loss and implements early stopping
        if validation accuracy exceeds 99.99%.

        Prints training/validation statistics for each epoch. 
        """
        for epoch in range(self.num_epochs):
            self.model.train()
            running_loss = 0.0
            start_time = time.time()

            for inputs, labels in self.train_loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)

                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = self.criterion(outputs, labels)
                loss.backward()
                self.optimizer.step()
                
                running_loss += loss.item() * inputs.size(0)

            train_loss = running_loss / len(self.train_dataset)
            val_loss, val_acc = self.evaluate()
            current_lr = self.optimizer.param_groups[0]["lr"]
            elapsed = time.time() - start_time

            print(f"Epoch {epoch+1}/{self.num_epochs} | Train Loss: {train_loss:.4f} | "
                  f"Val Loss: {val_loss:.4f} | Val Acc: {val_acc*100:.2f}% | "
                  f"LR: {current_lr:.2e} | Time: {elapsed:.1f}s")
            
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                torch.save(self.model.state_dict(), self.checkpoint_path)
                print(f"Best model saved! Val Loss: {self.best_val_loss:.4f}")
            
            if self.scheduler is not None:
                if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.scheduler.step(val_loss)
                else:
                    self.scheduler.step()

            if val_acc >= self.val_reach:
                print(f"Val Accuracy reached {self.val_reach * 100:.2f}% training is stopped early.")
                break
        print("Training completed")
    
    def help(self):
        """
        Prints all methods of the Trainer class with their dockstrings.
        Useful for quick reference of available functionalities.
        """
        print(f"Help for {self.__class__.__name__} class methods:\n")
        
        for name, func in self.__class__.__dict__.items():
                if callable(func) and not name.startswith('_'):
                    doc = func.__doc__ or "No documentation available."
                    print(f"Method: {name} \n{'-'*40}\n{doc.strip()}\n")


    
    def print_model_info(self):
        """
        Prints detailed information about the loaded model:
        - Model architecture
        - Model class type
        - Total and trainable parameter counts
        """
        print("=== Model Information ===")
        print(f"Model class: {type(self.model)}\n")
        print(f"Model architecture:\n{self.model}\n")

        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        print(f"Total parameters: {total_params:,}")
        print(f"Trainable parameters: {trainable_params:,}")
        print("=============================")
    
    def list_all_timm_models(self):
        """
        Prints all available model name in the timm library along with the total count.

        Use this to check which pretrained or custom models you can specify
        via the `model_name` parameters in the Trainer()

        Args:
            None
        
        Returns:
            None
        """
        models = timm.list_models(pretrained=False)
        print(f"Total {len(models)} models found in the timm:\n")
        for model_name in models:
            print(model_name)