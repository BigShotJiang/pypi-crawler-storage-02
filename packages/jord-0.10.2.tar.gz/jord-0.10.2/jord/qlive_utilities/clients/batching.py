# TODO: MAKE CLIENT THAT BATCHES features in layers within a context __enter__ and finally sends the data at
#  __exit__
