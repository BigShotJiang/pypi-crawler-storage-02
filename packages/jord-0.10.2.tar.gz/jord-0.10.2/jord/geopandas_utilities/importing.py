import os

os.environ["USE_PYGEOS"] = "0"

import geopandas

__all__ = ["geopandas"]
