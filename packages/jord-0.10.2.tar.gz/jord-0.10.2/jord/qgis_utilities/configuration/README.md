# jord/qgis_utilities/configuration
