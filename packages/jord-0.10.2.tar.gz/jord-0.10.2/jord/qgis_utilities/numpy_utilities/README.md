# jord/qgis_utilities/numpy_utilities
