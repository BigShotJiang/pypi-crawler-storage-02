python computer vision neo droid
