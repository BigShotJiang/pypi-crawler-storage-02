# LinkedinApp MCP Server

An MCP Server for the LinkedinApp API.

## 🛠️ Tool List

This is automatically generated from OpenAPI schema for the LinkedinApp API.


| Tool | Description |
|------|-------------|
| `create_post` | Create a post on LinkedIn. |
| `get_your_info` | Get your LinkedIn profile information. |
| `delete_post` | Delete a post on LinkedIn. |
| `update_post` | Update a post on LinkedIn. |
