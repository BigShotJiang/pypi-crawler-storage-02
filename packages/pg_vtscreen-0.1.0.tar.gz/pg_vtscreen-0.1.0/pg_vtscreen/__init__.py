__version__ = "0.1.0"
from .virtual_screen_manager import VirtualScreenManager