# simpleslug

A simple Python function to convert text into URL-friendly slugs.

## Installation
```bash
pip install simpleslug
