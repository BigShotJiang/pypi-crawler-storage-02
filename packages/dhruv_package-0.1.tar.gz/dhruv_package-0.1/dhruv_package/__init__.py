from .main import slugify

__all__ = ["slugify"]
