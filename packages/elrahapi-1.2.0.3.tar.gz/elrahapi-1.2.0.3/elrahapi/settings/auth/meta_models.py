from pydantic import BaseModel
from .schemas import UserBaseModel
class MetaEntityUser(UserBaseModel):
    pass

