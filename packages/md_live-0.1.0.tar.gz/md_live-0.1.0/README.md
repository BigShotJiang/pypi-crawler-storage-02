# md-live

![PyPI version](https://img.shields.io/pypi/v/md-live.svg)
[![Documentation Status](https://readthedocs.org/projects/md-live/badge/?version=latest)](https://md-live.readthedocs.io/en/latest/?version=latest)

md-live is Markdown with live executed code blocks

* PyPI package: https://pypi.org/project/md-live/
* Free software: MIT License
* Documentation: https://md-live.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
