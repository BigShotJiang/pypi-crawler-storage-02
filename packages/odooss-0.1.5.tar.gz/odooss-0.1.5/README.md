
# Odoo Standard Scaffold

```zsh
 odooss create <your-dir-path> --odoo_version 18.0 --python 3.10
```