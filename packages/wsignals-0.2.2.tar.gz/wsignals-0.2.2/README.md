
# wsignals
v0.2.2

Library for event emitting and handling


## Installation

### PyPI
```sh
pip install wsignals
```

### GitHub
```sh
pip install git+https://github.com/wumtdev/wsignals.git
```

### Manual
Clone from github
```sh
# using https
git clone https://github.com/wumtdev/wsignals.git
# using ssh
git clone git@github.com:wumtdev/wsignals.git
```

In the environment where you need to install library, install it as a local package. Specify path to cloned repository.
```sh
pip install /path/to/cloned_repo
```


## Usage
TODO: There will be guides for library usage :(
