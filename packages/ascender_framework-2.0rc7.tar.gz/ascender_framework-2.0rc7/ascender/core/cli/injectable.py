class Injectable:
    """
    NOTE: This object is just a type stub for other part of ascender/core to classify
    """
    pass