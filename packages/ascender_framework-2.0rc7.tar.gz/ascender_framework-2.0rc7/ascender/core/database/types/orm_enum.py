from enum import Enum


class ORMEnum(Enum):
    TORTOISE = "tortoise"
    SQLALCHEMY = "sqlalchemy"