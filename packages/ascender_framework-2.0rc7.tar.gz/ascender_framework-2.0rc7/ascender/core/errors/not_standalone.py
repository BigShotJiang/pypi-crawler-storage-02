class NotStandaloneError(Exception):
    pass