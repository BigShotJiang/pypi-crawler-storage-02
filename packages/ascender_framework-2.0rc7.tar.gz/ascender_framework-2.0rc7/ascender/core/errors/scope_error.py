class ScopeError(Exception):
    pass