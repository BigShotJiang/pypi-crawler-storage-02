from typing import TypedDict


class ConsumerMetadata(TypedDict):
    transporter: str