Developer documentation
=======================

.. include:: ../../CONTRIBUTING.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 2
   :hidden:

   getting-started
   coding-conventions
   dependency-management
   testing
