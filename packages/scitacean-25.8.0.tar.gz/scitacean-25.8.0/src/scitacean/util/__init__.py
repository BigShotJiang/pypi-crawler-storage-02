"""Generic utilities."""
