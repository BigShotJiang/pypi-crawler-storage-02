"""Module to handle the fatigue data from the owimetadatabase."""
