mod basic;
mod nested;

pub use basic::array_to_page;
pub use nested::array_to_page as nested_array_to_page;
