"""
Egile MCP Client

A comprehensive MCP client with direct connection and AI agent modes,
including web interface for interacting with MCP servers.
"""

__version__ = "0.1.3"
__author__ = "Jean-Baptiste Poullet"
__email__ = "egile@gmail.com"
