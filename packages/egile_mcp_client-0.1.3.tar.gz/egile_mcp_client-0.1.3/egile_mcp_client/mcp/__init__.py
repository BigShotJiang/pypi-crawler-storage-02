"""MCP (Model Context Protocol) client package."""
