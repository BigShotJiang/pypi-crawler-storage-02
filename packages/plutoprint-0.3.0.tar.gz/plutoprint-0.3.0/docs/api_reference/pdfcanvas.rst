PDFCanvas
=========

.. currentmodule:: plutoprint

.. autoclass:: PDFCanvas
    :show-inheritance:
    :members:

    .. automethod:: __init__
