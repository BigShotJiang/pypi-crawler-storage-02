ResourceFetcher
===============

.. currentmodule:: plutoprint

.. autoclass:: ResourceFetcher
    :members:

.. autodata:: default_resource_fetcher
