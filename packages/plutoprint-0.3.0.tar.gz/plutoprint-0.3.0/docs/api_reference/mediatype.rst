MediaType
=========

.. currentmodule:: plutoprint

.. autoclass:: MediaType

.. autodata:: MEDIA_TYPE_PRINT

.. autodata:: MEDIA_TYPE_SCREEN
