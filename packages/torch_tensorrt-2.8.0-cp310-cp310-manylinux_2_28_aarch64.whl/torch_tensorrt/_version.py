__version__ = "2.8.0+cu129"
__cuda_version__ = "12.9"
__tensorrt_version__ = "10.12.0"
