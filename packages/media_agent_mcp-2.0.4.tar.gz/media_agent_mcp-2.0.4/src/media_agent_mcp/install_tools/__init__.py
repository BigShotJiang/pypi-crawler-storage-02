"""Install tools module for managing system dependencies."""

from .installer import install_tools_plugin

__all__ = ['install_tools_plugin']