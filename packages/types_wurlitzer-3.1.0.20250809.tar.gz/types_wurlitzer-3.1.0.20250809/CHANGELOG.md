## 3.1.0.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 3.1.0.20250708 (2025-07-08)

[wurlitzer] Remove from pyrightconfig (#14292)

## 3.1.0.20240511 (2024-05-11)

[stubsabot] Bump wurlitzer to 3.1.* (#11848)

## 3.0.0.20240311 (2024-03-11)

Use PEP 570 syntax in third party stubs (#11554)

## 3.0.0.20240310 (2024-03-10)

Add `wurlitzer` stubs (#11459)

Co-authored-by: Alex Waygood <Alex.Waygood@Gmail.com>
Co-authored-by: Akuli <akuviljanen17@gmail.com>

