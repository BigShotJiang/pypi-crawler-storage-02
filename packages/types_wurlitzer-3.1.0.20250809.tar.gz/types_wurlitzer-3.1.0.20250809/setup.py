
from setuptools import setup

setup(package_data={'wurlitzer-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
