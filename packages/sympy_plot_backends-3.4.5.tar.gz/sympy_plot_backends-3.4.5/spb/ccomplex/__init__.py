import warnings


warnings.warn(
    "`spb.ccomplex` is deprecated and will be removed in a future release. "
    "Please, use `spb.plot_functions` or `spb` directly (better option).",
    DeprecationWarning,
    stacklevel=2
)
