from spb.wegert import *

import warnings

warnings.warn(
    "`spb.ccomplex.wegert` is deprecated and will be removed in a future "
    "release. Please, use `spb.wegert`.",
    DeprecationWarning,
    stacklevel=2
)
