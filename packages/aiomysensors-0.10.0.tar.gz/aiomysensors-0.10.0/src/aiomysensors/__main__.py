"""Make the CLI runnable using python -m aiomysensors."""

from .cli import cli

cli(prog_name="aiomysensors")
