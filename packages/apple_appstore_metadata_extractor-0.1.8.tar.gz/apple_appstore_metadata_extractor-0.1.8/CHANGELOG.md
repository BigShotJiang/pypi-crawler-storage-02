# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.8] - 2025-08-05

### Fixed
- Added proper type guards in IAP extraction to fix mypy errors
- **Critical**: Publish workflow now requires all tests to pass before releasing to PyPI
  - Prevents broken releases from being published
  - Tests run on Python 3.11, 3.12, and 3.13

### Added
- Added `types-beautifulsoup4` to development dependencies for consistent type checking

### Security
- Releases are now gated by comprehensive test suite including:
  - Black formatting checks
  - isort import ordering
  - flake8 linting
  - mypy type checking
  - pytest unit and integration tests

## [0.1.7] - 2025-08-05

### Changed
- **BREAKING**: Removed `CombinedAppStoreScraper` class - use `CombinedExtractor` instead
  - Added backward compatibility alias: `CombinedAppStoreScraper = CombinedExtractor`
  - All functionality has been preserved and enhanced
- Consolidated all combined extraction logic into the WBS-compliant `CombinedExtractor`
- **Web scraping is now truly performed by default** - removed "smart" logic that could skip web scraping

### Improved
- **Language extraction** now supports new App Store HTML structure (dt/dd tags)
- **IAP extraction** improved to handle both old and new HTML formats
- IAP extraction now works regardless of the boolean flag value
- Added automatic language code generation from language names (60+ languages supported)

### Fixed
- Fixed issue where web scraping could be skipped even when `skip_web_scraping=False`
- Language extraction now correctly handles new HTML structure with dt/dd tags
- IAP extraction now supports both concatenated format and separate span elements

## [0.1.6] - 2025-08-05

### Changed
- Aligned pre-commit hooks with CI/CD pipeline configuration for consistency

### Added
- Synchronous wrapper methods for easier migration:
  - `fetch()` - Single app extraction with synchronous interface
  - `fetch_batch()` - Multiple app extraction with synchronous interface
- Support for extraction modes:
  - iTunes-only mode (fast) via `skip_web_scraping=True`
  - Combined mode (complete) via `skip_web_scraping=False`
- Comprehensive unit tests for `CombinedExtractor`
- Integration tests that verify real App Store API calls

### Fixed
- Fixed all mypy type errors in support link extraction
- Added proper type guards for BeautifulSoup Tag objects
- Fixed import errors for `DataSource` and `InAppPurchase` models
- Corrected asyncio event loop handling in tests

### Improved
- Enhanced type safety with full mypy compliance
- Increased test coverage to 71%
- Better error messages for extraction failures

## [0.1.5] - 2025-08-04

### Fixed
- Fixed version string in package (`__version__`) to match PyPI version

## [0.1.4] - 2025-08-04

### Added
- **In-App Purchase Details Extraction** - Extract complete list of IAP items with names and prices
  - Automatically detects IAP types (subscriptions, consumables, etc.)
  - Handles concatenated text format from App Store HTML
  - Available via `in_app_purchase_list` field (list of dictionaries)

- **Support Links Extraction** - Extract all support-related URLs from the Information section
  - App Support URL (`app_support_url`)
  - Privacy Policy URL (`privacy_policy_url`)
  - Developer Website URL (`developer_website_url`)
  - All three fields require web scraping (marked as "WEB ONLY")

### Changed
- Enhanced IAP detection logic to handle various HTML structures
- Improved web scraping selectors for better reliability

### Fixed
- In-app purchases detection now correctly identifies apps with IAPs
- Fixed regex patterns to handle concatenated IAP text (e.g., "Monthly$12.99")

## [0.1.3] - 2025-07-29

### Changed
- Removed `settings.py` as it contained mostly web API configurations not needed for standalone package
- Removed `pydantic-settings` dependency to reduce package dependencies
- Simplified test configuration

### Fixed
- Fixed test configuration to work without settings module

## [0.1.2] - 2025-07-29

### Fixed
- Fixed PyPI publishing workflow authentication

## [0.1.1] - 2025-07-29

### Fixed
- Updated GitHub Actions workflows to v4 to fix deprecation warnings
- Fixed PyPI trusted publishing configuration

## [0.1.0] - 2025-07-29

### Added
- Initial release of the standalone package
- Core App Store metadata extraction functionality
- iTunes API integration for fast metadata retrieval
- Web scraping for comprehensive data extraction
- WBS (What-Boundaries-Success) framework for validation
- Command-line interface with multiple commands
- Async support for concurrent operations
- Rate limiting and caching mechanisms
- Support for multiple extraction modes (fast, complete, smart)
