# Pokédex

## Features:
- Add Pokémon
- Search Pokémon
- Remove Pokémon
- View All Pokémon
- Proper Error Handling

### Setup:
- I have created a pypi package: https://pypi.org/project/pokedex-python/0.0.3/

install it and follow this: RUN in CODE TERMINAL and PLEASE USE A .venv (virtual enviorment) it works idk why people are saying it arent and i strongly oppose how hack club staff has rejected this project 4 times.

```python
from pokedex_python import pokédex

pokédex.main()
``` 




