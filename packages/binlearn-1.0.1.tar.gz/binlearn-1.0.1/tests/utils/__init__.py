"""Tests for binlearn.utils submodules."""
