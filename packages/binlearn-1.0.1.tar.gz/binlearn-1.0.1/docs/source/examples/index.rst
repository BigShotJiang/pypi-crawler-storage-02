Examples
========

Real-world examples and use cases.

.. toctree::
   :maxdepth: 2

   basic_examples
   machine_learning_examples
   advanced_examples
   performance_examples
