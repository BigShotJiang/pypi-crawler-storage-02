from .async_ import _NearTextQueryAsync
from .sync import _NearTextQuery

__all__ = [
    "_NearTextQuery",
    "_NearTextQueryAsync",
]
