weaviate.collections.queries.near\_media
========================================

.. automodule:: weaviate.collections.queries.near_media
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.collections.queries.near\_media.generate module
.. --------------------------------------------------------

.. .. automodule:: weaviate.collections.queries.near_media.generate
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.queries.near\_media.query module
.. -----------------------------------------------------

.. .. automodule:: weaviate.collections.queries.near_media.query
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
