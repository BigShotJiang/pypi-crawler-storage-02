"""
Source package for axonode-chunker
"""

from .chunker import AxonodeChunker, StructuralMarker

__version__ = "0.1.0"
__all__ = ["AxonodeChunker", "StructuralMarker"] 