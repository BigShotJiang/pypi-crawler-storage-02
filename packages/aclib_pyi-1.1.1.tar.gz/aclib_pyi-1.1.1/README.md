
# Installation
    pip install aclib.pyi


# Usage

``` python
# from aclib.pyi import compile, pyipack
from aclib import pyi

compileddir = pyi.compile(...)
if compileddir:
    pyi.pyipack(...)
```
