List all charts/saved queries in Lightdash, optionally filtered by space.

This tool retrieves all saved charts and queries from your Lightdash project. You can filter
by space to see charts in a specific area, or get all charts across all spaces.

Examples:
- "Show me all Lightdash charts"
- "What charts are saved in the Marketing space?"
- "List all saved queries in Lightdash"