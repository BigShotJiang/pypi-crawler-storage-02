stcal API
==========

.. automodapi:: stcal
