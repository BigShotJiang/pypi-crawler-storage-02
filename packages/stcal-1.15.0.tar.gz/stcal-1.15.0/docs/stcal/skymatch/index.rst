.. _skymatch:

=======================
Skymatch
=======================

.. toctree::
   :maxdepth: 2

   description.rst

.. automodapi:: stcal.skymatch.skystatistics
.. automodapi:: stcal.skymatch.skyimage
.. automodapi:: stcal.skymatch.skymatch
