"""
MCPStore CLI Package
"""
from .main import main

__all__ = ["main"]
