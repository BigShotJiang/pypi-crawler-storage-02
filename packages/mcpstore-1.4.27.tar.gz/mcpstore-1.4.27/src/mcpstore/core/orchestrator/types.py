"""
MCPOrchestrator Types
编排器相关的类型定义
"""

from typing import Dict, Any, Optional, List
from enum import Enum

# 这里可以添加编排器相关的类型定义
# 目前保持简单，为未来扩展预留
