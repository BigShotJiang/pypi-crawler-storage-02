
# THIS FILE IS GENERATED FROM HRProfiler SETUP.PY
short_version = '0.0.2'
version = '0.0.2'
  
  