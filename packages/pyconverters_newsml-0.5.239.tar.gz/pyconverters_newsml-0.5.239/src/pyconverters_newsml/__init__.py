"""NewsML converter (AFP news)"""
__version__ = "0.5.239"
