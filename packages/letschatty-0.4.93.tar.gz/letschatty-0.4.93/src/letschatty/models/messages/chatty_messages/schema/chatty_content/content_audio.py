from .content_media import ChattyContentMedia

class ChattyContentAudio(ChattyContentMedia):
    pass