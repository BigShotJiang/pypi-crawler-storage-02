"""Unit test package for cuteagent."""

# This file makes this a Python package
