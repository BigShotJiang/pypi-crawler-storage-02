Examples
========

.. nbgallery::
   /examples/magicfunctions
   /examples/excesstopography
