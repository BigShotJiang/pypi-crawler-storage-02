# myrlkit

**A tiny, teaching-focused reinforcement learning kit**: Q-learning, SARSA, and multi-armed bandits with two toy environments (GridWorld, K-armed Bandit), plus simple matplotlib learning curves.

- Zero heavy frameworks
- Small, readable code with docstrings
- Good for courses, homework, and quick demos

## Install

```bash
pip install myrlkit
```

> If installing from source:
```bash
pip install -e .
```

## Quickstart

### Q-learning on GridWorld

```python
import numpy as np
from myrlkit.agents import QLearningAgent
from myrlkit.envs import GridWorld

env = GridWorld(width=5, height=5, start=(0,0), goal=(4,4), obstacles=[(1,1), (1,2), (2,1)])
agent = QLearningAgent(state_size=env.n_states, action_size=env.n_actions, alpha=0.5, gamma=0.99, epsilon=0.1)

episodes = 300
rewards = []
for _ in range(episodes):
    s = env.reset()
    done = False
    total = 0.0
    while not done:
        a = agent.choose_action(s)
        ns, r, done, _ = env.step(a)
        agent.update(s, a, r, ns, done)
        s = ns
        total += r
    rewards.append(total)

# Show the greedy policy
policy = env.render_policy(agent.q_table)
print(policy)
```

### SARSA on GridWorld

```python
from myrlkit.agents import SARSAAgent
from myrlkit.envs import GridWorld

env = GridWorld(width=4, height=4, start=(0,0), goal=(3,3))
agent = SARSAAgent(state_size=env.n_states, action_size=env.n_actions, alpha=0.5, gamma=0.99, epsilon=0.1)
```

### Epsilon-Greedy Bandit

```python
from myrlkit.agents import EpsilonGreedyBandit
from myrlkit.envs import KArmedBandit

env = KArmedBandit(k=10, means=[0.0]*10, std=1.0, seed=42)
agent = EpsilonGreedyBandit(k=env.k, epsilon=0.1)

rewards = []
for t in range(1000):
    a = agent.select_action()
    r = env.pull(a)
    agent.update(a, r)
    rewards.append(r)
```

## API

- `myrlkit.agents.QLearningAgent`
- `myrlkit.agents.SARSAAgent`
- `myrlkit.agents.EpsilonGreedyBandit`
- `myrlkit.envs.GridWorld`
- `myrlkit.envs.KArmedBandit`

## Examples

See `examples/` for runnable scripts (learning curves, policy printouts).

## License

MIT
