"""Spark platform generators."""
