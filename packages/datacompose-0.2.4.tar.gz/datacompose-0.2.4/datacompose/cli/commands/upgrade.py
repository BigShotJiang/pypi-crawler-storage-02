"""Upgrade command for upgrading a transformer to a new version."""


class UpgradeCommand:
    """Command to upgrade a transformer to a new version."""

    None
