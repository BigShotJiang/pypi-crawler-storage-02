#!/usr/bin/env python
# pylint: disable=missing-module-docstring
import setuptools

if __name__ == "__main__":
    setuptools.setup()
