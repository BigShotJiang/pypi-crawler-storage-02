import pyperclip


def main() -> None:
    print(pyperclip.paste(), end='')


if __name__ == '__main__':
    main()
