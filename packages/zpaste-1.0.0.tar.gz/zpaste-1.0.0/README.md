# zpaste

A small CLI tool to print the clipboard's content (using [pyperclip](https://pypi.org/project/pyperclip)).

```console
uv tool install zpaste
```
