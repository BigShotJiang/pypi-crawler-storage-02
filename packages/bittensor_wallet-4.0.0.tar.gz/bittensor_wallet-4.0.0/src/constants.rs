pub const BT_WALLET_NAME: &str = "default";
pub const BT_WALLET_HOTKEY: &str = "default";
pub const BT_WALLET_PATH: &str = "~/.bittensor/wallets/";
