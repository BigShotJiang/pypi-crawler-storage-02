from bittensor_wallet.bittensor_wallet import errors as _

ConfigurationError = _.ConfigurationError
KeyFileError = _.KeyFileError
PasswordError = _.PasswordError
WalletError = _.WalletError
