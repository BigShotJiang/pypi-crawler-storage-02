from bittensor_wallet.bittensor_wallet import wallet as _

display_mnemonic_msg = _.display_mnemonic_msg
Wallet = _.Wallet
