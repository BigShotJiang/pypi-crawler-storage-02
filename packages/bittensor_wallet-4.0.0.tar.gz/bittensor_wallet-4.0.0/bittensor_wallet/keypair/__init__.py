from bittensor_wallet.bittensor_wallet import keypair as _

Keypair = _.Keypair
