from bittensor_wallet.bittensor_wallet import utils as _

get_ss58_format = _.get_ss58_format
is_valid_ss58_address = _.is_valid_ss58_address
is_valid_ed25519_pubkey = _.is_valid_ed25519_pubkey
is_valid_bittensor_address_or_public_key = _.is_valid_bittensor_address_or_public_key
SS58_FORMAT = _.SS58_FORMAT
