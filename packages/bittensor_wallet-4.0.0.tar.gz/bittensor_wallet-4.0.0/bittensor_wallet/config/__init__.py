from bittensor_wallet.bittensor_wallet import config as _

Config = _.Config
