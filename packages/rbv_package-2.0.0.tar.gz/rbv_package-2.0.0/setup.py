from setuptools import setup, find_packages

setup(
    name="rbv-package",
    version="2.0.0",
    packages=find_packages(),
    description="Un package de fonction utiles pour la Vérification basée sur les risques",
    author="Hubinont Jean-Philippe",
    author_email="jphubinont@bluesquarehub.com",
    install_requires=[],
)
