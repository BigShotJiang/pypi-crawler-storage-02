"""Base exception classes."""


class SecEdgarApiError(Exception):
    """Base exception for SEC EDGAR API errors."""

    pass
