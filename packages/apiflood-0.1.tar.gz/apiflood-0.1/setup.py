from setuptools import setup, find_packages

setup(
    name="apiflood",
    version="0.1",
    description="DESTROY SOME APIS!!!",
    author="Pankoza3-pl",
    packages=find_packages(),
    install_requires=[
        "requests",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
