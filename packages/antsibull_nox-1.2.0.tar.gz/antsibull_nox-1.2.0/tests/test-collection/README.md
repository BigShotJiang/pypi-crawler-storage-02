<!--
Copyright (c) Ansible Project
GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
SPDX-License-Identifier: GPL-3.0-or-later
-->

# Test collection README

This `antsibull.test` collection is used to test sessions in the `antsibull-nox` project.
Test run in the repository CI with the `.github/workflows/test-gh-action.yml` workflow.
