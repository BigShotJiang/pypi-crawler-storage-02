from . import generate_init_py

__all__ = [
    "generate_init_py",
]
