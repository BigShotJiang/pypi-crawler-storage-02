from enum import Enum


class DataStatusEnum(Enum):
    OK = 1
    ERROR = -1
