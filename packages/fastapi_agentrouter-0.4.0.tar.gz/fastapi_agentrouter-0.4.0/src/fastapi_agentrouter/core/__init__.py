"""Core components for FastAPI AgentRouter."""
