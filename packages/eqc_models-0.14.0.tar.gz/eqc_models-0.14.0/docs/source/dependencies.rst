Dependencies
=============

Requires Python: >=3.9, <3.11

Packages
--------

- ``numpy>=1.22.1, <2``
- ``networkx>=2.6.3, <3``
- ``pandas>=2.1.0``
- ``scikit-learn>=1.2.1``
- ``qci-client>=4.3.0, <5``
- ``emucore-direct==1.0.6``
