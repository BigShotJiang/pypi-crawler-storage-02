import eqc_models
import doctest

if __name__ == "__main__":
    doctest.testmod(eqc_models)
