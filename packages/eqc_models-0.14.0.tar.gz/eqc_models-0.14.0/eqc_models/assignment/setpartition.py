from ..combinatorics import SetPartitionModel
import warnings

warnings.warn("import of SetPartitionModel through assignment is deprecated", DeprecationWarning)
