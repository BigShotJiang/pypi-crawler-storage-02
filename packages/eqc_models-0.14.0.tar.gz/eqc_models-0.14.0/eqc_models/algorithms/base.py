# (C) Quantum Computing Inc., 2024.

class Algorithm:

    def __init__(self, model, solver):
        self.model = model
        self.solver = solver

    def run(self, *args, **kwargs):
        return {}