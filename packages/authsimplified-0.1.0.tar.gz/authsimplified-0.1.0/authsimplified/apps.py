from django.apps import AppConfig

class AuthsimplifiedConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "authsimplified"
    verbose_name = "AuthSimplified"
