default_app_config = "authsimplified.apps.AuthsimplifiedConfig"
