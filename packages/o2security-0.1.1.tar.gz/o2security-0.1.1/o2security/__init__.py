# o2security/__init__.py

# این خط به پایتون می‌گوید که وقتی کسی 'from o2security' را ایمپورت می‌کند،
# متغیر 'tokman' از ماژول 'tokman' در دسترس باشد.
from .tokman import tokman

# می‌توانید اطلاعات نسخه را نیز اینجا تعریف کنید
__version__ = "0.1.0"
