from frogml.core.exceptions import FrogmlSuggestionException


class FrogmlDeployNewBuildFailedException(FrogmlSuggestionException):
    pass
