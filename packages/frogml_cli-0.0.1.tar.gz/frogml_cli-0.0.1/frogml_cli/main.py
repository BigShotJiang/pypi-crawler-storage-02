from frogml_cli.cli import create_frogml_cli


def frogml_cli():
    return create_frogml_cli()()


if __name__ == "__main__":
    frogml_cli()()
