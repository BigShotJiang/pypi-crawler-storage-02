from enum import Enum


class Niveau(Enum):
    DÉPARTEMENTAL = "Départemental"
    HANDIBASKET = "Handibasket"
    INTERNATIONAL = "International"
    NATIONAL = "National"
    PRO = "Pro"
    RÉGIONAL = "Régional"
