from enum import Enum


class TypeCompetition(Enum):
    CHAMPIONNAT = "Championnat"
    CHAMPIONNAT_3_X3 = "Championnat 3x3"
    COUPE = "Coupe"
    PLATEAU = "Plateau"
