from enum import Enum


class TypeEnum(Enum):
    COMITÉ = "Comité"
    FÉDÉRATION = "Fédération"
    LIGUE = "Ligue"
