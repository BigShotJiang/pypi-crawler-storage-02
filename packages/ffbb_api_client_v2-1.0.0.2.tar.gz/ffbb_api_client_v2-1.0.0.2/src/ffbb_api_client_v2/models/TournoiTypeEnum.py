from enum import Enum


class TournoiTypeEnum(Enum):
    OPEN_PLUS = "Open Plus"
    OPEN_PLUS_ACCESS = "Open Plus Access"
    OPEN_START = "Open Start"
