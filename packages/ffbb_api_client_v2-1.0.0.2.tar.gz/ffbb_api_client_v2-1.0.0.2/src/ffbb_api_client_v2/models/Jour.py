from enum import Enum


class Jour(Enum):
    SUNDAY = "dimanche"
    THURSDAY = "jeudi"
    MONDAY = "lundi"
    TUESDAY = "mardi"
    WEDNESDAY = "mercredi"
    SATURDAY = "samedi"
    FRIDAY = "vendredi"
