from enum import Enum


class Etat(Enum):
    A = "A"
    D = "D"
