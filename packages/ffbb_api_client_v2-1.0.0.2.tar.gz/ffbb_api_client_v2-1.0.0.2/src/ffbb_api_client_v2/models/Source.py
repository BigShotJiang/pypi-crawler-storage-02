from enum import Enum


class Source(Enum):
    FFBB_SERVEUR = "FFBB Serveur"
