from enum import Enum


class TypeLeague(Enum):
    JUNIOR = "junior"
    SENIOR = "senior"
