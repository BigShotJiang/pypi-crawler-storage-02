from enum import Enum


class Objectif(Enum):
    ACCOMPAGNEMENT = "Accompagnement"
    CURATIF = "Curatif"
    PREVENTIVE = "Préventif"
