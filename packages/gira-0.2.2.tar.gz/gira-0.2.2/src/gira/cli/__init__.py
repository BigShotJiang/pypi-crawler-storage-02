"""CLI module for Gira - Command Line Interface implementation."""

from .main import app

__all__ = ["app"]