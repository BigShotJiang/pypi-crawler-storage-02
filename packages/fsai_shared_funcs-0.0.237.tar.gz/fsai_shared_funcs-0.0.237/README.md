# fsai-shared-funcs

Simple functions shared across fsai apps.

## Installation
```shell
poetry add fsai-shared-funcs
```