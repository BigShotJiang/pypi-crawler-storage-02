"""Version information for django-i18n-noprefix."""

__version__ = "0.1.1"
