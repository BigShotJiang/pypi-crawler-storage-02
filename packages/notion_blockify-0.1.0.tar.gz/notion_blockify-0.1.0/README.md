# notion-blockify

## Installation
```
pip install notion-blockify
```

## Usage
```
from notion_blockify import Blockizer

blockizer = Blockizer()
```
