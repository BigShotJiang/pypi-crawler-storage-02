render = 'JSON'
source = 'national'

# EG/211858
appnum_mask = 'EG/(\\d*)'
