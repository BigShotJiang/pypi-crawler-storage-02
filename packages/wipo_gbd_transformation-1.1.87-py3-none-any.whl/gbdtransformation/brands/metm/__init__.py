render = 'JSON'
source = 'national'

# ME/Z/2014/321890
appnum_mask = '(\\d{4})-(.*)'
