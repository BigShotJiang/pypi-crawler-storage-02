render = 'JSON'
source = 'national'

# GM/M/2014/288
# AP/M/1986/46
appnum_mask = [ 'GM/M/\\d{4}/(\\d*)',
                '(AP)/M/\\d{4}/(\\d*)'  ]
