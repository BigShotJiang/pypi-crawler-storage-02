# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# VA 1963 01864
appnum_mask = [ '(VA) \\d{4} (\\d*)',
                '(FA) \\d{4} (\\d*)' ]
