dict_of_parts = {}
