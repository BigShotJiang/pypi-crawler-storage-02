from .getmaps import main


def getmaps_command(args, logger):
    return main(args, logger)