#!/bin/python
# -*- coding: utf-8 -*-
"""
__main__.py

Author: GrimAndGreedy
Created: 2025-06-25
License: MIT
"""

from listpick.listpick_app import main

if __name__ == "__main__":
    main()
