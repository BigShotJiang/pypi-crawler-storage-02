# emezed.gui

`emzed.gui` is the graphical user interface component of `emzed`.
