# Jupyterlab Russian (Russia) Language Pack

Russian (Russia) language pack for the JupyterLab ecosystem.

## Install

### pip

```bash
pip install jupyterlab-language-pack-ru-RU
```

### conda

```bash
conda install -c conda-forge jupyterlab-language-pack-ru-RU
```

## Contributing

To contribute to this package please visit the [Crowdin site](https://crowdin.com/project/jupyterlab).
