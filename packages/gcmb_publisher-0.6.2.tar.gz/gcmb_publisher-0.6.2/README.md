## Releasing

* Update version in pyproject.toml
* Set tag to vx.y.z
* Push tag
