Script
=========

.. autoclass:: django_musicbrainz_connector.models::Script
