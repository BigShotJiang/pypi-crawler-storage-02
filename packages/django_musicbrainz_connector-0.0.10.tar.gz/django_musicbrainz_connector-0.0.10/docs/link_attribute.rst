Link Attribute
==============

.. autoclass:: django_musicbrainz_connector.models::LinkAttribute
