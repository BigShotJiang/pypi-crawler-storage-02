Link Attribute Text Value
=========================

.. autoclass:: django_musicbrainz_connector.models::LinkAttributeTextValue
