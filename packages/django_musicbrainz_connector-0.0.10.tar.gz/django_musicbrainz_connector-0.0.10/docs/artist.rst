Artist
======

.. autoclass:: django_musicbrainz_connector.models::Artist
