RecordingWorkLink
=================

.. autoclass:: django_musicbrainz_connector.models::RecordingWorkLink
