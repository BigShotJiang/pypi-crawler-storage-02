Base tag model
==============

.. autoclass:: django_musicbrainz_connector.models::TagModel
