Link Attribute Type
===================

.. autoclass:: django_musicbrainz_connector.models::LinkAttributeType

.. include:: includes/link-attribute-types.md
   :parser: myst_parser.sphinx_
