Area
====

.. autoclass:: django_musicbrainz_connector.models::Area
