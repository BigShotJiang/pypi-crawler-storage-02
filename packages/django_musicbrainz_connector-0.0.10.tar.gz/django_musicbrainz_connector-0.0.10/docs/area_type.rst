Area Type
=========

.. autoclass:: django_musicbrainz_connector.models::AreaType

.. include:: includes/area-types.md
   :parser: myst_parser.sphinx_
