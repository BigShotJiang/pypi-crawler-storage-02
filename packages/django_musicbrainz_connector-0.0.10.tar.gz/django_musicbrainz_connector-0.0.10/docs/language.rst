Language
========

.. automodule:: django_musicbrainz_connector.models.language
   :noindex:

Model Documentation
-------------------

.. autoclass:: django_musicbrainz_connector.models.language::Language

Model Source
------------

.. literalinclude:: ../django_musicbrainz_connector/models/language.py
   :pyobject: Language
..    :caption: The `language` Model
