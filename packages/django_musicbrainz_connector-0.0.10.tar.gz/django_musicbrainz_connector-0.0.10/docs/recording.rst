Recording
=========

.. autoclass:: django_musicbrainz_connector.models::Recording
