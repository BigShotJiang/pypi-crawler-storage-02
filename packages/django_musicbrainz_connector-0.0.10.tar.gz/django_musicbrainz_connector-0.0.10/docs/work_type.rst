Work Type
=========

.. autoclass:: django_musicbrainz_connector.models::WorkType

.. include:: includes/work-types.md
   :parser: myst_parser.sphinx_
