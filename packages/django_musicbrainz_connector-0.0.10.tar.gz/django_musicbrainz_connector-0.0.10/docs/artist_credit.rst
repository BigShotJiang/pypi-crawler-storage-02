Artist Credit
=============

.. automodule:: django_musicbrainz_connector.models.artist_credit
   :noindex:

Model Documentation
-------------------

.. autoclass:: django_musicbrainz_connector.models.artist_credit::ArtistCredit

Model Source
------------

.. literalinclude:: ../django_musicbrainz_connector/models/artist_credit.py
   :pyobject: ArtistCredit
..    :caption: The `artist_credit` Model
