ReleaseGroupPrimaryType
=======================

.. autoclass:: django_musicbrainz_connector.models::ReleaseGroupPrimaryType
