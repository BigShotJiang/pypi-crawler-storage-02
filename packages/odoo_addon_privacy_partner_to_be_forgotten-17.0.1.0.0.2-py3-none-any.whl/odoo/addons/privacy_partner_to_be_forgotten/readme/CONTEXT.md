This module aims to help companies comply with the European Union General Data Protection Regulation (GDPR) by providing a mechanism to anonymize personal data in `res.partner` records.
