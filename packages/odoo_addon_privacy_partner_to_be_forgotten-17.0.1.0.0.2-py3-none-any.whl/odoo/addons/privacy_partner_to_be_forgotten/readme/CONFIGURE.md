##  To permit a user to anonymize partner records:
1. Go to **Settings** → **Users & Companies** → **Users**
2. Select the user you want to authorize
3. In the **Administration** group, enable the checkbox **"Anonymize Contacts"**

This will allow the user to access and execute the anonymization functionality provided by the module.
