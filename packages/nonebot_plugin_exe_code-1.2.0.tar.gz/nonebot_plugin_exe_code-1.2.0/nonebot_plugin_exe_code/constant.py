from nonebot_plugin_localstore import get_plugin_data_dir

DATA_DIR = get_plugin_data_dir()
