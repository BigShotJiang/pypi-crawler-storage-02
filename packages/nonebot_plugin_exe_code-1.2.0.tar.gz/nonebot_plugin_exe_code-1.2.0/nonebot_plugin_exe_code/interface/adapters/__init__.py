from . import onebot11 as onebot11
from . import qq as qq
from . import satori as satori
from . import telegram as telegram
