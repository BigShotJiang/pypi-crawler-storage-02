"""config - subpackage for configurations used in data processing before fitting."""
