"""fit_data - subpackage for filtering and otherwise preparing LVM data before fitting."""
