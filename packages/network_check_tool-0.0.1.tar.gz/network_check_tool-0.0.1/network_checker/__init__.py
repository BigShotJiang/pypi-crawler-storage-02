"""Network Checker - A network monitoring tool with ping tracking and dashboard visualization."""

__version__ = "0.0.1"