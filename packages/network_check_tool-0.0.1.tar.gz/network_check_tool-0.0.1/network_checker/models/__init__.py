from .ping_result import db, PingResult

__all__ = ['db', 'PingResult']