from .dashboard import dashboard_bp

__all__ = ['dashboard_bp']