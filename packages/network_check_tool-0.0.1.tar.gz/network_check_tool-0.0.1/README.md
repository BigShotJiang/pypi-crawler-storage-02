# Network Checker

A comprehensive network monitoring tool that performs periodic ping tests to monitor host availability and response times, with a web-based dashboard for visualization.

![Network Checker Dashboard](https://img.shields.io/badge/Dashboard-Live-green)
![Python Version](https://img.shields.io/badge/Python-3.10%2B-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

## Features

<� **Core Functionality**
- **Periodic Ping Monitoring**: Automated ping tests at configurable intervals
- **SQLite Database**: Persistent storage of ping results with timestamps
- **Web Dashboard**: Interactive visualization using Plotly charts
- **CLI Interface**: Comprehensive command-line tools for management
- **RESTful API**: JSON endpoints for data access and integration

=� **Dashboard Features**
- Real-time response time charts
- Packet loss visualization
- Success rate statistics
- Multiple host monitoring
- Time range filtering (1 hour to 1 week)
- Auto-refresh every 30 seconds

=' **Advanced Features**
- Background scheduling with APScheduler
- Configurable ping timeouts and intervals
- Database indexing for performance
- Error handling and logging
- Development and production configurations

## Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/mikawa-bushi/network-checker.git
cd network-checker

# Install dependencies with Poetry
poetry install

# Initialize the database
poetry run network-checker init
```

### Basic Usage

```bash
# Test a single host
poetry run network-checker ping google.com --count 5

# Start continuous monitoring
poetry run network-checker start-monitoring google.com cloudflare.com --interval 30

# Launch web dashboard
poetry run network-checker run-server

# Check recent results
poetry run network-checker status --host google.com
```

## CLI Commands

### `network-checker ping <host>`
Send ping tests to a specific host
```bash
poetry run network-checker ping example.com --count 4
```

### `network-checker start-monitoring <hosts>`
Start continuous monitoring of one or more hosts
```bash
poetry run network-checker start-monitoring google.com cloudflare.com --interval 60
```

### `network-checker run-server`
Start the web dashboard server
```bash
poetry run network-checker run-server --host 0.0.0.0 --port 9991
```

### `network-checker status`
Display recent ping results
```bash
poetry run network-checker status --host google.com --limit 10
```

### `network-checker init`
Initialize the database
```bash
poetry run network-checker init
```

### `network-checker clear`
Clear all ping data (with confirmation)
```bash
poetry run network-checker clear
```

## Web Dashboard

Access the web dashboard at `http://localhost:9991` after running:

```bash
poetry run network-checker run-server
```

### Dashboard Features
- **Host Selection**: Choose from monitored hosts
- **Time Range**: View data from 1 hour to 1 week
- **Statistics Cards**: Total pings, success rate, average response time, packet loss rate
- **Interactive Charts**: Response time trends with packet loss indicators
- **Auto-refresh**: Updates every 30 seconds

## API Endpoints

### GET `/api/hosts`
Get list of monitored hosts
```json
["google.com", "cloudflare.com"]
```

### GET `/api/stats?host=<host>&hours=<hours>`
Get statistics for a specific host
```json
{
  "total_pings": 100,
  "successful_pings": 98,
  "failed_pings": 2,
  "packet_loss_rate": 2.0,
  "avg_response_time": 15.5,
  "min_response_time": 10.2,
  "max_response_time": 25.8
}
```

### GET `/api/ping_data?host=<host>&hours=<hours>`
Get raw ping data for visualization
```json
{
  "host": "google.com",
  "timestamps": ["2023-01-01T12:00:00", "2023-01-01T12:01:00"],
  "response_times": [15.2, 16.8],
  "packet_losses": [0, 0],
  "total_pings": 2,
  "successful_pings": 2,
  "packet_loss_rate": 0.0
}
```

### GET `/api/ping_chart?host=<host>&hours=<hours>`
Get Plotly chart data for dashboard visualization

## Configuration

### Environment Variables

```bash
# Database configuration
DATABASE_URL=sqlite:///network_checker.db

# Ping settings
PING_TIMEOUT=4.0
DEFAULT_PING_INTERVAL=60

# Default hosts to monitor
DEFAULT_HOSTS=google.com,cloudflare.com

# Flask configuration
FLASK_ENV=development
SECRET_KEY=your-secret-key
```

### Configuration File
The application uses `network_checker/config/config.py` for settings:

- **Development**: Debug mode enabled, SQL logging
- **Production**: Optimized for production deployment

## Architecture

```
network_checker/
   __init__.py              # Package initialization
   app.py                   # Flask application factory
   cli.py                   # Command-line interface
   models/
      __init__.py
      ping_result.py       # SQLAlchemy model
   services/
      __init__.py
      ping_service.py      # Ping execution service
      scheduler_service.py # Background scheduling
   views/
      __init__.py
      dashboard.py         # Web API endpoints
   templates/
      dashboard.html       # Web dashboard UI
   config/
       __init__.py
       config.py            # Application configuration
```

## Database Schema

### ping_results table
- `id`: Primary key (INTEGER)
- `target_host`: Target hostname (VARCHAR(255), indexed)
- `timestamp`: Ping timestamp (DATETIME, indexed)
- `response_time`: Response time in milliseconds (FLOAT, nullable)
- `packet_loss`: Boolean indicating packet loss (BOOLEAN)
- `error_message`: Error details if ping failed (TEXT, nullable)

## Dependencies

**Core Dependencies:**
- `flask ^3.1.0` - Web framework
- `flask-sqlalchemy ^3.1.1` - Database ORM
- `ping3 ^4.0.4` - Ping functionality
- `apscheduler ^3.10.4` - Background scheduling
- `plotly ^5.17.0` - Data visualization
- `pandas ^2.2.3` - Data manipulation
- `flask-cors ^4.0.0` - CORS support
- `click ^8.1.3` - CLI framework

**Development Dependencies:**
- `pytest ^8.3.4` - Testing framework
- `black ^24.0.0` - Code formatting

## Development

### Running Tests
```bash
poetry run pytest
```

### Code Formatting
```bash
poetry run black network_checker/
```

### Development Server
```bash
poetry run network-checker run-server --debug
```

## Production Deployment

### Docker (Coming Soon)
```bash
# Build and run with Docker
docker build -t network-checker .
docker run -p 9991:9991 network-checker
```

### Manual Deployment
```bash
# Set production environment
export FLASK_ENV=production

# Run with a production WSGI server
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:9991 "network_checker.app:create_app('production')"
```

## Examples

### Monitor Multiple Hosts
```bash
# Start monitoring with custom intervals
poetry run network-checker start-monitoring \
  google.com cloudflare.com github.com \
  --interval 30
```

### View Statistics
```bash
# Check overall status
poetry run network-checker status

# Filter by host
poetry run network-checker status --host google.com --limit 20
```

### API Usage
```bash
# Get hosts via curl
curl http://localhost:9991/api/hosts

# Get statistics
curl "http://localhost:9991/api/stats?host=google.com&hours=24"
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- =� [Documentation](docs/)
- = [Issue Tracker](https://github.com/mikawa-bushi/network-checker/issues)
- =� [Discussions](https://github.com/mikawa-bushi/network-checker/discussions)

---

**Network Checker** - Keep your network monitoring simple and effective! =�