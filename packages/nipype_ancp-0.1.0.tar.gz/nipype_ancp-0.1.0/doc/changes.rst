:orphan:
:tocdepth: 2

.. _changes:

=================
Changes in Nipype
=================

.. include:: changelog/1.X.X-changelog.rst

.. include:: changelog/0.X.X-changelog.rst

.. include:: links_names.txt
