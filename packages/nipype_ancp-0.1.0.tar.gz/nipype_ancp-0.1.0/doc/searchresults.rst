:orphan:

.. This displays the search results from the Google Custom Search engine.
   Don't link to it directly.

Search results
==============

.. raw:: html

   <div id="cse" style="width: 100%;">Loading
   <script>
     (function() {
       var cx = '010960497803984932957:u8pmqf7fdoq';
       var gcse = document.createElement('script');
       gcse.type = 'text/javascript';
       gcse.async = true;
       gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
       var s = document.getElementsByTagName('script')[0];
       s.parentNode.insertBefore(gcse, s);
     })();
   </script>
   <gcse:search></gcse:search>
   </div>
