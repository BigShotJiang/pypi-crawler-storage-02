from agno.embedder.base import Embedder

__all__ = [
    "Embedder",
]
