from dspeed.processors import *  # noqa: F403, F401


def test_import():
    pass
