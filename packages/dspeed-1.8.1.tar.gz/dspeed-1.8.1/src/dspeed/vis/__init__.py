"""
This subpackage implements utilities to visualize data.
"""

from .waveform_browser import WaveformBrowser

__all__ = ["WaveformBrowser"]
