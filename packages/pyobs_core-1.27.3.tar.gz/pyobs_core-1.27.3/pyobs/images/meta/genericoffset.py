class GenericOffset:
    def __init__(self, dx: float, dy: float) -> None:
        self.dx: float = dx
        self.dy: float = dy
