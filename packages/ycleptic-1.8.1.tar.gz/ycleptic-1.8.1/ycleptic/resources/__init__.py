"""
Resources for the ycleptic package.

- ``example_base.yaml``: Example base configuration file.

"""