ycleptic.yclept module
======================

.. automodule:: ycleptic.yclept
   :members:
   :show-inheritance:
   :undoc-members:
