ycleptic.dictthings module
==========================

.. automodule:: ycleptic.dictthings
   :members:
   :show-inheritance:
   :undoc-members:
