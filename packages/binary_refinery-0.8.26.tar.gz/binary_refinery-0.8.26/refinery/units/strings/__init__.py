#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simple operations on strings, such as concatenation, replacement, slicing,
trimming, etcetera.
"""
