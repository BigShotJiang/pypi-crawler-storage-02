#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Library functions for processing of Inno Setup files.
"""
