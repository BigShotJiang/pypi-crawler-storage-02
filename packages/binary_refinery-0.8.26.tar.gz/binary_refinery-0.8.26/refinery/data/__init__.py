"""
This module contains data resources.
"""
