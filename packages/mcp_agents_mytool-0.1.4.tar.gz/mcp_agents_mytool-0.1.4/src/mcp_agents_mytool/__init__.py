from .mcp_tools_math import mcp

# Start the FastMCP server
if __name__ == "__main__":
    mcp.run()
