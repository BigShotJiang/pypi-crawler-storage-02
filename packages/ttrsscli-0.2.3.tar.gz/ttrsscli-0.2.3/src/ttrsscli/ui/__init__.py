"""UI module for ttrsscli."""

from .app import ttrsscli

__all__: list[str] = ["ttrsscli"]
