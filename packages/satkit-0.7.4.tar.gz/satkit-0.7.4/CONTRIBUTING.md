# Contributing

## Run the Tests

1. Run `python -m pip install requests && python ./python/test/download_testvecs.py`.
2. Run `cargo test`.
