from bluer_journal import README


def test_build_README():
    assert README.build()
