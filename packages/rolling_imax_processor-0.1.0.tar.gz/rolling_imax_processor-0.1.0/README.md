Rolling_Imax_Processor

This script processes raw intensity measurement data stored in a nested Year → Month → Day folder structure. It reads data in millimeters per second (mm/sec) from Excel files, calculates rolling maximum values for intensity classes, and outputs results in millimeters per minute (mm/min) for intensity classes I1–I60.

## Installation

```bash
pip install your_package_name
