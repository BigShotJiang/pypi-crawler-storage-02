"""Database type implementations."""

__all__ = []
