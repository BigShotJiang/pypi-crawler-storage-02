from .asgi import write_django_asgi_content
from .settings import write_django_settings_content
from .urls import DJANGO_URLS_CONTENT
from .wsgi import write_django_wsgi_content
from .manage import write_manage_py_content
