MAIN_CSS_CONTENT = """
@import "tailwindcss";
"""
