GITIGNORE_CONTENT = """
#Node.js dependencies
node_modules/
.vite
# Ignore the frontend environments
frontend/environments/.env.development
frontend/environments/.env.production
# Python Stuff (add to this as needed)
.env
.venv
db.sqlite3
__pycache__/
*.py[cod]
*$py.class
"""
