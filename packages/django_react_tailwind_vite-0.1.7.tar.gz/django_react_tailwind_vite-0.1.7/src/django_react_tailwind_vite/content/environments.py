DEV_ENV_CONTENT = """
VITE_NODE_ENV=development
VITE_BASE_API_URL=http://127.0.0.1:8000
"""

DEV_PROD_CONTENT = """ 
VITE_NODE_ENV=production
VITE_BASE_API_URL=http://your-production-url.com
"""
