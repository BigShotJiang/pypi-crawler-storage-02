REQUIREMENTS_CONTENT = """
asgiref
Django
django-vite
sqlparse
"""
