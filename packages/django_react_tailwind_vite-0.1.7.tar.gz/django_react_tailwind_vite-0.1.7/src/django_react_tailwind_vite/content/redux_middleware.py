MIDDLEWARE_INDEX_CONTENT = """
console.log("Import and export all middleware here");
"""
