# -*- encoding: utf-8 -*-

from .inject_init import inject_init
