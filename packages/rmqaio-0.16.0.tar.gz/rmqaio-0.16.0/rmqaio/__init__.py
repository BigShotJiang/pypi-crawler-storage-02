import importlib.metadata

from .rmqaio import *  # noqa F403


__version__ = importlib.metadata.version("rmqaio")
