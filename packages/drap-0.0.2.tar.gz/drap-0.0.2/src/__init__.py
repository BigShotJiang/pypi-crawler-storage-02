DrAP = "DrAP.main:main"

__version__ = "0.1.0"
