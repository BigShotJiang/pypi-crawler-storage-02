"""Utilities for agent.ai integration."""
