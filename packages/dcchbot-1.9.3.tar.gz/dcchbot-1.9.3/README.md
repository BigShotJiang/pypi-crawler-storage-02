# dcchbot

一個支援 GUI 控制面板的 Discord 管理機器人。