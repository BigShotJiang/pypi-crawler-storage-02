from encord.http.constants import RequestsSettings
