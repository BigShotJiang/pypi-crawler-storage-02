from .openwebui_chat_client import OpenWebUIClient

__version__ = "0.1.16"
__author__ = "fujie"
