# bimkit

**bimkit** – A toolkit for bioimage processing in Python.
