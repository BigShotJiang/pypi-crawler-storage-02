#. Filter the list of Purchase Orders by Fully Received and Fully Invoice Validated
