from . import test_purchase_fully_received
