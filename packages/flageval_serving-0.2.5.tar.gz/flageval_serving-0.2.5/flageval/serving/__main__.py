if __name__ == '__main__':
    def main():
        cli()
