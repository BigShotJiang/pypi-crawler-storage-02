from .autonomi import get as get

__all__ = [
    "get",
]


