#!/usr/bin/env python3
"""Sequence data mixin."""

from .sequence import SequenceDataMixin

__all__ = ["SequenceDataMixin"]
