#! /usr/venv/bin python3
"""TanaT main module."""

from tanat.cli import script_main

if __name__ == "__main__":
    script_main()
