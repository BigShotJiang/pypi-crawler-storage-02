Contributors
==============

Core development team
-------------------------
* Arnaud Duvermy, Inria, AIstroSight/Chaire AIRacles
* Thomas Guyet, Inria, AIstroSight/Chaire AIRacles


Contributors
-------------
* Mike Rye, Inria, AIstroSight