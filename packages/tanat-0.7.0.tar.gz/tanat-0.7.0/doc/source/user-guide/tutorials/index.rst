Tutorials
==================

.. toctree::
    :maxdepth: 1
    :caption: Simulation:

    01-simulation/simulation_sequence
    01-simulation/simulation_trajectory

.. toctree::
    :maxdepth: 1
    :caption: Data Wrangling:

    02-data_wrangling/data_wrangling_sequence
    02-data_wrangling/data_wrangling_trajectory

.. toctree::
    :maxdepth: 1
    :caption: Real data:

    03-real_data/mimic