::: polars_st.GeoSeries
    options:
        show_root_heading: true
        members: [st]

::: polars_st.GeoSeriesNameSpace
    options:
        show_root_heading: true
        show_object_full_path: true
        merge_init_into_class: false
        filters:
            - "!^_[^_]"
            - "!^__init__"
