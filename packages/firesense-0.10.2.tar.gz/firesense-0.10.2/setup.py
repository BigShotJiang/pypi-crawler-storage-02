#!/usr/bin/env python
"""Setup script for backward compatibility with older pip versions."""

from setuptools import setup

# The actual configuration is in pyproject.toml
# This file exists only for backward compatibility
setup()
