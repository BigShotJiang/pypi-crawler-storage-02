"""Processor based on Presidio anonymizer"""
__version__ = "0.5.90"
