/model openai/gpt-oss-20b:free 4096
@header.md
@resources/
@reasoning.md
/completion
@footer.md
/model google/gemini-2.0-flash-exp:free 8192
/completion
