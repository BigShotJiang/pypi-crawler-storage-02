# Let's think step by step.
