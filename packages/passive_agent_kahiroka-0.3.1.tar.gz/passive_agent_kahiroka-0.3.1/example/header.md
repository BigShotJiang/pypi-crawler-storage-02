# Who will be affected by climate change and in what ways?
