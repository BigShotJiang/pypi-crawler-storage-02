Developing countries, especially small island states and arid regions, face severe climate impacts despite contributing the least to global emmissions.
