Climate change disproportionately affects vulnerable groups such as the poor, elderly, and children, who have limited resources to adapt to environmental changes.
