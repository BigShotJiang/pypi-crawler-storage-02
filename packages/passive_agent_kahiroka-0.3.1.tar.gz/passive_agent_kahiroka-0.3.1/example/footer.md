# What measures are realistic and fair?
