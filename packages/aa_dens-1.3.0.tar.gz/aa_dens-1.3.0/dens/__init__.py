"""Mercenary dens plugin app for Alliance Auth."""

# pylint: disable = invalid-name
default_app_config = "dens.apps.DensConfig"

__version__ = "1.3.0"
