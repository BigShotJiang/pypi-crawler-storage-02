from . import ai


def leftpad(string: str, length: int, pad_char: str = " ") -> str:
    return ai.leftpad(string, length, pad_char)
