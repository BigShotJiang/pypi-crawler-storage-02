  - Funcționalități:
    
      - limitare încasare numerar
      - afișare conturi în format scurt
      - corecție traducere încasare
