class InvalidOAuth2Scopes(Exception):
    pass
