# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

from . import purchase_request_allocation
from . import orderpoint
from . import purchase_request
from . import purchase_request_line
from . import stock_rule
from . import product_template
from . import purchase_order
from . import stock_move
from . import stock_move_line
