"""Define version number here and read it from setup.py automatically"""
__version__ = "2.2.1"
