"""
Emulate commonly used fonctions, either for older Python versions, or in case an optional dependency is missing.
""" 
