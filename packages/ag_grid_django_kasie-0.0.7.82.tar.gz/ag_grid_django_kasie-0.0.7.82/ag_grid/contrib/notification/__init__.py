default_app_config = "ag_grid.contrib.notification.apps.NotificationConfig"
