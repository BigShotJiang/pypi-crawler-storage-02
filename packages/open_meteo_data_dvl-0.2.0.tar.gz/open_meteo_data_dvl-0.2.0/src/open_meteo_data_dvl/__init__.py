"""Open Meteo Data Client"""
