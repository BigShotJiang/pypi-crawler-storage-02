Authors
=======

Christopher Farrow, Pavol Juhas, Simon J. L. Billinge, and members of the Billinge Group

Contributors
------------

For a list of contributors, visit
https://github.com/diffpy/diffpy.srfit/graphs/contributors
