# Núcleo da aplicação


