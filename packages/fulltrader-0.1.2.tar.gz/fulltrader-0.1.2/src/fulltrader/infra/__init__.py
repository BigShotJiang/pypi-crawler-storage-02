# Integrações (DB, APIs, etc.)


