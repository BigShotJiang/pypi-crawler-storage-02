"""FullTrader Data SDK."""

from .use_cases.hello.say_hello import say_hello as hello

__all__ = ["hello", "__version__"]
__version__ = "0.1.2"


