# Pygments Lexer

The lexer module extracts from [Pygments](https://pygments.org/).

This module synced with Pygments 2.18.0.
