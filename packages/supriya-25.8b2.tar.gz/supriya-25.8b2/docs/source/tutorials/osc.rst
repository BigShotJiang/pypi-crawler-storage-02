:status: under-construction

Open Sound Control
==================

..  self-criticism::

    These docs are still under construction.

- what is osc
- anatomy of an osc message

Messages
--------

Bundles
```````

Scheduling
``````````

Protocols
---------

Threaded
````````

Async
`````

Healthchecks
````````````

Callbacks
---------

Registering
```````````

Unregistering
`````````````

Requests
--------

Responses
`````````

Request bundles
```````````````

Debugging
---------

Logging
```````

Capturing
`````````
