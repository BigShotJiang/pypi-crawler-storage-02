"""XPawn: A Python client for the XPawn API."""

__version__ = "0.2.3"

from .client import Client