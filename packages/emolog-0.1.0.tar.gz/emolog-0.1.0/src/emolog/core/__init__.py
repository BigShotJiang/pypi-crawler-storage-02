# Core modules for emolog
