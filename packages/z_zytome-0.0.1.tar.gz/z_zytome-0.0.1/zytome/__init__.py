"""zytome"""

__version__ = "0.0.1"
__author__ = "Marko Zolo Gozano Untalan"
