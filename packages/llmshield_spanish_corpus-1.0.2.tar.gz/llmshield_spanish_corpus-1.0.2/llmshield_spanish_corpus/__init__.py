"""Spanish corpus data for the LLMShield package."""

from .loader import get_corpus_path

__all__ = ["get_corpus_path"]
