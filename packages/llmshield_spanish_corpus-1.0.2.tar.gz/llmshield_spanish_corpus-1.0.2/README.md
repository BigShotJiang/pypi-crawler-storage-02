[![Upload Python Package](https://github.com/brainpolo/llmshield_english_corpus/actions/workflows/python-publish.yml/badge.svg)](https://github.com/brainpolo/llmshield_english_corpus/actions/workflows/python-publish.yml)

# LLMShield Spanish Corpus
