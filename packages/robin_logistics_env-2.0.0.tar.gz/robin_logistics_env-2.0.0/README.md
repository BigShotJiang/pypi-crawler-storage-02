# Robin Logistics Environment

[![PyPI version](https://badge.fury.io/py/robin-logistics-env.svg)](https://badge.fury.io/py/robin-logistics-env)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A comprehensive logistics optimization environment for developing and testing multi-depot vehicle routing algorithms. Built for hackathons, research, and educational purposes.

## 🚀 Quick Start

### Installation

```bash
pip install robin-logistics-env
```

### Basic Usage

```python
from robin_logistics import LogisticsEnvironment

# Load the environment
env = LogisticsEnvironment()

# Define your solver function
def my_solver(env):
    """Your optimization algorithm goes here"""
    routes = {}
    
    # Access environment data
    warehouses = env.warehouse_locations
    orders = env.order_requirements
    vehicles = env.get_available_vehicles()
    
    # Build your solution
    for vehicle_id in vehicles[:len(orders)]:
        warehouse_node = env.get_vehicle_home_warehouse(vehicle_id)
        order = orders[0] if orders else None
        
        if order:
            routes[vehicle_id] = [
                warehouse_node,
                order['destination_node'],
                warehouse_node
            ]
            orders.pop(0)
    
    return {"routes": routes}

# Launch interactive dashboard
env.launch_dashboard(my_solver)
```

## 📋 Features

### 🎯 Core Capabilities
- **Multi-depot vehicle routing** with real-world constraints
- **Interactive dashboard** with real-time visualization
- **Performance metrics** and algorithm comparison
- **Dynamic problem generation** with configurable parameters
- **Solution validation** and cost estimation

### 🛠️ Environment API
- **Distance calculations** between any nodes
- **Route optimization** helpers and validation
- **Inventory management** across multiple warehouses
- **Vehicle capacity** and constraint checking
- **Order fulfillment** tracking and analytics

### 📊 Dashboard Features
- **Problem Definition Editor** - Configure orders, warehouses, inventory
- **Interactive Map** - Visualize routes and locations
- **Performance Metrics** - Track solver time, costs, efficiency
- **Order Inspector** - Detailed order and delivery information
- **Real-time Analytics** - Vehicle utilization, delivery rates

## 📖 API Reference

### LogisticsEnvironment

The main interface for accessing problem data and running optimizations.

#### Properties

```python
env.num_warehouses          # Number of distribution centers
env.num_vehicles            # Total fleet size
env.num_orders             # Customer orders count
env.warehouse_locations    # [(warehouse_id, lat, lon), ...]
env.customer_locations     # [(order_id, lat, lon), ...]
env.order_requirements     # Detailed order specifications
env.vehicle_specs          # Vehicle capacity and cost info
```

#### Core Methods

```python
# Distance and routing
env.get_distance(node1, node2)                    # Shortest distance in km
env.get_shortest_path(node1, node2)               # Path as list of nodes
env.calculate_route_statistics(route)             # Distance, stops, etc.

# Vehicle and capacity checking
env.get_available_vehicles()                      # List of vehicle IDs
env.can_vehicle_serve_orders(vehicle_id, orders)  # Capacity validation
env.get_vehicle_home_warehouse(vehicle_id)        # Home base location

# Order and inventory management
env.get_order_location(order_id)                  # Delivery destination
env.get_warehouse_inventory(warehouse_id)         # Stock levels
env.get_unassigned_orders(current_solution)       # Remaining orders

# Solution validation and optimization
env.validate_route(vehicle_id, route)             # Check route validity
env.estimate_route_cost(vehicle_id, route)        # Cost estimation
env.run_optimization(solver_function)             # Execute and analyze
```

#### Advanced Utilities

```python
# Geographic analysis
env.get_nodes_within_distance(center, max_dist)   # Nearby locations
env.get_sku_info()                                # Product specifications

# Performance analysis
env.launch_dashboard(solver_function)             # Interactive visualization
```

## 🧪 Example Solvers

### Basic Nearest Neighbor

```python
def nearest_neighbor_solver(env):
    """Simple nearest neighbor heuristic"""
    routes = {}
    unassigned = list(range(len(env.order_requirements)))
    
    for vehicle_id in env.get_available_vehicles():
        if not unassigned:
            break
            
        warehouse_node = env.get_vehicle_home_warehouse(vehicle_id)
        route = [warehouse_node]
        current_node = warehouse_node
        vehicle_orders = []
        
        while unassigned:
            # Find nearest unassigned order
            nearest_order = None
            min_distance = float('inf')
            
            for i, order_idx in enumerate(unassigned):
                order = env.order_requirements[order_idx]
                order_node = order['destination_node']
                distance = env.get_distance(current_node, order_node)
                
                # Check capacity constraints
                if env.can_vehicle_serve_orders(vehicle_id, [order['order_id']]):
                    if distance < min_distance:
                        min_distance = distance
                        nearest_order = i
            
            if nearest_order is None:
                break
                
            # Add order to route
            order_idx = unassigned.pop(nearest_order)
            order = env.order_requirements[order_idx]
            current_node = order['destination_node']
            route.append(current_node)
        
        # Return to warehouse
        route.append(warehouse_node)
        routes[vehicle_id] = route
    
    return {"routes": routes}
```

### Advanced Genetic Algorithm

```python
def genetic_algorithm_solver(env):
    """Genetic algorithm for vehicle routing"""
    import random
    
    def create_individual():
        orders = list(range(len(env.order_requirements)))
        random.shuffle(orders)
        return orders
    
    def evaluate_fitness(individual):
        # Convert to routes and calculate cost
        routes = assign_orders_to_vehicles(individual, env)
        return calculate_total_cost(routes, env)
    
    def crossover(parent1, parent2):
        # Order crossover (OX)
        size = len(parent1)
        start, end = sorted(random.sample(range(size), 2))
        child = [-1] * size
        child[start:end] = parent1[start:end]
        
        remaining = [x for x in parent2 if x not in child]
        for i in range(size):
            if child[i] == -1:
                child[i] = remaining.pop(0)
        return child
    
    def mutate(individual):
        # Swap mutation
        i, j = random.sample(range(len(individual)), 2)
        individual[i], individual[j] = individual[j], individual[i]
        return individual
    
    # Genetic algorithm main loop
    population_size = 100
    generations = 500
    mutation_rate = 0.1
    
    population = [create_individual() for _ in range(population_size)]
    
    for generation in range(generations):
        # Evaluate fitness
        fitness_scores = [evaluate_fitness(ind) for ind in population]
        
        # Selection, crossover, mutation
        new_population = []
        for _ in range(population_size):
            parent1 = tournament_selection(population, fitness_scores)
            parent2 = tournament_selection(population, fitness_scores)
            child = crossover(parent1, parent2)
            
            if random.random() < mutation_rate:
                child = mutate(child)
            
            new_population.append(child)
        
        population = new_population
    
    # Return best solution
    best_individual = min(population, key=evaluate_fitness)
    return assign_orders_to_vehicles(best_individual, env)
```

## 🎛️ Dashboard Configuration

The interactive dashboard provides comprehensive control over problem parameters:

### Problem Definition
- **Orders**: Number, weight ratios, SKU variety
- **Warehouses**: Count, locations, inventory distribution  
- **Fleet**: Vehicle count per warehouse, capacity specifications
- **Geography**: Delivery distance constraints

### Performance Metrics
- **Timing**: Solver execution, simulation overhead
- **Efficiency**: Delivery rates, cost per order, fleet utilization
- **Quality**: Solution validation, constraint satisfaction

### Visualization
- **Interactive Map**: Real-time route visualization with order details
- **Analytics**: Vehicle status, inventory usage, journey analysis
- **Comparison**: Multi-algorithm performance benchmarking

## 🔧 Development Setup

### Local Installation

```bash
# Clone repository
git clone https://github.com/your-org/robin-logistics-env.git
cd robin-logistics-env

# Install in development mode
pip install -e .

# Install development dependencies
pip install -r requirements-dev.txt
```

### Running Tests

```bash
# Run test suite
python -m pytest tests/

# Run with coverage
python -m pytest tests/ --cov=robin_logistics --cov-report=html
```

### Building Documentation

```bash
# Generate API documentation
cd docs/
make html

# Serve locally
python -m http.server 8000 --directory _build/html
```

## 🎯 Problem Constraints

### Vehicle Constraints
- **Capacity**: Weight (kg) and volume (m³) limits
- **Distance**: Maximum travel distance per route
- **Home Base**: Must start and end at assigned warehouse

### Order Constraints  
- **Delivery**: Each order has a specific destination
- **Items**: Multiple SKUs with different weight/volume
- **Fulfillment**: Orders must be completely satisfied

### Inventory Constraints
- **Availability**: Limited stock at each warehouse
- **Distribution**: Configurable inventory allocation
- **Depletion**: Stock decreases with order fulfillment

## 📈 Solution Format

Your solver function must return a dictionary with the following structure:

```python
{
    "routes": {
        "vehicle_id_1": [warehouse_node, customer_node_1, customer_node_2, warehouse_node],
        "vehicle_id_2": [warehouse_node, customer_node_3, warehouse_node],
        # ... more routes
    }
}
```

### Route Requirements
- **Start/End**: Routes must begin and end at the vehicle's home warehouse
- **Nodes**: Use node IDs from the road network
- **Orders**: Visit customer nodes to fulfill orders
- **Capacity**: Respect vehicle weight and volume limits
- **Distance**: Stay within vehicle's maximum travel distance

## 🏆 Optimization Tips

### Algorithm Design
1. **Start Simple**: Implement nearest neighbor or greedy heuristics first
2. **Add Constraints**: Gradually incorporate capacity and distance limits
3. **Improve Solutions**: Use local search, genetic algorithms, or simulated annealing
4. **Handle Edge Cases**: Empty orders, unreachable locations, capacity exceeded

### Performance Optimization
1. **Distance Caching**: Cache frequently accessed distances
2. **Early Termination**: Stop when solutions aren't improving
3. **Parallel Processing**: Use multiple threads for population-based algorithms
4. **Memory Management**: Avoid storing unnecessary intermediate solutions

### Dashboard Usage
1. **Problem Tuning**: Use sliders to test different problem sizes
2. **Performance Analysis**: Monitor solver time vs solution quality
3. **Visual Debugging**: Use the map to identify routing inefficiencies
4. **Comparison**: Test multiple algorithms on the same problem instance

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Development Workflow
1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Make your changes with tests
4. Run the test suite: `python -m pytest`
5. Submit a pull request

### Issue Reporting
- Use GitHub Issues for bug reports and feature requests
- Include code samples and error messages
- Describe your environment (Python version, OS, etc.)

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built for logistics optimization education and research
- Inspired by real-world vehicle routing challenges
- Designed for hackathon accessibility and extensibility

## 📚 Additional Resources

- [Vehicle Routing Problem on Wikipedia](https://en.wikipedia.org/wiki/Vehicle_routing_problem)
- [Operations Research Techniques](https://www.coursera.org/learn/operations-research-modeling)
- [Python Optimization Libraries](https://pypi.org/search/?q=optimization)

---

**Happy Optimizing!** 🚛📦✨