from chilo_api.cli import CLIManager  # pragma: no cover


if __name__ == '__main__':
    cli = CLIManager()
    cli.run()
