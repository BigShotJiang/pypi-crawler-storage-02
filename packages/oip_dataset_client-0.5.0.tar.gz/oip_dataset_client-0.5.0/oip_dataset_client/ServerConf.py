SERVER_MODULE_NAME: str = "dataset"
WORKSPACE_ENTITY_NAME: str = "workspace"
DATASET_ENTITY_NAME: str = "ml_dataset"
