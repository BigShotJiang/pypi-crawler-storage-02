"""Strategies for permission management."""

from ._factory import PermissionStrategyFactory

__all__ = [
    "PermissionStrategyFactory",
]
