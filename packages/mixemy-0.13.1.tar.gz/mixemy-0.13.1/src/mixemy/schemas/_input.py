from mixemy.schemas._base import BaseSchema


class InputSchema(BaseSchema):
    pass
